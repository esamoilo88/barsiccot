import axios from 'axios';
import Vue from 'vue';

const $axios = axios.create();
$axios.interceptors.response.use(function (response) {
        return response;
    }, function (error) {
        if (error.response.status == 401) {
            document.location.reload();
        }
        return Promise.reject(error);
    }
);

$axios.defaults.headers.common['isAjax'] = true;

const eventBus = new Vue();

export {
    $axios,
    eventBus
};
