<template>
    <div class="tasks-status-container">
        <div>
            <button v-b-toggle.collapse-1 class="btn btn-secondary w-100">{{ collapseTitle }}</button>
            <b-collapse :visible="visible" id="collapse-1" class="collapse-container">
                <div v-if="items.length == 0" class="d-flex justify-content-center collapse-content">
                    <b-spinner small v-if="pending" class="m-1"></b-spinner>
                    <span v-else class="mt-2">Keine Daten vorhanden.</span>
                </div>
                <div v-else  class="collapse-content">
                    <Item
                        v-for="item in items"
                        :item="item"
                        :key="item.id"
                        :is-expandable="item.status.value == 'fail' && item.data.errors && item.data.errors.length > 0"
                        class="mt-2"
                    >
                        <div v-if="item.status.value == 'fail' && item.data.errors && item.data.errors.length > 0">
                            <ul class="mt-2">
                                <li v-for="err in item.data.errors" class="error-message">{{ err }}</li>
                            </ul>
                        </div>
                    </Item>
                </div>
            </b-collapse>
        </div>
    </div>
</template>

<script>
import {$axios} from 'res/js/boot';
import {BCollapse, BSpinner, VBToggle} from 'bootstrap-vue';
import Item from "./Item";

export default {
    name: "Container",
    components: {
        Item, BCollapse, BSpinner
    },
    directives: {
        'b-toggle': VBToggle
    },
    props: {
        keyProp: { // a key which is used for storing tasks inside redis
            type: String,
            required: true
        },
        collapseTitle: {
            type: String,
            required: true
        },
        timeout: {
            type: Number,
            required: false,
            default: 10000
        },
        visible: {
            type: Boolean,
            required: false,
            default: true
        }
    },
    data() {
        return {
            items: [],
            timerId: null,
            overflowContent: false,
            pending: false
        }
    },
    async mounted() {
        await this.fetchLastStatuses();
        if (this.items.length > 0) {
            this.init();
        }
    },
    methods: {
        async fetchLastStatuses() {
            this.pending = true;
            try {
                const res = await $axios.post(`/queue/tasks/statuses`, {key: this.keyProp});
                if (res.data.tasks) {
                    this.show = res.data.tasks.length > 0;
                    this.items.splice(0);
                    this.items.push(...res.data.tasks);
                }
            } catch (err) {
                console.error("Couldn't get data for queue tasks statuses! Err: ", err);
            }
            this.pending = false;
        },
        init() {
            setInterval(this.fetchLastStatuses, this.timeout);
        },
        removeInterval() {
            clearInterval(this.timerId);
        },
        async refresh() {
            this.removeInterval();
            await this.fetchLastStatuses();
            this.init();
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.tasks-status-container {
    max-width: 490px;

    .collapse-content {
        min-height: 30px;
    }

    /* width */
    ::v-deep ::-webkit-scrollbar {
        width: 4px;
        height: 4px;
    }

    /* Track */
    ::v-deep ::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

    /* Handle */
    ::v-deep ::-webkit-scrollbar-thumb {
        background: darkgrey;
    }

    /* Handle on hover */
    ::v-deep ::-webkit-scrollbar-thumb:hover {
        background: #555;
    }
}

.collapse-container {
    max-height: 300px;
    overflow-y: auto;

    .error-message {
        color: $error;
    }
}
</style>
