<template>
    <div :class="{
        'queue-task-status': true,
        'pending': item.status.value == 'pending',
        'successfull': item.status.value == 'success',
        'fail': item.status.value == 'fail',
        'p-2': true
    }">
        <div class="basic-data d-flex justify-content-between align-items-center">
            <div class="task-date">
                <b class="mr-2">Datum:</b> {{ timestampToDatetime() }}
            </div>
            <div class="task-status">
                <b class="mr-2">Status:</b>
                <span :class="statusIcon"></span>
                <span class="task-status-text">{{ statusText }}</span>
            </div>
            <div class="expand-btn-wrapper">
                <button v-if="isExpandable" v-b-toggle="item.ts + '-' + item.status.value" class="btn btn-secondary expand-btn py-1 px-2">
                    <span class="icon-action-more-selected vertical-align-middle"></span>
                </button>
            </div>
        </div>

        <b-collapse v-if="isExpandable" :id="item.ts + '-' + item.status.value">
            <template>
                <slot></slot>
            </template>
        </b-collapse>
    </div>
</template>

<script>
import {BCollapse, VBToggle} from 'bootstrap-vue';
import dayjs from "res/js/utils/day";

export default {
    name: "Item",
    components: {
        BCollapse, VBToggle
    },
    directives: {
        'b-toggle': VBToggle
    },
    props: {
        item: {
            type: Object,
            required: true
        },
        isExpandable: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    computed: {
        statusIcon() {
            switch (this.item.status.value) {
                case 'success':
                    return 'icon-action-succsess-selected task-status-icon';
                case 'fail':
                    return 'icon-alert-error-default task-status-icon';
                case 'pending':
                    return 'icon-content-clock-default task-status-icon';
            }
        },
        statusText() {
            switch (this.item.status.value) {
                case 'success':
                    return 'Erfolg';
                case 'fail':
                    return 'Fehler';
                case 'pending':
                    return 'Warteschlange';
            }
        }
    },
    methods: {
        timestampToDatetime() {
            return dayjs.unix(Number(this.item.ts)).format('DD.MM.YYYY  HH:mm:ss');
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.expand-btn-wrapper {
    min-width: 37px;
}

.queue-task-status {
    border: 1px solid lightgrey;
    border-radius: 0.25rem;
}

.fail .task-status-text,
.fail .task-status-icon {
    color: $error;
}

.successfull .task-status-text,
.successfull .task-status-icon {
    color: $success;
}

.pending .task-status-text,
.pending .task-status-icon {
    color: $link;
}
</style>
