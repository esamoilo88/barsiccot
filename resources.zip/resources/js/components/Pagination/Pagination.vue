<template>
    <div class="pagination-wrapper">
        <div>
            <span class="total-rows-text">{{ paginationEntriesText }}</span>
            <span class="font-weight-bold">{{ totalRowsProp }}</span>
        </div>
        <b-pagination
            v-if="perPageProp != -1"
            :value="currentPage"
            class="m-0"
            @input="val => $emit('input', val)"
            :total-rows="totalRowsProp"
            :per-page="perPageProp"
            :aria-controls="tableId"
            label-first-page="zur ersten Seite"
            label-prev-page="Zurück zur letzten Seite"
            label-next-page="gehe zur nächsten Seite"
            label-last-page="zur letzten Seite"
            label-page="gehe zu Seite"
        >
            <template #first-text><span class="icon-action-fast-forward_nb-default"></span></template>
            <template #prev-text><span class="icon-action-play_nb-default"></span></template>
            <template #next-text><span class="icon-action-play_nb-default"></span></template>
            <template #last-text><span class="icon-action-fast-forward_nb-default"></span></template>
        </b-pagination>
        <div class="d-flex">
            <button
                v-for="pages in perPageVariants"
                class="btn btn-secondary text-decoration-none ml-1 per-page-selector"
                :class="{'active': perPageProp == pages}"
                @click="$emit('per-page-changed', pages)"
            >
                {{ pages === -1 ? 'Alle' : pages }}
            </button>
        </div>
    </div>
</template>

<script>
import {BPagination} from 'bootstrap-vue';

export default {
    name: "Pagination",
    components: {
        BPagination
    },
    props: {
        paginationEntriesText: {
            type: String,
            required: false,
            default: 'Anzahl Positionen:'
        },
        perPageProp: {
            type: Number,
            required: true
        },
        currentPage: {
            type: Number,
            required: true
        },
        totalRowsProp: {
            type: Number,
            required: true
        },
        tableId: {
            type: String,
            required: true
        },
        perPageVariants: {
            type: Array,
            required: false,
            default: () => []
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep li.page-item:nth-child(1) .page-link,
::v-deep li.page-item:nth-child(2) .page-link {
    transform: scale(-1, 1);
}

::v-deep .page-item .page-link {
    display: inline-flex;
    align-items: center;
    border: none;
    color: #000;
    background-color: transparent;
    padding-top: 0.4rem;

    span[class*="icon-"] {
        color: #000;
        margin-top: 2px;
    }
}

::v-deep .page-item.active .page-link {
    font-weight: 700;
}

::v-deep .page-item.disabled {
    opacity: 0.5;
    &:hover {
        background-color: transparent;
    }
}

::v-deep .page-item {
    &:hover {
        background-color: rgba(0, 0, 0, 0.07);
    }
}

.pagination-wrapper {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    position: relative;
    justify-content: space-between;

    .total-rows-text {
        margin-left: 20px;
    }
}
</style>
