<template>
    <div class="change-month-button">
        <button
            @click="addMonth(fieldName)"
            title="1 Monat hinzufügen"
            :disabled=disabledButton(form[fieldName])
            class="btn btn-secondary submit-btn"
        >
            <span>+</span>
        </button>
        <button
            @click="subtractsMonth(fieldName)"
            title="1 Monat abziehen"
            :disabled=disabledButton(form[fieldName])
            class="btn btn-secondary submit-btn"
        >
            <span>-</span>
        </button>
    </div>
</template>
<script>

export default {
    name: "change-month",
    props: {
        fieldName: {
            type: String,
            required: false,
            default: false
        },
        form:{
            type: Object,
            required: false,
            default: false
        },
    },
    data(){
        return {
            field: {
                vertragsbeginn: '',
                vertragsende: '',
                rolloutbeginn: '',
                rolloutende: '',
                betriebsbeginn: '',
                betriebsende: '',
                beauftragungsende: '',
            }
        }
    },
    methods: {
        addMonth(attribute) {
            let arr = this.form[attribute].split('.');
            let month = parseInt(arr[1]);
            let year = parseInt(arr[2]);
            if (month <= 11) {
                month = (month < 9) ? '0' + String(month + 1) : month + 1;
            } else {
                year = year + 1;
                month = '01';
            }
            this.field[attribute] = arr[0] + '.' + month + '.' + year;
            this.$emit('change-field',this.field[attribute],attribute)
        },
        subtractsMonth(attribute) {
            let arr = this.form[attribute].split('.');
            let month = parseInt(arr[1]);
            let year = parseInt(arr[2]);
            if (month >= 2) {
                month = (month < 11) ? '0' + String(month - 1) : month - 1;
            } else {
                year = year - 1;
                month = 12;
            }
            this.field[attribute] = arr[0] + '.' + month + '.' + year;
            this.$emit('change-field',this.field[attribute], attribute)
        },
        disabledButton(field) {
            return field === '';
        }
    }
}
</script>

<style scoped>
.change-month-button{
    display: inherit;
}
</style>
