<template>
    <div
        ref="searchableSelect"
        :class="{
            'searchable-select': true,
            'form-group-floating': true,
            'upper-label': content,
            'is-invalid': errorsNumber > 0,
            'no-label': labelText === '' || labelText === null
        }"
    >
        <label
            @click="open"
            :class="{'searchable-select-label': true}"
            :id="selectId + '__label'"
            :for="selectId"
        >
            {{ labelText }}
        </label>
        <Select2
            :id="selectId"
            :name="name"
            ref="searchableSelectTag"
            class="searchable-select-inner"
            v-model="content"
            :options="option"
            :settings="settings"
            @change="handleChange"
            @select="handleSelect"
            :disabled="readonly"
        />
        <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";
import Select2 from 'v-select2-component';

export default {
    name: 'FormSelect',
    components: {
        Select2, FormInputErrors
    },
    mixins: [ErrorsMxn],
    props: {
        value: null,
        name: {
            type: String,
            required: true
        },
        selectId: {
            type: String,
            required: true
        },
        labelText: {
            type: String,
            required: false,
            default: null
        },
        options: {
            type: Array,
            required: true
        },
        userSettings: {
            type: Object,
            required: false
        },
        searchable: {
            type: Boolean,
            required: false,
            default: false
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        },
        readonly: {
            type: Boolean,
            required: false,
            default: false
        },
        withHtml: {
            type: Boolean,
            required: false,
            default: false
        },
        withHtmlSelection: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            content: this.value,
            previousContent: this.value,
            settings: {   // https://select2.org/configuration/options-api
                minimumResultsForSearch: -1,
                language: {
                    noResults: () => 'Keine Einträge gefunden'
                },
                width: '100%',
            },
            isLabelCanOpen: true,
            dataOptions: null
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.content = newVal;
        }
    },
    computed: {
        option() {
            if (!this.dataOptions) return this.options;
            return this.dataOptions;
        }
    },
    created() {
        this.content = this.value === 'empty' ? null : this.value;

        this.settings = {...this.settings, ...this.userSettings}
        if (this.searchable) {
            this.settings.minimumResultsForSearch = undefined;
        }

        if (this.withHtml) {
            this.settings = {
                ...this.settings,
                escapeMarkup: function (markup) {
                    return markup;
                },
                templateResult: function (data) {
                    return data.html;
                },
                templateSelection: data => {
                    return this.withHtmlSelection ? data.html : data.text;
                }
            }
        }
    },
    mounted() {
        this.$refs.searchableSelectTag.select2.on('select2:close', () => {
            this.isLabelCanOpen = false;
            setTimeout(() =>  this.isLabelCanOpen = true, 300);
        });
        this.$refs.searchableSelectTag.select2.on('select2:selecting', (e) => {
            if (e.params.args.data.id === 'empty' && (this.previousContent === null || this.previousContent === undefined)) {
                this.$refs.searchableSelectTag.select2.select2('close');
                e.preventDefault();
            }
        });
    },
    methods: {
        handleSelect(value) {
            setTimeout(() => {
                this.$refs.searchableSelectTag.select2.select2('focus');
            }, 1);
            this.previousContent = this.content;
            this.$emit('select', this.content);
        },
        handleChange(value) {
            this.content = this.content === 'empty' ? null : this.content;
            if (this.content === null) {
                this.$refs.searchableSelectTag.select2.select2('data', null);
                this.$emit('input', null);
            } else {
                this.$emit('input', this.content);
            }
            this.$emit('change', this.content);
        },
        open() {
            if (this.isLabelCanOpen) {
                this.$refs.searchableSelectTag.select2.select2('open');
            } else {
                this.$refs.searchableSelectTag.select2.select2('close');
            }
            this.isLabelCanOpen = !this.isLabelCanOpen;
        },
        /**
         * Destroy and recreate select2 input when some of the settings were
         * changed dynamically, but select2 couldn't apply it reactively
         */
        reinitialize() {
            this.$refs.searchableSelectTag.select2.select2('destroy');
            this.$refs.searchableSelectTag.select2.select2({
                ...this.settings,
                data: this.options
            });
        },
        setOptions(options) {
            this.dataOptions = []
            this.dataOptions.push(options);
        },
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.one-error {
    padding-left: 0 !important;
    list-style: none;
}

.searchable-select {
    min-width: 200px;
    padding: 2px;
    position: relative;
}

.searchable-select-label {
    position: absolute;
    z-index: 1;
    top: 14px;
    left: 15px;
    color: #888;
    cursor: pointer;
    transition: transform 150ms ease-out, font-size 150ms ease-out;
}

.upper-label .searchable-select-label {
    transform: translateY(-50%);
    font-size: .75em;
}

::v-deep div.searchable-select-inner,
::v-deep span.select2.select2-container.select2-container--default,
::v-deep span.select2-selection.select2-selection--single {
	min-height: 44px;
}

::v-deep span.select2-selection.select2-selection--single {
	border-color: #ccc;
	outline: 0;
	box-shadow: 0 1px 0 0 #e5e5e5;
    display: flex;
}

::v-deep span.select2.select2-container.select2-container--default.select2-container--below.select2-container--open .select2-selection--single,
::v-deep .select2.select2-container.select2-container--default.select2-container--focus .select2-selection--single {
    box-shadow: inset 0 -2px $primary;
}

.is-invalid {
    ::v-deep .select2-selection.select2-selection--single {
        border: 1px solid $error;
    }

    .invalid-feedback {
        color: $error;
        padding-left: 20px;
        padding-top: 5px;
        margin-bottom: 0;
    }
}

::v-deep .select2.select2-container.select2-container--default {
    min-height: 44px;
}

::v-deep .select2-container--default .select2-selection--single .select2-selection__arrow {
	top: 50%;
    transform: translateY(-50%);
}

::v-deep .select2-container .select2-selection--single .select2-selection__rendered {
    align-self: flex-end;
    text-overflow: ellipsis;
    margin-bottom: -3px;
    padding-left: 12px;
}

::v-deep .select2-container--default .select2-selection--single .select2-selection__arrow b {
    border-color: #000 transparent transparent transparent;
    margin-left: -13px;
}

::v-deep .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b {
    border-color: transparent transparent #000 transparent;
}

::v-deep .select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #000;
}

.no-label {
    ::v-deep div.searchable-select-inner,
    ::v-deep span.select2.select2-container.select2-container--default,
    ::v-deep span.select2-selection.select2-selection--single {
        min-height: 36px;
    }

    ::v-deep .select2.select2-container.select2-container--default {
        min-height: 36px;
    }
}
</style>
