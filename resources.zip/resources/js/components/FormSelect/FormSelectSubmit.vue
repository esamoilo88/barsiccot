<template>
    <div :class="{'inline-input__container': true, 'is-invalid': errorsNumber > 0}">
        <b-input-group>
            <b-form-select
                class="params-select"
                @input="onInput"
                @change="onChange"
                @submit="onSubmit"
                :id="inputId"
                name="view-type-select"
                :options="options"
                :disabled="readonly"
                with-html
                with-html-selection
                :value="content"
                :aria-describedby="subtext"
            />
            <template v-if="!withoutButton" #append>
                <button
                    v-if="!disabled"
                    @click="onSubmit"
                    :title="submitButtonTitle"
                    :aria-label="submitButtonTitle"
                    class="btn btn-secondary submit-btn"
                    v-b-tooltip.hover
                    :disabled="readonly"
                >
                    <b-spinner v-if="loading" small></b-spinner>
                    <span v-else class="icon-action-succsess-default"></span>
                </button>
            </template>
        </b-input-group>

        <label v-if="errorsNumber > 0" :for="inputId">
            <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
        </label>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";
import {BFormSelect, BSpinner, BInputGroup, VBTooltip} from 'bootstrap-vue';

export default {
    name: "FormSelectSubmit",
    components: {
        ButtonIcon, FormInputErrors, BFormSelect, BSpinner, BInputGroup
    },
    mixins: [ErrorsMxn],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        value: null,
        inputId: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => ([])
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        submitButtonTitle: {
            type: String,
            required: true
        },
        hintPosition: {
            type: String,
            required: false,
            default: 'righttop'
        },
        options: {
            type: Array,
            required: true,
            default: []
        },
        label: {
            type: String,
            required: true
        },
        subtext: {
            type: String,
            required: true
        },
        prependText: {
            type: String,
            required: false,
            default: ''
        },
        withoutButton: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            content: this.value,
            loading: false,
            readonly: this.disabled
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.content = newVal;
        }
    },
    computed: {
        errorsNumber() {
            let anyErrors = [];
            if (this.errorConditions !== undefined) {
                anyErrors = this.errorConditions.filter((error) => {
                    return error.condition;
                });
            }
            return anyErrors.length;
        }
    },
    methods: {
        onInput(value) {
            this.content = value;
            this.$emit('input', this.content);
        },
        onSubmit() {
            if (!(this.errorsNumber > 0)) {
                this.$emit('submit', this.content);
                this.isReadonly = true;
            }
        },
        setSpinner(isLoading) {
            this.loading = isLoading;
        },
        onChange() {
            if (this.withoutButton && !(this.errorsNumber > 0)) {
                this.$emit('submit', this.content);
                this.isReadonly = true;
            }
        },
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.inline-input.form-control {
    text-align: right;
    font-size: 100%;
    font-weight: bold;
    padding: 5px 5px;
    height: auto;

    &.circled-borders-left {
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
    }

    &.circled-borders-right {
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
    }
}

.inline-input .form-control:read-only {
    background-color: transparent;
    pointer-events: none;
}

.is-invalid {
    ::v-deep .select2-selection.select2-selection--single {
        border: 1px solid $error;
    }

    .invalid-feedback {
        font-size: 85%;
        color: $error;
        padding-left: 20px;
        padding-top: 5px;
        margin-bottom: 0;
    }
}

.inline-input .form-control:read-only::-webkit-outer-spin-button,
.inline-input .form-control:read-only::-webkit-inner-spin-button {
    -webkit-appearance: none;
}

.inline-input__container {
    .input-group-text {
        background-color: #ededed;
    }

    .submit-btn {
        border: 1px solid #ced4da;
    }
}
select {
    min-height: 33px !important;
    height: 34px !important;
}
</style>
