<template>
    <div>
        <div class="row align-items-end">
            <div class="col-lg-7 pr-sm-0 pr-lg-2 pl-0">
                <div class="mb-3">
                    <div class="dropdown">
                        <h1 class="d-inline-block">
                            Produktkatalog
                        </h1>
                        <button title="Katalog wechseln" type="button" class="btn btn-lg dropdown-toggle dropdown-toggle-split py-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="sr-only">Toggle Dropdown</span>
                        </button>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="catalogDropdown">
                            <a
                                v-for="item in dropdownOptions"
                                @click.prevent="toggleCatalogType(item.key)"
                                :class="{'selected': selectedCatalogType === item.key}"
                                class="dropdown-item"
                                href="#"
                            >
                                <span class="dropdown-icon icon-action-succsess-default"></span>
                                <span>{{ item.name }}</span>
                            </a>
                        </div>
                    </div>
                    <div>{{ title }}</div>
                </div>

                <slot name="buttons"></slot>
            </div>

            <div class="col-lg-17 pr-0 pl-sm-0 pl-lg-2 mt-sm-2 mt-lg-0">
                <div class="d-flex justify-content-end">
                    <div class="search-container">
                        <div class="floating-label prepend">
                            <span class="icon-action-search-default"></span>
                            <input v-model="searchVal" @keyup.enter="search" type="text" class="form-control" id="katalog_suchen-input" placeholder="Katalog durchsuchen">
                            <label for="katalog_suchen-input">Katalog durchsuchen</label>
                        </div>
                        <button class="btn btn-primary" @click="search">Suchen</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row flex-lg-nowrap">
            <div class="pr-sm-0 pr-lg-2 pl-0" :class="toggleCatalogView ? 'col-lg-auto' : 'col-lg-7'">
                <div class="simple-box bg-white h-100">
                    <div v-show="toggleCatalogView">
                        <button @click="setToggleCatalogView(false)" class="btn-light" title="Katalog einblenden">
                            <i class="icon-action-menu-default"></i>
                        </button>
                    </div>
                    <div v-show="!toggleCatalogView">
                        <h3 class="mb-4">Katalogbrowser</h3>

                        <div class="placeholder-preloader-wrapper" v-if="pending">
                            <div class="ph-item">
                                <div class="ph-col-24">
                                    <div class="ph-row">
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                        <div class="ph-col-24"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-for="tree in treeData">
                            <Tree
                                class="item"
                                :item="tree"
                                :selected-item="selectedTreeItem"
                                name-field="bezeichnung"
                                id-field="kategorieId"
                                :open="openCatalog"
                            ></Tree>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pr-0 pl-sm-0 pl-lg-2 mt-sm-2 mt-lg-0" :class="toggleCatalogView ? 'col' : 'col-lg-17'">
                <div class="catalog-table" :class="{'simple-box bg-white': !focusNav}">
                    <div :class="{'simple-box': focusNav}">
                        <div class="row no-gutters align-items-center">
                            <div class="col" v-if="selectedTreeItem.kategorieId">
                                <nav v-if="breadcrumbs.length" aria-label="breadcrumb">
                                    <ol class="breadcrumb bg-white text-muted p-0 mb-2">
                                        <li class="breadcrumb-item">Produktkatalog</li>
                                        <template v-for="item in breadcrumbs">
                                            <li class="breadcrumb-item">{{ item }}</li>
                                        </template>
                                    </ol>
                                </nav>

                                <h3 class="mb-3">{{ positionName ? positionName : selectedTreeItem.bezeichnung }}</h3>
                            </div>

                            <slot name="nav"></slot>
                        </div>

                        <slot name="belownav"></slot>
                    </div>

                    <slot name="table"></slot>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Tree from "@comp/Common/NodeTree/Tree"

export default {
    components: {Tree},
    props: {
        treeData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        focusNav: {
            type: Boolean,
            default: false
        },
        positionName: {
            type: String,
            default: null
        }
    },
    data() {
        return {
            pending: false,
            selectedCatalogType: 'ap',
            dropdownOptions: [
                {
                    key: 'ap',
                    name: 'Angebotspositionen',
                },
                {
                    key: 'lp',
                    name: 'Leistungspositionen',
                }
            ],
            selectedTreeItem: {
                kategorieId: null
            },
            searchVal: null,
            toggleCatalogView: false
        }
    },
    computed: {
        title() {
            return this.selectedCatalogType === 'ap' ? 'Angebotspositionen' : 'Leistungspositionen';
        },
        breadcrumbs() {
            const breadcrumbs = structuredClone(this.selectedTreeItem.breadcrumbs);

            if (this.positionName) {
                breadcrumbs.push(this.selectedTreeItem.bezeichnung);
            }

            return breadcrumbs;
        }
    },
    methods: {
        setPending(value) {
            this.pending = value;
        },
        toggleCatalogType(key) {
            this.selectedCatalogType = key;

            if (this.isTableOpen) {
                this.search();
            }

            this.$emit('catalogTypeChange', this.selectedCatalogType);
        },
        openCatalog(item) {
            this.selectedTreeItem = item;
            this.searchVal = null;

            this.search();
        },
        search() {
            this.$emit('search', {
                selectedTreeItem: this.selectedTreeItem,
                search: this.searchVal
            });
        },
        setToggleCatalogView(value) {
            this.toggleCatalogView = value;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables.scss';

::v-deep .placeholder-preloader-wrapper {
    display: flex;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        border: none;
        border-radius: 0;
        box-shadow: none;
        margin: 0;

        .ph-col-24 {
            padding: 0;
        }

    }

    .ph-row div {
        width: 350px;
    }
}

.breadcrumb-item + .breadcrumb-item::before {
    color: inherit;
    content: ">";
}

.search-container {
    display: grid;
    grid-template-columns: 1fr 0fr;
    gap: 16px;
    width: 500px;
    margin-bottom: 16px;
}

.dropdown-item {
    display: grid;
    grid-template-columns: 32px 0fr;
}

.dropdown-icon {
    visibility: hidden;
}

.dropdown-item.selected .dropdown-icon {
    visibility: visible;
}

.catalog-table {
    height: 100%;
}

</style>
