<template>
    <div :class="{'simple-badge': true, 'outline': outline}">
        <b-badge :class="{'w-100': fullWidth}" :style="{'background-color': !outline ? color : false, 'border-color': outline ? color : false}">
            <slot></slot>
        </b-badge>
    </div>
</template>

<script>
import {BBadge} from 'bootstrap-vue';

export default {
    name: "badge",
    components: {
        BBadge
    },
    props: {
        color: {
            type: String,
            required: false,
            default: '#e20074'
        },
        outline: {
            type: Boolean,
            required: false,
            default: false
        },
        fullWidth: {
            type: Boolean,
            required: false,
            default: false
        }
    }
}
</script>

<style lang="scss" scoped>
    .simple-badge {
        span.badge {
            color: #fff;
        }
    }
    .simple-badge.outline {
        span.badge {
            color: #000;
            background-color: #fff;
            border: 1px solid;
        }
    }
</style>
