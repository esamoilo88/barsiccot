<template>
    <div :class="{'loading-overlay': true, 'visible': busy}">
        <div class="loading-overlay__spinner">
            <b-spinner class="align-middle"></b-spinner>
            <span class="sr-only">wird heruntergeladen</span>
        </div>
    </div>
</template>

<script>
import {BSpinner} from 'bootstrap-vue';
export default {
    name: "BoxSpinner",
    components: {BSpinner},
    props: {
        busy: {
            type: Boolean,
            required: false,
            default: false
        }
    }
}
</script>

<style lang="scss" scoped>
.loading-overlay {
    display: none;
    position: absolute;
    background: rgba(255,255,255,0.35);
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 99;

    .loading-overlay__spinner {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

        span {
            width: 55px;
            height: 55px;
        }
    }
}

.loading-overlay.visible {
    display: block;
}
</style>
