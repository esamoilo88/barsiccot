<template>
    <div class="btn-icon__wrapper">
        <b-button
            ref="button"
            :class="'btn-icon ' + buttonClass"
            :id="buttonId"
            @click="$emit('click')"
            :variant="variant"
            :disabled="isDisabled"
            :type="type"
        >
            <b-spinner v-if="loading" small></b-spinner>
            <span v-else :class="'btn-icon__icon ' + iconClass"></span>
        </b-button>
        <b-tooltip v-if="title" :placement="hintPosition" :target="() => $refs['button']" :title="title"
                   triggers="hover"></b-tooltip>
    </div>
</template>

<script>
import {BButton, BTooltip, BSpinner} from 'bootstrap-vue';

export default {
    name: "button-icon",
    components: {
        BButton, BTooltip, BSpinner
    },
    props: {
        iconClass: {
            type: String,
            required: false
        },
        buttonId: {
            type: String,
            required: false
        },
        buttonClass: {
            type: String,
            required: false,
            default: ''
        },
        title: {
            type: String,
            required: false,
            default: ''
        },
        variant: {
            type: String,
            required: false,
            default: 'secondary'
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        type: {
            type: String,
            required: false,
            default: 'button'
        },
        hintPosition: {
            type: String,
            required: false,
            default: 'lefttop'
        }
    },
    data() {
        return {
            loading: false,
            isDisabled: this.disabled
        }
    },
    methods: {
        setSpinner(isLoading) {
            this.loading = isLoading;
            this.isDisabled = isLoading;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.btn-icon__wrapper {
    display: inline-block;
}

.btn-icon {
    padding: 3px 5px;
}

.btn-icon__icon {
    vertical-align: middle;
    font-size: 25px;
    color: $iconscolor;
}

.btn-icon-link {
    background-color: transparent;
    padding: 3px 5px;
    border: none;
}

.btn-icon.btn-primary,
.btn-icon.btn-danger {
    .btn-icon__icon {
        color: #fff;
    }
}
</style>
