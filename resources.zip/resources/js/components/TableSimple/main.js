// THIS FILE IS FOR TESTING TableWithFilters COMPONENT
import Vue from 'vue';
import TableSimple from "./TableSimple";
import ButtonIcon from '../ButtonIcon/ButtonIcon';
import SimpleDropdown from '../SimpleDropdown/SimpleDropdown';
import vueDebounce from 'vue-debounce';
import {$axios} from '../../boot';
import SimpleTranslator from "../../utils/SimpleTranslator";
import {BDropdownItemButton} from 'bootstrap-vue';

const translations = require('../../../lang/lang.translations.json');

const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;
Vue.prototype.$axios = $axios;
Vue.use(vueDebounce);

export default new Vue({
    el: '#filter-component', //https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/TableSimple
    components: {
        TableSimple, ButtonIcon, SimpleDropdown, BDropdownItemButton
    },
    data() {
        return {
            fields: [
                {key: "sin", label: "SIN", sortable: true, sortDirection: 'desc', sortKey: 'sin'},
                {key: "vorhabenname", sortable: true},
                "kundenname",
                "status",
                {key: "optionen", label: "Optionen", class: 'optionen-col'}
            ],
            filters: [
                {
                    field: "verkaufsstufen",
                    type: "select",
                    settings: {label: "Aktiv/Passiv", options: [{id: "0", text: "Aktiv"}, {id: "1", text: "Passiv"}]}
                },
                {
                    field: "suchen",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'sin',
            sortDesc: true,
            totalRows: 0,
            perPage: 10
        }
    },
    methods: {
        createVorhaben() {
            console.log('EXECUTE VORHABEN CREATION');
        },
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/vorhaben/list', ctx);
                this.totalRows = response.data.total;
                return response.data.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        }
    }
});
