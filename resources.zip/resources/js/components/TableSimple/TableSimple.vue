<template>
    <div class="table-with-filters">
        <div class="row no-gutters">
            <slot name="beforefilters"></slot>
            <div class="col-auto">
                <div v-if="$slots['table-controls'] || filters.length > 0" class="table-head-utils">
                    <div class="table-filters mb-2">
                        <template v-for="filter in filters">
                            <!-- If filter is just text input -->
                            <FormInput
                                class="filter-item"
                                :name="filter.field"
                                v-if="filter.type === 'text'"
                                v-model="filtersApplied[filter.field]"
                                :label-text="filter.settings.label"
                                :input-id="filter.field + '-filter'"
                                :key="filter.field"
                                v-debounce:600ms="value => handleInput(filter, value)" debounce-events="input"
                            />
                            <!-- If filter is a select input -->
                            <FormSelect
                                class="filter-item"
                                :name="filter.field"
                                v-else-if="filter.type === 'select'"
                                v-model="filtersApplied[filter.field]"
                                :label-text="filter.settings.label"
                                :select-id="filter.field + '-filter'"
                                :options="filter.settings.options"
                                :searchable="filter.settings.searchable"
                                :key="filter.field"
                                :preselected="filter.settings.preselected"
                                @input="value => handleInput(filter, value)"
                            />
                        </template>
                    </div>
                    <div class="table-controls mb-2">
                        <slot name="table-controls"></slot>
                    </div>
                </div>
            </div>
        </div>

        <div :class="containerClass">
            <div :class="{'table-wrapper': true, 'table-loading': tableBusy}">
                <b-table
                    ref="table"
                    class="table-sm mb-0"
                    :id="tableId"
                    :items="items"
                    :fields="fields"
                    :current-page="currentPage"
                    :no-local-sorting="true"
                    :busy="tableBusy"
                    :sort-by="sortBy"
                    :sort-desc="sortDesc"
                    empty-text="Keine Daten vorhanden"
                    @context-changed="handleCtxChange"
                    responsive="lg"
                    :no-sort-reset="noSortReset"
                    :striped="striped"
                    :borderless="borderless"
                    :primary-key="primaryKey"
                    :sort-icon-left="sortIconsLeft"
                    show-empty
                    label-sort-asc="Aufsteigend sortieren"
                    label-sort-clear="Sortierung aufheben"
                    label-sort-desc="Absteigend sortieren"
                >
                    <template v-for="(value, slot) in $scopedSlots" v-slot:[slot]="scope">
                        <slot :name="slot" v-bind="scope"/>
                    </template>
                </b-table>
                <div :class="{'loading-overlay': true, 'visible': tableBusy}">
                    <div class="loading-overlay__spinner">
                        <b-spinner class="align-middle"></b-spinner>
                        <span class="sr-only">wird heruntergeladen</span>
                    </div>
                </div>
            </div>

            <Pagination
                v-model="currentPage"
                v-if="totalRowsProp != -1"
                :pagination-entries-text="$t.__('tables.table_simple_entries')"
                :per-page-prop="perPageProp"
                :current-page="currentPage"
                :table-id="tableId"
                :total-rows-prop="totalRowsProp"
                :per-page-variants="perPageVariants"
                @per-page-changed="pages => $emit('per-page-changed', pages)"
            />
        </div>
    </div>
</template>

<script>
// docs:  https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/TableSimple
import {BTable, BPagination, BSpinner} from 'bootstrap-vue';
import FormInput from "../FormInput/FormInput";
import FormSelect from "../FormSelect/FormSelect";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import vueDebounce from 'vue-debounce';
import Vue from "vue";
import axios from 'axios';

const translations = require('res/lang/lang.translations.json');
Vue.prototype.$t = new SimpleTranslator(translations);
Vue.use(vueDebounce);

import Sortable from 'sortablejs';
import Pagination from "@comp/Pagination/Pagination";
const createSortable = (el, options, vnode) => {
    if (options.isDraggable) {
        return Sortable.create(el, {...options});
    }
}

export default Vue.extend({
    name: "table-simple",
    components: {
        Pagination,
        BTable, FormInput, FormSelect, BPagination, BSpinner
    },
    props: {
        tableId: {
            type: String,
            required: true
        },
        fields: {
            type: Array,
            required: false
        },
        filters: {
            type: Array,
            required: true
        },
        totalRowsProp: {
            type: Number,
            required: true,
            default: 0
        },
        perPageProp: {
            type: Number,
            required: true,
            default: 5
        },
        sortByProp: {
            type: String,
            required: false
        },
        sortDescProp: {
            type: Boolean,
            required: false,
            default: false
        },
        itemsProvider: {
            type: Function,
            required: true
        },
        noSortReset: {
            type: Boolean,
            required: false,
            default: true
        },
        striped: {
            type: Boolean,
            required: false,
            default: false
        },
        primaryKey: {
            type: String,
            required: false,
            default: ""
        },
        draggableRows: {
            type: Boolean,
            required: false,
            default: false
        },
        perPageVariants: {
            type: Array,
            required: false,
            default: () => []
        },
        fetchOnMount: {
            type: Boolean,
            default: true
        },
        borderless: {
            type: Boolean,
            default: false
        },
        readyItems: {
            type: Array,
            default: () => []
        },
        sortIconsLeft: {
            type: Boolean,
            default: true
        },
        containerClass: {
            type: [String, Array, Object],
            default: ''
        }
    },
    data() {
        return {
            items: [],
            filtersApplied: {},
            tableBusy: false,
            currentPage: 1,
            sortBy: this.sortByProp,
            sortDesc: this.sortDescProp,
            cancelToken: null,
            sortableOptions: {
                animation: 250,
                isDraggable: this.draggableRows,
                chosenClass: 'is-dragging',
                handle: '.drag-handle',
                easing: "cubic-bezier(1, 0, 0, 1)",
                onStart: this.onDragStartHandler,
                onEnd: this.onDragEndHandler,
            },
        }
    },
    watch: {
        draggableRows(newVal) {
            this.sortableOptions.isDraggable = newVal;
            const table = this.$refs.table.$el;
            if (newVal) {
                table._sortable = createSortable(
                    table.querySelector("tbody"),
                    this.sortableOptions,
                    this.$refs.table.$vnode
                );
            } else {
                table._sortable.destroy();
            }
        },
        perPageProp(newVal) {
            this.handleInput();
        },
        readyItems(newItems) {
            this.items = newItems;
        }
    },
    created() {
        this.filters.map((fltr) => {
            let preselected = fltr.settings.preselected ?? false;
            if (preselected) {
                this.filtersApplied[fltr.field] = preselected;
            }
            return fltr;
        });
    },
    async mounted() {
        if (this.fetchOnMount) {
            const ctx = this.$refs.table.context;
            await this.itemsProviderProxy(ctx);
        } else {
            this.items = this.readyItems;
        }
    },
    methods: {
        async manualCtxTrigger() {
            const ctx = this.$refs.table.context;
            await this.itemsProviderProxy(ctx);
        },
        async handleCtxChange(ctx) {
            await this.itemsProviderProxy(ctx);
        },
        async handleInput() {
            let ctx = Object.assign({}, this.$refs.table.context);
            ctx.currentPage = 1;
            this.currentPage = 1;
            await this.itemsProviderProxy(ctx);
        },
        async itemsProviderProxy(ctx) {
            let ctxCopy = Object.assign({}, ctx);
            if (!ctx.isCustomFilter) {
                ctxCopy.filter = this.filtersApplied;
            }
            let items = [];
            this.tableBusy = true;
            try {
                if (this.cancelToken) {
                    this.cancelToken.cancel();
                }
                this.cancelToken = axios.CancelToken.source();
                items = await this.itemsProvider(ctxCopy, this.cancelToken);
            } catch (err) {
                if (axios.isCancel(err)) {
                    return;
                } else {
                    console.log(err);
                }
            }

            this.tableBusy = false;
            this.items = items;
            this.$emit('new-items', items);
            this.$emit('applied-filters', this.filtersApplied);
        },
        getContext() {
            return this.$refs.table.context;
        },
        onDragEndHandler(evt) {
            let draggedItem = this.items[evt.oldIndex];
            this.items.splice(evt.oldIndex, 1);
            this.items.splice(evt.newIndex, 0, draggedItem);
            this.$emit('drag-ended', evt);
        },
        onDragStartHandler(evt) {
            this.$emit('drag-started', evt);
        },
        makeTableBusy(bool) {
            this.tableBusy = bool;
        }
    }
});
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
@import 'resources/sass/tables/new-table';

.table-with-filters {
    display: flex;
    flex-direction: column;
}

.table-filters {
    display: flex;
    align-self: flex-start;
    flex-wrap: wrap;
    flex: 1;
}

.filter-item {
    margin-bottom: 5px;

    &:not(:first-child) {
        margin-left: 3px;
    }
}

.table-head-utils {
    display: flex;
    align-items: flex-end;
}

.table-controls {
    flex: 0 1 auto;
    display: flex;
    padding-bottom: 5px;

    button {
        min-height: 44px;
    }
}

::v-deep th.b-table-sort-icon-left {
    color: #00739F;
}

::v-deep th[role="columnheader"] {
    height: 42px;
    vertical-align: middle;
    font-size: 1.25rem;
    border-top: none;

    &:focus {
        outline-color: $primary;
    }
}

::v-deep td[role="cell"] {
    vertical-align: middle;
}

::v-deep .optionen-col {
    text-align: right;
}

::v-deep ul.dropdown-menu.dropdown-menu-right.show {
    min-width: 250px;
}

.table-wrapper {
    margin-bottom: 10px;
    border-radius: 4px;
    position: relative;
    background-color: #ffffff;

    .loading-overlay {
        display: none;
        position: absolute;
        background-color: #fff;
        opacity: 0.35;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;

        .loading-overlay__spinner {
            position: absolute;
            top: 40%;
            left: 50%;
            transform: translate(-50%, 4px);

            span {
                width: 55px;
                height: 55px;
            }
        }
    }

    .loading-overlay.visible {
        display: block;
    }
}

::v-deep .b-table-empty-row {
    td {
        padding-top: 15px;
    }
}

::v-deep .table-loading .b-table-empty-row {
    div {
        visibility: hidden;
    }
}

.shadow-none .table-wrapper {
    box-shadow: none;
}
</style>
