<template>
    <div :style="computedWidth">
        <div v-if="isHidden" class="truncated">
            {{ truncatedText }}
            <button ref="btnDetails" type="button" @click="toggle">...</button>
        </div>
        <div v-else>
            {{ text }}
            <button ref="btnDetails" v-if="isHidden" type="button" @click="toggle">...</button>
        </div>
        <b-tooltip ref="tooltip" :target="() => $refs['btnDetails']" :title="title"></b-tooltip>
    </div>
</template>

<script>
import {BTooltip} from 'bootstrap-vue';

export default {
    name: "TruncatedText",
    components: {
        BTooltip
    },
    props: {
        text: {
            type: String,
            required: true
        },
        title: {
            type: String,
            required: true
        },
        width: {
            type: Number,
            required: false
        },
        maxLength: {
            type: Number,
            required: false,
            default: 40
        }
    },
    data() {
        return {
            isHidden: true,
        }
    },
    computed: {
        truncatedText() {
            return this.text.slice(0, this.maxLength)
        },
        tooltipEvent() {
            return this.isHidden === true ? 'close': 'open';
        },
        computedWidth() {
            return this.width !== null ? `width: ${this.width}px`: `width: 100%`
        }
    },
    methods: {
        toggle() {
            this.isHidden = ! this.isHidden;
            this.$refs.tooltip.$emit(this.tooltipEvent)
        }
    },
    mounted() {
        this.isHidden = this.text.length > this.maxLength
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
    .truncated {
        overflow: hidden;
        text-overflow: ellipsis;
        overflow-wrap: break-word;
    }
    button {
        padding: 0;
        font-weight: bold;
        color: $link;
        background: transparent;
        box-shadow: 0 0 0 transparent;
        border: 0 solid transparent;
        text-shadow: 0 0 0 transparent;
    }
</style>