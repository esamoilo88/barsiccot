<template>
    <div :class="{
        'form-group-floating': true,
        'focused': focusClass,
        'upper-label': content || focusClass,
        'is-invalid': errorsNumber > 0,
        'large': size === 'large'
    }">

        <label @click="$refs.input.focus()"
               class="form-label"
               :id="inputId + '__label'"
               :for="inputId">
            {{ labelText }}
        </label>
        <b-input-group>
            <input
                ref="input"
                v-model="content"
                :name="name"
                :value="value"
                @input="handleInput"
                @focus="focusClass=true"
                @blur="handleBlur"
                :autocomplete="autocomplete"
                :id="inputId"
                :type="type"
                class="form-input"
                :readonly="readonly"
            />
            <template #append>
                <b-form-timepicker
                    v-model="timepicker"
                    button-only
                    right
                    show-seconds
                    locale="de"
                    aria-controls="example-input"
                    @context="onContext"
                ></b-form-timepicker>
            </template>
        </b-input-group>

        <ul :class="{
            'd-none': !(errorsNumber > 0),
            'invalid-feedback': true,
            'd-block': errorsNumber > 0,
            'one-error': errorsNumber === 1
        }">
            <li
                :class="{'d-none': !error.condition}"
                role="alert"
                aria-live="assertive"
                aria-atomic="true"
                v-for="error in errorConditions"
                :key="error.name"
            >{{ error.text }}
            </li>
        </ul>
    </div>
</template>
<script>

import {BFormTimepicker, BInputGroupAppend, BInputGroup, VBTooltip} from 'bootstrap-vue';
import dayjs from "../../utils/day";

export default {
    name: "FormTimePicker",
    components: {
        BFormTimepicker,
        BInputGroupAppend,
        BInputGroup
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        value: {
            type: String,
            default: null
        },
        name: {
            type: String,
            required: true
        },
        iconClass: {
            type: String,
            required: false
        },
        disabled: {
            type: Boolean,
            required: false,
            default: true
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        inputId: {
            type: String,
            required: true
        },
        min:{
            type: String,
            required: false
        },
        max:{
            type: String,
            required: false
        },
        labelText: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        autocomplete: {
            type: String,
            required: false,
            default: 'off'
        },
        prefilled: {
            type: String,
            required: false
        },
        readonly: {
            type: Boolean,
            default: false
        },
        datepickerDisabled: {
            type: Boolean,
            default: false
        },
    },
    data() {
        return {
            focusClass: false,
            timepicker: null,
            content: this.value

        }
    },
    watch: {
        value() {
            this.content = this.value;
        }
    },
    computed: {
        errorsNumber() {
            let anyErrors = [];
            if (this.errorConditions !== undefined) {
                anyErrors = this.errorConditions.filter((error) => {
                    return error.condition;
                });
            }
            return anyErrors.length;
        }
    },
    methods: {
        onContext() {
            // The date formatted in the locale, or the `label-no-date-selected` string
            if (this.timepicker) {
                this.content = this.timepicker;
                this.$emit('input', this.content);
            }
            // The following will be an empty string until a valid date is entered
        },
        handleInput() {
            this.$emit('input', this.content);
            if (this.content == '') {
                this.timepicker = null;
            }
        },
        handleBlur() {
            if (this.content === null || this.content === '') {
                this.focusClass = false;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.one-error {
    padding-left: 0 !important;
    list-style: none;
}

.form-wrapper {
    max-width: 30%;
    min-width: 300px;
    padding: 50px 30px 50px 30px;
    margin: 50px auto;
    background-color: #ffffff;
    border-radius: 5px;
    box-shadow: 0 15px 35px rgba(50, 50, 93, .1), 0 5px 15px rgba(0, 0, 0, .07);
}

.form-group-floating {
    position: relative;
    padding: 2px;
    border-radius: 0.25rem;

    &.is-invalid {
        .form-input {
            border: 1px solid $error;
        }

        .invalid-feedback {
            color: $error;
            padding-left: 20px;
            padding-top: 5px;
            margin-bottom: 0;
        }
    }
}

.form-label {
    position: absolute;
    cursor: text;
    left: 15px;
    top: 15px;
    color: #888;
    z-index: 10;
    transition: transform 150ms ease-out, font-size 150ms ease-out;
}

.upper-label .form-label {
    transform: translateY(-55%);
    font-size: .75em;
}

.focused .form-input {
    &::placeholder {
        color: #888;
    }
}

.form-group-floating.large {
    .form-label {
        font-size: 26px;
    }

    .form-input {
        font-size: 26px;
    }

    &.focused .form-label {
        font-size: 1.1rem;
    }

    .invalid-feedback {
        font-size: 100%;
    }
}

.input-group {
    display: grid;
    grid-template-columns: 1fr 0fr;
}

::v-deep label.h-auto {
    height: 100% !important;
}
</style>
