<template>
    <div>
        <b-modal
            :no-close-on-backdrop="noCloseOnBackdrop"
            no-close-on-esc
            :visible="isVisible"
            ref="refModal"
            class="modal-dialog"
            :modal-class="modalClass"
            :id="modalId"
            :hide-footer="hideFooter"
            :button-class="buttonClass"
            :title="titleDialog"
            :size="size"
            :static="static"
            :scrollable="scrollable"
            @close="hideModal"
            @shown="shown"
        >
            <template #modal-header="{ close }">
                <slot name="header">
                    <h2 tabindex="0" class="modal-title">{{ titleDialog }}</h2>
                </slot>
                <button @click="close()" type="button" aria-label="Close" class="close">×</button>
            </template>

            <template #default="{ hide }">
                <slot></slot>
            </template>

            <template #modal-footer="{ ok, cancel, hide }">
                <slot name="footer" :methods="{hideModal}">
                    <div class="d-flex w-100 justify-content-center">
                        <b-button
                            :class="'btn btn-sm d-block ' + buttonClass"
                            variant="primary"
                            @click="hideModal">
                            {{ closeButton }}
                        </b-button>
                    </div>
                </slot>
            </template>
        </b-modal>
    </div>
</template>
<script>
import {BButton, BModal, BSpinner} from 'bootstrap-vue';

export default {
    name: "ModalDialog",
    components: {
        BButton, BModal, BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true
        },
        size: {
            type: String,
            required: false
        },
        titleDialog: {
            type: String,
            required: false
        },
        closeButton: {
            type: String,
            required: false,
            default: 'Abbrechen'
        },
        buttonClass:{
            type: String,
            required: false,
            default: 'btn-primary'
        },
        scrollable: {
            type: Boolean,
            required: false,
            default: false
        },
        static: {
            type: Boolean,
            required: false,
            default: false
        },
        hideFooter: {
            type: Boolean,
            required: false,
            default: false
        },
        noCloseOnBackdrop: {
            type: Boolean,
            required: false,
            default: true
        },
        modalClass: {
            type: String,
            required: true,
            default: ''
        },
        modalId: {
            type: String,
            required: false,
            default: ''
        }
    },
    data() {
        return {
            isDefaultSlotPassed: false
        }
    },
    methods: {
        hideModal() {
            this.$refs.refModal.hide();
            this.$emit('hideModal');
        },
        shown() {
            this.removeTabIndex();
            this.focusTitle();
        },
        removeTabIndex() {
            try {
                // remove tabindex, otherwise select2 search inside dialog will not work
                document.querySelector(`.${this.modalClass} .modal-content`).removeAttribute('tabindex');
            } catch (e) {}
        },
        focusTitle() {
            try {
                let modalTitle = document.querySelector(`.${this.modalClass} .modal-title`);
                modalTitle.focus();
            } catch (err) {}
        }
    }
}

</script>
<style lang="scss" scoped>
@media (min-width: 1600px) {
    ::v-deep .modal-xl {
        max-width: 1540px;
    }
}

@media (min-width: 1366px) and (max-width: 1599px) {
    ::v-deep .modal-xl {
        max-width: 1200px;
    }
}

@media (min-width: 576px) and (max-width: 991px) {
    ::v-deep .modal-xl {
        max-width: 900px;
    }
}

@media (min-width: 992px) and (max-width: 1365px) {
    ::v-deep .modal-xl {
        max-width: 1100px;
    }
}
</style>
