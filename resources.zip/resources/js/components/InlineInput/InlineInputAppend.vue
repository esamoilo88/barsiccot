<template>
    <div
        class="inline-input__container"
        :class="{'is-invalid': errorsNumber > 0}"
    >
        <b-input-group>
            <template #prepend>
                <b-input-group-text v-if="prependText !== ''">{{ prependText }}</b-input-group-text>
            </template>

            <b-form-input
                ref="input"
                :id="inputId"
                class="inline-input"
                :class="{
                    'circled-borders-left': prependText === '',
                    'circled-borders-right': (disabled || withoutButton) && appendText === '',
                    'text-right': alignright
                }"
                :readonly="readonly"
                :value="content"
                :type="type"
                :step="step"
                @input="onInput"
                @keyup.enter="onSubmit"
                :debounce="debounce"
                :disabled="disabled"
                :aria-describedby="subtext"
                @change="onChange"
            ></b-form-input>

            <template #append>
                <b-input-group-text v-if="appendText !== ''">{{ appendText }}</b-input-group-text>
                <button
                    v-if="!disabled && !withoutButton"
                    @click="onSubmit"
                    :title="submitButtonTitle"
                    :aria-label="submitButtonTitle"
                    class="btn btn-secondary submit-btn"
                    v-b-tooltip.hover
                    :disabled="readonly"
                >
                    <b-spinner v-if="loading" small></b-spinner>
                    <span v-else class="icon-action-succsess-default"></span>
                </button>
            </template>

        </b-input-group>

        <label v-if="errorsNumber > 0" :for="inputId">
            <FormInputErrors :error-conditions="errorConditions" :errors-number="errorsNumber"/>
        </label>
    </div>
</template>

<script>
import {BInputGroup, BInputGroupText, BFormInput, VBTooltip, BSpinner} from 'bootstrap-vue';
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";

export default {
    name: "InlineInputAppend",
    components: {
        BInputGroup, BInputGroupText, BFormInput, FormInputErrors, BSpinner
    },
    mixins: [ErrorsMxn],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        value: null,
        appendText: {
            type: String,
            required: false,
            default: ''
        },
        prependText: {
            type: String,
            required: false,
            default: ''
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        maxLength: {
            type: String,
            required: false
        },
        inputId: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => ([])
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        submitButtonTitle: {
            type: String,
            required: false,
            default: ""
        },
        hintPosition: {
            type: String,
            required: false,
            default: 'righttop'
        },
        step: {
            type: Number,
            default: 1
        },
        withoutButton: {
            type: Boolean,
            required: false,
            default: false
        },
        formatter: {
            type: Function,
            required: false,
            default: null
        },
        debounce: {
            type: String,
            required: false
        },
        subtext: {
            type: String,
            required: false
        },
        alignright: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {
            content: this.value,
            initialValue: this.value,
            loading: false,
            readonly: this.disabled
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.content = newVal;
        }
    },
    computed: {
        errorsNumber() {
            let anyErrors = [];
            if (this.errorConditions !== undefined) {
                anyErrors = this.errorConditions.filter((error) => {
                    return error.condition;
                });
            }
            return anyErrors.length;
        }
    },
    created() {
        if (this.formatter !== null) {
            this.content = this.formatter(this.value);
        }
    },
    methods: {
        onInput(value) {
            this.isDirty = true;
            this.content = value;
            this.$emit('input', this.content);
        },
        onSubmit() {
            if (!this.errorsNumber > 0 && (this.initialValue != this.content)) {
                this.initialValue = this.content;
                this.$emit('submit', this.content);
            }
        },
        setSpinner(isLoading) {
            this.loading = isLoading;
        },
        onChange() {
            if (this.withoutButton && !this.errorsNumber > 0 && (this.initialValue != this.content)) {
                this.initialValue = this.content;
                this.$emit('submit', this.content);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.inline-input.form-control {
    font-size: 100%;
    font-weight: bold;
    padding: 5px 5px;
    height: auto;

    &.circled-borders-left {
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
    }

    &.circled-borders-right {
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
    }
}

.inline-input .form-control:read-only {
    background-color: transparent;
    pointer-events: none;
}

.is-invalid {
    ::v-deep .select2-selection.select2-selection--single {
        border: 1px solid $error;
    }

    .invalid-feedback {
        font-size: 85%;
        color: $error;
        padding-left: 20px;
        padding-top: 5px;
        margin-bottom: 0;
    }
}

.inline-input .form-control:read-only::-webkit-outer-spin-button,
.inline-input .form-control:read-only::-webkit-inner-spin-button {
    -webkit-appearance: none;
}

.inline-input__container {
    .input-group-text {
        background-color: #ededed;
    }

    .submit-btn {
        border: 1px solid #ced4da;
    }
}
</style>
