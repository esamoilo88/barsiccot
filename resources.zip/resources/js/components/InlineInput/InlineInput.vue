<template>
    <div :class="{'inline-input__container': true, 'is-invalid': errorsNumber > 0}">
        <div class="inline-input">
            <div class="input-wrapper">
                <input
                    ref="input"
                    :id="inputId"
                    class="form-control"
                    :readonly="isReadonly"
                    :value="content"
                    :type="type"
                    :step="step"
                    @input="onInput"
                    @keyup.enter="onSubmit"
                >
            </div>
            <div v-if="!disabled" class="button-wrapper ml-1">
                <ButtonIcon
                    v-if="isReadonly"
                    icon-class="icon-action-edit-default"
                    :title="editButtonTitle"
                    @click="onEdit"
                    :hint-position="hintPosition"
                />
                <ButtonIcon
                    v-else
                    icon-class="icon-action-succsess-default"
                    :title="submitButtonTitle"
                    @click="onSubmit"
                    :hint-position="hintPosition"
                />
            </div>
        </div>

        <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";

export default {
    name: "InlineInput",
    components: {
        ButtonIcon, FormInputErrors
    },
    mixins: [ErrorsMxn],
    props: {
        value: null,
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        maxLength: {
            type: String,
            required: false
        },
        inputId: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => ([])
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        editButtonTitle: {
            type: String,
            required: true
        },
        submitButtonTitle: {
            type: String,
            required: true
        },
        hintPosition: {
            type: String,
            required: false,
            default: 'righttop'
        },
        step: {
            type: Number,
            default: 1
        },
        checkErrors: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {
            content: this.value,
            isReadonly: true
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.content = newVal;
        }
    },
    methods: {
        onInput($event) {
            this.content = $event.target.value;
            this.$emit('input', this.content);
        },
        onSubmit() {
            if (this.checkErrors && this.errorsNumber) return;

            this.$emit('submit', this.content);
            this.isReadonly = true;
        },
        onEdit() {
            if (!this.disabled) {
                this.isReadonly = false;
                this.$refs.input.focus();
            }
            this.$emit('edit');
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.one-error {
    padding-left: 0 !important;
    list-style: none;
}

.inline-input {
    display: flex;
    align-items: center;
}

.inline-input .form-control {
    text-align: right;
    font-size: 100%;
    font-weight: bold;
    padding: 5px 5px;
    height: auto;
}

.inline-input .form-control:read-only {
    background-color: transparent;
    pointer-events: none;
}

.is-invalid {
    .invalid-feedback {
        font-size: 85%;
        color: $error;
        padding-left: 20px;
        padding-top: 5px;
        margin-bottom: 0;
    }
}

.inline-input .form-control:read-only::-webkit-outer-spin-button,
.inline-input .form-control:read-only::-webkit-inner-spin-button {
    -webkit-appearance: none;
}
</style>
