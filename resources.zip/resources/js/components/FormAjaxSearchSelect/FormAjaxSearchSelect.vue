<template>
    <div :class="{'options-visible': optionsVisible}">
        <div class="form-group-floating" :class="labelStyle">
            <label class="form-label" :id="inputId + '__label'" :for="inputId" @click="focus">
                {{ placeholder }}
            </label>
            <input
                v-model="localValue"
                ref="input"
                class="form-input"
                :placeholder="placeholder"
                :name="name"
                :id="inputId"
                @focus="focus"
                @blur="blur"
                @input="input"
                autocomplete="off"
            />

            <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>

            <div v-if="pending" class="pending">
                <div class="spinner-border text-primary spinner-border-sm" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>

        <div class="options-box">
            <ul>
                <li v-for="option in options" @click="select(option)">{{ option[label] }}</li>
            </ul>
        </div>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";

export default {
    components: {FormInputErrors},
    mixins: [ErrorsMxn],
    props: {
        name: {
            type: String,
            required: true
        },
        value: null,
        placeholder: {
            type: String,
            required: false
        },
        options: {
            type: Array,
            required: false,
            default: () => []
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        },
        pending: {
            type: Boolean,
            required: false,
            default: false
        },
        label: {
            type: String,
            required: false,
            default: 'text'
        }
    },
    data() {
        return {
            localValue: this.value,
            inputId: `${this.name}-input-id`,
            focusClass: false,
            showOptions: false
        }
    },
    computed: {
        labelStyle() {
            return {
                'focused': this.focusClass,
                'upper-label': this.focusClass || this.value || this.value === 0,
                'is-invalid': this.errorsNumber,
            }
        },
        optionsVisible() {
            return this.options.length && this.showOptions;
        }
    },
    methods: {
        input() {
            this.$emit('input', this.localValue);
        },
        select(option) {
            this.$emit('select', option);

            this.showOptions = false;
        },
        focus() {
            this.showOptions = true;
            this.focusClass = true;

            this.$refs.input.focus();
        },
        blur() {
            this.focusClass = false;
        },
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/components/formInput';

.options-box {
    display: none;
    padding-left: 2px;
    padding-right: 2px;
    position: absolute;
    width: 100%;
    z-index: 9999;

    ul {
        list-style-type: none;
        border: 1px solid lightgrey;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        border-top: none;
        max-height: 200px;
        overflow-y: auto;
        background-color: white;
        padding: 0;

        li {
            padding: 6px;
            cursor: pointer;

            &:hover {
                background-color: #5897fb;
                color: white;
            }
        }
    }
}

.options-visible {
    .form-input {
        box-shadow: 0 2px 0 0 #e20074;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
    }

    .options-box {
        display: block;
    }
}

.pending {
    position: absolute;
    top: 12px;
    right: 12px;
}
</style>
