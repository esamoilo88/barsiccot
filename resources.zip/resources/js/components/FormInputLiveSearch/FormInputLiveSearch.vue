<template>
    <div class="d-flex">
        <div class="position-relative">
            <div
                role="combobox"
                :aria-expanded="(pendingSuggestions || (suggestionsExpanded && suggestions.length > 0)) ? 'true' : 'false'"
                :aria-owns="`suggestions-list-${inputId}`"
                aria-haspopup="listbox"
            >
                <b-form-input
                    ref="input"
                    id="new-tag-input"
                    class="form-control"
                    :placeholder="placeholder"
                    :maxlength="maxLength"
                    :value="value"
                    :name="name"
                    @input="onInput"
                    @change="onChange"
                    @keyup.enter="onSubmit"
                    @keydown.up="event => navigateSuggestion('up', event)"
                    @keydown.down="event => navigateSuggestion('down', event)"
                    @focus.native="onFocus"
                    @blur="onBlur"
                    :id="inputId"
                    :type="type"
                    :autocomplete="autocomplete"
                    :readonly="disabled"
                    :debounce="600"
                    :aria-controls="`suggestions-list-${inputId}`"
                    :aria-activedescendant="activeSuggestion !== null ? `suggestion-${inputId}-${activeSuggestion}` : false"
                />
            </div>

            <div v-if="(suggestionsExpanded && value && suggestions.length > 0) || (pendingSuggestions && value)" class="live-search-suggestions">
                <div v-if="pendingSuggestions" class="text-center"><b-spinner class="mx-auto" small></b-spinner></div>

                <ul
                    ref="suggestionsList"
                    :id="`suggestions-list-${inputId}`"
                    v-else-if="suggestions.length > 0"
                    class="suggestions-list p-0 m-0"
                    role="listbox"
                >
                    <li
                        v-for="s in suggestions"
                        :key="`suggestion-${inputId}-${s[suggestionIdColumn]}`"
                        :id="`suggestion-${inputId}-${s[suggestionIdColumn]}`"
                        @mouseover="activeSuggestion = s[suggestionIdColumn]"
                        @keydown.enter="selectSuggestion(s)"
                        @click="selectSuggestion(s)"
                        :class="{'p-2': true, 'suggestion': true, 'active': activeSuggestion == s[suggestionIdColumn]}"
                        role="option"
                        :aria-selected="activeSuggestion == s[suggestionIdColumn] ? 'true' : 'false'"
                    >
                        {{ s[suggestionTextColumn] }}
                    </li>
                </ul>
            </div>
        </div>

        <div class="d-flex">
            <template v-for="i of 3">
                <slot :name="'button-' + i"></slot>
            </template>
        </div>
    </div>
</template>

<script>
import {BFormInput, BSpinner} from 'bootstrap-vue';
import axios from 'axios';
import {isElementVisible} from "@helpers/DOM/DOMHelper";

let timeoutToken;
let cancelToken;

export default {
    name: "FormInputLiveSearch",
    components: {
        BFormInput, BSpinner
    },
    props: {
        value: null,
        name: {
            type: String,
            required: true
        },
        itemsProvider: {
            type: Function,
            required: true,
            default: () => []
        },
        suggestionIdColumn: {
            type: String,
            required: false,
            default: 'id'
        },
        suggestionTextColumn: {
            type: String,
            required: false,
            default: 'bezeichnung'
        },
        minLengthToSuggest: {
            type: Number,
            required: false,
            default: 2
        },
        inputId: {
            type: String,
            required: true
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        maxLength: {
            type: String,
            required: false
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        autocomplete: {
            type: String,
            required: false,
            default: 'off'
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        useFormatter: {
            tyoe: Boolean,
            default: false
        },
        formatter: {
            type: Function,
            required: false,
            default: v => v
        },
        placeholder: {
            type: String,
            required: false,
            default: ""
        },
        debounce: {
            type: Number,
            required: false,
            default: 600
        }
    },
    data() {
        return {
            suggestions: [],
            focused: false,
            suggestionsExpanded: false,
            activeSuggestion: null,
            pendingSuggestions: false
        }
    },
    methods: {
        onInput(value) {
            if (value !== '' && value !== null) {
                this.suggestionsExpanded = true;
                this.suggestionsPending = true;
            } else {
                this.suggestions.splice(0);
            }

            this.$emit('input', this.formatter(value));
            timeoutToken && clearTimeout(timeoutToken);

            if (value && value.length >= this.minLengthToSuggest) {
                timeoutToken = setTimeout(() => this.itemsProviderWrapper(), this.debounce);
            }
        },
        onChange(value) {
            this.$emit('change', this.formatter(value));
        },
        onSubmit(value) {
            if (this.activeSuggestion !== null) {
                this.selectSuggestion(this.suggestions[this.getSuggestionIndexById(this.activeSuggestion)]);
            } else {
                this.$emit('submit', this.formatter(value));
                this.suggestions.splice(0);
            }
        },
        onFocus() {
            this.focused = true;
            this.suggestionsExpanded = true;
            this.activeSuggestion = null;
        },
        onBlur() {
            this.focused = false;
            setTimeout(() => {
                this.suggestionsExpanded = false;
                this.activeSuggestion = null;
            }, 200);
        },
        navigateSuggestion(direction, event) {
            event.preventDefault();
            let currentActiveSuggestionIndex = this.getSuggestionIndexById(this.activeSuggestion);

            if (this.suggestions.length == 0) {
                this.activeSuggestion = null;
            } else if (this.activeSuggestion === null) {
                this.activeSuggestion = this.suggestions[0][this.suggestionIdColumn];
            } else if (direction === 'up') {
                if (currentActiveSuggestionIndex !== 0) {
                    this.activeSuggestion = this.suggestions[--currentActiveSuggestionIndex][this.suggestionIdColumn];
                } else {
                    this.activeSuggestion = null;
                }
            } else if (direction === 'down') {
                if (currentActiveSuggestionIndex !== this.suggestions.length - 1) {
                    this.activeSuggestion = this.suggestions[++currentActiveSuggestionIndex][this.suggestionIdColumn];
                }
            }
            this.$forceUpdate();
            this.$nextTick(this.scrollToActive);
        },
        getSuggestionIndexById(id) {
            let index = null;
            this.suggestions.map((s, i) => {
                if (id === s[this.suggestionIdColumn]) {
                    index = i;
                }
            });
            return index;
        },
        selectSuggestion(suggestion) {
            this.$emit('input', this.formatter(suggestion[this.suggestionTextColumn]));
            this.activeSuggestion = null;
            this.suggestionsExpanded = false;
            this.suggestions.splice(0);
            this.focus();
        },
        async itemsProviderWrapper() {
            this.suggestions.splice(0);

            if (this.value === '' || this.value === null) {
                return;
            }

            this.pendingSuggestions = true;
            try {
                if (cancelToken) {
                    cancelToken.cancel();
                }
                cancelToken = axios.CancelToken.source();
                let suggestions = await this.itemsProvider(cancelToken);
                this.suggestions.push(...suggestions);
            } catch (err) {
                if (axios.isCancel(err)) {
                    return;
                } else {
                    console.error("Cannot get live search results! Err: ", err);
                }
            }
            this.pendingSuggestions = false;
        },
        focus() {
            this.$refs.input.focus();
        },
        scrollToActive() {
            let active = document.querySelector(`#suggestions-list-${this.inputId} li.active`);
            let wrapper = document.querySelector('.live-search-suggestions');
            if (active && wrapper && !isElementVisible(active, wrapper)) {
                active.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start'});
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.live-search-suggestions {
    background-color: #ffffff;
    border-left: 1px solid lightgrey;
    border-right: 1px solid lightgrey;
    border-bottom: 1px solid lightgrey;
    border-bottom-left-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
    position: absolute;
    top: 30px;
    left: 0;
    right: 0;
    max-height: 150px;
    overflow-y: auto;
}

.suggestion {
    word-break: break-word;
    cursor: pointer;
}

.suggestions-list {
    list-style: none;
}

.suggestion.active {
    color: #fff;
    background: #5897fb;
}
</style>
