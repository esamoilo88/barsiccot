<template>
    <div class="text-center">
        <span class="sr-only">Wird geladen</span>
        <b-spinner></b-spinner>
    </div>
</template>

<script>
import {BSpinner} from 'bootstrap-vue';
export default {
    name: "Loading",
    components: {BSpinner}
}
</script>
