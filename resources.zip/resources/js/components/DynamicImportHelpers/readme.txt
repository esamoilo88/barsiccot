Use these components when you use dynamic imports.
For example:

import Loading from '@comp/DynamicImportHelpers/Loading';
import Error from '@comp/DynamicImportHelpers/Error';

const AsyncComponent = () => ({

  // The component to load (should be a Promise)
  component: import('./MyComponent.vue'),

  // A component to use while the async component is loading
  loading: Loading,

  // A component to use if the load fails
  error: Error,

  // Delay before showing the loading component. Default: 200ms.
  delay: 200,

  // The error component will be displayed if a timeout is
  // provided and exceeded. Default: Infinity.
  timeout: 3000
})


https://vuejs.org/v2/guide/components-dynamic-async.html#Handling-Loading-State
