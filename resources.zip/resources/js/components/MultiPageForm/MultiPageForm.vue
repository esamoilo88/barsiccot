<template>
    <div class="mpf-wrapper">
        <div class="mpf-progress" role="list" ref="mpfProgress">
            <span class="sr-only">Prozessforschritt</span>
            <template v-for="step in steps">
                <div
                    v-if="step.number !== 1"
                    :style="[noanimation ? {'animation-duration': '0s'} : {}]"
                    :class="{'mpf-progress-divider': true, 'touched': isStepTouched(step.number), 'passed': step.number <= activeStep}"
                ></div>
                <div
                    role="listitem"
                    :tabindex="activeStep === step.number ? 0 : -1"
                    :data-step="step.number"
                    :class="{
                        'mpf-progress-step': true,
                        'touched': isStepTouched(step.number),
                        'active': step.number === activeStep,
                        'passed': step.number < activeStep,
                        'invalid': isStepInvalid(step.number),
                        'valid': isStepValid(step.number)
                    }"
                    @click="navigateToStep(step.number)"
                    @keydown.tab.exact="focusFirstInput"
                    @keydown.down="focusFirstInput"
                    @keydown.left="navigateToStep(step.number - 1)"
                    @keydown.right="navigateToStep(step.number + 1)"
                >
                    <span v-if="step.icon" :class="'mpf-progress-step__content ' + step.icon"></span>
                    <span v-else class="mpf-progress-step__content">{{ step.number }}</span>
                    <span v-if="activeStep === step.number" class="sr-only">{{ activeStepSrText }}</span>
                    <span v-if="activeStep === step.number && step.srDescription !== undefined" class="sr-only">{{ step.srDescription }}</span>
                    <div v-if="activeStep === step.number && $scopedSlots['desc'+step.number]" class="mpf-progress-step__arrow"></div>
                </div>
            </template>
        </div>

        <template v-for="step in steps">
            <div v-if="$scopedSlots['desc'+step.number] && activeStep === step.number" class="mpf-description">
                <slot :name="'desc'+step.number"/>
            </div>
        </template>

        <div class="mpf-form" ref="mpfForm">
            <template v-for="step in steps">
                <template v-if="!step.lazy">
                    <div v-show="activeStep === step.number" :class="`step-${step.number}-form-wrapper`" :aria-hidden="activeStep !== step.number">
                        <slot
                            :name="step.number"
                            v-bind="{activeStep}"
                        />
                    </div>
                </template>
                <template v-else>
                    <div v-if="activeStep === step.number" :class="`step-${step.number}-form-wrapper`" :aria-hidden="activeStep !== step.number">
                        <slot
                            :name="step.number"
                            v-bind="{activeStep}"
                        />
                    </div>
                </template>
            </template>
        </div>

        <div class="mpf-footer">
            <div class="mpf-footer__buttons-holder">
                <button v-if="activeStep !== 1" @click="previousStep" :id="previousStepButtonId" class="btn btn-secondary mr-2">
                    {{ previousStepButtonText }}
                </button>
                <button v-if="activeStep !== steps.length" @click="nextStep" :id="nextStepButtonId" class="btn btn-primary">
                    {{ nextStepButtonText }}
                </button>
                <button v-if="activeStep === steps.length" @click="submit" :id="submitButtonId" class="btn btn-primary">
                    {{ submitButtonText }}
                </button>
            </div>
        </div>
    </div>
</template>

<script>

import {focusOnFirstFocusable} from "@helpers/Form/InputsHelper";

export default { //https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/MultiPageForm
    name: "multi-page-form",
    components: {},
    props: {
        steps: {
            type: Array,
            required: true,
        },
        activeStepProp: {
            type: Number,
            required: false,
            default: 1
        },
        onSubmit: {
            type: Function,
            required: false,
            default: null
        },
        nextStepButtonText: {
            type: String,
            required: false,
            default: 'Weiter'
        },
        previousStepButtonText: {
            type: String,
            required: false,
            default: 'Zurück'
        },
        submitButtonText: {
            type: String,
            required: false,
            default: 'Fertigstellen'
        },
        activeStepSrText: {
            type: String,
            required: false,
            default: 'Derzeit aktiv'
        },
        nextStepButtonId: {
            type: String,
            required: false,
            default: 'next-step-btn'
        },
        previousStepButtonId: {
            type: String,
            required: false,
            default: 'previous-step-btn'
        },
        submitButtonId: {
            type: String,
            required: false,
            default: 'submit-mpf-btn'
        },
    },
    data() {
        return {
            activeStep: this.activeStepProp,
            touched: [],
            invalid: [],
            valid: [],
            noanimation: false,
        }
    },
    mounted() {
        this.init();
    },
    methods: {
        init() {
            for (let step = 1; step <= this.activeStepProp; step++) {
                this.touched.push(step);
            }
            setTimeout(() => this.$refs['mpfProgress'].querySelector('.mpf-progress-step').focus(), 100);
        },
        reset() {
            this.touched.splice(0);
            this.invalid.splice(0);
            this.valid.splice(0);
            this.activeStep = this.activeStepProp;
            this.noanimation = false;
            this.init();
        },
        focusOnActiveStep(evt = null) {
            let active = document.querySelector(`[data-step="${this.activeStep}"]`);
            if (evt === null || active.dataset.step != evt.currentTarget.dataset.step) {
                active.focus();
            }
        },
        isStepTouched(step) {
            return this.touched.includes(step);
        },
        isStepInvalid(step) {
            return this.invalid.includes(step);
        },
        isStepValid(step) {
            return this.valid.includes(step);
        },
        submit() {
            if (this.invalid.length > 0) {
                window.flash.show({text: 'Please resolve all the active issues!', type: 'error'});
                return false;
            }
            if (this.onSubmit !== null) {
                this.onSubmit();
            }
        },
        nextStep() {
            if (this.activeStep === this.steps.length) {
                return false;
            }
            this.noanimation = false;
            if (this.isValid(this.activeStep)) {
                ++this.activeStep;
                if (!this.touched.includes(this.activeStep)) {
                    this.touched.push(this.activeStep);
                }
                this.focusOnActiveStep();
            }
        },
        previousStep() {
            if (this.activeStep === 1) {
                return false;
            }
            this.noanimation = false;
            --this.activeStep;
            this.focusOnActiveStep();
            if (!this.touched.includes(this.activeStep)) {
                this.touched.push(this.activeStep);
            }
        },
        navigateToStep(step) {
            if ((!this.isStepTouched(step) && (step - this.activeStep) > 1) || (step < 1 || step > this.steps.length)) {
                return false;
            }

            let currStepInvalid = !this.isValid(this.activeStep);

            if ((step - this.activeStep) > 0) {
                if (currStepInvalid) return false;

                let isFurtherInvalid = this.getFurtherInvalid(step);
                step = isFurtherInvalid !== -1 ? isFurtherInvalid : step;
            }

            this.noanimation = Math.abs(step - this.activeStep) > 1;
            this.activeStep = step;
            if (!this.touched.includes(this.activeStep)) {
                this.touched.push(this.activeStep);
            }
            this.focusOnActiveStep();
        },
        getFurtherInvalid(step) {
            let invalidStep = -1;
            for (let i = this.activeStep; i < step; i++) {
                invalidStep = !this.isValid(i) ? i : invalidStep;
            }
            return invalidStep;
        },
        // used by custom validation functions passed through on-switch prop
        isValid(step) {
            let onSwitch = this.$slots[step][0]?.componentOptions?.propsData?.onSwitch;
            let isValid = onSwitch === undefined ? true : onSwitch();
            if (!isValid) {
                (!this.invalid.includes(step)) ? this.invalid.push(step) : '';
                this.valid = this.valid.includes(step) ? this.valid.filter(s => s !== step) : this.valid;
            } else {
                this.invalid = this.invalid.includes(step) ? this.invalid.filter(s => s !== step) : this.invalid;
                (!this.valid.includes(step)) ? this.valid.push(step) : '';
            }

            return isValid;
        },
        focusFirstInput() {
            let activeForm = document.querySelector(`.step-${this.activeStep}-form-wrapper`);
            setTimeout(() => focusOnFirstFocusable(activeForm), 10);
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.mpf-description {
    border: 1px solid lightgrey;
    border-radius: 5px;
    margin-top: -13px;
    margin-bottom: 30px;
    padding: 30px;
    box-shadow: $shadow;
    background-color: #ffffff;
}

.mpf-progress {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
}

.mpf-progress-step {
    border-radius: 50%;
    position: relative;
    padding: 20px;
    margin: 5px 10px;
    background-color: lightgrey;
    cursor: pointer;

    .mpf-progress-step__content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    svg.mpf-progress-step__content {
        max-height: 25px;
        max-width: 25px;
        fill: $iconscolor;
    }

    //&.touched {
    //    background-color: #f9a1ce;
    //    color: #fff;
    //
    //    svg {
    //        fill: #fff;
    //    }
    //}

    &.touched.valid:not(.passed) {
        background-color: $success;
        color: #fff;

        svg {
            fill: #fff;
        }
    }

    &.passed {
        background-color: $success;
        color: #fff;

        svg {
            fill: #fff;
        }
    }

    &.active {
        background-color: $primary;
        color: #fff;

        svg {
            fill: #fff;
        }
    }

    &.touched.valid.active {
        background-color: $success;
        color: #fff;

        svg {
            fill: #fff;
        }
    }

    &.invalid {
        color: #fff;
        background-color: $error;

        svg {
            fill: #fff;
        }
    }
}

.mpf-progress-divider {
    height: 2px;
    width: 100%;
    background: lightgrey;

    &.touched {
        background: linear-gradient(to left, lightgrey 50%, $primary 0) left;
        background-size: 200% 100%;
        animation: emptyProgress 0.25s forwards;
    }

    &.passed {
        background: linear-gradient(to right, $primary 50%, lightgrey 0) right;
        background-size: 200% 100%;
        animation: fillProgress 0.25s forwards;
    }
}

@keyframes fillProgress {
    100% {
        background-position: left;
    }
}

@keyframes emptyProgress {
    100% {
        background-position: right;
    }
}


.mpf-form {
    padding: 10px;
}

.mpf-footer {
    padding-top: 30px;
}

.mpf-footer__buttons-holder {
    display: flex;
    justify-content: center;

    button {
        width: 140px;
    }
}

.mpf-progress-step__arrow {
    background: #fff;
    width: 25px;
    height: 25px;
    position: absolute;
    border: 1px solid lightgrey;
    border-right: none;
    border-bottom: none;
    pointer-events: none;
    bottom: -35px;
    left: 50%;
    transform: translateX(-50%) rotate(45deg);
    z-index: 9;
}

.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}
</style>
