<template>
    <div>
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: "step",
    props: {
        number: {
            type: Number,
            required: true
        },
        onSwitch: {
            type: Function,
            required: false,
            default: () => true
        }
    }
}
</script>
