@extends('layout.layout')

@section('title', 'Test page')
@section('content')
    <div id="mpf">
        <multi-page-form
            :steps="[
                {number: 1, srDescription: 'Type here name and lastname'},
                {number: 2, icon: '/img/icons/calculator.svg#calculator-icon', srDescription: 'Type age here'},
                {number: 3, srDescription: 'type department here'},
                {number: 4, srDescription: 'type tag here'}
            ]"
            :on-submit="onSubmit"
        >
            <template #desc1>
                <span>Hello! Type in your name and surname here. These fields are required, so if you leave them empty you cannot proceed</span>
            </template>
            <template #1>
                <step :number="1" key="step1" :on-switch="validateFirstStep">
                    <form-input
                        v-model="step1.name"
                        name="name"
                        input-id="name-input"
                        class="w-25"
                        label-text="Name:*"
                        :error-conditions="[
                            {
                                name: 'empty-name',
                                condition: !$v.step1.name.required && $v.step1.name.$dirty,
                                text: 'Please enter the name!'
                            }
                        ]"
                    ></form-input>
                    <form-input
                        v-model="step1.lastname"
                        name="lastname"
                        input-id="lastname-input"
                        class="w-25"
                        label-text="Lastname:*"
                        :error-conditions="[
                            {
                                name: 'empty-lastname',
                                condition: !$v.step1.lastname.required && $v.step1.lastname.$dirty,
                                text: 'Please enter the lastname'
                            }
                        ]"
                    ></form-input>
                </step>
            </template>

            <template #desc2>
                <span>There you can type in your age</span>
            </template>
            <template #2>
                <step :number="2" key="step2" :on-switch="validateSecondStep">
                    <form-input
                        v-model="step2.age"
                        name="age"
                        input-id="age-input"
                        class="w-25"
                        label-text="Age:*"
                        :error-conditions="[
                            {
                                name: 'empty-age',
                                condition: !$v.step2.age.required && $v.step2.age.$dirty,
                                text: 'Please enter your age'
                            }
                        ]"
                    ></form-input>
                </step>
            </template>

            <template #desc3>
                <span>Type in the department you are working at</span>
            </template>
            <template #3>
                <step :number="3" key="step3" :on-switch="validateThirdStep">
                    <form-input
                        v-model="step3.department"
                        name="department"
                        input-id="dep-input"
                        class="w-25"
                        label-text="Department:*"
                        :error-conditions="[
                            {
                                name: 'empty-dep',
                                condition: !$v.step3.department.required && $v.step3.department.$dirty,
                                text: 'Please enter your department'
                            }
                        ]"
                    ></form-input>
                </step>
            </template>

            <template #desc4>
                <span>Type in tag (I don't know what that is, just another one input)</span>
            </template>
            <template #4>
                <step :number="4" key="step4" :on-switch="validateFourthStep">
                    <form-input
                        v-model="step4.tag"
                        name="tag"
                        input-id="tag-input"
                        class="w-25"
                        label-text="Tag:*"
                        :error-conditions="[
                            {
                                name: 'empty-tag',
                                condition: !$v.step4.tag.required && $v.step4.tag.$dirty,
                                text: 'Please enter some tag'
                            }
                        ]"
                    ></form-input>
                </step>
            </template>

        </multi-page-form>
    </div>
@endsection
@section('scripts')
    <script src="{{ mix('js/components/MultiPageForm/main.js') }}"></script>
@endsection
