import Vue from 'vue';
import { required } from 'vuelidate/lib/validators';
import Vuelidate from "vuelidate";
import MultiPageForm from "../MultiPageForm";
import Step from "../Step";
import FormInput from "@comp/FormInput/FormInput";

Vue.use(Vuelidate);

export default new Vue({
    el: '#mpf',
    components: {
        MultiPageForm, Step, FormInput
    },
    data() {
        return {
            step1: {
                name: '',
                lastname: ''
            },
            step2: {
                age: null
            },
            step3: {
                department: ''
            },
            step4: {
                tag: ''
            }
        }
    },
    methods: {
        validateFirstStep() {
            this.$v.step1.$touch();
            return !this.$v.step1.$anyError;
        },
        validateSecondStep() {
            this.$v.step2.$touch();
            return !this.$v.step2.$anyError;
        },
        validateThirdStep() {
            this.$v.step3.$touch();
            return !this.$v.step3.$anyError;
        },
        validateFourthStep() {
            this.$v.step4.$touch();
            return !this.$v.step4.$anyError;
        },
        onSubmit() {
            alert(JSON.stringify({...this.step1, ...this.step2,...this.step3,...this.step4}));
        }
    },
    validations: {
        step1: {
            name: {required},
            lastname: {required}
        },
        step2: {
            age: {required}
        },
        step3: {
            department: {required}
        },
        step4: {
            tag: {required}
        },
    }
});
