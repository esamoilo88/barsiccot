<template>
    <div class="observer"/>
</template>

<script>
export default {
    props: {
        isLoading: {
            type: Boolean,
            default: false
        },
        options: {}
    },
    data: () => ({
        observer: null,
    }),
    mounted() {
        const options = this.options || {};

        this.observer = new IntersectionObserver(([entry]) => {
            if (entry && entry.isIntersecting && !this.isLoading) {
                this.$emit("intersect");
            }
        }, options);

        this.observer.observe(this.$el);
    },
    destroyed() {
        this.observer.disconnect();
    }
};
</script>
