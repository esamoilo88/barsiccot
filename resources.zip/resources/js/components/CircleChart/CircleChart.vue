<template>
    <div :class="'circle-chart ' + size">
        <span class="sr-only">{{ srText }}</span>
        <div class="circle-chart__content">
            <span :class="iconClass">{{ iconClass ? '' : text }}</span>
        </div>
        <svg viewBox="0 0 200 200">
            <circle
                class="circle-chart__circle"
                ref="circle"
                cx="100"
                cy="100"
                :r="radius"
                fill="transparent"
                stroke="#e9e9e9"
                :stroke-width="strokeWidth"
            ></circle>
            <circle
                class="circle-chart__circle"
                cx="100"
                cy="100"
                :r="radius"
                fill="transparent"
                :stroke="color"
                :stroke-width="strokeWidth"
                :stroke-dasharray="strokeDasharray"
                :stroke-dashoffset="strokeDashoffset"
            ></circle>
        </svg>
    </div>
</template>

<script>
export default {
    name: "circle-chart",
    props: {
        content: {
            type: String,
            required: false
        },
        value: {
            type: Number,
            required: false,
            default: 0
        },
        color: {
            type: String,
            required: false,
            default: '#E20074'
        },
        size: {
            type: String,
            required: false,
            default: ''
        },
        strokeWidth: {
            type: Number,
            required: false,
            default: 20
        },
        srText: {
            type: String,
            required: false,
            default: ''
        },
        step: {
            type: Number,
            required: false,
            default: 5
        },
        iconClass: {
            type: String,
            default: null
        }
    },
    data() {
        return {
            radius: 80,
            percentageValue: this.value
        }
    },
    computed: {
        strokeDasharray() {
            return this.radius * 2 * Math.PI;
        },
        strokeDashoffset() {
            if (this.step !== 1) {
                let remainder = this.value % this.step;
                let percentage = remainder !== 0 ? Math.floor(this.value - remainder) : this.value;
                return this.strokeDasharray - percentage / 100 * this.strokeDasharray;
            } else {
                return (this.strokeDasharray >= this.value) ? this.strokeDasharray - this.value / 100 * this.strokeDasharray : 0;
            }
        },
        percentage() {
            if (this.step !== 1) {
                let remainder = this.value % this.step;
                return remainder !== 0 ? Math.floor(this.value - remainder) : this.value;
            } else {
                return this.value;
            }
        },
        text() {
            return this.content === undefined || this.content === null ? this.percentage + '%' : this.content;
        }
    },
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables.scss';

.circle-chart {
    position: relative;
    width: 100px;
    height: 100px;

    &.xxsmall {
        width: 33px;
        height: 33px;

        .circle-chart__content {
            span {
                font-size: 0.5rem;
            }
        }
    }

    &.xmsmall {
        width: 40px;
        height: 40px;

        .circle-chart__content {
            span {
                font-size: 0.8rem;
            }
        }
    }

    &.xsmall {
        width: 55px;
        height: 55px;

        .circle-chart__content {
            span {
                font-size: 0.9rem;
            }
        }
    }

    &.small {
        width: 70px;
        height: 70px;

        .circle-chart__content {
            span {
                font-size: 1.25rem;
                line-height: 20px;
            }
        }
    }

    &.large {
        width: 130px;
        height: 130px;

        .circle-chart__content {
            span {
                font-size: 2.35rem;
            }
        }
    }
}

.circle-chart__circle {
    transition: 0.35s stroke-dashoffset;
    -moz-transform: rotate(-90deg);
    -ms-transform: rotate(-90deg);
    -webkit-transform: rotate(-90deg);
    transform: rotate(-90deg);
    transform-origin: 50% 50%;
}

.circle-chart__content {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    white-space: normal;
    width: 60%;
    height: 60%;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);

    span {
        font-size: 1.75rem;
        font-weight: bold;
        text-align: center;
    }
}

</style>
