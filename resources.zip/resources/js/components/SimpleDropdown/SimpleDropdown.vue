<template>
    <div class="btn-more__wrapper" ref="btnMore">
        <b-dropdown
            :class="{'btn-more': more}"
            :id="buttonId"
            @shown="handleShown"
            :variant="variant"
            :disabled="disabled"
            :type="type"
            right
            :text="title"
            :no-caret="noCaret"
        >
            <template #button-content v-if="customButton">
                <slot name="button">
                    <span :class="'btn-more__icon ' + iconClass"></span>
                </slot>
            </template>

            <h6 v-if="dropdownHeadline" class="dropdown-headline">{{ dropdownHeadline }}</h6>
            <slot></slot>

        </b-dropdown>
        <b-tooltip v-if="!noTooltip" :target="() => $refs['btnMore']" :title="title" triggers="hover"></b-tooltip>
    </div>
</template>

<script>
import {BDropdown, BTooltip} from 'bootstrap-vue';

export default {
    name: 'SimpleDropdown',
    components: {
        BDropdown, BTooltip
    },
    props: {
        iconClass: {
            type: String,
            required: false,
            default: 'icon-action-more-selected'
        },
        buttonId: {
            type: String,
            required: false
        },
        title: {
            type: String,
            required: false,
            default: 'More'
        },
        dropdownHeadline: {
            type: String,
            required: false
        },
        variant: {
            type: String,
            required: false
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        type: {
            type: String,
            required: false,
            default: 'button'
        },
        more: {
            type: Boolean,
            required: false,
            default: true
        },
        customButton: {
            type: Boolean,
            required: false,
            default: true
        },
        noCaret: {
            type: Boolean,
            required: false,
            default: true
        },
        noTooltip: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    methods: {
        handleShown() {
            let firstDropdownItem;
            if (this.dropdownHeadline === undefined) {
                firstDropdownItem = this.$refs['btnMore'].querySelector('li:first-child button');
            } else {
                firstDropdownItem = this.$refs['btnMore'].querySelector('li:nth-child(2) button');
            }
            if (firstDropdownItem) {
                firstDropdownItem.focus();
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
.btn-more__wrapper {
    display: inline-block;
}

::v-deep .btn-more button {
    background-color: transparent;
    padding: 3px 5px;
    border: none;
}

.btn-more__icon,
::v-deep .dropdown-item span[class*="icon-"] {
    vertical-align: middle;
    font-size: 25px;
}

::v-deep .dropdown-item span[class*="icon-"] {
    margin-right: 5px;
}

::v-deep .dropdown-menu.dropdown-menu-right.show {
    padding: 15px;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    z-index: 10000;
    & li button:active {
        color: #000;
    }
}

.dropdown-headline {
    padding-left: 3px;
}

::v-deep .dropdown-item {
    white-space: normal;
}

::v-deep li[role="presentation"] {
    padding: 5px 0;
}
</style>
