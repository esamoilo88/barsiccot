<template>
    <div class="quick-view">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: "QuickViewSlot"
}
</script>

<style lang="scss" scoped>

.quick-view {
    background-color: #ededed;
    border-radius: 5px;
}
</style>
