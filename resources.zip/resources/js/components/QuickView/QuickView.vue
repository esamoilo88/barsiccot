<template>
    <div class="d-inline-flex generalInfo mt-3 pl-5 pr-3 pb-3 pt-3">
        <div class="d-flex flex-column mr-5" v-for="column in content">
            <div class="mb-4" v-for="item in column.col"><b>{{ item.name }}</b><br>
                <span v-if="item.value == null"> - </span>
                <span v-else>{{ item.value }}</span>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    name: "quick-view",
    props: {
        content: {
            type: Array,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.generalInfo {
    background-color: $lightgrey;
}
</style>
