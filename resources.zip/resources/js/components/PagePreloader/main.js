import Vue from 'vue';
import PagePreloader from "./PagePreloader";

export default new Vue({
    el: "#page-preloader", //resources/views/layout/layout.blade.php
    components: {
        PagePreloader
    },
    data() {
        return {
            isVisible: false
        }
    },
    methods: {
        show() { this.$children[0].show(); this.isVisible=true; },
        hide() { this.$children[0].hide(); this.isVisible=false; }
    }
});
