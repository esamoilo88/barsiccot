<template>
    <div class="double-deck-date" :id="id">
        <table>
            <tr><td class="double-deck-date__month">{{ dateMonth }}</td></tr>
            <tr><td class="double-deck-date__year">{{ dateYear }}</td></tr>
        </table>
        <span class="double-deck-date__desc">{{ desc }}</span>
    </div>
</template>

<script>
import dayjs from 'dayjs';

export default {
    name: "double-deck-date",
    props: {
        id: {
            type: String,
            required: false
        },
        fullDate: {
            type: String,
            required: false
        },
        month: {
            required: false
        },
        year: {
            required: false
        },
        desc: {
            type: String,
            required: false,
            default: ''
        }
    },
    computed: {
        dateMonth() {
            let month = '';
            if (this.fullDate !== undefined && this.fullDate !== null) {
                month = dayjs(this.fullDate).isValid() ? dayjs(this.fullDate).format('MM') : '-';
            } else {
                switch (typeof this.month) {
                    case 'string':
                        month = this.month.length < 2 ? '0' + this.month : this.month;
                        break;
                    case 'number':
                        month = this.month.toString().length < 2 ? '0' + this.month.toString() : this.month.toString();
                        break;
                    default:
                        month = '-';
                }
            }

            return month;
        },
        dateYear() {
            let year = '';
            if (this.fullDate !== undefined && this.fullDate !== null) {
                year = dayjs(this.fullDate).isValid() ? dayjs(this.fullDate).format('YYYY') : '-';
            } else {
                year = this.year ?? '-';
            }

            return year;
        }
    }
}
</script>

<style scoped>
.double-deck-date {
    display: flex;
    align-items: center;
}

.double-deck-date__month {
    font-weight: bold;
    text-align: center;
    border-bottom: 1px solid black;
}

.double-deck-date__year {
    font-weight: bold;
    text-align: center;
    border-top: 1px solid black;
}

.double-deck-date__desc {
    padding: 0 10px;
}
</style>
