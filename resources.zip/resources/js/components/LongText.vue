<template>
    <span>
        {{ displayText }}
        <button
            v-if="isMoreBtn"
            @click="showLong"
            class="btn-light text-link-color"
            :title="moreBtnTitle"
        >
            {{ moreBtnTitle }}
        </button>
    </span>
</template>

<script>
export default {
    props: {
        text: {
            type: String,
            required: true
        },
        moreBtnTitle: {
            type: String,
            default: 'Mehr anzeigen'
        },
        maxLen: {
            type: Number,
            default: 40
        }
    },
    data() {
        return {
            isLongView: false
        }
    },
    computed: {
        isTextLong() {
            return this.text.length > 40;
        },
        shortText() {
            return this.isTextLong ? this.text.slice(0, this.maxLen) + '...' : this.text;
        },
        displayText() {
            return this.isLongView ? this.text : this.shortText;
        },
        isMoreBtn() {
            return this.isTextLong && !this.isLongView;
        }
    },
    methods: {
        showLong() {
            this.isLongView = true;
        }
    }
}
</script>
