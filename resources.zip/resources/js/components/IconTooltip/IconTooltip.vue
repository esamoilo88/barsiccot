<template>
    <div
        @keyup.enter="onEvent"
        @keyup.space="onEvent"
        tabindex="0"
        class="icon-tooltip">
        <span
            @click="onEvent"
            @keyup.enter="onEvent"
            @keyup.space="onEvent"
            ref="icon-tooltip"
            :class="classList"></span>
        <b-tooltip
            v-if="title"
            :placement="hintPosition"
            :target="() => $refs['icon-tooltip']"
            :title="title"
            triggers="hover">
        </b-tooltip>
    </div>
</template>

<script>
import {BTooltip} from 'bootstrap-vue';
export default {
    name: "IconTooltip",
    components: {
        BTooltip
    },
    props: {
        iconClass: {
            type: String,
            required: false
        },
        title: {
            type: String,
            required: false,
            default: ''
        },
        hintPosition: {
            type: String,
            required: false,
            default: 'lefttop'
        },
        pointer: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        classList() {
            return [
                `icon-tooltip__icon ${this.iconClass}`,
                this.pointer ? 'pointer' : ''
            ]
        }
    },
    methods: {
        onEvent() {
            this.$emit('click');
        }
    }
}
</script>

<style lang="scss" scoped>
.icon-tooltip {
    display: inline-block;
}
.pointer {
    cursor: pointer;
}
</style>
