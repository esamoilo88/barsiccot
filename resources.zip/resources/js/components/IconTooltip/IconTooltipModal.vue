<template>
    <div>
        <IconTooltip
            :icon-class="iconClass"
            :title="title"
            :hint-position="hintPosition"
            pointer
            @click="showModal"
        />
    </div>
</template>

<script>
import IconTooltip from "@comp/IconTooltip/IconTooltip";

export default {
    components: {
        IconTooltip
    },
    props: {
        iconClass: {
            type: String,
        },
        title: {
            type: String,
            default: ''
        },
        hintPosition: {
            type: String,
            default: 'lefttop'
        },
        modalBody: {
            required: true
        },
        modalTitle: {
            type: String,
            required: true
        }
    },
    methods: {
        showModal() {
            this.$bvModal.msgBoxOk(this.modalBody, {
                title: this.modalTitle,
                okTitle: 'Schließen',
                footerClass: 'justify-content-center',
                titleTag: 'h2'
            })

            this.$root.$on('bv::modal::shown', (bvEvent) => {
                const modalTitle = bvEvent.vueTarget.$refs.header.querySelector('.modal-title');

                modalTitle.setAttribute('tabindex', '0');
                modalTitle.focus();
            })
        }
    }

}
</script>
