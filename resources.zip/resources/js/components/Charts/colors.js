export const colors = [
    ['#ffde5d', '#ffd329', '#dbad39'], // 'light', 'normal' and 'dark' tones. And the same below
    ['#ffb356', '#ff9a1e', '#d48936'],
    ['#7ecbf5', '#53baf2', '#317cb3'],
    ['#529AD6', '#1063AD', '#235482'],
    ['#65c8c0', '#1bada2', '#218076'],
    ['#cfd89b', '#bfcb44', '#889130']
];
