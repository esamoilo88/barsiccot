<template>
    <div>
        <canvas :id="id" ref="chart" :width="canvasWidth" :height="canvasHeight"></canvas>
    </div>
</template>

<script>
import ChartMixin from "./mixins/ChartMixin";

export default {
    name: "doughnut-chart",
    mixins: [ChartMixin],
    props: {
        halfDoughnut: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    created() {
        this.setPropsToOptions();

        if (this.halfDoughnut) {
            this.chartOptions.rotation = -Math.PI;
            this.chartOptions.circumference = Math.PI;
        }
    },
    mounted() {
        this.createDataset();
        this.createChart();
    },
    watch: {
        data() {
            this.currentColorGroup = 0;
            this.currentColor = 0;
            this.createDataset();
            this.chart.update();
        }
    },
    data() {
        return {
            type: 'doughnut'
        }
    },
    methods: {
        /**
         * Method for creating dataset data from "data" prop for Doughnut chart
         */
        createDataset() {
            this.chartData.datasets = [];
            let dataset = {};
            let secondLevelDataset = {};
            this.chartData.labels = [];
            this.data.map(item => {

                dataset = this.mapDataPropToChartData(dataset, item);

                if (this.showLegend) this.chartData.labels.push(dataset.labels[dataset.labels.length - 1]);

                if (item.subvalues) {
                    item.subvalues.map(subitem => {
                        secondLevelDataset = this.mapDataPropToChartData(secondLevelDataset, subitem);
                        this.switchColor();
                    });
                }
                this.switchColorGroup();
            });
            this.chartData.datasets.push(dataset);
            this.chartData.datasets.push(secondLevelDataset);
        }
    }
}
</script>

<style scoped></style>
