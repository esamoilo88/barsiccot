<template>
    <div>
        <canvas :id="id" ref="chart" :width="canvasWidth" :height="canvasHeight"></canvas>
    </div>
</template>

<script>
import Chart from "chart.js/auto";

export default {
    name: "BarChart",
    props: {
        id: {
            type: String,
            required: true
        },
        data: {
            type: Object,
            required: true,
            default: () => []
        },
        options: {
            type: Object,
            required: false,
            default: () => ({})
        },
        canvasWidth: {
            type: Number,
            required: false,
            default: 300
        },
        canvasHeight: {
            type: Number,
            required: false,
            default: 150
        }
    },
    created() {

    },
    mounted() {
        this.createChart();
    },
    data() {
        return {
            type: 'bar',
            chart: null,
        }
    },
    methods: {
        /**
         * Instantiates ChartJS object and displays chart in canvas tag
         */
        createChart() {
            const ctx = document.getElementById(this.id);
            this.chart = new Chart(ctx, {
                type: this.type,
                data: this.data,
                options: this.options,
            });
        }
    }
}
</script>

<style scoped>

</style>
