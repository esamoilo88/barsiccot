import {colors} from "@comp/Charts/colors";
import Chart from 'chart.js/auto'
/**
 * Mixin which provides some basic functionality
 * https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/Charts
 */
export default {
    props: {
        id: {
            type: String,
            required: true
        },
        data: {
            type: Array,
            required: true,
            default: () => []
        },
        options: {
            type: Object,
            required: false,
            default: () => ({})
        },
        canvasWidth: {
            type: Number,
            required: false,
            default: 300
        },
        canvasHeight: {
            type: Number,
            required: false,
            default: 150
        },
        showLegend: {
            type: Boolean,
            required: false,
            default: false
        },
        percentFractionNumbers: {
            type: Number,
            required: false,
            default: 0
        },
        customTooltip: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            currentColorGroup: 0,
            currentColor: 0,
            chartData: {
                datasets: []
            },
            chart: null,
            chartOptions: {
                aspectRatio: 1,
                responsive: true,
                labelSuffix: '',
                tooltips: {}
            }
        }
    },
    methods: {
        /**
         * Set props provided by users to chartOptions object
         */
        setPropsToOptions() {
            if (!this.showLegend) {
                this.chartOptions.legend = {display: false};
            }

            if (this.customTooltip) {
                this.chartOptions.tooltips.enabled = false;
                this.chartOptions.tooltips.custom = this.renderCustomTooltip;
            } else {
                this.chartOptions.tooltips.callbacks = {label: this.showTooltip};
            }
        },

        /**
         * Instantiates ChartJS object and displays chart in canvas tag
         */
        createChart() {
            this.chartOptions = {...this.chartOptions, ...this.options}
            const ctx = document.getElementById(this.id);
            this.chart = new Chart(ctx, {
                type: this.type,
                data: this.chartData,
                options: this.chartOptions,
            });
        },

        /**
         * This method restructures data from "data" prop to be applicable for ChartJS
         * for more info - https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/Charts
         * @param dataset
         * @param item
         * @returns {*}
         */
        mapDataPropToChartData(dataset, item) {
            if (item.label) {
                dataset.labels = dataset.labels || [];
                dataset.labels.push(item.label)
            }
            if (item.value) {
                dataset.data = dataset.data || [];
                dataset.data.push(item.value);
            }
            if (item.color) {
                dataset.backgroundColor = dataset.backgroundColor || [];
                dataset.backgroundColor.push(item.color)
            } else {
                dataset.backgroundColor = dataset.backgroundColor || [];
                dataset.backgroundColor.push(this.getColor());
            }
            return dataset;
        },

        /**
         * Get color of an arc of a doughnut. Group (which a first level arc) get the first
         * color of an subarray in colors.js array, all its items (which are second level arcs)
         * get all colors from this subarray.
         * for more info - https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/Charts
         * @returns {*|string}
         */
        getColor() {
            return colors[this.currentColorGroup][this.currentColor];
        },
        switchColorGroup() {
            this.currentColorGroup = this.currentColorGroup === colors.length - 1 ? 0 : ++this.currentColorGroup;
            this.currentColor = 0;
        },
        switchColor() {
            this.currentColor = this.currentColor === colors[this.currentColorGroup].length - 1 ? 0 : ++this.currentColor;
        },

        /**
         * https://www.chartjs.org/docs/latest/configuration/tooltip.html#label-callback
         * @param item
         * @param data
         */
        showTooltip(item, data) {
            let dataset = data.datasets[item.datasetIndex];
            let label = `${dataset.labels[item.index]}: ` || '';
            label += `${dataset.data[item.index]} ${this.chartOptions.labelSuffix}`;
            return label;
        },

        /**
         * Function for displaying external custom tooltip
         * https://www.chartjs.org/docs/latest/configuration/tooltip.html#external-custom-tooltips
         * @param tooltipModel
         */
        renderCustomTooltip(tooltipModel) {
            // Tooltip Element
            let tooltipEl = document.getElementById('chartjs-tooltip-' + this.id);

            // Create element on first render
            if (!tooltipEl) {
                tooltipEl = document.createElement('div');
                tooltipEl.id = 'chartjs-tooltip-' + this.id;
                tooltipEl.innerHTML = '<span></span>';
                document.body.appendChild(tooltipEl);
            }

            // Hide if no tooltip
            if (tooltipModel.opacity === 0) {
                tooltipEl.classList.add('hidden');
                return;
            } else {
                tooltipEl.classList.remove('hidden');
            }

            // Set Text
            if (tooltipModel.body) {
                let dataset = this.chartData.datasets[tooltipModel.dataPoints[0].datasetIndex];
                let label = `${dataset.labels[tooltipModel.dataPoints[0].index]}: ` || '';
                label += `${dataset.data[tooltipModel.dataPoints[0].index]}${this.chartOptions.labelSuffix}`;

                tooltipEl.querySelector('span').innerHTML = label;
            }

            let position = this.chart.canvas.getBoundingClientRect();
            tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
            tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
            tooltipEl.style.padding = tooltipModel.yPadding + 'px ' + tooltipModel.xPadding + 'px';
        }
    }
}
