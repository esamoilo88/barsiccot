<template>
    <span
        :class="icon"
        ref="btnMore"
        :id="iconId"
        tabindex="0"
        :variant="variant"
        @click="clickIcon"
        @keyup.enter="clickIcon"
    >
        <b-tooltip v-if="title" :target="() => $refs['btnMore']" :title="title" triggers="hover"></b-tooltip>
    </span>
</template>

<script>
import {BIcon, BTooltip} from 'bootstrap-vue';

export default {
    name: "FormIcon",
    components: {
        BIcon, BTooltip
    },
    props: {
        clickIcon: {
            type: Function,
            required: false,
            default: () => {
            }
        },
        icon: {
            type: String,
            required: false
        },
        iconId: {
            type: String,
            required: true
        },
        iconClass: {
            type: String,
            required: false
        },
        title: {
            type: String,
            required: false,
            default: ''
        },
        variant: {
            type: String,
            required: false,
            default: 'secondary'
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        type: {
            type: String,
            required: false,
            default: 'button'
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.btn-icon__wrapper {
    display: inline-block;
}

.btn-icon {
    padding: 3px 5px;
}

.btn-icon__svg {
    width: 24px;
    height: 24px;
    fill: $iconscolor;
}
</style>
