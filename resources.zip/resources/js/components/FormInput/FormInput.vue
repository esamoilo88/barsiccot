<template>
    <div :class="{
        'form-group-floating': true,
        'focused': focusClass,
        'upper-label': (focusClass && !disabled) || content || content === 0,
        'is-invalid': errorsNumber > 0,
        'errors-with-bg': errorsNumber > 0 && errorsWithBg,
        'large': size === 'large'
    }">

        <label @click="onLabelClick"
               class="form-label"
               :id="inputId + '__label'"
               :for="inputId">
            {{ labelText }}
        </label>
        <input
            :maxlength="maxLength"
            ref="input"
            :value="value"
            :name="name"
            @input="onInput"
            @change="onChange"
            @focus="focusClass=true"
            @blur="onBlur"
            @keyup.enter="$emit('submit')"
            :id="inputId"
            :type="type"
            :placeholder="placeholder"
            class="form-input"
            :autocomplete="autocomplete"
            :readonly="disabled"
        />
        <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";

export default {
    name: "form-input",
    components: {FormInputErrors},
    mixins: [ErrorsMxn],
    props: {
        value: null,
        name: {
            type: String,
            required: true
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        maxLength: {
            type: String,
            required: false
        },
        inputId: {
            type: String,
            required: true
        },
        labelText: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        autocomplete: {
            type: String,
            required: false,
            default: 'off'
        },
        errorsWithBg: {
            type: Boolean,
            required: false,
            default: false
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        useFormatter: {
            tyoe: Boolean,
            default: false
        },
        formatter: {
            type: Function,
            required: false,
            default: v => v
        },
        placeholder: {
            type: String,
            required: false
        },
    },
    data() {
        return {
            focusClass: false
        }
    },
    computed: {
        content() {
            if (this.useFormatter) {
                this.$emit('input', this.formatter(this.value));
            }

            return this.value;
        }
    },
    methods: {
        onInput($event) {
            let value = $event.target.value;
            this.$emit('input', this.formatter(value));
        },
        onChange($event) {
            let value = $event.target.value;
            this.$emit('change', this.formatter(value));
        },
        onLabelClick() {
            this.focus();
        },
        focus() {
            this.$refs.input.focus();
        },
        onBlur() {
            this.$emit('blur');

            this.focusClass = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/components/formInput';
</style>
