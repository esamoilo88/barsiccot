<template>
    <div :class="{
        'form-group-floating': true,
        'is-invalid': errorsNumber > 0,
        'left-borders-none': prepended || prepend !== '',
        'right-borders-none': appended || append !== ''
    }">

        <b-input-group>
            <slot name="prepend">
                <b-input-group-prepend v-if="prepend !== ''" is-text>
                    {{ prepend }}
                </b-input-group-prepend>
            </slot>

            <FormInput
                :value="value"
                :max-length="maxLength"
                :name="name"
                :type="type"
                :autocomplete="autocomplete"
                :input-id="inputId"
                :label-text="labelText"
                @input="onInput"
                @change="val => $emit('change', val)"
                :disabled="disabled"
                @submit="$emit('submit')"
            />

            <slot name="append">
                <b-input-group-append v-if="append !== ''" is-text>
                    {{ append }}
                </b-input-group-append>
            </slot>
        </b-input-group>

        <ul
            v-if="errorsNumber > 0"
            :class="{
                'invalid-feedback': true,
                'd-block': errorsNumber > 0,
                'one-error': errorsNumber === 1
            }
        ">
            <li
                :class="{'d-none': !error.condition}"
                role="alert"
                aria-live="assertive"
                aria-atomic="true"
                v-for="error in errorConditions"
                :key="error.name"
            >{{ error.text }}</li>
        </ul>
    </div>
</template>

<script>
import {BInputGroup, BFormInput, BInputGroupAppend, BInputGroupPrepend} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";

export default {
    name: "FormInputAppend",
    components: {
        FormInput,
        BInputGroup, BFormInput, BInputGroupAppend, BInputGroupPrepend
    },
    props: {
        value: null,
        name: {
            type: String,
            required: true
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        maxLength: {
            type: String,
            required: false
        },
        inputId: {
            type: String,
            required: true
        },
        labelText: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        autocomplete: {
            type: String,
            required: false,
            default: 'off'
        },
        append: {
            type: String,
            required: false,
            default: ''
        },
        prepend: {
            type: String,
            required: false,
            default: ''
        },
        appended: {
            type: Boolean,
            required: false,
            default: false
        },
        prepended: {
            type: Boolean,
            required: false,
            default: false
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            focusClass: false
        }
    },
    computed: {
        content() {
            return this.value;
        },
        errorsNumber() {
            let anyErrors = [];
            if (this.errorConditions !== undefined) {
                anyErrors = this.errorConditions.filter((error) => {
                    return error.condition;
                });
            }
            return anyErrors.length;
        }
    },
    methods: {
        onInput(value) {
            this.$emit('input', value);
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.one-error {
    padding-left: 0 !important;
    list-style: none;
}
.form-group-floating {
    position: relative;
    padding: 0;
    border-radius: 0.25rem;
    width: 100%;

    &.is-invalid {

        .form-input {
            border: 1px solid $error;
        }

        .invalid-feedback {
            color: $error;
            padding-left: 20px;
            padding-top: 5px;
            margin-bottom: 0;
        }
    }

    ::v-deep .form-group-floating {
        padding: 0;
    }
}

::v-deep .input-group {
    flex-wrap: nowrap;
    padding: 2px;
}

::v-deep .input-group-text {
    padding-top: 11px;
}

::v-deep .form-label {
    top: 14px;
}

::v-deep .upper-label .form-label {
    transform: translateY(-50%);
    font-size: .75em;
}

.left-borders-none {
    ::v-deep .form-input {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
    }
}

.right-borders-none {
    ::v-deep .form-input {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
    }
}

</style>
