<template>
    <div class="d-inline-flex w-100">
        <div class="simple-box w-100 d-flex align-items-center">
            <div class="row no-gutters wrapper-icon">
                <span class="icon-alert-warning-default notice-icon"></span>
            </div>
            <div class="row no-gutters">
                Du hast keine Berechtigung auf diese Funktion.
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "NotAvailable"
}
</script>

<style scoped>
.notice-icon {
    font-size: 30px;
    margin-right: 10px;
}
.wrapper-icon {
    display: flex;
    align-items: center;
}
</style>
