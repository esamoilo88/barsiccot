<template>
    <div class="people-search-component">
        <b-form-tags no-outer-focus class="mb-2" style="padding-bottom: 20px" id="people-search">
            <template v-slot="{ tags, inputAttrs, inputHandlers, addTag, removeTag }">
                <label class="card-label">{{ label }}</label>
                <div class="d-inline-block user-block">
                    <ul v-if="users !== []" class="list-inline d-inline-block mb-2 user-list">
                        <li v-for="user in users"
                            :key="user.display_name"
                            class="list-inline-item user-item"
                            @keyup.enter="showModal(user)"
                            tabindex="0"
                        >
                            <b-form-tag
                                @remove="removeUser(user)"
                                :key="user.display_name"
                                :title="user.display_name"
                                class="mr-1 item"
                                @click.native="showModal(user)"
                            >{{ user.display_name }}
                            </b-form-tag>
                        </li>
                        <UserCardDialog
                            @hideModal="hideModal"
                            :email="email"
                            :isVisible="isVisible"
                        />
                    </ul>
                </div>
                <b-input-group>
                    <b-input-group-prepend is-text class="search-icon">
                        <span class="icon-action-search-default"></span>
                    </b-input-group-prepend>
                    <b-form-input
                        v-model="inputValue"
                        v-debounce:1000ms="value => search(value)" debounce-events="input"
                        @click="showResult"
                        @keyup.enter="showResult"
                        @focus="inputFocused = true"
                        @blur="onInputBlur"
                        class="search-form"
                        autocomplete="off"
                        placeholder="Personen suchen..."
                        :id="inputId"
                        ref="input"
                        type="search"
                        :disabled="disabled || searchDisabled"
                    />
                </b-input-group>
                <b-card v-show="showNotEmptyResult" class="result-wrapper" ref="suggestedList">
                    <div
                        v-for="user in result"
                        @click="addUser(user)"
                        class="result-card"
                        tabindex="0"
                        @keyup.enter="addUser(user)"
                        @blur="hideResultsOnBlur"
                    >
                        <span class="username">{{ user.display_name }}</span>
                        <span class="department">{{ user.department }}</span>
                    </div>
                </b-card>
                <b-card v-show="showEmptyResult" class="result-wrapper">
                    Keine Daten gefunden.
                </b-card>
            </template>
        </b-form-tags>
    </div>
</template>

<script>
import {BCard, BFormTags, BFormInput, BFormTag, BInputGroup, BInputGroupPrepend} from 'bootstrap-vue';
import vueDebounce from 'vue-debounce';
import Vue from 'vue';
import UserCardDialog from "../Ldap/UserCardDialog";

Vue.use(vueDebounce);
export default Vue.extend({
    name: "PeopleSearch",
    props: {
        type: {
            type: String,
            default: 'simple',
            validator: function (value) {
                return value === 'simple' || value === 'ldap' || value === 'default'
            }
        },
        permissionIds: {
            type: Array,
            required: false
        },
        label: {
            type: String,
            default: 'Search for users / people',
            required: false
        },
        defaultSearch: {
            type: Function,
            required: false
        },
        multiple: {
            type: Boolean,
            required: false,
            default: true
        },
        searchDisabled: {
            type: Boolean,
            required: false,
            default: false
        },
        inputId: {
            type: String,
            default: 'button-content'
        }
    },
    components: {
        BCard,
        BFormTags,
        BFormInput,
        BFormTag,
        UserCardDialog,
        BInputGroup,
        BInputGroupPrepend
    },
    data() {
        return {
            isVisible: false,
            disabled: false,
            result: [],
            showNotEmptyResult: false,
            showEmptyResult: false,
            isLoaded: false,
            users: [],
            email: '',
            inputValue: '',
            inputFocused: false
        }
    },
    methods: {
        hideResultsOnBlur() {
            setTimeout(() => {
                let result = this.$refs.suggestedList;
                let isResultsFocus = result === undefined ? null : result.querySelector('.result-card:focus') !== null;
                if (isResultsFocus === false) {
                    this.hideResult();
                }
            }, 10);
        },
        onInputBlur() {
            this.inputFocused = false;
            this.hideResultsOnBlur();
        },
        async search(value) {
            this.showEmptyResult = false;
            this.showNotEmptyResult = false;
            this.isLoaded = false;

            if (value.length < 3) {
                return;
            }

            this.disabled = true;
            this.result = [];

            let response = [];

            try {
                if (this.type === 'ldap') {
                    response = await this.$axios.post('/ldap/search', {search: value});
                } else if (this.type == 'default') {
                    response = await this.defaultSearch(value);
                } else {
                    response = await this.$axios.post('/users/search', {search: value, roles: this.permissionIds});
                }
            } catch (error) {
                window.flash.showMessagesFromAjax('Ein Fehler ist aufgetreten.', 'error');
            }

            this.isLoaded = true;
            this.disabled = false;

            if (response.data.length !== 0) {
                this.result = response.data
            }

            this.showResult();
        },
        addUser(value) {
            this.removeUser(value, false);

            if (!this.multiple) {
                this.users = [];
            }

            this.users.push(value);

            this.$emit('user-added', value);
            this.inputValue = '';
            this.focusInput();
            this.inputFocused = false;
            this.hideResult();
        },
        removeUser(value, isEmit = true) {
            this.users = this.users.filter(user => value.display_name !== user.display_name);
            if (isEmit === true) {
                this.$emit('user-dropped', value)
            }
        },
        hideResult() {
            if (this.inputFocused === false) {
                this.showEmptyResult = false;
                this.showNotEmptyResult = false;
            }
        },
        hideModal() {
            this.isVisible = false;
            this.email = '';
        },
        showModal(value) {
            if (this.users.filter(user => value.display_name === user.display_name).length !== 0) {
                this.email = value.email;
                this.isVisible = true;
            }
        },
        showResult() {
            if (this.isLoaded) {
                if (this.result.length !== 0) {
                    this.showNotEmptyResult = true;
                } else {
                    this.showEmptyResult = true;
                    setTimeout(() => {
                        this.showEmptyResult = false;
                    }, 2000)
                }
                this.focusInput();
            }
        },
        focusInput() {
            let input = this.$refs.input.$el;
            setTimeout(() => {
                input.focus()
            }, 10)
        },
        clear() {
            this.users = [];
            this.result = [];
            this.inputValue = '';
        },
        pushUser(user) {
            this.users.push(user);
        }
    }
})
</script>

<style scoped>
.people-search-component {
    width: 350px;
    position: relative;
}

.result-card {
    display: flex;
    flex-direction: column;
    padding: 5px;
}

.username {
    font-weight: bold;
    font-size: 20px;
}

.result-card:hover {
    background-color: #e20074;
    color: #f7f7f7;
    border-radius: 7px;
    cursor: pointer;
}

.result-card:focus {
    background-color: #e20074;
    color: #f7f7f7;
    border-radius: 7px;
    cursor: pointer;
}

.result-wrapper {
    margin-top: 10px;
    max-height: 200px;
    overflow-y: auto;
    width: 320px;
    position: absolute;
    z-index: 1000;
}

.user-list {
    width: 100%;
    margin: 5px 0;

}

.user-block {
    width: 100%;
    font-size: 1.5rem;
}

.user-item {
    width: 100%;
    margin-bottom: 7px;
    cursor: pointer;
}

.item {
    width: 100%;
    text-align: left;
    background-color: #007bff40;
}

.card-label {
    color: #888;
    font-weight: bold;
    margin-top: 7px;
}

.search-icon {
    border-right: none;
    background-color: transparent;
}

.search-form {
    border-left: none;
}

::v-deep ::-webkit-scrollbar {
    width: 5px;
}

::v-deep .input-group-text {
    border-right: none;
    background-color: transparent;
}

/* Track */
::v-deep ::-webkit-scrollbar-track {
    border-radius: 10px;
}

/* Handle */
::v-deep ::-webkit-scrollbar-thumb {
    background: #e20074;
    border-radius: 10px;
}

/* Handle on hover */
::v-deep ::-webkit-scrollbar-thumb:hover {
    background: #e20074;
}
</style>
