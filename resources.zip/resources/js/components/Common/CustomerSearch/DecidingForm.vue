<template>
    <div class="customer_cards">
        <b-card
            :img-src="'/img/conf/external_customers.jpg'"
            img-alt="Externe Kunden"
            img-top
            tag="article"
            style="max-width: 17rem;"
            class="mb-2 mr-3 card"
        >
            <h3 class="mb-2">Externe Kunden</h3>
            <b-card-text>
                Finde hier <b>externe</b> Kunden wie Siemens, Lidl oder Stihl in allen Segmenten sowie Behörden und
                öffentliche Einrichtungen.
            </b-card-text>
            <div class="customer_button">
                <b-button
                    @click="$emit('select-customer', true)"
                    href="#"
                    variant="primary">
                    Externe Kunden suchen
                </b-button>
            </div>
        </b-card>
        <b-card
            :img-src="'/img/conf/internal_customers.jpg'"
            img-alt="Konzernkunden"
            img-top
            tag="article"
            style="max-width: 17rem;"
            class="mb-2 mr-3 card"
        >
            <h3 class="mb-2">Konzernkunden</h3>
            <b-card-text>
                Finde hier <b>interne</b> Kunden wie Telekom Deutschland, ITENOS oder die DT IT in den Segmenten VEB und
                VEBT.
            </b-card-text>
            <div class="customer_button">
                <b-button
                    @click="$emit('select-customer',false)"
                    href="#"
                    variant="primary">
                    Konzernkunden suchen
                </b-button>
            </div>
        </b-card>
    </div>

</template>

<script>
import {BCard, BCardText, BCardTitle, BButton} from 'bootstrap-vue';

export default {
    name: "deciding-form",
    components: {
        BCard,
        BCardText,
        BCardTitle,
        BButton
    }
}
</script>
<style lang="scss" scoped>
.customer_cards {
    display: flex;
    position: relative;
    flex-wrap: wrap;
    width: 51%;
    margin: 0 auto;

    .customer_button {
        position: absolute;
        bottom: 1rem;
    }

    .card-text {
        margin-bottom: 3rem;
    }
}
</style>
