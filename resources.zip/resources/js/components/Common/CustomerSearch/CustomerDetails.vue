<template>
    <div class="quick-view py-2 mt-3 row">
        <div class="spinner" v-if="detailsData === {}">
            <b-spinner label="wird heruntergeladen"></b-spinner>
        </div>
        <div class="d-flex w-100" v-else>
           <div class="col-lg-6">
                <div class="mt-2"><b>GP-Nummer</b></div>
                <div>{{ defVal(detailsData.gpNr, '-') }}</div>
                <div class="mt-2"><b>Kundenname</b></div>
                <div>{{ defVal(detailsData.gpNameLang, '-') }}</div>
                <div class="mt-2"><b>Kundennummer</b></div>
                <div>{{ defVal(detailsData.dtagKdnr, '-') }}</div>
               <div class="mt-2"><b>PLZ</b></div>
               <div>{{ defVal(detailsData.gpPlz, '-') }}</div>
            </div>
            <div class="col-lg-6">
                <div class="mt-2"><b>Ort</b></div>
                <div>{{ defVal(detailsData.gpOrt, '-') }}</div>
                <div class="mt-2"><b>Segment</b></div>
                <div>{{ defVal(detailsData.segment, '-') }}</div>
                <div class="mt-2"><b>Status</b></div>
                <div>{{ defVal((detailsData.isActive) ? 'Aktiv' : 'Inaktiv', '-') }}</div>
            </div>
            <div class="col-lg-6">
                <div class="mt-2"><b>USt-ID</b></div>
                <div>{{ defVal(detailsData.ustId, '-') }}</div>
                <div class="mt-2"><b>Zielgruppen-ID</b></div>
                <div>{{ defVal(detailsData.zgId, '-') }}</div>
                <div class="mt-2"><b>Zielgruppe</b></div>
                <div>{{ defVal(detailsData.zgBezeichnung, '-') }}</div>
            </div>
            <div class="col-lg-6">
                <div class="mt-2"><b>Wirtschaftszweig-ID</b></div>
                <div>{{ defVal(detailsData.wzId, '-') }}</div>
                <div class="mt-2"><b>Zielgruppen-ID</b></div>
                <div>{{ defVal(detailsData.zgId, '-') }}</div>
                <div class="mt-2"><b>Wirtschaftszweig</b></div>
                <div>{{ defVal(detailsData.wzBezeichnung, '-') }}</div>
            </div>
        </div>
    </div>

</template>

<script>
import {BSpinner} from 'bootstrap-vue';
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";


export default {
    name: "customer-details",
    components: {BSpinner},
    mixins: [ScalarsProcessing],
    props:{
        detailsData: {
            type: Object,
            required: true,
        }
    }
}
</script>
<style lang="scss" scoped>
.spinner {
    position: relative;
    padding: 40px;
    left: 45%
}
.quick-view {
    background-color: #ededed;
    border-radius: 5px;
}
</style>
