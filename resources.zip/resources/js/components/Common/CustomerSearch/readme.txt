replica from resources/js/widgets/Projects/ProjectsWidget/CustomerSearch but without state
