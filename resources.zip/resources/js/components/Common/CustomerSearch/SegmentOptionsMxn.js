export default {
    methods: {
        async getSegmentsOptions() {
            const response = await this.$axios.get('/projects/segmentsList');
            if (response.data) {
                let project = response.data;
                this.segmentList = project.internal_cutomer_segment;
            }
        }
    }
}
