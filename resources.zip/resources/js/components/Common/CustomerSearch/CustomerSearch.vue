<template>
    <b-container fluid>
        <deciding-form @select-customer="value =>decided(value)" v-if="isDecidingView"></deciding-form>
        <search-form
            @deciding-view="isDecidingView = true"
            v-else
            :is-update="update"
        />
    </b-container>
</template>
<script>
import SearchForm from "./SearchForm";
import DecidingForm from "./DecidingForm";
import {mapActions, mapState} from 'vuex';
import {BContainer} from 'bootstrap-vue';

export default {
    name: "customer-search",
    components: {
        SearchForm,
        DecidingForm,
        BContainer
    },
    props: {
        update: {
            type: Boolean,
            required: false,
            default: false
        },
    },
    created() {
        this.isDecidingView = !this.searchCustomerData.searchWord;
    },
    computed: {
        ...mapState({
            searchCustomerData: state => state.project.searchCustomer
        })
    },
    data() {
        return {
            isDecidingView: true
        }
    },
    methods: {
        ...mapActions({
            setCustomerResult: "project/setCustomerResult"
        }),
        decided(value) {
            this.isDecidingView = false;
            this.setCustomerResult({
                searchData: [],
                searchWord: null,
                segment: null,
                isExternal: value,
                totalRows: 0
            });
        }
    }
}

</script>

