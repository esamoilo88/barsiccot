<template>
    <div class="simple-box configuration-item my-3">
        <div class="row">
            <div class="col-xl-17 col-lg-14 col-md-15 col-sm-14 col-14 px-0">
                <div class="item-customerName">
                    {{ item.kundenname }}
                </div>
                <div class="item-footer mt-1 text-muted">
                    {{ item.kundenstandort }}
                    <span class="mx-1 bullet-divider" v-if="item.gpNummer">•</span>
                    {{ item.gpNummer }}
                    <span class="mx-1 bullet-divider" v-if="item.gpNummer && item.kundennummer">•</span>
                    {{ item.kundennummer }}
                    <span class="mx-1 bullet-divider" v-if="item.segment && item.kundennummer">•</span>
                    {{ item.segment }}
                    <span class="mx-1 bullet-divider" v-if="item.segment && item.zgId">•</span>
                    {{ item.zgBezeichnung }}
                    <span class="mx-1 bullet-divider" v-if="item.zgId && item.wzId">•</span>
                    {{ item.wzBezeichnung }}
                </div>
            </div>
            <div class="col-xl-3 col-lg-5 col-md-4 col-sm-4 col-4 align-items-center pr-0">
                <div class="item-segment ml-auto">
                    <b-badge :variant="'success'" v-if="item.customerId">
                        Bestandskunde
                    </b-badge>
                    <b-badge :variant="'info'" v-else>
                        Neuekunde
                    </b-badge>
                    <b-badge :variant="'secondary'">
                        {{ isInternal(item.segment) }}
                    </b-badge>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5 col-md-5 col-sm-6 col-6 align-items-center pr-0 pt-3">
                <b-button
                    :disabled="disableBestandskunde && item.customerId"
                    size="md"
                    @click="selectCustomer(item)"
                    class="ml-1"
                    variant="primary"
                >
                    {{ selectionBtnText }}
                </b-button>
            </div>
        </div>
        <div class="details" v-if="isDetailsVisible">
            <customer-details :details-data="item"></customer-details>
        </div>
    </div>
</template>
<script>
import {BButton, BTable, BBadge} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import CustomerDetails from "./CustomerDetails";
import {mapActions, mapGetters, mapMutations, mapState} from "vuex";
import SegmentOptionsMxn from "./SegmentOptionsMxn";

export default {
    name: "CustomerItem",
    components: {
        BButton, BTable, ButtonIcon, CustomerDetails, BBadge
    },
    props: {
        itemProp: {
            type: Object,
            required: true
        },
        isUpdate: {
            type: Boolean,
            required: false
        },
        selectionBtnText: {
            type: String,
            required: false,
            default: 'Auswählen'
        },
        disableBestandskunde: {
            type: Boolean,
            required: false,
            default: false
        },
        segmentList: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            item: this.itemProp,
            isDetailsVisible: false,
            kunde: {}
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'project/simpleId'
        })
    },
    methods: {
        isInternal(segment) {
            return this.segmentList.includes(segment) ? 'Konzernkunde' : 'Externalkunde';
        },
        selectCustomer(item) {
            this.$eventBus.$emit('select-customer', item);
        },
    }
}
</script>

<style lang="scss" scoped>
.item-customerName {
    font-weight: bold;
    align-self: flex-start;
}

.customer-item-left {
    border-right: 2px solid #d2d2d2;
}

.customer-data {
    display: flex;

    td:nth-child(1) {
        padding: 5px 20px 5px 0;
    }
}

.badge-info, .badge-success {
    margin-bottom: 8px;
    width: 120px;
}

.badge-secondary {
    width: 120px;
}
</style>
