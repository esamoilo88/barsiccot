<template>
    <div>
        <b-overlay :show="pending">
            {{ introText }}
            <!-- User Interface controls -->
            <div class="simple-box">
                <div class="d-flex row">
                    <div class="col-md-12 col-lg-12 pl-0">
                        <FormInput
                            v-model="filter.kundenname"
                            @keyup.native.enter="searchCustomer"
                            input-id="kundenname-input"
                            name="kundenname"
                            class="w-100"
                            size="small"
                            label-text="Kundenname"
                        />
                        <FormInput
                            v-model="filter.kundennummer"
                            @keyup.native.enter="searchCustomer"
                            input-id="kundennummer-input"
                            name="kundennummer"
                            class="w-100"
                            size="small"
                            label-text="Kundennummer"
                            :error-conditions="[
                                {
                                    name: 'not-integer-kundennummer',
                                    condition: !$v.filter.kundennummer.integer && $v.filter.kundennummer.$dirty,
                                    text: $t.__('validation.project.kundennummer.integer')
                                },
                            ]"
                        />
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <FormInput
                            v-model="filter.gpNummer"
                            @keyup.native.enter="searchCustomer"
                            input-id="gpNummer-input"
                            name="gpNummer"
                            class="w-100"
                            size="small"
                            label-text="GP-Nummer"
                            :error-conditions="[
                                {
                                    name: 'not-integer-gpNummer',
                                    condition: !$v.filter.gpNummer.integer && $v.filter.gpNummer.$dirty,
                                    text: $t.__('validation.project.gpNummer.integer')
                                },
                            ]"
                        />
                        <FormInput
                            v-model="filter.ort"
                            @keyup.native.enter="searchCustomer"
                            input-id="ort-input"
                            name="ort"
                            class="w-100"
                            size="small"
                            label-text="Ort"
                        />
                    </div>
                </div>

                <div class="d-flex mt-4 row">
                    <div class="col-md-12 col-lg-12">
                        <b-form-group>
                            <b-form-radio-group
                                id="btn-radios-1"
                                v-model="radioSelect.selectedInternalExternal"
                                :options="optionsInternalExternal"
                                name="radios-btn-default"
                            ></b-form-radio-group>
                        </b-form-group>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <b-form-group>
                            <b-form-radio-group
                                id="btn-radios-2"
                                v-model="radioSelect.selectedCrm"
                                :options="optionsCrm"
                                name="radios-btn-default-1"
                            ></b-form-radio-group>
                        </b-form-group>
                    </div>
                    <div class="search_button">
                        <b-button
                            :disabled="(!filter.kundenname && !filter.kundennummer && !filter.gpNummer && !filter.ort) || pending"
                            class="ml-5 h-50"
                            variant="primary"
                            @click="searchCustomer"
                        >
                            Suchen
                        </b-button>
                    </div>
                </div>
            </div>

            <!-- Main table element -->
            <div class="mt-3" v-if="searchData">
                <h2>Suchergebnisse</h2>
                <div v-if="searchData.length > 0" id="customer-items-list" class="list-wrapper">
                    <customer-item
                        v-for="item in searchData"
                        :item-prop="item"
                        :key="item.dtagKdnr"
                        :is-update="isUpdate"
                        :selection-btn-text="selectionBtnText"
                        :segment-list="segmentList"
                        :disable-bestandskunde="disableBestandskunde"
                    />
                </div>

                <div v-else class="text-center">
                    {{ emptyText }}
                </div>

                <Pagination
                    v-model="currentPage"
                    v-if="totalRows != -1"
                    @input="searchCustomer"
                    :per-page-prop="perPage"
                    :current-page="currentPage"
                    table-id="customer-items-list"
                    :total-rows-prop="totalRows"
                    @per-page-changed="pages => $emit('per-page-changed', pages)"
                />
            </div>
        </b-overlay>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {
    BButton, BModal, BTable, BCol, BRow, BFormRadioGroup,
    BFormGroup, BInputGroup, BOverlay
} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import CustomerItem from "./CustomerItem"
import SegmentOptionsMxn from "./SegmentOptionsMxn";
import Vue from 'vue';
import Vuelidate from 'vuelidate';
import {integer} from "vuelidate/lib/validators";
import Pagination from "@comp/Pagination/Pagination";

Vue.use(Vuelidate);

export default Vue.extend({
    name: "search-form",
    components: {
        FormInput, BButton, BModal, BTable, BCol, BRow, BInputGroup, BOverlay,
        CustomerItem, FormSelect, BFormRadioGroup, BFormGroup, Pagination
    },
    mixins: [SegmentOptionsMxn],
    props: {
        isUpdate: {
            type: Boolean,
            required: false,
            default: false
        },
        selectionBtnText: {
            type: String,
            required: false,
            default: 'Auswählen'
        },
        disableBestandskunde: {
            type: Boolean,
            required: false,
            default: false
        },
        introText: {
            type: String,
            required: false,
            default: 'Verwende die Kundensuche um einen neuen Kunden anzulegen.'
        }
    },
    async created() {
        await this.getSegmentsOptions();
    },
    computed: {
        paginationEntriesText() {
            if (this.totalRows === 1) {
                return this.$t.__('tables.entries');
            } else {
                return this.$t.__(this.entriesPlural, {entries: this.totalRows});
            }
        }
    },
    data() {
        return {
            segmentList: [],
            totalRows: 0,
            currentPage: 1,
            perPage: (window.innerHeight > 700) ? 10 : 5,
            sortDesc: false,
            sortDirection: 'asc',
            filter: {
                kundenname: null,
                kundennummer: null,
                gpNummer: null,
                ort: null,
            },
            emptyText: null,
            searchData: null,
            radioSelect: {
                selectedInternalExternal: 'alle',
                selectedCrm: this.disableBestandskunde ? 'alle' : 'bestandkunden'
            },
            optionsInternalExternal: [
                {text: 'Alle Kunden', value: 'alle'},
                {text: 'Nur Konzernkunden', value: 'konzern'}
            ],
            optionsCrm: [
                {text: 'Nur ISP Bestandskunden', value: 'bestandkunden', disabled: this.disableBestandskunde},
                {text: 'Alle Kunden (Account-Navigator)', value: 'alle'}
            ],
            pending: false
        }
    },
    watch: {
        searchData() {
            this.emptyText = (this.searchData && this.filter) ?
                this.$t.__('errors.project.customer.empty_search') :
                this.$t.__('errors.project.customer.search_text');
        }
    },
    methods: {
        async searchCustomer(currentPage) {
            if(typeof currentPage === "object") {
                this.currentPage = 1;
            }
            if (this.filter) {
                this.$v.$touch();
                if (this.$v.$anyError) return;

                this.pending = true;
                let data = {
                    search: this.filter,
                    isInternal: this.radioSelect.selectedInternalExternal,
                    onlyCustomer: this.radioSelect.selectedCrm,
                    currentPage: this.currentPage,
                    perPage: this.perPage,
                    sortDesc: true
                }
                try {
                    const response = await this.$axios.post('/searchCustomer', data);
                    this.searchData = response.data.data;
                    this.totalRows = response.data.total;
                } catch (error) {
                    console.error("Couldn't find customers! Err:", error);
                    window.flash.showMessagesFromAjax(error.response.data);
                }
                this.pending = false;
            }
        }
    },
    validations: {
        filter: {
            kundennummer: {integer},
            gpNummer: {integer}
        }
    }
});
</script>

<style lang="scss" scoped>
.spinner {
    position: relative;
    padding: 40px;
    left: 45%
}

.input-tooltip {
    position: absolute;
    right: -30px;
    top: 15px;
}

.table {
    table-layout: fixed
}

.input-group {
    flex-wrap: nowrap;
}

.search-box {
    display: flex;
    grid-template-columns: 1fr 40px;

    .icon-container {
        padding-top: 14px;
        text-align: center;
    }

}

::v-deep .table.b-table.b-table-stacked > tbody > tr > [data-label]::before {
    text-align: left;
}

::v-deep .modal-content button.btn.btn-primary {
    justify-content: center
}
.search_button {
    align-self: flex-end;
    margin-left: auto;
}

::v-deep .custom-control-inline {
    display: block;
}
</style>
