<template>
    <div>
        <modal-dialog
            modal-class="close-project-modal"
            :is-visible="isVisible"
            @hideModal="$emit('hide-close-project-modal')"
            title-dialog="Auftrag beenden"
            scrollable
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <b-overlay :show="onInitPending">
                        <FormSelect
                            v-model="reasonId"
                            class="mb-3"
                            select-id="reason-id"
                            name="reason-id"
                            label-text="Abgeschlossen Grund*"
                            :options="reasonOptions"
                            :error-conditions="[
                                {
                                    name: 'empty-reason',
                                    condition: !$v.reasonId.required  && $v.reasonId.$dirty,
                                    text: $t.__('validation.required', {attribute: 'Abgeschlossen Grund'})
                                }
                            ]"
                        />
                    </b-overlay>
                </div>
            </div>

            <template #footer="{methods}">
                <button @click="closeProject" class="btn btn-primary">
                    <b-spinner v-if="onSavePending" small></b-spinner>
                    Auftrag beenden
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BSpinner, BOverlay} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {required} from "vuelidate/lib/validators";
import {createOptions} from "@helpers/Form/InputsHelper";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "CloseProject",
    components: {
        BSpinner, BOverlay, FormTextArea, FormSelect, ModalDialog
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        simpleId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            reasonId: null,
            reasonOptions: [],
            onInitPending: false,
            onSavePending: false
        }
    },
    async created() {
        await this.init();
    },
    methods: {
        async closeProject() {
            this.onSavePending = true;
            this.$v.$touch();
            if (!this.$v.$anyError) {
                try {
                    const res = await this.$axios.post(`/projects/${this.simpleId}/close`, {reasonId: this.reasonId});
                    window.flash.showMessagesFromAjax(res.data);
                    document.location.reload();
                    this.$emit('hide-close-project-modal');
                } catch (err) {
                    console.error("Couldn't perform close project action!", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onSavePending = false;
        },
        async init() {
            this.onInitPending = true;
            try {
                const res = await this.$axios.get(`/projects/${this.simpleId}/close/get-reasons`);
                this.reasonOptions.push(...createOptions(
                    res.data,
                    (r) => r.abgeschlossengrundId,
                    (r) => r.bezeichnung,
                ));
            } catch (err) {
                console.error("Couldn't initialize close project form!", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.onInitPending = false;
        }
    },
    validations: {reasonId: {required}}
}
</script>

<style scoped>

</style>
