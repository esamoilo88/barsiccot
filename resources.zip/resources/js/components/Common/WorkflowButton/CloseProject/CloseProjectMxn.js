export default {
    data() {
        return {
            isCloseProjectModalShown: false,
            closeProjectModalInit: false
        }
    },
    methods: {
        canCloseProject(user, status) {
            return (user.userRoles.includes('SM') || user.userRoles.includes('AD') || user.isAdmin)
                && (!status.presales && status.active);
        },
        hideCloseProjectModal() {
            this.isCloseProjectModalShown = false;
        }
    }
}
