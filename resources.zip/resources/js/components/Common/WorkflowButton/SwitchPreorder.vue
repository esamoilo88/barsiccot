<template>
    <div>
        <modal-dialog
            :is-visible="isModalVisible"
            @hideModal="toggleModal(false)"
            title-dialog="Vorabbeauftragung fertigstellen"
            modal-class="switchPreorder"
        >
            <b-overlay :show="loading">
                <b-form-group>
                    <FormInput
                        v-model="form.sapAuftragsNr"
                        label-text="SAP Bestellnummer*"
                        name="sapAuftragsNr"
                        input-id="sapAuftragsNr"
                        :error-conditions="[...errorConditions.sapAuftragsNr, ...bestellnummerErrorConditions]"
                    />
                </b-form-group>

                <b-form-group>
                    <form-file-load
                        v-model="form.file"
                        ref="file"
                        type="file"
                        browse-text="Auswählen"
                        @uploadFile="uploadFile"
                        placeholder="Beauftragungsdatei*"
                        accept=".doc, .docx, .pdf, .p7f, .xia"
                        :error-conditions="errorConditions.file"
                    />
                </b-form-group>
            </b-overlay>

            <template v-slot:footer>
                <button class="btn btn-primary" @click="submit" :disabled="loading">
                    Speichern
                </button>
                <button class="btn btn-secondary" @click="toggleModal(false)">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BFormGroup, BSpinner, BOverlay} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import FormFileLoad from '@comp/FileLoad/FormFileLoad';
import {numeric, required} from "vuelidate/lib/validators";
import Validation from '@mixins/Validation/Validation';
import UploadFile from "res/js/widgets/Orders/OrdersCreateWidget/AngebotAuswahl/UploadFile";
import IcpBestellnummerValidationMxn from "@mixins/IcpBestellnummerValidation/IcpBestellnummerValidationMxn";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    components: {ModalDialog, BFormGroup, FormInput, FormFileLoad, BSpinner, BOverlay},
    mixins: [Validation, UploadFile, IcpBestellnummerValidationMxn],
    props: {
        simpleId: {
            required: true
        }
    },
    computed: {
        errorConditions() {
            return {
                sapAuftragsNr: [
                    {
                        name: 'sapAuftragsNr-required',
                        condition: this.isInvalid('sapAuftragsNr', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'SAP Bestellnummer'})
                    },
                    {
                        name: 'sapAuftragsNr-integer',
                        condition: this.isInvalid('sapAuftragsNr', 'numeric'),
                        text: this.$t.__('validation.numeric', {attribute: 'SAP Bestellnummer'})
                    }
                ],
                file: [
                    {
                        name: 'file-required',
                        condition: this.isInvalid('file', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Datei'})
                    }
                ],
            }
        }
    },
    data() {
        return {
            isModalVisible: false,
            loading: false,
            form: {
                file: null,
                attachedfile: null,
                sapAuftragsNr: null,
                financeOrderId: null
            }
        }
    },
    methods: {
        toggleModal(isVisible) {
            this.isModalVisible = isVisible;

            if (this.isModalVisible) {
                this.getFinanceOrderData();
            }
        },
        isValid() {
            this.resetBestellnummerErrors();
            this.$v.form.$touch();

            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;
                this.isContentVisible = true;

                return false;
            }

            return true;
        },
        async submit() {
            if (!this.isValid()) return;

            this.loading = true;

            try {
                await this.$axios.post(`/orders/${this.simpleId}/preorder/switch`, this.form);
                window.flash.success('Erfolgreich gespeichert');
                this.toggleModal(false);
                this.$emit('switchedOrder');
            } catch (e) {
                if (e.response.data.errors) {
                    this.setBestellnummerErrors(e.response.data.errors.sapBestellnummer);
                    navigateToFirstInvalid();
                    delete e.response.data.errors;
                }
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        },
        async getFinanceOrderData() {
            this.loading = true;
            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/finance/order`);
                const financeOrder = response.data;
                if (financeOrder) {
                    this.form.sapAuftragsNr = financeOrder.orderNumber;
                    this.form.financeOrderId = financeOrder.id;
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
            this.loading = false;
        }
    },
    validations: {
        form: {
            file: {required},
            sapAuftragsNr: {required, numeric}
        }
    }

}
</script>
