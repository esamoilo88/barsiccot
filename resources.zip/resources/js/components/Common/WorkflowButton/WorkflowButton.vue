<template>
    <simple-dropdown
        title="Workflow"
        :more="false"
        :custom-button="false"
        :no-caret="false"
        :no-tooltip="noTooltip"
    >
        <b-dropdown-item :href="'/offers/' + simpleId + '/request/'" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-communication-email-default"></span>
                Angebot anfordern
            </span>
        </b-dropdown-item>

        <b-dropdown-item @click="handleFasttrack" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-action-fast-forward-default"></span>
                Angebot erstellen
            </span>
        </b-dropdown-item>

        <b-dropdown-divider class="divider"></b-dropdown-divider>

        <b-dropdown-item @click="resetStatusToS0" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-action-previous_nb-default"></span>
                Vorhaben zurücksetzen
            </span>
        </b-dropdown-item>

        <b-dropdown-item :href="`/projects/${simpleId}/cancel/form`" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-action-circle-close-default"></span>
                Vorhaben stornieren
            </span>
        </b-dropdown-item>

        <b-dropdown-divider class="divider"></b-dropdown-divider>

        <b-dropdown-item :href="`/orders/${simpleId}/create`" link-class="px-1">
            <span class="text-nowrap">
                <span class="icon-user_file-contracts-default"></span>
                Angebot beauftragen
            </span>
        </b-dropdown-item>

        <template>
            <b-dropdown-item @click="showSwitchPreorderModal" link-class="px-1 py-0">
                <span class="text-nowrap">
                    <span class="icon-user_file-contracts-default"></span>
                    Vorabbeauftragung fertigstellen
                </span>
            </b-dropdown-item>

            <SwitchPreorder ref="switchPreorder" :simple-id="simpleId" @switchedOrder="$emit('switchedOrder')" />
        </template>

        <template>
            <b-dropdown-divider class="divider"></b-dropdown-divider>

            <b-dropdown-item @click="showCloseProjectModal" link-class="px-1">
                <span class="text-nowrap">
                    <span class="icon-action-succsess-selected"></span>
                    Auftrag beenden
                </span>
            </b-dropdown-item>

            <CloseProject
                v-if="isCloseProjectModalShown && closeProjectModalInit"
                :simple-id="simpleId"
                :is-visible="isCloseProjectModalShown"
                :is-close-project-modal-shown="isCloseProjectModalShown"
                @hide-close-project-modal="hideCloseProjectModal"
            />
        </template>

        <b-dropdown-item :href="`/change-request/${simpleId}`" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-user_file-contracts-default mr-2"></span>
                Vertrag ändern
            </span>
        </b-dropdown-item>

        <b-dropdown-item @click="handleStartOffer" link-class="px-1 py-0">
            <span class="text-nowrap">
                <span class="icon-user_file-contracts-default mr-2"></span>
                Bearbeitung beginnen
            </span>
        </b-dropdown-item>

    </simple-dropdown>
</template>

<script>
import {BDropdownItem, BDropdownDivider} from 'bootstrap-vue';
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import SwitchPreorder from "./SwitchPreorder";
import CloseProjectMxn from "./CloseProject/CloseProjectMxn";
import Loading from "@comp/DynamicImportHelpers/Loading";
const CloseProject = () => ({loading: Loading, component: import('./CloseProject/CloseProject'), delay: 0});

export default {
    name: "WorkflowButton",
    mixins: [ConfirmationModal, CloseProjectMxn],
    components: {
        CloseProject, BDropdownItem, BDropdownDivider, SimpleDropdown, SwitchPreorder
    },
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        status: {
            type: Object,
            required: true
        },
        hasAePermission: {
            type: Boolean,
            required: true
        },
        canResetStatusToS0: {
            type: Boolean,
            required: true
        },
        noTooltip: {
            type: Boolean,
            required: false,
            default: false
        },
        canSwitchPreorder: {
            type: Boolean,
            default: false
        },
        user: {
            type: Object,
            required: true,
            default: () => ({})
        }
    },
    data() {
        return {
            extra: {
                canResetStatusToS0: this.canResetStatusToS0
            }
        }
    },
    methods: {
        async resetStatusToS0() {
            const hasPermissions = await this.checkPermissionsForResetStatus();

            if (!hasPermissions) {
                return;
            }

            const result = await this.showConfirmationModal({
                message: this.genResetStatusMsg(),
                title: 'Status zurücksetzen',
                okTitle: 'Status zurücksetzen',
            });

            if (!result) {
                return;
            }

            await this.sendResetStatusRequest();
        },
        async checkPermissionsForResetStatus() {
            try {
                await this.$axios.get(`/projects/${this.simpleId}/statuses/s0/reset/permissions`);
                return true;
            } catch (error) {
                this.extra.canResetStatusToS0 = false;
                this.$forceUpdate();
                window.flash.showMessagesFromAjax(error.response.data, 'error');
                return false;
            }
        },
        genResetStatusMsg() {
            const h = this.$createElement;
            return h('div', {
                domProps: {
                    innerHTML: `
                        <p>Der Status des Vorhabens wird auf S0 zurückgesetzt.</p>
                        <ul>
                            <li>Bestehende Kalkulationsdaten bleiben zwar erhalten, werden jedoch archiviert</li>
                            <li>Bestehende Rollenzuweisungen bleiben erhalten</li>
                        </ul>
                    `
                }
            });
        },
        async sendResetStatusRequest() {
            window.preloader.show();

            try {
                const response = await this.$axios.put(`/projects/${this.simpleId}/statuses/s0/reset`);

                this.status.shortName = response.data.status.shortName;
                this.status.progress = response.data.status.progress;
                this.status.color = response.data.status.color;

                this.extra.canResetStatusToS0 = false;
                this.$forceUpdate();

                window.flash.success('Status erfolgreich zurückgesetzt');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data, 'error');
            } finally {
                window.preloader.hide();
            }
        },
        async handleFasttrack() {
            if (!this.hasAePermission) {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
            }
            const h = this.$createElement;
            const messageVNode = h('div',
                {
                    domProps:
                        {
                            innerHTML: '<div class="mb-3">Bitte bestätige die Erstellung eines neuen Angebots:</div> <ul>' +
                                '<li>Das Vorhaben wird direkt in den Status S3 überführt</li> ' +
                                '<li>Das Eingangstor wird nicht eingebunden</li>' +
                                '<li>Das Angebot wird dir zur Bearbeitung zugewiesen</li>' +
                                '<li>Sollte bereits eine Version in Arbeit sein, so wird eine neue Version angelegt</li>' +
                                '</ul>'
                        }
                }
            );

            const result = await this.showConfirmationModal({
                message: messageVNode,
                title: 'Angebot erstellen',
                okTitle: 'Angebot erstellen',
                okVariant: 'primary',
                cancelTitle: 'Abbrechen',
                footerClass: 'flex-row-reverse justify-content-start'
            });

            if (!result) return;

            try {
                window.preloader.show();
                const response = await this.$axios.post(`/offers/${this.simpleId}/fasttrack`);
                window.location.href = response.data.redirect;
                window.preloader.hide();
            } catch (error) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(error.response.data.text, 'error');
            }
        },
        showSwitchPreorderModal() {
            if (!this.canSwitchPreorder) {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
            }
            this.$refs.switchPreorder.toggleModal(true);
        },
        async handleStartOffer() {
            if (this.status.shortName !== 'S2') {
                window.flash.showMessagesFromAjax('Die Funktion kann nur im Status S2 aufgerufen werden.', 'error');
                return;
            }

            const result = await this.$bvModal.msgBoxConfirm('Bitte bestätige den Start der Angebotserstellung.', {
                okTitle: 'Bestätigen',
                cancelTitle: 'Abbrechen',
            });

            if (!result) return;

            window.preloader.show();

            try {
                const response = await this.$axios.post('/offers/' + this.simpleId + '/start');
                window.preloader.hide();
                window.flash.showMessagesFromAjax(response.data.text, 'success');
                window.location.href = '/projects';
            } catch (err) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(err.response.data.text, 'error');
            }
        },
        showCloseProjectModal() {
            if (!this.canCloseProject(this.user, this.status)) {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
            }
            this.isCloseProjectModalShown = true;
            this.closeProjectModalInit = true;
        },
    }
}
</script>

<style lang="scss" scoped>
::v-deep .dropdown-menu {
    padding: 0.4rem 0.5rem !important;
}

.divider {
    ::v-deep hr.dropdown-divider {
        margin: 0.2rem 0;
    }
}
</style>
