<template>
    <div>
        <div v-if="!isLoaded && isEmpty" class="preloader">Warte bitte...</div>
        <div v-else-if="isEmpty && isLoaded" class="preloader">Keine Daten gefunden.</div>
        <div v-else-if="!isEmpty && isLoaded" class="user-card">
            <div class="wrapper">
                <span class="title">Vorname Nachname:</span>
                <span>{{card.name}} {{card.surname}}</span>
            </div>
            <div class="wrapper">
                <span class="title">Firma und Ressort:</span>
                <span>{{card.company}}</span>
                <span>{{card.department}}</span>
                <span>{{card.address}}</span>
                <span>{{card.postcode}} {{card.place}}</span>
            </div>
            <div class="wrapper inline">
                <span class="title">E-Mail und Telefon:</span>
                <a class="link" :href="`mailto:${card.email}`">{{card.email}}</a>
                <span>{{card.phone}}</span>
            </div>
            <div class="button-wrapper">
                <b-button
                    class="btn px-2 btn-secondary custom"
                    size="sm"
                    type="button"
                    :onclick="`self.location.href='${'tel:' + card.phone}'`"
                >
                    Anrufen
                </b-button>
            </div>
        </div>
    </div>
</template>

<script>
import {BButton} from "bootstrap-vue";

export default {
    name: "UserCard",
    components: {
        BButton
    },
    props: {
        email: {
            type: String,
            required: true,
            validator: function (value) {
                return value.indexOf("@") !== -1
            }
        }
    },
    data() {
        return {
            card: {
                name: '',
                surname: '',
                company: '',
                department: '',
                address: '',
                postcode: '',
                place: '',
                email: '',
                phone: ''
            },
            isLoaded: false,
            isEmpty: true
        }
    },
    methods: {
        async fetchData() {
            try {
                const response = await this.$axios.post('/ldap/search', {search: this.email});
                if (response.data.length === 0) {
                    this.isLoaded = true;
                    return;
                }
                this.card = response.data[0];
                this.isLoaded = true;
                this.isEmpty = false;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data, 'error');
            }
        }
    },
    beforeMount() {
        this.fetchData();
    }
}
</script>

<style scoped>
    .custom {
        border: 1px solid gray;
    }
    .title {
        font-weight: bold;
        font-size: 20px;
        margin-bottom: 10px;
    }
    .wrapper {
        display: flex;
        flex-direction: column;
        padding: 10px 5px;
    }
    .user-card {
        height: 100%;
    }
    .link {
        color: #00739F;
    }
    .inline {
        display: inline-flex;
    }
</style>