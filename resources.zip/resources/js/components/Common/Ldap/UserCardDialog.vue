<template>
    <ModalDialog
        :is-visible="isVisible"
        @hideModal="hideModal"
        button-title="User card"
        close-button="Schließen"
        size="l"
        title-dialog="Kontaktdetails"
        modal-class="kontakt-details"
    >
        <UserCard :email="email"/>
    </ModalDialog>
</template>

<script>
import ModalDialog from "../../../components/ModalDialog/ModalDialog";
import UserCard from "../Ldap/UserCard";

export default {
    name: "UserCardDialog",
    props: {
        isVisible: {
            required: true,
            type: Boolean,
            default: false
        },
        email: {
            required: true,
            type: String
        }
    },
    components: {
        ModalDialog,
        UserCard
    },
    methods: {
        hideModal() {
            this.$emit('hideModal');
        }
    }
}
</script>

<style scoped>

</style>
