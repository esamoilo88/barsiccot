import Vue from 'vue';
import DashboardsSwitch from "./DashboardsSwitch";

export default new Vue({
    el: '#dashboard-switch',
    components: {
        DashboardsSwitch
    }
});
