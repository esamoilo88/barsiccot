<template>
    <div>
        <h1 lang="en" class="d-inline-block">
            <span :class="['pr-3',`${iconTitle}-default`]"/>
            {{ title }}
        </h1>
        <div @keyup.enter="setFocus" id="dropdown_box" class="d-inline-block">
            <b-dropdown
                class="switcher-dropdown"
                :aria-expanded="isShow"
                no-caret
            >
                <template #button-content>
                    <slot name="button">
                        <a @click="isShow =!isShow"
                           :title="`${isShowText} Dashboard Switcher`"
                           v-click-outside="() => isShow =false"
                           class="toggle-button">
                            <span
                                :class="isShow ?'btn-more__icon icon-navigation-collapse-up-default':'btn-more__icon icon-navigation-collapse-down-default'"></span></a>
                    </slot>
                </template>
                <div v-for="(item, index) in buttonsList" :key="item.name">
                    <b-dropdown-item :href="item.link" link-class="px-1">
                        <span v-if="item.active" class="sr-only">Zurzeit aktiv</span>
                        <div class="h2"
                             lang="en"
                             :class="{'text-primary': item.active}"
                             :title="item.name"
                             @click="handleClick(item)"
                        >
                        <span class="pr-3"
                              :class="[item.active ? `${item.icon}-selected`: `${item.icon}-default`]"></span>
                            {{ item.name }}
                        </div>
                        <div class="d-flex d-inline-flex">
                            <span class="dashboard-subtext text-muted">{{ item.text }}</span>
                            <span
                                :class="{'pl-3 text-muted': true,'icon-action-succsess-default' : item.active}"></span>
                        </div>
                    </b-dropdown-item>
                    <b-dropdown-divider v-if="index != buttonsList.length - 1" class="divider"
                                        aria-hidden="true"></b-dropdown-divider>
                </div>
            </b-dropdown>
        </div>
    </div>
</template>
<script>
import ButtonList from "@comp/ButtonListe/ButtonList";
import {BButton, BDropdown, BDropdownItem, BDropdownDivider} from "bootstrap-vue";
import ClickOutside from 'vue-click-outside';
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";

export default {
    name: "dashboard-switch",
    components: {
        ButtonList,
        BButton,
        BDropdown,
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider
    },
    directives: {
        ClickOutside
    },
    data() {
        return {
            iconTitle: '',
            isShow: false,
            buttonsList: [
                {
                    name: "Sales Dashboard",
                    text: "Zeigt Stammdaten, Kundendaten, Kontakte und Notizen eines Vorhabens an und ermöglicht dessen Änderung.",
                    icon: "icon-content-news",
                    link: "/projects/" + this.sin,
                    active: false

                },
                {
                    name: "Offer Dashboard",
                    text: "Zeigt Einstellungen sowie Konfiguration, Preis-, Kalkulations- und Angebotsdaten an und ermöglicht dessen Änderung.",
                    icon: "icon-content-tarrifs",
                    link: "/offers/" + this.sin,
                    active: false
                },
                {
                    name: "Finance Dashboard",
                    text: "Zeigt Einstellungen sowie Forecast, Abgrenzungs-, Rechnungs- und Kostendaten an und ermöglicht dessen Änderung.",
                    icon: "icon-user_file-billing",
                    link: "/orders/" + this.sin,
                    active: false
                }
            ]
        }
    },
    props: {
        sin: {
            type: Number,
            required: true
        },
        title: {
            type: String,
            required: true
        },
        customerId: {
            type: Number,
            required: false,
            default: null
        }
    },
    mounted() {
        this.buttonsList.map(item => {
            item.active = false;
            if (item.name === this.title) {
                item.active = true;
                this.iconTitle = item.icon;
            }
            return item;
        });
        if (this.customerId) {
            this.buttonsList.push(
                {
                    name: "Customer Dashboard",
                    text: "Zeigt Kundendaten und verknüpfte Vorhabendaten an.",
                    icon: "icon-user_file-contacts",
                    link: "/customers/" + this.customerId,
                    active: false
                }
            );
        }


    },
    computed: {
        isShowText() {
            return this.isShow ? 'Schließen' : 'Öffnen';
        }
    },
    methods: {
        handleClick(data) {
            this.buttonsList.forEach(item => item.active = false);
            data.active = true;
            window.location.href = data.link;
        },
        setFocus() {
            this.isShow = ! this.isShow;
            setTimeout(function () {
                document.getElementById('dropdown_box').focus();
            }, 10);
        },
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';

.icon-action-succsess-default {
    font-size: 30px;
    color: #56595D;
}

.switcher-dropdown {
    ::v-deep ul.dropdown-menu.show {
        position: absolute;
        transform: translate3d(0px, 45px, 0px);
        top: 0;
        left: -307px !important;
        will-change: transform;
        min-width: 505px;
        max-width: 545px;

        .dropdown-item:active {
            background-color: white;
        }

        a {
            margin: 8px 0 0 21px;
            padding: 11px 0 15px;
            width: 90%;
            cursor: pointer;
        }

        a, span {
            &:hover {
                color: $primary;
            }
        }
    }
}

@media (max-width: 992px) {
    .switcher-dropdown {
        ::v-deep ul.dropdown-menu.show {
            position: absolute;
            transform: translate3d(0px, 45px, 0px);
            top: 5px !important;
            left: -230px !important;
        }
    }
}

::v-deep .btn-secondary {
    border: none;
    padding: 0px;

    &:hover, &:focus, &:active {
        background-color: white;
        border: none;
    }
}

.toggle-button {
    font-size: 30px;
    text-decoration: none;
    color: grey;
}

::v-deep .dropdown-toggle::after {
    display: none;
}

.dashboard-subtext {
    white-space: normal;
}
</style>
