<template>
    <div class="d-inline-block">
        <b-overlay :show="pending">
            <div class="d-flex flex-wrap">
                <div class="d-flex flex-wrap" id="project-tags-list">
                    <b-form-tag
                        @remove="onRemoveTag(tag.label)"
                        v-for="tag in tags"
                        :key="tag.id"
                        :id="`project-tag-${tag.id}`"
                        :class="{'project-tag': true, 'mb-1': true, 'locked': tag.locked}"
                        :no-remove="!isActive || tag.static || tag.locked"
                    >
                        {{ tag.label }}
                    </b-form-tag>

                    <div v-if="!readonly" class="new-tag-input-group ml-1">
                        <button
                            v-if="!isActive"
                            @click="onActive"
                            title="Labels bearbeiten"
                            class="btn btn-secondary edit-btn rounded"
                            v-b-tooltip.hover
                        >
                            <span class="icon-action-edit-default"></span>
                        </button>

                        <FormInputLiveSearch
                            v-else
                            ref="input"
                            v-model="newTag"
                            @submit="onAddTag"
                            input-id="add-tag-input"
                            name="newTag"
                            :items-provider="suggestionsProvider"
                            placeholder="Neues Label"
                            suggestion-text-column="label"
                        >
                            <template #button-1>
                                <button
                                    @click="onAddTag"
                                    title="Label erstellen"
                                    class="btn btn-secondary add-tag-btn"
                                    v-b-tooltip.hover
                                >
                                    <span class="icon-action-add-default"></span>
                                </button>
                            </template>
                            <template #button-2>
                                <button
                                    @click="onCancel"
                                    title="Abbrechen"
                                    class="btn btn-secondary cancel-btn"
                                    v-b-tooltip.hover
                                >
                                    Abbrechen
                                </button>
                            </template>
                        </FormInputLiveSearch>
                    </div>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {BFormTag, BInputGroup, VBTooltip, BOverlay} from 'bootstrap-vue';
import FormInputLiveSearch from "@comp/FormInputLiveSearch/FormInputLiveSearch";
import {$axios} from "res/js/boot";

export default {
    name: "ProjectTags",
    components: {
        FormInputLiveSearch, BFormTag, BInputGroup, ButtonIcon, BOverlay
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        readonly: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            isActive: false,
            newTag: null,
            pending: false,
            tags: [],
        }
    },
    async mounted() {
        await this.init();
    },
    methods: {
        async init() {
            this.pending = true;
            try {
                const res = await $axios.get(`/projects/${this.simpleId}/tags`);
                this.tags.push(...res.data);
            } catch (err) {
                console.error("Couldn't get project tags! Err: ", err);
            }
            this.pending = false;
        },
        async onAddTag() {
            if (this.newTag && this.newTag.length > 1 && !this.checkForDuplicates()) {
                this.pending = true;
                try {
                    const res = await $axios.post(`/projects/${this.simpleId}/tags`, {tag: this.newTag});
                    this.tags.push({id: res.data.id, label: res.data.label, locked: res.data.locked});
                    window.flash.success(this.$t.__('success.generic_success'));
                    this.newTag = null;
                } catch (err) {
                    console.error("Couldn't create a project tag! Err: ", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
                this.pending = false;
            } else {
                this.newTag = null;
            }
        },
        async onRemoveTag(tag) {
            this.pending = true;
            try {
                const res = await $axios.post(`/projects/${this.simpleId}/tags/remove`, {tag});
                this.removeTagLocally(tag);
                window.flash.showMessagesFromAjax(res.data);
            } catch (err) {
                console.error("Couldn't remove a project tag! Err: ", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        async suggestionsProvider() {
            try {
                const res = await $axios.post(`/projects/${this.simpleId}/tags/suggestions`, {tag: this.newTag});
                return res.data;
            } catch (err) {
                console.error("Couldn't get suggestions! Err: ", err);
                return [];
            }
        },
        onActive() {
            this.isActive = true;
            this.$nextTick(() => this.$refs.input.focus());
        },
        onCancel() {
            this.isActive = false;
            this.newTag = null;
        },
        removeTagLocally(tag) {
            let index;
            this.tags.map((t, i) => {
                if (tag === t.label) {
                    index = i;
                }
            });
            this.tags.splice(index, 1);
        },
        checkForDuplicates() {
            let duplicate = this.tags.filter(t => t.label == this.newTag);
            return duplicate.length > 0;
        },
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

$input-group-height: 30px;

#project-tags-list {
    min-width: 25px;
    min-height: 25px;
}

.project-tag.locked {
    background-color: $info;
}

.new-tag-input-group {
    display: flex;
    width: auto;
    max-width: 285px;
    height: $input-group-height;

    ::v-deep #add-tag-input {
        height: $input-group-height;
        font-size: 100%;
        border-bottom-right-radius: 0;
        border-top-right-radius: 0;
    }

    .add-tag-btn {
        border-radius: 0;
        height: initial !important;
    }

    .cancel-btn {
        height: initial !important;
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
        border-left: 2px solid #cdcdcd;
    }
}

span[id*='project-tag-'] {
    align-items: center !important;
    align-self: center;
    font-size: 90%;
    height: 30px;

    button {
        padding-top: 2px;
    }
}

.edit-btn {
    height: initial !important;
}
</style>
