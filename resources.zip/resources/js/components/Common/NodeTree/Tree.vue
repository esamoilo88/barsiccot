<template>
    <div>
        <div
            :class="{
                folder: isFolder,
                'dropdown-item': true,
                'active': item[idField] === selectedItem[idField],
                'd-flex': true
            }"
            :title="title"
            tabindex="0"
        >
            <span
                v-if="isFolder"
                @click="isOpen = !isOpen"
                @keyup.enter="isOpen = !isOpen"
                :class="iconClass + ' mr-1'"
            ></span>
            <div
                class="w-100"
                @click="toggle"
                @keyup.enter="toggle"
            >
                <span class="item-name">{{ item[nameField] }}</span>
            </div>
        </div>
        <ul v-show="isOpen" v-if="isFolder">
            <Tree
                class="item"
                v-for="child in item.children"
                :key="child[idField]"
                :item="child"
                :selected-item="selectedItem"
                :id-field="idField"
                :name-field="nameField"
                :open="open"
            ></Tree>
        </ul>
    </div>
</template>
<script>

export default {
    name: "Tree",
    props: {
        item: {
            type: Object,
            required: false
        },
        selectedItem: {
            type: Object,
            required: false
        },
        idField: {
            type: String,
            default: 'id'
        },
        nameField: {
            type: String,
            default: 'name'
        },
        open: {
            default: () => {}
        }
    },
    data() {
        return {
            isOpen: false,
            setActive: false,
        };
    },
    computed: {
        isFolder() {
            return this.item.children && this.item.children.length;
        },
        title() {
            if (this.isFolder) {
                return this.isOpen ? 'Kategorie schließen' : 'Kategorie öffnen';
            } else {
                return 'Diese Kategorie enthält keine Unterkategorien';
            }
        },
        iconClass() {
            return this.isOpen ? 'icon-navigation-collapse-down-default' : 'icon-navigation-right-default';
        }
    },
    methods: {
        async toggle() {
            this.open(this.item);

            this.setActive = true;
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';

.item {
    cursor: pointer;
}

.folder {
    padding-left: 1px;
}

ul {
    padding-left: 1em;
    line-height: 1.5em;
    list-style-type: dot;
    margin-bottom: 0px;
}

.item-name {
    white-space: normal;
}

</style>
