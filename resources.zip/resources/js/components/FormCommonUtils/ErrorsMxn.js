export default {
    computed: {
        errorsNumber() {
            return (this.errorConditions.filter((e) => e.condition)).length;
        }
    }
}
