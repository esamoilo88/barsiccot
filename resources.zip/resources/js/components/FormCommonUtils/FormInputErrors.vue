<template>
    <ul :class="{'invalid-feedback': true, 'd-block': errorsNumber > 0, 'one-error': errorsNumber === 1}">
        <template v-for="error in errorConditions">
            <li
                v-if="error.condition"
                role="alert"
                aria-live="assertive"
                aria-atomic="true"
                :key="error.name"
            >
                {{ error.text }}
            </li>
        </template>
    </ul>
</template>

<script>
export default {
    name: "FormInputErrors",
    props: {
        errorsNumber: {
            type: Number,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        }
    }
}
</script>

<style scoped>
</style>
