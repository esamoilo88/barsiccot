import Vue from 'vue';
import Toaster from './Toaster';

export default new Vue({
    el: '#flash-messages', //resources/views/layout/layout.blade.php
    props: {
        messages: {
            type: Array
        }
    },
    components: {
        Toaster
    },
    methods: {
        show({text, type}) {
            this.$children[0].show({text, type});
        },
        showMessagesFromAjax(messages, type) {
            try {
                if (typeof messages === 'string' && type !== undefined) {
                    this.$children[0].show({text: messages, type});
                } else if (Array.isArray(messages) && type !== undefined) {
                    this.$children[0].showMessagesFromAjax(messages, type);
                } else if (typeof messages === 'object' && messages.errors !== undefined) {
                    let errors = [];
                    for (const [key, value] of Object.entries(messages.errors)) {
                        if (Array.isArray(value)) {
                            value.forEach(errorMsg => errors.push(errorMsg));
                        }
                    }
                    this.$children[0].showMessagesFromAjax(errors, 'error');
                } else if (typeof messages === 'object' && messages.message !== undefined) {
                    this.error(messages.message);
                } else if (type === undefined) {
                    if (Array.isArray(messages)) {
                        this.$children[0].showMessagesFromAjax(messages);
                    } else {
                        console.error('Messages is not an array!');
                    }
                }
            } catch (err) {
                console.error("Couldn't create flash message from argument ([err], [messages], [type]):", err, messages, type);
                return false;
            }
        },
        error(text) {
            this.$children[0].show({text: text, type: 'error'});
        },
        success(text) {
            this.$children[0].show({text: text, type: 'success'});
        },
        info(text) {
            this.$children[0].show({text: text, type: 'info'});
        },
    },
    mounted() {
        if (this.messages !== undefined) {
            this.$children[0].showAll(this.messages);
        }
    }
});
