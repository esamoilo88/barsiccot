<template>
    <b-toast
        :class="'flash-message ' + type"
        :visible="true"
        no-auto-hide
        static
        @shown="$emit('shown')"
        @hidden="onHidden"
        append-toast
    >
        <template #toast-title="{hide}">
            <slot name="message-title">
                <div class="d-flex flex-grow-1 align-items-baseline">
                    <strong class="mr-auto">{{ defineTitle(type) }}</strong>
                </div>
            </slot>
        </template>
        {{ text }}
        <b-progress
            class="mt-2"
            :max="dismissMillisec"
            :value="dismissCountDown"
            height="4px"
        ></b-progress>
    </b-toast>
</template>

<script>
import {BToast, BProgress} from 'bootstrap-vue';

export default {
    name: 'toast',
    components: {
        BToast, BProgress
    },
    props: {
        text: {
            type: String,
            required: true
        },
        type: {
            type: String,
            required: true
        },
        hash: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            dismissMillisec: 15,
            dismissCountDown: 0
        }
    },
    mounted() {
        this.dismissCountDown = this.dismissMillisec;
        let countdown = setInterval(() => this.countDownChanged(--this.dismissCountDown), 1000);
        setTimeout(() => { clearInterval(countdown); this.onHidden(); }, this.dismissMillisec * 1000);
    },
    methods: {
        countDownChanged(dismissCountDown) {
            this.dismissCountDown = dismissCountDown;
        },
        defineTitle(type) {
            switch (type) {
                case 'error':
                    return 'Fehler';
                case 'success':
                    return 'Erfolgreich';
                case 'info':
                    return 'Info';
            }
        },
        onHidden() {
            this.dismissCountDown = 0;
            this.$emit('hidden', this.hash);
        },

    },
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables.scss";

.message-content-wrapper {
    display: flex;
    align-items: center;

    .message-content-icon {
        min-width: 40px;
        min-height: 40px;
        max-width: 40px;
        max-height: 40px;
        margin: 0 0.8em 0.3em 0;
    }

    .message-content-text {
        flex-grow: 1;
        margin: 0.3em;
    }
}

.flash-message.b-toast {
    min-height: 60px;
    font-size: 1.5rem;
    border: none;
    border-radius: 5px;
    background-color: #fff;

    ::v-deep .toast {
        font-size: 1.2rem;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #CCC;
        box-shadow: 0 0 5px rgb(0 0 0 / 10%);
    }

    ::v-deep .toast-body {
        word-break: break-word;
        background-color: #fff;
        padding-top: 0;
    }
}

.error.b-toast {
    ::v-deep .toast {
        border-left: 6px solid $error;

        header {
            color: $error;
        }

        .progress-bar {
            background-color: $error !important;
        }
    }
}

.success.b-toast {
    ::v-deep .toast {
        border-left: 6px solid $success;

        header {
            color: $success;
        }

        .progress-bar {
            background-color: $success !important;
        }

    }
}

.info.b-toast {
    ::v-deep .toast {
        border-left: 6px solid $info;

        header {
            color: $info;
        }

        .progress-bar {
            background-color: $info !important;
        }
    }
}

.info.b-toast, .success.b-toast, .error.b-toast {
    ::v-deep .toast {
        header {
            font-size: 1rem;
            background-color: #fff;
            border: none;

            .close {
                font-size: 1.5rem;
                margin-bottom: 0;
                opacity: 1;
            }
        }
        .toast-body {
            color: #000;
        }
    }
}
</style>
