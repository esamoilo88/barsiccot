<template>
    <div class="flash-messages-container">
        <Message v-for="(msg, index) in flashMessagesComputed" :text="msg.text" :type="msg.type" :key="msg.text + index"/>
    </div>
</template>

<script>
import Message from './Message';

export default {
    name: 'flash-messages',
    components: {
        Message
    },
    props: {
        messages: {
            type: String,
            required: false
        }
    },
    data() {
        return {
            flashMessages: []
        }
    },
    computed: {
        flashMessagesComputed() {
            return this.flashMessages;
        }
    },
    mounted() {
        if (this.messages !== undefined) {
            this.flashMessages = [...JSON.parse(this.messages)];
        }
    },
    methods: {
        show({text, type}) {
            this.flashMessages.push({text, type});
        },
        showAll(messages) {
            this.flashMessages = [...this.flashMessages, ...messages];
        },
        showMessagesFromAjax(messages, type) {
            if (type === undefined) {
                this.flashMessages = [...this.flashMessages, ...messages];
            } else {
                let flashMessages = messages.map(msg => {
                    return {text: msg, type: type};
                });
                this.flashMessages = [...this.flashMessages, ...flashMessages];
            }
        }
    }
}
</script>

<style scoped>
    .flash-messages-container {
        position: fixed;
        display: flex;
        flex-direction: column;
        top: 0;
        right: 50%;
        left: 50%;
        transform: translateX(-50%);
        width: 650px;
        padding-top: 20px;
        z-index: 2000;
    }
</style>
