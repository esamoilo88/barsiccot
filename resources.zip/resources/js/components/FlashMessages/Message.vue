<template>
    <b-alert
        class="flash-message"
        :show="dismissCountDown"
        :variant="type"
        @dismissed="dismissCountDown=0"
        @dismiss-count-down="countDownChanged"
        dismissible
    >
        <div class="message-content-wrapper">
            <svg v-if="type === 'success'" class="message-content-icon success">
                <use xlink:href="/img/icons/check-circle.svg#check-circle-icon"></use>
            </svg>
            <svg v-else-if="type === 'error'" class="message-content-icon error">
                <use xlink:href="/img/icons/alert-circle.svg#alert-circle-icon"></use>
            </svg>
            <svg v-else-if="type === 'notice'" class="message-content-icon notice">
                <use xlink:href="/img/icons/alert-circle.svg#alert-circle-icon"></use>
            </svg>
            <p class="message-content-text"> {{ text }} </p>
        </div>
        <b-progress
            :variant="type === 'error' ? 'danger' : type"
            :max="dismissSecs"
            :value="dismissCountDown"
            height="4px"
        ></b-progress>
    </b-alert>
</template>

<script>
import {BAlert, BProgress} from 'bootstrap-vue';

export default {
    name: 'message',
    components: {
        BAlert, BProgress
    },
    props: {
        text: {
            type: String,
            required: true
        },
        type: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            dismissSecs: 15,
            dismissCountDown: 0
        }
    },
    mounted() {
        this.dismissCountDown = this.dismissSecs;
    },
    methods: {
        countDownChanged(dismissCountDown) {
            this.dismissCountDown = dismissCountDown;
        }
    },
}
</script>

<style lang="scss" scoped>
    @import "resources/sass/variables.scss";

    .message-content-wrapper {
        display: flex;
        align-items: center;

        .message-content-icon {
            min-width: 40px;
            min-height: 40px;
            max-width: 40px;
            max-height: 40px;
            margin: 0 0.8em 0.3em 0;
        }

        .message-content-icon.success {
            fill: $success;
        }

        .message-content-icon.error {
            fill: $error;
        }

        .message-content-icon.notice {
            fill: $notice;
        }

        .message-content-text {
            flex-grow: 1;
            margin: 0.3em;
        }
    }

    .flash-message {
        min-height: 60px;
        font-size: 1.5rem;
        color: $secondary;
        background-color: $darkgrey;
        border: none;
    }

    .flash-message ::v-deep button.close:hover {
        color: $secondary;
    }
</style>
