<template>
    <div class="toasts-component" v-if="flashMessages.length > 0">
        <div class="toasts-container">
            <Toast
                v-for="msg in flashMessages"
                :text="msg.text"
                :type="msg.type"
                :key="msg.hash"
                :hash="msg.hash"
                @hidden="removeMessage"
            />
        </div>
        <div v-if="flashMessages.length > 2" class="d-flex clear-btn-wrapper mt-2">
            <button @click="clearAll" v-if="flashMessages.length > 2" class="btn btn-link mx-auto clear-all-messages p-0">
                Meldungen löschen
            </button>
        </div>
    </div>
</template>

<script>
import {BToaster} from 'bootstrap-vue';
import Toast from './Toast';
import {generateHash} from "@helpers/ValueProcessing/ScalarProcessing";
import dayjs from "dayjs";

export default {
    name: "toaster",
    components: {BToaster, Toast},
    props: {
        messages: {
            type: String,
            required: false
        }
    },
    data() {
        return {
            flashMessages: []
        }
    },
    mounted() {
        if (this.messages !== undefined) {
            this.showAll(JSON.parse(this.messages));
        }
    },
    methods: {
        show({text, type}) {
            let len = this.flashMessages.length; // len is basically the index for the next pushed element
            this.flashMessages.unshift({text, type, hash: generateHash(text + dayjs().unix(), len)});
        },
        showAll(messages) {
            messages.map(msg => this.show(msg));
        },
        showMessagesFromAjax(messages, type) {
            if (type === undefined) {
                this.showAll(messages);
            } else {
                let flashMessages = messages.map(msg => {
                    return {text: msg, type: type};
                });
                this.showAll(flashMessages);
            }
        },
        clearAll() {
            this.flashMessages.splice(0);
        },
        removeMessage(hash) {
            let index = this.flashMessages.map(msg => msg.hash).indexOf(hash);
            index !== -1 && this.flashMessages.splice(index, 1);
        }
    }
}
</script>

<style scoped>
.toasts-component {
    position: fixed;
    z-index: 9999;
    width: 350px;
    right: 40%;
    top: 20px;
    max-height: 415px;
    overflow: hidden;
}

.toasts-container {
    max-height: 330px;
    padding: 7px;
    overflow-y: auto;
}

::-webkit-scrollbar {
    width: 4px;
}

/* Track */
::-webkit-scrollbar-track {
    border-radius: 10px;
}

/* Handle */
::-webkit-scrollbar-thumb {
    background: #8a8a8a;
    border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
    background: #696969;
}

.clear-all-messages:focus {
    box-shadow: none;
}

.clear-all-messages {
    height: initial;
}

.clear-btn-wrapper {
    height: 24px;
}
</style>
