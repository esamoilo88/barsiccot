<template>
    <div class="form-radio__wrapper">
        <b-form-group :label="label" v-slot="{ ariaDescribedby }">
            <b-form-radio-group
                class="form-radio__input w-100"
                :id="id"
                :checked="selected"
                @input="onInput"
                @change="onChange"
                :aria-describedby="ariaDescribedby"
                :button-variant="buttonVariant"
                :disabled="disabled"
                :buttons="buttons"
                :stacked="stacked"
            >
                <b-form-radio
                    v-for="opt in options"
                    :id="`${opt.value}`"
                    :key="opt.value"
                    :value="opt.value"
                    :name="opt.text"
                    :size="size"
                    :disabled="opt.disabled"
                >
                    <span v-if="opt.icon" :class="opt.icon"></span>
                    <span v-if="selected == opt.value" class="sr-only">Zurzeit aktiv</span>
                    <span v-html="opt.text"></span>
                </b-form-radio>
            </b-form-radio-group>
        </b-form-group>
    </div>
</template>

<script>
import {BFormGroup, BFormRadioGroup, BFormRadio} from 'bootstrap-vue';

export default {
    name: "FormRadio",
    components: {
        BFormGroup, BFormRadioGroup, BFormRadio
    },
    props: {
        value: null,
        options: {
            type: Array,
            required: true
        },
        id: {
            type: String,
            required: true
        },
        label: {
            type: String,
            required: false,
            default: ''
        },
        buttonVariant: {
            type: String,
            required: false,
            default: ''
        },
        size: {
            type: String,
            required: false,
            default: ''
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        },
        stacked: {
            type: Boolean,
            required: false,
            default: false
        },
        buttons: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            selected: this.value
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.selected = newVal;
        }
    },
    methods: {
        onInput(selected) {
            this.selected = selected;
            this.$emit('input', this.selected);
        },
        onChange(selected) {
            this.selected = selected;
            this.$emit('change', this.selected);
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
.primary-white {
    label.btn {
        background-color: #ffffff;
        border: 1px solid #d3d3d3;
    }
    label.btn:focus,
    label.btn.focus {
        box-shadow: 0 0 0 0.1rem rgb(226 0 116 / 25%) !important;
    }
    label.btn.active,
    label.btn:active {
        color: #ffffff;
        background-color: $primary;
    }
}
</style>
