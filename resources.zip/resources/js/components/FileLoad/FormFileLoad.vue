<template>
    <div :class="{
        'form-group-floating': true,
        'focused': focusClass,
        'upper-label': file || focusClass,
        'is-invalid': errorsNumber > 0,
        'large': size === 'large'
    }">
        <b-form-file
            v-model="file"
            ref="file"
            :placeholder="placeholder"
            drop-placeholder="Drop file here..."
            :browse-text="browseText"
            :accept="accept"
            @input="handleFilesUpload"
        ></b-form-file>
        <div class="mt-3" v-if="inputText">{{ inputText }}: {{ file ? file.name : '' }}</div>

        <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
    </div>
</template>

<script>
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";
import {BFormFile} from 'bootstrap-vue';

export default {
    name: "form-file",
    components: {
        BFormFile, FormInputErrors
    },
    mixins: [ErrorsMxn],
    props: {
        placeholder: {
            type: String,
            required: false
        },
        accept:{
            type: String,
            required: false
        },
        inputText:{
            type: String,
            required: false
        },
        type: {
            type: String,
            required: false,
            default: 'text'
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        browseText: {
            type: String,
            required: false,
        }
    },
    data() {
        return {
            state: null,
            focusClass: false,
            file: null,
            formData: new FormData(),
            filesInfo: null
        }
    },
    computed: {
        errorsNumber() {
            let anyErrors = [];
            if (this.errorConditions !== undefined) {
                anyErrors = this.errorConditions.filter((error) => {
                    return error.condition;
                });
            }
            if (anyErrors.length > 0) {
                this.state = false;
            } else {
                this.state = null;
            }
            return anyErrors.length;
        }
    },
    methods: {
        handleInput() {
            this.$emit('input', this.file);
        },
        handleBlur() {
            if (this.file === undefined || this.file === '' || this.file === null) {
                this.focusClass = false;
            }
        },
        handleFilesUpload() {
            let uploadedFiles = this.$refs.file.files;

            let config = {
                header: {
                    'Content-Type': 'multipart/form-data'
                }
            }
            this.formData.append('file_0', uploadedFiles[0]);
            if(uploadedFiles[0]) {
                this.filesInfo = {
                    'formData': this.formData,
                    'config': config,
                    'fileNames': uploadedFiles[0].name,
                    'type': uploadedFiles[0].type,
                    'date': uploadedFiles[0].lastModifiedDate
                };
                this.$emit("uploadFile", this.filesInfo);
                this.$emit('input', this.file);
            }
        },
        clearFiles() {
            this.$refs.file.reset();
            this.formData = new FormData();
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.form-wrapper {
    max-width: 30%;
    min-width: 300px;
    padding: 50px 30px 50px 30px;
    margin: 50px auto;
    background-color: #ffffff;
    border-radius: 5px;
    box-shadow: 0 15px 35px rgba(50, 50, 93, .1), 0 5px 15px rgba(0, 0, 0, .07);
}

.form-group-floating {
    position: relative;
    padding: 2px;
    border-radius: 0.25rem;

    &.is-invalid {
        .custom-file-input {
            border: 1px solid $error;
        }
    }

    .invalid-feedback {
        color: $error;
    }
}

.form-label {
    position: absolute;
    cursor: text;
    left: 15px;
    top: 15px;
    color: #888;
    z-index: 10;
    transition: transform 150ms ease-out, font-size 150ms ease-out;
}

.upper-label .form-label {
    transform: translateY(-55%);
    font-size: .75em;
}


.form-group-floating.large {
    .form-label {
        font-size: 26px;
    }

    &.focused .form-label {
        font-size: 1.1rem;
    }

    .invalid-feedback {
        font-size: 100%;
    }

    .is-valid {
        border: none;
    }
}

</style>
