<template>
    <div>
        <div class="boxFile p-3" v-if="isButtonTyp">
            <p class="font-weight-bold grey"> {{ title }}</p>
            <div class="file btn btn-secondary">
                <form name="myForm" id="myForm">
                    {{ browseText }}
                    <input type="file" id="files" ref="files" multiple v-on:change="handleFilesUpload()"/>
                </form>
            </div>
            <form-tag
                @removeTag="removeTag"
                :set-clear="false"
                :taglist="selectedFileList"/>
        </div>
        <div v-else>
            <div class="d-flex">
                <div class="mt-2 mr-5">
                    Dateianhänge
                </div>
                <b-form-file
                    v-model="file"
                    ref="files"
                    id="files"
                    :accept="accept"
                    class="w-50"
                    :placeholder="placeholder"
                    drop-placeholder="Drop file here..."
                    :browse-text="browseText"
                    @input="handleFilesUpload"
                    multiple
                ></b-form-file>
            </div>
            <form-tag
                @removeTag="removeTag"
                :taglist="selectedFileList"
                :icon-remove="iconRemove"/>
        </div>
    </div>
</template>

<script>
import FormTag from "./FormTag/FormTag";
import {BFormFile} from 'bootstrap-vue';

export default {
    name: "multiple-file",
    components: {
        BFormFile,
        FormTag
    },
    props: {
        browseText: {
            type: String,
            required: true,
        },
        title: {
            type: String,
            required: false,
        },
        inputId: {
            type: String,
            required: true
        },
        isButtonTyp: {
            type: Boolean,
            required: false,
            default: true
        },
        iconRemove: {
            type: String,
            required: false,
            default: 'icon-action-close-default'
        },
        placeholder: {
            type: String,
            required: false
        },
        accept: {
            type: String,
            required: false
        },
        labelText: {
            type: String,
            required: false
        },
    },
    data() {
        return {
            formData: new FormData(),
            selectedFileList: [],
            filesInfo: {},
            file: null
        }
    },
    methods: {
        removeTag(file,setClear) {
            const tags = this.selectedFileList;
            const tagNdx = tags.indexOf(file);
            if (tagNdx < 0) return;

            tags.splice(tagNdx, 1);
            this.selectedFileList = tags;
            this.formData.delete('file_' + tagNdx);
            if(setClear) this.clearFiles();
        },
        handleFilesUpload() {
            let uploadedFiles = this.$refs.files.files;
            let config = {
                header: {
                    'Content-Type': 'multipart/form-data'
                }
            }
            if (uploadedFiles.length > 0 &&!this.selectedFileList.includes(uploadedFiles[0].name)) {
                this.formData.append('file_' + this.selectedFileList.length, uploadedFiles[0]);
                this.selectedFileList.push(uploadedFiles[0].name);
            }
            this.filesInfo = {
                'formData': this.formData,
                'config': config,
                'fileNames': this.selectedFileList
            };
            this.$emit("uploadFiles", this.filesInfo);
            document.getElementById('files').value = null;
        },
        clearFiles() {
            this.$refs.files.reset();
            this.formData = new FormData();
        },
        clearTags() {
            this.selectedFileList = [];
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

div {
    position: relative;
    overflow: hidden;
}

.grey {
    color: $grey;
}

input {
    position: absolute;
    font-size: 50px;
    opacity: 0;
    right: 0;
    top: 0;
}

.boxFile {
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    width: 450px;
}

.file.btn.btn-secondary input {
    cursor: pointer;
}

</style>
