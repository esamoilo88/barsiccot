<template>
    <ul class="tags pl-0">
        <li class="tag"
            v-for="(tag,index) in taglist"
            :key="`${tag}${index}`"
        >
            <div>
                <span>{{ tag }}</span>
                <button aria-keyshortcuts="Delete"
                        type="button"
                        @click="removeTag(tag, setClear)"
                        aria-label="Remove tag"
                        class="close b-form-tag-remove">
                    <span :class="iconRemove + ' small'"></span>
                </button>
            </div>
        </li>
    </ul>
</template>

<script>
export default {
    props: {
        taglist: {
            type: Array,
            required: true
        },
        setClear: {
            type: Boolean,
            required: false,
            default: true
        },
        iconRemove: {
            type: String,
            required: false,
            default: 'icon-action-close-default'
        }
    },
    methods: {
        removeTag(tag, setClear) {
            this.$emit('removeTag', tag, setClear)
        }
    }
}
</script>
<style lang="scss">
@import 'resources/sass/variables';

.tags {
    display: flex;
    margin-top: 20px;
    flex-wrap: wrap;
}

.tag {
    display: flex;
    margin-right: 10px;
    white-space: nowrap;
    padding: 6px 8px;
    border-radius: 0.3rem;
    background: $lightgrey;
    color: #000;
    margin-right: 8px;
    margin-bottom: 8px;
    font-size: 16px;

    span {
        padding-right: 15px;
    }
}

.remove {
    background: $lightgrey;
    border: none;
    cursor: pointer;
}

</style>

