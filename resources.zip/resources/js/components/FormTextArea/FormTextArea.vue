<template>
    <div :class="{
        'form-group-floating': true,
        'focused': focusClass,
        'upper-label': content || focusClass,
        'is-invalid': errorsNumber > 0,
        'large': size === 'large'
    }">

        <label @click="$refs.textarea.focus()"
               class="form-label"
               :id="inputId + '__label'"
               :for="inputId">
            {{ labelText }}
        </label>
        <b-form-textarea
            :name="name"
            :id="inputId"
            ref="textarea"
            v-model="content"
            @focus="focusClass=true"
            @input="handleInput"
            @change="val => $emit('change', val)"
            @blur="handleBlur"
            @keyup.enter.stop.prevent
            :rows="rows"
            class="form-control"
            :autocomplete="autocomplete"
            :disabled="disabled"
        ></b-form-textarea>

        <FormInputErrors v-if="errorsNumber > 0" :error-conditions="errorConditions" :errors-number="errorsNumber"/>
    </div>
</template>

<script>
import ErrorsMxn from "@comp/FormCommonUtils/ErrorsMxn";
import FormInputErrors from "@comp/FormCommonUtils/FormInputErrors";
import {BFormTextarea} from 'bootstrap-vue';

export default {
    name: "form-text-area",
    components: {
        BFormTextarea, FormInputErrors
    },
    mixins: [ErrorsMxn],
    props: {
        value: null,
        name: {
            type: String,
            required: true
        },
        rows: {
            type: String,
            required: false,
        },
        inputId: {
            type: String,
            required: true
        },
        labelText: {
            type: String,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false,
            default: () => []
        },
        size: {
            type: String,
            required: false,
            default: 'default'
        },
        autocomplete: {
            type: String,
            required: false,
            default: 'off'
        },
        prefilled: {
            type: String,
            required: false
        },
        errorsWithBg: {
            type: Boolean,
            required: false,
            default: false
        },
        disabled: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            focusClass: false,
            content: this.value
        }
    },
    watch: {
        value() {
            this.content = this.value;
        }
    },
    created() {
        if (this.prefilled !== undefined && this.prefilled !== null) {
            this.content = this.prefilled;
            this.$emit('textarea', this.content);
        }
    },
    methods: {
        handleInput() {
            this.$emit('handleTextArea', this.content);
            this.$emit('input', this.content);
        },
        handleBlur() {
            if (this.content === undefined || this.content === '' || this.content === null) {
                this.focusClass = false;
            }
        }
    }
}
</script>


<style lang="scss" scoped>
@import 'resources/sass/variables';

.one-error {
    padding-left: 0 !important;
    list-style: none;
}

.form-wrapper {
    max-width: 30%;
    min-width: 300px;
    padding: 50px 30px 50px 30px;
    margin: 50px auto;
    background-color: #ffffff;
    border-radius: 5px;
    box-shadow: 0 15px 35px rgba(50, 50, 93, .1), 0 5px 15px rgba(0, 0, 0, .07);
}

.form-group-floating {
    position: relative;
    padding: 2px;
    border-radius: 0.25rem;

    textarea.form-control {
        padding-top: 20px;
    }

    &.is-invalid {

        textarea.form-control {
            border: 1px solid $error;
        }

        .invalid-feedback {
            color: $error;
            padding-left: 20px;
            padding-top: 5px;
            margin-bottom: 0;
        }
    }
}

.errors-with-bg {
    background-color: $lighterror;
    border: 1px solid $darkerror;
}

.form-label {
    position: absolute;
    cursor: text;
    left: 15px;
    top: 15px;
    color: #888;
    z-index: 10;
    transition: transform 150ms ease-out, font-size 150ms ease-out;
}

.upper-label .form-label {
    transform: translateY(-55%);
    font-size: .75em;
}


.form-group-floating.large {
    .form-label {
        font-size: 26px;
    }

    .form-input {
        font-size: 26px;
    }

    &.focused .form-label {
        font-size: 1.1rem;
    }

    .invalid-feedback {
        font-size: 100%;
    }
}

</style>
