<template>
    <div class="headline">
        <div class="headline-card">
            <div class="item">
                <div class="name">SIN:</div>
                <div class="value">{{sin}}</div>
                <ButtonIcon
                    icon-class="icon-content-news-default"
                    :id="'project' + sin"
                    @click="go(sin)"
                    :title="'SIN ' + sin"
                    variant="link"
                />
            </div>
            <div class="item">
                <div class="name">Vorhaben:</div>
                <div class="value">{{projectName}}</div>
            </div>
            <div class="item">
                <div class="name">Kunde:</div>
                <div class="value">{{customer}}</div>
            </div>
        </div>
    </div>
</template>

<script>
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import TableSimple from "@comp/TableSimple/TableSimple";

export default {
    name: "Headline",
    components: {ButtonIcon},
    props: {
        customer: {
            type: String,
            required: true
        },
        projectName: {
            type: String,
            required: true
        },
        sin: {
            type: String,
            required: true
        }
    },
    methods: {
        go(sin) {
            window.location.href = `/projects/${sin}`;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

    .headline-card {
        display: flex;
        max-width: 90%;
    }
    .item {
        display: flex;
        font-size: 20px;
        align-items: flex-end;
        &:first-child {
            margin-right: 100px;
        }
        &:last-child {
            margin-left: auto;
        }
    }
    .name {
        margin-right: 10px;
    }
    .value {
        font-weight: bold;
        margin-right: 5px;
    }
    .headline {
        position: relative;
        margin-top: 10px;
        margin-bottom: 40px;
    }
    ::v-deep .btn-icon__icon {
        font-size: 23px;
        color: $link;
    }
    ::v-deep .btn-icon {
        padding: 2px 2px;
    }
</style>