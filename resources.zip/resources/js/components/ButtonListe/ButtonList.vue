<template>
    <div class="button_list_box m-3">
        <b-button class="btn-more"
                  href="#"
                  v-for="item in content"
                  :key="item.name"
                  @click="$emit('click', { key: item.name, simpleId })">
            <span :class="item.icon"></span>
            {{ item.name }}
        </b-button>
    </div>
</template>

<script>
import {BButton} from 'bootstrap-vue';

export default {
    name: "button-list",
    components: {
        BButton
    },
    props: {
        content: {
            type: Array,
            required: true
        },
        simpleId: {
            type: String,
            required: false
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.btn-more__icon {
    vertical-align: middle;
    font-size: 25px;
    color: $iconscolor;
}

.btn-more {
    background-color: transparent;
    padding: 10px;
    border: none;
}

.button_list_box {
    border: 1px solid lightgrey;
    border-radius: 4px;
    padding: 10px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
}
</style>




