import 'bootstrap';
import FlashMessages from './components/FlashMessages/main';
import PagePreloader from "./components/PagePreloader/main";
import navbarFocus from "./utils/navbarFocus";
import initSidebar from "./utils/initSidebar";
import {fetchUserPreferences} from "@helpers/SimpleBussiness/UserPreferences/userPreferences";

window.flash = FlashMessages;
window.preloader = PagePreloader;

navbarFocus();
initSidebar();
fetchUserPreferences();
