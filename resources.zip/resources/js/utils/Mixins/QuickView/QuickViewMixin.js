export default {
    data() {
        return {
            currentOpen: null,
            rowDetailsActive: 'none',
            openedRows: []
        }
    },
    methods: {
        /**
         * Toggle the opened state of quick view. Also it closes the quick view if it
         * was open and then clicked on the another row's quickview toggler
         * @param mode - the name of specific expanded quickview inside one row
         * @param row
         * @param uniqueKey - the name of the unique key of the row data (smth like "id")
         */
        toggleRow(mode = '', row, uniqueKey) {
            if (this.currentOpen === null) {
                this.currentOpen = row;
                row.toggleDetails();
                this.setDropDetailsAttributes(row.item,uniqueKey);
            } else if (this.currentOpen.item[uniqueKey] === row.item[uniqueKey]) {
                if (mode === this.rowDetailsActive) {
                    row.toggleDetails();
                    this.currentOpen = null;
                }
            } else {
                this.currentOpen.toggleDetails();
                row.toggleDetails();
                this.currentOpen = row;
            }
            this.rowDetailsActive = mode;
        },

        /**
         * Toggle row details regardless of any other opened row details
         * @param item
         * @param uniqueKey
         */
        toggleRowAnyway(item, uniqueKey) {
            if (this.openedRows.includes(item[uniqueKey])) {
                this.openedRows.splice(this.openedRows.indexOf(item[uniqueKey]), 1);
                item._showDetails = false;
            } else {
                this.openedRows.push(item[uniqueKey]);
                item._showDetails = true;
            }
            this.setDropDetailsAttributes(item,uniqueKey);
        },

        /**
         * Insert "_showDetails" variable into every item
         * https://bootstrap-vue.org/docs/components/table#row-details-support
         * @param items
         * @param uniqueKey
         * @param callback
         * @returns {*}
         */
        insertShowDetailsField(items, uniqueKey, callback = null) {
            return items.map(item => {
                item = callback ? callback(item) : item;
                item._showDetails = this.openedRows.includes(item[uniqueKey]);
                return item;
            });
        },
        toggleAllRows(items, uniqueKey, shouldExtend) {
            this.openedRows = [];
            if (shouldExtend) {
                for (let key in items) {
                    this.toggleRowAnyway(items[key], uniqueKey)
                }
            } else {
                for (let key in items) {
                    items[key]._showDetails = false;
                }
            }
        },
        setDropDetailsAttributes(item,uniqueKey){
            setTimeout(function () {
                const tableHasDetails = document.getElementsByClassName('b-table-has-details')[0];
                const detailsButton = document.getElementsByClassName('details_class')[0];
                detailsButton.setAttribute('aria-details', '__details_' + item[uniqueKey]);
                if (tableHasDetails.hasAttribute('aria-details')) {
                    tableHasDetails.removeAttribute('aria-details');
                    tableHasDetails.removeAttribute('aria-owns');
                }
            }, 10);
        }
    }
}
