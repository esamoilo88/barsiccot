export default {
    data() {
        return {
            showValidationErrors: false
        }
    },
    methods: {
        validate() {
            this.$v.$touch();

            this.showValidationErrors = this.$v.$invalid;

            return !this.$v.$invalid;
        },
        isInvalid(field, rule) {
            if (!this.$v.form[field]) return;

            if (rule) {
                return this.showValidationErrors && this.$v.form[field].$dirty && !this.$v.form[field][rule];
            }

            return this.showValidationErrors && this.$v.form[field].$dirty && this.$v.form[field].$invalid;
        },
    }
}
