import {getQueryParam, replaceUrlParam} from "@helpers/URL/UrlHelper";

export default {
    data() {
        return {
            tabsNames: [],
            tabIndex: 0
        }
    },
    mounted() {
        this.$nextTick(() => {
            let tabIndex = 0;
            let tabName = this.getQueryParamProxy('tab');
            if (tabName) {
                tabName = this.reformatTabname(tabName, true);
                this.tabsNames.map((name, index) => {
                    if (name.toLowerCase() == tabName) {
                        tabIndex = index;
                    }
                });
            }
            this.tabIndex = tabIndex;
            this.onTabSwitch(this.tabIndex);
        });
    },
    methods: {
        onTabSwitch(tab) {
            if (this.tabsNames[tab] !== undefined) {
                this.replaceUrlParamProxy('tab', this.reformatTabname(this.tabsNames[tab]));
            }
            if (!this.visitedTabs.includes(tab)) {
                this.visitedTabs.push(tab);
            }
        },
        getQueryParamProxy(key) {
            return getQueryParam(key);
        },
        replaceUrlParamProxy(param, value) {
            replaceUrlParam(param, value);
        },
        reformatTabname(value, fromUrl = false) {
            if (fromUrl) {
                return value.replaceAll('_', ' ').replaceAll('~', '&').toLowerCase();
            } else {
                return value.replaceAll(' ', '_').replaceAll('&', '~').toLowerCase();
            }
        }
    }
}
