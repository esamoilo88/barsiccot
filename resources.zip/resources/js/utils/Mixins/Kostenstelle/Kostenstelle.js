import {createOptions} from "@helpers/Form/InputsHelper";

export default {
    data() {
        return {
            kostenstelleOptions: []
        }
    },
    methods: {
        /**
         * Fetch the list of kostenstelle and create
         * options array out of it
         * @returns {Promise<void>}
         */
        async fetchKostenstelleData() {
            try {
                let res = await this.$axios.post('/offers/costs/kostenstelle', {
                    fields: ['kostenstelleId', 'gruppe', 'kostenstelle', 'beschreibung']
                });
                this.kostenstelleOptions.splice(0);
                this.kostenstelleOptions.push(...createOptions(
                    res.data,
                    (k) => k.kostenstelleId,
                    (k) => k.kostenstelle + ' - ' + k.beschreibung,
                    'gruppe',
                    true
                ));
            } catch (err) {
                this.kostenstelleOptions.splice(0);
                console.error("Couldn't fetch kostenstelle.", err);
            }
        },
    }
}
