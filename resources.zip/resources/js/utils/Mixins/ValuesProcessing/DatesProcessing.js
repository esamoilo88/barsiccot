import dayjs from 'res/js/utils/day';

export default {
    methods: {
        /**
         * Format the date
         * @param date
         * @param format
         * @param defVal
         */
        formatDate(date, format, defVal = '-') {
            if (date === undefined || date == null ) {
                return defVal;
            } else {
                if(typeof date === 'object'){
                    return dayjs(date.date).format(format)|| '';
                }
                return dayjs(date).format(format)|| '';
            }
        },
        /**
         * Concat month and year.
         * If month < 10, put a leading zero to it
         * @param year
         * @param month
         * @param delimiter
         */
        monthYearConcat(month, year, delimiter = '.') {
            let monthWithZero = parseInt(month) < 10 ? '0' + String(month) : String(month);
            return monthWithZero + delimiter + String(year);
        },
        isPastDate(dateStr) {
            const date = dayjs(dateStr);
            const now = dayjs();

            return date.diff(now) <=0;
        }
    }
}
