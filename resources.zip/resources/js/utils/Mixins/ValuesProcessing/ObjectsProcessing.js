export default {
    data() {
        return {
            obj: {}
        }
    },
    methods: {
        /**
         * Creates the copy of object
         * @param obj
         * @param name
         */
        persistObjectState(obj, name) {
            if (name === undefined) {
                this.obj = Object.assign({}, obj);
            } else {
                this.obj[name] = Object.assign({}, obj);
            }
        },

        /**
         * Returns an object which was persisted before.
         * This is useful when you need to get the initial state of object which
         * was overwritten or got dirty somehow
         * @param name
         */
        resetObject(name) {
            if (name === undefined) {
                return this.obj;
            } else {
                return this.obj[name];
            }
        },

        /**
         * Returns an object with removed any "null" or "empty string" fields
         * @param obj
         */
        removeEmptyFields(obj) {
            let objCopy = Object.assign({}, obj);
            for (const [key, value] of Object.entries(objCopy)) {
                if (value === null || value === '') {
                    delete objCopy[key];
                }
            }
            return objCopy;
        },

        /**
         * Helps to safely get the value of nested keys of object.
         * It is helpful when we are not sure that one of the keys is presented or not.
         * e.g. obj.field1.fields2 will raise an error if field1 is undefined or null
         * CAUTION!!! Since this function works recursively, be careful
         * with using it in components which are repeated many times at the page
         * @param obj
         * @param keys - array or string of recursively nested fields
         * @param def - default value
         * @param notEmpty - if you want to get non null value set it to true
         * @return returns "def" if one of the keys is not presented, otherwise returns value
         */
        getValue(obj, keys, def = null, notEmpty = false) {
            if (obj === null || obj === undefined) {
                return def
            }

            if (typeof keys === 'string') {
                keys = keys.split('.');
            }
            let key = keys.shift();
            let value = obj[key];

            if (keys.length === 0) {
                return notEmpty && value === null ? def : value;
            } else if (value !== undefined && value !== null) {
                return this.getValue(value, keys, def, notEmpty);
            } else {
                return def;
            }
        },

        /**
         * Create a deep copy of an object
         * @param obj
         * @returns {*[]|*}
         */
        deepCopy(obj) {
            let outObject, value, key;

            if (typeof obj !== "object" || obj === null) {
                return obj; // Return the value if obj is not an object
            }

            // Create an array or object to hold the values
            outObject = Array.isArray(obj) ? [] : {};

            for (key in obj) {
                value = obj[key];
                // Recursively (deep) copy for nested objects, including arrays
                outObject[key] = this.deepCopy(value);
            }

            return outObject;
        },

        /**
         * @param obj
         * @returns {boolean}
         */
        isEmpty(obj) {
            if (typeof obj !== 'object' || obj === null) {
                return true;
            }
            return Object.keys(obj).length === 0;
        }
    }
}
