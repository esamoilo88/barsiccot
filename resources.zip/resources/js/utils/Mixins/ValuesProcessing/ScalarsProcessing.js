export default {
    methods: {
        /**
         * Returns "def" if "value" is undefined or null, otherwise returns "value"
         * @param value
         * @param def - default value
         */
        defVal(value, def) {
            if (value === undefined || value === null) {
                return def;
            } else {
                return value;
            }
        },
        /**
         * Checks if the value is 'undefined', 'null' or ''
         * @param value
         * @returns {boolean}
         */
        isEmpty(value) {
            return (value === undefined || value === null || value === '');
        }
    }
}
