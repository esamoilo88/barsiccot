/**
 * If we have one module with 2 or more submodules and they load content
 * separately, we need one preloader which considers the state of both separate
 * boolean variables. This mixin initialize those variables and keeps
 * the main component more clean and maintainable.
 */
export default {
    data() {
        return {
            loadersMxn: {}
        }
    },
    computed: {

    },
    methods: {
        /**
         * Initialize groups of preloader
         * @param groups - array of groups, e.g.:
         * ['items', 'configuration']
         */
        initLoaderGroupsMxn(groups) {
            groups.map(group => {
                let modules = group.split('.');
                let currentObj = this.loadersMxn;
                modules.map((m, i) => {
                    let initValue = i === modules.length - 1 ? [] : {};
                    currentObj[m] === undefined ? this.$set(currentObj, m, initValue) : '';
                    currentObj = currentObj[m];
                });
            });
        },
        /**
         * Show a loader
         * @param group - which group has loading module
         * @param module - specific module inside group
         * which affects the common group loader
         */
        showLoader(group, module) {
            try {
                let objects = group.split('.');
                let currentObj = this.loadersMxn;
                objects.map(m => currentObj = currentObj[m]);
                currentObj.push(module);
            } catch (err) {
                console.error(err);
            }
        },
        /**
         * Hide a loader
         * @param group - which group has loading module
         * @param module - specific module inside group
         * which affects the common group loader
         */
        hideLoader(group, module) {
            try {
                let objects = group.split('.');
                let currentObj = this.loadersMxn;
                objects.map(m => currentObj = currentObj[m]);
                currentObj.splice(currentObj.indexOf(module), 1);
            } catch (err) {
                console.error(err);
            }
        },
        /**
         * Whether or not a group has at least one loading module
         * @param group
         * @returns {boolean}
         */
        isLoadingMxn(group) {
            let isAnyLoading = false;
            try {
                let modules = group.split('.');
                let currentObj = this.loadersMxn;
                modules.map(m => currentObj = currentObj[m]);
                currentObj.length > 0 ? isAnyLoading = true : '';
            } catch (err) {
                console.error(err);
            }

            return isAnyLoading;
        }
    }
}
