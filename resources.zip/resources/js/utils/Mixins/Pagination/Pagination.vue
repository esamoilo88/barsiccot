<script>
export default {
    data() {
        return {
            currentPage: 1,
            totalRows: 0,
            perPage: 20,
            entriesSingular: 'tables.entry',
            entriesPlural: 'tables.entries',
            sortBy: 'simpleId',
            sortDesc: true
        }
    },
    computed: {
        paginationEntriesText() {
            if (this.totalRows === 1) {
                return this.$t.__(this.entriesSingular);
            } else {
                return this.$t.__(this.entriesPlural, {entries: this.totalRows});
            }
        }
    },
    methods: {
        initPaginationMxn(
            currentPage = 1,
            totalRows = 0,
            perPage = 20,
            sortBy = "",
            sortDesc = true,
            entriesSingular = 'tables.entry',
            entriesPlural = 'tables.entries',
        )
        {
            this.currentPage = currentPage;
            this.totalRows = totalRows;
            this.perPage = perPage;
            this.entriesSingular = entriesSingular;
            this.entriesPlural = entriesPlural;
            this.sortBy = sortBy;
            this.sortDesc = sortDesc;
        }
    }
}
</script>

<style lang="scss">
.pagination-wrapper {
    display: flex;
    align-items: center;
    position: relative;
    justify-content: space-between;

    .pagination.b-pagination {
        margin: 0 auto;
    }

    .total-rows-text {
        margin-left: 20px;
    }
}
</style>
