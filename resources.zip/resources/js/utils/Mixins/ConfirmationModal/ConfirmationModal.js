export default {
    methods: {
        showConfirmationModal(props) {
            const defaultProps = {
                title: '',
                message: '',
                okVariant: 'danger',
                cancelVariant: 'secondary',
                okTitle: 'Ok',
                cancelTitle: 'Abbrechen',
                size: 'md',
                footerClass: 'confirmation-modal-footer flex-row-reverse justify-content-start',
            };

            props = {...defaultProps, ...props};

            this.$root.$on('bv::modal::shown', (bvEvent) => {
                const modalTitle = bvEvent.vueTarget.$refs.header.querySelector('.modal-title');

                modalTitle.setAttribute('tabindex', '0');
                modalTitle.focus();
            })

            return this.$bvModal.msgBoxConfirm(props.message, {
                title: props.title,
                okTitle: props.okTitle,
                cancelTitle: props.cancelTitle,
                okVariant: `${props.okVariant} confirmation-modal-ok-btn`,
                cancelVariant: `${props.cancelVariant} confirmation-modal-cancel-btn`,
                footerClass: props.footerClass,
                titleTag: 'h2',
                size: props.size,
            });
        }
    }
}
