export default {
    data() {
        return {
            sapBestellnummerErrors: false,
            sapBestellnummerErrorsText: '',
            icpKontPspKstErrors: false,
            icpKontPspKstErrorsText: '',
        }
    },
    computed: {
        bestellnummerErrorConditions() {
            return [
                {
                    name: 'sapAuftragsNr-valid',
                    condition: this.sapBestellnummerErrors,
                    text: this.sapBestellnummerErrorsText
                }
            ]
        },
        icpKontPspKstErrorConditions() {
            return [
                {
                    name: 'icpKontPspKst-valid',
                    condition: this.icpKontPspKstErrors,
                    text: this.icpKontPspKstErrorsText
                }
            ]
        }
    },
    methods: {
        setBestellnummerErrors(messages) {
            let text = messages.join(' oder ');
            this.sapBestellnummerErrors = true;
            this.sapBestellnummerErrorsText = text;
        },
        resetBestellnummerErrors() {
            this.sapBestellnummerErrors = false;
            this.sapBestellnummerErrorsText = '';
        },
        setIcpKontPspKstErrors(messages) {
            let text = messages.join(' oder ');
            this.icpKontPspKstErrors = true;
            this.icpKontPspKstErrorsText = text;
        },
        resetIcpKontPspKstErrors() {
            this.icpKontPspKstErrors = false;
            this.icpKontPspKstErrorsText = '';
        }
    }
}
