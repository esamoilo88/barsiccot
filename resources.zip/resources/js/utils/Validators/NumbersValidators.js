/**
 * @param value
 * @param afterComma
 * @param beforeComma
 * @returns {boolean}
 */
export const isValidFloat = (value, afterComma = 2, beforeComma = -1) => {
    let firstRule = beforeComma === -1 ? `^-?\\d{1,${beforeComma}},\\d{1,${afterComma}}$` : `^-?\\d+,\\d{1,${afterComma}}$`;
    let secondRule = beforeComma === -1 ? `^-?\\d+$` : `^-?\\d{1,${beforeComma}}$`;
    firstRule = new RegExp(firstRule);
    secondRule = new RegExp(secondRule);
    return String(value).match(firstRule) !== null || String(value).match(secondRule) !== null;
}
