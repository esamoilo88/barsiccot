import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export const validatePreference = (value, valids) => {
    if (!valids) {
        return true;
    }
    for (let valid of valids) {
        if (String(valid).indexOf('regex') !== -1) {
            return regexRule(value, valid);
        } else {
            // we return only if value == valid otherwise we keep looping through
            if (value == valid) {
                return true;
            }
        }
    }

    return false;
}

/**
 * @param value
 * @param rule
 * @returns {boolean}
 */
export const regexRule = (value, rule) => {
    let matches = rule.match(/regex:(?<regex>.+)/);
    let regex = new RegExp(matches.groups.regex);
    let result = String(value).match(regex);
    return !isEmpty(result);
}
