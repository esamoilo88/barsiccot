import dayjs from 'res/js/utils/day';

/**
 * @param value
 * @returns {boolean}
 */
export const isDate = (value) => {
    return dayjs(value, 'DD.MM.YYYY').format('DD.MM.YYYY') === value || value === '' || value === null || value === undefined;
}

export const isDatetime = (value) => {
    return dayjs(value, 'DD.MM.YYYY HH:mm').format('DD.MM.YYYY HH:mm') === value;
}

export const moreThanToday = value => {
    const selected = dayjs(value,'DD.MM.YYYY');
    const tomorrow  = dayjs().endOf('day');

    return selected > tomorrow;
}
