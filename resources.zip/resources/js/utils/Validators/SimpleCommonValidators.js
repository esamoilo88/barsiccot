export const aufwandHourValidator = (value) => {
    return String(value).match(/^[0-9]{2,3}$/) !== null;
}
export const aufwandMinuteValidator = (value) => {
    return String(value).match(/^[0-5][0-9]$/) !== null;
}
export const aufwandSecondValidator = (value) => {
    return String(value).match(/^[0-5][0-9]$/) !== null;
}
export const aufwandValidator = (value) => {
    return String(value).match(/^[0-9]{2,3}:[0-5][0-9]:[0-5][0-9]$/) !== null;
}
export const isPspElementValid = (value) => {
    return String(value).match(/^Z-D4J-\d{9}-\d{2}$/) !== null;
}
