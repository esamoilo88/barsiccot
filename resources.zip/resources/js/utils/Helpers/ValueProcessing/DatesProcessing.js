/**
 * Concat month and year.
 * If month < 10, put a leading zero to it
 * @param year
 * @param month
 * @param delimiter
 */
export const monthYearConcat = (month, year, delimiter = '.') => {
    let monthWithZero = parseInt(month) < 10 ? '0' + String(month) : String(month);
    return monthWithZero + delimiter + String(year);
}
