/**
 * Fill the necessary amount of leading zeros before 'val'
 * @param val
 * @param maxLength
 * @param prefix
 * @returns {string}
 */
export const leadingZeros = (val, maxLength, prefix = null) => {
    if (val === undefined || val === null) {
        return '0';
    }

    let valStr = String(val);

    if (valStr.length < maxLength) {
        valStr = '0'.repeat(maxLength - valStr.length) + valStr;

        if (prefix) {
            valStr = prefix + valStr;
        }
    }

    return valStr;
}
