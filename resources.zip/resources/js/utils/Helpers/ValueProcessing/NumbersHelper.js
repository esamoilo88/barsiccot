/**
 * Fill the necessary amount of leading zeros before 'val'
 * @param val
 * @param maxLength
 * @returns {string}
 */
export const leadingZeros = (val, maxLength) => {
    if (val === undefined || val === null) {
        return '0';
    }

    let valStr = String(val);
    if (valStr.length < maxLength) {
        return '0'.repeat(maxLength - valStr.length) + valStr;
    }

    return valStr;
}
