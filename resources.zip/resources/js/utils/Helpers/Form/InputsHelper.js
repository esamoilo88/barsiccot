/**
 * Create the options array which is suitable for FormSelect
 * @param arr
 * @param idField
 * @param textField
 * @param groupField
 * @param withEmpty
 * @param htmlField
 * @returns {[]}
 */
export const createOptions = (arr, idField, textField, groupField = null, withEmpty = false, htmlField = null) => {
    let result = [];

    try {
        if (groupField === null) {
            arr.map(item => {
                let option = htmlField === null
                    ? {id: idField(item), text: textField(item), payload: item}
                    : {id: idField(item), text: textField(item), payload: item, html: htmlField(item)};
                result.push(option)
            });
            withEmpty && result.unshift({id: 'empty', text: '-', html: '-'});
        } else {
            const options = new Map();
            let str = '';
            for (const item of arr) {
                if (item[groupField] === null || item[groupField] === undefined) continue;
                let option = htmlField === null
                    ? {id: idField(item), text: textField(item), payload: item}
                    : {id: idField(item), text: textField(item), payload: item, html: htmlField(item)};

                if (item[groupField] === '') {
                    str += ' ';
                    options.set(str, []) && options.get(str).push(option);
                    continue;
                }

                options.get(item[groupField]) !== undefined
                    ? options.get(item[groupField]).push(option)
                    : options.set(item[groupField], []) && options.get(item[groupField]).push(option);
            }

            for (const [group, optionsArr] of options) {
                result.push({text: group, children: optionsArr});
            }

            withEmpty && result.unshift({id: 'empty', text: '-'});
        }
    } catch (err) {
        return [];
    }

    return result;
};

/**
 * Set focus on the first focusable element
 * @param element - from which element search starts
 */
export const focusOnFirstFocusable = (element = null) => {
    if (!element) {
        element = document;
    }
    let focusable = element.querySelector('input, select, textarea, [href], [tabindex]:not([tabindex="-1"])');
    focusable && focusable.focus();
}
