/**
 * Bring the first invalid input to viewport and focus at it
 */
export const navigateToFirstInvalid = () => {
    setTimeout(() => {
        let firstError = document.querySelector('.invalid-feedback.d-block');
        if (firstError !== null) {
            let invalidInput = firstError.parentNode.querySelector('input');
            invalidInput = invalidInput === null
                ? firstError.parentNode.querySelector('.select2-selection.select2-selection--single')
                : invalidInput;
            invalidInput = invalidInput === null
                ? firstError.parentNode.querySelector('textarea')
                : invalidInput;
            invalidInput && invalidInput.focus();
            firstError && firstError.scrollIntoView({behavior: "smooth", block: "center"});
        }
    }, 1);
}
