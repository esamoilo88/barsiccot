import {$axios} from "res/js/boot";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

/**
 * Fetch user preferences if they don't exist in localStorage
 * @returns {Promise<void>}
 */
export const fetchUserPreferences = async () => {
    let userPreferences = localStorage.getItem('user-preferences');

    if (userPreferences === null) {
        try {
            const res = await $axios.get('/users/get-preferences');
            !isEmpty(res.data) && localStorage.setItem('user-preferences', JSON.stringify(res.data));
        } catch (err) {
            console.error("Couldn't get user preferences! Err:", err);
        }
    }
}

/**
 * @returns {any}
 */
export const getUserPreferences = () => {
    let userPreferences = localStorage.getItem('user-preferences');
    return JSON.parse(userPreferences);
}
