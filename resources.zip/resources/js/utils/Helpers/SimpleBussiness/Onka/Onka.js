import Formatter from "res/js/utils/formatter";

export const computeGmkz = (value) => {
    let formatter = new Formatter();
    if (String(value).match(/,/) !== null) {
        // converting 14,5 to 1.145
        value = formatter.stringToNumber(value) / 100 + 1;
    } else if (String(value).match(/\./) !== null) {
        // converting 1.145 to 14,5
        value = (value - 1) * 100;
        let arrGmkz = String(value).split('.');
        let decimals = arrGmkz[1] !== '' && arrGmkz[1] !== undefined ? String(arrGmkz[1]).length : 0;
        decimals < 2 && (decimals = 2);
        value = formatter.numberToString(value, false, false, null, {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
        });
    }

    return value;
}
