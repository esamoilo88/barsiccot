/**
 * Make an object with filter params for a get request
 * @param ctx
 * @returns {{}}
 */
export const getFilterParams = (ctx) => {
    let filters = {};
    for (let filter in ctx.filter) {
        if (ctx.filter.hasOwnProperty(filter)) {
            filters[`filter[${filter}]`] = ctx.filter[filter];
        }
    }
    return filters;
}
