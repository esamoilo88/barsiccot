export const getQueryParam = key => {
    const params = new Proxy(new URLSearchParams(window.location.search), {
      get: (searchParams, prop) => searchParams.get(prop.toString())
    });

    return params[key];
};

export const replaceUrlParam = (param, value) => {
    let url = window.location.href;
    if (value == null) {
        value = '';
    }
    let pattern = new RegExp('\\b('+param+'=).*?(&|#|$)');
    if (url.search(pattern)>=0) {
        url = url.replace(pattern,'$1' + value + '$2');
    } else {
        url = url.replace(/[?#]$/,'');
        url = url + (url.indexOf('?')>0 ? '&' : '?') + param + '=' + value;
    }

    // This will create a new entry in the browser's history, without reloading
    window.history.pushState({}, window.document.title, url);
}
