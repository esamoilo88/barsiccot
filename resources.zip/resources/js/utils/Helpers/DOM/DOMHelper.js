/**
 * Check if the element is visible inside a specific wrapper
 * @param el
 * @param rel - relative wrapper by which visibility of an element is calculated. 'document' by default
 * @param acceptableDiff - amount of pixels which element can be overflowed by a wrapper
 * @returns {boolean}
 */
export const isElementVisible = (el, rel = undefined, acceptableDiff = 5) => {
    if (!rel) {
        rel = document.documentElement;
    }
    rel = rel.getBoundingClientRect();
    el = el.getBoundingClientRect();
    return (
        el.left >= rel.left - acceptableDiff &&
        el.left < rel.right &&
        el.right <= rel.right + acceptableDiff &&
        el.right > rel.left &&
        el.top >= rel.top - acceptableDiff &&
        el.top < rel.bottom &&
        el.bottom <= rel.bottom + acceptableDiff &&
        el.bottom > rel.top
    );
}
