/**
 * Pause the execution for given amount of milliseconds
 * @param ms
 * @returns {Promise<unknown>}
 */
export const sleep = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
}
