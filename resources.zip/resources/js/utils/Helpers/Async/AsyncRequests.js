export const asyncCall = async (callback, errCallback = null, withPreloader = true, consoleErrMsg = null) => {
    withPreloader && window.preloader.show();
    try {
        await callback();
    } catch (err) {
        consoleErrMsg && console.log(consoleErrMsg, err);

        if (errCallback !== null) {
            errCallback(err);
        } else {
            window.flash.showMessagesFromAjax(err.response.data);
        }
    }
    withPreloader && window.preloader.hide();
}
