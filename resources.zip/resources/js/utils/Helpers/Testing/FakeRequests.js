/**
 * Simulate async request to backend
 * @param callback
 * @param time
 * @returns {Promise<void>}
 */
export const fakeAsyncCall = async (callback, time) => {
    const delay = ms => new Promise(res => setTimeout(res, ms))
    await delay(time);
    callback();
}
