export default class Formatter {
    numberToString(numberToFormat, withCurrency, roundToReadable = false, defVal, options = {}) {
        if (numberToFormat == null || numberToFormat == undefined) {
            return defVal;
        }
        const formatter = withCurrency
            ? new Intl.NumberFormat("de-DE", {
                style: "currency",
                currency: "EUR"
            })
            : new Intl.NumberFormat("de-DE", {...options});

        let formatted = formatter.format(numberToFormat);

        if (roundToReadable && withCurrency) {
            const arrFormatted = formatted.split('.');

            if (arrFormatted.length === 1 || (arrFormatted.length === 2 && arrFormatted[0].length === 1)) {
                return formatted; // we started to round from ten-thousand-value numbers
            }

            let rounded = formatted.replace(/,/g, '');
            rounded = rounded.replace(new RegExp(/\./g), ',');

            const arrRounded = rounded.split(',');
            switch (arrRounded.length) {
                case 2:
                    return rounded.slice(0, arrRounded[0].length + 2) + " k €";
                case 3:
                    return rounded.slice(0, arrRounded[0].length + 2) + " Mio €";
            }
        }

        return formatted;
    }

    removeTrailingZerosFromDB(value) {
        return value.toString().replace(/(\.0*|(?<=(\..*))0*)$/, '');
    }

    removeTrailingZeros(value) {
        return value.toString().replace(/,([1-9]+)(0+)$/,"$1");
    }

    stringToNumber(stringToFormat) {
        let group = new Intl.NumberFormat("de-DE").format(1111).replace(/1/g, '');
        let decimal = new Intl.NumberFormat("de-DE").format(1.1).replace(/1/g, '');

        let reversedString = stringToFormat.replace("€", '');

        reversedString = reversedString.replace(new RegExp('\\' + group, 'g'), '');
        reversedString = reversedString.replace(new RegExp('\\' + decimal, 'g'), '.');

        return isNaN(reversedString) ? stringToFormat : reversedString.trim();
    }

    dotToComma(value) {
        if (value === 0) return value.toString();

        if (value) {
            return value.toString().replace('.', ',');
        }

        return null;
    }

    stringToFloat(value, toFixed = 2) {
        if (!value) return null;

        value = parseFloat(value);
        value = value.toFixed(toFixed);

        return this.dotToComma(value);
    }

    /**
     * Get float value from string
     * @param value
     * @param defaultValue
     * @returns {number|*}
     */
    parseToFloat(value, defaultValue = 0.0) {
        if (value === undefined || value === null || value === '') {
            return defaultValue;
        }
        if (String(value).match(',') !== null) {
            return parseFloat(this.stringToNumber(value));
        } else {
            return parseFloat(value);
        }
    }
}
