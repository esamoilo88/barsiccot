import * as dayjs from 'dayjs'
import 'dayjs/locale/de'
import * as relativeTime from 'dayjs/plugin/relativeTime';
import customParseFormat from "dayjs/plugin/customParseFormat";

dayjs.extend(relativeTime);
dayjs.locale('de');
dayjs.extend(customParseFormat);

export default dayjs;
