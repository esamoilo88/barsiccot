export default () => {
    let navbar = document.getElementById('navigation');

    if (navbar !== null && navbar !== undefined) {
        let sticky = navbar.offsetTop;

        window.addEventListener('scroll', function(e) {
            if (window.pageYOffset >= sticky) {
                if (!navbar.classList.contains('sticky')) {
                    navbar.classList.add('sticky');
                    document.body.classList.add('h-auto');
                }
            } else {
                if (navbar.classList.contains('sticky')) {
                    navbar.classList.remove('sticky');
                    document.body.classList.remove('h-auto');
                }
            }
        });
    }
}
