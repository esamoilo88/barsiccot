export default () => {
    document.querySelectorAll('.nav-item.dropdown .nav-link').forEach((menu) => {
        menu.addEventListener('click', (e) => {
            if (!e.target.parentNode.classList.contains('show')) {
                setTimeout(() => {
                    e.target.parentNode.querySelector('.dropdown-menu .dropdown-item').focus();
                }, 1);
            }
        })
    });
}
