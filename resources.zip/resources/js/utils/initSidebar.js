import $ from 'jquery';

export default () => {
    let btn = document.getElementById('toggle-sidebar');

    if (btn !== null) {
        btn.addEventListener('click', (el, evt) => {
            let sidebar = document.getElementById('sidebar');
            let isCurrentlyCollapsed = sidebar.classList.contains('collapsed');
            sidebar.setAttribute('aria-expanded', String(isCurrentlyCollapsed));
            sidebar.classList.toggle('collapsed');
            $('body').toggleClass('sidebar-collapsed');

            document.cookie = `sidebarExpanded=${isCurrentlyCollapsed ? 1 : 0};path=/`;

            defineTooltips(!isCurrentlyCollapsed);
            setAriaAttributes(!isCurrentlyCollapsed);

            if (window.afterSidebarChanged !== undefined) {
                window.afterSidebarChanged.map(fn => fn());
            }
        });

        defineTooltips();
    }
}

const defineTooltips = (isCurrentlyCollapsed = null) => {
    if (!isCurrentlyCollapsed) {
        let sidebar = document.getElementById('sidebar');
        isCurrentlyCollapsed = sidebar.classList.contains('collapsed');

        //init tooltips for header here (on the first page load)
        $('.header-controls[data-toggle="tooltip"]').tooltip({boundary: 'window'});
    }

    if (isCurrentlyCollapsed) { //init tooltips
        $('#sidebar [data-toggle="tooltip"]:not(.user-button-dropdown)').tooltip({boundary: 'viewport'});
        $('.user-button-dropdown[data-toggle="tooltip"]').tooltip({boundary: 'viewport', container: '.options-tooltip'});
    } else {// remove tooltips
        $('#sidebar [data-toggle="tooltip"]').tooltip('dispose');
    }
}

const setAriaAttributes = (isCurrentlyCollapsed) => {
    $('.sidebar-title.full').attr('aria-hidden', isCurrentlyCollapsed ? 'true' : 'false');
    $('.sidebar-title:not(.full)').attr('aria-hidden', !isCurrentlyCollapsed ? 'true' : 'false');

    $('#sidebar .group-name, #sidebar .menu-item-text').attr('aria-hidden', isCurrentlyCollapsed ? 'true' : 'false');
}
