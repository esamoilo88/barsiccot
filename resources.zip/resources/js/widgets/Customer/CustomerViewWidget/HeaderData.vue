<template>
    <div>
        <div class="row pl-3 pr-3 d-flex justify-content-between">
            <div class="column-16 simple-box">
                <div class="row">
                    <div class="col-lg-8 col-md-8">
                        <h3 class="label-text wrap-text">Kundenname</h3>
                        <div>{{ defVal(dataProp.name, '-') }}</div>
                    </div>
                    <div class="col-lg-8 col-md-8">
                        <h3 class="label-text wrap-text">Gp-Nummer</h3>
                        <div>{{ defVal(dataProp.akpGpNr, '-') }}</div>
                    </div>
                    <div class="col-lg-8 col-md-8">
                        <h3 class="label-text wrap-text">Kundennummer</h3>
                        <div>{{ defVal(dataProp.akpDTAGkdnr, '-') }}</div>
                    </div>
                </div>
            </div>
            <div class="column-7 simple-box">
                <h3 class="label-text">Merkmale</h3>
                <b-badge :class="'bg-' + color + ' mr-2'">{{ isActive }}</b-badge>
                <b-badge class="badge-secondary">{{ isInternal }}</b-badge>
            </div>
        </div>
    </div>
</template>

<script>
import {BBadge} from 'bootstrap-vue';
import {mapState, mapActions} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";

export default {
    name: "HeaderData",
    components: {
        BBadge
    },
    mixins: [ScalarsProcessing],
    computed: {
        ...mapState({
            internalSegment: state => state.customer.internalSegment,
        }),
        isActive(){
            return (this.dataProp.active) ? 'Aktiv' : 'Inaktiv';
        },
        color(){
            return (this.dataProp.active) ? 'primary text-white' : 'secondary';
        },
        isInternal(){
            return (this.dataProp.internal) ? 'Konzernkunde' : 'Externer Kunde';
        }
    },
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    methods: {
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        font-size: 22px;
        padding: 5px 20px 5px 0;
    }
}

.marge-box {
    border-right: 2px solid #dee2e6;
    margin-right: 55px;
    padding-right: 55px;
}

[class*="header-data__"] {
    font-weight: bold;
}

@media (max-width: 1199px) {

    .marge-box {
        margin-right: 20px;
        padding-right: 0;
    }
}
.isInternal{
    margin-top: 27px;
}

.wrap-text {
    overflow-wrap: anywhere;
}
.column-16 {
    flex: 0 0 73.6666666667%;
    max-width: 73.6666666667%;
}
.column-7 {
    flex: 0 0 25%;
    max-width: 25%;
}
</style>
