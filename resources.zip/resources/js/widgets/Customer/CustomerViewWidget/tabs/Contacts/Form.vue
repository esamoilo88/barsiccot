<template>
    <b-overlay :show="pending">
        <div class="simple-box">
            <div class="form-group mb-4 people-search-container">
                <PeopleSearch
                    ref="search"
                    type="ldap"
                    label="Personen suchen..."
                    :multiple="false"
                    @user-added="fillContact"
                />

                <div class="text-muted">Suche nach internen Telekom Mitarbeitern</div>
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.firstName"
                    name="firstName"
                    input-id="firstName-input"
                    label-text="Vorname*"
                    :error-conditions="ec.firstName"
                />
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.lastName"
                    name="lastName"
                    input-id="lastName-input"
                    label-text="Nachname*"
                    :error-conditions="ec.lastName"
                />
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.company"
                    name="company"
                    input-id="company-input"
                    label-text="Firma*"
                    :error-conditions="ec.company"
                />
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.department"
                    name="department"
                    input-id="department-input"
                    label-text="Abteilung"
                />
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.email"
                    name="email"
                    input-id="email-input"
                    label-text="E-Mail"
                    :error-conditions="ec.email"
                />
            </div>

            <div class="form-group">
                <FormInput
                    v-model="form.telNr"
                    name="telNr"
                    input-id="telNr-input"
                    label-text="Telefonnummer"
                />
            </div>

            <div class="form-group">
                <FormSelect
                    v-model="form.roleId"
                    :options="roles"
                    name="roleId"
                    select-id="roleId-input"
                    label-text="Rolle*"
                    :error-conditions="ec.roleId"
                />
            </div>
        </div>
    </b-overlay>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import {BOverlay} from 'bootstrap-vue';
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import {required, email} from "vuelidate/lib/validators";

export default {
    components: {FormInput, FormSelect, BOverlay, PeopleSearch},
    props: {
        contact: {
            default: () => {
                return {
                    firstName: null,
                    lastName: null,
                    company: null,
                    department: null,
                    email: null,
                    telNr: null,
                    role: {
                        id: null
                    },
                }
            }
        }
    },
    computed: {
        ec() {
            return {
                firstName: [
                    {
                        name: 'firstName-required',
                        condition: !this.$v.form.firstName.required && this.$v.form.firstName.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Vorname'})
                    }
                ],
                lastName: [
                    {
                        name: 'lastName-required',
                        condition: !this.$v.form.lastName.required && this.$v.form.lastName.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Nachname'})
                    }
                ],
                company: [
                    {
                        name: 'company-required',
                        condition: !this.$v.form.company.required && this.$v.form.company.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Firma'})
                    }
                ],
                email: [
                    {
                        name: 'email-required',
                        condition: !this.$v.form.email.email && this.$v.form.email.$dirty,
                        text: this.$t.__('validation.email', {attribute: 'E-Mail'})
                    }
                ],
                roleId: [
                    {
                        name: 'roleId-required',
                        condition: !this.$v.form.roleId.required && this.$v.form.roleId.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Rolle'})
                    }
                ],
            }
        }
    },
    data() {
        return {
            pending: false,
            form: {
                firstName: this.contact.firstName,
                lastName: this.contact.lastName,
                company: this.contact.company,
                department: this.contact.department,
                email: this.contact.email,
                telNr: this.contact.telNr,
                roleId: this.contact.role.id,
            },
            roles: []
        }
    },
    mounted() {
        this.getRoles();
    },
    methods: {
        async getRoles() {
            if (this.pending) return;

            this.pending = true;

            try {
                const response = await this.$axios.get('/customers/contacts/roles');

                this.roles = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        fillContact(user) {
            this.form.firstName = user.name;
            this.form.lastName = user.surname;
            this.form.company = user.company;
            this.form.department = user.department;
            this.form.email = user.email;
            this.form.telNr = user.phone;
        },
        validate() {
            this.$v.$touch();

            return !this.$v.$anyError;
        }
    },
    validations: {
        form: {
            firstName: {required},
            lastName: {required},
            company: {required},
            email: {email},
            roleId: {required}
        }
    }
}
</script>

<style lang="scss">
.people-search-container {
    #people-search {
        border: none;
        padding: 0 !important;
    }

    .people-search-component {
        width: 100%;
    }

    .card-label {
        display: none;
    }

    .user-list {
        display: none;
    }
}
</style>
