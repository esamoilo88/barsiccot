<template>
    <div class="simple-box">
        <div class="row no-gutters justify-content-between mb-3 align-items-center">
            <div class="col-auto">
                <h2>
                    <span class="icon-user_file-user-default"></span>
                    Kontakte
                </h2>
            </div>
            <div class="col text-muted text-small px-3">
                Interne und externe Kundenkontakte
            </div>
            <div class="col-auto">
                <button class="btn btn-primary" @click="showCreateDialog">
                    <span class="icon-action-add-default"></span>
                    Neuer Kontakt
                </button>
            </div>
        </div>

        <b-overlay :show="pending">
            <div class="table-responsive">
                <table class="table">
                    <tr>
                        <th>Name und Abteilung</th>
                        <th>Firma</th>
                        <th>Rolle</th>
                        <th>Kontakt</th>
                        <th>Optionen</th>
                    </tr>
                    <tr v-for="item in data">
                        <td>
                            <div>{{ item.lastName }}, {{ item.firstName }}</div>
                            <div class="text-muted">{{ item.department }}</div>
                        </td>
                        <td>{{ item.company }}</td>
                        <td>{{ item.role.name }}</td>
                        <td>
                            <div class="contact-item" v-if="item.email">
                                <span class="icon-communication-email-default"></span>
                                <a :href="`mailto:${item.email}`" class="text-primary">{{ item.email }}</a>
                            </div>
                            <div class="contact-item" v-if="item.telNr">
                                <span class="icon-communication-phone-number-default"></span>
                                {{ item.telNr }}
                            </div>
                        </td>
                        <td>
                            <div class="text-nowrap">
                                <button class="btn btn-secondary" @click="showUpdateDialog(item)">
                                    <span class="icon-action-edit-default"></span>
                                </button>

                                <button class="btn btn-danger" @click="deleteContact(item)">
                                    <span class="icon-action-remove-default"></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </b-overlay>

        <Create
            v-if="createDialog.show"
            :show="createDialog.show"
            :customer-id="customerId"
            @hide="hideCreateDialog"
            @submit="getData"
        />

        <Update
            v-if="updateDialog.show"
            :show="updateDialog.show"
            :customer-id="customerId"
            :contact="updateDialog.contact"
            @hide="hideUpdateDialog"
            @submit="getData"
        />
    </div>
</template>

<script>
import {BOverlay} from 'bootstrap-vue';
import Create from './Create';
import Update from './Update';
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    components: {BOverlay, Create, Update},
    mixins: [ConfirmationModal],
    props: {
        customerId: {
            required: true
        }
    },
    data() {
        return {
            data: [],
            pending: false,
            createDialog: {
                show: false
            },
            updateDialog: {
                show: false,
                contact: {}
            }
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            if (this.pending) return;

            this.pending = true;

            try {
                const response = await this.$axios.get(`/customers/${this.customerId}/contacts`);

                this.data = response.data;

                this.$eventBus.$emit('updateContactsCount', this.data.length);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async deleteContact(contact) {
            if (this.pending) return;

            const result = await this.showConfirmationModal({
                message: `Bitte bestätige die Löschung des Kontakts ${contact.lastName}, ${contact.firstName}.`,
                title: 'Kontakt löschen',
                okTitle: 'Kontakt löschen',
            });

            if (!result) return;

            this.pending = true;

            try {
                await this.$axios.delete(`/customers/${this.customerId}/contacts/${contact.id}`);

                window.flash.success('Erfolgreich gelöscht');

                this.pending = false;

                await this.getData();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        showCreateDialog() {
            this.createDialog.show = true;
        },
        hideCreateDialog() {
            this.createDialog.show = false;
        },
        showUpdateDialog(contact) {
            this.updateDialog.show = true;
            this.updateDialog.contact = contact;
        },
        hideUpdateDialog() {
            this.updateDialog.show = false;
            this.updateDialog.contact = {};
        }
    }
}
</script>

<style lang="scss" scoped>
.contact-item {
    white-space: nowrap;
    display: grid;
    grid-template-columns: 0fr 0fr;
    align-items: center;
    gap: 4px;

    span {
        font-size: 22px;
    }
}
</style>
