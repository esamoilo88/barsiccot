<template>
    <modal-dialog
        :is-visible="show"
        @hideModal="hide"
        title-dialog="Neuer Kontakt"
        modal-class="create-contact-dialog">
        <b-overlay :show="pending">
            <Form ref="form" />
        </b-overlay>

        <template v-slot:footer>
            <button class="btn btn-primary" @click="sumbit">Speichern</button>
            <button class="btn btn-secondary" @click="hide">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import Form from "./Form";
import {BOverlay} from 'bootstrap-vue';

export default {
    components: {ModalDialog, Form, BOverlay},
    data() {
        return {
            pending: false
        }
    },
    props: {
        customerId: {
            required: true
        },
        show: {
            type: Boolean
        }
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async sumbit() {
            if (this.pending || !this.$refs.form.validate()) return;

            this.pending = true;

            try {
                await this.$axios.post(`/customers/${this.customerId}/contacts`, this.$refs.form.form);

                window.flash.success('Erfolgreich gespeichert');

                this.hide();

                this.$emit('submit');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>
