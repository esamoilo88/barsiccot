<template>
    <div id="klassifizierung" class="simple-box mb-5">
        <h2 class="mb-4 titles_box">Klassifizierung</h2>

        <b-overlay :show="pending">
            <div v-if="allCustomerCategories.length > 0" class="klassifizierung-data row">
                <div class="kunde-left col-md-12 col-lg-12 pl-0">
                    <div v-for="cat in firstHalfOfCategories">
                        <span class="text-uppercase font-weight-bold mb-1">{{ cat.catName }}</span>
                        <div class="mb-3">{{ cat.labelName }}</div>
                    </div>
                </div>
                <div class="kunde-right col-md-12 col-lg-12">
                    <div v-for="cat in secondHalfOfCategories">
                        <span class="text-uppercase font-weight-bold mb-1">{{ cat.catName }}</span>
                        <div class="mb-3">{{ cat.labelName }}</div>
                    </div>
                </div>
            </div>
            <div v-else class="text-muted text-center noDate">
                Keine Klassifizierung vorhanden.
            </div>
            <div class="d-flex w-100">
                <ButtonIcon
                    v-if="dataProp.hasPermissions"
                    icon-class="icon-action-edit-default align-middle"
                    class="edit-klassifizierung"
                    button-id="editKlassifizierung"
                    @click="isFormActive = true"
                    title="Klassifizierung bearbeiten"
                />
            </div>
        </b-overlay>

        <modal-dialog
            modal-class="klassifizierung-customer-modal"
            :is-visible="isFormActive"
            @hideModal="isFormActive = false"
            title-dialog="Klassifizierung bearbeiten"
        >
            <EditForm
                v-if="isFormActive" ref="editForm"
                :labels-categories-prop="allCategories"
                :customer-id="customerId"
                @pending="val =>isLoaded = val"
            />
            <template #footer="{methods}">
                <button v-if="isEditFormWritable" :disabled="onSavePending || isLoaded"
                        @click="onSave(methods.hideModal)" class="btn btn-primary">
                    <b-spinner v-if="onSavePending" small></b-spinner>
                    Klassifizierung speichern
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BSpinner} from 'bootstrap-vue';
import DoughnutChart from "@comp/Charts/DoughnutChart";
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import Loading from '@comp/DynamicImportHelpers/Loading';
import {mapActions, mapState} from "vuex";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {BOverlay} from 'bootstrap-vue';

const EditForm = () => ({
    loading: Loading,
    component: import(/*webpackChunkName:"klassifizierung-customers-edit-form"*/ './EditKlassifizierung'),
    delay: 0
});

export default {
    name: "Klassifizierung",
    components: {
        BOverlay, BSpinner, DoughnutChart, ModalDialog, EditForm, ButtonIcon
    },
    props: {
        customerId: {
            type: Number,
            required: true
        },
        dataProp: {
            type: Object,
            required: true
        }
    },
    async created() {
        await this.init();
    },
    computed: {
        ...mapState({
            project: state => state.project.project
        }),
        firstHalfOfCategories() {
            const half = Math.ceil(this.allCustomerCategories.length / 2);
            console.log('this.allCustomerCategories.slice(0, half)', this.allCustomerCategories.slice(0, half))
            return this.allCustomerCategories.slice(0, half)
        },
        secondHalfOfCategories() {
            if (this.allCustomerCategories.length === 1) {
                return [];
            }
            const half = Math.ceil(this.allCustomerCategories.length / 2);

            return this.allCustomerCategories.slice(-half)
        },
        isLabelsExist() {
            if (Object.keys(this.labelsCategories).length !== 0) {
                for (let cat in this.labelsCategories) {
                    if (this.labelsCategories[cat].chosenLabels.length > 0) return true;
                }
            }
            return false;
        },
        portfolioChartData() {
            let portfolios = [];
            // 35 id stands for Portfolio labels category
            if (this.labelsCategories[35] !== undefined && this.labelsCategories[35].chosenLabels !== undefined) {
                this.labelsCategories[35].chosenLabels.map(label => {
                    portfolios.push({label: label.bezeichnung, value: label.prozent});
                });
            }
            return portfolios;
        },
        portfolioLabels() {
            let portfolios = [];
            // 35 id stands for Portfolio labels category
            if (this.labelsCategories[35] !== undefined && this.labelsCategories[35].chosenLabels !== undefined) {
                return this.labelsCategories[35].chosenLabels;
            }
            return portfolios;
        },
        isEditFormWritable() {
            // if (!this.dataProp.canUserManageProject) return false;
            for (let cat in this.labelsCategories) {
                if (this.labelsCategories[cat].readonlyStatus.indexOf(this.projectStatus) === -1) return true;
            }
            return true;
        }
    },
    data() {
        return {
            isLoaded: false,
            allCategories: [],
            allCustomerCategories: [],
            labelsCategories: {},
            isFormActive: false,
            pending: false,
            onSavePending: false
        }
    },
    methods: {
        /**
         *  Event handler for dialog's "Klassifizierung speichern" button
         **/
        async onSave(callback) {
            this.onSavePending = true;
            let isSaved = await this.$refs.editForm.save();
            this.onSavePending = false;
            if (isSaved) {
                callback();
                await this.init();
            }
        },
        async init() {
            this.pending = true;
            let res = await this.$axios.get('/customers/categories');
            this.allCategories = res.data;
            this.allCustomerCategories = this.allCategories
                .filter(l => l.customerId === this.customerId);
            this.pending = false;
        }
    }
}
</script>

<style lang="scss" scoped>

.edit-klassifizierung {
    align-self: flex-end;
    margin-left: auto;
}

.klassifizierung-data {
    display: flex;
    min-height: 143px;

    td:nth-child(1) {
        padding: 5px 20px 5px 0;
    }

    td:nth-child(1) {
        font-weight: bold;
    }
}

.titles_box {
    border-bottom: 1px solid #dee2e6;
}

.noDate {
    min-height: 149px;
}
</style>
