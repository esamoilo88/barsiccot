<template>
    <div class="simple-box mb-5">
        <h2 class="mb-4 titles_box">Angebotenes Portfolio</h2>
        <b-overlay :show="loading">
            <div v-if="pending" class="portfolio-data placeholder-preloader-wrapper">
                <div class="ph-item">
                    <div class="ph-col-6">
                        <div class="ph-row">
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                        </div>
                    </div>
                    <div class="ph-col-6">
                        <div class="ph-row">
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else>
                <div v-if="portfolios.length >0" class="row portfolio-data">
                    <div class="col-lg-16 col-sm-24 pr-3 left-box">
                        <table class="w-100 mb-5">
                            <tbody>
                            <tr v-for="(portfolio, index) in portfolios" v-if="index < 5">
                                <td>{{ portfolio.bezeichnung }}</td>
                                <td class="font-weight-bold">{{ Math.round(parseFloat(portfolio.prozent)) }}%</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-8 col-lg-8 col-md-6">
                        <div>
                            <doughnut-chart
                                :data="portfolioChartData"
                                :options="{labelSuffix: '%', cutoutPercentage: 10}"
                                :canvas-width="50"
                                :canvas-height="50"
                                id="portfolio-chart"
                                class="portfolio-chart ml-3 mb-5"
                                custom-tooltip
                            ></doughnut-chart>
                        </div>
                        <span v-if="portfolios.length > 5">Es werden nur die fünf meistverwendeten Portfolios dargestellt.</span>
                    </div>
                </div>
                <div v-else class="portfolio-data text-center">
                    <span> Keine Portfolio vorhanden</span>
                </div>
                <div>
                    <b-form-checkbox
                        class="portfolio-checkbox"
                        switch
                        @change="getPortfolios(presales)"
                        v-model="presales"
                    >
                        Nur beauftragte Vorhaben berücksichtigen
                    </b-form-checkbox>
                </div>
            </div>
        </b-overlay>
    </div>
</template>
<script>
import DoughnutChart from "@comp/Charts/DoughnutChart";
import {BFormCheckbox, BOverlay} from "bootstrap-vue";

export default {
    name: "portfolio-tab",
    components: {
        BOverlay,
        BFormCheckbox,
        DoughnutChart
    },
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    async created() {
        this.getPortfolios();
    },
    computed: {
        portfolioChartData() {
            return this.portfolios.map(e => {
                return {'label': e.bezeichnung, 'value': Math.round(parseFloat(e.prozent))}
            });
        }
    },
    data() {
        return {
            portfolios: null,
            presales: false,
            pending: false,
            loading: false
        }
    },
    methods: {
        async getPortfolios(includeOrdered) {
            if (includeOrdered !== undefined) {
                this.loading = true;
            } else {
                this.pending = true;
            }
            let data = (includeOrdered) ? {'includeOrdered': 1} : {'includeOrdered': 0};
            const response = await this.$axios.post('/customers/' + this.dataProp.id + '/portfolios', data);
            this.portfolios = response.data;
            this.pending = false;
            this.loading = false;
        }
    }
}
</script>
<style lang="scss" scoped>
.left-box {
    border-right: 2px solid #dee2e6;
}

@media (max-width: 992px) {
    .portfolio-wrapper {
        flex-wrap: wrap;
    }
    .left-box {
        border: none;
    }
}

.portfolio-wrapper {
    display: flex;

}

@media (max-width: 992px) {
    .portfolio-wrapper {
        flex-wrap: wrap;
    }
    .left-box {
        border: none;
    }
}

.portfolio-data {
    min-height: 314px;

    td {
        font-size: 18px;
        padding: 5px 20px 5px 0;
    }
}

::v-deep .placeholder-preloader-wrapper {
    display: block;

    .ph-item {
        display: flex;
    }
}
::v-deep .b-overlay .position-absolute{
    margin: -13px;
}

.portfolio-chart {
    width: 150px;
    height: 150px;
}

.portfolio-checkbox {
    position: absolute;
    bottom: 0px;
}

.titles_box {
    border-bottom: 1px solid #dee2e6;
}
</style>
