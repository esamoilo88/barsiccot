<template>
    <div class="row w-100">
        <div class="col-lg-12 col-md-26 col-sm-26 col-26 pr-lg-2 pr-md-0 pr-sm-0 pl-0">
            <Kundendaten :data-prop="dataProp"/>
            <div class="simple-box">
                <h2 class="mb-4 titles_box">Account-Navigator Daten</h2>
                <div class="kunde-data row">
                    <div class="kunde-left col-md-12 col-lg-12 pl-0">
                        <span class="text-uppercase font-weight-bold mb-1">Segment</span>
                        <div class="mb-3">{{ defVal(customer.akpSegment, '-') }}</div>
                        <span class="text-uppercase font-weight-bold mb-1">Wirtschaftszweig</span>
                        <div class="mb-3">{{ defVal(customer.akpWzBezeichnung, '-') }}</div>
                        <span class="text-uppercase font-weight-bold mb-1">Zielgruppe</span>
                        <div class="mb-3">{{ defVal(customer.akpZgBezeichnung, '-') }}</div>
                    </div>
                    <div class="kunde-right col-md-12 col-lg-12">
                        <span class="text-uppercase font-weight-bold mb-1">Umsatzsteuer-ID</span>
                        <div class="mb-3">{{ defVal(customer.akpUstId, '-') }}</div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-12 col-md-26 col-sm-26 col-26 pr-lg-2 pr-md-0 pr-sm-0 pl-0">
            <Portfolio :data-prop="dataProp"/>
            <Klassifizierung :customerId="customer.id" :data-prop="dataProp" />
        </div>
    </div>
</template>
<script>
import {mapActions, mapState} from "vuex";
import Portfolio from './Portfolio'
import Kundendaten from "./Kundendaten";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import Klassifizierung from './Klassifizierung'
export default {
    name: "stammdaten-tab",
    components: {
        Klassifizierung,
        Portfolio,
        Kundendaten
    },
    mixins: [ScalarsProcessing],
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    async created() {
       this.setInitialCustomerData(this.dataProp);
    },
    computed: {
        ...mapState({
            customer: state => state.customer.customer,
        }),
    },
    data() {
        return {
            editDialog: {
                show: false
            }
        }
    },
    methods: {
        ...mapActions({
            setInitialCustomerData: "customer/setCustomerData"
        }),
        async editCustomer(id) {
            const data = this.$refs.form.form;
            await this.$refs.form.update(id, data);
        },
        showModal(customer) {
            this.editDialog.show = true;

            this.$refs.edit.fillForm(customer);
        },
        hideModal() {
            this.editDialog.show = false;
        }
    }
}
</script>
<style lang="scss" scoped>
// KUNDE block
.kunde-data {
    display: flex;

    td:nth-child(1) {
        padding: 5px 20px 5px 0;
    }

    td:nth-child(1) {
        font-weight: bold;
    }
}

.titles_box {
    border-bottom: 1px solid #dee2e6;
}

.edit-customer {
    align-self: flex-end;
    margin-left: auto;
}

.left-box {
    border-right: 2px solid #dee2e6;
}

@media (max-width: 992px) {
    .left-box {
        border: none;
    }
}
::v-deep .placeholder-preloader-wrapper {
    display: block;
    .ph-item {
        display: flex;
    }
}
</style>
