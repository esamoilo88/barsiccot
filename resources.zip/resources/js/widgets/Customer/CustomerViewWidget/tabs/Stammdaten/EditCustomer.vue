<template>
    <modal-dialog
        modal-class="vorhaben-bearbeiten"
        :is-visible="show"
        @hideModal="hide"
        title-dialog="Stammdaten bearbeiten"
        size="lg"
    >
        <b-overlay :show="pending">
            <div class="simple-box">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="form-group">
                            <FormInput
                                v-model="form.name"
                                name="name"
                                input-id="name-input"
                                label-text="Kundenname"
                                :error-conditions="ec.name"
                            />
                        </div>

                        <div class="form-group">
                            <FormSelect
                                v-model="form.country"
                                name="country"
                                select-id="country-input"
                                :options="countriesOptions"
                                label-text="Land"
                                searchable
                                :error-conditions="ec.country"
                                @change="countryChange"
                            />
                        </div>

                        <div class="form-group">
                            <FormAjaxSearchSelect
                                v-model="form.postalCode"
                                name="postalCode"
                                placeholder="PLZ"
                                :options="plzOptions"
                                :pending="pendingPlz"
                                :error-conditions="ec.postalCode"
                                label="ort"
                                @input="fetchPlz"
                                @select="plzSelect"
                            />
                        </div>

                        <div class="form-group">
                            <FormInput
                                v-model="form.state"
                                name="state"
                                input-id="state-input"
                                label-text="Bundesland"
                                :error-conditions="ec.state"
                            />
                        </div>

                        <div class="form-group">
                            <FormInput
                                v-model="form.city"
                                name="city"
                                input-id="city-input"
                                label-text="Stadt"
                                :error-conditions="ec.city"
                            />
                        </div>

                        <div class="form-group">
                            <FormInput
                                v-model="form.street"
                                name="street"
                                input-id="street-input"
                                label-text="Straße"
                                :error-conditions="ec.street"
                            />
                        </div>

                        <FormInput
                            v-model="form.hn"
                            name="hn"
                            input-id="hn-input"
                            label-text="Hausnummer"
                            :error-conditions="ec.hn"
                        />
                    </div>

                    <div class="col-12 pl-3">
                        <div class="mb-3 font-weight-bold">KUNDENLOGO</div>

                        <div class="mb-3">
                            <template v-if="form.logoBase64">
                                <div class="mb-3">
                                    <img :src="form.logoBase64" alt="logo">
                                </div>

                                <button class="btn btn-link" @click="deleteLogo">
                                    <span class="icon-action-remove-default"></span>
                                    Logo entfernen
                                </button>
                            </template>

                            <template v-else>
                                Kein Logo hochgeladen.
                            </template>
                        </div>

                        <div class="form-group">
                            <form-file-load
                                ref="file"
                                type="file"
                                browse-text="Auswählen"
                                @uploadFile="uploadFile"
                                placeholder="Logo hochladen"
                                accept=".png,.jpg,.jpeg"
                            />
                        </div>

                        <div class="text-muted small-text">
                            Bitte lade keine Logos hoch die markenrechtlich oder urheberrechtlich geschützt sind. Das Logo wird nach dem Hochladen verkleinert.
                        </div>
                    </div>
                </div>
            </div>
        </b-overlay>

        <template v-slot:footer>
            <button class="btn btn-primary" @click="update">Speichern</button>
            <button class="btn btn-secondary" @click="hide">Abbrechen</button>
        </template>
    </modal-dialog>
</template>
<script>

import {BOverlay} from 'bootstrap-vue';
import {required, maxLength, helpers} from 'vuelidate/lib/validators';
import FormInput from "@comp/FormInput/FormInput";
import {mapActions} from "vuex";
import FormFileLoad from '@comp/FileLoad/FormFileLoad'
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import countries from './countries.json';
import regexList from './regex.json';
import {createOptions} from "@helpers/Form/InputsHelper";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormAjaxSearchSelect from "@comp/FormAjaxSearchSelect/FormAjaxSearchSelect";

const postalCodeValidation = (value, vm) => {
    const short = countries.find((item) => item.name === vm.country);

    if (short) {
        const regex = regexList[short.alpha2.toUpperCase()];

        if (regex) {
            return RegExp(`^${regex}$`).test(value);
        }
    }

    return true;
}

export default {
    name: "editCustomer",
    components: {
        BOverlay,
        FormInput,
        FormFileLoad,
        ModalDialog,
        FormSelect,
        FormAjaxSearchSelect
    },
    props: {
        show: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        ec() {
            return {
                name: [
                    {
                        name: 'name-required',
                        condition: !this.$v.form.name.required && this.$v.form.name.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Kundenname'})
                    },
                    {
                        name: 'name-maxLength',
                        condition: !this.$v.form.name.maxLength && this.$v.form.name.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Kundenname', size: 200})
                    }
                ],
                city: [
                    {
                        name: 'city-required',
                        condition: !this.$v.form.city.required && this.$v.form.city.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Stadt'})
                    },
                    {
                        name: 'city-maxLength',
                        condition: !this.$v.form.city.maxLength && this.$v.form.city.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Stadt', size: 200})
                    }
                ],
                country: [
                    {
                        name: 'country-maxLength',
                        condition: !this.$v.form.country.maxLength && this.$v.form.country.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Land', size: 200})
                    }
                ],
                postalCode: [
                    {
                        name: 'postalCode-maxLength',
                        condition: !this.$v.form.postalCode.maxLength && this.$v.form.postalCode.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'PLZ', size: 20})
                    },
                    {
                        name: 'postalCode-postalCodeValidation',
                        condition: !this.$v.form.postalCode.postalCodeValidation && this.$v.form.postalCode.$dirty,
                        text: this.$t.__('validation.not_regex', {attribute: 'PLZ'})
                    }
                ],
                state: [
                    {
                        name: 'state-maxLength',
                        condition: !this.$v.form.state.maxLength && this.$v.form.state.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Straße', size: 300})
                    }
                ],
                street: [
                    {
                        name: 'street-maxLength',
                        condition: !this.$v.form.street.maxLength && this.$v.form.street.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Bundesland', size: 200})
                    }
                ],
                hn: [
                    {
                        name: 'hn-maxLength',
                        condition: !this.$v.form.hn.maxLength && this.$v.form.hn.$dirty,
                        text: this.$t.__('validation.size.string', {attribute: 'Hausnummer', size: 20})
                    }
                ]
            }
        }
    },
    data() {
        return {
            pending: false,
            pendingPlz: false,
            form: {
                id: null,
                name: null,
                country: null,
                postalCode: null,
                state: null,
                city: null,
                street: null,
                hn: null,
                logoBase64: null
            },
            countriesOptions: [],
            plzOptions: [],
        }
    },
    mounted() {
        this.countriesOptions = createOptions(
            countries,
            (item) => item.name,
            (item) => item.name
        );
    },
    methods: {
        ...mapActions({
            setCustomerData: "customer/setCustomerData"
        }),
        async uploadFile(file) {
            this.pending = true;

            try {
                const response = await this.$axios.post(`/customers/${this.form.id}/logo`, file.formData, file.config);

                this.form.logoBase64 = `data:${file.type};base64,${response.data}`;

                this.setCustomerData(this.form);

                window.flash.success('Logo erfolgreich hochgeladen');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.$refs.file.clearFiles();

            this.pending = false;
        },
        async deleteLogo() {
            this.pending = true;

            try {
                await this.$axios.delete(`/customers/${this.form.id}/logo`);

                this.form.logoBase64 = null;

                this.setCustomerData(this.form);

                window.flash.success('Logo wurde gelöscht');

            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        fillForm(customer) {
            this.form.id = customer.id;
            this.form.name = customer.name;
            this.form.country = customer.country;
            this.form.postalCode = customer.postalCode;
            this.form.state = customer.state;
            this.form.city = customer.city;
            this.form.street = customer.street;
            this.form.hn = customer.hn;
            this.form.logoBase64 = customer.logoBase64;
        },
        async update() {
            this.$v.form.$touch();

            if (this.$v.$invalid) return;

            this.pending = true;

            try {
                await this.$axios.put(`/customers/${this.form.id}/stammdaten`, this.form);

                window.flash.success('Erfolgreich gespeichert');

                this.setCustomerData(this.form);

                this.hide();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        hide() {
            this.$emit('hide');

            this.form.id = null;
            this.form.name = null;
            this.form.country = null;
            this.form.postalCode = null;
            this.form.state = null;
            this.form.city = null;
            this.form.street = null;
            this.form.hn = null;
            this.form.logoBase64 = null;

            this.plzOptions = [];
        },
        async fetchPlz(search) {
            this.plzOptions = [];

            if (search.length < 5 || this.form.country !== 'Deutschland') return;

            this.pendingPlz = true;

            try {
                const response = await this.$axios.get(`/plz/${search}`);

                if (response.data.length === 0) {
                    this.form.state = null;
                    this.form.city = null;
                } else if (response.data.length === 1) {
                    this.plzSelect(response.data[0]);
                } else {
                    this.plzOptions = response.data;
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pendingPlz = false;
        },
        plzSelect(option) {
            this.form.country = 'Deutschland';
            this.form.postalCode = option.plz;
            this.form.state = option.bundesland;
            this.form.city = option.ort;
        },
        countryChange() {
            this.plzOptions = [];
        }
    },
    validations: {
        form: {
            name: {required, maxLength: maxLength(200)},
            city: {required, maxLength: maxLength(200)},
            country: {maxLength: maxLength(200)},
            postalCode: {
                maxLength: maxLength(20),
                postalCodeValidation
            },
            state: {maxLength: maxLength(300)},
            street: {maxLength: maxLength(200)},
            hn: {maxLength: maxLength(20)},
        }
    }
}

</script>

<style lang="scss">
.small-text {
    font-size: 1rem;
}
</style>
