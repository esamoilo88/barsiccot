<template>
    <div class="simple-box mb-5">
        <h2 class="mb-4 titles_box">Stammdaten</h2>
        <div v-if="!customer" class="placeholder-preloader-wrapper">
            <div class="ph-item">
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
            </div>
        </div>
        <div v-else class="kunde-data row">
            <div class="kunde-left col-md-12 col-lg-12 pl-0">
                <span class="text-uppercase font-weight-bold mb-1">Kundenname</span>
                <div class="mb-3">{{ defVal(customer.name, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">Land</span>
                <div class="mb-3">{{ defVal(customer.country, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">Bundesland</span>
                <div class="mb-3">{{ defVal(customer.state, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">PLZ/ORT</span>
                <div class="mb-3">{{ defVal(customer.postalCode, '-') }} {{ defVal(customer.city, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">Strasse</span>
                <div>{{ defVal(customer.street, '-') }} {{defVal(customer.hn, '-')}}</div>
            </div>
            <div class="kunde-right col-md-12 col-lg-12">
                <span class="text-uppercase font-weight-bold">Kundenlogo</span>
                <img v-if="customer.logoBase64 !== null" :src="customer.logoBase64"
                     alt="Deutsche Telekom. Erleben, was verbindet."
                     style="border: 0; display: block; height: auto; line-height: 100%; outline: none; text-decoration: none; vertical-align: middle;"/>
                <div v-else class="mt-2">Kein Logo hochgeladen</div>

            </div>
            <div class="d-flex w-100">
                <ButtonIcon
                    icon-class="icon-action-edit-default align-middle"
                    class="edit-customer"
                    button-id="editCustomer"
                    @click="showModal(customer)"
                    title="Kunde bearbeiten"
                />
            </div>
        </div>
        <EditCustomer ref="edit" :show="editDialog.show" @hide="hideModal"/>
    </div>
</template>
<script>
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ModalDialog from "@comp/ModalDialog/ModalDialog"
import EditCustomer from "./EditCustomer"
import {BButton, BOverlay} from 'bootstrap-vue';
import {mapActions, mapState} from "vuex";

export default {
    name: "stammdaten-tab",
    components: {
        BOverlay,
        ButtonIcon,
        ModalDialog,
        EditCustomer,
        BButton
    },
    mixins: [ScalarsProcessing],
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    async created() {
        this.setInitialCustomerData(this.dataProp);
    },
    computed: {
        ...mapState({
            customer: state => state.customer.customer,
        }),
    },
    data() {
        return {
            editDialog: {
                show: false
            }
        }
    },
    methods: {
        ...mapActions({
            setInitialCustomerData: "customer/setCustomerData"
        }),
        async editCustomer(id) {
            const data = this.$refs.form.form;
            await this.$refs.form.update(id, data);
        },
        showModal(customer) {
            this.editDialog.show = true;

            this.$refs.edit.fillForm(customer);
        },
        hideModal() {
            this.editDialog.show = false;
        }
    }
}
</script>
<style lang="scss" scoped>
// KUNDE block
.kunde-data {
    display: flex;

    td:nth-child(1) {
        padding: 5px 20px 5px 0;
    }

    td:nth-child(1) {
        font-weight: bold;
    }
}

.titles_box {
    border-bottom: 1px solid #dee2e6;
}

.edit-customer {
    align-self: flex-end;
    margin-left: auto;
}

.left-box {
    border-right: 2px solid #dee2e6;
}

@media (max-width: 992px) {
    .left-box {
        border: none;
    }
}
::v-deep .placeholder-preloader-wrapper {
    display: block;
    .ph-item {
        display: flex;
    }
}
</style>
