<template>
    <div class="klassifizierung-form">
     <b-overlay :show="pending">
        <div class="klassifizierung-data">
                <div v-for="(labels, cat) in labelList">
                    <FormSelect
                        v-model="chosenLabels[labels[0].categoryId]"
                        :options="getOptions(labels)"
                        :key="'labels-' + labels[0].categoryId"
                        :name="'klassifizierung_' + labels[0].categoryId"
                        :select-id="'klassifizierung-category-select-' + labels[0].categoryId"
                        :label-text="cat"
                        empty
                        searchable
                    />
            </div>
        </div>
     </b-overlay>
    </div>
</template>

<script>
import {BFormInput, BInputGroup, BSpinner, BOverlay } from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import KlassifizierungMxn from './KlassifizierungMxn';

export default {
    name: "EditKlassifizierung",
    components: {
        BOverlay, FormSelect, BSpinner, BInputGroup, BFormInput
    },
    mixins: [KlassifizierungMxn],
    props: {
        labelsCategoriesProp: {
            type: Array,
            required: true
        },
        customerId: {
            type: Number,
            required: true
        }
    },
    async created() {
        await this.getLabels();
    },
    mounted() {
        this.fillLabels();
    },
    data() {
        return {
            pending: false,
            labelsCategories: {},
            chosenLabels: [],
            labelList: []
        }
    },
    methods: {
        fillLabels() {
            for (let cat in this.labelsCategoriesProp) {
                if(this.labelsCategoriesProp[cat].customerId === this.customerId) {
                    this.chosenLabels[this.labelsCategoriesProp[cat].catId] = this.labelsCategoriesProp[cat].labelId;
                }
            }
        },
        async getLabels() {
            this.pending = true;
            this.$emit('pending',this.pending);

            let res = await this.$axios.get('/customers/labels');
            const groupBy = (array, key) => {
                return array.reduce((result, currentValue) => {
                    (result[currentValue[key]] = result[currentValue[key]] || []).push(
                        {'labelId': currentValue.labelId, 'labelName': currentValue.name, 'categoryId': currentValue.categoryId}
                    );
                    return result;
                }, {});
            };
            this.labelList = groupBy(Object.values(res.data), 'categoryName');
            this.pending = false;
            this.$emit('pending',this.pending);
        },

        /**
         * Store classification in the backend
         **/
        async save() {
            try {
                let response = await this.$axios.post(`/customers/${this.customerId}/labels`, {
                    labels: this.chosenLabels
                });
                window.flash.showMessagesFromAjax(response.data);
                return true;
            } catch (err) {
                let errorMsg = err.response.statusText ?? err.response.data ?? 'Fehler.';
                window.flash.error(errorMsg);
                return false;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.klassifizierung-form {
    display: flex;
    flex-direction: column;

    .form-control.is-invalid {
        background-image: none;
        border: 1px solid $darkerror;
    }

    .invalid-feedback {
        color: $darkerror;
        padding-left: 20px;
        padding-top: 5px;
        margin-bottom: 3px;
    }

    .category-wrapper {
        padding: 6px 0;
    }
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Firefox */
input[type=number] {
    -moz-appearance: textfield;
}
</style>
