export default {
    methods: {
        /**
         * Check whether or not a specific category is writable
         * @param cat
         * @returns {boolean}
         */
        isCategoryWritable(cat) {
            if (!this.projectData.canUserManageProject) {
                return false;
            }
            return cat.readonlyStatus.indexOf(this.projectStatus) === -1;

        },

        /**
         * Set labels values which are already assigned to a project to display it
         * when form is opened for the first time. Also set stubs for other labels
         */
        setChosenLabels() {
            if (Object.keys(this.labelsCategories).length !== 0) {
                for (let cat in this.labelsCategories) {
                    let categoryChosenLabels = this.labelsCategories[cat].chosenLabels;
                    if (Array.isArray(categoryChosenLabels) && categoryChosenLabels.length > 0) {
                        this.chosenLabels[cat] = []
                        this.labelsCategories[cat].chosenLabels.map(l => {
                            this.chosenLabels[cat].push({
                                ...deepCopy(labelStub),
                                labelId: l.labelId,
                                percentage: l.prozent
                            });
                        });
                    } else {
                        this.chosenLabels[cat] = [{...deepCopy(labelStub)}];
                    }
                }
            }
        },

        /**
         * Used for labels categories which can have more than one value.
         * Shows "cat.chosenLabels.length" number of select inputs or min number of
         * select inputs specified for category
         * @param cat
         */
        howManySelectsToDisplay(cat) {
            return this.chosenLabels[cat.labelKategorieId].length > 0 ?
                this.chosenLabels[cat.labelKategorieId].length :
                cat.minVorkommen;
        },

        /**
         * Add another select input for a category that allow to have
         * more than one select input
         * @param cat
         */
        addAnotherSelect(cat) {
            let labelsLength = this.chosenLabels[cat.labelKategorieId].length;
            if (labelsLength < (cat.maxVorkommen - cat.minVorkommen + 1) && this.isCategoryWritable(cat)) {
                this.chosenLabels[cat.labelKategorieId].push({...deepCopy(labelStub)});
                this.$forceUpdate();
                return true;
            }
            return false;
        },

        /**
         * Get options for select inputs
         **/
       getOptions(category) {
            try {
                let options = category
                    .map(label => {return {id: label.labelId, text: label.labelName};
                });
                options.unshift({id: 0, text: '-'});
                return options;
            } catch (e) {
                return [];
            }
        },
    }
}
