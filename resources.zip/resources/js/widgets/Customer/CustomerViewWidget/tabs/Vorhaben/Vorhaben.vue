<template>
    <div class="simple-box">
        <div class="row no-gutters justify-content-between mb-3 align-items-center">
            <div class="col-auto">
                <h2>
                    <span class="icon-communication-feedback-default"></span>
                    Vorhaben
                </h2>
            </div>
            <span
                class="col text-muted text-small px-3">Vorhaben, Angebote und Verträge die mit dem Kunden verknüpft sind</span>
        </div>

        <table-simple
            table-id="requests-list-table"
            :fields="fields"
            :filters="filters"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
        >
            <template #cell(simpleId)="data">
                <span>SIN/{{ data.item.simpleId }}</span>
            </template>

            <template #cell(thema)="data">
                <div class="d-flex flex-column">
                    <span>{{ data.item.thema }}</span>
                    <span class="text-muted">{{ data.item.labels.filter(l => l !== null).join(' / ') }}</span>
                </div>
            </template>

            <template #cell(vertragsbeginn)="data">
                <div>{{ formatDate(data.item.vertragsbeginn, 'DD.MM.YYYY') }}</div>
            </template>

            <template #cell(vertragsende)="data">
                <div>{{ formatDate(data.item.vertragsende, 'DD.MM.YYYY') }}</div>
            </template>

            <template #cell(volumenDtts)="data">
                <div>{{ $f.numberToString(data.item.volumenDtts, true, true, '-') }}</div>
            </template>

            <template #cell(status)="data">
                <div>
                    <CircleChart
                        :content="data.item.shortName"
                        :value="data.item.progress"
                        :color="data.item.color"
                        size="xsmall"
                        sr-text="Status"
                    />
                </div>
            </template>

            <template #cell(optionen)="row">
                <div class="options-container btn-group" role="group">
                    <a
                        :href="'/projects/' + row.item.simpleId"
                        class="btn btn-outline-secondary dashboard-link"
                        :id="'sales-dashboard-btn-' + row.item.simpleId"
                        title="Sales Dashboard"
                        v-b-tooltip.hover.lefttop
                    >
                        <span class="icon-content-news-default"></span>
                    </a>
                    <a
                        :href="'/offers/' + row.item.simpleId"
                        class="btn btn-outline-secondary dashboard-link"
                        :id="'offer-dashboard-btn-' + row.item.simpleId"
                        title="Offer Dashboard"
                        v-b-tooltip.hover.lefttop
                    >
                        <span class="icon-content-tarrifs-default"></span>
                    </a>
                    <a
                        :href="'/orders/' + row.item.simpleId"
                        class="btn btn-outline-secondary dashboard-link"
                        :id="'finance-dashboard-btn-' + row.item.simpleId"
                        title="Finance Dashboard"
                        v-b-tooltip.hover.lefttop
                    >
                        <span class="icon-user_file-billing-default"></span>
                    </a>
                </div>
            </template>
        </table-simple>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import TableSimple from "@comp/TableSimple/TableSimple";
import {getFilterParams} from "@helpers/Tables/tableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import {VBTooltip} from 'bootstrap-vue';
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: "Vorhaben",
    components: {
        TableSimple, CircleChart
    },
    mixins: [Pagination, DatesProcessing],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        customerId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            fields: [
                {key: "simpleId", label: "SIN", sortable: true, sortDirection: 'desc'},
                {key: "thema", label: "Vorhaben", sortable: true},
                {key: "vertragsbeginn", label: "Vertragsbeginn", sortable: true},
                {key: "vertragsende", label: "Vertragsende", sortable: true},
                {key: "volumenDtts", label: "Auftragsvolumen", sortable: true},
                {key: "status", label: "Status"},
                {key: "optionen", label: "Optionen", class: 'optionen-col'}
            ],
            filters: [
                {
                    field: "status",
                    type: "select",
                    settings: {label: "Status", preselected: 'all', options: [
                        {id: "all", text: "Alle"}, {id: "1", text: "Aktiv"}, {id: "0", text: "Inaktiv"}
                    ]}
                },
                {
                    field: "workflow",
                    type: "select",
                    settings: {label: "Workflow", preselected: 'all', options: [
                        {id: "all", text: "Alle"}, {id: '1', text: 'Presales'}, {id: '0', text: 'Beauftragt'}
                    ]}
                },
                {
                    field: "portfolio",
                    type: "select",
                    settings: {label: "Portfolio", preselected: 'all', options: [
                        {id: "all", text: "Alle"},
                    ]}
                },
                {field: "search", type: "text", settings: {label: "Suchen..."}}
            ],
        }
    },
    async created() {
        try {
            const portfolios = await this.$axios.get(`/customers/${this.customerId}/projects-portfolios`);
            this.filters[2].settings.options.push(...portfolios.data.map(item => item.labelName));
        } catch (err) {
            console.error("Couldn't get portfolios for filter!", err);
        }
    },
    methods: {
        async itemsProvider(ctx, cancelToken) {
            try {
                const res = await this.$axios.get(`/customers/${this.customerId}/projects-list`, {
                        params: {
                            currentPage: ctx.currentPage,
                            sortBy: ctx.sortBy,
                            sortDesc: ctx.sortDesc ? 1 : 0,
                            ...getFilterParams(ctx)
                        }
                    },
                    {cancelToken: cancelToken.token}
                );
                this.totalRows = res.data.total;
                this.perPage = res.data.perPage;
                return res.data.data;
            } catch (err) {
                console.error("Couldn't fetch projects list! Err:", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/tables/new-table';

.vorhaben-icon {
    font-size: 2rem;
}
</style>
