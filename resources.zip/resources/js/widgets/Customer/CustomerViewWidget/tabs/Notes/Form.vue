<template>
    <b-overlay :show="pending">
        <div class="form-group">
            <FormTextArea
                v-model="form.notiz"
                name="note"
                input-id="note-input"
                label-text="Notiz*"
                :error-conditions="errorConditions.notiz"
                rows="8"
            />
        </div>
    </b-overlay>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import {BOverlay} from 'bootstrap-vue';
import {required} from "vuelidate/lib/validators";
import FormTextArea from "@comp/FormTextArea/FormTextArea";

export default {
    components: {FormTextArea, FormInput, FormSelect, BOverlay},
    props: {
        note: {
            default: () => {
                return {
                    note: null,
                }
            }
        }
    },
    computed: {
        errorConditions() {
            return {
                notiz: [
                    {
                        name: 'note-required',
                        condition: !this.$v.form.notiz.required && this.$v.form.notiz.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Notiz'})
                    }
                ]
            }
        }
    },
    data() {
        return {
            pending: false,
            form: {
                notiz: this.note.note,
            }
        }
    },
    methods: {
        validate() {
            this.$v.$touch();

            return !this.$v.$anyError;
        }
    },
    validations: {
        form: {
            notiz: {required},
        }
    }
}
</script>

<style lang="scss">
.people-search-container {
    #people-search {
        border: none;
        padding: 0 !important;
    }

    .people-search-component {
        width: 100%;
    }

    .card-label {
        display: none;
    }

    .user-list {
        display: none;
    }
}
</style>
