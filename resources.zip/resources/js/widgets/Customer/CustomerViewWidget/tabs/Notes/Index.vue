<template>
    <div class="simple-box">
        <div class="row no-gutters justify-content-between mb-3 align-items-center">
            <div class="col-auto">
                <h2>
                    <span class="icon-communication-feedback-default"></span>
                    Notizen
                </h2>
            </div>
            <div class="col text-muted text-small px-3">
                Interne Anmerkungen zum Kunden
            </div>
            <div class="col-auto">
                <button class="btn btn-primary" @click="showCreateDialog">
                    <span class="icon-action-add-default"></span>
                    Neue Notiz
                </button>
            </div>
        </div>

        <div>
            <div v-if="!show" class="placeholder-preloader-wrapper">
                <div class="ph-item">
                    <div class="ph-col-12">
                        <div class="ph-row">
                            <div class="ph-col-8"></div>
                            <div class="ph-col-12 empty"></div>
                            <div class="ph-col-8"></div>
                            <div class="ph-col-8"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <Item
                    v-for="note in notes"
                    :key="note.id"
                    :note="note"
                    @show-update-dialog="showUpdateDialog"
                    @delete-note="deleteNote"
                />
            </div>
        </div>

        <Create
            v-if="createDialog.show"
            :show="createDialog.show"
            :customer-id="customerId"
            @hide="hideCreateDialog"
            @submit="getData"
        />

        <Update
            v-if="updateDialog.show"
            :show="updateDialog.show"
            :customer-id="customerId"
            :note="updateDialog.note"
            @hide="hideUpdateDialog"
            @new-value="setNewValue"
        />
    </div>
</template>

<script>
import {BOverlay, BTable, BSpinner} from 'bootstrap-vue';
import Create from './Create';
import Update from './Update';
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import dayjs from "res/js/utils/day";
import Item from "./Item";

export default {
    components: {Item, BOverlay, BSpinner, Create, Update, ButtonIcon,BTable},
    mixins: [ConfirmationModal],
    props: {
        customerId: {
            required: true
        }
    },
    data() {
        return {
            data: [],
            pending: false,
            createDialog: {
                show: false
            },
            updateDialog: {
                show: false,
                note: {}
            },
            fields: [
                {key: 'created', label: 'Datum', class: 'width-15'},
                {key: 'user', label: 'Erstellt Von', class: 'width-20'},
                {key: 'note', label: 'Notiz', class: 'width-50'},
                {key: 'options', label: 'Optionen'},
            ],
            notes: [],
            show: false
        }
    },
    async mounted() {
        await this.getData();
        this.show = true;
    },
    methods: {
        async getData() {
            if (this.pending) return;

            this.pending = true;

            this.show = false;
            try {
                const response = await this.$axios.get(`/customers/${this.customerId}/notes`);

                this.notes = response.data;

                this.$eventBus.$emit('updateNotesCount', this.notes.length);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.show = true;
            this.pending = false;
        },
        async deleteNote(note) {
            if (this.pending) return;

            const result = await this.showConfirmationModal({
                message: 'Bitte bestätige das Löschen der Notiz',
                title: 'Notiz löschen',
                okTitle: 'Notiz löschen',
            });

            if (!result) return;

            this.pending = true;

            try {
                await this.$axios.delete(`/customers/${this.customerId}/notes/${note.id}`);

                window.flash.success('Erfolgreich gelöscht.');

                this.pending = false;

                this.notes = this.notes.filter(function (noteItem) {
                    return noteItem.id !== note.id;
                })
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        showCreateDialog() {
            this.createDialog.show = true;
        },
        hideCreateDialog() {
            this.createDialog.show = false;
        },
        showUpdateDialog(note) {
            this.updateDialog.note = note;
            this.updateDialog.show = true;
        },
        hideUpdateDialog() {
            this.updateDialog.note = {};
            this.updateDialog.show = false;
        },
        formatDate(item) {
            return dayjs(item.created.date, "YYYY-MM-DDTh:mm:ss").format('DD.MM.YYYY H:mm');
        },
        setNewValue(object) {
            this.notes = this.notes.map(function (note) {
                if (object.id === note.id) {
                    note.note = object.value;
                }

                return note;
            })
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/tables/new-table';

.badge {
    width: 100px;
    text-align: center;
}

::v-deep .width-15 {
    min-width: 15%;
}
::v-deep .width-20 {
    min-width: 20%;
}
::v-deep .width-50 {
    width: 50%;
}
::v-deep .placeholder-preloader-wrapper {
    display: flex;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        box-shadow: none;

        .ph-col-12 {
            padding: 0;
        }
    }

    .ph-row div {
        width: 350px;
    }
}
</style>
