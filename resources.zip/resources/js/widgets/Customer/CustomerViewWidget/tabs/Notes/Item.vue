<template>
    <div class="simple-box mb-3">
        <div class="pl-0">
            <div class="d-flex flex-column">
                <div class="d-flex justify-content-between mb-3">
                    <div>
                        <span class="simple-id font-weight-bold">{{ note.user }} ·</span>
                        <span class="thema">{{ formatDate(note) }}</span>
                    </div>
                    <div>
                        <ButtonIcon
                            icon-class="icon-action-edit-default"
                            variant="secondary"
                            @click="$emit('show-update-dialog', note)"
                        />
                        <ButtonIcon
                            icon-class="icon-action-remove-default"
                            variant="danger"
                            @click="$emit('delete-note', note)"
                        />
                    </div>
                </div>
                <div class="w-75" v-html="note.note.replace(/(?:\r\n|\r|\n)/g, '<br />')"></div>
            </div>
        </div>
    </div>
</template>

<script>
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {VBTooltip} from 'bootstrap-vue';
import dayjs from "res/js/utils/day";

export default {
    name: "Item",
    components: {
        ButtonIcon
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        note: {
            type: Object,
            required: true
        }
    },
    methods: {
        formatDate(item) {
            return dayjs(item.created.date, "YYYY-MM-DDTh:mm:ss").format('DD.MM.YYYY H:mm');
        },
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.options-container {
    padding-left: 15px;
    border-left: 3px solid lightgrey;
}

.kundenname, .psp-element {
    font-size: 1rem;
}

.dashboard-link {
    span {
        font-size: 1.5rem;
        color: $iconscolor;
        vertical-align: middle;
    }
}

.circle_red {
    background: $error;
    text-decoration:none;
    border-radius: 50%;
    display: block;
    height: 19px;
    width: 19px;
}
.circle_red::after {
    content: "\2191";
    display: block;
    color: white;
    font-size: 14px;
    text-align: center;
    padding-top: 2px;
}
.circle_green {
    background: $success;
    text-decoration:none;
    border-radius: 50%;
    display: block;
    height: 19px;
    width: 19px;
}
.circle_green::after {
    content: "\2193";
    display: block;
    color: white;
    font-size: 14px;
    text-align: center;
    padding-top: 2px;
}
.total {
    display: flex;
    align-items: flex-start;
    margin-right: auto;
    margin-left: 0;
}
::v-deep .btn-light{
    background-color: white;
    border-color: white;
}

</style>
