<template>
    <div>
        <div class="d-flex align-items-center bg-white pt-3 pb-3 pl-4 pr-4">
            <h1 lang="en">
                <span class="icon-user_file-contacts-default pr-2"/>
                Customer Dashboard
            </h1>
            <div class="ml-auto">
                <a href="#" onclick="history.go(-1)">Zurück</a>
            </div>
        </div>
        <div>
            <div class="simple-header px-2">
                <HeaderData :data-prop="dataProp"/>
            </div>
            <div>
                <b-tabs @input="onTabSwitch" v-model="tabIndex" class="simple-tabs">
                    <b-tab id="stammdaten-tab" active>
                        <template #title>
                            <span class="text">Stammdaten</span>
                        </template>
                        <div v-if="visitedTabs.includes(0)">
                            <div class="content-padding mb-5 mx-2">
                                <Stammdaten :data-prop="dataProp"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="kontakte-tab">
                        <template #title>
                            <span class="text">Kontakte</span>
                            <b-badge variant="secondary">
                                {{ contactsCount }}
                            </b-badge>
                        </template>
                        <div v-if="visitedTabs.includes(1)">
                            <div class="content-padding mb-5 mx-2">
                                <Contacts :customer-id="dataProp.id" />
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="notizen-tab" lazy>
                        <template #title>
                            <span class="text">Notizen</span>
                            <b-badge variant="secondary">
                                {{ notesCount }}
                            </b-badge>
                        </template>
                        <div v-if="visitedTabs.includes(2)">
                            <div class="content-padding mb-5 mx-2">
                                <Notes :customer-id="dataProp.id" />
                            </div>
                        </div>
                    </b-tab>

                    <b-tab id="vorhaben-tab">
                        <template #title>
                            <span class="text">Vorhaben</span>
                            <b-badge variant="secondary">
                                {{ dataProp.counters.vorhaben }}
                            </b-badge>
                        </template>
                        <div v-if="visitedTabs.includes(3)">
                            <div class="content-padding mb-5 mx-2">
                                <Vorhaben :customer-id="dataProp.id"/>
                            </div>
                        </div>
                    </b-tab>
<!--                    <b-tab id="leistungen-tab" lazy>-->
<!--                        <template #title>-->
<!--                            <span class="text">Leistungen</span>-->
<!--                            <b-badge variant="secondary">-->
<!--                                {{ usersCount }}-->
<!--                            </b-badge>-->
<!--                        </template>-->
<!--                        <div v-if="visitedTabs.includes(4)">-->
<!--                        </div>-->
<!--                    </b-tab>-->
                </b-tabs>
            </div>
        </div>
    </div>
</template>

<script>
import HeaderData from "./HeaderData";
import {BTabs, BTab, BBadge} from 'bootstrap-vue';
import DashboardsSwitch from "@comp/Common/DashboardsSwitchWidget/DashboardsSwitch";
import ProjectTags from "@comp/Common/ProjectTags/ProjectTags";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import Stammdaten from "./tabs/Stammdaten/Stammdaten";
import {mapActions} from "vuex";
import Loading from "@comp/DynamicImportHelpers/Loading";
const Vorhaben = () => ({loading: Loading, component: import('./tabs/Vorhaben/Vorhaben'), delay: 0});
import Contacts from './tabs/Contacts/Index';
import Notes from './tabs/Notes/Index';

export default {
    name: "customer-view",
    components: {
        ProjectTags,
        DashboardsSwitch,
        HeaderData,
        BTabs, BTab, BBadge,
        Stammdaten,
        Contacts,
        Notes,
        Vorhaben
    },
    mixins: [ScalarsProcessing],
    props: {
        dataProp: {
            type: Object,
            required: true
        },
        segments: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            usersCount: 1,
            visitedTabs: [],
            tabIndex: 1,
            contactsCount: this.dataProp.counters.contacts,
            notesCount: this.dataProp.counters.notes
        }
    },
    created() {
        this.$eventBus.$on('updateContactsCount', (count) => this.contactsCount = count);
        this.$eventBus.$on('updateNotesCount', (count) => this.notesCount = count);
    },
    beforeDestroy() {
        this.$eventBus.$off('updateContactsCount');
        this.$eventBus.$off('updateNotesCount');
    },
    mounted() {
        this.setSegmentsOptions(this.segments);
    },
    methods: {
        onTabSwitch(tab) {
            if (!this.visitedTabs.includes(tab)) {
                this.visitedTabs.push(tab)
            }
        },
        ...mapActions({
            setSegmentsOptions: "customer/setSegmentsOptions"
        }),
    }
}
</script>

<style lang="scss" scoped>
::v-deep .more-options-btn span[class*=icon-] {
    font-size: 20px;
}
::v-deep ul.nav-tabs {
    padding: 1.5rem 1rem 0 1rem;
    border-bottom: 1px solid #d3d3d3;
    background-color: #fff;
    -webkit-box-shadow: 0 5px 3px -3px rgba(0, 0, 0, 0.25);
    -moz-box-shadow: 0 5px 3px -3px rgba(0, 0, 0, 0.25);
    box-shadow: 0 5px 3px -3px rgba(0, 0, 0, 0.25);
    margin-bottom: 2rem;
}
.simple-header {
    border-bottom: none;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
}
</style>
