import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import customer from './modules/customer.store'

const store = new Vuex.Store({
    modules: {
      customer
    }
});

store.$axios = $axios;

export default store;
