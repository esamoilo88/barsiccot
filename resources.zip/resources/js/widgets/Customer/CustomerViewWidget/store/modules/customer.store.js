export default {
    namespaced: true,
    state: {
        customer: {},
        externalSegment: [],
        internalSegment: []
    },
    mutations: {
        SET_CUSTOMER(state, customer) {
            state.customer = {...customer};
        },
        SET_SEGMENTS(state, segments) {
            state.internalSegment = segments.internal_customer_segment;
            state.externalSegment = segments.external_customer_segment;
        }
    },
    actions: {
        setCustomerData(context, data) {
            context.commit('SET_CUSTOMER', data);
        },
        setSegmentsOptions(context, segments) {
            context.commit('SET_SEGMENTS', segments);
        }
    }
}
