<template>
    <div class="simple-box">
        <div class="mb-5">
            <div class="row no-gutters">
                <div class="col">
                    {{ user.displayName }}
                    <div class="text-muted">{{ user.department }}</div>
                </div>
                <div class="col-auto">
                    <button class="btn btn-link" @click="$emit('delete', index)">
                        <i class="icon-action-remove-default"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <b-form-radio-group
                :id="getUniqName('radio-mode-')"
                v-model="user.mode"
                :options="radioManageModes"
                :name="getUniqName('radio-mode-')"
                stacked
            ></b-form-radio-group>
        </div>

        <template v-if="isEditMode">
            <div class="mb-3">
                <FormSelect
                    v-model="user.roleId"
                    :name="getUniqName('role-')"
                    label-text="Rolle*"
                    :select-id="getUniqName('role-')"
                    :options="roles"
                    :error-conditions="errorConditions.roleId"
                />
            </div>

            <div class="mb-3">
                <FormSelect
                    v-model="user.roleInfoId"
                    :name="getUniqName('roleinfo-')"
                    label-text="Funktionstext"
                    :select-id="getUniqName('roleinfo-')"
                    :options="roleinfo"
                />
            </div>

            <b-form-checkbox
                switch
                v-model="user.representative"
                :name="getUniqName('representative-')"
            >
                Vertreter
            </b-form-checkbox>
        </template>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckbox, BFormRadioGroup} from "bootstrap-vue";
import {requiredIf} from "vuelidate/lib/validators";
import {User} from "res/js/widgets/Admin/MembersWidget/entities";

export default {
    components: {BFormCheckbox, FormSelect, BFormRadioGroup},
    props: {
        user: {
            type: User,
            required: true
        },
        roles: {
            type: Array,
            default: () => {
                return [];
            }
        },
        roleinfo: {
            type: Array,
            default: () => {
                return [];
            }
        },
        index: {
            type: Number,
            required: true
        }
    },
    computed: {
        isEditMode() {
            return this.user.isEditMode();
        },
        errorConditions() {
            return {
                roleId: [
                    {
                        name: 'roleId-required',
                        condition: this.$v.user.roleId.$dirty && !this.$v.user.roleId.required,
                        text: this.$t.__('validation.required', {attribute: 'Rolle'})
                    }
                ]
            }
        }
    },
    data() {
        return {
            radioManageModes: [
                {text: 'Mitglied hinzufügen', value: 'edit'},
                {text: 'Mitglied löschen', value: 'delete'}
            ],
        }
    },
    methods: {
        getUniqName(name) {
            return name + `${this.user.benutzerId}-${this.index}`;
        }
    },
    validations: {
        user: {
            roleId: {
                required: requiredIf(function () {
                    return this.isEditMode;
                })
            },
        }
    }
}
</script>
