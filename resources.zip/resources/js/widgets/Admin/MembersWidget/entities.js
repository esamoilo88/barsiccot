export class User {
    constructor(displayName, department, benutzerId, roleId = null, roleInfoId = null, representative = false, mode = 'edit') {
        this.displayName = displayName;
        this.department = department;
        this.benutzerId = benutzerId;
        this.roleId = roleId;
        this.roleInfoId = roleInfoId;
        this.representative = representative;
        this.mode = mode;
    }

    isEditMode() {
        return this.mode === 'edit';
    }
}
