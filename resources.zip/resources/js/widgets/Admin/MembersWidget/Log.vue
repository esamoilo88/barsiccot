<template>
    <div class="simple-box">
        <div class="mb-5 row no-gutters align-items-center justify-content-between">
            <div class="col">
                <i class="icon-content-clock-default"></i>
                Deine Änderungen befinden sich nun in der Warteschlange
            </div>

            <div class="col-auto text-nowrap">
                <button class="btn btn-link" @click="getLog">
                    <i class="icon-action-refresh-default"></i>
                    Aktualisieren
                </button>
                <button class="btn btn-link" @click="$emit('back')">
                    <i class="icon-navigation-left-default"></i>
                    Zurück
                </button>
            </div>
        </div>

        <b-overlay :show="pending">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Zeitpunkt</th>
                            <th>Nachricht</th>
                            <th>SIN</th>
                            <th>Benutzer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in log">
                            <td>{{ formatDate(item.timestamp.date, 'DD.MM.YYYY HH:mm') }}</td>
                            <td>{{ item.logText }}</td>
                            <td>{{ item.simpleId }}</td>
                            <td>{{ item.nachname }}, {{ item.vorname }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BOverlay} from "bootstrap-vue";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    components: {BOverlay},
    mixins: [DatesProcessing],
    data() {
        return {
            log: [],
            pending: false
        }
    },
    async mounted() {
        await this.getLog();
    },
    methods: {
        async getLog() {
            this.pending = true;

            try {
                const response = await this.$axios.get('/admin/members/log');

                this.log = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>
