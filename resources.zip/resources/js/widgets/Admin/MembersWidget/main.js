import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Index from "./Index";
import {ModalPlugin} from 'bootstrap-vue';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$axios = $axios;
Vue.prototype.$t = t;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);

export default new Vue({
    el: "#admin-members-widget", //resources/views/App/Admin/Members/index.blade.php
    components: {
        Index
    }
});
