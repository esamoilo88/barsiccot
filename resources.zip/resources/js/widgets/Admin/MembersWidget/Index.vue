<template>
    <div>
        <Log v-if="logMode" @back="toFormMode" />

        <b-overlay v-else :show="pending">
            <div class="simple-box mb-3">
                <div>Schritt 1</div>
                <div class="mb-3">Vorhaben auswählen</div>

                <div class="row no-gutters mb-3">
                    <div class="col-24 col-lg-12">
                        <div class="form-group">
                            <FormTextArea
                                v-model="form.simpleIds"
                                @input="trim"
                                name="simpleIds"
                                input-id="simpleIds-input"
                                label-text="SINs*"
                                :error-conditions="errorConditions.simpleIds"
                            />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <button class="btn btn-primary" @click="toUsersSearch">Weiter</button>

                    <div class="pl-3">
                        {{ simplesCount }}
                    </div>
                </div>
            </div>

            <div v-if="showUsersSearch">
                <div class="mb-5">
                    <Users ref="users" />
                </div>

                <div>
                    <button class="btn btn-primary" @click="submit">Fertigstellen</button>
                </div>
            </div>

        </b-overlay>
    </div>
</template>

<script>
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {BOverlay} from "bootstrap-vue";
import {helpers, required} from "vuelidate/lib/validators";
import Users from "./Users";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import Log from './Log';

const simpleIdsList = helpers.regex('simpleIdsList', /^(\d{7})((\s?)*,(\s?)*\d{7})*$/);

export default {
    components: {BOverlay, FormTextArea, Users, Log},
    mixins: [ConfirmationModal],
    data() {
        return {
            pending: false,
            form: {
                simpleIds: null
            },
            logMode: false,
            showUsersSearch: false
        }
    },
    computed: {
        errorConditions() {
            return {
                simpleIds: [
                    {
                        name: 'simpleIds-regex',
                        condition: !this.$v.form.simpleIds.simpleIdsList,
                        text: 'Ungültig. Beispiel: 1234567,1234567'
                    },
                    {
                        name: 'simpleIds-required',
                        condition: this.$v.form.simpleIds.$dirty && !this.$v.form.simpleIds.required,
                        text: this.$t.__('validation.required', {attribute: 'Simple-IDs'})
                    }
                ]
            }
        },
        simplesCount() {
            try {
                return this.form.simpleIds.split(',').filter(item => {
                    return RegExp("\\d{7}").test(item.trim());
                }).length + ' Vorhaben ausgewählt';
            } catch (e) {
                return null;
            }
        }
    },
    methods: {
        async submit() {
            const confirmed = await this.showConfirmationModal({
                title: 'Mitglieder verwalten',
                message: `Bestätige die ausgewählten Änderungen`,
                okTitle: 'Fertigstellen',
                okVariant: 'primary',
            });

            if (!confirmed) return;

            if (!this.$refs.users.validate() || this.$v.$anyError) return;

            const form = this.$refs.users.getUsers();
            form.simpleIds = this.form.simpleIds.split(',');

            try {
                await this.$axios.post('/admin/members', form)

                window.flash.success('Aktionen in Warteschlange');

                this.logMode = true;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        toUsersSearch() {
            this.$v.$touch();

            if (this.$v.$anyError) return;

            this.showUsersSearch = true;
        },
        trim() {
            if (this.form.simpleIds) {
                return this.form.simpleIds = this.form.simpleIds.trim();
            }

            return this.form.simpleIds;
        },
        toFormMode() {
            this.logMode = false;

            this.form.simpleIds = null;
            this.showUsersSearch = false;

            this.$v.$reset();
        }
    },
    validations: {
        form: {
            simpleIds: {required, simpleIdsList},
        }
    }
}
</script>
