<template>
    <div class="simple-box">
        <div>Schritt 2</div>
        <div class="mb-3">Aktionen auswählen</div>

        <div class="mb-3">
            <PeopleSearch
                ref="search"
                type="simple"
                label="Benutzersuche*"
                :multiple="false"
                @user-added="addUser"
            />
        </div>

        <div class="row user-cards">
            <div class="col-12 col-xl-6 mb-3" v-for="(user, index) in users">
                <UserCard
                    ref="user"
                    :key="index"
                    :index="index"
                    :user="user"
                    :roles="roles"
                    :roleinfo="roleinfo"
                    @delete="deleteUser" />
            </div>
        </div>
    </div>
</template>

<script>
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import UserCard from "res/js/widgets/Admin/MembersWidget/UserCard";
import {User} from "res/js/widgets/Admin/MembersWidget/entities";

export default {
    components: {PeopleSearch, UserCard},
    data() {
        return {
            users: [],
            roles: [],
            roleinfo: []
        }
    },
    async mounted() {
        await this.getRoles();
    },
    methods: {
        addUser(user) {
            this.users.push(
                new User(user.display_name, user.department, user.benutzerId)
            );
        },
        deleteUser(index) {
            this.users.splice(index, 1);
        },
        async getRoles() {
            try {
                const response = await this.$axios.get('/roles');
                const roles = [];

                response.data.roles.forEach(item => {
                    roles.push({
                        id: item.role_id,
                        text: item.role_long
                    });
                });

                this.roles = roles;
                const roleinfo = [];

                response.data.roleinfo.forEach(item => {
                    roleinfo.push({
                        id: item.roleinfo_id,
                        text: item.roleinfo_name
                    });
                });

                this.roleinfo = roleinfo;
            } catch (error) {
                return [];
            }
        },
        validate() {
            let valid = true;

            this.$refs.user.forEach(user => {
                user.$v.$touch();

                if (user.$v.$anyError) {
                    valid = false;
                }
            });

            return valid;
        },
        getUsers() {
            const toUpdateOrCreate = [];
            const toDelete = [];

            this.users.forEach(user => {
                if (user.isEditMode()) {
                    toUpdateOrCreate.push(user);
                } else {
                    toDelete.push(user);
                }
            });

            return {
                toUpdateOrCreate,
                toDelete
            };
        }
    }
}
</script>

<style lang="scss" scoped>
.user-cards {
    margin-left: -15px;
    margin-right: -15px;
}
</style>
