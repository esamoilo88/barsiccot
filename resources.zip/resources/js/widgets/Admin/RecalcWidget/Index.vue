<template>
    <b-overlay :show="pending">
        <div class="simple-box">
            <div class="row no-gutters">
                <div class="col-24 col-lg-12">
                    <div class="form-group">
                        <FormTextArea
                            v-model="form.simpleIds"
                            name="simpleIds"
                            input-id="simpleIds-input"
                            label-text="Simple-IDs"
                            :error-conditions="ec.simpleIds"
                        />
                    </div>
                </div>
            </div>

            <div>
                <div class="recalc-options">
                    <div>
                        <button class="btn btn-primary" @click="recalcTotals">Kalkulation neu berechnen</button>
                    </div>
                    <div>Berechnet die Gesamtbeträge des Angebots derzeit aktiven VK-Version neu</div>
                </div>

                <div class="recalc-options">
                    <div>
                        <button class="btn btn-primary" @click="recalcILV">ILV neu validieren</button>
                    </div>
                    <div>Berechnet das Feld ilv_valid für ILV-relevante Kosteneinträge neu</div>
                </div>

                <div class="recalc-options">
                    <div>
                        <button class="btn btn-primary" @click="recalcFinanceBalance">Finanzbeträge neu berechnen</button>
                    </div>
                    <div>Berechnet die Gesamtbeträge des Auftrags neu</div>
                </div>

                <div class="recalc-options">
                    <div>
                        <button class="btn btn-primary" @click="recalcFinanceStatus">Finanzstatus neu berechnen</button>
                    </div>
                    <div>Berechnet die Finanzstatus des Auftrags neu</div>
                </div>
            </div>
        </div>
    </b-overlay>
</template>

<script>
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {helpers, required} from 'vuelidate/lib/validators'
import {BOverlay} from "bootstrap-vue";

const simpleIdsList = helpers.regex('simpleIdsList', /^(\d{7})(,(\s?)*\d{7})*$/);

export default {
    components: {FormTextArea, BOverlay},
    data() {
        return {
            form: {
                simpleIds: null
            },
            pending: false
        }
    },
    computed: {
        ec() {
            return {
                simpleIds: [
                    {
                        name: 'simpleIds-regex',
                        condition: !this.$v.form.simpleIds.simpleIdsList,
                        text: 'Ungültig. Beispiel: 1234567,1234567'
                    },
                    {
                        name: 'simpleIds-required',
                        condition: this.$v.form.simpleIds.$dirty && !this.$v.form.simpleIds.required,
                        text: this.$t.__('validation.required', {attribute: 'Simple-IDs'})
                    }
                ]
            }
        }
    },
    methods: {
        async recalcTotals() {
            await this.submit('/admin/calculations/recalc/totals');
        },
        async recalcILV() {
            await this.submit('/admin/calculations/recalc/ilv');
        },
        async recalcFinanceBalance() {
            await this.submit('/admin/calculations/recalc/finance/balance');
        },
        async recalcFinanceStatus() {
            await this.submit('/admin/calculations/recalc/finance/status');
        },
        async submit(url) {
            if (this.pending) return;

            this.$v.$touch();

            if (this.$v.$invalid) return;

            this.pending = true;

            try {
                await this.$axios.put(url, this.form);

                window.flash.success('Erfolgreich neu berechnet');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    },
    validations: {
        form: {
            simpleIds: {required, simpleIdsList},
        }
    }
}
</script>

<style lang="scss" scoped>
.recalc-options {
    display: grid;
    grid-template-columns: minmax(100px, 250px) 1fr;
    margin-bottom: 1rem;
    align-items: center;
    gap: 3rem;

    .btn {
        width: 100%;
    }
}
</style>
