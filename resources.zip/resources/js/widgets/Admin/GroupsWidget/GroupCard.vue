<template>
    <div class="simple-box">
        <div>
            <div class="row no-gutters mb-3">
                <div class="col">
                    {{ group.name }}
                    <div class="text-muted">{{ group.bereich.teamKurz }}- {{group.bereich.teamLang }}</div>
                </div>
                <div class="col-auto">
                    <button class="btn btn-link" @click="$emit('delete', group)">
                        <i class="icon-action-remove-default"></i>
                    </button>
                </div>
            </div>
            <div class="mb-3">
                <div>Rolle: {{defVal(group.role.roleLong, '-')}}</div>
                <div>Funktionstext: {{defVal(group.roleInfo.name, '-')}}</div>
            </div>

            <div class="mb-3">
                <b-form-radio-group
                    :id="`radio-edit-${group.id}`"
                    v-model="radioManageMode"
                    :options="radioManageModes"
                    :name="`radio-edit-${group.id}`"
                    stacked
                ></b-form-radio-group>
            </div>
        </div>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckbox, BFormRadioGroup} from "bootstrap-vue";
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";

export default {
    components: {BFormCheckbox, FormSelect, BFormRadioGroup},
    mixins: [ScalarsProcessing],
    props: {
        group: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            groupId: this.group.id,
            radioManageMode: 'create',
            radioManageModes: [
                {text: 'Gruppe hinzufügen', value: 'create'},
                {text: 'Gruppe löschen', value: 'delete'}
            ],
        }
    }
}
</script>
