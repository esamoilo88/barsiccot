<template>
    <div class="simple-box">
        <div>Schritt 2</div>
        <div class="mb-3">Aktionen auswählen</div>

        <b-overlay :show="pending">
            <div class="mb-3 w-25">
                <FormSelect
                    v-model="group"
                    :options="groupOptions"
                    label-text="Gruppe*"
                    name="gruppe"
                    @select="addGroup"
                    select-id="gruppe"
                    :error-conditions="errorConditions.group"
                />
            </div>
        </b-overlay>

        <div class="row group-cards">
            <div class="col-12 col-xl-8 mb-3" v-for="group in groupsAction">
                <GroupCard ref="group" :group="group" @delete="deleteGroup"/>
            </div>
        </div>
    </div>
</template>

<script>
import GroupCard from "./GroupCard";
import FormSelect from '@comp/FormSelect/FormSelect';
import {required} from "vuelidate/lib/validators";
import {BOverlay} from "bootstrap-vue";

export default {
    components: {FormSelect,BOverlay, GroupCard},
    data() {
        return {
            pending: false,
            group: null,
            groups: [],
            roles: [],
            roleinfo: [],
            groupsAction: []
        }
    },
    computed: {
        groupOptions() {
            return this.groups.map(group => ({
                id: group.id,
                text: group.name
            }));
        },
        errorConditions() {
            return {
                group: [
                    {
                        name: 'group-required',
                        condition: this.$v.group.$dirty && !this.$v.group.required,
                        text: this.$t.__('validation.required', {attribute: 'Gruppe'})
                    }
                ]
            }
        }

    },
    async mounted() {
        await this.getGroups();
    },
    methods: {
        async getGroups() {
            this.pending = true;
            try {
                const response = await this.$axios.get(`/admin/groups/list`);
                this.groups = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
            this.pending = false;

        },
        addGroup(groupId) {
            let selectedGroup = this.groups.filter(el => el.id == groupId)[0];
            let index = this.groupsAction.findIndex(item => item.id == groupId);

            if (index == -1) {
                this.groupsAction.push(selectedGroup);
            }
        },
        deleteGroup(group) {
            const index = this.groupsAction.findIndex(item => item.id === group.id);

            if (index > -1) {
                this.groupsAction.splice(index, 1);
            }
            if(this.groupsAction.length == 0){
                this.group = null;
            }
        },
        validate() {
            let valid = true;

            this.$v.$touch();

            if (this.$v.$anyError) {
                valid = false;
            }
            console.log('valid', valid)
            return valid;
        },
        getGroupsToHandle() {
            const toCreate = [];
            const toDelete = [];

            this.$refs.group.forEach(group => {
                if (group.radioManageMode == 'create') {
                    toCreate.push({groupId: group.groupId});
                } else {
                    toDelete.push({groupId: group.groupId});
                }
            });

            return {
                toCreate,
                toDelete
            };
        }
    },
    validations: {
        group: {required}
    }
}
</script>

<style lang="scss" scoped>
.group-cards {
    margin-left: -15px;
    margin-right: -15px;
}
</style>
