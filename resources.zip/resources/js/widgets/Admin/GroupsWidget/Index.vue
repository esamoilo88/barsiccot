<template>
    <div>
        <Log v-if="logMode" @back="toFormMode" />

        <b-overlay v-else :show="pending">
            <div class="simple-box mb-3">
                <div>Schritt 1</div>
                <div class="mb-3">Vorhaben auswählen</div>

                <div class="row no-gutters mb-3">
                    <div class="col-24 col-lg-12">
                        <div class="form-group">
                            <FormTextArea
                                v-model="form.simpleIds"
                                @input="trim"
                                name="simpleIds"
                                input-id="simpleIds-input"
                                label-text="SINs*"
                                :error-conditions="errorConditions.simpleIds"
                            />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <button class="btn btn-primary" @click="toActionGroup">Weiter</button>

                    <div class="pl-3">
                        {{ simplesCount }}
                    </div>
                </div>
            </div>

            <div v-if="actionMode">
                <Groups ref="groups" class="mb-3"/>
                <button class="btn btn-primary" @click="submit" :disabled="pending">Fertigstellen</button>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {BOverlay} from "bootstrap-vue";
import {helpers, required} from "vuelidate/lib/validators";
import Groups from "./Groups";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import Log from './Log';

const simpleIdsList = helpers.regex('simpleIdsList', /^(\d{7})((\s?)*,(\s?)*\d{7})*$/);

export default {
    components: {BOverlay, FormTextArea, Groups, Log},
    mixins: [ConfirmationModal],
    data() {
        return {
            pending: false,
            actionMode: false,
            form: {
                simpleIds: null
            },
            logMode: false,
        }
    },
    computed: {
        errorConditions() {
            return {
                simpleIds: [
                    {
                        name: 'simpleIds-regex',
                        condition: !this.$v.form.simpleIds.simpleIdsList,
                        text: 'Ungültig. Beispiel: 1234567,1234567'
                    },
                    {
                        name: 'simpleIds-required',
                        condition: this.$v.form.simpleIds.$dirty && !this.$v.form.simpleIds.required,
                        text: this.$t.__('validation.required', {attribute: 'Simple-IDs'})
                    }
                ]
            }
        },
        simplesCount() {
            try {
                return this.form.simpleIds.split(',').filter(item => {
                    return RegExp("\\d{7}").test(item.trim());
                }).length + ' Vorhaben ausgewählt';
            } catch (e) {
                return null;
            }
        }
    },
    methods: {
        async submit() {
            if (!this.$refs.groups.validate()) return;

            const confirmed = await this.showConfirmationModal({
                title: 'Gruppen verwalten',
                message: `Bestätige die ausgewählten Änderungen`,
                okTitle: 'Fertigstellen',
                okVariant: 'primary'
            });

            if (!confirmed) return;
            const form = this.$refs.groups.getGroupsToHandle();
            form.simpleIds = this.form.simpleIds.split(',');
            try {
                this.pending = true;
                await this.$axios.post('/admin/groups', form)

                this.logMode = true;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
            this.pending = false;
        },
        toActionGroup() {
            this.$v.$touch();

            if (this.$v.$anyError) return;

            this.actionMode = true;
        },
        trim() {
            if (this.form.simpleIds) {
                return this.form.simpleIds = this.form.simpleIds.trim();
            }

            return this.form.simpleIds;
        },
        toFormMode() {
            this.logMode = false;

            this.form.simpleIds = null;
            this.actionMode = false;

            this.$v.$reset();
        }

    },
    validations: {
        form: {
            simpleIds: {required, simpleIdsList},
        }
    }
}
</script>
