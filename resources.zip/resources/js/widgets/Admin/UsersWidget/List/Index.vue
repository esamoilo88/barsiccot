<template>
    <div class="simple-box">
        <List ref="list" @edit="showEdit" @create="showCreate" />

        <Create v-if="createDialog.show" :show="createDialog.show" @hide="hideCreate" />
        <Edit v-if="editDialog.show" :show="editDialog.show" :user="editDialog.user" @hide="hideEdit" />
    </div>
</template>

<script>
import List from './components/List';
import Create from './components/Create';
import Edit from './components/Edit';

export default {
    components: {List, Create, Edit},
    data() {
        return {
            createDialog: {
                show: false
            },
            editDialog: {
                user: null,
                show: false
            }
        }
    },
    methods: {
        showCreate() {
            this.createDialog.show = true;
        },
        showEdit(user) {
            this.editDialog.user = user;
            this.editDialog.show = true;
        },
        hideCreate(update) {
            this.createDialog.show = false;

            if (update) {
                this.$refs.list.updateTable();
            }
        },
        hideEdit(update) {
            this.editDialog.user = null;
            this.editDialog.show = false;

            if (update) {
                this.$refs.list.updateTable();
            }
        }
    }
}
</script>
