import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Index from "./Index";
import {ModalPlugin} from 'bootstrap-vue';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import vSelect from "vue-select";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$axios = $axios;
Vue.prototype.$t = t;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);

Vue.component("v-select", vSelect);

export default new Vue({
    el: "#admin-users-widget", //resources/views/App/Admin/Users/index.blade.php
    components: {
        Index
    }
});
