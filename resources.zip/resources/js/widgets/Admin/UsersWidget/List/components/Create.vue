<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide(false)"
            title-dialog="Neuer Benutzer"
            modal-class="create-user-dialog"
            :hide-footer="true"
            scrollable>
            <b-overlay :show="pending">
                <Form @submit="create" @hide="hide(false)" />
            </b-overlay>
        </modal-dialog>
    </div>
</template>

<script>
import Form from './Form';
import {BOverlay} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";

export default {
    components: {Form, BOverlay, ModalDialog},
    data() {
        return {
            pending: false
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        }
    },
    methods: {
        hide(update) {
            this.$emit('hide', update);
        },
        async create(form) {
            this.pending = true;

            try {
                await this.$axios.post('/admin/users', form);

                window.flash.success('Benutzer wurde erstellt');

                this.hide(true);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>
