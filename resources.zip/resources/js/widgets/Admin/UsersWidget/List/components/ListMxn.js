export default {
    data() {
        return {
            pending: false,
            tableConf: {
                currentPage: 1,
                totalRows: 0,
                perPage: 20,
                sortBy: null,
                sortDesc: true,
                fields: [
                    {key: 'fullName', label: 'Name und Bereich'},
                    {key: 'merkmale', label: 'Merkmale'},
                    {key: 'contact', label: 'Kontakt'},
                    {key: 'options', label: 'Optionen'},
                ],
                filters: [
                    {
                        field: "search",
                        type: "text",
                        settings: {label: "Suchen..."}
                    }
                ],
            }
        }
    },
    methods: {
        async itemsProvider(ctx) {
            this.pending = true;

            try {
                const response = await this.$axios.post('/admin/users/list', ctx);

                this.tableConf.totalRows = response.data.total;
                this.tableConf.perPage = response.data.perPage;

                this.pending = false;

                return response.data.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async updateTable() {
            await this.$refs.table.itemsProviderProxy(this.$refs.table.getContext());
        },
    }
}
