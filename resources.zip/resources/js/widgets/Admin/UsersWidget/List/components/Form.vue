<template>
    <div>
        <b-overlay :show="pending">
            <div class="simple-box mb-5">
                <div class="mb-3">
                    <div class="mb-3 font-weight-bold">Benutzerdaten</div>

                    <div>Bitte gebe die E-Mail Adresse des Benutzers ein um die restlichen Daten zu vervollständigen</div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.email"
                            @submit="searchUser"
                            @blur="updateUsername"
                            name="email"
                            input-id="email-input"
                            label-text="E-Mail Adresse*"
                            :error-conditions="errorConditions.email"
                        />
                    </div>

                    <div class="form-group">
                        <FormSelect
                            v-model="form.anrede"
                            name="anrede"
                            select-id="anrede-input"
                            :options="anredeOptions"
                            label-text="Anrede"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.vorname"
                            name="vorname"
                            input-id="vorname-input"
                            label-text="Vorname*"
                            :error-conditions="errorConditions.vorname"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.nachname"
                            name="nachname"
                            input-id="nachname-input"
                            label-text="Nachname*"
                            :error-conditions="errorConditions.nachname"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.username"
                            name="username"
                            input-id="username-input"
                            label-text="Username*"
                            :error-conditions="errorConditions.username"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.firma"
                            name="firma"
                            input-id="firma-input"
                            label-text="Firma"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.orge"
                            name="orge"
                            input-id="orge-input"
                            label-text="OrgE"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.ressort"
                            name="ressort"
                            input-id="ressort-input"
                            label-text="Ressort"
                        />
                    </div>

                    <div class="form-group">
                        <FormInput
                            v-model="form.telNr"
                            name="telNr"
                            input-id="telNr-input"
                            label-text="Telefonnummer"
                        />
                    </div>

                    <div class="form-group">
                        <v-select
                            @search="findDepartment"
                            :options="bereichOptions"
                            v-model="form.bereichId"
                            label="text"
                            :reduce="item => item.id"
                            placeholder="Bereich"
                        >
                            <template slot="no-options">Keine Daten gefunden.</template>
                        </v-select>
                    </div>

                    <div class="form-group">
                        <FormTextArea
                            v-model="form.internalNotes"
                            name="internalNotes"
                            input-id="internalNotes-input"
                            label-text="Merkmale"
                        />
                    </div>

                    <div v-if="editmode" class="form-group">
                        <FormInput
                            v-model="form.loginCount"
                            name="loginCount"
                            input-id="loginCount-input"
                            label-text="Anzahl Passwort falsch eingegeben"
                            type="number"
                        />
                    </div>

                    <div class="form-group">
                        <div v-if="editmode" class="form-check">
                            <input v-model="form.changePassword" class="form-check-input" type="checkbox" id="changePassword-input">
                            <label class="form-check-label" for="changePassword-input">
                                Passwort Änderung notwendig
                            </label>
                        </div>
                        <div class="form-check">
                            <input v-model="form.isAdmin" class="form-check-input" type="checkbox" id="isAdmin-input">
                            <label class="form-check-label" for="isAdmin-input">
                                Administrator
                            </label>
                        </div>
                        <div class="form-check">
                            <input v-model="form.blocked" class="form-check-input" type="checkbox" id="blocked-input">
                            <label class="form-check-label" for="blocked-input">
                                Gesperrt
                            </label>
                        </div>
                        <div class="form-check">
                            <input v-model="form.notification" class="form-check-input" type="checkbox" value="" id="notification-input">
                            <label class="form-check-label" for="notification-input">
                                Benachrichtigung
                            </label>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="mb-3 font-weight-bold">Berechtigungen</div>

                    <div v-for="right in rights" class="form-check">
                        <input v-model="form.rechte" :value="right.rechteId" class="form-check-input" type="checkbox" :id="`rechte-input-${right.rechteId}`">
                        <label class="form-check-label" :for="`rechte-input-${right.rechteId}`">
                            <strong>{{ right.group }}</strong> - {{ right.bezeichnung }}
                        </label>
                    </div>
                </div>

                <div>
                    <div class="mb-3 font-weight-bold">Gruppen</div>
                    <div v-for="group in groups" class="form-check">
                        <input v-model="form.userGroup" :value="group.id" class="form-check-input" type="checkbox" :id="`group-input-${group.id}`">
                        <label class="form-check-label" :for="`group-input-${group.id}`">
                            {{ group.name }}
                        </label>
                    </div>
                </div>
            </div>

            <div class="text-center">
                <button v-if="editmode" @click="searchUser" class="btn btn-info">Benutzerdaten aktualisieren</button>
                <button @click="submit" class="btn btn-primary">Speichern</button>
                <button @click="$emit('hide')" class="btn btn-secondary">Abbrechen</button>
            </div>

        </b-overlay>
    </div>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import {required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {createOptions} from "@helpers/Form/InputsHelper";
import {BOverlay} from 'bootstrap-vue';
import FormTextArea from "@comp/FormTextArea/FormTextArea";

export default {
    components: {FormInput, FormSelect, BOverlay, FormTextArea},
    mixins: [Validation],
    props: {
        editmode: {
            type: Boolean,
            default: false
        },
        user: {
            type: Object,
            default: null
        }
    },
    data() {
        return {
            form: {
                anrede: null,
                vorname: null,
                nachname: null,
                username: null,
                firma: null,
                orge: null,
                ressort: null,
                email: null,
                telNr: null,
                bereichId: null,
                rechte: [],
                userGroup: [],
                changePassword: false,
                isAdmin: false,
                blocked: false,
                notification: true,
                loginCount: null,
                internalNotes: null,
            },
            rights: [],
            groups: [],
            bereichOptions: [],
            anredeOptions: [
                {id: 'Herr', text: 'Herr'},
                {id: 'Frau', text: 'Frau'}
            ],
            pending: false,
            showValidationErrors: true,
            usernameEditable: null
        }
    },
    computed: {
        errorConditions() {
            return {
                vorname: [
                    {
                        name: 'vorname-required',
                        condition: this.isInvalid('vorname', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Vorname'})
                    },
                ],
                nachname: [
                    {
                        name: 'nachname-required',
                        condition: this.isInvalid('nachname', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Nachname'})
                    },
                ],
                email: [
                    {
                        name: 'email-required',
                        condition: this.isInvalid('email', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'E-Mail Adresse'})
                    },
                ],
                username: [
                    {
                        name: 'username-required',
                        condition: this.isInvalid('username', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'username'})
                    },
                ],
            }
        }
    },
    async mounted() {
        if (this.user) {
            const form = {
                anrede: this.user.anrede,
                vorname: this.user.vorname,
                nachname: this.user.nachname,
                username: this.user.username,
                firma: this.user.firma,
                orge: this.user.orgEinheit,
                ressort: this.user.ressort,
                email: this.user.email,
                telNr: this.user.telNr,
                bereichId: this.user.bereich ? this.user.bereich.bereichId : null,
                rechte: this.user.backendRechtes.map(item => item.rechteId),
                userGroup: (this.user.backendGroup) ?this.user.backendGroup.map(item => item.id):[],
                isAdmin: this.user.admin,
                blocked: this.user.blocked,
                notification: this.user.userInformiert,
                internalNotes: this.user.internalNotes,
                loginCount: this.user.loginCount
            };

            await this.setForm(form);
        }
        await this.getGroups();
        await this.getRights();
    },
    methods: {
        async getRights() {
            try {
                const response = await this.$axios.get('/admin/users/rights');

                this.rights = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async getGroups() {
            try {
                const response = await this.$axios.get(`/admin/groups/list`);
                this.groups = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async findDepartment(search) {
            if (search.length < 4) return;

            try {
                const response = await this.$axios.get('/admin/users/departments', {
                    params: {search}
                });

                this.bereichOptions = createOptions(
                    response.data,
                    (item) => item.bereichId,
                    (item) => item.bezeichnung
                );

                if (this.bereichOptions.length) {
                    const bereich = this.bereichOptions[0];

                    this.form.bereichId = bereich.id;
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        submit() {
            this.$v.form.$touch();

            if (this.$v.form.$invalid) return;

            this.$emit('submit', this.form)
        },
        async searchUser() {
            if (this.pending || this.$v.form.email.$invalid) {
                this.$v.form.email.$touch();

                return;
            }

            this.pending = true;

            try {
                const response = await this.$axios.post('/ldap/search', {search: this.form.email});

                if (response.data.length) {
                    window.flash.success('Benutzer wurde gefunden');

                    const user = response.data[0];

                    this.form.vorname = user.name;
                    this.form.nachname = user.surname;
                    this.form.firma = user.company;
                    this.form.orge = user.orge;
                    this.form.ressort = user.department;
                    this.form.telNr = user.phone;

                    await this.findDepartment(user.department);
                } else {
                    window.flash.error('Benutzer nicht gefunden');
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async setForm(form) {
            this.pending = true;

            this.form = {...this.form, ...form};

            this.pending = false;

            if (this.form.bereichId) {
                await this.findDepartment(this.form.bereichId);
            }
        },
        updateUsername() {
            if (this.usernameEditable === null) {
                this.usernameEditable = this.form.username ? false : true;
            }

            if (this.form.email && this.usernameEditable) {
                try {
                    this.form.username = this.form.email.substr(0, this.form.email.indexOf('@'));
                } catch (e) {}
            }
        }
    },
    validations: {
        form: {
            vorname: {required},
            nachname: {required},
            email: {required},
        }
    }
}
</script>

<style lang="scss">
@import "~vue-select/dist/vue-select.css";

.right-item {
    display: grid;
    grid-template-columns: 0fr 0fr;
    align-items: center;
    margin-right: 4px;
    margin-bottom: 4px;

    .icon-action-close-default {
        cursor: pointer;
    }
}

.vs__dropdown-toggle {
    height: 45px;
}

.vs__search {
    font-size: 1.125rem;
    color: #888;
}
</style>
