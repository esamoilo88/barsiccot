<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide(false)"
            title-dialog="Benutzer bearbeiten"
            modal-class="edit-user-dialog"
            :hide-footer="true"
            scrollable>
            <b-overlay :show="pending">
                <Form @submit="update" @hide="hide(false)" :user="user" editmode />
            </b-overlay>
        </modal-dialog>
    </div>
</template>

<script>
import Form from './Form';
import {BOverlay} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";

export default {
    components: {Form, BOverlay, ModalDialog},
    props: {
        user: {
            required: true,
            type: Object
        },
        show: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            pending: false
        }
    },
    methods: {
        hide(update) {
            this.$emit('hide', update);
        },
        async update(form) {
            this.pending = true;

            try {
                await this.$axios.put(`/admin/users/${this.user.benutzerId}`, form);

                window.flash.success('Benutzer wurde bearbeitet');

                this.hide(true);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>
