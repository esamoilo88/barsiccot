<template>
    <div>
        <table-simple
            ref="table"
            table-id="admin-users-list"
            :fields="tableConf.fields"
            :filters="tableConf.filters"
            :total-rows-prop="tableConf.totalRows"
            :per-page-prop="tableConf.perPage"
            :sort-by-prop="tableConf.sortBy"
            :sort-desc-prop="tableConf.sortDesc"
            :items-provider="itemsProvider"
        >
            <template v-slot:beforefilters>
                <div class="col pt-2">
                    <button @click="$emit('create')" class="btn btn-primary">
                        <span class="icon-action-add-default"></span>
                        Neuer Benutzer
                    </button>
                </div>
            </template>
            <template #cell(fullName)="data">
                <div>{{ data.item.nachnameVorname }}</div>
                <div class="text-muted">{{ data.item.bereich ? data.item.bereich.bezeichnung : ''}}</div>
            </template>

            <template #cell(merkmale)="data">
                <span v-if="data.item.admin" class="badge badge-primary">Admin</span>
                <span v-if="data.item.blocked" class="badge badge-danger">Gesperrt</span>
                <span v-else class="badge badge-success">Aktiv</span>
            </template>

            <template #cell(contact)="data">
                <div class="contact-item">
                    <span class="icon-communication-email-default"></span>
                    <a :href="`mailto:${data.item.email}`" class="text-primary">{{ data.item.email }}</a>
                </div>
                <div class="contact-item" v-if="data.item.telNr">
                    <span class="icon-communication-phone-number-default"></span>
                    {{ data.item.telNr }}
                </div>
            </template>

            <template #cell(options)="data">
                <div class="text-nowrap">
                    <ButtonIcon
                        @click="$emit('edit', data.item)"
                        icon-class="icon-action-edit-default"
                        variant="secondary"
                        title="Benutzer bearbeiten"
                        hint-position="top"
                    />
                    <ButtonIcon
                        :icon-class="data.item.blocked ? 'icon-content-unlock-default' : 'icon-content-lock-default'"
                        :variant="data.item.blocked ? 'success' : 'danger'"
                        :title="data.item.blocked ? 'Benutzer entsperren' : 'Benutzer sperren'"
                        hint-position="top"
                        @click="toggleLock(data.item)"
                    />
                </div>
            </template>
        </table-simple>
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ListMxn from "res/js/widgets/Admin/UsersWidget/List/components/ListMxn";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    components: {TableSimple, ButtonIcon},
    mixins: [ListMxn, ConfirmationModal],
    data() {
        return {
        }
    },
    methods: {
        async toggleLock(user) {
            if (this.pending) return;

            const result = await this.showConfirmationModal({
                message: user.blocked ? `Bitte bestätige die Entsperrung des Benutzers ${user.nachnameVorname}` : `Bitte bestätige die Sperrung des Benutzers ${user.nachnameVorname}`,
                title: user.blocked ? 'Benutzer entsperren' : 'Benutzer sperren',
                okTitle: user.blocked ? 'Benutzer entsperren' : 'Benutzer sperren',
                okVariant: user.blocked ? 'success' : 'danger',
            });

            if (!result) return;

            this.pending = true;

            try {
                await this.$axios.put(`/admin/users/${user.benutzerId}/lock/toggle`);

                window.flash.success(user.blocked ? 'Benutzer entsperrt' : 'Benutzer gesperrt');

                user.blocked = !user.blocked;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>

<style lang="scss">
.btn-success {
    .btn-icon__icon {
        color: white;
    }
}

.contact-item {
    white-space: nowrap;
    display: grid;
    grid-template-columns: 0fr 0fr;
    align-items: center;
    gap: 4px;

    span {
        font-size: 22px;
    }
}
</style>
