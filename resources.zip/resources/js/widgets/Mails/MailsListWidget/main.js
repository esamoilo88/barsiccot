import Vue from 'vue';
import vueDebounce from 'vue-debounce';
import {$axios} from 'res/js/boot';
import MailsListWidget from "res/js/widgets/Mails/MailsListWidget/MailsListWidget";

Vue.prototype.$axios = $axios;
Vue.use(vueDebounce);

export default new Vue({
    el: '#mails-list', //resources/views/App/Mails/list.blade.php
    components: {
        MailsListWidget
    }
});
