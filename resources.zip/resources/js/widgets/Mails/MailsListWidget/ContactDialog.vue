<template>
    <modal-dialog
        @hideModal="$emit('hide')"
        :is-visible="visible"
        modal-class="contact-dialog"
        :title-dialog="title"
    >
        <UserCard :email="contact.email" />

        <template #footer="{methods}">
            <div class="text-center w-100">
                <button @click="$emit('hide')" class="btn btn-secondary">Schließen</button>
            </div>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import UserCard from "@comp/Common/Ldap/UserCard";

export default {
    components: {UserCard, ModalDialog},
    props: {
        visible: {
            required: true,
            type: Boolean
        },
        contact: {
            required: true,
            type: Object
        }
    },
    computed: {
        title() {
            return `Eigenschaften von ${this.contact.name ? this.contact.name : null}`;
        }
    }
}
</script>
