<template>
    <div>
        <headline :sin="data.sin" :customer="data.customer" :project-name="data.projectName"></headline>
        <div class="content">
            <table-simple
                table-id="projects-list-table"
                :fields="fields"
                :filters="filters"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="itemsProvider"
            >
                <template #cell(subject)="data">
                    <truncated-text
                        :text="data.item.subject"
                        title="Betreff anzeigen"
                        :width="400"/>
                </template>
                <template #cell(optionen)="row">
                    <ButtonIcon
                        icon-class="icon-communication-email-default"
                        :id="'email-details-btn-' + row.item.mailId"
                        @click="showDetailsDialog(row.item.mailId)"
                        title="E-Mail anzeigen"
                    />
                </template>
            </table-simple>
            <a class="link" @click="redirectBack" href="">Zurück</a>
        </div>

        <MailDetails
            v-if="visibleMailId"
            :visible="isDetailsDialogVisible"
            :simple-id="data.sin"
            :mail-id="visibleMailId"
            @hide="hideDetailsDialog" />
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import Headline from "@comp/Headline/Headline";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import MailDetails from "./MailDetails";

export default {
    name: "mails-list-widget",
    components: {
        TruncatedText,
        TableSimple, ButtonIcon, Headline, MailDetails
    },
    props: {
        data: {
            type: Object
        }
    },
    data() {
        return {
            fields: [
                {key: "sentAt", label: "Gesendet am", sortable: true, sortDirection: 'desc', sortKey: 'sentAt'},
                {key: "from", label: "Von", sortable: false, sortKey: 'from'},
                {key: "to", label: "An", sortable: false, sortKey: 'to'},
                {key: "subject", label: "Betreff", sortable: false, sortKey: 'name', class: 'truncated'},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            filters: [
                {
                    field: "search",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'sentAt',
            sortDesc: true,
            totalRows: 0,
            perPage: 0,
            isDetailsDialogVisible: false,
            visibleMailId: null
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/mails/' + this.data.sin, ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        redirectBack() {
            history.go(-1);
        },
        showDetailsDialog(id) {
            this.visibleMailId = id;
            this.isDetailsDialogVisible = true;
        },
        hideDetailsDialog() {
            this.visibleMailId = null;
            this.isDetailsDialogVisible = false;
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
    ::v-deep .optionen-col {
        text-align: left;
    }

    ::v-deep th[role=columnheader] {
        color: $primary;

        &:last-child {
            color: black;
        }
    }

    .content {
        position: relative;
    }

    .link {
        position: absolute;
        right: 0;
        margin-right: 5px;
        top: 30px;
    }
</style>
