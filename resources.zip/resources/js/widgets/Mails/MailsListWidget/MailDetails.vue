<template>
    <div>
        <modal-dialog
            @hideModal="$emit('hide')"
            :is-visible="visible"
            modal-class="mail-details-dialog"
            title-dialog="E-Mail"
            :scrollable="true"
            size="lg"
        >
            <b-overlay :show="pending">
                <div class="row mb-4 no-gutters">
                    <div class="col">
                        <div class="font-weight-bold">Gesendet am</div>
                        {{ formatDate(mail.dateline, 'DD.MM.YYYY, HH:mm') }}
                    </div>
                    <div class="col">
                        <div class="font-weight-bold">Von</div>
                        <a href="#" @click="showContactDialog(mail.von, mail.von_name)">
                            {{ mail.von_name ? mail.von_name : mail.von }}
                        </a>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="mb-3">
                        <div class="font-weight-bold">An</div>
                        <div v-for="an in mail.an">
                            <a href="#" @click="showContactDialog(an.email, an.name)">{{ an.name }}</a>
                        </div>
                    </div>
                    <div>
                        <div class="font-weight-bold">CC</div>
                        <div v-for="cc in mail.cc">
                            <a href="#" @click="showContactDialog(cc.email, cc.name)">{{ cc.name }}</a>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="font-weight-bold">Anhang</div>
                    <div v-for="item in mail.attachments">
                        <a :href="item.url" download>{{ item.name }}</a>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="font-weight-bold">Betreff</div>
                    {{ mail.betreff }}
                </div>

                <div>
                    <div class="font-weight-bold">Nachricht</div>
                    <div v-html="mail.nachricht"></div>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <div class="text-center w-100">
                    <button @click="$emit('hide')" class="btn btn-secondary">Schließen</button>
                </div>
            </template>
        </modal-dialog>

        <ContactDialog v-if="selectedContact" :visible="isContactDialogVisible" :contact="selectedContact" @hide="hideContactDialog" />
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import ContactDialog from "./ContactDialog";
import {BOverlay} from 'bootstrap-vue';
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    components: {ModalDialog, ContactDialog, BOverlay},
    mixins: [DatesProcessing],
    props: {
        visible: {
            required: true,
            type: Boolean
        },
        simpleId: {
            required: true,
            type: String
        },
        mailId: {
            required: true,
            type: String
        },
    },
    data() {
        return {
            isContactDialogVisible: false,
            mail: {},
            selectedContact: null,
            pending: false
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        showContactDialog(email, name) {
            this.selectedContact = {email, name};
            this.isContactDialogVisible = true;
        },
        hideContactDialog() {
            this.selectedContact = null;
            this.isContactDialogVisible = false;
        },
        async getData() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/mails/${this.simpleId}/${this.mailId}`);

                this.mail = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
    }
}
</script>
