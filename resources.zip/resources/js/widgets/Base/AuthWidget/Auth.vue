<template>
    <div class="d-flex flex-column justify-content-between h-100">
        <div class="auth-pages-wrapper" :class="{'justify-content-center': slides.length == 0}">
            <AuthForm @changePage="changePage" v-if="activePage === 'auth-page'" :mycard="mycard"/>
            <Register @changePage="changePage" v-if="activePage === 'register-page'"/>
            <NewPassword @changePage="changePage" v-if="activePage === 'new-password-page'"/>
            <div class="slider-wrapper" v-if="slides.length > 0">
                <info-slider :slides="slides"></info-slider>
            </div>
        </div>
        <div class="auth-footer d-flex justify-content-between mt-auto">
            <span>© Deutsche Telekom IT</span>
            <div>
                <a href="https://yam.telekom.de/groups/simple" target="_blank" class="mr-2">YAM</a>
                <a href="#" target="_blank">Impressum</a>
            </div>
        </div>
    </div>
</template>

<script>
import AuthForm from './AuthForm';
import Register from './Register';
import NewPassword from './NewPassword';
import InfoSlider from './InfoSlider';

export default {
    name: "auth-widget",
    props: {
        slides: {
            type: Array
        },
        mycard: {
          type: String
        }
    },
    components: {
        AuthForm,
        InfoSlider,
        Register,
        NewPassword
    },
    data() {
        return {
            activePage: 'auth-page'
        }
    },
    methods: {
        changePage(page) {
            this.activePage = page;
        }
    }
}
</script>

<style scoped>
</style>
