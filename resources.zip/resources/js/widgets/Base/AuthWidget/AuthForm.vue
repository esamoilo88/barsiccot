<template>
    <div id="auth-form" class="p-4 w-100 d-flex flex-column align-items-center">
        <div class="d-flex flex-column mb-3">
            <h1 class="text-center">SIMPLE</h1>
            <span class="welcome-text">Bitte melde dich an.</span>
        </div>

        <div @keyup.enter="auth" class="form-fields-wrapper px-3">

            <FormInput
                v-model="username"
                name="username"
                class="w-100 mb-2"
                input-id="username-input"
                label-text="Benutzername*"
                :error-conditions="[
                    {
                        name: 'empty-username',
                        condition: !$v.username.required && $v.username.$dirty,
                        text: 'Bitte gebe einen Benutzernamen ein.'
                    }
                ]"
            />

            <FormInput
                v-model="password"
                name="password"
                type="password"
                class="w-100 mb-3"
                input-id="password-input"
                label-text="Passwort*"
                :error-conditions="[
                    {
                        name: 'empty-password',
                        condition: !$v.password.required && $v.password.$dirty,
                        text: 'Bitte gebe ein Passwort ein'
                    }
                ]"
            />

            <div class="mt-2 text-center">
                <button @click="auth" class="btn btn-secondary center-content w-100">Anmelden</button>
                <form :action="mycard" method="post" class="d-flex justify-content-center mt-2">
                    <input type="hidden" name="_token" :value="csrf">
                    <b-button type="submit" class="btn center-content btn-primary" variant="primary">
                        MyCard Login
                    </b-button>
                </form>
            </div>

            <div class="links-holder mt-3">
                <a @click="$emit('changePage', 'register-page')" href="#" class="mr-2 text-decoration-none">Registrieren</a>
                <a @click="$emit('changePage', 'new-password-page')" href="#" class="text-decoration-none">Passwort vergessen</a>
            </div>
        </div>
    </div>
</template>

<script>
import {BButton, BFormInput} from 'bootstrap-vue';
import { required } from 'vuelidate/lib/validators';
import FormInput from "../../../components/FormInput/FormInput";

export default {
    name: "AuthForm",
    props: {
        mycard: {
            type: String
        }
    },
    components: {
        BButton, BFormInput, FormInput
    },
    data() {
        return {
            username: '',
            password: '',
            csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        }
    },
    mounted() {
        this.username = localStorage.getItem('authUser') ? localStorage.getItem('authUser') : '';
        let selector = this.username !== '' ? 'password-input' : 'username-input';
        document.getElementById(selector).focus();
    },
    methods: {
        async auth() {
            this.$v.$touch();
            if (!this.$v.$anyError) {
                window.preloader.show();
                try {
                    const response = await this.$axios.post('/auth', {
                        username: this.username,
                        passwort: this.password
                    });
                    localStorage.setItem('authUser', this.username);
                    window.location.href = response.data.redirect;
                } catch (error) {
                    window.preloader.hide();
                    window.flash.showMessagesFromAjax(error.response.data, 'error');
                }
            }
        }
    },
    validations: {
        username: { required },
        password: { required }
    }
}
</script>

<style lang="scss" scoped>
#auth-form {
    position: relative;
}

.form-fields-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.links-holder {
    a {
        text-decoration: underline;
        padding: 0 5px;
    }
}
</style>
