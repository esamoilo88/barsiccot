<template>
    <div id="new-password-page" class="p-4 w-100 d-flex flex-column align-items-center">
        <div class="d-flex flex-column mb-3">
            <h1 class="text-center">SIMPLE</h1>
            <span class="welcome-text">Passwort vergessen</span>
        </div>
        <div @keyup.enter="sendNewPassword" class="change-pass-wrapper">
            <FormInput
                class="w-100 mb-4"
                name="email-or-username-input"
                id="email-or-username-input__label"
                label-text="Benutzername oder E-Mail*:"
                label-for="email-or-username-input"
                input-id="email-or-username-input"
                v-model="emailOrUsername"
                :error-conditions="[
                {
                    name: 'empty-email',
                    condition: !$v.emailOrUsername.required && $v.emailOrUsername.$dirty,
                    text: 'Bitte Benutzername oder E-Mail eingeben.'
                }
            ]"
            />

            <div class="d-flex flex-column align-items-center text-center mb-5">
                <button @click="sendNewPassword" class="btn btn-primary center-content mb-3">
                    Neues Passwort anfordern
                </button>
                <a @click="$emit('changePage', 'auth-page')" href="#">Zurück</a>
            </div>
        </div>
    </div>
</template>

<script>
import {BButton, BFormInput} from 'bootstrap-vue';
import FormInput from "../../../components/FormInput/FormInput";
import {required} from 'vuelidate/lib/validators';

export default {
    name: "NewPassword",
    components: {
        BButton, BFormInput, FormInput
    },
    data() {
        return {
            emailOrUsername: ''
        }
    },
    methods: {
        async sendNewPassword() {
            this.$v.$touch();
            if (!this.$v.$anyError) {
                let data = this.emailOrUsername.indexOf('@') !== -1 ? {email: this.emailOrUsername} : {username: this.emailOrUsername}
                window.preloader.show();
                try {
                    const response = await this.$axios.post('/auth/new-password', data);
                    window.preloader.hide();
                    window.flash.showMessagesFromAjax(response.data, 'success');
                } catch (error) {
                    window.preloader.hide();
                    window.flash.showMessagesFromAjax(error.response.data, 'error');
                }
            }
        }
    },
    validations: {
        emailOrUsername: {required}
    }
}
</script>

<style lang="scss" scoped>
#new-password-page {
    position: relative;
}

.change-pass-wrapper {
    min-width: 300px;
}
</style>
