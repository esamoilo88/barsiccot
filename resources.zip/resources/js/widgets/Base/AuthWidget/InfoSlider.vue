<template>
    <div id="info-slider-block" class="p-4 w-100">
        <div class="carousel-wrapper">
            <b-carousel
                id="info-carousel"
                indicators
                img-width="100%"
                img-height="100%"
                background="transparent"
            >
                <b-carousel-slide
                    v-for="slide in slides"
                    :text-html="slide.html"
                    :key="slide.hash"
                    background="transparent"
                ></b-carousel-slide>
            </b-carousel>
        </div>
    </div>
</template>

<script>
import { BCarousel, BCarouselSlide } from 'bootstrap-vue';
export default {
    name: "info-slider",
    components: {
        BCarousel, BCarouselSlide
    },
    props: {
        slides: {
            type: Array
        }
    }
}
</script>

<style lang="scss" scoped>
    @import 'resources/sass/variables';
    #info-slider-block {
        position: relative;
        background-color: #f4f4f4;
        border-radius: 5px;
    }

    #info-carousel,
    .carousel-item {
        height: 100%;
    }

    ::v-deep .carousel-item {
        text-shadow: none;
    }

    #info-carousel {
        display: flex;
        flex-direction: column;
    }

    ::v-deep .carousel-inner {
        flex: 1;
        max-height: 300px;
        min-height: 300px;
        overflow-y: auto;
        overflow-x: hidden;
    }

    .carousel-wrapper {
        height: 100%;
    }

    ::v-deep ol.carousel-indicators {
        margin-bottom: 0;
        position: relative;

        & li {
            background-color: $secondary;
            &.active {
                background-color: $primary;
            }
        }
    }

    ::v-deep .carousel-caption {
        color: #000;
        position: unset;
        text-align: unset;
        padding: 0;
    }
</style>
