import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Vuelidate from "vuelidate";
import Auth from "./Auth";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

Vue.use(Vuelidate);

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);
Vue.prototype.$t = t;
Vue.prototype.$axios = $axios;

new Vue({
    el: "#auth", //resources/views/auth.blade.php
    components: {
        Auth
    }
});
