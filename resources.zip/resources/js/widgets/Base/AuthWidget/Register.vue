<template>
    <div id="register-page" class="p-4 w-100 d-flex flex-column align-items-center">
        <div class="d-flex flex-column mb-3">
            <h1 class="text-center">SIMPLE</h1>
            <span class="welcome-text text-center">Registrierung</span>
        </div>

        <div class="register-inputs-wrapper">
            <FormInput
                v-model="email"
                name="email"
                class="w-100 mb-2"
                input-id="email-input"
                label-text="E-Mail Adresse*"
                :error-conditions="[
                    {
                        name: 'empty-email',
                        condition: !$v.email.required && $v.email.$dirty,
                        text: 'Bitte gebe deine E-Mail Adresse ein'
                    }
                ]"
            />

            <FormTextArea
                class="mb-3"
                v-model="reason"
                input-id="reason-text"
                label-text="Begründung*"
                name="reason"
                :error-conditions="[
                    {
                        name: 'empty-reason',
                        condition: !$v.reason.required  && $v.reason.$dirty,
                        text: 'Bitte gebe eine Begründung ein'
                    }
                ]"
                rows="5"
            />
        </div>

        <div class="d-flex flex-column align-items-center">
            <button @click="register" class="btn center-content btn-primary mb-3">
                <b-spinner v-if="pending" class="mr-2" small></b-spinner>
                Registrieren
            </button>
            <a @click="$emit('changePage', 'auth-page')" href="#">Zurück</a>
        </div>
    </div>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {required} from "vuelidate/lib/validators";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {BSpinner} from 'bootstrap-vue';

export default {
    name: "Register",
    components: {
        FormInput, FormTextArea, BSpinner
    },
    data() {
        return {
            pending: false,
            email: '',
            reason: ''
        }
    },
    methods: {
        async register() {
            this.pending = true;
            try {
                this.$v.$touch();
                if (!this.$v.$anyError) {
                    const res = await this.$axios.post('/register', {
                        email: this.email,
                        reason: this.reason
                    });
                    window.flash.showMessagesFromAjax(res.data);
                } else {
                    navigateToFirstInvalid();
                }
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Cannot register user! Err:", err);
            }
            this.pending = false;
        }
    },
    validations: {
        email: {required},
        reason: {required}
    }
}
</script>

<style lang="scss" scoped>
#register-page {
    position: relative;
}

.register-inputs-wrapper {
    min-width: 300px;
}
</style>
