<template>
    <div class="row text-white justify-content-center align-items-center h-100">
        <div class="col-xl-10 col-lg-14 col-md-16 col-sm-20 mb-2 justify-content-center">
            <div id="change-form" class="p-6 w-100">
                <h1 class="display-4 py-2 text-center">Passwort ändern</h1>
                <form>
                    <div @keyup.enter="change" class="form-fields-wrapper px-3">
                        <hr class="border-secondary my-4 w-100">
                        <FormInput
                            v-model="oldPassword"
                            name="oldPassword"
                            type="password"
                            class="w-100 mb-3"
                            input-id="old-password-input"
                            label-text="Altes Passwort*"
                            :error-conditions="[
                            {
                                name: 'empty-old-password',
                                condition: !$v.oldPassword.required && $v.oldPassword.$dirty,
                                text: 'Bitte gebe das alte Passwort (oder Initialpasswort) ein.'
                            }
                            ]"
                        />
                        <div class="info-text">Ein sicheres Passwort besteht mindestens aus 8 Zeichen mit Groß- und
                            Kleinbuchstaben
                            sowie Ziffern. Bitte erfülle die Passwort-Richtlinie.
                        </div>
                        <FormInput
                            v-model="newPassword"
                            name="newPassword"
                            type="password"
                            class="w-100 mb-3"
                            input-id="new-password-input"
                            label-text="Neues Passwort*"
                            @input="verify"
                            :error-conditions="[
                            {
                              name: 'empty-new-password',
                              condition: !$v.newPassword.required && $v.newPassword.$dirty,
                              text: 'Bitte gebe das neue Passwort ein.'
                            }
                            ]"
                        />
                        <FormInput
                            v-model="newPasswordRepeat"
                            name="newPasswordRepeat"
                            type="password"
                            class="w-100 mb-3"
                            :state="false"
                            input-id="new-password-repeat-input"
                            label-text="Neues Passwort (wiederholen)*"
                            :error-conditions="[
                            {
                                name: 'empty-new-password-repeat',
                                condition: !$v.newPasswordRepeat.required && $v.newPasswordRepeat.$dirty,
                                text: 'Bitte gebe das neue Passwort erneut ein.'
                            }
                            ]"
                        />
                        <div v-if="valid" class="progress-holder mb-3">
                            <svg id="tooltip-target" class="message-content-icon success">
                                <use xlink:href="/img/icons/check-circle.svg#check-circle-icon"></use>
                            </svg>
                            <div class="progress-holder text">Passwort-Richtline erfüllt</div>
                        </div>
                        <div v-else class="progress-holder mb-3">
                            <svg id="tooltip-target" class="message-content-icon error">
                                <use xlink:href="/img/icons/alert-circle.svg#alert-circle-icon"></use>
                            </svg>
                            <div class="progress-holder text">Passwort-Richtlinie nicht erfüllt</div>
                        </div>

                        <div class="buttons-holder">
                            <b-button @click="change" class="btn btn-lg px-4 align-self-center" variant="primary"
                                      type="button"
                                      :disabled="!valid">Passwort ändern
                            </b-button>
                            <a class="link" href="/logout">Abbrechen</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
import {BButton, BFormInput, BProgress, BTooltip} from 'bootstrap-vue';
import {required} from 'vuelidate/lib/validators';
import FormInput from "../../../components/FormInput/FormInput";

export default {
    name: "change-password-widget",
    components: {
        BButton, BFormInput, FormInput, BProgress, BTooltip
    },
    data() {
        return {
            oldPassword: '',
            newPassword: '',
            newPasswordRepeat: '',
            passwordStark: 0
        }
    },
    computed: {
        valid() {
            return this.passwordStark >= 3 && this.newPassword.length >= 8 && this.newPassword === this.newPasswordRepeat
        }
    },
    methods: {
        async change() {
            this.$v.$touch();
            if (!this.$v.$anyError) {
                window.preloader.show();
                try {
                    const response = await this.$axios.post('/auth/change-password', {
                        oldPassword: this.oldPassword,
                        newPassword: this.newPassword,
                        newPasswordRepeat: this.newPasswordRepeat
                    });
                    window.location.href = response.data.redirect;
                    window.preloader.hide();
                } catch (error) {
                    window.preloader.hide();
                    window.flash.showMessagesFromAjax(error.response.data, 'error');
                }
            }
        },
        verify() {
            this.passwordStark = 0;
            let passwordStark = 0;

            if (this.newPassword.match(/[a-z]/)) passwordStark++;

            if (this.newPassword.match(/[A-Z]/)) passwordStark++;

            if (this.newPassword.match(/\d+/)) passwordStark++;

            if (this.newPassword.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)) passwordStark++;

            this.passwordStark = passwordStark;
        }
    },
    mounted() {
        window.flash.showMessagesFromAjax('Du musst das Passwort ändern, weil dein Passwort abgelaufen ist oder die Funktion "Passwort vergessen" verwendet wurde.', 'info');
    },
    validations: {
        oldPassword: {required},
        newPassword: {required},
        newPasswordRepeat: {required}
    }
}
</script>

<style lang="scss" scoped>
    @import "resources/sass/variables.scss";

    #change-form {
      position: relative;

      &::before {
        content: '';
        height: 100%;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.65);
        z-index: -1;
        border-radius: 10px;
      }
    }

    .form-fields-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .links-holder {
      a {
        text-decoration: underline;
        color: #fff;
        padding: 0 5px;
      }
    }

    .message-content-icon {
      min-width: 30px;
      min-height: 30px;
      max-width: 30px;
      max-height: 30px;
      margin-right: 10px;
    }

    .message-content-icon.error {
      fill: $error;
    }

    .message-content-icon.success {
      fill: $success;
    }

    .link {
      text-decoration: underline;
      color: #fff;
      padding: 0 5px;
      left: 300px;
      justify-self: flex-end;
      align-self: flex-end;
    }

    .p-6 {
      padding: 2rem !important;
    }

    .buttons-holder {
      display: flex;
      flex-direction: column;
      width: 100%;
    }

    .progress-holder {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      width: 100%;
    }

    .progress-holder.text {
      font-size: 22px;
    }

    .info-text {
      margin-bottom: 15px;
      font-size: 22px
    }
</style>
