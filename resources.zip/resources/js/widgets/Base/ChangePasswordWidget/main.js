import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Vuelidate from "vuelidate";
import ChangePassword from "./ChangePassword";

Vue.prototype.$axios = $axios;
Vue.use(Vuelidate);

new Vue({
    el: "#change", //resources/views/change.blade.php
    components: {
        ChangePassword
    }
});
