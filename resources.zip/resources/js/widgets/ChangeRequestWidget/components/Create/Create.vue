<template>
    <div>
        <modal-dialog
            modal-class="create-cr-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-create-cr-modal')"
            title-dialog="Neue Vertragsänderung"
            scrollable
        >
            <p class="mt-3 mb-4">
                Über eine Vertragsänderung kannst Du das Angebot und die Laufzeiten des Vertrages nach der Beauftragung ändern.
                Eine Vertragsänderung hat stets eine Motivation die <b>intern</b> (ohne Auftraggeber Beteiligung, z.B.
                einfache Korrekturen) oder <b>extern</b> (kommerziell, z.B. Vertragsverländerungen) begründet sein kann.
            </p>

            <b-overlay :show="pending">
                <div class="row simple-box pt-5">
                    <div class="col-lg-12 d-flex flex-column">
                        <div class="d-flex flex-column mb-4">
                            <FormSelect
                                v-model="form.crType"
                                class="mb-3"
                                select-id="anderungsgrund"
                                name="anderungsgrund"
                                label-text="Änderungsgrund*"
                                :options="crTypeOptions"
                                :error-conditions="[
                                    {
                                        name: 'empty-anderungsgrund',
                                        condition: !$v.form.crType.required  && $v.form.crType.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Anderungsgrud'})
                                    }
                                ]"
                            />
                            <FormTextArea
                                v-model="form.bemerkungen"
                                input-id="bemerkungen-text"
                                label-text="Bemerkungen*"
                                name="bemerkungen"
                                :error-conditions="[
                                    {
                                        name: 'empty-bemerkungen',
                                        condition: !$v.form.bemerkungen.required  && $v.form.bemerkungen.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Bemerkungen'})
                                    }
                                ]"
                                rows="6"
                            />
                            <span class="text-muted text-1r mt-2">Beschreibe hier näheren Umstände bezogen auf den Vertrag.</span>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="d-flex align-items-start mb-4">
                            <span class="cr-form-icon icon-content-unlock-default mr-3"></span>
                            <span>
                                Nachdem die Vertragsänderung gestartet ist können <b>Änderungen am Angebot</b> vorgenommen werden
                            </span>
                        </div>
                        <div class="d-flex align-items-start mb-4">
                            <span class="cr-form-icon icon-user_file-billing-default mr-3"></span>
                            <span>
                                Während die Vertragsänderung offen ist können alle <b>Finanzprozesse weiterhin ausgefuhrt</b> werden
                            </span>
                        </div>
                        <div class="d-flex align-items-start">
                            <span class="cr-form-icon icon-user_file-handshake-default mr-3"></span>
                            <span>
                                Externe Vertragsänderungen erfordern das Hochladen des signierten <b>CR-Dokuments</b> und
                                daher auch eine <b>Abstimmung mit dem Auftraggeber</b>
                            </span>
                        </div>
                    </div>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="onCreate" class="btn btn-primary">
                    <b-spinner v-if="onSubmitPending" small></b-spinner>
                    Vertragsänderung starten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {BOverlay, BSpinner} from 'bootstrap-vue';
import {mapGetters} from "vuex";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {createOptions} from "@helpers/Form/InputsHelper";
import {required} from "vuelidate/lib/validators";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import FormSelect from "@comp/FormSelect/FormSelect";

export default {
    name: "Create",
    components: {
        ModalDialog, FormTextArea, FormSelect, BOverlay, BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
    },
    async created() {
        await this.init();
    },
    data() {
        return {
            form: {
                crType: null,
                bemerkungen: null,
            },
            crTypeOptions: [],
            pending: false,
            onSubmitPending: false,
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'changeRequest/simpleId',
        })
    },
    methods: {
        /**
         * Create ChangeRequest
         * @returns {void}
         */
        async onCreate() {
            this.$v.$touch();

            if (!this.$v.$anyError) {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.post(`/change-request/${this.simpleId}`, {...this.form});
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('refreshCRList');
                    this.$eventBus.$emit('refreshBasicProjectData');
                    this.$emit('close-create-cr-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create ChangeRequest", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onSubmitPending = false;
        },
        async init() {
            this.pending = true;
            try {
                const res = await this.$axios.get(`/change-request/types`);
                let optionsWithGroup = res.data.map(opt => {
                    return opt.external ? {...opt, group: "Kommerzielle Gründe"} : {...opt, group: "ISP interne Gründe"};
                });
                this.crTypeOptions.push(...createOptions(
                    optionsWithGroup,
                    (r) => r.id,
                    (r) => r.bezeichnung,
                    'group',
                    true
                    )
                );
            } catch (err) {
                console.error("Couldn't init 'create CR' form!", err);
                window.flash.error(this.$t.__('errors.generic_errors'));
            }
            this.pending = false;
        },
    },
    validations: {
        form: {
            crType: {required},
            bemerkungen: {required}
        }
    }
}
</script>

<style lang="scss">
.create-cr-modal {
    .modal-dialog {
        max-width: 950px;
    }

    .cr-form-icon {
        font-size: 1.7rem;
    }
}
</style>
