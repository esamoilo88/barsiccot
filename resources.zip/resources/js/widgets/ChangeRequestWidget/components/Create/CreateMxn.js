export default {
    data() {
        return {
            isCreateFormVisible: false
        }
    },
    methods: {
        openCreateChangeRequestForm(isAnyOpenCr, status) {
            if (isAnyOpenCr) {
                window.flash.error(this.$t.__('validation.change_request.opened_cr_already_exist'));
            } else if (status.presales || !status.active) {
                window.flash.error(this.$t.__('validation.change_request.wrong_project_status'));
            } else {
                this.isCreateFormVisible = true;
            }
        },
        closeCreateChangeRequestForm() {
            this.isCreateFormVisible = false;
        }
    }
}
