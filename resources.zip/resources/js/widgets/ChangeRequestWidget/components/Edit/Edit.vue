<template>
    <modal-dialog
        :is-visible="isVisible"
        @hideModal="hide"
        title-dialog="Vertragsänderung bearbeiten"
        close-button="Abbrechen"
        :static="true"
        :scrollable="true"
        modal-class="edit-cr"
        size="xl"
    >
        <b-overlay :show="pending">
            <div class="mb-3">Bitte fülle alle mit* gekennzeichneten Felder aus.</div>

            <div class="simple-box mb-5">
                <div class="row no-gutters mb-5">
                    <div class="col pr-3">
                        <h5>Vertragsänderungstyp und Grund</h5>

                        <Reason ref="reason" @change="reasonChanged"></Reason>

                        <div class="files-padding">
                            <h5 v-if="crIsRequired">
                                Für die Änderung von T-Systems Verträgen ist der Upload einer Change-Request Datei erforderlich.
                            </h5>
                            <h5 v-else>
                                Optional kann eine Change-Request Datei hochgeladen werden.
                            </h5>

                            <form-file-load
                                v-model="files.changeRequest"
                                ref="changeRequest"
                                type="file"
                                browse-text="Auswählen"
                                @uploadFile="(file) => uploadFile(file, 'changeRequest')"
                                :placeholder="`Change-Request${crIsRequired ? '*' : ''}`"
                                accept=".xlsx"
                                :error-conditions="errorConditions.changeRequest"
                            />

                            <h5 class="mt-3">Aktualisiere optional auch die bereits hinterlegten Systemdateien</h5>

                            <form-file-load
                                v-model="files.angebot"
                                ref="angebot"
                                type="file"
                                browse-text="Auswählen"
                                @uploadFile="(file) => uploadFile(file, 'angebot')"
                                placeholder="Angebot"
                                accept=".pdf,.doc,.docx,.xia,.p7f"
                            />

                            <form-file-load
                                v-model="files.beauftragung"
                                ref="beauftragung"
                                type="file"
                                browse-text="Auswählen"
                                @uploadFile="(file) => uploadFile(file, 'beauftragung')"
                                placeholder="Beauftragung"
                                accept=".doc,.docx,.pdf,.p7f,.xia,.tif,.tiff,.msg"
                            />
                        </div>
                    </div>

                    <div class="col pl-3">
                        <h5>Laufzeiten und Termine</h5>

                        <Runtime ref="runtime"></Runtime>
                    </div>
                </div>
            </div>

            <optional-leistungen
                v-if="isVisible"
                :simple-id="simpleId"
                @selected-aps="(ids) => form.apIds = ids"
                :form-data="{vkVersion: vkVersionsId}"
                :show-tab="false"
                :filter="['optional','beauftragt']"
                class="mb-4">
                <template v-slot:title>
                    <h5>Nachfolgende Angebotspositionen werden beauftragt</h5>
                </template>
            </optional-leistungen>

        </b-overlay>

        <template #footer="{methods}">
            <b-button variant="primary" @click="update">
                Speichern
            </b-button>

            <b-button variant="secondary" @click="hide">
                Abbrechen
            </b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BSpinner, BButton, BFormGroup, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import FormFileLoad from '@comp/FileLoad/FormFileLoad'
import dayjs from "res/js/utils/day";
import OptionalLeistungen from "res/js/widgets/Orders/OrdersCreateWidget/OptionalLeistungen/OptionalLeistungen";
import LaufzeitEdit from "res/js/widgets/Projects/ProjectsViewWidget/tabs/Laufzeiten/LaufzeitEdit";
import Runtime from "res/js/widgets/Projects/ProjectsViewWidget/tabs/Laufzeiten/Runtime";
import Reason from "res/js/widgets/Projects/ProjectsViewWidget/tabs/Laufzeiten/Reason";
import {required, requiredIf} from "vuelidate/lib/validators";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    components: {
        ModalDialog,
        BSpinner,
        BButton,
        BFormGroup,
        FormDatepicker,
        FormFileLoad,
        BFormCheckbox,
        BOverlay,
        OptionalLeistungen,
        LaufzeitEdit,
        Runtime,
        Reason
    },
    props: {
        simpleId: {
            required: true,
            type: Number
        },
        vkVersionsId: {
            required: true,
            type: Number
        },
        salesAnfrage: {
            required: true,
            type: Object
        },
        status: {
            required: true,
            type: Object
        },
        isIksl: {
            required: true,
            type: Boolean
        }
    },
    computed: {
        laufzeitenData() {
            return {
                vertragsbeginn: this.formatDate(this.salesAnfrage.vertragsbeginn),
                vertragsende: this.formatDate(this.salesAnfrage.vertragsende),
                rolloutbeginn: this.formatDate(this.salesAnfrage.rolloutbeginn),
                rolloutende: this.formatDate(this.salesAnfrage.rolloutende),
                betriebsbeginn: this.formatDate(this.salesAnfrage.betriebsbeginn),
                betriebsende: this.formatDate(this.salesAnfrage.betriebsende),
                crTyp: this.form.crTyp,
                bemerkungen: this.form.grund,
            }
        },
        crIsRequired() {
            return this.isIksl && this.isExternal;
        },
        errorConditions() {
            return {
                changeRequest: [
                    {
                        name: 'changeRequest-required',
                        condition: !this.$v.form.files.changeRequest.required && this.$v.form.files.changeRequest.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Change-Request Datei'})
                    }
                ]
            }
        }
    },
    data() {
        return {
            isExternal: false,
            isVisible: false,
            pending: false,
            form: {
                crId: null,
                crTyp: null,
                grund: null,
                vertragsbeginn: null,
                vertragsende: null,
                rolloutbeginn: null,
                rolloutende: null,
                betriebsbeginn: null,
                betriebsende: null,
                files: {
                    changeRequest: null,
                    angebot: null,
                    kalkulation: null,
                    beauftragung: null,
                },
                apIds: []
            },
            files: {
                changeRequest: null,
                angebot: null,
                kalkulation: null,
                beauftragung: null,
            }
        }
    },
    methods: {
        show() {
            this.isVisible = true;
        },
        hide() {
            this.isVisible = false;

            this.$refs.runtime.$v.form.$reset();
            this.$refs.reason.$v.form.$reset();
            this.$v.form.files.$reset();
        },
        async uploadFile(file, key) {
            this.pending = true;

            try {
                const response = await this.$axios.post(`/change-request/upload/${key}`, file.formData, file.config);

                const uploadedFile = response.data.filesPath[0];

                this.form.files[key] = {
                    'savePath': uploadedFile.tempPath,
                    'size': uploadedFile.size,
                    'name': file.fileNames,
                    'date': file.date
                }

                window.flash.success('Datei hochgeladen');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);

                this.$refs[key].clearFiles();
            }

            this.pending = false;
        },
        async update() {
            if (this.invalid()) {
                navigateToFirstInvalid();

                return;
            }

            this.pending = true;

            try {
                this.setRuntimeForm();
                this.setReasonForm();

                await this.$axios.post(`/change-request/${this.simpleId}/${this.form.crId}`, this.form);

                window.flash.success('Erfolgreich gespeichert');

                this.$emit('updated');

                this.hide();
                this.clearForm();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        invalid() {
            this.$v.form.files.$touch();

            this.$refs.runtime.$v.form.$touch();
            this.$refs.reason.$v.form.$touch();

            return this.$refs.runtime.$v.form.$invalid || this.$refs.reason.$v.form.$invalid || this.$v.form.files.$invalid;
        },
        clearForm() {
            this.form = {
                crId: null,
                crTyp: null,
                grund: null,
                vertragsbeginn: null,
                vertragsende: null,
                rolloutbeginn: null,
                rolloutende: null,
                betriebsbeginn: null,
                betriebsende: null,
                files: {
                    changeRequest: null,
                    angebot: null,
                    kalkulation: null,
                    beauftragung: null,
                },
                apIds: []
            }

            this.$refs.angebot.clearFiles();
            this.$refs.beauftragung.clearFiles();
            this.$refs.changeRequest.clearFiles();

            this.$refs.runtime.$v.form.$reset();
            this.$refs.reason.$v.form.$reset();
            this.$v.form.files.$reset();
        },
        setForm(item) {
            this.form.crId = item.crId;
            this.form.crTyp = item.crTyp.id;
            this.form.grund = item.grund;

            this.form.vertragsbeginn = this.formatDate(this.salesAnfrage.vertragsbeginn);
            this.form.vertragsende = this.formatDate(this.salesAnfrage.vertragsende);
            this.form.rolloutbeginn = this.formatDate(this.salesAnfrage.rolloutbeginn);
            this.form.rolloutende = this.formatDate(this.salesAnfrage.rolloutende);
            this.form.betriebsbeginn = this.formatDate(this.salesAnfrage.betriebsbeginn);
            this.form.betriebsende = this.formatDate(this.salesAnfrage.betriebsende);

            this.$refs.runtime.setForm(this.form);
            this.$refs.reason.setForm({
                crTyp: this.form.crTyp,
                bemerkungen: this.form.grund,
            });
        },
        formatDate(date) {
            return date ? dayjs(date).format('DD.MM.YYYY') : null;
        },
        setRuntimeForm() {
            const form = this.$refs.runtime.form;

            this.form.vertragsbeginn = form.vertragsbeginn;
            this.form.vertragsende = form.vertragsende;
            this.form.rolloutbeginn = form.rolloutbeginn;
            this.form.rolloutende = form.rolloutende;
            this.form.betriebsbeginn = form.betriebsbeginn;
            this.form.betriebsende = form.betriebsende;
            this.form.crTyp = form.crTyp;
            this.form.grund = form.bemerkungen;
        },
        setReasonForm() {
            const form = this.$refs.reason.form;

            this.form.crTyp = form.crTyp;
            this.form.grund = form.bemerkungen;
        },
        reasonChanged() {
            this.isExternal = this.$refs.reason.isExternal();
        }
    },
    validations: {
        form: {
            files: {
                changeRequest: {
                    required: requiredIf(function(model) {
                        return this.crIsRequired && !model.changeRequest
                    }),
                }
            }
        }
    },
}
</script>

<style lang="scss" scoped>
.files-padding {
    padding-top: 4.1rem;
}
</style>
