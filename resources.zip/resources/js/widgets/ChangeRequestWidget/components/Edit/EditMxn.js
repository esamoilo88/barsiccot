export default {
    methods: {
        showEditDialog(item) {
            this.$eventBus.$emit('updateHeader');

            this.$refs.edit.setForm(item);
            this.$refs.edit.show();
        },
        onUpdated() {
            this.$eventBus.$emit('updateHeader');

            this.refreshTable();
        }
    }
}
