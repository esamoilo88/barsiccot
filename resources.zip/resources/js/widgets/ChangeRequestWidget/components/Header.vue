<template>
    <div class="simple-box box-shadow">
        <div class="header-data">
            <table>
                <tr>
                    <td>SIN:</td>
                    <td class="header-data__simple-id">{{ simpleId }}</td>
                </tr>
                <tr>
                    <td>Vorhaben:</td>
                    <td class="header-data__vorhaben">{{ project.globalGate.thema }}</td>
                </tr>
                <tr>
                    <td>Kunde:</td>
                    <td class="header-data__kunde">{{ project.kundenname }}</td>
                </tr>
            </table>

            <CircleChart
                :content="status.shortName"
                :value="status.progress"
                :color="status.color"
                size="small"
                sr-text="Status"
            />
        </div>
    </div>
</template>

<script>
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownDivider, BDropdownItem} from "bootstrap-vue";
import CircleChart from "@comp/CircleChart/CircleChart";
import {mapGetters, mapMutations, mapState} from 'vuex';

export default {
    name: "Header",
    components: {
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider,
        CircleChart
    },
    computed: {
        ...mapGetters({
            status: 'changeRequest/status',
            simpleId: 'changeRequest/simpleId'
        }),
        ...mapState({
            project: state => state.changeRequest.basicData
        })
    },
    created() {
        this.$eventBus.$on('updateHeader', async () => {
            const response = await this.$axios.get(`/projects/${this.simpleId}/basic-data`);

            this.setHeaderData(response.data);
        });
    },
    methods: {
        ...mapMutations({
            setHeaderData: 'changeRequest/SET_BASIC_DATA'
        }),
    }
}
</script>

<style lang="scss" scoped>
.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        font-size: 22px;
        padding: 5px 20px 5px 0;
    }
}

.header-data__simple-id,
.header-data__vorhaben,
.header-data__kunde {
    font-weight: bold;
}
</style>
