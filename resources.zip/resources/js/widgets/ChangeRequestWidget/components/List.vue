<template>
    <div>
        <button v-if="canCreate" @click="openCreateChangeRequestForm(isAnyOpenedCR, status)" class="btn btn-primary mb-2">
            + Neue Vertragsänderung
        </button>

        <table-simple
            table-id="change-requests-list-table"
            :fields="fields"
            :filters="[]"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
            primary-key="crId"
            ref="table"
        >
            <template #cell(merkmal)="data">
                <badge
                    :class="'merkmal-badge ' +  (data.item.crTyp.external ? 'external-merkmal' : 'internal-merkmal')"
                    :color="data.item.crTyp.external ? '#e20074' : '#e0e0e0'"
                >
                    {{ data.item.crTyp.external ? 'Extern' : 'Intern' }}
                </badge>
            </template>

            <template #cell(status)="data">
                <badge class="status-badge" :color="data.item.fertigAm ? '#46a800' : '#ffe401'">
                    {{ data.item.fertigAm ? 'Geschlossen' : 'Offen' }}
                </badge>
            </template>

            <template #cell(versionsnrExternal)="data">
                <div class="versionsnr-external">
                    {{ data.item.versionsnrExternal ? 'V' + data.item.versionsnrExternal : '-' }}
                </div>
            </template>

            <template #cell(crTyp)="data">
                <div class="cr-typ">{{ data.item.crTyp.bezeichnung }}</div>
            </template>

            <template #cell(createdAt)="data">
                <div class="created-at">{{ formatDate(data.item.created, 'DD.MM.YYYY, HH:mm') }}</div>
            </template>

            <template #cell(closedAt)="data">
                <div class="closed-at">{{ formatDate(data.item.fertigAm, 'DD.MM.YYYY, HH:mm') }}</div>
            </template>

            <template #cell(optionen)="row">
                <ButtonIcon
                    v-if="canUpdate && row.item.fertigAm === null"
                    @click="showEditDialog(row.item)"
                    icon-class="icon-action-edit-default"
                    :id="'edit-cr-btn-' + row.item.crId"
                    title="Vertragsänderung bearbeiten"
                />
                <ButtonIcon
                    button-class="btn-icon-link details_class"
                    icon-class="icon-action-more-selected"
                    :id="'cr-more-btn-' + row.item.crId"
                    @click="toggleRowAnyway(row.item, 'crId')"
                    :title="row.item._showDetails ? 'Schließen weitere Optionen':'Zeigen weitere Optionen an'"
                />
            </template>

            <template #row-details="row">
                <div>
                    <QuickViewSlot>
                        <div class="p-3">
                            <div><b>Bemerkungen</b></div>
                            <p>{{ defVal(row.item.grund, '-') }}</p>
                        </div>
                    </QuickViewSlot>
                </div>
            </template>
        </table-simple>

        <Create
            v-if="isCreateFormVisible"
            :is-visible="isCreateFormVisible"
            @close-create-cr-modal="closeCreateChangeRequestForm"
        />

        <Edit
            ref="edit"
            :simple-id="simpleId"
            :vk-versions-id="project.vkVersionsId"
            :sales-anfrage="project.salesAnfrage"
            :is-iksl="project.isIksl"
            :status="status"
            @updated="onUpdated"
        />
    </div>
</template>

<script>
import {VBTooltip} from 'bootstrap-vue';
import {mapGetters, mapState} from 'vuex';
import TableSimple from "@comp/TableSimple/TableSimple";
import QuickViewMixin from "@mixins/QuickView/QuickViewMixin";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import Pagination from "@mixins/Pagination/Pagination";
import Badge from "@comp/Badge/Badge";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import Create from "./Create/Create";
import CreateMxn from "./Create/CreateMxn";
import Edit from './Edit/Edit';
import EditMxn from "./Edit/EditMxn";

export default {
    name: "List",
    mixins: [QuickViewMixin, Pagination, DatesProcessing, ScalarsProcessing, CreateMxn, EditMxn],
    directives: {
        'b-tooltip': VBTooltip
    },
    components: {
        Create, Edit,
        TableSimple, QuickViewSlot, ButtonIcon, Badge
    },
    data() {
        return {
            fields: [
                {key: "versionsnr", label: "Nr", class: 'nr-col'},
                {key: "merkmal", label: "Merkmal", class: 'merkmal-col'},
                {key: "status", label: "Status", class: 'status-col'},
                {key: "versionsnrExternal", label: "CR-Nr", class: 'cr-nr-col'},
                {key: "crTyp", label: "Änderungsgrund", class: 'cr-typ-col'},
                {key: "createdAt", label: "Erstellt am", class: 'created-at-col'},
                {key: "closedAt", label: "Abgeschlossen am", class: 'closed-at-col'},
                {key: "optionen", label: "Optionen", class: 'optionen-col'}
            ]
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'changeRequest/simpleId',
            status: 'changeRequest/status',
        }),
        ...mapState({
            project: state => state.changeRequest.basicData
        }),

        canCreate() {
            let user = this.project.user;
            return this.status.active && (user.roles.includes('SC')
                || user.roles.includes('AE')
                || user.roles.includes('SM')
                || user.roles.includes('FFU')
                || user.roles.includes('FLU')
                || user.roles.includes('FIU')
                || user.roles.includes('AD'));
        },
        canUpdate() {
            let user = this.project.user;
            return this.status.active && (
                user.roles.includes('SC')
                || user.roles.includes('AE')
                || user.roles.includes('SM')
                || user.roles.includes('AD')
                || user.roles.includes('FFU')
                || user.roles.includes('FLU')
                || user.roles.includes('FIU')
            );
        },
        isAnyOpenedCR() {
            return this.$refs.table.items.filter(i => i.fertigAm === null).length > 0
        }
    },
    created() {
        this.initPaginationMxn(1, 0, 20);
        this.$eventBus.$on('refreshCRList', this.refreshTable);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshCRList', this.refreshTable);
    },
    methods: {
        async itemsProvider(ctx, cancelToken) {
            try {
                const response = await this.$axios.post(`/change-request/${this.simpleId}/list`, ctx, {cancelToken: cancelToken.token});
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return this.insertShowDetailsField(response.data.data, 'crId');
            } catch (err) {
                console.log(err);
                window.flash.error(this.$t.__('errors.generic_error'));
                return [];
            }
        },
        async refreshTable() {
            await this.$refs.table.manualCtxTrigger();
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .merkmal-badge.internal-merkmal span,
::v-deep .status-badge span {
    color: #000 !important;
}

::v-deep .external-merkmal {
    color: #fff !important;
}
</style>
