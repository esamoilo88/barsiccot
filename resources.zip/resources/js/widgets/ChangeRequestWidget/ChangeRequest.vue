<template>
    <div>
        <Header class="mb-4"/>

        <div class="simple-box box-shadow">
            <List/>
        </div>
    </div>
</template>

<script>
import Header from "./components/Header";
import List from "./components/List";
import {mapMutations, mapGetters} from 'vuex';

export default {
    name: "change-request",
    components: {
        List, Header
    },
    props: {
        basicData: {
            type: Object,
            required: true
        }
    },
    created() {
        this.setBasicData(this.basicData);
        this.$eventBus.$on('refreshBasicProjectData', this.refreshProjectBasicData);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshBasicProjectData', this.refreshProjectBasicData);
    },
    computed: {
        ...mapGetters({
            simpleId: 'changeRequest/simpleId'
        })
    },
    methods: {
        ...mapMutations({
            setBasicData: 'changeRequest/SET_BASIC_DATA'
        }),

        async refreshProjectBasicData() {
            try {
                const res = await this.$axios.get(`/projects/${this.simpleId}/basic-data`);
                this.setBasicData(res.data);
            } catch (err) {
                console.error("Couldn't refresh basic project data");
                window.flash.error(this.$t.__('errors.generic_error'));
            }
        }
    }
}
</script>

<style scoped></style>
