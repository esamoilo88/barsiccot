import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Formatter from "res/js/utils/formatter";
import Vuelidate from "vuelidate";
import ChangeRequest from "./ChangeRequest";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
const translations = require('res/lang/lang.translations.json');
import store from './store';

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$t = new SimpleTranslator(translations);
Vue.prototype.$eventBus = eventBus;

Vue.use(Vuelidate);

export default new Vue({
    el: '#change-request', //resources/views/App/ChangeRequest/list.blade.php
    components: {
        ChangeRequest
    },
    store
});
