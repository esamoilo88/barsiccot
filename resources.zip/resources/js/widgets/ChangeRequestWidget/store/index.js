import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import changeRequest from "./modules/change_request.store";

const store = new Vuex.Store({
    modules: {
        changeRequest
    }
});

store.$axios = $axios;

export default store;
