import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    namespaced: true,
    state: {
        basicData: null,
    },
    mutations: {
        SET_BASIC_DATA(state, data) {
            state.basicData = {...data};
        },
    },
    actions: {
        /**
         * Get basic project data
         * @param context
         * @param simpleId
         * @returns {Promise<*>}
         */
        async fetchData(context, simpleId) {
            try {
                const res = await this.$axios.get(`/projects/${simpleId}/basic-data`);
                context.commit('SET_BASIC_DATA', res.data.data.basic);
            } catch (err) {
                console.error("Couldn't fetch data for ChangeRequest view page!", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
        },
    },
    getters: {
        status(state) {
            return state.basicData.globalGate.sinStatus.status;
        },
        simpleId(state) {
            return state.basicData.globalGate.simpleId;
        },
        isInit(state) {
            return !isEmpty(state.basicData);
        },
    }
}
