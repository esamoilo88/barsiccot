import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import cbi from './modules/cbi.store';

const store = new Vuex.Store({
    modules: {
        cbi

    }
});

store.$axios = $axios;

export default store;
