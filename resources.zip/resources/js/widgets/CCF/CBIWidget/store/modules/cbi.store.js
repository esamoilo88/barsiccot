export default {
    namespaced: true,
    state: {
        cbiList: [],
    },
    mutations: {
        SET_CBI_LIST(state, list) {
            state.cbiList = [...list];
        }
    },
    actions: {
        /**
         * Get CBI list
         * @param context
         * @param swtch
         * @returns {Promise<*>}
         */
        async fetchCBIList(context, swtch) {
            try {
                let res = await this.$axios.get('/admin/cbi/list', {params: {switch: swtch}});
                if (res.data.error) {
                    window.flash.error(res.data.error);
                } else {
                    context.commit('SET_CBI_LIST', res.data);
                }
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.log("Couldn't fetch CBI list!", err);
            }
        }
    }
}
