<template>
    <div>
        <div class="simple-box box-shadow p-4">
            <div class="d-flex align-items-center">
                <div class="pr-3">
                    <i class="icon-user_file-billing-default icon-lg"></i>
                </div>
                <div>
                    <h2 class="mb-0">
                        Sammelfaktura Übersicht
                    </h2>
                    <div class="text-muted text-1r">Erstelle Rechnungen für die Sammelfaktura und buche sie im SAP</div>
                </div>
            </div>

            <hr class="mb-5"/>

            <b-overlay :show="pending">
                <div class="row no-gutters justify-content-between align-items-center">
                    <div class="col-auto mr-auto">
                        <button class="btn btn-primary" @click="showLbusExportDialog" title="Fakturareport">
                            <span class="icon-action-download-default"></span>
                            Fakturareport
                        </button>
                    </div>
                    <div class="col-auto">
                        <b-form-checkbox
                            class="item-switch-input mr-3"
                            v-model="actualFakturaMonth"
                            @change="onActualFakturaMonthChange"
                            switch
                        >
                            Aktuellen Fakturamonat berücksichtigen
                        </b-form-checkbox>
                    </div>
                    <div class="col-auto">
                        <a class="btn" href="/admin/ccf/cbi-invoices" title="Rechnungen">
                            <i class="icon-user_file-billing-default"></i>
                            Rechnungen
                        </a>

                        <button class="btn" @click="showMarkAllDialog=true" title="Manuellen Streams markieren">
                            <i class="icon-action-succsess-default"></i>
                            Manuellen Streams markieren
                        </button>
                    </div>
                </div>
                <div class="table-wrapper mt-2">
                    <b-table-lite
                        table-id="cbi-table"
                        :fields="fields"
                        :items="cbiList"
                        borderless
                        sticky-header
                        primary-key="streamId"
                        ref="table"
                    >
                        <template #cell(sumOpen)="row">
                            <div :class="{'text-success': row.item.sumOpen > 0, 'font-weight-bold': true}">
                                {{ $f.numberToString(row.item.sumOpen, true, false, '0,00') }}
                            </div>
                        </template>

                        <template #cell(sumLocked)="row">
                            <div :class="{'text-danger': row.item.sumLocked > 0, 'font-weight-bold': true}">
                                {{ $f.numberToString(row.item.sumLocked, true, false, '0,00') }}
                            </div>
                        </template>

                        <template #cell(modus)="row">
                            <badge v-if="row.item.sapInterfaceUsage" class="status-badge" color="#46a800">Schnittstelle</badge>
                            <badge v-else class="status-badge" color="#7ecbf5">Manuell</badge>
                            <badge v-if="row.item.xm2Logic" class="status-badge mt-1" color="#e0e0e0">XM2</badge>
                        </template>

                        <template #cell(options)="row">
                            <div class="text-nowrap">
                                <button
                                    class="btn btn-secondary font-weight-bold"
                                    @click="showLbuListDialog(row.item.streamId, row.item.streamName)"
                                    :id="'lbu-btn-' + row.item.streamId"
                                    title="LBU"
                                >
                                    <span class="icon-action-changelog-default mr-2"></span>
                                    LBU
                                </button>

                                <button
                                    v-if="!row.item.sapInterfaceUsage"
                                    :disabled="row.item.countOpen == 0"
                                    class="btn btn-primary font-weight-bold"
                                    @click="showMarkLbuDialog(row.item)"
                                    :id="'markieren-btn-' + row.item.streamId"
                                    title="Markieren"
                                >
                                    <span class="icon-content-price-tag-default mr-2"></span>
                                    Markieren
                                </button>
                            </div>
                        </template>

                        <template #row-details="row">
                            <div>
                                <QuickViewSlot>
                                    Additional details
                                </QuickViewSlot>
                            </div>
                        </template>
                    </b-table-lite>
                </div>
            </b-overlay>

            <LbuList
                v-if="lbuListDialog.show"
                :show="lbuListDialog.show"
                :stream-id="lbuListDialog.streamId"
                :switch="actualFakturaMonth"
                :stream-name="lbuListDialog.streamName"
                @hide="hideLbuListDialog"
                @refresh-cbi="refreshCBI"
            />
        </div>

        <MarkLbuDialog
            v-if="markLbuDialog.show"
            :show="markLbuDialog.show"
            :item="markLbuDialog.item"
            :actual-faktura-month="actualFakturaMonth"
            @hide="hideMarkLbuDialog"
        />
        <MarkAllDialog
            v-if="showMarkAllDialog"
            :show="showMarkAllDialog"
            :items="cbiListManual"
            :actual-faktura-month="actualFakturaMonth"
            @hide="showMarkAllDialog=false"
            @refresh-cbi="refreshCBI"
        />

        <LBUsExportDialog
            ref="lbuExportDialog"
            :date="data.dates.at4"
            :time="data.dates.time"
            :show="lbusExportDialog.show"
            @hide="hideLbusExportDialog"
        />

    </div>
</template>

<script>
import {BTableLite, BFormCheckbox, BOverlay, BDropdown, BDropdownItem, BDropdownItemButton, VBTooltip} from 'bootstrap-vue';
import {mapState, mapActions} from 'vuex';
import Badge from "@comp/Badge/Badge";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import QuickViewMixin from "@mixins/QuickView/QuickViewMixin";
import MarkLbuDialog from "res/js/widgets/CCF/CBIWidget/MarkLbuDialog";
import MarkAllDialog from "res/js/widgets/CCF/CBIWidget/MarkAllDialog";
import LbuList from "res/js/widgets/CCF/CBIWidget/components/LbuList";
import LBUsExportDialog from "res/js/widgets/CCF/CBIWidget/components/LBUsExportDialog";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
export default {
    name: "CBI",
    components: {
        LbuList, QuickViewSlot, ButtonIcon, BDropdownItem, BTableLite, Badge, BFormCheckbox, BDropdown, BDropdownItemButton,
        BOverlay, MarkLbuDialog, MarkAllDialog, LBUsExportDialog,SimpleDropdown
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [QuickViewMixin],
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    created() {
        this.$eventBus.$on('refreshCBI', this.refreshCBI);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshCBI', this.refreshCBI);
    },
    data() {
        return {
            fields: [
                {key: "streamName", label: "Stream", class: 'stream-name-col', sortable: true},
                {key: "debitor", label: "Debitor", class: 'debitor-col'},
                {key: "pgnr", label: "PG-Nr", class: 'pgnr-col'},
                {key: "countOpen", label: "Offene LBU", class: 'open-lbu-count-col'},
                {key: "sumOpen", label: "Offener Betrag", class: 'open-lbu-sum-col'},
                {key: "countLocked", label: "Gesperrte LBU", class: 'locked-lbu-count-col'},
                {key: "sumLocked", label: "Gesperrter Betrag", class: 'locked-lbu-sum-col'},
                {key: "modus", label: "Modus", class: 'modus-col'},
                {key: "options", label: "Optionen"},
            ],
            actualFakturaMonth: false,
            pending: false,
            markLbuDialog: {
                show: false,
                item: null
            },
            showMarkAllDialog: false,
            lbuListDialog: {
                show: false,
                streamId: null,
                streamName: null
            },
            lbusExportDialog: {
                show: false,
            }
        }
    },
    computed: {
        ...mapState({
            cbiList: state => state.cbi.cbiList
        }),
        cbiListManual(){
            return this.cbiList.filter(e=> !e.sapInterfaceUsage && e.countOpen > 0);
        }
    },
    methods: {
        ...mapActions({
            fetchCBIList: 'cbi/fetchCBIList'
        }),

        async refreshCBI() {
            this.pending = true;
            await this.fetchCBIList(this.actualFakturaMonth ? 1 : 0);
            this.pending = false;
        },
        async onActualFakturaMonthChange() {
            let streamId = this.lbuListDialog.streamId;
            let streamName = this.lbuListDialog.streamName;
            this.clearLbuListDialog();
            await this.refreshCBI();
            if (streamId && streamName) {
                this.showLbuListDialog(streamId, streamName);
            }
        },
        showMarkLbuDialog(item) {
            this.markLbuDialog.show = true;
            this.markLbuDialog.item = item;
        },
        hideMarkLbuDialog(update) {
            this.markLbuDialog.show = false;
            this.markLbuDialog.item = null;

            if (update) {
                this.onActualFakturaMonthChange();
            }
        },
        hideLbuListDialog() {
            this.lbuListDialog.show = false;
        },
        showLbuListDialog(streamId, streamName) {
            this.clearLbuListDialog();
            this.lbuListDialog.streamId = streamId;
            this.lbuListDialog.streamName = streamName;
            this.lbuListDialog.show = true;
        },
        clearLbuListDialog() {
            this.hideLbuListDialog();
            this.lbuListDialog.streamId = null;
            this.lbuListDialog.streamName = null;
        },
        showLbusExportDialog(id) {
            this.lbusExportDialog.show = true;
        },
        hideLbusExportDialog() {
            this.lbusExportDialog.show = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/tables/new-table';

.table-title {
    font-size: 1.4rem;
}

#cbi-table {
    max-height: 450px;
}

::v-deep .simple-badge span.badge {
    color: #000;
}

::v-deep .pgnr-col,
::v-deep .open-lbu-sum-col,
::v-deep .locked-lbu-sum-col,
::v-deep .modus-col {
    border-right: 1px solid lightgrey;
}

::v-deep .options-col {
    width: 280px;
    min-width: 280px;
}

::v-deep .b-table-sticky-header {
    overflow-y: auto;
    max-height: 500px;
    margin: 0;
}
::v-deep .dropdown-menu {
    padding: 0.4rem 0.5rem !important;
}

.icon-lg {
    font-size: 40px;
}
</style>
