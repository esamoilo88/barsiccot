<template>
    <div class="mt-4">
        <h3 class="table-title text-muted font-weight-bold mb-3">LBU Liste</h3>

        <div class="mb-3">Stream: <span class="ml-2 font-weight-bold">{{ streamName }}</span></div>
        <table-simple
            table-id="lbu-list-table"
            :fields="fields"
            :filters="filters"
            :total-rows-prop="-1"
            :per-page-prop="-1"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
            :ready-items="items"
            ref="table"
            :fetch-on-mount="false"
            @new-items="value => setItems(value)"
            @applied-filters="value => filtersApplied(value)"
        >
            <template #cell(thema)="row">
                <div>
                    {{ 'SIN/' + row.item.simpleId }}
                    <br>
                    <span class="text-muted text-small">
                        <truncated-text
                            :text="row.item.thema + ' · ' + row.item.kundenname"
                            title="thema"
                            :width="300"
                        />
                    </span>
                </div>
            </template>
            <template #cell(projectStatusName)="row">
                <b-badge v-if="row.item.billingLocked" variant="danger">{{ row.item.projectStatusName }}</b-badge>
                <b-badge v-else variant="success">{{ row.item.projectStatusName }}</b-badge>
            </template>
            <template #cell(lbuStatusName)="row">
                <b-badge v-if="row.item.locked == '0'" variant="info">{{ row.item.lbuStatusName }}</b-badge>
                <b-badge v-else variant="danger">{{ row.item.lbuStatusName }}</b-badge>
            </template>
            <template #cell(fakturamonat)="row">
                {{ monthYearConcat(row.item.fakturaMonat, row.item.fakturaJahr, '/') }}
            </template>
            <template #cell(leistungsmonat)="row">
                {{ monthYearConcat(row.item.leistungsMonat, row.item.leistungsJahr, '/') }}
            </template>
            <template #cell(betrag)="row">
                <span :class="{'text-success': row.item.type === 'A1', 'text-danger': row.item.type === 'A2', 'font-weight-bold': true}"> {{ $f.numberToString(row.item.betrag, true, false, '0,00') }} </span>
            </template>
            <template #cell(optionen)="row">
                <b-button
                    :disabled="isProcessing(row.item.lbuId)"
                    :variant="row.item.locked != '0' ? 'success' : 'danger'"
                    @click="changeLbuStatus(row.item.lbuId, row.item.locked == '0')"
                >
                    <span :class="{'icon-content-unlock-default': row.item.locked != '0', 'icon-content-lock-default': row.item.locked == '0'}"></span>
                    {{ row.item.locked != '0' ? 'Entsperren' : 'Sperren' }}
                    <b-spinner v-if="isProcessing(row.item.lbuId)" small/>
                </b-button>
            </template>
        </table-simple>
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import Headline from "@comp/Headline/Headline";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import {BButton, BSpinner, BBadge} from 'bootstrap-vue';
import Badge from "@comp/Badge/Badge";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: "lbu-list-widget",
    mixins: [DatesProcessing],
    components: {
        TruncatedText,
        TableSimple, Headline, BButton, Badge, ModalDialog, BSpinner, BBadge
    },
    props: {
        streamId: {
            required: true,
            type: Number
        },
        show: {
            type: Boolean,
            default: false
        },
        switch: {
            type: Boolean,
            default: false
        },
        streamName: {
            required: true,
            type: String
        },
    },
    watch: {
        'streamId': async function () {
            await this.$refs.table.manualCtxTrigger();
        }
    },
    data() {
        return {
            fields: [
                {key: "lbuId", label: "LBU-ID", sortable: false, sortDirection: 'desc', sortKey: 'created'},
                {key: "thema", label: "Vorhaben", sortable: false, sortKey: 'thema'},
                {key: "projectStatusName", label: "Status", sortable: false, sortKey: 'status', class: 'truncated'},
                {key: "type", label: "Vorgangstyp", sortable: false, sortKey: 'vorgangstyp'},
                {key: "fakturamonat", label: "Fakturamonat", sortable: false, sortKey: 'bezeichnung'},
                {key: "leistungsmonat", label: "Leistungsmonat", sortable: false, sortKey: 'bezeichnung'},
                {key: "betrag", label: "Betrag", sortable: false, sortKey: 'betrag'},
                {key: "lbuStatusName", label: "LBU-Status", sortable: false, sortKey: 'status', class: 'truncated'},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            filters: [
                {
                    field: "vorgangstyp",
                    type: "select",
                    settings: {
                        preselected: 'alle',
                        label: "Vorgangstyp",
                        options: [{id: "alle", text: "Alle"}, {id: "a1", text: "A1 Rechnung"}, {id: "a2", text: "A2 Gutschrift"}]
                    }
                },
                {
                    field: "status",
                    type: "select",
                    settings: {
                        preselected: 'alle',
                        label: "Status",
                        options: [{id: "alle", text: "Alle"}, {id: "gesperrt", text: "Gesperrt"}, {id: "entsperrt", text: "Entsperrt"}]
                    }
                },
                {
                    field: "search",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'created',
            sortDesc: true,
            totalRows: 0,
            perPage: 10,
            isDetailsDialogVisible: false,
            visibleMailId: null,
            isLoading: false,
            processingLbus: [],
            items: [],
            upcomingUpdate: false,
            appliedFilters: {}
        }
    },
    async mounted() {
      await this.firstFetch();
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/admin/lbu/stream/' + this.streamId + '/lbu-list', {
                    ctx: ctx,
                    switch: this.switch
                });
                return response.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        async firstFetch() {
            this.$refs.table.makeTableBusy(true);
            const response = await this.$axios.post('/admin/lbu/stream/' + this.streamId + '/lbu-list', {
                ctx: {
                    currentPage: 1,
                    filter: {status: "alle", vorgangstyp: "alle"},
                    perPage: 0,
                    sortBy: "created",
                    sortDesc: true
                },
                switch: this.switch
            });
            this.items = response.data;
            this.$refs.table.makeTableBusy(false);
        },
        async changeLbuStatus(lbuId, shouldLocked) {
            try {
                this.processingLbus.push(lbuId);

                let response = await this.$axios.post(`/admin/lbu/stream/${this.streamId}/lbu-change-status/${lbuId}`, {
                    shouldLocked: shouldLocked
                });

                this.isLoading = false;

                let message = shouldLocked ? `LBU/${lbuId} wurde gesperrt.` : `LBU/${lbuId} wurde entsperrt.`;

                this.updateItem(lbuId, shouldLocked, response.data.statusName);

                window.flash.showMessagesFromAjax(message, 'success');
            } catch (err) {
                console.log(err);
                window.flash.showMessagesFromAjax(err.response.data);
            } finally {
                this.processingLbus = this.processingLbus.filter(lbu => lbu !== lbuId);
                this.setUpcomingUpdate();
            }
        },
        isProcessing(lbuId) {
            return this.processingLbus.includes(lbuId);
        },
        updateItem(lbuId, shouldLocked, statusName) {
            if (this.shouldRemoveFromList()) {
                this.items = this.items.filter(function (item) {
                    if (item.lbuId != lbuId) {
                        return item;
                    }
                });
            }
            this.items = this.items.map(function (item) {
                if (item.lbuId == lbuId) {
                    item.lbuStatusName = statusName;
                    item.locked = shouldLocked ? '1' : '0';
                }

                return item;
            })
        },
        setItems(items) {
            this.items = items;
        },
        updateCbiList() {
            this.$emit('refresh-cbi');

            this.upcomingUpdate = false;
        },
        filtersApplied(object) {
            this.appliedFilters = object;
        },
        shouldRemoveFromList() {
            if (Object.keys(this.appliedFilters).length === 0) return false;

            return this.appliedFilters.status != 'alle';
        },
        setUpcomingUpdate() {
            if (this.upcomingUpdate === false) {
                setTimeout(() =>
                    this.updateCbiList(), 2500
                )
                this.upcomingUpdate = true;
            }
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
::v-deep .optionen-col {
    text-align: left;
}

.link {
    position: absolute;
    right: 0;
    margin-right: 5px;
    top: 30px;
}

.text-small {
    font-size: 16px;
}


.table-title {
    font-size: 1.4rem;
}

</style>
