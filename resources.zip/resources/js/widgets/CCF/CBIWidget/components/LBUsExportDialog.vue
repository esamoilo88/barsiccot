<template>
    <div>
        <modal-dialog
            modal-class="lbus-export-dialog"
            :is-visible="show"
            @hideModal="hide"
            title-dialog="Fakturareport exportieren"
            scrollable
        >
            <div class="mb-3 text-muted">
                Exportiere die LBU-Daten um diese in Excel weiterzuverarbeiten.
            </div>

            <b-overlay :show="pending">
                <div class="simple-box">
                    <div class="mb-3">
                        <FormSelect
                            v-model="form.billingType"
                            name="billingType"
                            select-id="billingType-input"
                            :options="options.billingType"
                            label-text="Rechnungsart"
                        />
                    </div>

                    <div class="mb-5">
                        <FormSelect
                            v-model="form.modus"
                            name="modus"
                            select-id="modus-input"
                            :options="options.modus"
                            label-text="Modus"
                        />
                    </div>

                    <div class="font-weight-bold mb-3">LBU-Status</div>

                    <div class="d-flex">
                        <div class="first-column mr-5">
                            <div class="mb-3" v-for="(status, index) in statuses.firstColumn">
                                <b-form-checkbox :key="status.key" v-model="form[status.key]" :name="`${status.key}-input`" switch>
                                    {{ status.name }}
                                </b-form-checkbox>
                            </div>
                        </div>
                        <div class="second-column ml-3">
                            <div class="mb-3" v-for="(status, index) in statuses.secondColumn">
                                <b-form-checkbox :key="status.key" v-model="form[status.key]" :name="`${status.key}-input`" switch>
                                    {{ status.name }}
                                </b-form-checkbox>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <b-form-checkbox key="march-rule-checkbox" v-model="form.marchRuleIgnore" name="marchRule-input" switch>
                            März Regel ignorieren
                        </b-form-checkbox>
                    </div>
                    <div class="text-muted size">
                        Wenn aktiviert wird das Leistungsjahr nicht entsprechend der März-Regel gefiltert.
                    </div>

                    <FormDatepicker
                        v-model="form.date"
                        label-text="Fakturabereit Datum"
                        name="validity"
                        input-id="validity-input"
                        aria-controls="date-input"
                        class="mt-2"
                    />
                    <FormTimepicker
                        v-model="form.time"
                        label-text="Fakturabereit Zeit"
                        name="validity"
                        input-id="validity-input"
                        aria-controls="date-input"
                        class="mt-3"
                    />
                </div>
            </b-overlay>

            <a ref="download" class="d-none" href="/admin/lbu/export/download" download="Fakturadaten 3 AT.xlsx"></a>

            <template #footer="{methods}">
                <button :disabled="pending" @click="submit" class="btn btn-primary">Exportieren</button>
                <button @click="hide" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckbox, BOverlay, BFormTimepicker} from "bootstrap-vue";
import dayjs from "res/js/utils/day";
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import FormTimepicker from "@comp/FormDatepicker/FormTimepicker";

export default {
    components: {ModalDialog, FormSelect, BFormCheckbox, BOverlay, FormDatepicker, FormTimepicker},
    props: {
        show: {
            type: Boolean,
            default: false
        },
        date: {
            type: String,
            required: true
        },
        time: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            form: {
                billingType: 2,
                modus: 100,
                created: false,
                send: false,
                ready: true,
                transferred: false,
                accounted: false,
                rejected: false,
                locked: false,
                canceled: false,
                marchRuleIgnore: false,
                date: null,
                time: null
            },
            statuses: {
                firstColumn: [
                    {
                        name: 'Erstellt',
                        key: 'created',
                    },
                    {
                        name: 'Gesendet',
                        key: 'send',
                    },
                    {
                        name: 'Fakturabereit',
                        key: 'ready',
                    },
                    {
                        name: 'Übertragen',
                        key: 'transferred',
                    },
                ],
                secondColumn: [
                    {
                        name: 'Abgerechnet',
                        key: 'accounted',
                    },
                    {
                        name: 'Abgelehnt',
                        key: 'rejected',
                    },
                    {
                        name: 'Gesperrt',
                        key: 'locked',
                    },
                    {
                        name: 'Storniert',
                        key: 'canceled',
                    },
                ]
            },
            options: {
                billingType: [
                    {
                        id: 2,
                        text: 'Sammelfaktura'
                    },
                    {
                        id: 1,
                        text: 'Vertragsfaktura'
                    },
                    {
                        id: 0,
                        text: 'Alle'
                    }
                ],
                modus: [
                    {
                        id: 0,
                        text: 'Manuell'
                    },
                    {
                        id: 1,
                        text: 'Schnittstelle'
                    },
                    {
                        id: 100,
                        text: 'Alle'
                    }
                ]
            },
            pending: null,
        }
    },
    created() {
        this.setDefaultDateAndTime();
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async submit() {
            if (this.pending) return;

            this.pending = true;

            try {
                const response = await this.$axios.post('/admin/lbu/export', this.form);

                this.$refs.download.click();

                this.hide();

                window.flash.success('Datei exportiert');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        clear() {
            this.form.billingType = 2;
            this.form.modus = 100;
            this.form.created = false;
            this.form.send = false;
            this.form.ready = true;
            this.form.transferred = false;
            this.form.accounted = false;
            this.form.rejected = false;
            this.form.locked = false;
            this.form.canceled = false;
            this.setDefaultDateAndTime();
        },
        setDefaultDateAndTime() {
            this.form.date = this.date;
            this.form.time = this.time;
        }
    }
}
</script>
<style lang="scss" scoped>
    .size {
        font-size: 16px;
    }
</style>
