<template>
    <div class="table-wrapper mt-5">
        <b-table-lite
            table-id="invoice-positions-table"
            :fields="fields"
            :items="positions"
            borderless
            sticky-header
            primary-key="id"
        >
            <template #cell(simpleId)="row">
                <div>{{ defVal(row.item.auftrag.simpleId, '-') }}</div>
            </template>

            <template #cell(unitPrice)="row">
                <div>{{ $f.numberToString(defVal(row.item.unitPrice, 0.0), true) }}</div>
            </template>

            <template #cell(pspElement)="row">
                <div>{{ defVal(row.item.psp.pspElement, '-') }}</div>
            </template>

            <template #cell(matNr)="row">
                <div>{{ defVal(row.item.matNr.matNr, '-') }}</div>
            </template>

            <template #cell(icpKontierung)="row">
                <div v-if="row.item.sachkonto || row.item.icpKontPspKst">
                    {{getValue(row.item, "sachkonto.sachkonto", '-', true)}};{{ defVal(row.item.icpKontPspKst, '-') }}
                </div>
                <div v-else>-</div>
            </template>

        </b-table-lite>
    </div>
</template>

<script>
import {BTableLite} from 'bootstrap-vue';
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";

export default {
    name: "PositionsDetails",
    components: {
        BTableLite
    },
    mixins: [ScalarsProcessing, ObjectsProcessing],
    props: {
        positions: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            fields: [
                {key: "simpleId", label: "SIN", class: 'sin-col'},
                {key: "shortText", label: "Positionstext", class: 'short-text-col'},
                {key: "quantity", label: "Menge", class: 'quantity-col'},
                {key: "unitPrice", label: "Betrag", class: 'unit-price-col'},
                {key: "pspElement", label: "PSP-Element", class: 'psp-element-col'},
                {key: "matNr", label: "Mat-Nr", class: 'mat-nr-col'},
                {key: "icpKontierung", label: "ICP Kontierung", class: 'icp-kontierung-col'}
            ]
        }
    },
}
</script>

<style scoped>
#invoice-positions-table {
    max-height: 450px;
}

::v-deep .short-text-col,
::v-deep .unit-price-col {
    border-right: 1px solid lightgrey;
}
</style>
