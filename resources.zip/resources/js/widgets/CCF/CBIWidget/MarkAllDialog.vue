<template>
    <div>
        <modal-dialog
            modal-class="mark-all-dialog"
            :is-visible="show"
            @hideModal="hide(false)"
            title-dialog="LBU als abgerechnet markieren"
            size="lg"
        >
            Setze die LBU von ausgewälten Streams auf Status "Abgerechnet".
            <div class="row">
                <b-form-checkbox v-model="isAllSelected" :disabled="items.length === 0" @change="selectAll" class="mt-3 left-side select-all-checkbox">
                    Alle Streams auswählen
                </b-form-checkbox>
                <b-overlay :show="pending" class="right-side">
                    <div class="form-group">
                        <FormDatepicker
                            v-model="form.accounted"
                            :error-conditions="errorCondition.accounted"
                            input-id="accounted-input"
                            label-text="Abgerechnet am*"
                            name="accounted"
                            aria-controls="date-input"
                        />
                    </div>
                </b-overlay>
            </div>
            <div v-if="displayErrorMessage" class="error-message my-2">
                <span
                    :class="{'invalid-feedback': true, 'd-block': displayErrorMessage}"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true"
                >
                    Bitte wähle mindestens ein Stream aus.
                </span>
            </div>
            <div class="simple-box">
                <div class="table-wrapper">
                    <b-table
                        ref="cbiTable"
                        v-if="items"
                        :fields="fields"
                        :items="items"
                        show-empty
                    >
                        <template #empty="scope">
                            <div class="text-muted text-center">Keine Daten vorhanden</div>
                        </template>
                        <template #cell(checkCbi)="data">
                            <div>
                                <b-form-checkbox
                                    :key="`select-ap-checkbox-${data.item.streamId}`"
                                    :checked="isSelected(data.item.streamId)"
                                    @change="toggleCbi(data.item)"
                                ></b-form-checkbox>
                            </div>
                        </template>
                        <template #cell(sumOpen)="data">
                            <div class="font-weight-bold">
                                {{ $f.numberToString(data.item.sumOpen, true, false, '0,00') }}
                            </div>
                        </template>
                    </b-table>
                </div>
                <span class="selected-lps-number">{{ selectedCbis.length }} Streams ausgewählt</span>
            </div>
            <template #footer="{methods}">
                <button @click="submit" class="btn btn-primary" :disabled="items.length === 0 || pending">
                    <b-spinner v-if="pending" small></b-spinner>
                    Verbindlich markieren
                </button>
                <button @click="hide(false)" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {BOverlay, BTable, BFormCheckbox, BSpinner} from "bootstrap-vue";
import dayjs from 'dayjs';
import {required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {isDatetime} from "res/js/utils/Validators/DatesValidators";

export default {
    components: {ModalDialog, FormDatepicker, BOverlay, BTable, BFormCheckbox, BSpinner},
    mixins: [ConfirmationModal, Validation],
    props: {
        show: {
            required: true,
            type: Boolean,
            default: false
        },
        items: {
            required: true,
            type: Array
        },
        actualFakturaMonth: {
            required: true,
            type: Boolean
        }
    },
    computed: {
        errorCondition() {
            return {
                accounted: [
                    {
                        name: 'accounted-required',
                        condition: this.isInvalid('accounted', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Abgerechnet am'})
                    },
                    {
                        name: 'accounted-isDate',
                        condition: this.isInvalid('accounted', 'isDatetime'),
                        text: this.$t.__('validation.date', {attribute: 'Abgerechnet am'})
                    },
                ],
            }
        }
    },
    data() {
        return {
            form: {
                accounted: dayjs().format('DD.MM.YYYY HH:mm'),
            },
            displayErrorMessage: false,
            selectedCbis: [],
            isAllSelected: false,
            fields: [
                {key: "checkCbi", label: "Auswahl"},
                {key: "streamName", label: "Stream", class: 'stream-name-col'},
                {key: "countOpen", label: "Anzahl LBUs", class: 'open-lbu-count-col'},
                {key: "sumOpen", label: "Gesamtbetrag", class: 'open-lbu-sum-col'},
            ],
            pending: false,
            showValidationErrors: true
        }
    },
    methods: {
        hide(update = false) {
            this.$emit('hide', update);
        },
        selectAll() {
            this.$refs.cbiTable.items.map(item => {
                let selectedCbiIndex = this.selectedCbiIndex(item.streamId);
                if (selectedCbiIndex === -1) {
                    this.isAllSelected && this.selectedCbis.push(item);
                } else {
                    !this.isAllSelected && this.selectedCbis.splice(selectedCbiIndex, 1);
                }
            });
            this.$emit('input', this.selectedCbis);
        },
        isSelected(streamId) {
            return this.selectedCbiIndex(streamId) !== -1;
        },
        selectedCbiIndex(streamId) {
            let index = -1;
            this.selectedCbis.map((a, i) => {
                if (a.streamId === streamId) {
                    index = i;
                }
            });
            return index;
        },
        toggleCbi(item) {
            let index = this.selectedCbiIndex(item.streamId);
            if (index !== -1) {
                this.selectedCbis.splice(index, 1);
            } else {
                this.displayErrorMessage =false;
                this.selectedCbis.push(item);
            }
            this.$emit('input', this.selectedCbis);
        },
        async submit() {
            if (this.pending) return;

            this.$v.form.$touch();
            if (this.$v.form.$invalid || this.selectedCbis.length===0){
                this.displayErrorMessage =true;
                return;
            }

            const confirmed = await this.showConfirmationModal({
                title: 'Verbindlich markieren',
                message: `Bitte bestätige, dass du die LBUs verbindlich auf Status "Abgerechnet" setzen möchtest.`,
                okTitle: 'Ja, LBU verbindlich markieren',
                okVariant: 'primary'
            });

            if (!confirmed) return;

            this.pending = true;
            this.form.streamIds = this.selectedCbis.map(i => i.streamId);
            try {
                await this.$axios.post(`/admin/lbu/stream/mark-all`, this.form, {
                    params: {
                        actualFakturaMonth: this.actualFakturaMonth ? 1 : 0
                    }
                });

                window.flash.success('LBU wurden markiert');
                this.$emit('refresh-cbi');
                this.hide(true);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    },
    validations: {
        form: {
            accounted: {required, isDatetime},
        },
        selectedCbis: {required}
    }
}
</script>
<style lang="scss" scoped>
.right-side {
    margin-left: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>
