<template>
    <div>
        <modal-dialog
            modal-class="mark-lbu-dialog"
            :is-visible="show"
            @hideModal="hide(false)"
            title-dialog="LBU als abgerechnet markieren"
        >
            <div class="mb-3">
                Setze die LBU im Modus "Manuell" auf abgerechnet.
            </div>

            <div class="simple-box">
                <table class="w-100 mb-3">
                    <tr>
                        <td>Stream:</td>
                        <td class="font-weight-bold">{{ item.streamName }}</td>
                    </tr>
                    <tr>
                        <td>Anzahl LBUs:</td>
                        <td class="font-weight-bold">{{ item.countOpen }}</td>
                    </tr>
                    <tr>
                        <td>Gesamtbetrag:</td>
                        <td class="font-weight-bold">
                            {{ $f.numberToString(item.sumOpen, true, false, '0,00') }}
                        </td>
                    </tr>
                </table>

                <b-overlay :show="pending">
                    <div class="form-group">
                        <FormDatepicker
                            v-model="form.accounted"
                            :error-conditions="ec.accounted"
                            input-id="accounted-input"
                            label-text="Abgerechnet am*"
                            name="accounted"
                            aria-controls="date-input"
                        />
                    </div>
                </b-overlay>
            </div>

            <template #footer="{methods}">
                <button @click="submit" class="btn btn-primary">Markieren</button>
                <button @click="hide(false)" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {BOverlay} from "bootstrap-vue";
import dayjs from 'dayjs';
import {required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {isDatetime} from "res/js/utils/Validators/DatesValidators";

export default {
    components: {ModalDialog, FormDatepicker, BOverlay},
    mixins: [ConfirmationModal, Validation],
    props: {
        show: {
            required: true,
            type: Boolean,
            default: false
        },
        item: {
            required: true,
            type: Object
        },
        actualFakturaMonth: {
            required: true,
            type: Boolean
        }
    },
    computed: {
        ec() {
            return {
                accounted: [
                    {
                        name: 'accounted-required',
                        condition: this.isInvalid('accounted', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Abgerechnet am'})
                    },
                    {
                        name: 'accounted-isDate',
                        condition: this.isInvalid('accounted', 'isDatetime'),
                        text: this.$t.__('validation.date', {attribute: 'Abgerechnet am'})
                    },
                ],
            }
        }
    },
    data() {
        return {
            form: {
                accounted: dayjs().format('DD.MM.YYYY HH:mm'),
            },
            pending: false,
            showValidationErrors: true
        }
    },
    methods: {
        hide(update = false) {
            this.$emit('hide', update);
        },
        async submit() {
            if (this.pending) return;

            this.$v.form.$touch();
            if (this.$v.form.$invalid) return;

            const confirmed = await this.showConfirmationModal({
                title: 'Verbindlich markieren',
                message: `Bitte bestätige, dass du die LBUs verbindlich auf Status "Abgerechnet" setzen möchtest.`,
                okTitle: 'Ja, LBU verbindlich markieren',
                okVariant: 'primary'
            });

            if (!confirmed) return;

            this.pending = true;

            try {
                await this.$axios.post(`/admin/lbu/stream/${this.item.streamId}/mark`, this.form, {
                    params: {
                        actualFakturaMonth: this.actualFakturaMonth ? 1 : 0
                    }
                });

                window.flash.success('LBU wurden markiert');

                this.hide(true);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    },
    validations: {
        form: {
            accounted: {required, isDatetime},
        }
    }
}
</script>
