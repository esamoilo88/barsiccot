<template>
    <div>
        <HeaderDates
            class="mb-4"
            :current="data.dates.current"
            :u3="data.dates.u3"
            :u7="data.dates.u7"
        />

        <Sammelfaktura :data="data" />
    </div>
</template>

<script>
import Sammelfaktura from "res/js/widgets/CCF/CBIWidget/components/Sammelfaktura";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import {mapMutations} from "vuex";

export default {
    components: {HeaderDates, Sammelfaktura},
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    created() {
        if (this.data.error) {
            window.flash.error(this.data.error);
        } else {
            this.setCbiList(this.data.cbi);
        }
    },
    data() {
        return {
            sammelfakturaMode: true
        }
    },
    methods: {
        ...mapMutations({
            setCbiList: 'cbi/SET_CBI_LIST'
        })
    }
}
</script>
