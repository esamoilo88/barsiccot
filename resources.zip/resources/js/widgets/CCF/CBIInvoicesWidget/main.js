import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Formatter from "res/js/utils/formatter";
import {ModalPlugin} from 'bootstrap-vue';
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import Index from './Index';

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$t = t;

Vue.use(ModalPlugin);

export default new Vue({
    el: '#ccf-cbi-invoices', //resources/views/App/CCF/CBI/Invoices/index.blade.php
    components: {Index}
});
