<template>
    <div>
        <HeaderDates
            class="mb-4"
            :current="data.dates.current"
            :u3="data.dates.u3"
            :u7="data.dates.u7"
            :show-back-btn="true"
            @back="toSammelfaktura"
        />

        <InvoiceList />
    </div>
</template>

<script>
import InvoiceList from "res/js/widgets/CCF/CBIInvoicesWidget/components/InvoiceList";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";

export default {
    components: {HeaderDates, InvoiceList},
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    methods: {
        toSammelfaktura() {
            window.location.href = '/admin/ccf/collective-billing';
        }
    }
}
</script>
