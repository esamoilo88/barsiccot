<template>
    <b-overlay :show="pending">
        <div class="invoice-details-wrapper">
            <div v-if="!isEmptyObject(details)">
                <div class="row">
                    <div class="col-lg-6 pl-0">
                        <table class="invoice-data">
                            <tr><td>Stream:</td><td>{{ defVal(details.stream.name, '-') }}</td></tr>
                            <tr>
                                <td>Debitor (PG-Nr):</td>
                                <td>{{ defVal(details.debitor.nummer, '-') }} ({{defVal(details.debitor.gesellschaftsnummer, '-')}})</td>
                            </tr>
                            <tr>
                                <td>Gesamtbetrag:</td>
                                <td :class="{'success': defVal(overallSum, 0.0) > 0}">
                                    {{ $f.numberToString(defVal(overallSum, 0.0), true) }}
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="col-lg-12">
                        <table class="invoice-data">
                            <tr><td>Ansprechpartner:</td><td class="text-nowrap">{{ defVal(details.ansprechpartner.nachnameVornameTel, '-') }}</td></tr>
                            <tr><td>Rechnungsbetreff:</td><td>{{ defVal(details.billingSubject, '-') }}</td></tr>
                            <tr><td>Rechnungsdatum:</td><td>{{ formatDate(details.billingDate, 'DD.MM.YYYY', '-') }}</td></tr>
                        </table>
                    </div>

                    <div class="col-auto ml-auto">
                        <button class="more-details btn btn-link px-0" @click="showInvoiceDetailsDialog">Weitere Details</button>
                    </div>
                </div>

                <PositionsDetails v-if="details.positions && details.positions.length > 0" :positions="details.positions"/>
            </div>

           <div v-else-if="!pending">
               <span>Der Gesamtbetrag ist 0,00 EUR, daher kann keine Rechnung erstellt werden.</span>
           </div>
        </div>
    </b-overlay>
</template>

<script>
import {BOverlay, VBTooltip} from 'bootstrap-vue';
import {isEmpty} from '@helpers/ValueProcessing/ObjectsProcessing';
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import Badge from "@comp/Badge/Badge";
import PositionsDetails from "res/js/widgets/CCF/CBIWidget/components/PositionsDetails";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    name: "InvoiceDetails",
    components: {
        Badge, BOverlay, PositionsDetails
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [ScalarsProcessing, DatesProcessing, ConfirmationModal],
    props: {
        openedCbiItem: {
            type: Object,
            required: true
        },
        actualFakturaMonth: {
            type: Boolean,
            required: true
        },
        open: {
            type: Boolean,
            default: true
        }
    },
    watch: {
        'openedCbiItem.streamId': async function () {
            await this.getData();
        }
    },
    data() {
        return {
            details: {},
            pending: false
        }
    },
    computed: {
        overallSum() {
            let sum = 0.0;
            if (this.details.positions) {
                this.details.positions.map(p => sum += p.unitPrice);
            }
            return sum;
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            this.pending = true;
            try {
                const res = await this.$axios.get('/admin/cbi/invoice', {
                    params: {
                        switch: this.actualFakturaMonth ? 1 : 0,
                        streamId: this.openedCbiItem.stream.id,
                        invoiceId: this.openedCbiItem.id,
                        open: this.open ? 1 : 0
                    }
                });
                this.details = res.data[0];
            } catch (err) {
                console.error("Couldn't get invoice details data!");
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        isEmptyObject(obj) {
            return isEmpty(obj);
        },
        showInvoiceDetailsDialog() {
            this.$emit('showInvoiceDetailsDialog', this.details.id);
        }
    }
}
</script>

<style lang="scss" scoped>
@import '../../../../../sass/tables/new-table';

.rechnung-title {
    font-size: 1.4rem;
}
.invoice-data {
    td {
        padding: 0.25rem 0.4rem 0.25rem 0;
    }

    td:last-child {
        font-weight: bold;
        padding-left: 0.4rem;
    }
}
.invoice-details-wrapper {
    min-height: 200px;
}

.more-details {
    width: 115px;
}
</style>
