<template>
    <div class="simple-box box-shadow">
        <div class="d-flex align-items-center">
            <div class="pr-3">
                <i class="icon-user_file-billing-default icon-lg"></i>
            </div>
            <div>
                <h2 class="mb-0">
                    Rechnungen
                </h2>
                <div class="text-muted text-1r">Erstelle Rechnungen für die ISP Faktura und buche sie im SAP</div>
            </div>
        </div>

        <hr class="mb-5"/>

        <div class="mb-5 d-flex align-items-center">
            <b-form-checkbox v-model="allSelected" @change="selectAll" class="mr-3">
                Alle offenen Rechnungen markieren
            </b-form-checkbox>

            <button class="btn text-nowrap" @click="showActualFakturaMonthCheckbox(true)">
                <i class="icon-action-add-default"></i>
                Offene Rechnungen erstellen
            </button>

            <button class="btn text-nowrap" @click="showActualFakturaMonthCheckbox(false)">
                <i class="icon-action-refresh-default"></i>
                Offene Rechnungen aktualisieren
            </button>

            <button class="btn btn-primary text-nowrap ml-auto" @click="bill">
                <i class="icon-action-succsess-default"></i>
                Verbindlich buchen
            </button>
        </div>

        <b-overlay :show="pending">
            <div class="table-responsive table-wrapper mb-3">
                <table class="table">
                    <tr>
                        <th></th>
                        <th>Rechnungs-ID</th>
                        <th>Stream</th>
                        <th>Fakturamonat</th>
                        <th>Betreff</th>
                        <th>Betrag</th>
                        <th>Erstellt</th>
                        <th>Übertragen</th>
                        <th>Status</th>
                        <th>Optionen</th>
                    </tr>

                    <template v-for="item in data">
                        <tr>
                            <td>
                                <b-form-checkbox v-model="selected" :disabled="item.closed" :value="item"></b-form-checkbox>
                            </td>
                            <td>{{ leadingZeros(item.id) }}</td>
                            <td>{{ item.stream.name }}</td>
                            <td class="text-nowrap">{{ item.fakturaMonat }}/{{ item.fakturaJahr }}</td>
                            <td class="text-nowrap">{{ item.billingSubject }}</td>
                            <td class="text-nowrap">{{ getSum(item.positions) }}</td>
                            <td class="text-nowrap">{{ formatDate(item.created, 'DD.MM.YYYY HH:mm') }}</td>
                            <td class="text-nowrap">{{ formatDate(item.transferred, 'DD.MM.YYYY HH:mm') }}</td>
                            <td>
                                <span v-if="item.closed" class="badge badge-secondary">Geschlossen</span>
                                <span v-else class="badge badge-success">Offen</span>
                            </td>
                            <td>
                                <button class="btn btn-secondary" @click="toggleInvoiceDetails(item)">Anzeigen</button>
                            </td>
                        </tr>
                        <tr v-if="item.showDetails" class="bg-light">
                            <td colspan="9">
                                <InvoiceDetails
                                    :actual-faktura-month="actualFakturaMonthDialog.value"
                                    :openedCbiItem="item"
                                    :open="!item.closed"
                                    @showInvoiceDetailsDialog="showInvoiceDetailsDialog"
                                />
                            </td>
                        </tr>
                    </template>

                    <tr v-if="data.length === 0">
                        <td colspan="9" class="text-center text-muted">
                            Nicht gefunden
                        </td>
                    </tr>
                </table>
            </div>

            <div class="d-flex justify-content-end">
                <b-pagination
                    v-model="pagination.currentPage"
                    @input="getData"
                    :total-rows="pagination.total"
                    :per-page="pagination.perPage"
                ></b-pagination>
            </div>
        </b-overlay>

        <InvoiceDetailsDialog
            v-if="invoiceDetailsDialog.show"
            :show="invoiceDetailsDialog.show"
            :id="invoiceDetailsDialog.id"
            @hide="hideInvoiceDetailsDialog"
        />

        <modal-dialog
            modal-class="actual-faktura-month-dialog"
            :is-visible="actualFakturaMonthDialog.show"
            :title-dialog="actualFakturaMonthDialog.action === 'create' ? 'Offene Rechnung erstellen' : 'Offene Rechnungen aktualisieren'"
            @hideModal="hideActualFakturaMonthCheckbox"
        >
            <b-form-checkbox
                v-model="actualFakturaMonthDialog.value"
                switch
            >
                Aktuellen Fakturamonat berücksichtigen
            </b-form-checkbox>

            <template #footer="{methods}">
                <button @click="actualFakturaMonthDialog.action === 'create' ? recreateInvoice() : refresh()" class="btn btn-primary">{{ actualFakturaMonthDialog.btnTitle }}</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import {BOverlay, BPagination, BFormCheckbox} from "bootstrap-vue";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import InvoiceDetails from "res/js/widgets/CCF/CBIInvoicesWidget/components/InvoiceDetails";
import InvoiceDetailsDialog from "res/js/widgets/CCF/CBIInvoicesWidget/components/InvoiceDetailsDialog";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {leadingZeros} from "@helpers/ValueProcessing/ValueProcessing";

export default {
    components: {BOverlay, BPagination, InvoiceDetails, InvoiceDetailsDialog, ModalDialog, BFormCheckbox},
    mixins: [DatesProcessing, ConfirmationModal],
    data() {
        return {
            data: [],
            pending: false,
            pagination: {
                currentPage: 1,
                total: 0,
                perPage: 20,
            },
            selected: [],
            allSelected: false,
            invoiceDetailsDialog: {
                show: false,
                id: null
            },
            actualFakturaMonthDialog: {
                value: false,
                show: false,
                btnTitle: null,
                action: null
            }
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            this.pending = true;

            try {
                const response = await this.$axios.get('/admin/cbi/invoice/list', {
                    params: {
                        actualFakturaMonth: this.actualFakturaMonthDialog.value ? 1 : 0,
                        currentPage: this.pagination.currentPage
                    }
                });

                this.data = response.data.data;
                this.pagination.total = response.data.total;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
            this.actualFakturaMonthDialog.show = false;
        },
        getSum(data) {
            let init = 0;

            const sum = data.reduce(
                (prev, current) => prev + current.unitPrice,
                init
            );

            return this.$f.numberToString(sum, true);
        },
        toggleInvoiceDetails(item) {
            if (item.showDetails === undefined) {
                this.$set(item, 'showDetails', true);
            } else {
                item.showDetails = !item.showDetails;
            }
        },
        async bill() {
            if (this.selected.length === 0) return;

            const h = this.$createElement;

            let table = '';

            this.selected.forEach(invoice => {
                let overallSum = this.getOverallSum(invoice);

                table += `
                    <tr>
                        <td class="p-2">Rechnungsbetreff:</td>
                        <td class="p-2"><b>${invoice.billingSubject}</b></td>
                    </tr>
                    <tr>
                        <td class="p-2">Betrag:</td>
                        <td class="p-2 ${overallSum > 0 ? 'text-success' : ''}">
                            <b>${this.$f.numberToString(overallSum, true)}</b>
                        </td>
                    </tr>
                `
            });

            let message = h('div', {
                domProps: {
                    innerHTML: `
                        <p class="mb-3">Bitte bestätige, dass du die nachfolgende Rechnung im SAP buchen möchtest.</p>
                        <table>${table}</table>
                    `
                }
            });

            const confirmed = await this.showConfirmationModal({
                title: 'Verbindlich buchen',
                message: message,
                okTitle: 'Rechnung verbindlich buchen',
                okVariant: 'primary'
            });

            if (confirmed) {
                this.pending = true;

                try {
                    await this.$axios.post('/admin/cbi/invoice/bill', {
                        ids: this.selected.map(item => item.id)
                    });

                    window.flash.success('Rechnung erfolgreich an SAP übertragen.');

                    await this.getData();
                } catch (err) {
                    console.log("Error during bill of the invoice! Err:", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }

                this.pending = false;
                this.selected = [];
            }
        },
        async recreateInvoice() {
            this.pending = true;
            try {
                await this.$axios.get('/admin/cbi/invoice/recreate', {
                    params: {
                        switch: this.actualFakturaMonthDialog.value ? 1 : 0,
                    }
                });

                await this.getData();
            } catch (err) {
                console.error("Couldn't recreate invoice!");
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
            this.actualFakturaMonthDialog.show = false;
        },
        getOverallSum(invoice) {
            let sum = 0.0;
            if (invoice.positions) {
                invoice.positions.map(p => sum += p.unitPrice);
            }
            return sum;
        },
        showInvoiceDetailsDialog(id) {
            this.invoiceDetailsDialog.show = true;
            this.invoiceDetailsDialog.id = id;
        },
        hideInvoiceDetailsDialog() {
            this.invoiceDetailsDialog.show = false;
            this.invoiceDetailsDialog.id = null;
        },
        showActualFakturaMonthCheckbox(create) {
            this.actualFakturaMonthDialog.show = true;

            if (create) {
                this.actualFakturaMonthDialog.action = 'create';
                this.actualFakturaMonthDialog.btnTitle = 'Offene Rechnungen erstellen';
            } else {
                this.actualFakturaMonthDialog.action = 'refresh';
                this.actualFakturaMonthDialog.btnTitle = 'Offene Rechnungen aktualisieren';
            }
        },
        hideActualFakturaMonthCheckbox() {
            this.actualFakturaMonthDialog.show = false;
            this.actualFakturaMonthDialog.action = null;
            this.actualFakturaMonthDialog.btnTitle = null;
        },
        selectAll() {
            this.selected = this.allSelected ? this.data.filter(item => !item.closed) : [];
        },
        async refresh() {
            this.pending = true;
            try {
                await this.$axios.post('/admin/cbi/invoice/refresh', {
                    switch: this.actualFakturaMonthDialog.value ? 1 : 0,
                });

                await this.getData();
            } catch (err) {
                console.error("Couldn't recreate invoice!");
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
            this.actualFakturaMonthDialog.show = false;
        },
        leadingZeros(id) {
            return leadingZeros(id, 9, 'CB');
        }
    }
}
</script>

<style lang="scss" scoped>
@import '../../../../../sass/tables/new-table';

.table-title {
    font-weight: bold;
    font-size: 1.4rem;
}

.icon-lg {
    font-size: 40px;
}
</style>
