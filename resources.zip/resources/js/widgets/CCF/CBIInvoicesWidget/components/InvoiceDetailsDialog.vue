<template>
    <div>
        <modal-dialog
            modal-class="invoice-details-dialog"
            :is-visible="show"
            @hideModal="hide"
            title-dialog="Rechnungsdetails"
        >
            <b-overlay :show="pending">
                <table class="mb-3">
                    <tr>
                        <td width="200px">Stream:</td>
                        <td class="font-weight-bold">{{ invoice.stream.name }}</td>
                    </tr>
                    <tr>
                        <td>Fakturamonat:</td>
                        <td class="font-weight-bold">{{ invoice.fakturaMonat }}/{{ invoice.fakturaJahr }}</td>
                    </tr>
                    <tr>
                        <td>Rechnungsteil:</td>
                        <td class="font-weight-bold">1 von {{ invoicesCount }}</td>
                    </tr>
                    <tr>
                        <td>Anzahl LBUs:</td>
                        <td class="font-weight-bold">{{ invoice.positions.length }}</td>
                    </tr>
                    <tr>
                        <td>Gesamtbetrag:</td>
                        <td class="font-weight-bold" :class="{'text-success': defVal(overallSum, 0.0) > 0}">
                            {{ $f.numberToString(overallSum, true) }}
                        </td>
                    </tr>
                    <tr>
                        <td>Status:</td>
                        <td class="font-weight-bold">
                            <badge v-if="invoice.closed" class="status-badge" color="#d90000">Geschlossen</badge>
                            <badge v-else class="status-badge" color="#46a800">Offen</badge>
                        </td>
                    </tr>
                </table>

                <table class="mb-3">
                    <tr>
                        <td width="200px">Rechnungsbetreff:</td>
                        <td class="font-weight-bold">{{ invoice.billingSubject }}</td>
                    </tr>
                    <tr>
                        <td>Rechnungsdatum:</td>
                        <td class="font-weight-bold">{{ formatDate(invoice.billingDate, 'DD.MM.YYYY') }}</td>
                    </tr>
                    <tr>
                        <td>Debitor:</td>
                        <td class="font-weight-bold">{{ invoice.debitor.nummer }}</td>
                    </tr>
                    <tr>
                        <td>PG-Nr:</td>
                        <td class="font-weight-bold">{{ invoice.debitor.gesellschaftsnummer }}</td>
                    </tr>
                    <tr>
                        <td>Referenz:</td>
                        <td class="font-weight-bold">{{ invoice.billingHeadReference }}</td>
                    </tr>
                </table>

                <table class="mb-3">
                    <tr>
                        <td width="200px">Erstellt von:</td>
                        <td class="font-weight-bold">{{ invoice.createdBy.nachnameVorname }}</td>
                    </tr>
                    <tr>
                        <td>Ansprechpartner:</td>
                        <td class="font-weight-bold">{{ invoice.ansprechpartner.nachnameVorname }}</td>
                    </tr>
                    <tr>
                        <td>Erstellt am:</td>
                        <td class="font-weight-bold">{{ formatDate(invoice.created, 'DD.MM.YYYY HH:mm') }}</td>
                    </tr>
                    <tr>
                        <td>Übertragen am:</td>
                        <td class="font-weight-bold">{{ formatDate(invoice.transferred, 'DD.MM.YYYY HH:mm') }}</td>
                    </tr>
                </table>

                <table>
                    <tr>
                        <td width="200px">SIMPLE Invoice-ID:</td>
                        <td class="font-weight-bold">{{ invoice.id }}</td>
                    </tr>
                    <tr>
                        <td>SAP Schnittstellendatei:</td>
                        <td class="font-weight-bold">{{ invoice.sapInterfaceFilename }}</td>
                    </tr>
                    <tr>
                        <td>SAP Auftragsnummer:</td>
                        <td class="font-weight-bold">{{ invoice.sapTransactionCode }}</td>
                    </tr>
                    <tr>
                        <td>SAP Rechnungsnummer:</td>
                        <td class="font-weight-bold">{{ invoice.sapInvoiceCode }}</td>
                    </tr>
                    <tr>
                        <td>SAP Status:</td>
                        <td class="font-weight-bold">{{ invoice.sapStatus }}</td>
                    </tr>
                </table>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="hide" class="btn btn-secondary">Schließen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import Badge from "@comp/Badge/Badge";
import {BOverlay} from "bootstrap-vue";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";

export default {
    components: {ModalDialog, Badge, BOverlay},
    mixins: [DatesProcessing, ScalarsProcessing],
    props: {
        id: {
            required: true,
            type: Number
        },
        show: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        overallSum() {
            let init = 0.0;

            const sum = this.invoice.positions.reduce(
                (prev, current) => prev + current.unitPrice,
                init
            );

            return sum;
        }
    },
    data() {
        return {
            invoice: {
                stream: {},
                debitor: {},
                createdBy: {},
                ansprechpartner: {},
                positions: [],
                lbus: []
            },
            invoicesCount: 0,
            pending: false
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async getData() {
            if (this.pending) return;

            this.pending = true;

            try {
                const response = await this.$axios.get(`/admin/cbi/invoice/${this.id}/details`);

                if (response.data.invoice) {
                    this.invoice = response.data.invoice;
                    this.invoicesCount = response.data.invoicesCount;
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
td:empty:after {
    content: "-";
}
</style>
