<template>
    <div>
        <HeaderDates class="mb-4" :current="datesParsed.current" :u3="datesParsed.u3" :u7="datesParsed.u7"/>
        <div class="content simple-box box-shadow">
            <div class="d-flex align-items-center">
                <h2 class="mr-4"><span class="icon-content-lock-default mr-2"></span>Finanzsperre einrichten</h2>
                <span class="text-muted text-1r">Sperre die Abrechnung eines Vertrags</span>
            </div>

            <hr class="mb-3"/>
            <table-simple
                table-id="project-lock-list-table"
                :fields="fields"
                :filters="filters"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="itemsProvider"
                ref="table"
            >
                <template #cell(shortName)="row">
                    <b-badge v-if="row.item.billingLocked" variant="danger">{{ row.item.shortName }}</b-badge>
                    <b-badge v-else variant="success">{{ row.item.shortName }}</b-badge>
                </template>
                <template #cell(optionen)="row">
                    <b-button
                        :disabled="isProcessing(row.item.simpleId)"
                        :variant="row.item.billingLocked ? 'success' : 'danger'"
                        @click="changeStatus(row.item.simpleId, !row.item.billingLocked)"
                    >
                        <span :class="{'icon-content-unlock-default': row.item.billingLocked, 'icon-content-lock-default': !row.item.billingLocked}"></span>
                        {{ row.item.billingLocked ? 'Entsperren' : 'Sperren' }}
                        <b-spinner
                            v-if="isProcessing(row.item.simpleId)"
                            small
                        />
                    </b-button>
                </template>
            </table-simple>
        </div>
    </div>

</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import Headline from "@comp/Headline/Headline";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import {BButton, BSpinner, BBadge} from 'bootstrap-vue';
import Badge from "@comp/Badge/Badge";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";

export default {
    name: "lock",
    mixins: [DatesProcessing],
    components: {
        TruncatedText,
        TableSimple, Headline, BButton, Badge, ModalDialog, BSpinner, BBadge, HeaderDates
    },
    props: {
        data: {
            type: Object,
            required: true,
        }
    },
    computed: {
        htmlContentParsed() {
            return this.data.html// !== '' ?  JSON.parse(this.htmlContent) : '';
        },
        datesParsed() {
            return this.data.dates// !== '[]' ?  JSON.parse(this.dates) : {current: {date: '-', u: '-', at: '-'}, u3: '-', u7: '-'};
        },
    },
    data() {
        return {
            fields: [
                {key: "simpleId", label: "SIN", sortable: true, sortDirection: 'desc', sortKey: 'simpleId'},
                {key: "thema", label: "Vorhabenname", sortable: true, sortKey: 'thema'},
                {key: "kundenname", label: "Kundenname", sortable: true, sortKey: 'kundenname'},
                {key: "shortName", label: "Status", sortable: false},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            filters: [
                {
                    field: "status",
                    type: "select",
                    settings: {
                        preselected: 'gesperrt',
                        label: "Status",
                        options: [{id: "gesperrt", text: "Gesperrt"}, {id: "aktiv", text: "Aktiv"}]
                    }
                },
                {
                    field: "search",
                    type: "text",
                    settings: {label: "Suchen..."}
                },
            ],
            sortBy: 'simpleId',
            sortDesc: true,
            totalRows: 0,
            perPage: 10,
            isDetailsDialogVisible: false,
            visibleMailId: null,
            isLoading: false,
            processingProjects: []
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/admin/ccf/lock-billing/list', ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        async changeStatus(simpleId, shouldLocked) {
            try {
                this.processingProjects.push(simpleId);

                await this.$axios.post(`/admin/ccf/lock-billing/${simpleId}/change-status`, {
                    shouldLocked: shouldLocked
                });

                this.isLoading = false;

                let message = shouldLocked ?
                    `Finanzsperre für SIN/${simpleId} eingerichtet.` :
                    `Finanzsperre für SIN/${simpleId} entfernt.`;

                await this.$refs.table.manualCtxTrigger();

                window.flash.showMessagesFromAjax(message, 'success');
            } catch (err) {
                console.log(err);
                window.flash.showMessagesFromAjax(err.response.data);
            } finally {
                this.processingProjects = this.processingProjects.filter(sin => sin !== simpleId);
            }
        },
        isProcessing(simpleId) {
            return this.processingProjects.includes(simpleId);
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
::v-deep .optionen-col {
    text-align: left;
}

.content {
    position: relative;
}

.link {
    position: absolute;
    right: 0;
    margin-right: 5px;
    top: 30px;
}
</style>
