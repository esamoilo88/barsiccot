<template>
    <div>
        <HeaderDates class="mb-4" :current="data.dates.current" :u3="data.dates.u3" :u7="data.dates.u7"/>

        <div class="simple-box box-shadow p-4">
            <div class="d-flex align-items-center">
                <h2 class="mr-4"><span class="icon-action-edit-default mr-2"></span>Datenkorrektur</h2>
                <span class="text-muted text-1r">Lade Daten in einem einheitlichen Datenformat hoch um Abrechnungsdaten zu korrigieren</span>
            </div>

            <hr class="mb-5"/>

            <div class="d-flex page-height">
                <div class="mr-5 w-100">
                    <b-overlay class="w-75" :show="dataLoading">
                        <form-file-load
                            v-model="file"
                            ref="file"
                            type="file"
                            browse-text="Auswählen"
                            @uploadFile="upload"
                            placeholder="Importdatei auswählen oder Drag/Drop"
                            accept=".xlsx,.xls"
                            class="mb-5"
                        />
                    </b-overlay>
                    <div v-if="showErrorForm">
                        <div class="mb-3" >
                            <img
                                class="icon mr-2"
                                :src="'/img/icons/error_graphical.svg'"
                                :alt="'Fehler'"
                            />
                            <span>In der Datei {{ errorsCount === 1 ? 'ist' : 'sind' }} {{ errorsCount }} Fehler enthalten. </span>
                        </div>
                        <b-overlay :show="pending">
                            <div class="table-wrapper">
                                <b-table
                                    responsive
                                    :fields="errorFields"
                                    :items="issues"
                                >
                                    <template #cell(error)="item">
                                        <div v-html="item.item.error"></div>
                                    </template>
                                </b-table>
                            </div>
                        </b-overlay>
                    </div>
                    <div v-else-if="success">
                        <img
                            class="icon mr-2"
                            :src="'/img/icons/confirm_graphical.svg'"
                            :alt="'erfolgreich'"
                        />
                        <span v-if="successCount === 1"> Es wurde {{ successCount }} Änderung erfolgreich durchgeführt. </span>
                        <span v-else> Es wurden {{ successCount }} Änderungen erfolgreich durchgeführt. </span>
                    </div>
                </div>
                <div class="w-100">
                    <div class="simple-box p-4">
                        <h5 class="mb-4">Informationen</h5>
                        <div class="font-weight-bold mb-4">
                            <a
                                href="/admin/ccf/corrections/download"
                                download
                            >
                                <span class="icon-action-download-default"></span>
                                Vorlage runterladen
                            </a>
                        </div>
                        <div class="w-90">
                            <ul>
                                <li class="mb-2">Datenkorrekturen können erforderlich sein, wenn im Abrechnungsprozess Unstimmigkeiten oder Fehler festgestellt werden</li>
                                <li class="mb-2">Mit der Vorlage können beliebig viele Korrekturen durchgeführt werden</li>
                                <li class="mb-2">Korrekturen werden vor der Änderung geprüft und müssen gültig sein</li>
                                <li class="mb-2">Mit der Vorlage ist es nicht möglich Daten hinzuzufügen oder zu löschen</li>
                                <li class="mb-2">Es können nur ausgewählte Datenfelder korrigiert werden (siehe Vorlage)</li>
                                <li class="">Nach der erfolgreichen Korrektur sind die Daten ohne Zeitverzug aktualisiert</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
import {BOverlay, BSpinner, BTable, BInputGroup, BInputGroupPrepend} from 'bootstrap-vue';
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import Badge from "@comp/Badge/Badge";
import TableSimple from "@comp/TableSimple/TableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import FormFileLoad from '@comp/FileLoad/FormFileLoad'

export default {
    name: "Datenkorrektur",
    components: {
        HeaderDates, FormFileLoad, Badge, BOverlay, TableSimple, FormSelect, BInputGroup,
        BInputGroupPrepend, FormInputAppend, ButtonIcon, BSpinner, BTable
    },
    mixins: [Pagination],
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    created() {
        if (this.data.error) {
            window.flash.error(this.data.error);
        }
    },
    data() {
        return {
            pending: false,
            dataLoading: false,
            attachedFile: null,
            mapping: [],
            file: {},
            showErrorForm: false,
            issues: [],
            errorFields: [
                {
                    key: 'row',
                    label: 'Zeile',
                },
                {
                    key: 'column',
                    label: 'Spalte'
                },
                {
                    key: 'error',
                    label: 'Fehler'
                },
            ],
            errorsCount: 0,
            success: false,
            successCount: 0
        }
    },
    methods: {
        closeForm() {
            this.openedDiscount = null;
            setTimeout(() => {
                document.getElementById('new-discount-btn').focus();
            }, 200);
        },
        async upload(filesInfo) {
            this.refresh();

            this.dataLoading = true;
            try {
                let res = await this.$axios.post(`/admin/ccf/corrections/upload`,
                    filesInfo.formData
                );

                if (res.data.issues && Object.keys(res.data.issues).length > 0) {
                    this.setIssues(res.data.issues);
                    this.showErrorForm = true;
                } else {
                    this.success = true;
                    this.successCount = res.data.success;
                }
            } catch (err) {
                console.error(err);
                if (err.response) {
                    window.flash.showMessagesFromAjax(err.response.data);
                } else {
                    this.$emit('close-dialog');
                    window.flash.showMessagesFromAjax('Bitte versuchen Sie noch einmal.', 'error');
                }
            } finally {
                this.file = {};
                this.$refs.file.clearFiles();
                this.dataLoading = false;
            }
        },
        setIssues(issues) {
            let newErrors = [];
            let errorsCount = 0;
            for (let row in issues) {
                if (issues.hasOwnProperty(row)) {
                    issues[row].forEach(function (error) {
                        newErrors.push({
                            row: row,
                            column: error.column,
                            error: error.message
                        })
                        errorsCount++;
                    })
                }
            }
            this.issues = newErrors;
            this.errorsCount = errorsCount;
        },
        refresh() {
            this.successCount = 0;
            this.success = false;
            this.errorsCount = 0;
            this.showErrorForm = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/tables/new-table';

.mr-right {
    margin-right: 300px;
}

.icon {
    width: 26px;
}

.page-height {
    min-height: 300px;
}

</style>
