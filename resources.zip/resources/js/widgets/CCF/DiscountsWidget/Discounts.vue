<template>
    <div>
        <HeaderDates class="mb-4" :current="data.dates.current" :u3="data.dates.u3" :u7="data.dates.u7"/>

        <div class="simple-box box-shadow p-4">
            <div class="d-flex align-items-center">
                <h2 class="mr-4"><span class="icon-content-voucher-default mr-2"></span>Rabattierung einrichten</h2>
                <span class="text-muted text-1r">Stelle die Rabattierung für einen Vertrag ein</span>
            </div>

            <hr class="mb-5"/>

            <div v-if="!openedDiscount">
                <div class="filters d-flex flex-wrap align-items-center">
                    <button @click="newDiscount" id="new-discount-btn" class="new-discount-btn btn btn-primary mr-2">
                        <span class="icon-action-add-default mr-2"></span>
                        Neue Rabattierung
                    </button>
                    <FormSelect
                        v-model="filters.status"
                        :readonly="pending"
                        class="status-select mr-2"
                        @select="val => onFilterChange('status', val)"
                        select-id="status-select"
                        name="status-select"
                        label-text="Status"
                        :options="statusOptions"
                    />
                    <FormInputAppend
                        v-model="filters.search"
                        input-id="search-input"
                        class="search-input"
                        name="search-input"
                        label-text="Suche"
                        prepended
                        v-debounce:1000ms="val => onFilterChange('search', val)"
                        debounce-events="input"
                        :disabled="pending"
                    >
                        <template #prepend>
                            <b-input-group-prepend is-text>
                                <span class="icon-action-search-default"></span>
                            </b-input-group-prepend>
                        </template>
                    </FormInputAppend>
                </div>

                <table-simple
                    class="mt-2"
                    table-id="discounts-table"
                    :fields="fields"
                    :items-provider="getDiscounts"
                    :per-page-prop="perPage"
                    :total-rows-prop="totalRows"
                    :filters="[]"
                    borderless
                    primary-key="simpleId"
                    ref="table"
                    :per-page-variants="perPageVariants"
                    @per-page-changed="val => this.perPage = val"
                >
                    <template #cell(simpleId)="row">
                        <a :href="'/orders/' + row.item.simpleId">{{ row.item.simpleId }}</a>
                    </template>

                    <template #cell(status)="row">
                        <badge :color="row.item.color">{{ row.item.shortName }}</badge>
                    </template>

                    <template #cell(gmkzAlt)="row">
                        <div>
                            <span>
                                {{ $f.numberToString(row.item.gmkzAlt, false, false, '0,00', {maximumFractionDigits: 4, minimumFractionDigits: 1}) }} %
                            </span>
                        </div>
                    </template>

                    <template #cell(gmkzNeu)="row">
                        <div>
                            <span>
                                {{ $f.numberToString(row.item.gmkzNeu, false, false, '0,00', {maximumFractionDigits: 4, minimumFractionDigits: 1}) }} %
                            </span>
                        </div>
                    </template>

                    <template #cell(preisnachlass)="row">
                        <div>
                            <span>
                                {{ $f.numberToString(row.item.preisnachlass, false, false, '0,00', {maximumFractionDigits: 4, minimumFractionDigits: 1}) }} %
                            </span>
                        </div>
                    </template>

                    <template #cell(options)="row">
                        <ButtonIcon
                            @click="editDiscount(row.item)"
                            icon-class="icon-content-voucher-default"
                            variant="secondary"
                            title="Rabattierung bearbeiten"
                            hint-position="topleft"
                            :id="'discount-details-btn-' + row.item.simpleId"
                        />
                    </template>
                </table-simple>
            </div>

            <Form v-else :data="openedDiscount" @close-form="closeForm"/>
        </div>
    </div>
</template>

<script>
import {BOverlay, BInputGroup, BInputGroupPrepend} from 'bootstrap-vue';
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import Badge from "@comp/Badge/Badge";
import TableSimple from "@comp/TableSimple/TableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {getFilterParams} from "@helpers/Tables/tableSimple";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import Form from "./components/Form";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    name: "Discounts",
    components: {
        Form,
        HeaderDates, Badge, BOverlay, TableSimple, FormSelect, BInputGroup,
        BInputGroupPrepend, FormInputAppend, ButtonIcon
    },
    mixins: [Pagination],
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    created() {
        if (this.data.error) {
            window.flash.error(this.data.error);
        }

        this.$eventBus.$on('refreshDiscounts', this.getDiscounts);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshDiscounts', this.getDiscounts);
    },
    data() {
        return {
            fields: [
                {key: "simpleId", label: "SIN", class: 'sin-col', sortable: true},
                {key: "thema", label: "Vorhabenname", class: 'project-name-col', sortable: true},
                {key: "kundenname", label: "Kundenname", class: 'customer-name-col', sortable: true},
                {key: "status", label: "Status", class: 'status-col'},
                {key: "gmkzAlt", label: "GMKZ alt", class: 'gmkz-alt-col'},
                {key: "gmkzNeu", label: "GMKZ neu", class: 'gmkz-neu-col'},
                {key: "preisnachlass", label: "Preisnachlass", class: 'preisnachlass-col'},
                {key: "options", label: "Optionen", class: 'options-col'},
            ],
            filters: {
                status: 1,
                search: ''
            },
            statusOptions: [{id: 1, text: "Aktive Verträge"}, {id: 2, text: "Inaktive Verträge"}],
            perPageVariants: [20, 40, 60, 80, 100, -1],
            pending: false,
            openedDiscount: null
        }
    },
    methods: {
        async getDiscounts(ctx, cancelToken) {
            this.pending = true;
            try {
                const res = await this.$axios.get('/admin/ccf/discount/list', {
                        params: {
                            currentPage: ctx.currentPage,
                            sortBy: ctx.sortBy,
                            sortDesc: ctx.sortDesc ? 1 : 0,
                            ...getFilterParams(!isEmpty(ctx.filter) ? ctx : {filter: this.filters})
                        }
                    },
                    {cancelToken: cancelToken.token}
                );
                this.totalRows = res.data.total;
                return res.data.data;
            } catch (err) {
                console.error('Couldn\'t fetch discounts list');
                window.flash.error(this.$t.__('errors.generic_error'));
                return [];
            } finally {
                this.pending = false;
            }
        },
        async onFilterChange(field, value) {
            this.pending = true;

            let ctx = this.$refs.table.getContext();
            this.filters[field] = value;
            ctx.filter = {...this.filters};
            ctx.isCustomFilter = true;
            await this.$refs.table.handleCtxChange(ctx);

            this.pending = false;
        },
        editDiscount(discount) {
            this.openedDiscount = discount;
        },
        newDiscount() {
            this.openedDiscount = {};
        },
        closeForm() {
            this.openedDiscount = null;
            setTimeout(() => {
                document.getElementById('new-discount-btn').focus();
            }, 200);

        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/tables/new-table';

.table-title {
    font-size: 1.4rem;
}

::v-deep .simple-badge span.badge {
    color: #000;
}

::v-deep .pgnr-col,
::v-deep .open-lbu-sum-col,
::v-deep .locked-lbu-sum-col,
::v-deep .modus-col {
    border-right: 1px solid lightgrey;
}

::v-deep .options-col {
    width: 280px;
    min-width: 280px;
}

::v-deep .b-table-sticky-header {
    overflow-y: auto;
    max-height: 500px;
    margin: 0;
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}

.new-discount-btn {
    width: 190px;
    height: 44px;
}

.search-input {
    width: 250px;
}
</style>
