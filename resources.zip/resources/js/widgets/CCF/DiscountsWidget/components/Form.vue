<template>
    <div>
        <b-overlay :show="pending">
            <SearchProjectDiscount :data="discount" @start-search="pending = true" @found-discount="setDiscountData"/>

            <div v-if="discount && discount.simpleId" class="row mt-3">
                <div class="col-xl-16 col-lg-24 mt-2 pl-0">
                    <div class="simple-box row">
                        <div class="discount-form col-lg-12 col-sm-24 d-flex flex-column">
                            <h3>Rabattierung</h3>

                            <b-form-checkbox
                                :disabled="!discount.active"
                                class="vertrag-switch mt-3"
                                v-model="useDiscount"
                                switch
                            >
                                Vertrag rabattieren
                            </b-form-checkbox>

                            <FormInputAppend
                                class="mt-3"
                                v-model="preisnachlassComputed"
                                input-id="preisnachlass-input"
                                name="preisnachlass-input"
                                label-text="Preisnachlass*"
                                :error-conditions="[
                                    {
                                        name: 'invalid-preisnachlass',
                                        condition: !$v.discount.preisnachlass.validFloat  && $v.discount.preisnachlass.$dirty,
                                        text: $t.__('validation.wrong_data')
                                    }
                                ]"
                                prepend="%"
                                :disabled="!discount.active"
                            />
                            <FormInputAppend
                                class="mt-2"
                                v-model="gmkzAltComputed"
                                input-id="gmkz-alt-input"
                                name="gmkz-alt-input"
                                label-text="GMKZ alt*"
                                :error-conditions="[
                                    {
                                        name: 'invalid-gmkz-alt',
                                        condition: !$v.discount.gmkzAlt.validFloat  && $v.discount.gmkzAlt.$dirty,
                                        text: $t.__('validation.wrong_data')
                                    }
                                ]"
                                prepend="%"
                                :disabled="!discount.active"
                            />
                            <FormInputAppend
                                class="mt-2"
                                v-model="gmkzNeuComputed"
                                input-id="gmkz-neu-input"
                                name="gmkz-neu-input"
                                label-text="GMKZ neu*"
                                :error-conditions="[
                                    {
                                        name: 'invalid-gmkz-neu',
                                        condition: !$v.discount.gmkzNeu.validFloat  && $v.discount.gmkzNeu.$dirty,
                                        text: $t.__('validation.wrong_data')
                                    }
                                ]"
                                prepend="%"
                                :disabled="!discount.active"
                            />

                            <b-form-checkbox :disabled="!discount.active" class="gesamtpreis-switch mt-3" v-model="discount.discountTotals" switch>
                                Gesamtpreis rabattieren
                            </b-form-checkbox>
                            <span class="text-muted text-1r mt-1">
                                Wenn aktiviert, werden anstatt der Stuckpreise die Gesamtpreise rabattiert und
                                auf die Stuckpreise zuruckgerechnet. Dies ist hilfreich, wenn der Vertrag sehr geringe
                                Stuckpreise und gleichzeitig sehr hohe Mengen fakturiert.
                            </span>

                            <FormTextArea
                                class="mt-3"
                                v-model="comment"
                                input-id="comment-text"
                                label-text="Bemerkungen*"
                                name="comment"
                                :error-conditions="[
                                    {
                                        name: 'empty-bemerkungen',
                                        condition: !$v.comment.required  && $v.comment.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Bemerkungen'})
                                    }
                                ]"
                                rows="6"
                                :disabled="!discount.active"
                            />
                        </div>

                        <div class="info col-lg-12 col-sm-24">
                            <h3>Informationen</h3>
                            <ul class="pl-3">
                                <li class="py-2">Die Rabattierung wirkt nur auf die Faktura (LBU)</li>
                                <li class="py-2">Die Rabattierung wirkt immer nur auf zukünftige LBU</li>
                                <li class="py-2">Bereits erstellte LBU bleiben unverändert</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <Historie ref="history" class="col-xl-8 col-lg-24 simple-box mt-2" :simple-id="String(discount.simpleId)"/>
            </div>

            <div class="mt-3">
                <button @click="processDiscount" v-if="discount && discount.active" class="btn btn-primary mr-2">Speichern</button>
                <button @click="$emit('close-form')" class="btn btn-secondary">Abbrechen</button>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BOverlay, BFormCheckbox} from 'bootstrap-vue';
import SearchProjectDiscount from "./SearchProjectDiscount";
import Historie from "res/js/widgets/CCF/GrundeinstellungWidget/Historie";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {required} from "vuelidate/lib/validators";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    name: "Form",
    components: {
        SearchProjectDiscount, Historie, BOverlay, FormInputAppend, BFormCheckbox,
        FormTextArea
    },
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            useDiscount: false,
            discount: {},
            comment: '',
            pending: false
        }
    },
    created() {
        this.setDiscountData(this.data);
    },
    computed: {
        preisnachlassComputed: {
            get() { return this.formatValue(this.discount?.preisnachlass ?? '') },
            set(newValue) { this.discount.preisnachlass = this.formatValue(newValue) }
        },
        gmkzAltComputed: {
            get() { return this.formatValue(this.discount.gmkzAlt ?? '') },
            set(newValue) { this.discount.gmkzAlt = this.formatValue(newValue) }
        },
        gmkzNeuComputed: {
            get() { return this.formatValue(this.discount.gmkzNeu ?? '') },
            set(newValue) { this.discount.gmkzNeu = this.formatValue(newValue) }
        }
    },
    methods: {
        formatValue(value) {
            if (value === '' || value === null || value === undefined) {
                return value;
            }
            value = value.replace(/[^\d.,]/g, '');
            if (value.indexOf(',') !== -1) {
                value = value.replace('.', '').replace(',', '.');
            }
            return this.$f.numberToString(value, false, false, '0,0', {
                maximumFractionDigits: 4,
                minimumFractionDigits: 1
            });
        },
        isFloatValid(value) {
            return value ? value.match(/^[\d.]+,\d{1,4}$/) !== -1 : false;
        },
        setDiscountData(data) {
            if (!isEmpty(data)) {
                this.discount = data;
                this.discount.preisnachlass = this.formatValue(this.discount.preisnachlass);
                this.discount.gmkzAlt = this.formatValue(this.discount.gmkzAlt);
                this.discount.gmkzNeu = this.formatValue(this.discount.gmkzNeu);
                this.useDiscount = data.preisnachlass !== null || data.gmkzAlt !== null || data.gmkzNeu !== null
            }
            this.pending = false;
        },
        async processDiscount() {
            this.pending = true;
            this.$v.$touch();
            if (!this.$v.$anyError) {
                try {
                    const res = await this.$axios.post(`/admin/ccf/discount/${this.discount.simpleId}`, {
                        useDiscount: this.useDiscount,
                        preisnachlass: this.discount.preisnachlass,
                        gmkzAlt: this.discount.gmkzAlt,
                        gmkzNeu: this.discount.gmkzNeu,
                        discountTotals: this.discount.discountTotals,
                        projectName: this.discount.thema,
                        comment: this.comment
                    });
                    window.flash.showMessagesFromAjax(res.data);
                    await this.$refs.history.refresh();
                } catch (err) {
                    console.error("Couldn't process a discount! Err", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.pending = false;
        }
    },
    validations: {
        comment: {required},
        discount: {
            simpleId: {
                required(value) { return this.discount?.simpleId !== undefined && this.discount?.simpleId !== null }
            },
            preisnachlass: {validFloat(value) {return this.isFloatValid(value)}},
            gmkzAlt: {validFloat(value) { return this.isFloatValid(value)}},
            gmkzNeu: {validFloat(value) {return this.isFloatValid(value)}},
        },
    }
}
</script>

<style scoped>
h3 {
    font-size: 22px;
}

::v-deep .history-items-wrapper {
    max-height: 480px;
    overflow-y: auto;
}
</style>
