<template>
    <div class="row simple-box">
        <div class="col-lg-8 d-flex flex-column pl-0">
            <span>Bitte wähle mindestens eine SIN aus.</span>
            <div class="d-flex align-items-start mt-2">
                <FormInput
                    v-model="sin"
                    @input="dirty = true"
                    class="mr-2 pt-0"
                    label-text="SIN"
                    name="simple-id"
                    input-id="simple-id-input"
                    :error-conditions="[
                        {
                            name: 'invalid-sin',
                            condition: !isSinValid && dirty,
                            text: $t.__('validation.wrong_data')
                        }
                    ]"
                    ref="sinInput"
                />

                <button @click="searchProjectDiscount" class="search-discount-btn btn btn-secondary">Öffnen</button>
            </div>
        </div>

        <div v-if="data.simpleId" class="project-data col-lg-16 pl-3 d-flex justify-content-between align-items-start">
            <table>
                <tr><td class="py-1 px-3">SIN:</td><td class="font-weight-bold">{{discount.simpleId}}</td></tr>
                <tr><td class="py-1 px-3">Vorhaben:</td><td class="font-weight-bold">{{discount.thema}}</td></tr>
                <tr><td class="py-1 px-3">Kunde:</td><td class="font-weight-bold">{{discount.kundenname}}</td></tr>
            </table>

            <CircleChart
                :content="discount.shortName"
                :value="discount.progress"
                :color="discount.color"
                size="small"
                sr-text="Status"
            />
        </div>
    </div>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import CircleChart from "@comp/CircleChart/CircleChart";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "SearchProjectDiscount",
    components: {FormInput, CircleChart},
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    mounted() {
        setTimeout(() => {
            this.$refs.sinInput.focus();
        }, 100);
    },
    data() {
        return {
            sin: this.data.simpleId,
            discount: this.data,
            dirty: false,
        }
    },
    computed: {
        isSinValid() {
            return String(this.sin).match(/^\d{7}$/);
        },
    },
    methods: {
        async searchProjectDiscount() {
            this.$emit('start-search');
            let projectDiscount = {};
            if (this.isSinValid) {
                try {
                    const res = await this.$axios.get(`/admin/ccf/discount/${this.sin}`);
                    if (!isEmpty(res.data)) {
                        projectDiscount = res.data[0];
                        this.discount = {...projectDiscount};
                    } else {
                        window.flash.error(`SIN/${this.sin} nicht gefunden`);
                    }
                } catch (err) {
                    console.error("Couldn't find project discount! Err", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            } else {
                window.flash.error(this.$t.__('validation.wrong_data'));
                navigateToFirstInvalid();
            }
            this.$emit('found-discount', projectDiscount);
        }
    }
}
</script>

<style lang="scss" scoped>
.project-data {
    border-left: 2px solid lightgrey;
}

.search-discount-btn {
    height: 46px;
}
</style>
