import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Discounts from "./Discounts";
import store from "res/js/widgets/CCF/CBIWidget/store";
import Formatter from "res/js/utils/formatter";
import {ModalPlugin} from 'bootstrap-vue';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import vueDebounce from 'vue-debounce';

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;
Vue.prototype.$t = t;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);
Vue.use(vueDebounce);

export default new Vue({
    el: '#discounts', //resources/views/App/CCF/Discounts/index.blade.php
    components: {
        Discounts
    },
    store
});
