<template>
    <div>
        <BoxSpinner :busy="loading"/>
        <p class="text-size font-weight-bold mb-3">Historie</p>
        <div class="history-items-wrapper">
            <div v-for="item in items">
                <div class="d-flex flex-column">
                    <div class="text-muted mb-1">{{item.timestamp + ' - ' + defVal(item.user, '')}}</div>
                    <div v-html="item.logText.replace(/(?:\r\n|\r|\n)/g, '<br />')"></div>
                </div>
                <hr>
            </div>
            <div v-if="showMessage" class="more-data">
                Bitte warten
            </div>
            <Observer
                @intersect="intersected"
                :is-loading="isLoading"
            />
        </div>
    </div>
</template>

<script>
import Observer from "@comp/Observer/Observer";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import {BSpinner} from 'bootstrap-vue';
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";

export default {
    name: "Historie",
    components: {Observer, BSpinner, BoxSpinner},
    mixins: [ScalarsProcessing],
    props: {
        simpleId: {
            type: String,
            required: true
        },
        perPage: {
            type: Number,
            required: false,
            default: 5
        }
    },
    data() {
        return {
            items: [],
            page: 1,
            total: null,
            loading: false,
            showMessage: false,
            isLoading: false
        }
    },
    methods: {
        async intersected() {
            if (this.total && this.items.length === this.total) return;

            const isFirstPage = this.page === 1;

            if (isFirstPage) {
                this.loading = true;
            } else {
                this.showMessage = true;
            }

            this.isLoading = true;

            const res = await this.$axios.get(`/admin/ccf/settings/${this.simpleId}/historie?page=${this.page}&perPage=${this.perPage}`)
            this.page++;

            this.total = res.data.total;
            const items = await res.data.data;
            this.items = [...this.items, ...items];

            this.loading = false;
            this.showMessage = false;
            this.isLoading = false;
        },
        async refresh() {
            this.items = [];
            this.page = 1;
            this.total = null;
            await this.intersected();
        }
    }
}
</script>

<style scoped>
.text-size {
    font-size: 22px;
}
.more-data {
    font-size: 20px;
    font-weight: bold;
    padding: 10px;
}
</style>
