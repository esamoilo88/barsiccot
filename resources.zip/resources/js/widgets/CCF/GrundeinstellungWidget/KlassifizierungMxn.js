import {
    filterOptions,
    labelStub
} from "./klassifizierung.helper";
import {deepCopy} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    methods: {
        /**
         * Check whether or not a specific category is writable
         * @param cat
         * @returns {boolean}
         */
        isCategoryWritable(cat) {
            if (!this.projectData.canUserManageProject) {
                return false;
            }
            return cat.readonlyStatus.indexOf(this.projectStatus) === -1;

        },

        /**
         * Set labels values which are already assigned to a project to display it
         * when form is opened for the first time. Also set stubs for other labels
         */
        setChosenLabels() {
            if (Object.keys(this.labelsCategories).length !== 0) {
                for (let cat in this.labelsCategories) {
                    let categoryChosenLabels = this.labelsCategories[cat].chosenLabels;
                    if (Array.isArray(categoryChosenLabels) && categoryChosenLabels.length > 0) {
                        this.chosenLabels[cat] = []
                        this.labelsCategories[cat].chosenLabels.map(l => {
                            this.chosenLabels[cat].push({...deepCopy(labelStub), labelId: l.labelId, percentage: l.prozent});
                        });
                    } else {
                        this.chosenLabels[cat] = [{...deepCopy(labelStub)}];
                    }
                }
            }
        },

        /**
         * Used for labels categories which can have more than one value.
         * Shows "cat.chosenLabels.length" number of select inputs or min number of
         * select inputs specified for category
         * @param cat
         */
        howManySelectsToDisplay(cat) {
            return this.chosenLabels[cat.labelKategorieId].length > 0 ?
                this.chosenLabels[cat.labelKategorieId].length :
                cat.minVorkommen;
        },

        /**
         * Add another select input for a category that allow to have
         * more than one select input
         * @param cat
         */
        addAnotherSelect(cat) {
            let labelsLength = this.chosenLabels[cat.labelKategorieId].length;
            if (labelsLength < (cat.maxVorkommen - cat.minVorkommen + 1) && this.isCategoryWritable(cat)) {
                this.chosenLabels[cat.labelKategorieId].push({...deepCopy(labelStub)});
                this.$forceUpdate();
                return true;
            }
            return false;
        },

        /**
         * Get options for select inputs
         **/
        getOptions(categoryId) {
            let filteredLabels = filterOptions(this.labelsCategories[categoryId], this.chosenLabels, this.dependencies);
            if (!filteredLabels) return [];

            let isMatchingSelected = filteredLabels.filter(l => l.labelId == this.chosenLabels[categoryId][0].labelId);

            if (isMatchingSelected.length === 0) {
                this.chosenLabels[categoryId][0].labelId = null;
            }
            try {
                let options = filteredLabels.map(label => {
                    return {id: label.labelId, text: label.bezeichnung};
                });
                options.unshift({id: 'empty', text: '-'});
                return options;
            } catch (e) {
                return [];
            }
        },

        /**
         * Check whether or not categories have the list of all their labels
         */
        isLabelsOptionsExist() {
            if (Object.keys(this.labelsCategories).length !== 0) {
                for (let cat in this.labelsCategories) {
                    if (this.labelsCategories[cat].labels !== undefined) return true;
                }
            }
            return false;
        },

        async setLabels() {
            if (!this.isLabelsOptionsExist()) {
                let labels = this.data.labels;
                labels.map(label => {
                    try {
                        if (this.labelsCategories[label.labelKategorie].labels === undefined) {
                            this.$set(this.labelsCategories[label.labelKategorie], 'labels', []);
                        }
                        this.labelsCategories[label.labelKategorie].labels.push({...label});
                    } catch (e) {
                    } // means we don't have labels for specific category because its hidden, so we just skip it
                });
            }
        },

        /**
         * Generate errors messages and conditions for select inputs.
         * Will be used everytime when validation is executed
         * @param label
         * @returns array of {condition: *, name: *, text: *}
         */
        getErrorConditions(label) {
            return label.validations.basic.map(err => {
                return {
                    name: err.message.replaceAll(' ', '-'),
                    condition: err.state,
                    text: err.message
                }
            });
        },
    }
}
