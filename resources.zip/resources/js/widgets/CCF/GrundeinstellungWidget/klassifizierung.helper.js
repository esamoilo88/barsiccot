import {isEmpty} from "res/js/utils/Helpers/ValueProcessing/ScalarProcessing";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

export const labelStub = {
    labelId: null,
    percentage: null,
    validations: {
        basic: [], // array of objects -  {state: true/false, message: ''}
        percentage: [] // array of objects -  {state: true/false, message: ''}
    }
};

/**
 * Filter options of select inputs depending on values which
 * were selected in respective affecting categories. All dependencies
 * are defined in Sales_Label_Kombinationen
 * @param category
 * @param chosenLabels
 * @param dependencies
 * @returns array
 */
export const filterOptions = (category, chosenLabels, dependencies) => {
    let labels = category.labels;
    let categoriesAffecting = dependencies.categories[category.labelKategorieId] ?? [];
    if (categoriesAffecting.length !== 0) {
        for (let cat of categoriesAffecting) {
            if (chosenLabels[cat][0].labelId !== null) {
                let labelAffecting = chosenLabels[cat][0].labelId;
                let labelsToFilterThrough = dependencies.labels[labelAffecting] ?? [];
                if (labelsToFilterThrough.length !== 0 && labels) {
                    labels = labels.filter(l => labelsToFilterThrough.includes(l.labelId));
                }
            }
        }
    }

    return labels;
}

let projectStatus;

/**
 * Validate klassifizierung form
 * @param chosenLabels
 * @param labelsCategories
 * @param projStatus
 * @returns {boolean}
 */
export const validate = (chosenLabels, labelsCategories, projStatus) => {
    projectStatus = projStatus;
    resetErrors(chosenLabels); // reset error messages from previous validation
    let requiredErrors   = checkRequired(chosenLabels, labelsCategories);
    return requiredErrors === 0;
};

/**
 * Check if user have chosen same labels
 * @param chosenLabels
 * @param labelsCategories
 * @returns {number}
 */
const checkSame = (chosenLabels, labelsCategories) => {
    let errors = 0;
    for (let cat in chosenLabels) {
        if (chosenLabels[cat].length > 1 && !isReadonly(labelsCategories[cat])) { // check only if cat.maxVorkommen>1
            let labels = chosenLabels[cat];
            for (let label of labels) {
                let same = 0;
                let lastSameIndex = 0;
                labels.map((l, i) => {
                    if (label.labelId === l.labelId) {
                        if (l.labelId === null) {
                            return;
                        }
                        same++;
                        lastSameIndex = i;
                    }
                });
                if (same > 1) {
                    pushError(labels[lastSameIndex], 'basic', t.__('validation.klassifizierung.cannot_select_same'));
                    errors++;
                }
            }
        }
    }

    return errors;
}

/**
 * Check if required select inputs have values
 * @param chosenLabels
 * @param labelsCategories
 * @returns {number} - number of errors
 */
const checkRequired = (chosenLabels, labelsCategories) => {
    let errors = 0;
    for (let cat in chosenLabels) {
        let labels = chosenLabels[cat];
        if (labelsCategories[cat].maxVorkommen > 1) {
            let isAnyFilled = labels.filter(l => l.labelId !== undefined && l.labelId !== null).length > 0;
            if (!isAnyFilled) {
                pushError(labels[0], 'basic', t.__('validation.klassifizierung.required'));
                errors++;
            }
        } else {
            if (labels[0].labelId === undefined || labels[0].labelId === null) {
                pushError(labels[0], 'basic', t.__('validation.klassifizierung.required'));
                errors++;
            }
        }
    }
    return errors;
};

/**
 * Check if percentage values are matching necessary conditions
 * @param chosenLabels
 * @param labelsCategories
 * @returns {number} - number of errors
 */
const checkPercentage = (chosenLabels, labelsCategories) => {
    let errors = 0;
    for (let cat in chosenLabels) {
        if (labelsCategories[cat].prozentualeEingabe && !isReadonly(labelsCategories[cat])) {
            let labels = chosenLabels[cat];
            // check sum of all percentage inputs
            let sum = 0;
            for (const [i, label] of labels.entries()) {
                //if label was not selected
                if (isEmpty(label.labelId) && isEmpty(label.percentage)) {
                    continue;
                } else if (isEmpty(label.labelId) && !isEmpty(label.percentage)) {
                    pushError(label, 'basic', t.__('validation.klassifizierung.required'));
                    errors++;
                } else if (isEmpty(label.percentage)) { // if label was selected but percentage wasn't
                    pushError(label, 'percentage', t.__('validation.klassifizierung.percentage_empty'));
                    errors++;
                }
                // if percentage has the wrong format
                if (!String(label.percentage).match(/^\d{1,3}$/) || Number(label.percentage) < 1 || Number(label.percentage) > 100) {
                    pushError(label, 'percentage', t.__('validation.klassifizierung.percentage_wrong_format'));
                    errors++;
                }

                sum += Number(label.percentage);
            }

            if (sum !== 100) {
                let lastFilledPercentage = 0;
                labels.map((l, index) => { if (!isEmpty(l.percentage)) lastFilledPercentage = index; });
                pushError(labels[lastFilledPercentage], 'percentage', t.__('validation.klassifizierung.percentage_must_be_100'));
                errors++;
            }
        }
    }

    return errors;
};

/**
 * Push an error message to a respective array
 * @param label
 * @param type - either 'basic' or 'percentage'
 * @param message
 */
const pushError = (label, type, message) => {
    let isAlreadyExist = label.validations[type].filter(err => err.message.indexOf(message) !== -1).length > 0;
    if (!isAlreadyExist) {
        label.validations[type].push({
            state: true,
            message: message
        })
    }
};

/**
 * Remove all error messages
 * @param chosenLabels
 */
const resetErrors = (chosenLabels) => {
    for (let cat in chosenLabels) {
        chosenLabels[cat].map(l => {
            l.validations.basic = [];
            l.validations.percentage = [];
        });
    }
};

/**
 * @param category
 * @returns {boolean}
 */
const isReadonly = (category) => {
    return category.readonlyStatus.indexOf(projectStatus) !== -1;
}
