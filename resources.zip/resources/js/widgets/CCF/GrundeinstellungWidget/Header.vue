<template>
    <div class="header-data right-box pl-4">
        <table>
            <tr>
                <td>SIN:</td>
                <td class="header-data__simple-id">{{ projectData.simpleId }}</td>
            </tr>
            <tr>
                <td>Vorhaben:</td>
                <td class="header-data__vorhaben">{{ projectData.thema }}</td>
            </tr>
            <tr>
                <td>Kunde:</td>
                <td class="header-data__kunde">{{ projectData.kundenname }}</td>
            </tr>
        </table>

        <CircleChart
            :content="projectData.status.shortName"
            :value="projectData.status.progress"
            :color="projectData.status.color"
            size="small"
            sr-text="Status"
        />
    </div>
</template>

<script>
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownDivider, BDropdownItem} from "bootstrap-vue";
import CircleChart from "@comp/CircleChart/CircleChart";
import {mapGetters, mapMutations, mapState} from 'vuex';

export default {
    name: "Header",
    props: {
        projectData: {
            type: Object,
            required: true,
        }
    },
    components: {
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider,
        CircleChart
    }
}
</script>

<style lang="scss" scoped>
.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        padding: 5px 20px 5px 0;
    }
}

.header-data__simple-id,
.header-data__vorhaben,
.header-data__kunde {
    font-weight: bold;
}
.right-box {
    border-left: 2px solid #dee2e6;
}
</style>
