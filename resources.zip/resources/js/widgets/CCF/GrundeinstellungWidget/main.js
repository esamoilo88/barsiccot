import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import grundeinstellung from "./Grundeinstellung";
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;
Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;
Vue.use(Vuelidate);

export default new Vue({
    el: '#grundeinstellung', //resources/views/App/CCF/index.blade.php
    components: {
        grundeinstellung
    }
});
