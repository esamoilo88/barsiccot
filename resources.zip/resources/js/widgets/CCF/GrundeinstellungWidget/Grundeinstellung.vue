<template>
    <div>
        <HeaderDates class="mb-4" :current="datesParsed.current" :u3="datesParsed.u3" :u7="datesParsed.u7"/>
        <div class="simple-box box-shadow pb-4">
            <div class="d-flex align-items-center">
                <h2 class="mr-4"><span class="icon-service-seettings-default mr-2"></span>Grundeinstellung ändern</h2>
                <span class="text-muted text-1r">Ändere Klassifizierung, Rechnungsart und Debitor eines Vertrags</span>
            </div>
            <hr class="mb-3"/>
            <div class="simple-box d-flex align-items-center">
                <div class="mr-4">
                    <span class="mb-2"> Bitte wähle eine SIN aus. </span>
                    <div @keyup.enter="search" class="">
                        <FormInput
                            v-model="sin"
                            input-id="select-sin"
                            label-text="SIN*"
                            name="sin"
                            class="mr-2 float-left"
                            :disabled="pending || savePending"
                            :error-conditions="[
                                {
                                    name: 'empty-sin',
                                    condition: !$v.sin.required && $v.sin.$dirty,
                                    text: $t.__('validation.required', {attribute: 'SIN'})
                                },
                                {
                                    name: 'integer-sin',
                                    condition: !$v.sin.integer && $v.sin.$dirty,
                                    text: $t.__('validation.integer', {attribute: 'SIN'})
                                },
                                {
                                    name: 'max-sin',
                                    condition: !this.$v.sin.maxLength && this.$v.sin.$dirty,
                                    text: 'SIN muss nicht mehr als 7 Zeichen sein.'
                                },
                                {
                                    name: 'min-sin',
                                    condition: !this.$v.sin.minLength && this.$v.sin.$dirty,
                                    text: 'SIN muss mindestens 7 Zeichen lang sein.'
                                }
                            ]"
                        />
                        <b-button
                            variant="primary"
                            @click="search"
                            :disabled="pending || savePending"
                            class="height"
                        >
                            Öffnen
                        </b-button>
                    </div>
                </div>
                <Header
                    v-if="showInfo"
                    :project-data="projectData"
                    class="flex-grow-1"
                />
            </div>
            <div class="mt-3" v-html="htmlContentParsed"></div>
            <div v-if="showInfo" class="row mt-3">
                <div class="simple-box col-lg-16 col-md-16 col-xl-16 col-xxl-16 mr-5 max-height">
                    <div class="row">
                        <div id="form-focus" class="col-lg-10">
                            <p class="text-size font-weight-bold mb-3">Klassifizierung und Rechnungsdaten</p>
                            <BoxSpinner :busy="savePending"/>
                            <div v-for="catId in categoriesSortedIds">
                                <template>
                                    <div class="category-wrapper">
                                        <FormSelect
                                            v-model="chosenLabels[catId][0].labelId"
                                            :options="getOptions(catId)"
                                            :key="'labels-' + catId"
                                            :name="labelsCategories[catId].bezeichnung"
                                            :select-id="'klassifizierung-category-select-' + catId"
                                            :label-text="getSelectInputLabel(labelsCategories[catId])"
                                            :error-conditions="getErrorConditions(chosenLabels[catId][0])"
                                            @select="value => onSelectChange(catId, value)"
                                            searchable
                                            @keyup.enter="save"
                                            :readonly="!isActive"
                                        />
                                    </div>
                                </template>
                            </div>
                            <FormSelect
                                v-model="selectedProfitcenterSetting"
                                :options="profitcenterSettingsOptions"
                                key="profitcenterSettings"
                                name="profitcenterSettings"
                                select-id="profitcenterSettings"
                                label-text="Grundeinstellung*"
                                @input="value => onProfitcenterSettingsSelect(value)"
                                class="category-wrapper"
                                @keyup.enter="save"
                                :readonly="!isActive"
                                :error-conditions="[
                                    {
                                        name: 'empty-profitcenterSetting',
                                        condition: !$v.selectedProfitcenterSetting.required && $v.selectedProfitcenterSetting.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Grundeinstellung'})
                                    }
                                ]"
                            />
                            <FormSelect
                                v-model="selectedDebitor"
                                name="debitor"
                                :options="debitorList"
                                type="select"
                                select-id="debitor-input"
                                label-text="Debitor*"
                                :readonly="!isHardBilling || !isActive"
                                class="category-wrapper"
                                @keyup.enter="save"
                                :error-conditions="[
                                    {
                                        name: 'empty-debitor',
                                        condition: !$v.selectedDebitor.required && $v.selectedDebitor.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Debitor'})
                                    }
                                ]"
                            />
                            <div class="mt-3 ml-1 mb-2">
                                <b-form-checkbox
                                    v-model="cbiSinControl"
                                    switch
                                    class="mb-1"
                                >
                                    SIN steuert Kontierung
                                </b-form-checkbox>
                                <div class="text-muted pt-2">Aktivieren um für die Sammelfaktura die Kontierung aus der SIN zu ermitteln. Dies kann zum Übersteuern des Feldes "Profitcenter steuert Kontierung" genutzt werden.</div>
                            </div>

                            <FormTextArea
                                v-if="isActive"
                                v-model="reason"
                                input-id="reason-textarea"
                                name="reason-textarea"
                                rows="5"
                                label-text="Bemerkungen*"
                                @keyup.enter="save"
                                :error-conditions="[
                                    {
                                        name: 'empty-reason',
                                        condition: !$v.reason.required && $v.reason.$dirty,
                                        text: $t.__('validation.required', {attribute: 'Bemerkungen'})
                                    }
                                ]"
                            />
                        </div>
                        <div class="col-lg-14 pr-0">
                            <p class="text-size font-weight-bold mb-3">Grundeinstellung</p>
                            <BoxSpinner :busy="pending"/>
                            <b-table
                                    class="table-sm"
                                    stacked
                                    borderless
                                    :fields="fields"
                                    :items="item"
                                    :busy="pending"
                                >
                                </b-table>
                        </div>
                    </div>
                </div>
                <div class="simple-box col-lg-7 col-xl-7 col-xxl-7 max-height overflow">
                    <Historie
                        ref="historie"
                        :simple-id="sin"
                        :per-page="5"
                    />
                </div>
            </div>
            <b-button
                v-if="showInfo && isActive"
                variant="primary"
                @click="save"
                :disabled="savePending"
                class="button-save"
            >
                Speichern
            </b-button>
        </div>
    </div>
</template>

<script>
import {VBTooltip, BButton, BFormCheckbox} from "bootstrap-vue";
import MenuItem from "res/js/widgets/CCF/CCFWidget/MenuItem";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import FormInput from "@comp/FormInput/FormInput";
import KlassifizierungMxn from  './KlassifizierungMxn';
import FormSelect from "@comp/FormSelect/FormSelect";
import {BTable} from "bootstrap-vue";
import Header from "res/js/widgets/CCF/GrundeinstellungWidget/Header";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import {createOptions} from "@helpers/Form/InputsHelper";
import Historie from "./Historie";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";
import {validate} from "./klassifizierung.helper";
import {integer, maxLength, minLength, required, requiredIf} from "vuelidate/lib/validators";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "grundeinstellung",
    components: {Historie, Header, FormInput, HeaderDates, MenuItem, BButton, FormSelect, BTable, FormTextArea, BoxSpinner, BFormCheckbox},
    mixins: [KlassifizierungMxn, ScalarsProcessing],
    props: {
        data: {
            type: Object,
            required: true,
        }
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    created() {
        this.setDependencies();
        this.setAllLabelCategories();
        this.setLabels();
        this.setCbiSinControlList();
    },
    computed: {
        htmlContentParsed() {
            return this.data.html// !== '' ?  JSON.parse(this.htmlContent) : '';
        },
        datesParsed() {
            return this.data.dates// !== '[]' ?  JSON.parse(this.dates) : {current: {date: '-', u: '-', at: '-'}, u3: '-', u7: '-'};
        },
        fields() {
            return [
                {
                    key: 'rechnungsart',
                    label: 'Rechnungsart:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'debitor',
                    label: 'Debitor:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'materialnummer',
                    label: 'Materialnummer:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'fakturaziel',
                    label: 'Fakturaziel:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'sachkonto',
                    label: 'ICP Sachkonto:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'kontierung',
                    label: 'ICP Kontierung:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'frequency',
                    label: 'Rechnungsturnus:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'rechnungsubertragung',
                    label: 'Rechnungsübertragung:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'ansprechpartner',
                    label: 'Ansprechpartner:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'rechnungskop',
                    label: 'Referenz Rechnungskopf:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'allowEmptyAp',
                    label: 'Freie Angebotspositionen:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'vertragsverhaltnis',
                    label: 'Vertragsbeziehung:',
                    class: 'font-weight-bold'
                },
                {
                    key: 'cbiUsePcs',
                    label: 'Profitcenter steuert Kontierung:',
                    class: 'font-weight-bold'
                }
            ]
        },
        item() {
            return [{
                rechnungsart: this.settings.rechnungsart,
                debitor: this.defVal(this.settings.debitor, 'Unbekannt'),
                frequency: this.settings.frequency,
                rechnungsubertragung: this.settings.rechnungsubertragung,
                allowEmptyAp: this.settings.allowEmptyAp,
                vertragsverhaltnis: this.settings.vertragsverhaltnis,
                ansprechpartner: this.defVal(this.settings.ansprechpartner, 'Unbekannt'),
                materialnummer: this.defVal(this.settings.materialnummer, 'Unbekannt'),
                fakturaziel: this.defVal(this.settings.fakturaziel, 'Unbekannt'),
                sachkonto: this.defVal(this.settings.sachkonto, 'Unbekannt'),
                kontierung: this.defVal(this.settings.kontierung, 'Unbekannt'),
                rechnungskop: this.defVal(this.settings.kontierung, 'Unbekannt'),
                cbiUsePcs: this.defVal(this.settings.cbiUsePcs, 'Unbekannt'),
            }]
        }
    },
    data() {
        return {
            sin: null,
            pending: false,
            labelsCategories: {},
            categoriesSortedIds: [],
            chosenLabels: {},
            dependencies: {},
            projectData: {},
            showInfo: false,
            allLabelsCategories: [],
            projectLabels: null,
            settings: {},
            profitcenterSettings: [],
            profitcenterSettingsOptions: [],
            selectedProfitcenterSetting: null,
            debitorList: [],
            selectedDebitor: null,
            savedDebitor: null,
            reason: null,
            baseDebitorList: [],
            baseProfitcenter: null,
            savePending: false,
            isHardBilling: false,
            projectStatus: null,
            isBillingWritable: false,
            isActive: false,
            profitcenterKategorieId: null,
            cbiSinControl: null,
            cbiSinControlList: []
        }
    },
    methods: {
        async save() {
            let isValid = validate(this.chosenLabels, this.labelsCategories, this.projectStatus);
            this.$forceUpdate();
            this.$v.$touch();

            if (!this.$v.$anyError && isValid) {
                const data = {
                    "chosenLabels": this.chosenLabels,
                    "profitcenterSettingId": this.selectedProfitcenterSetting,
                    "debitorId": this.selectedDebitor,
                    "comment": this.reason,
                    "cbiSinControl": this.cbiSinControl
                };

                this.savePending = true;

                try {
                    const response = await this.$axios.post(`/admin/ccf/settings/${this.sin}`, data);

                    window.flash.showMessagesFromAjax(response.data);
                } catch (e) {
                    window.flash.showMessagesFromAjax(e.response.data);
                }

                this.savePending = false;
                this.$refs.historie.refresh();
            } else {
                navigateToFirstInvalid();
            }

        },
        async search() {
            this.clearForm();
            this.$v.$reset();

            this.pending = true;

            this.$v.sin.$touch()

            if (!this.$v.sin.$anyError) {

                try {
                    const response = await this.$axios.get(`/admin/ccf/settings/${this.sin}/info`);
                    this.projectLabels = response.data.projectLabels;

                    this.setSettings(response.data.settings);
                    this.setProjectData(response.data.projectData);
                    this.setDebitorList(response.data.debitorList);
                    this.setProfitcenterSettings(response.data.profitcenterSettings);
                    this.baseDebitorList = this.debitorList;
                    this.init();
                    this.baseProfitcenter = this.chosenLabels[this.profitcenterKategorieId][0].labelId;
                } catch (e) {
                    console.log(e);
                    window.flash.showMessagesFromAjax(e.response.data);
                }
            } else {
                navigateToFirstInvalid();
            }

            this.pending = false;

            // document.querySelector('[id*="klassifizierung-category-select-"]').focus();
        },
        async onProfitcenterSettingsSelect(value) {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/admin/ccf/settings/profitcenter-settings-info/${this.chosenLabels[this.profitcenterKategorieId][0].labelId}/${value}`);
                this.setSettings(response.data);
                this.setDebitorList(response.data.debitorList);
                this.selectedDebitor = !response.data.isHardBilling ? response.data.debitorId : null;
            } catch (e) {
                console.log(e);
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async onSelectChange(catID, value) {
            if (!value || !this.isBillingWritable) return;
            if (catID == this.profitcenterKategorieId) {
                this.selectedProfitcenterSetting = null;
                this.profitcenterSettingsOptions = [];
                this.profitcenterSettings = [];

                this.savePending = true;

                try {
                    const response = await this.$axios.get(`/admin/ccf/settings/profitcenter-settings/${value}`);
                    this.setProfitcenterSettings(response.data);

                    this.selectedDebitor = null;
                    this.selectedProfitcenterSetting = null;
                    this.debitorList = [];
                } catch (e) {
                    console.log(e);
                    window.flash.showMessagesFromAjax(e.response.data);
                }

                this.savePending = false;
        }
            this.$forceUpdate();
        },
        init() {
            let projectLabels = this.projectLabels;
            projectLabels = projectLabels.filter(l => {
                return this.labelsCategories[l.label.labelKategorie.labelKategorieId];
            });
            projectLabels.map(l => {
                this.labelsCategories[l.label.labelKategorie.labelKategorieId].chosenLabels.push({
                    ...l.label,
                    prozent: l.prozent
                })
            });
            this.setChosenLabels();

            this.showInfo = true;
        },

        /**
         * @param category
         * @returns {string|string}
         */
        getSelectInputLabel(category) {
            return this.isCategoryWritable(category) ? category.bezeichnung + '*' : category.bezeichnung;
        },
        setDependencies() {
            this.dependencies = this.data.dependencies;
        },
        setProfitcenterSettings(profitcenterSettings) {
            this.profitcenterSettingsOptions = [];
            this.profitcenterSettings = [];
            this.profitcenterSettings = profitcenterSettings;
            this.profitcenterSettingsOptions.push(...createOptions(
                profitcenterSettings,
                (ps) => ps.profitcenterSettingsId,
                (ps) => ps.bezeichnung,
            ));
        },
        setDebitorList(debitorList) {
            this.debitorList = [];
            this.debitorList.push(...createOptions(
                debitorList,
                (db) => db.debitorId,
                (db) => db.nummer + ' - ' + db.name + ' (' + db.gesellschaftsnummer + ')'
            ));
        },
        setAllLabelCategories() {
            this.allLabelsCategories = this.data.categories;
            this.allLabelsCategories.map(cat => {
                this.categoriesSortedIds.push(cat.labelKategorieId);
                this.$set(this.labelsCategories, cat.labelKategorieId, {...cat});
                this.$set(this.labelsCategories[cat.labelKategorieId], 'chosenLabels', []);
            });
            this.profitcenterKategorieId = this.data.profitcenterKategorieId;
        },
        setSettings(settings) {
            this.settings = settings;
            this.settings.frequency = this.getFrequency();
            this.isHardBilling = settings.isHardBilling;
        },
        getFrequency() {
            let ultimoMatches = String(this.settings.frequency).match(/_U-(\d+)$/);
            let atMatches = String(this.settings.frequency).match(/_(\d+)AT$/);
            if (this.settings.frequency === undefined) {
                return '-';
            } else if (this.settings.frequency === 'hourly') {
                return 'Stündlich';
            } else if (ultimoMatches !== null) {
                return `Monatlich, Ultimo-${ultimoMatches[1]}`;
            } else if (atMatches !== null) {
                return `Monatlich, ${atMatches[1]}. AT`;
            }
        },
        setProjectData(data) {
            this.projectData.thema = data.thema;
            this.projectData.kundenname = data.kundenname;
            this.projectData.simpleId = this.sin;
            this.projectData.status = data.status;
            this.selectedDebitor = data.debitorId;
            this.savedDebitor = data.debitorId;
            this.projectStatus = data.status.shortName;
            this.setProfitcenterSettings(data.savedProfitcenter);
            this.selectedProfitcenterSetting = data.savedProfitcenter.profitcenterSettingsId;
            this.isBillingWritable = data.isBillingWritable;
            this.isActive = data.isActive;
            this.cbiSinControl = data.isCbiSinControl;
        },
        clearForm() {
            this.showInfo = false;
            this.chosenLabels = {};
            this.projectData = {};
            this.projectLabels = null;
            this.settings = {};
            this.profitcenterSettings = [];
            this.profitcenterSettingsOptions = [];
            this.selectedProfitcenterSetting = null;
            this.debitorList = [];
            this.selectedDebitor = null;
            this.savedDebitor = null;
            this.reason = null;
            this.baseDebitorList = [];
            this.baseProfitcenter = null;
            this.isHardBilling = false;
            this.projectStatus = null;
            this.isBillingWritable = false;
            this.isActive = false;
            this.dependencies = [];
            this.categoriesSortedIds = [];
            this.allLabelsCategories = [];
            this.labelsCategories = {};
            this.setDependencies();
            this.setAllLabelCategories();
            this.setLabels();
        },
        setCbiSinControlList() {
            const cbiSinControlOptions = [
                {
                    id: 1,
                    title: 'Ja'
                },
                {
                    id: 0,
                    title: 'Nein'
                }
            ]
            this.cbiSinControlList.push(...createOptions(
                cbiSinControlOptions,
                (op) => op.id,
                (op) => op.title
            ));
        }
    },
    validations: {
        sin: {required, integer, maxLength: maxLength(7), minLength: minLength(7)},
        reason: {required},
        selectedDebitor: {
            required: requiredIf(function () {
                return this.isBillingWritable && this.isHardBilling
            }),
        },
        selectedProfitcenterSetting: {
            required: requiredIf(function () {
                return this.isBillingWritable
            }),
        },
    }
}
</script>

<style lang="scss" scoped>
.ccf-menu-wrapper {
    border: 1px solid lightgrey;
    border-radius: 4px;
    padding: 20px;

    .ccf-menu {
        padding: 0;
    }

    ::v-deep .ccf-menu-item {
        margin-bottom: 20px;
        border-radius: 4px;

        .menu-item-icon {
            font-size: 1.8rem;
        }

        a {
            color: #000;
            text-decoration: none;
        }

        .menu-item-subtext {
            max-width: 320px;
        }
    }

    ::v-deep .ccf-menu-item:hover {
        background-color: #f1f1f1;
        cursor: pointer;
    }
}
.text-size {
    font-size: 22px;
}

.category-wrapper {
    margin: 6px 0;
}
::v-deep .table.b-table.b-table-stacked > tbody > tr > [data-label]::before {
    text-align: left;
    font-weight: normal;
}
.max-height {
    min-height: 500px;
    max-height: 700px;
}
.button-save {
    margin-top: 15px;
}
.overflow {
    overflow-y: auto;
    overflow-wrap: break-word;
}
.height {
    height: 50px;
}
</style>
