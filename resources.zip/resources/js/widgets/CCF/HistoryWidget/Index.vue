<template>
    <div>
        <HeaderDates class="mb-4" :current="data.dates.current" :u3="data.dates.u3" :u7="data.dates.u7" />

        <div class="simple-box box-shadow p-4">
            <div class="d-flex align-items-center">
                <h2 class="mr-4">
                    <span class="icon-content-history-default mr-2"></span>
                    Historie einsehen
                </h2>
                <span class="text-muted text-1r">Überprüfe die Finanzhistorie des CCF oder eines Vorhabens</span>
            </div>

            <hr class="mb-5"/>

            <table-simple
                ref="table"
                table-id="admin-users-list"
                :fields="tableConf.fields"
                :filters="tableConf.filters"
                :total-rows-prop="tableConf.totalRows"
                :per-page-prop="tableConf.perPage"
                :sort-by-prop="tableConf.sortBy"
                :sort-desc-prop="tableConf.sortDesc"
                :items-provider="itemsProvider"
            >
                <template #cell(timestamp)="data">
                    {{ formatDate(data.item.timestamp, 'DD.MM.YYYY HH:mm') }}
                </template>

                <template #cell(logText)="data">
                    <div v-html="data.item.logText"></div>
                </template>
            </table-simple>
        </div>
    </div>
</template>

<script>
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import TableConf from "res/js/widgets/CCF/HistoryWidget/TableConf";
import TableSimple from "@comp/TableSimple/TableSimple";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    components: {HeaderDates, TableSimple},
    mixins: [TableConf, DatesProcessing],
    props: {
        data: {
            required: true,
            type: Object
        }
    },
    data() {
        return {
            pending: false
        }
    },
    methods: {
        async itemsProvider(ctx) {
            this.pending = true;

            try {
                const response = await this.$axios.post('/admin/ccf/history/list', ctx);

                this.tableConf.totalRows = response.data.total > 1000 ? 1000 : response.data.total;
                this.tableConf.perPage = response.data.perPage;

                this.pending = false;

                return response.data.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>
