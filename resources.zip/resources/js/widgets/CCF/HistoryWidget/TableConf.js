export default {
    data() {
        return {
            tableConf: {
                currentPage: 1,
                totalRows: 0,
                perPage: 20,
                fields: [
                    {key: 'groupName', label: 'Gruppe'},
                    {key: 'timestamp', label: 'Datum/Uhrzeit'},
                    {key: 'simpleId', label: 'SIN'},
                    {key: 'logText', label: 'Nachricht'},
                    {key: 'benutzerName', label: 'Benutzer'},
                ],
                filters: [
                    {
                        field: 'group',
                        type: 'select',
                        settings: {
                            preselected: 'all',
                            label: 'Gruppe',
                            options: [
                                {id: 'all', text: 'Alle'},
                                {id: 'ccf', text: 'CCF'},
                                {id: 'finance', text: 'Vorhaben'},
                            ]
                        }
                    },
                    {
                        field: 'search',
                        type: 'text',
                        settings: {label: 'Suchen...'}
                    }
                ],
            }
        }
    }
}
