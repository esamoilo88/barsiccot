import pspelement from "./Index";
import Formatter from "res/js/utils/formatter";
import store from './store';
import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import {ModalPlugin} from 'bootstrap-vue';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
Vue.prototype.$f = new Formatter();

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$axios = $axios;
Vue.prototype.$t = t;
Vue.prototype.$eventBus = eventBus;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);

export default new Vue({
    el: '#psp', //resources/views/App/CCF/psp.blade.php
    components: {
        pspelement
    },
    store
});
