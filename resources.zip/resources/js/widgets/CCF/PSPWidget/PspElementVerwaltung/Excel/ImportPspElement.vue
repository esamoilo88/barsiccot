<template>
    <modal-dialog
        modal-class="psp-element-excel-dialog"
        :is-visible="isVisible"
        @hideModal="closeDialog"
        title-dialog="PSP-Elemente importieren"
        :size="size"
        scrollable
    >
        <div class="simple-box pr-5 mb-4">
            <span class="font-weight-bold mb-1">Importiere neue PSP-Elemente per Excel-Datei.</span>
            <form-file-load
                v-model="file"
                ref="file"
                type="file"
                browse-text="Auswählen"
                @uploadFile="upload"
                placeholder="Datei auswählen / drag&drop"
                accept=".xlsx,.xls"
                class="mt-3 w-75"
            />
            <div class="text-muted">
                Gültiger Dateityp: *.xlsx.
            </div>
        </div>
        <b-overlay :show="dataLoading">
            <SuccessForm
                v-if="showSuccessForm"
                :success-data="successData"
                @close-success="closeSuccess"
                @close-dialog="closeDialog"
            />
            <ErrorForm
                v-else-if="showErrorForm"
                :error-data="errorData"
                @close-error="closeError"
                @close-dialog="closeDialog"
            />
        </b-overlay>

        <template #footer="{methods}">
            <div class="d-flex justify-content-center">
                <button
                    :key="'fertigstellen-btn'"
                    v-if="showSuccessForm"
                    @click="commit"
                    class="btn btn-primary mr-1"
                    :disabled="dataLoading"
                >
                    <b-spinner v-if="dataLoading" small></b-spinner>
                    Fertigstellen
                </button>
                <button @click="closeDialog" class="btn btn-secondary">Schließen</button>

            </div>
        </template>

    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {BSpinner, BOverlay, BTable} from "bootstrap-vue";
import {mapActions} from "vuex";
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import FormFileLoad from '@comp/FileLoad/FormFileLoad'
import SuccessForm from "./SuccessForm";
import ErrorForm from "./ErrorForm";

export default {
    name: "LBUExcelDialog",
    components: {
        SuccessForm,
        ModalDialog, BSpinner, BOverlay, FormFileLoad, BTable, ErrorForm
    },
    mixins: [ObjectsProcessing],
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        }
    },
    data() {
        return {
            size: 'lg',
            pending: false,
            dataLoading: false,
            attachedFile: null,
            file: {},
            showErrorForm: false,
            showSuccessForm: false,
            successData: [],
            errorData: []
        }
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        async commit() {
            this.dataLoading = true;
            try {
                await this.$axios.post(`/admin/ccf/psp/import/commit`,
                    {key: this.successData.key}
                );
                this.dataLoading = false;
                this.$eventBus.$emit('update-table');
                this.$eventBus.$emit('get-totals-element-count');
                window.flash.success(this.$t.__('success.generic_success'));
                this.closeDialog();
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
        },
        clear() {
            this.$refs.file.clearFiles();
            this.file = {};
        },
        async upload(filesInfo) {
            this.dataLoading = true;
            try {
                let res = await this.$axios.post(`/admin/ccf/psp/import`,
                    filesInfo.formData
                );
                if (Object.keys(res.data.errors).length > 0) {
                    this.setErrorData(res.data.errors);
                    this.showErrorForm = true;
                } else {
                    this.setSuccessData(res.data.success);
                    this.size = 'xl';
                    this.showSuccessForm = true;
                }

            } catch (err) {
                console.error(err);
                window.flash.showMessagesFromAjax(err.response.data);
            } finally {
                this.clearFile();
            }
        },
        clearFile() {
            this.file = {};
            this.$refs.file && this.$refs.file.clearFiles();
            this.dataLoading = false;
        },
        setSuccessData(data) {
            let result = [];
            for (let psp in data.data) {
                if (data.data.hasOwnProperty(psp)) {
                    let newData = data.data[psp];
                    result.push(newData);
                }
            }
            data.data = result;
            this.successData = data;
        },
        setErrorData(data) {
            let newErrors = [];
            for (let row in data.errors) {
                if (data.errors.hasOwnProperty(row)) {
                    data.errors[row].forEach(function (error) {
                        newErrors.push({
                            row: row,
                            type: error.type,
                            message: error.message,
                            column: error.column
                        })
                    })
                }
            }
            data.errors = newErrors;
            this.errorData = data;
        },
        closeError() {
            this.size = 'lg';
            this.showErrorForm = false;
            this.errorData = [];
        },
        closeSuccess() {
            this.size = 'lg';
            this.showSuccessForm = false;
            this.successData = [];
        },
        closeDialog() {
            this.size = 'lg';
            this.successData = [];
            this.errorData = [];
            this.showSuccessForm = false;
            this.showErrorForm = false;
            this.clearFile();
            this.$emit('close-dialog');
        }
    }
}
</script>

<style lang="scss">
@import "resources/sass/variables";

.warning {
    color: $info;
}

.edit-kontierung-dialog {
    .modal-dialog {
        max-width: 665px;
    }

    .text-muted {
        font-size: 1rem;
    }
}
</style>
