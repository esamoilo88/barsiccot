<template>
    <div>
        <div class="mb-4 mt-2">
            <div class="d-flex align-items-center mb-2">
                <img
                    class="icon-info mr-2"
                    :src="'/img/icons/error_graphical.svg'"
                    :alt="'fehler'"
                />
                <span>In der Exceldatei wurde <span class="font-weight-bold"> {{ errorData.errorCount }} Fehler </span> gefunden.</span>
            </div>
        </div>
        <b-table
            id="lbu-import"
            responsive
            :fields="fields"
            :items="errorData.errors"
            striped
        >
            <template #cell(message)="row">
                <truncated-text
                    :text="row.item.message"
                    title="Fehler Anzeigen"
                    :width=450
                    :max-length="80"
                />
            </template>
        </b-table>
    </div>
</template>

<script>
import {BSpinner, BOverlay, BTable, BButton} from "bootstrap-vue";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import DetailsLBU from "res/js/widgets/Orders/OrdersViewWidget/tabs/LBU/Excel/DetailsLBU";

export default {
    name: "ErrorForm",
    components: {
        DetailsLBU,
        BSpinner, BOverlay, BTable, TruncatedText, BButton, ButtonIcon
    },
    mixins: [DatesProcessing],
    props: {
        errorData: {
            type: Object,
            required: true,
            default: {}
        }
    },
    data() {
        return {
            fields: [
                {key: 'column', label: 'Spalte'},
                {key: 'row', label: 'Zeile'},
                {key: 'message', label: 'Fehler'},
            ]
        }
    }
}
</script>

<style scoped>
    .icon-info {
        width: 32px;
    }
    .icon {
        width: 26px;
    }
</style>
