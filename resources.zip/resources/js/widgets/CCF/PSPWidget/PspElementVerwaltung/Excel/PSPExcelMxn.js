export default {
    data() {
        return {
            isPSPImportFormActive: false
        }
    },
    methods: {
        onPspImport() {
            this.isPSPImportFormActive = true;
        },
        onPspImportClose() {
            this.isPSPImportFormActive = false;
        }
    }
}
