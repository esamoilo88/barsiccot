<template>
    <div>
        <div>
            <div class="mb-4 mt-2">
                <div class="d-flex align-items-center mb-2">
                    <img
                        class="icon mr-2"
                        :src="'/img/icons/confirm_graphical.svg'"
                        :alt="'erfolgreich'"
                    />
                    <span>Die Exceldatei wurde erfolgreich validiert.</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <img
                        class="icon mr-2"
                        :src="'/img/icons/confirm_graphical.svg'"
                        :alt="'erfolgreich'"
                    />
                    <span v-if="pspCount>1">Es werden <span class="font-weight-bold"> {{pspCount }} PSP-Elemente </span> angelegt.</span>
                    <span v-else>Es wird <span class="font-weight-bold"> {{pspCount }} PSP-Element </span> angelegt.</span>
                </div>
            </div>
            <b-table
                id="psp-element-import"
                responsive
                :fields="fields"
                :items="successData.data"
                striped
            >
                <template #cell(pspElement)="data">
                    {{ data.item.pspElement }}
                </template>
                <template #cell(pspElementSAP)="data">
                    {{ data.item.pspElementSAP }}
                </template>
                <template #cell(uebergeordneter-name)="data">
                    <truncated-text
                        class="text-break"
                        :text="data.item.parentName"
                        title="Übergeordneter Name anzeigen"
                        :max-length="100"
                    />
                </template>
                <template #cell(name)="data">
                    <truncated-text
                        class="text-break"
                        :text="data.item.name"
                        title="Name anzeigen"
                        :max-length="100"
                    />
                </template>
                <template #cell(kontakt)="data">
                    {{ data.item.contact }}
                </template>
                <template #cell(representative)="data">
                    {{ data.item.representative }}
                </template>
                <template #cell(merkmale)="data">
                    <b-badge v-if="parseInt(data.item.hide)" variant="secondary" class="mb-1">Ausgeblendet</b-badge>
                    <b-badge v-if="parseInt(data.item.locked)" variant="danger" class="mb-1">Gesperrt</b-badge>
                    <b-badge v-if="parseInt(data.item.collector)" variant="warning" class="mb-1">Sammler</b-badge>
                </template>
            </b-table>
        </div>
    </div>
</template>

<script>
import {BSpinner, BOverlay, BTable, BButton,BBadge} from "bootstrap-vue";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";

export default {
    name: "SuccessForm",
    components: {
        BSpinner, BOverlay, BTable, TruncatedText, BButton, ButtonIcon, BBadge
    },
    mixins: [DatesProcessing],
    props: {
        successData: {
            type: Object,
            required: true,
            default: {}
        }
    },
    computed: {
        pspCount() {
            return this.successData.data.length;
        }
    },
    data() {
        return {
            onSubmitPending: false,
            fields: [
                {key: 'pspElement',label: 'PSP-Element', thStyle: {width: '15%'}},
                {key: 'pspElementSAP',label: 'PSP-Element (SAP-Schreibweise)', thStyle: {width: '15%'}},
                {key: 'uebergeordneter-name', label: 'Übergeordneter Name', thStyle: {width: '20%'}},
                {key: 'name', label: 'Name', thStyle: {width: '20%'}},
                {key: 'kontakt', label: 'Kontakt', thStyle: {width: '15%'}},
                {key: 'representative', label: 'Vertreter Kontakt', thStyle: {width: '15%'}},
                {key: 'merkmale', label: 'Merkmale'}
            ]
        }
    }
}
</script>

<style scoped>
    .icon {
        width: 32px;
    }
</style>
