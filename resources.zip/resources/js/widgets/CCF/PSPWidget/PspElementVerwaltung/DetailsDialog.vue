<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide"
            title-dialog="Detailansicht"
            modal-class="psp-details-dialog"
            size="xl"
        >
            <b-overlay :show="pending">
                <div class="row mb-3">
                    <div class="col">
                        <div class="mb-2">
                            <div class="font-weight-bold">PSP-Element</div>
                            {{ psp.pspElement }}
                        </div>

                        <div class="mb-2">
                            <div class="font-weight-bold">Übergeordneter Name</div>

                            {{ psp.parentName }}
                        </div>

                        <div>
                            <div class="font-weight-bold">Name</div>
                            {{ psp.name }}
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-2">
                            <div class="font-weight-bold">Kontakt</div>
                            {{ psp.contact ? psp.contact.lastNameFirstName : 'Nicht vorhanden' }}
                        </div>

                        <div>
                            <div class="font-weight-bold">Vertreter Kontakt</div>
                            {{ psp.representative ? psp.representative.lastNameFirstName : 'Nicht vorhanden' }}
                        </div>
                    </div>
                    <div class="col">
                        <b-form-checkbox v-model="psp.hide" disabled name="ausgeblendet-input" switch>
                            Ausgeblendet
                        </b-form-checkbox>

                        <b-form-checkbox v-model="psp.locked" disabled name="gesperrt-input" switch>
                            Gesperrt
                        </b-form-checkbox>

                        <b-form-checkbox v-model="psp.collector" disabled name="sammler-input" switch>
                            Sammler
                        </b-form-checkbox>
                    </div>
                </div>
            </b-overlay>

            <div class="simple-box">
                <h5 class="mb-3">Zugeordnete SIN</h5>

                <table-simple
                    table-id="psp-projects-table"
                    :fields="table.fields"
                    :filters="[]"
                    :total-rows-prop="table.totalRows"
                    :per-page-prop="table.perPage"
                    :items-provider="pspProjects"
                    ref="table"
                >
                    <template #cell(statusShortName)="data">
                        <badge :color="data.item.statusColor">{{ data.item.statusShortName }}</badge>
                    </template>

                    <template #cell(volumenDtts)="data">
                        {{ $f.numberToString(data.item.volumenDtts, true, true, '0,0 €') }}
                    </template>
                </table-simple>
            </div>

            <template #footer="{methods}">
                <button @click="hide" class="btn btn-secondary">Schließen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BOverlay, BFormCheckbox} from "bootstrap-vue";
import Badge from "@comp/Badge/Badge";
import TableSimple from '@comp/TableSimple/TableSimple';

export default {
    components: {ModalDialog, BOverlay, BFormCheckbox, Badge, TableSimple},
    props: {
        show: {
            default: false
        },
        pspId: {
            type: Number
        },
        pspElementOld: {
            type: String,
            default: null
        }
    },
    data() {
        return {
            pending: true,
            psp: {},
            table: {
                fields: [
                    {key: 'simpleId', label: 'SIN'},
                    {key: 'thema', label: 'Vorhabenname'},
                    {key: 'kundenname', label: 'Kundenname'},
                    {key: 'statusShortName', label: 'Status'},
                    {key: 'volumenDtts', label: 'Auftragsvolumen'},
                ],
                totalRows: 0,
                perPage: 0,
            }
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async getData() {
            try {
                const response = await this.$axios.get(`/admin/ccf/psp/details`, {
                    params: {
                        pspId: this.pspId,
                        pspElementOld: this.pspElementOld
                    }
                });

                this.psp = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async pspProjects(ctx) {
            try {
                if (!this.pspId) return [];

                ctx.pspId = this.pspId;
                ctx.pspElementOld = this.pspElementOld;

                const response = await this.$axios.post(`/admin/ccf/psp/projects`, ctx);

                this.table.totalRows = response.data.total;
                this.table.perPage = response.data.perPage;

                return response.data.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        }
    }
}
</script>
