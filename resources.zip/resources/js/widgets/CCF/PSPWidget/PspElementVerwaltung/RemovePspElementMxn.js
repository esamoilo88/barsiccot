import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    mixins: [ConfirmationModal],
    methods: {
        async deletePspElement(item) {
            const confirmed = await this.showConfirmationModal({
                title: 'PSP-Element löschen',
                message: `Bitte bestätige die Löschung des PSP-Elements ${item.pspElement}.`,
                okTitle: 'PSP-Element löschen',
            });

            if (!confirmed) return;

            window.preloader.show();

            try {
               let res = await this.$axios.delete(`/admin/ccf/psp/element/${item.id}`);
                this.updateTable();
                this.$eventBus.$emit('get-totals-element-count');
                window.flash.showMessagesFromAjax(res.data);
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }finally {
                window.preloader.hide();
            }
        }
    }
}
