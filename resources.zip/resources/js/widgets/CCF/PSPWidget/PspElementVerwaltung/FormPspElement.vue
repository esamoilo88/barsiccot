<template>
    <modal-dialog
        :is-visible="isModalVisible"
        @hideModal="hideModal"
        :static="true"
        :title-dialog="updatePspElement === null ? 'PSP-Element anlegen' : 'PSP-Element bearbeiten'"
        modal-class="modal-psp-element"
        :scrollable="true"
    >
        <div @keyup.enter="submit">
            <div class="mb-3">
                Bitte fülle alle mit * gekennzeichneten Felder aus.
            </div>
            <div class="simple-box">
                <b-form-group>
                    <FormInput
                        v-model="form.pspElement"
                        label-text="PSP-Element*"
                        name="pspElement"
                        input-id="pspElement"
                        v-mask="'Z-D4J-#########-##'"
                        placeholder="Z-D4J-012345678-90"
                        :error-conditions="errorConditions.pspElement"
                    />
                </b-form-group>
                <b-form-group>
                    <FormInput
                        v-model="form.parentName"
                        label-text="Übergeordneter Name*"
                        name="parent-name"
                        input-id="parentName"
                        :error-conditions="errorConditions.parentName"
                    />
                </b-form-group>
                <b-form-group>
                    <FormInput
                        v-model="form.name"
                        label-text="Name*"
                        name="name"
                        input-id="name"
                        :error-conditions="errorConditions.name"
                    />
                </b-form-group>
                <b-form-group>
                    <PeopleSearch
                        v-model="form.contact"
                        ref="searchContact"
                        label="Kontakt"
                        :multiple="false"
                        @user-added="contactAdded"
                        @user-dropped="contactDropped"
                        input-id="contact-search-button-content"
                    />
                </b-form-group>
                <b-form-group>
                    <PeopleSearch
                        v-model="form.representative"
                        ref="searchRepresentative"
                        label="Vertreter Kontakt"
                        :multiple="false"
                        @user-added="representativeAdded"
                        @user-dropped="representativeDropped"
                        input-id="representative-contact-search-button-content"
                    />
                </b-form-group>
                <b-form-group>
                    <b-form-checkbox
                        switch
                        v-model="form.hide"
                    >
                        Ausgeblendet
                    </b-form-checkbox>
                    <div class="text-muted mt-2">
                        Sofern aktiviert, können User das PSP-Element nicht auswählen.
                    </div>
                </b-form-group>
                <div class="horizontal-line-thin mb-3 mt-2"></div>

                <b-form-group>
                    <b-form-checkbox
                        switch
                        v-model="form.locked"
                    >
                        Gesperrt
                    </b-form-checkbox>
                    <div class="text-muted mt-2">
                        Ist ein PSP-Element gesperrt, können User bei zugeordneten Verträgen keine Faktura und ILV buchen.                    </div>
                </b-form-group>
                <div class="horizontal-line-thin mb-3 mt-2"></div>

                <b-form-group>
                    <b-form-checkbox
                        switch
                        v-model="form.collector"
                    >
                        Sammler
                    </b-form-checkbox>
                    <div class="text-muted mt-2">
                        Das PSP-Element wird als Sammler genuzt.
                    </div>
                </b-form-group>
                <div class="horizontal-line-thin mb-3 mt-2"></div>
            </div>
        </div>

        <template v-slot:footer>
            <button
                :key="'store-psp-element-btn'"
                @click="submit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Speichern
            </button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {mapActions, mapGetters, mapState} from "vuex";
import {BButton, BFormGroup, BSpinner, BFormCheckbox} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import {required, maxLength} from "vuelidate/lib/validators";
import {isPspElementValid} from "res/js/utils/Validators/SimpleCommonValidators";
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormDatepicker from '@comp/FormDatepicker/FormDatepicker'
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import {mask} from 'vue-the-mask'

export default {
    components: {
        FormInput,
        ModalDialog,
        BButton,
        BFormGroup,
        BSpinner,
        FormDatepicker,
        BFormCheckbox,
        FormInputAppend,
        PeopleSearch
    },
    directives: {mask},
    mixins: [Validation, ObjectsProcessing, DatesProcessing],
    props: {
        updatePspElement: {
            type: Object,
            required: false,
            default: null
        },
        hasPermissions: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        errorConditions() {
            return {
                pspElement: [
                    {
                        name: 'invalid-pspElement-required',
                        condition: this.isInvalid('pspElement', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'PSP Element'})
                    },
                    {
                        name: 'is-psp-element-unique',
                        condition: !this.isPspElementUnique && this.$v.form.pspElement.$dirty,
                        text: this.$t.__('validation.ccf.psp.isPspElementUnique')
                    },
                    {
                        name: 'invalid-pspelement-regex',
                        condition: this.isInvalid('pspElement', 'isPspElementValid'),
                        text: this.$t.__('validation.not_regex', {attribute: 'PSP Element'})
                    }
                ],
                name: [
                    {
                        name: 'invalid-name-required',
                        condition: this.isInvalid('name', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    },
                    {
                        name: 'name-max',
                        condition: !this.$v.form.name.maxLength && this.$v.form.name.$dirty,
                        text: 'Name soll nicht mehr als 150 Zeichen sein.'
                    }
                ],
                parentName: [
                    {
                        name: 'invalid-parent-name-required',
                        condition: this.isInvalid('parentName', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Übergeordneter Name'})
                    },
                    {
                        name: 'parentName-max',
                        condition: !this.$v.form.parentName.maxLength && this.$v.form.parentName.$dirty,
                        text: 'Übergeordneter Name soll nicht mehr als 150 Zeichen sein.'
                    }
                ]
            }
        }
    },
    data() {
        return {
            isPspElementUnique: true,
            isModalVisible: false,
            onSubmitPending: false,
            form: {
                pspElement: null,
                parentName: null,
                name: null,
                contact: null,
                representative: null,
                hide: false,
                locked: false,
                collector: false
            }
        }
    },
    methods: {
        contactAdded(user) {
            console.log(user)
            this.form.contact = user.benutzerId;
        },
        contactDropped() {
            this.form.contact = null;
        },

        representativeAdded(user) {
            this.form.representative = user.benutzerId;
        },
        representativeDropped() {
            this.form.representative = null;
        },
        showModal(item = null) {
            this.isModalVisible = true;
            if (item) {
                this.fillData(item);
            }
        },
        fillData(item) {
            this.form.pspElement = item.pspElement;
            this.form.name = item.name;
            this.form.parentName = item.parentName;
            this.form.hide = item.hide;
            this.form.collector = item.collector;
            this.form.locked = item.locked;
            this.form.representative = item.representative_id;
            this.form.contact = item.contact_id;
            if(item.representative_name) {
                this.$refs.searchRepresentative.pushUser({
                    display_name: item.representative_name,
                    department: null,
                    email: item.representative_email,
                });
            }
            if(item.contact_name) {
                this.$refs.searchContact.pushUser({
                    display_name: item.contact_name,
                    department: null,
                    email: item.contact_email,
                });
            }
        },
        /**
         * Create PSP-Element
         * @returns {void}
         */
        async onCreate() {
            try {
                const res = await this.$axios.post(`/admin/ccf/psp/element`, this.form);
                if (res.data.isPspElementUnique) {
                    navigateToFirstInvalid();
                    this.onSubmitPending = false;
                    return this.isPspElementUnique = false;
                }
                this.$eventBus.$emit('update-table');
                this.$eventBus.$emit('get-totals-element-count');
                this.hideModal();
                window.flash.showMessagesFromAjax(res.data);
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
                console.error("Couldn't create PSP Element", error);
            }
            this.onSubmitPending = false;
        },

        /**
         * Update PSP Element
         * @returns {void}
         */
        async onUpdate() {
            try {
                const res = await this.$axios.put(`/admin/ccf/psp/element/${this.updatePspElement.id}`,
                    {...this.form}
                );
                this.$eventBus.$emit('update-table');
                this.$eventBus.$emit('get-totals-element-count');
                window.flash.showMessagesFromAjax(res.data);
                this.hideModal();
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't update PSP Element", err);
            }
            this.onSubmitPending = false;
        },
        async submit() {
            this.$v.$touch();

            if (this.$v.$anyError) {
                this.showValidationErrors = true;
                navigateToFirstInvalid();
                return;
            }
            this.onSubmitPending = true;
            if (this.updatePspElement) {
                await this.onUpdate();
            } else {
                await this.onCreate();
            }
        },
        hideModal() {
            this.clearForm();
            this.isModalVisible = false;
        },
        clearForm(item = null) {
            this.showValidationErrors = false;
            if (item === null) {
                this.form = {
                    pspElement: null,
                    parentName: null,
                    name: null,
                    contact: null,
                    representative: null,
                    hide: false,
                    locked: false,
                    collector: false
                };
                this.$refs.searchRepresentative.clear();
                this.$refs.searchContact.clear();
            }
        }
    },
    validations: {
        form: {
            pspElement: {required, isPspElementValid},
            parentName: {required, maxLength: maxLength(150)},
            name: {required, maxLength: maxLength(150)}
        }
    }

}
</script>
<style lang="scss" scoped>
.icon {
    width: 46px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.horizontal-line-thin {
    height: 1.5px;
    background-color: #dee2e6;
}
.people-search-component {
   width: 100%;
}
</style>
