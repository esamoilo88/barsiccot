<template>
    <div>
        <ControlPanel
            :has-permission="hasPermission"
            :filters="filters"
            @update-table="updateTable"
        />
        <b-overlay :show="pending">
            <table-simple
                table-id="pspElementVerwaltung"
                :fields="fields"
                :filters="[]"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="getData"
                ref="table"
                class="shadow-none mt-2"
                primary-key="pspElementId"
            >
                <template #cell(pspElement)="data">
                    <a href="#" class="text-primary" @click="showDetails(data.item)">{{ data.item.pspElement }}</a>
                </template>
                <template #cell(uebergeordneter-name)="data">
                    <truncated-text
                        class="text-break"
                        :text="data.item.parentName"
                        title="Übergeordneter Name anzeigen"
                        :max-length="100"
                    />
                </template>
                <template #cell(name)="data">
                    <truncated-text
                        class="text-break"
                        :text="data.item.name"
                        title="Name anzeigen"
                        :max-length="100"
                    />
                </template>
                <template #cell(kontakt)="data">
                    {{ data.item.contact_name }}
                </template>
                <template #cell(merkmale)="data">
                    <b-badge v-if="data.item.collector" variant="warning" class="mb-1">Sammler</b-badge>
                    <b-badge v-if="data.item.hide" variant="secondary" class="mb-1">Ausgeblendet</b-badge>
                    <b-badge v-if="data.item.locked" variant="danger" class="mb-1">Gesperrt</b-badge>
                </template>
                <template #cell(options)="data">
                    <div class="text-nowrap">
                        <template>
                            <ButtonIcon
                                v-if="hasPermission"
                                icon-class="icon-action-edit-default"
                                variant="secondary"
                                title="PSP-Element bearbeiten"
                                @click="showModal(data.item)"
                                hint-position="top"
                            />
                            <ButtonIcon
                                v-if="hasPermission"
                                icon-class="icon-action-remove-default"
                                variant="danger"
                                title="PSP-Element löschen"
                                @click="deletePspElement(data.item)"
                                hint-position="top"
                                :button-id="'deleteButton-' + data.item.id"
                            />
                        </template>
                    </div>
                </template>
            </table-simple>
        </b-overlay>
        <form-psp-element
            ref="pspElementForm"
            :update-psp-element="updatePspElement"
        />

        <DetailsDialog
            v-if="detailsDialog.pspId"
            :show="detailsDialog.show"
            :psp-id="detailsDialog.pspId"
            @hide="hideDetails" />
    </div>
</template>

<script>
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BTooltip, BOverlay, BBadge} from 'bootstrap-vue';
import TableSimple from '@comp/TableSimple/TableSimple';
import {mapState} from "vuex";
import ControlPanel from "./ControlPanel";
import FormPspElement from "./FormPspElement";
import RemovePspElementMxn from "./RemovePspElementMxn";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import DetailsDialog from './DetailsDialog';

export default {
    name: 'PspElementVerwaltung',
    mixins: [RemovePspElementMxn],
    components: {
        TruncatedText,
        FormPspElement,
        ControlPanel,
        ButtonIcon,
        BTooltip,
        TableSimple,
        BOverlay,
        BBadge,
        DetailsDialog
    },
    props: {
        hasPermission: {
            type: Boolean,
            required: true
        }
    },
    created() {
        this.$eventBus.$on('update-table', async () => await this.updateTable());
    },
    data() {
        return {
            updatePspElement: null,
            fields: [
                {key: 'pspElement',label: 'PSP-Element', sortable: true, sortKey: 'pspElement', thStyle: {width: '20%'}},
                {key: 'uebergeordneter-name', label: 'Übergeordneter Name',sortable: true, sortKey: 'parentName', thStyle: {width: '30%'}},
                {key: 'name', label: 'Name',sortable: true, sortKey: 'name', thStyle: {width: '15%'}},
                {key: 'kontakt', label: 'Kontakt', thStyle: {width: '15%'}},
                {key: 'merkmale', label: 'Merkmale'},
                {key: 'options', label: 'Optionen', class: 'optionen-col', sortable: false}
            ],
            sortBy: 'name',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            pending: false,
            detailsDialog: {
                show: false,
                pspId: null
            }
        }
    },
    computed: {
        ...mapState({
            filters: state => state.pspElement.filters
        })
    },
    methods: {
        showModal(item = null) {
            this.updatePspElement = item;
            this.$refs.pspElementForm.showModal(item);
        },
        async updateTable() {
            if (this.$refs.table) {
                await this.$refs.table.itemsProviderProxy(this.$refs.table.getContext());
            }
        },
        async getData(ctx) {
            try {
                ctx.filter = ctx.filter !== null ? {...ctx.filter, ...this.filters} : {...this.filters};
                const response = await this.$axios.post('/admin/ccf/psp/element/control/list', ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (error) {
                return []
            }
        },
        showDetails(item) {
            this.detailsDialog.show = true;
            this.detailsDialog.pspId = item.id;
        },
        hideDetails() {
            this.detailsDialog.show = false;
            this.detailsDialog.pspId = null;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.counters-overlay {
    ::v-deep span {
        width: 1rem;
        height: 1rem;
        border: 0.15em solid currentColor;
        border-right-color: transparent;
    }
}

#representative-filter {
    ::v-deep label {
        background: transparent;
        border: none;
        outline: none;
        border-bottom: 2px solid transparent;
        transition-duration: 0s;

        &:hover, &.active, &:active {
            background: transparent;
            color: $primary;
            outline: none;
            box-shadow: none;
            border-radius: 0;
            border-bottom: 2px solid $primary;
        }
    }
}

::v-deep div.searchable-select {
    min-width: 147px;
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}
</style>
