<template>
    <div class="d-flex align-items-start flex-wrap">
        <div class="mb-3">
            <button
                v-if="hasPermission"
                href="#"
                @click="showModal()"
                class="btn btn-primary center-content mt-2 mr-3"
            >
                PSP-Element anlegen
            </button>
            <button
                v-if="hasPermission"
                href="#"
                @click="onPspImport"
                class="btn btn-secondary center-content mt-2 mr-3"
            >
                PSP-Elemente importieren
            </button>
        </div>
        <div class="right-side">
            <FormSelect
                v-model="sichtbarkeitSelected"
                :readonly="pending"
                label-text="Sichtbarkeit"
                class="view-type-select w-50 mr-3"
                @select="onSichtbarChange"
                preselected="alle"
                select-id="sichtbar-select"
                name="sichtbar-select"
                :options="sichtbarOptions"
                with-html
                with-html-selection
            />
            <FormSelect
                v-model="sperreSelected"
                :readonly="pending"
                label-text="Sperre"
                class="view-type-select w-50 mr-3"
                @select="onSperreChange"
                select-id="sperre-select"
                name="sperre-select"
                :options="sperreOptions"
                with-html
                with-html-selection
            />
            <FormSelect
                v-model="sammlerSelected"
                :readonly="pending"
                label-text="Sammler"
                class="view-type-select w-50 mr-3"
                @select="onSammlerChange"
                select-id="sammler-select"
                name="sammler-select"
                :options="sammlerOptions"
                with-html
                with-html-selection
            />
            <b-input-group class="search-input-wrapper w-75">
                <b-input-group-prepend><span class="icon-action-search-default"></span></b-input-group-prepend>
                <b-form-input
                    v-model="search"
                    :disabled="pending"
                    @update="onSearchElement"
                    class="search-project-input"
                    debounce="800"
                    placeholder="Suchen"
                    autocomplete="off"
                ></b-form-input>
            </b-input-group>
        </div>
        <form-psp-element
            ref="pspElementForm"
        />
        <import-psp-element
            ref="importPspElement"
            :is-visible="isPSPImportFormActive"
            @close-dialog="onPspImportClose"
        />
    </div>
</template>
<script>
import {BButton, BTooltip, BInputGroup, BInputGroupPrepend, BFormInput} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import PspElementFilterMxn from "../PspElementFilterMxn";
import FormPspElement from "./FormPspElement";
import ImportPspElement from "./Excel/ImportPspElement";
import PSPExcelMxn from "./Excel/PSPExcelMxn"

export default {
    name: 'control-panel',
    mixins: [PspElementFilterMxn, PSPExcelMxn],
    components: {
        ImportPspElement,
        FormPspElement,
        BButton,
        BTooltip,
        FormSelect,
        BInputGroup,
        BInputGroupPrepend,
        BFormInput
    },
    props: {
        hasPermission: {
            type: Boolean,
            required: true
        },
        filters: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            pending: false,
            search: this.filters.search_elements,
            sichtbarkeitSelected: this.filters.sichtbar,
            sperreSelected: this.filters.sperre,
            sammlerSelected: this.filters.sammler
        }
    },
    methods: {
        showModal(item = null) {
            this.$refs.pspElementForm.clearForm(item);
            this.$refs.pspElementForm.showModal(item);
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

::v-deep div.searchable-select {
    min-width: 180px;
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}

.right-side {
    margin-left: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

@media (max-width: 1200px) {
    .right-side {
        margin-left: 0;
        margin-top: 15px;
    }
}

@media (max-width: 770px) {
    .right-side {
        flex-direction: column;
        align-items: flex-start;
    }
    .view-type-select, .search-input-wrapper {
        margin-top: 15px;
        margin-left: 0;
    }
}
</style>
