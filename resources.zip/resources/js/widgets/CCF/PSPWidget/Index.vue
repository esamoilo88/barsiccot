<template>
    <div>
        <HeaderDates class="mb-4" :current="datesParsed.current" :u3="datesParsed.u3" :u7="datesParsed.u7"/>
        <HeaderPanel @change-tab="(val)=> isFirstTab = val" class="mb-4"/>
        <div class="simple-box box-shadow">
            <PspElementVerwaltung v-if="!isFirstTab" :has-permission="data.hasPermission"/>
            <Vertragsverwaltung v-if="isFirstTab"/>
        </div>
    </div>
</template>

<script>
import HeaderPanel from "./HeaderPanel";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";
import PspElementVerwaltung from './PspElementVerwaltung/List';
import Vertragsverwaltung from './Vertragsverwaltung/List';

export default {
    name: "pspelement",
    components: {
        HeaderDates,
        HeaderPanel,
        Vertragsverwaltung,
        PspElementVerwaltung
    },
    props: {
        data: {
            type: Object,
            required: true,
        }
    },
    data() {
        return {
            isFirstTab: 0
        }
    },
    computed: {
        datesParsed() {
            return this.data.commonData.dates// !== '[]' ?  JSON.parse(this.dates) : {current: {date: '-', u: '-', at: '-'}, u3: '-', u7: '-'};
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .more-options-btn span[class*=icon-] {
    font-size: 20px;
}
</style>
