<template>
    <div class="simple-box box-shadow">
        <div class="d-flex align-items-start flex-wrap">
            <b-form-radio-group
                id="pspelement-filter"
                class="pspElement-filter"
                v-model="pspelementTab"
                :disabled="pending"
                @change="onTabChange"
                buttons
            >
                <b-form-radio class="mr-3" :value="0">
                    PSP-Elemente
                    <b-badge variant="secondary ml-1">
                        <b-overlay class="counters-overlay" :show="countersElementsPending">
                            {{ pspElementsCount }}
                        </b-overlay>
                    </b-badge>
                </b-form-radio>
                <b-form-radio :value="1">
                    Verträge
                    <b-badge variant="secondary ml-1">
                        <b-overlay class="counters-overlay" :show="countersVertragsPending">
                            {{ vertragsCount }}
                        </b-overlay>
                    </b-badge>
                </b-form-radio>
            </b-form-radio-group>
        </div>
    </div>
</template>

<script>
import {
    BInputGroup, BInputGroupPrepend, BFormInput, BFormRadio,
    BFormRadioGroup, BBadge, BOverlay
} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import {mapMutations, mapState} from "vuex";

export default {
    name: "HeaderPanel",
    components: {
        FormSelect, BInputGroup, BInputGroupPrepend, BFormInput,
        BFormRadioGroup, BFormRadio, BBadge, BOverlay
    },
    async created() {
        await this.init();
    },
    data() {
        return {
            pending: false,
            pspelementTab: 0,
            countersElementsPending: false,
            countersVertragsPending: false,
            vertragsCount: 0,
            search: '',
            pspElementsCount: 0
        }
    },
    computed: {
        ...mapState({
            filters: state => state.pspElement.filters
        })
    },
    methods: {
        ...mapMutations({
            setZuordnung: 'pspElement/SET_ZUORDNUNG',
            setSearchVertrags: 'pspElement/SET_SEARCH_VERTRAGS',
            setSearchElements: 'pspElement/SET_SEARCH_ELEMENTS',
            setSperre: 'pspElement/SET_SPERRE',
            setSammler: 'pspElement/SET_SAMMLER',
            setSichtbar: 'pspElement/SET_SICHTBAR',
        }),
        async onTabChange(value) {
            this.pending = true;
            this.$emit('change-tab', value);
            this.pending = false;
        },

        async init() {
            this.setZuordnung('zuordnung_offen');
            this.$eventBus.$on('get-totals-vertrag-count', async () => await this.getVertragsTotalsCount());
            this.$eventBus.$on('get-totals-element-count', async () => await this.getElementsTotalsCount());
            await this.getVertragsTotalsCount();
            await this.getElementsTotalsCount();
        },
        async getElementsTotalsCount() {
            this.countersElementsPending = true;
            try {
                let res = await this.$axios.post('/admin/ccf/psp/elements/totals-count', {filter: {...this.filters}});
                this.pspElementsCount = res.data;
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.countersElementsPending = false;
        },
        async getVertragsTotalsCount() {
            this.countersVertragsPending = true;
            try {
                let res = await this.$axios.post('/admin/ccf/psp/vertrags/totals-count', {filter: {...this.filters}});
                this.vertragsCount = res.data;
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.countersVertragsPending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.counters-overlay {
    ::v-deep span {
        width: 1rem;
        height: 1rem;
        border: 0.15em solid currentColor;
        border-right-color: transparent;
    }
}

#pspelement-filter {
    ::v-deep label {
        background: transparent;
        border: none;
        outline: none;
        border-bottom: 2px solid transparent;
        transition-duration: 0s;

        &:hover, &.active, &:active {
            background: transparent;
            color: $primary;
            outline: none;
            box-shadow: none;
            border-radius: 0;
            border-bottom: 2px solid $primary;
        }
    }
}

.view-type-select {
    width: 210px;

    ::v-deep div.searchable-select-inner,
    ::v-deep span.select2.select2-container.select2-container--default,
    ::v-deep span.select2-selection.select2-selection--single {
        min-height: 35px;
    }

    ::v-deep .select2-container .select2-selection--single .select2-selection__rendered {
        margin-bottom: 0;
    }

    ::v-deep #select2-view-type-select-container {
        padding-right: 30px;
    }

    ::v-deep .select2-container .select2-selection--single .select2-selection__rendered {
        font-weight: normal;
        font-size: 100%;
    }
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}

.right-side {
    margin-left: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

@media (max-width: 1200px) {
    .right-side {
        margin-left: 0;
        margin-top: 15px;
    }
}

@media (max-width: 770px) {
    .right-side {
        flex-direction: column;
        align-items: flex-start;
    }
    .view-type-select, .search-input-wrapper {
        margin-top: 15px;
        margin-left: 0;
    }
}
</style>
