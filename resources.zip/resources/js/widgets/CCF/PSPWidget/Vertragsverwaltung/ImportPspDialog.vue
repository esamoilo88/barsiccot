<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide(false)"
            title-dialog="Zuordnungen importieren"
            modal-class="import-psp-dialog"
        >
            <b-overlay :show="pending">
                <div class="simple-box">
                    <div class="mb-3 font-weight-bold">
                        Importiere die Zuordnung von PSP-Elementen per Excel-Datei. Spalte A = SIN (ohne SIN/), Spalte B = PSP-Element
                    </div>

                    <form-file-load
                        ref="file"
                        type="file"
                        browse-text="Auswählen"
                        @uploadFile="(file) => uploadFile(file, 'changeRequest')"
                        :placeholder="form.file ? form.file.name : 'Datei auswählen / drag&drop'"
                        accept=".xlsx"
                        :error-conditions="ec.file"
                    />

                    <div class="text-muted">Gültiger Dateityp: *.xlsx</div>

                    <table class="table mt-3 mb-3">
                        <tr v-for="item in previewData">
                            <td>{{ item.A === 'simple_id' ? 'SIN' : item.A }}</td>
                            <td>{{ item.B === 'psp_element' ? 'PSP-Element' : item.B }}</td>
                        </tr>
                    </table>

                    <table v-if="errors.length" class="table mt-3">
                        <thead>
                        <tr>
                            <th>Spalte</th>
                            <th>Zeile</th>
                            <th>Fehler</th>
                        </tr>
                        </thead>

                        <tbody>
                        <tr v-for="error in errors">
                            <td>{{ error.col }}</td>
                            <td>{{ error.row }}</td>
                            <td>{{ error.message }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="importPsp" class="btn btn-primary" :disabled="$v.form.$invalid">Fertig stellen</button>
                <button @click="hide(false)" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import FormFileLoad from "@comp/FileLoad/FormFileLoad";
import {BOverlay} from 'bootstrap-vue';
import {required} from "vuelidate/lib/validators";

export default {
    components: {ModalDialog, FormFileLoad, BOverlay},
    props: {
        show: {
            default: false
        }
    },
    computed: {
        ec() {
            return {
                file: [
                    {
                        name: 'file-required',
                        condition: !this.$v.form.file.required && this.$v.form.file.$dirty,
                        text: 'Eine XLSX-Datei muss ausgefüllt werden.'
                    }
                ]
            }
        }
    },
    data() {
        return {
            form: {
                file: null
            },
            pending: false,
            errors: [],
            previewData: []
        }
    },
    methods: {
        hide(update = false) {
            this.$emit('hide', update);

            this.clear();
        },
        clear() {
            this.$v.form.$reset();
            this.$refs.file.clearFiles();
            this.form.file = null;
            this.errors = [];
            this.previewData = [];
        },
        async importPsp() {
            if (this.pending) return;

            this.$v.form.$touch();

            if (this.$v.form.$invalid) return;

            this.pending = true;
            this.errors = [];
            this.previewData = [];

            try {
                await this.$axios.post('/admin/ccf/psp/xlsx/import', this.form.file);

                window.flash.success('Daten wurden importiert');

                this.hide(true);

            } catch (e) {
                if (e.response.status === 403) {
                    this.errors = e.response.data;
                } else {
                    window.flash.showMessagesFromAjax(e.response.data);
                }
            }

            this.pending = false;
        },
        async uploadFile(file) {
            if (this.pending) return;

            this.pending = true;

            this.errors = [];

            this.clear();

            try {
                const response = await this.$axios.post('/admin/ccf/psp/import/upload', file.formData, file.config);

                const uploadedFile = response.data.filesPath[0];

                this.form.file = {
                    'savePath': uploadedFile.tempPath,
                    'size': uploadedFile.size,
                    'name': file.fileNames,
                    'date': file.date
                }

                this.previewData = response.data.data;
            } catch (e) {
                if (e.response.status === 403) {
                    this.errors = e.response.data;
                } else {
                    window.flash.showMessagesFromAjax(e.response.data);
                }

                this.$refs.file.clearFiles();
            }

            this.pending = false;
        },
    },
    validations: {
        form: {
            file: {required}
        }
    }
}
</script>
