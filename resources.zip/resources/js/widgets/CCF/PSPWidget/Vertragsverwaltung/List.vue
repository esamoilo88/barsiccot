<template>
    <div>
        <ControlPanel :filters="filters"/>
        <b-overlay :show="pending">
            <table-simple
                table-id="vertragsverwaltung"
                :fields="fields"
                :filters="[]"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="getData"
                ref="table"
                class="shadow-none mt-2"
                primary-key="vertragsverwaltungId"
            >
                <template #cell(sin)="data">
                    {{ data.item.simpleId }}
                </template>
                <template #cell(vorhabenname)="data">
                    {{ data.item.thema }}
                </template>
                <template #cell(kundenname)="data">
                    {{ data.item.kundenname }}
                </template>
                <template #cell(status)="data">
                    <badge :color="data.item.color">{{ data.item.shortName }}</badge>
                </template>
                <template #cell(auftragsvolumen)="data">
                    {{ $f.numberToString(data.item.volumenDtts, true, true, '0,0 €') }}
                </template>
                <template #cell(psp_element)="data">
                    <a href="#" class="text-primary" @click="showDetails(data.item)">{{ data.item.pspElementOld }}</a>
                </template>
                <template #cell(options)="data">
                    <div class="text-nowrap ml-5">
                        <div class="options-container btn-group" role="group">
                            <a
                                :href="'/projects/' + data.item.simpleId"
                                class="btn btn-outline-secondary dashboard-link"
                                :id="'sales-dashboard-btn-' + data.item.simpleId"
                                title="Sales Dashboard"
                                v-b-tooltip.hover.lefttop
                            >
                                <span class="icon-content-news-default"></span>
                            </a>
                            <a
                                :href="'/offers/' + data.item.simpleId"
                                class="btn btn-outline-secondary dashboard-link"
                                :id="'offer-dashboard-btn-' + data.item.simpleId"
                                title="Offer Dashboard"
                                v-b-tooltip.hover.lefttop
                            >
                                <span class="icon-content-tarrifs-default"></span>
                            </a>
                            <a
                                :href="'/orders/' + data.item.simpleId"
                                class="btn btn-outline-secondary dashboard-link"
                                :id="'finance-dashboard-btn-' + data.item.simpleId"
                                title="Finance Dashboard"
                                v-b-tooltip.hover.lefttop
                            >
                                <span class="icon-user_file-billing-default"></span>
                            </a>

                            <button title="PSP-Element zuordnen" v-b-tooltip.hover.lefttop class="btn btn-primary" @click="showAssignDialog(data.item)">
                                <span class="icon-action-link-selected"></span>
                            </button>
                        </div>
                    </div>
                </template>
            </table-simple>
        </b-overlay>

        <DetailsDialog
            v-if="detailsDialog.pspId || detailsDialog.pspElementOld"
            :show="detailsDialog.show"
            :psp-id="detailsDialog.pspId"
            :psp-element-old="detailsDialog.pspElementOld"
            @hide="hideDetails" />

        <AssignDialog
            v-if="assignDialog.simple"
            :show="assignDialog.show"
            :simple="assignDialog.simple"
            @hide="hideAssignDialog" />
    </div>
</template>

<script>
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BTooltip, BOverlay} from 'bootstrap-vue';
import TableSimple from '@comp/TableSimple/TableSimple';
import {mapState} from "vuex";
import ControlPanel from "./ControlPanel";
import Badge from "@comp/Badge/Badge";
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";
import DetailsDialog from "res/js/widgets/CCF/PSPWidget/PspElementVerwaltung/DetailsDialog";
import AssignDialog from "res/js/widgets/CCF/PSPWidget/Vertragsverwaltung/AssignDialog";
import {VBTooltip} from 'bootstrap-vue';

export default {
    name: 'vertragsverwaltung',
    components: {
        Badge,
        ControlPanel,
        ButtonIcon,
        BTooltip,
        TableSimple,
        BOverlay,
        DetailsDialog,
        AssignDialog
    },
    mixins:[ScalarsProcessing],
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            search:'',
            zuordnungSelected: 'zuordnung_offen',
            zuordnung: [
                {id: 'zuordnung_offen', text: "Zuordnung offen"},
                {id: 'zuordnung_erledigt ', text: "Zuordnung erledigt"}
            ],
            sichtbarkeitSelected: 'alle',
            sperreSelected: 'alle',
            sammlerSelected: 'alle',
            fields: [
                {key: 'sin', label: 'SIN', sortable: true, sortKey: 'simpleId', thStyle: {width: '7%'}},
                {key: 'vorhabenname', label: 'Vorhabenname',sortable: true, sortKey: 'thema', thStyle: {width: '20%'}},
                {key: 'kundenname', label: 'Kundenname',sortable: true, sortKey: 'kundenname', thStyle: {width: '20%'}},
                {key: 'status', label: 'Status', sortable: true, sortKey: 'shortName', thStyle: {width: '8%'}},
                {key: 'auftragsvolumen', label: 'Auftragsvolumen',sortable: true, sortKey: 'volumenDtts', thStyle: {width: '15%'}},
                {key: 'psp_element', label: 'PSP-Element',sortable: true, sortKey: 'pspElement',thStyle: {width: '20%'}},
                {key: 'options', label: 'Optionen', class: 'optionen-col', sortable: false}
            ],
            sortBy: 'simpleId',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            pending: false,
            detailsDialog: {
                show: false,
                pspId: null,
                pspElementOld: null
            },
            assignDialog: {
                show: false,
                simple: null
            }
        }
    },
    created() {
        this.$eventBus.$on('update-table', async () => await this.updateTable());
    },
    computed: {
        ...mapState({
            filters: state => state.pspElement.filters
        })
    },
    methods: {
        async updateTable() {
            if (this.$refs.table) {
                await this.$refs.table.itemsProviderProxy(this.$refs.table.getContext());
            }
        },
        async getData(ctx) {
            try {
                ctx.filter = ctx.filter !== null ? {...ctx.filter, ...this.filters} : {...this.filters};
                const response = await this.$axios.post('/admin/ccf/psp/vertrags/control/list', ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (error) {
                return []
            }
        },
        showDetails(item) {
            this.detailsDialog.show = true;
            this.detailsDialog.pspId = item.pspId;
            this.detailsDialog.pspElementOld = item.pspElementOld;
        },
        hideDetails() {
            this.detailsDialog.show = false;
            this.detailsDialog.pspId = null;
            this.detailsDialog.pspElementOld = null;
        },
        showAssignDialog(item) {
            this.assignDialog.show = true;
            this.assignDialog.simple = item;
        },
        hideAssignDialog() {
            this.assignDialog.show = false;
            this.assignDialog.simple = null;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.counters-overlay {
    ::v-deep span {
        width: 1rem;
        height: 1rem;
        border: 0.15em solid currentColor;
        border-right-color: transparent;
    }
}

#representative-filter {
    ::v-deep label {
        background: transparent;
        border: none;
        outline: none;
        border-bottom: 2px solid transparent;
        transition-duration: 0s;

        &:hover, &.active, &:active {
            background: transparent;
            color: $primary;
            outline: none;
            box-shadow: none;
            border-radius: 0;
            border-bottom: 2px solid $primary;
        }
    }
}

::v-deep div.searchable-select {
    min-width: 147px;
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}
::v-deep .btn-icon {
    padding: 2px 4px;
}
</style>
