<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide"
            title-dialog="PSP-Element einem Vertrag zuordnen"
            modal-class="assign-dialog"
        >
            <b-overlay :show="pending">
                <table class="mb-3 w-100">
                    <tbody>
                        <tr>
                            <td width="40%">SIN</td>
                            <td class="font-weight-bold">{{ simple.simpleId }}</td>
                        </tr>
                        <tr>
                            <td>Stamm-SIN</td>
                            <td class="font-weight-bold">{{ simple.stammSimpleId }}</td>
                        </tr>
                        <tr>
                            <td>Vorhabenname</td>
                            <td class="font-weight-bold">{{ simple.thema }}</td>
                        </tr>
                        <tr>
                            <td>Kundenname</td>
                            <td class="font-weight-bold">{{ simple.kundenname }}</td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td>
                                <badge :color="simple.color">{{ simple.shortName }}</badge>
                            </td>
                        </tr>
                        <tr>
                            <td>Auftragsvolumen</td>
                            <td class="font-weight-bold">{{ $f.numberToString(simple.volumenDtts, true, true, '0,0 €') }}</td>
                        </tr>
                    </tbody>
                </table>

                <div class="form-group">
                    <FormSelect
                        v-model="form.pspId"
                        name="pspId"
                        select-id="pspId-input"
                        :options="pspOptions"
                        label-text="PSP-Element*"
                        searchable
                        @select="onSelect"
                        :error-conditions="errorConditions.pspId"
                    />
                </div>

                <div class="simple-box" v-if="psp.id">
                    <div class="mb-2">
                        <div class="font-weight-bold">Übergeordneter Name</div>

                        {{ psp.parentName }}
                    </div>

                    <div class="mb-2">
                        <div class="font-weight-bold">Name</div>
                        {{ psp.name }}
                    </div>

                    <div class="mb-2">
                        <div class="font-weight-bold">Kontakt</div>
                        {{ psp.contact ? psp.contact.fullName : 'Nicht vorhanden' }}
                    </div>

                    <div class="mb-5">
                        <div class="font-weight-bold">Vertreter Kontakt</div>
                        {{ psp.representative ? psp.representative.fullName : 'Nicht vorhanden' }}
                    </div>

                    <b-form-checkbox v-model="psp.hide" disabled name="ausgeblendet-input" switch>
                        Ausgeblendet
                    </b-form-checkbox>

                    <div class="text-muted text-small">
                        Sofern aktiviert, können User das PSP-Element nicht auswählen.
                    </div>

                    <hr>

                    <b-form-checkbox v-model="psp.locked" disabled name="gesperrt-input" switch>
                        Gesperrt
                    </b-form-checkbox>

                    <div class="text-muted text-small">
                        Ist ein PSP-Element gesperrt, können User bei zugeordneten Verträgen keine Faktura und ILV buchen.
                    </div>

                    <hr>

                    <b-form-checkbox v-model="psp.collector" disabled name="sammler-input" switch>
                        Sammler
                    </b-form-checkbox>

                    <div class="text-muted text-small">
                        Das PSP-Element wird als Sammler genuzt.
                    </div>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="save" class="btn btn-primary">Speichern</button>
                <button @click="hide" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BOverlay, BFormCheckbox} from "bootstrap-vue";
import FormSelect from "@comp/FormSelect/FormSelect";
import Badge from "@comp/Badge/Badge";
import {createOptions} from "@helpers/Form/InputsHelper";
import {required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";

export default {
    components: {ModalDialog, BOverlay, BFormCheckbox, FormSelect, Badge},
    mixins: [Validation],
    props: {
        show: {
            default: false
        },
        simple: {
            required: true,
            type: Object
        }
    },
    data() {
        return {
            pending: true,
            form: {
                pspId: this.simple.pspId
            },
            psp: {},
            pspOptions: []
        }
    },
    computed: {
        errorConditions() {
            return {
                pspId: [
                    {
                        name: 'pspId-required',
                        condition: this.isInvalid('pspId', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'PSP-Element'})
                    },
                ],
            }
        }
    },
    async mounted() {
        await this.getPspOptions();

        await this.prefill();
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async getPspOptions() {
            try {
                const response = await this.$axios.get(`/admin/ccf/psp/options`);

                this.pspOptions.push(...createOptions(
                    response.data,
                    (item) => item.id,
                    (item) => item.pspElement
                ));
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        onSelect(id) {
            const psp = this.pspOptions.find(item => item.id == id);

            if (psp) {
                this.psp = psp.payload;
            }
        },
        async save() {
            this.$v.form.$touch();

            if (this.pending || this.$v.form.$invalid) return;

            this.pending = true;

            try {
                await this.$axios.post(`/admin/ccf/psp/assign`, {
                    pspId: this.form.pspId,
                    simpleId: this.simple.simpleId
                });

                this.simple.pspElementOld = this.psp.pspElement;
                this.simple.pspId = this.form.pspId;

                this.form.pspId = null;

                this.hide();
                this.$v.form.$reset();

                window.flash.success('PSP-Element wurde zugewiesen');
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        async prefill() {
            if (!this.simple.stammSimpleId || this.simple.pspId) return;

            this.pending = true;

            try {
                const response = await this.$axios.get(`/admin/ccf/psp/stammsin/${this.simple.stammSimpleId}`);

                const pspId = response.data;
                const psp = this.pspOptions.find(item => item.id === pspId);

                if (psp) {
                    this.form.pspId = psp.id;
                    this.psp = psp.payload;
                }
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    },
    validations: {
        form: {
            pspId: {required},
        }
    }
}
</script>

<style lang="scss" scoped>
.text-small {
    font-size: 14px;
}
</style>
