<template>
    <div>
        <div class="row no-gutters align-items-center">
            <div class="col-auto mr-auto">
                <button @click="showImportDialog" class="btn btn-secondary" title="Zuordnungen importieren">Zuordnungen importieren</button>
                <button @click="downloadPspTemplate" class="btn btn-secondary" title="Download">
                    <i class="icon-action-download-default pr-2"></i>
                    Download
                </button>
            </div>

            <div class="col-auto">
                <div class="row no-gutters align-items-center">
                    <div class="col-auto">
                        <FormSelect
                            v-model="zuordnungSelected"
                            :readonly="pending"
                            label-text="Zuordnung"
                            class="view-type-select"
                            @select="onZuordnungChange"
                            preselected="alle"
                            select-id="sichtbar-select"
                            name="sichtbar-select"
                            :options="zuordnungOptions"
                            with-html
                            with-html-selection
                        />
                    </div>
                    <div class="col-auto">
                        <FormInputAppend
                            v-model="search"
                            name="search-input"
                            input-id="search-input-id"
                            label-text="Suchen"
                            prepended
                        >
                            <template #prepend>
                                <b-input-group-prepend is-text>
                                    <i class="icon-action-search-default"></i>
                                </b-input-group-prepend>
                            </template>
                        </FormInputAppend>
                    </div>
                </div>
            </div>
        </div>

        <ImportPspDialog :show="importDialog.show" @hide="hideImportDialog" />
    </div>
</template>

<script>
import { BTooltip, BInputGroup, BInputGroupPrepend, BFormInput} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import PspElementFilterMxn from "../PspElementFilterMxn";
import ImportPspDialog from "res/js/widgets/CCF/PSPWidget/Vertragsverwaltung/ImportPspDialog";
import FormInputAppend from "@comp/FormInput/FormInputAppend";

export default {
    name: 'control-panel',
    mixins: [PspElementFilterMxn],
    components: {
        BTooltip,
        FormSelect,
        BInputGroup,
        BInputGroupPrepend,
        BFormInput,
        ImportPspDialog,
        FormInputAppend
    },
    props:{
        filters: {
            type: Object,
            required: true
        }
    },
    watch: {
        search() {
            if (!this.awaitingSearch) {
                setTimeout(() => {
                    this.onSearchVertags(this.search);
                    this.awaitingSearch = false;
                }, 1000);
            }
            this.awaitingSearch = true;
        },
    },
    data() {
        return {
            pending: false,
            search: this.filters.search_vertrags,
            zuordnungSelected: this.filters.zuordnung,
            importDialog: {
                show: false
            },
            awaitingSearch: false
        }
    },
    methods: {
        showImportDialog() {
            this.importDialog.show = true;
        },
        hideImportDialog(update = false) {
            this.importDialog.show = false;

            if (update) {
                this.$emit('update-table');
            }
        },
        downloadPspTemplate() {
            const assigned = this.zuordnungSelected === 'zuordnung_offen' ? '0' : '1';

            window.location.href = `/admin/ccf/psp/export/template?assigned=${assigned}`;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

::v-deep div.searchable-select {
    min-width: 180px;
}

::v-deep .input-group-text {
    box-shadow: 0 1px 0 0 #e5e5e5;
}

::v-deep .select2-selection.select2-selection--single {
    width: 200px;
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}

.right-side {
    margin-left: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

@media (max-width: 1200px) {
    .right-side {
        margin-left: 0;
        margin-top: 15px;
    }
}

@media (max-width: 770px) {
    .right-side {
        flex-direction: column;
        align-items: flex-start;
    }
    .view-type-select, .search-input-wrapper {
        margin-top: 15px;
        margin-left: 0;
    }
}
</style>
