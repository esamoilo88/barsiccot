import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import pspElement from './modules/psp_element.store';

const store = new Vuex.Store({
    modules: {
        pspElement
    }
});

store.$axios = $axios;

export default store;
