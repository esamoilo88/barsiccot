export default {
    namespaced: true,
    state: {
        filters: {
            sperre: 'alle',
            sammler: 'alle',
            search_elements: '',
            search_vertrags: '',
            sichtbar: 'alle',
            zuordnung: 'zuordnung_offen'
        },
    },
    mutations: {
        SET_SICHTBAR(state, sichtbar) {
            state.filters.sichtbar = sichtbar;
        },
        SET_SPERRE(state, sperre) {
            state.filters.sperre = sperre;
        },
        SET_SAMMLER(state, sammler) {
            state.filters.sammler = sammler;
        },
        SET_SEARCH_VERTRAGS(state, search) {
            state.filters.search_vertrags = search;
        },
        SET_SEARCH_ELEMENTS(state, search) {
            state.filters.search_elements = search;
        },
        SET_ZUORDNUNG(state, zuordnung) {
            state.filters.zuordnung = zuordnung;
        }
    }
}
