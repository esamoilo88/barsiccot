import {mapMutations} from "vuex";
import {createOptions} from "@helpers/Form/InputsHelper";

export default {
    data() {
        return {
            zuordnung: [
                {label: 'Nach Aufwand',id: 'zuordnung_offen', text: "Zuordnung offen"},
                {id: 'zuordnung_erledigt ', text: "Zuordnung erledigt"}
            ],
            sichtbarkeit: [
                {id: 'alle', text: "Alle"},
                {id: 'sichtbar', text: "Sichtbar"},
                {id: 'ausgeblendet', text: "Ausgeblendet"}
            ],
            sammlerArray: [
                {id: 'alle', text: "Alle"},
                {id: 'nur_sammler', text: "Nur Sammler"},
                {id: 'keine_sammler', text: "Keine Sammler"}
            ],
            sperreArray: [
                {id: 'alle', text: "Alle"},
                {id: 'nicht_gesperrt', text: "Nicht gesperrt"},
                {id: 'gesperrt', text: "Gesperrt"}
            ],
        }
    },
    computed: {
        zuordnungOptions() {
            return createOptions(
                this.zuordnung,
                v => v.id,
                v => v.text,
                null,
                false,
                v => v.text
            );
        },
        sichtbarOptions() {
            return createOptions(
                this.sichtbarkeit,
                v => v.id,
                v => v.text,
                null,
                false,
                v => v.text
            );
        },
        sperreOptions() {
            return createOptions(
                this.sperreArray,
                v => v.id,
                v => v.text,
                null,
                false,
                v => v.text
            );
        },
        sammlerOptions() {
            return createOptions(
                this.sammlerArray,
                v => v.id,
                v => v.text,
                null,
                false,
                v => v.text
            );
        }
    },
    methods: {
        ...mapMutations({
            setZuordnung: 'pspElement/SET_ZUORDNUNG',
            setSearchVertrags: 'pspElement/SET_SEARCH_VERTRAGS',
            setSearchElements: 'pspElement/SET_SEARCH_ELEMENTS',
            setSperre: 'pspElement/SET_SPERRE',
            setSammler: 'pspElement/SET_SAMMLER',
            setSichtbar: 'pspElement/SET_SICHTBAR',
        }),
        async onSearchElement(value) {
            value = value.replace('SIN/', '');
            this.setSearchElements(value);
            this.pending = true;
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-element-count');
            this.pending = false;
        },
        async onSearchVertags(value) {
            value = value.replace('SIN/', '');
            this.setSearchVertrags(value);
            this.pending = true;
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-vertrag-count');
            this.pending = false;
        },
        async onZuordnungChange(value) {
            this.pending = true;
            this.setZuordnung(value);
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-vertrag-count');
            this.pending = false;
        },
        async onSichtbarChange(value) {
            this.pending = true;
            this.setSichtbar(value);
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-element-count');
            this.pending = false;
        },
        async onSperreChange(value) {
            this.pending = true;
            this.setSperre(value);
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-element-count');
            this.pending = false;
        },
        async onSammlerChange(value) {
            this.pending = true;
            this.setSammler(value);
            this.$eventBus.$emit('update-table');
            this.$eventBus.$emit('get-totals-element-count');
            this.pending = false;
        }

    }
}
