<template>
    <div>
        <HeaderDates class="mb-4" :current="data.dates.current" :u3="data.dates.u3" :u7="data.dates.u7"/>

        <div class="simple-box box-shadow d-flex">
            <div class="ccf-menu-wrapper d-flex flex-column">
                <ul class="ccf-menu">
                    <li
                        is="MenuItem"
                        title="Grundeinstellung ändern"
                        subtext="Ändere Klassifizierung, Rechnungsart und Debitoren eines Vertrags"
                        icon-class="icon-service-seettings-default"
                        href="/admin/ccf/settings"
                    ></li>
                    <li
                        is="MenuItem"
                        title="PSP-Elemente verwalten"
                        subtext="Erstelle neue PSP-Elemente und ordne diesen Verträgen zu"
                        icon-class="icon-action-link-default"
                        href="/admin/ccf/psp"
                    >
                    </li>
                    <li
                        is="MenuItem"
                        title="Sammelfaktura abrechnen"
                        subtext="Erstelle Rechnungen für die Sammelfaktura und buche sie im SAP"
                        icon-class="icon-user_file-billing-default"
                        href="/admin/ccf/collective-billing"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Abgrenzung erstellen"
                        subtext="Erstelle Abgrenzungen und exportiere sie für die Erfassung im SMART-Tool"
                        icon-class="icon-content-tarrifs-default"
                        href="#"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Vorleisterverrechnung erstellen"
                        subtext="Erstelle die Kosten für interne Vorleister und und exportiere sie für die Erfassung im SAP"
                        icon-class="icon-service-maintanance-default"
                        href="#"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Rabattierung einrichten"
                        subtext="Stelle die Rabattierung für einen Vertrag ein"
                        icon-class="icon-content-voucher-default"
                        href="/admin/ccf/discount"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Finanzsperre einrichten"
                        subtext="Sperre die Abrechnung eines Vertrags"
                        icon-class="icon-content-lock-default"
                        href="/admin/ccf/lock-billing"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Externe Faktura freigeben"
                        subtext="Quittiere die Abrechnung an externe Debitoren"
                        icon-class="icon-action-succsess-default"
                        href="#"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Historie einsehen"
                        subtext="Überprüfe die Finanzhistorie des CCF oder eines Vorhabens"
                        icon-class="icon-content-history-default"
                        href="/admin/ccf/history"
                    ></li>
                    <li
                        is="MenuItem"
                        title="Datenkorrektur"
                        subtext="Lade Daten in einem einheitlichen Datenformat hoch um Abrechnungsdaten zu korrigieren"
                        icon-class="icon-action-edit-default"
                        href="/admin/ccf/corrections"
                    ></li>
                </ul>
            </div>

            <div class="ml-4">
                <h2>Hallo, {{ data.user }}.</h2>

                <div class="mt-3" v-html="data.html"></div>
            </div>
        </div>
    </div>
</template>

<script>
import {VBTooltip} from "bootstrap-vue";
import MenuItem from "res/js/widgets/CCF/CCFWidget/MenuItem";
import HeaderDates from "res/js/widgets/CCF/CCFWidget/HeaderDates";

export default {
    name: "ccf",
    components: {HeaderDates, MenuItem},
    props: {
        data: {
            type: Object,
            required: true,
        }
    },
    directives: {
        'b-tooltip': VBTooltip
    },
}
</script>

<style lang="scss" scoped>
.ccf-menu-wrapper {
    border: 1px solid lightgrey;
    border-radius: 4px;
    padding: 20px;

    .ccf-menu {
        padding: 0;
    }

    ::v-deep .ccf-menu-item {
        margin-bottom: 20px;
        border-radius: 4px;

        .menu-item-icon {
            font-size: 1.8rem;
        }

        a {
            color: #000;
            text-decoration: none;
        }

        .menu-item-subtext {
            max-width: 320px;
        }
    }

    ::v-deep .ccf-menu-item:hover {
        background-color: #f1f1f1;
        cursor: pointer;
    }
}
</style>
