<template>
    <div>
        <div class="d-flex">
            <h1>
                <span class="icon-user_file-billing-selected mr-2"></span>
                Control Center Finance
            </h1>

            <div class="ml-auto" v-if="showBackBtn">
                <a href="#" @click.prevent="$emit('back')">
                    Zurück
                </a>
            </div>
        </div>

        <div class="simple-box box-shadow d-flex">
            <div class="d-flex">
                <span class="icon-content-calendar-default mr-2"></span>
                <span>Heute: {{formatDate(current.date, 'DD.MM.YYYY')}} (U-{{current.u}}, AT-{{current.at}})</span>
            </div>

            <div class="divider"></div>

            <div class="d-flex">
                <span class="icon-content-calendar-default mr-2"></span>
                <span>Ultimo-7: {{formatDate(u7, 'DD.MM.YYYY')}}</span>
            </div>

            <div class="divider"></div>

            <div class="d-flex">
                <span class="icon-content-calendar-default mr-2"></span>
                <span>Ultimo-3: {{formatDate(u3, 'DD.MM.YYYY')}}</span>
            </div>
        </div>
    </div>
</template>

<script>
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: "HeaderDates",
    mixins: [DatesProcessing],
    props: {
        current: {
            type: Object,
            required: true
        },
        u7: {
            type: String,
            required: true
        },
        u3: {
            type: String,
            required: true
        },
        showBackBtn: {
            type: Boolean,
            default: false
        }
    }
}
</script>

<style scoped>
.divider {
    width: 2px;
    background-color: lightgrey;
    border-radius: 1rem;
    margin: 0 40px;
}
</style>
