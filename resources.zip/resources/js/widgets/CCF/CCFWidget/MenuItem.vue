<template>
    <li class="ccf-menu-item d-flex p-2" v-once>
        <a :href="href" class="d-flex">
            <span :class="iconClass + ' mr-3 menu-item-icon'"></span>
            <div class="d-flex flex-column">
                <span class="menu-item-title font-weight-bold mb-1">{{ title }}</span>
                <span class="menu-item-subtext text-muted text-1r">
                    {{ subtext }}
                </span>
            </div>
        </a>
    </li>
</template>

<script>
export default {
    name: "MenuItem",
    props: {
        href: {
            type: String,
            required: true
        },
        iconClass: {
            type: String,
            required: true
        },
        title: {
            type: String,
            required: true
        },
        subtext: {
            type: String,
            default: ''
        }
    }
}
</script>

<style scoped>

</style>
