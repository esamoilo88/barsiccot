<template>
    <div class="simple-box box-shadow">
        <div class="d-flex align-items-start flex-wrap">
            <b-form-radio-group
                id="representative-filter"
                class="representative-filter"
                v-model="representative"
                :disabled="pending"
                @change="onTabChange"
                buttons
            >
                <b-form-radio class="mr-3" :value="0">
                    Offiziell
                    <b-badge variant="secondary ml-1">
                        <b-overlay class="counters-overlay" :show="countersPending">
                            {{ leadedProjectsCount }}
                        </b-overlay>
                    </b-badge>
                </b-form-radio>
                <b-form-radio :value="1">
                    Vertretung
                    <b-badge variant="secondary ml-1">
                        <b-overlay class="counters-overlay" :show="countersPending">
                            {{ representativeProjectsCount }}
                        </b-overlay>
                    </b-badge>
                </b-form-radio>
                <b-form-radio class="mr-3"  :value="2">
                    Gruppen
                    <b-badge variant="secondary ml-1">
                        <b-overlay class="counters-overlay" :show="countersPending">
                            {{ groupCount }}
                        </b-overlay>
                    </b-badge>
                </b-form-radio>
            </b-form-radio-group>
            <div class="right-side">
                <b-input-group class="search-input-wrapper">
                    <FormInput
                        v-model="search"
                        input-id="search"
                        name="search"
                        :disabled="pending"
                        @change="onSearch"
                        class="filter-item"
                        debounce="800"
                        label-text="Suchen..."
                        autocomplete="off"
                    />
                </b-input-group>
            </div>
        </div>
    </div>
</template>

<script>
import {
    BInputGroup, BInputGroupPrepend, BFormInput, BFormRadio,
    BFormRadioGroup, BBadge, BOverlay
} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInput from "@comp/FormInput/FormInput"
import {mapGetters, mapMutations, mapState} from 'vuex';
import FilterListOptions from "./LBUTable/FilterListOptionsMxn";


export default {
    name: "HeaderPanel",
    components: {
        FormSelect, BInputGroup, BInputGroupPrepend, BFormInput,
        BFormRadioGroup, BFormRadio, BBadge, BOverlay, FormInput
    },
    mixins: [FilterListOptions],
    async created() {
        this.$eventBus.$on('get-totals-count',  async () => await this.getTotalsCount());
        await this.init();
    },
    props:{
        simpleId: {
            type: Number,
            required: false,
            default: null
        }
    },
    data() {
        return {
            filtersApplied: {},
            representative: 0,
            search: '',
            leadedProjectsCount: 0,
            representativeProjectsCount: 0,
            pending: false,
            countersPending: false,
            groupCount: 0
        }
    },
    computed: {
        ...mapState({
            filters: state => state.confirmLbuList.filters,
        })
    },
    methods: {
        ...mapMutations({
            setHeaderTab: 'confirmLbuList/SET_HEADER_TAB',
            setSearch: 'confirmLbuList/SET_SEARCH',
        }),
        onTabChange(value) {
            this.setHeaderTab(value);
            this.$eventBus.$emit('update-confirm-lbu');
        },
        async onSearch(value) {
            value = value.replace('SIN/', '');
            this.setSearch(value);
            this.$eventBus.$emit('update-confirm-lbu', value);
            await this.getTotalsCount();
        },
        async init() {
            this.$eventBus.$on('confirm-lbu-list-ready', (value) => {
                this.pending = false
            });
            await this.getTotalsCount();
        },
        async getTotalsCount() {
            this.pending =true;
            this.countersPending = true;
            if(this.simpleId){
                this.filters.simpleId = this.simpleId;
            }
            try {
                let res = await this.$axios.post('/orders/lbu/multi-confirm/totals-count', {filter: {...this.filters}});
                this.leadedProjectsCount = res.data.leaded;
                this.representativeProjectsCount = res.data.representative;
                this.groupCount = res.data.group;
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
            this.countersPending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.counters-overlay {
    ::v-deep span {
        width: 1rem;
        height: 1rem;
        border: 0.15em solid currentColor;
        border-right-color: transparent;
    }
}

#representative-filter {
    ::v-deep label {
        background: transparent;
        border: none;
        outline: none;
        border-bottom: 2px solid transparent;
        transition-duration: 0s;

        &:hover, &.active, &:active {
            background: transparent;
            color: $primary;
            outline: none;
            box-shadow: none;
            border-radius: 0;
            border-bottom: 2px solid $primary;
        }
    }
}

.view-type-select {
    width: 210px;

    ::v-deep div.searchable-select-inner,
    ::v-deep span.select2.select2-container.select2-container--default,
    ::v-deep span.select2-selection.select2-selection--single {
        min-height: 35px;
    }

    ::v-deep .select2-container .select2-selection--single .select2-selection__rendered {
        margin-bottom: 0;
    }

    ::v-deep #select2-view-type-select-container {
        padding-right: 30px;
    }

    ::v-deep .select2-container .select2-selection--single .select2-selection__rendered {
        font-weight: normal;
        font-size: 100%;
    }
}

.search-input-wrapper {
    width: 200px;

    .input-group-prepend {
        border: 1px solid #ced4da;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
        border-right: none;

        span {
            margin: auto 0 auto 10px;
        }
    }

    input {
        font-size: 100%;
        max-height: 35px;
        border-left: none;
    }
}

.filter-item {
    margin-bottom: 5px;

    &:not(:first-child) {
        margin-left: 3px;
    }
}

.right-side {
    margin-left: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

@media (max-width: 1200px) {
    .right-side {
        margin-left: 0;
        margin-top: 15px;
    }
}

@media (max-width: 770px) {
    .right-side {
        flex-direction: column;
        align-items: flex-start;
    }
    .view-type-select, .search-input-wrapper {
        margin-top: 15px;
        margin-left: 0;
    }
}
</style>
