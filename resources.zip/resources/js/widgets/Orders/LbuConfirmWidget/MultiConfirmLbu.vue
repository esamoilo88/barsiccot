<template>
    <div>
        <PagePreloader v-if="!isStoreInit"/>
        <div v-else>
            <HeaderPanel :simple-id="simpleId" class="mb-4" />

            <div class="simple-box box-shadow position-relative">
                <LbuTable :freigabegrund="freigabegrund" :simple-id="simpleId" />
            </div>
        </div>
    </div>
</template>

<script>
import PagePreloader from "./PagePreloader";
import HeaderPanel from "./HeaderPanel";
import Loading from "@comp/DynamicImportHelpers/Loading";
import {mapGetters} from "vuex";

const LbuTable = () => ({loading: Loading, component: import('./LBUTable/List'), delay: 0});

export default {
    name: "send-lbu-list",
    components: {
        PagePreloader, HeaderPanel,LbuTable
    },
    props:{
        simpleId: {
            type: Number,
            required: false,
            default: null
        },
        freigabegrund: {
            type: Object,
            required: true,
        }
    },
    data() {
        return {
            lbuList: [],
            pending: false
        }
    },
    computed: {
        ...mapGetters({
            isStoreInit: 'confirmLbuList/isInit'
        }),
    },
    methods: {
        getLbu(value){
            this.lbuList = value;
        }
    }
}
</script>

<style scoped>

</style>
