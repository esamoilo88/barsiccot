import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Vuelidate from "vuelidate";
import MultiConfirmLbu from "./MultiConfirmLbu";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import Formatter from "res/js/utils/formatter";
import store from './store';

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;

Vue.use(Vuelidate);
const translations = require('res/lang/lang.translations.json');

const t = new SimpleTranslator(translations);
Vue.prototype.$t = t;

new Vue({
    el: "#confirm-lbu-list", //resources/views/App/Orders/multi_confirm_lbu.blade.php');
    components: {
        MultiConfirmLbu
    },
    store
});
