<template>
    <div>
        <div class="row justify-content-between mb-3">
            <div class="col-auto mt-2">
                <b-form-checkbox v-model="isAllSelected" @change="chooseAll">
                    Alle LBU auswählen
                </b-form-checkbox>
            </div>
            <div class="col-auto">
                <button class="btn btn-primary" @click="confirmLbu" :disabled="selectedLbu.length === 0">LBU
                    fakturieren
                </button>
            </div>
        </div>
        <table-simple
            ref="table"
            table-id="send-lbu-list"
            :fields="fields"
            :filters="[]"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
            primary-key="id"
            striped
        >
            <template #cell(lbuId)="data">
                <b-form-checkbox
                    @change="handleCheck(data.item.lbuId)"
                    :key="data.item.lbuId"
                    :class="'lbu' + data.item.lbuId"
                    :value="data.item.lbuId"
                    v-model="selectedLbu"
                />
            </template>
            <template #cell(status)="data">
                <div class="d-flex align-items-center">
                    <CircleChart
                        :icon-class="data.item.statusIcon"
                        :content="''"
                        :value="data.item.statusProgress"
                        :color="data.item.statusColor"
                        size="xmsmall"
                        :sr-text="data.item.statusName"
                        class="mr-3"
                    />
                    <badge
                        :color="data.item.statusColor"
                        :title="data.item.statusDesc"
                        v-b-tooltip.hover
                    >
                        {{ data.item.statusName }}
                    </badge>
                </div>
            </template>
            <template #cell(lbu)="data">
                <div class="d-flex flex-column">
                    <div class="lbu-info d-flex text-muted my-1">
                        <span class="lbu-id mr-1">LBU/{{ data.item.lbuId }}</span>
                        <span
                            @click="copyToClipboard(data.item.lbuId)"
                            class="icon-content-clipboard-selected copy-to-clipboard"
                            tabindex="0"
                            title="LBU-ID kopieren"
                            v-b-tooltip.hover
                        ></span>
                        <span class="mx-1 bullet-divider">•</span>
                        <span>{{ data.item.vorgangstyp }}</span>
                        <span class="mx-1 bullet-divider">•</span>
                        <span>{{ data.item.debitorNummer }}</span>
                    </div>
                    <div class="d-flex">
                        <span class="font-weight-bold">
                            {{ monthYearConcat(data.item.leistungsMonat, data.item.leistungsJahr) }}
                        </span>
                        <span class="text-muted">▸</span>
                        <span class="font-weight-bold">
                            {{ monthYearConcat(data.item.fakturaMonat, data.item.fakturaJahr) }}
                        </span>
                    </div>
                </div>
            </template>
            <template #cell(simpleId)="data">
                <div class="lbu-info d-flex text-muted my-1">
                    <span class="mr-1">{{ data.item.vorhabenname }}</span>
                </div>
                <div class="d-flex">
                    <span class="font-weight-bold"> SIN/{{ data.item.simpleId }}</span>
                </div>
            </template>
            <template #cell(betrag)="data">
                <span :class="{
                    'font-weight-bold': true,
                    'text-success': (data.item.preisTP2 || 0) > 0,
                    'text-danger': (data.item.preisTP2 || 0) < 0,
                }">
                    {{ $f.numberToString(data.item.preisTP2, true, false, '0,00') }}
                </span>
            </template>
            <template #cell(grund)="data">
                <FormSelect
                    class="filter-item"
                    @input="value =>handleGrund(data.item.lbuId,value)"
                    name="reason"
                    v-model="freigabegrundId[data.item.lbuId]"
                    :select-id="'grund-filter'+data.item.lbuId"
                    :options="freigabegrundOption"
                    :key="data.item.lbuId"
                />
            </template>
            <template #cell(optionen)="row">
                <ButtonIcon
                    button-class="btn-icon-link"
                    icon-class="icon-action-more-selected"
                    :id="'lbu-more-btn-' + row.item.lbuId"
                    @click=""
                    title="Weitere Optionen"
                />
            </template>
        </table-simple>
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import SimpleDropdown from '@comp/SimpleDropdown/SimpleDropdown';
import Badge from '@comp/Badge/Badge';
import {BDropdownItemButton, BDropdownDivider, BDropdownItem, VBTooltip, BFormCheckbox} from 'bootstrap-vue';
import {mapState} from "vuex";
import Pagination from "@mixins/Pagination/Pagination";
import SelectLbuMix from "./SelectLbuMix";
import CircleChart from "@comp/CircleChart/CircleChart";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import FilterListOptions from "../LBUTable/FilterListOptionsMxn";
import FormSelect from '@comp/FormSelect/FormSelect';

export default {
    name: "LbuTabledList",
    components: {
        CircleChart,
        TableSimple,
        ButtonIcon,
        SimpleDropdown,
        BDropdownItemButton,
        Badge,
        BDropdownDivider,
        BDropdownItem,
        BFormCheckbox,
        FormSelect
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [Pagination, SelectLbuMix, DatesProcessing, FilterListOptions],
    props:{
        simpleId: {
            type: Number,
            required: false,
            default: null
        },
        freigabegrund: {
            type: Object,
            required: true,
        }
    },
    data() {
        return {
            freigabegrundId: [],
            fristAbgelauft: null,
            selectedFreigabegrund: [],
            allLbu: [],
            items: [],
            freigabegrundData: [],
            isAllSelected: false,
            selectedLbu: [],
            fields: [
                {key: "lbuId", label: "", thStyle: 'width:5%'},
                {key: "status", label: "Status", sortable: true, sortKey: 'statusId', thStyle: 'width:10%'},
                {key: "lbu", label: "LBU", sortable: true, sortKey: 'lbuId', thStyle: 'width:20%'},
                {key: "simpleId", label: "Vorhaben", sortable: true, sortKey: 'simpleId', thStyle: 'width:30%'},
                {key: "betrag", label: "Betrag", sortable: true, sortKey: 'betrag', thStyle: 'width:10%'},
                {key: "grund", label: "Grund", sortable: false, thStyle: 'width:20%'},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false, thStyle: 'width:5%'}
            ],
        }
    },
    computed: {
        ...mapState({
            filters: state => state.confirmLbuList.filters,
        })
    },
    async created() {
        this.setFreigabeGrund();
        this.$eventBus.$on('update-confirm-lbu', this.updateTable);
        this.initPaginationMxn(1, 0, 20, 'simpleId', true);
    },
    beforeDestroy() {
        this.$eventBus.$off('update-confirm-lbu', this.updateTable);
    },
    methods: {
        async updateTable() {
            await this.$refs.table.manualCtxTrigger();
        },
        handleGrund(lbuId, value) {
            this.freigabegrundId[lbuId] = value;
        },
        async itemsProvider(ctx) {
            if(this.simpleId){
                this.filters.simpleId = this.simpleId;
            }
            ctx.filter = ctx.filter !== null ? {...ctx.filter, ...this.filters} : {...this.filters};
            try {
                const response = await this.$axios.post('/orders/lbu/multi-confirm/list', ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                this.items.splice(0);
                this.items.push(...response.data.data);
                this.$eventBus.$emit('confirm-lbu-list-ready');
                this.allLbu = this.items.map(item => item.lbuId);
                this.preselectedGrund(this.items);
                return response.data.data;
            } catch (err) {
                console.log(err);
                this.$eventBus.$emit('confirm-lbu-list-ready');
                return [];
            }
        },
        copyToClipboard(lbuId) {
            let copyText = document.querySelector(`#send-lbu-list__row_${lbuId} .lbu-info .lbu-id`).innerHTML;
            copyText = copyText.replace('LBU/', '');
            const el = document.createElement('textarea');
            el.value = copyText;
            document.body.appendChild(el);
            el.select();
            document.execCommand('copy');
            document.body.removeChild(el);
            window.flash.info(`LBU id ${lbuId} wurde kopiert`);
        },
        setFreigabeGrund() {
            this.freigabegrundData = this.freigabegrund.freigabegrundList;
            this.fristAbgelauft = this.freigabegrund.fristAbgelauft;
        },
        async confirmLbu() {
            let confirmedLbu = [];
            for (let element of this.selectedLbu) {
                confirmedLbu.push(
                    {
                        'lbuId': element,
                        'grund': parseInt(this.freigabegrundId[element])
                    });
            }
            window.preloader.show();
            try {
                let res = await this.$axios.post('/orders/lbu/multi-confirm', {'selectedLBUs': confirmedLbu});
                this.selectedLbu = [];
                this.isAllSelected = false;
                window.preloader.hide();
                window.flash.showMessagesFromAjax(res.data);
                this.updateTable();
                this.$eventBus.$emit('get-totals-count');
            } catch (error) {
                window.preloader.hide();
                console.error(`Couldn't send lbu`, error);
                window.flash.showMessagesFromAjax(error.response.data);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

::v-deep .table-wrapper {
    box-shadow: none;
}

.dashboard-link {
    span {
        font-size: 1.5rem;
        color: $iconscolor;
        vertical-align: middle;
    }
}

.filter-item {
    max-width: 200px;
}
</style>
