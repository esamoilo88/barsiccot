import dayjs from "res/js/utils/day";

export default {
    computed: {
        freigabegrundOption() {
            return this.freigabegrundData.map(item => ({
                id: item.freigabegrundId,
                text: item.bezeichnung
            }));
        },
    },
    methods: {
        addLbuToSelectedList(lbuId) {
            if (this.selectedLbu.includes(lbuId)) return;
            this.selectedLbu.push(lbuId);
        },
        chooseAll() {
            if (this.isAllSelected) {
                this.allLbu.forEach(lbuId => {
                    this.addLbuToSelectedList(lbuId)
                });
            } else {
                this.allLbu.forEach(lbuId => {
                    this.removeLbuFromSelectedList(lbuId);
                });
            }
        },
        removeLbuFromSelectedList(lbuId) {
            this.selectedLbu = this.selectedLbu.filter(item => item !== lbuId);
        },
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        handleCheck(lbuId) {
            this.isLbuChecked(lbuId) ? this.addLbuToSelectedList(lbuId) : this.removeLbuFromSelectedList(lbuId);
            this.setAllSelected();
        },
        preselectedGrund(items) {
            items.map((lbu) => {
                if(lbu.freigabegrundId === null) {
                    this.freigabegrundId[lbu.lbuId] = (!lbu.autoApprove) ?
                        this.freigabegrundData.filter(e => e.bezeichnung === 'LBU bestätigt')[0]['freigabegrundId'] :
                        this.freigabegrundData.filter(e => e.bezeichnung === 'Dauerfreigabe')[0]['freigabegrundId'];
                    if (lbu.gesendetAm < this.fristAbgelauft) {
                        this.freigabegrundId[lbu.lbuId] = this.freigabegrundData.filter(e => e.bezeichnung === 'LBU Bestätigungsfrist abgelaufen')[0]['freigabegrundId']
                    }
                }else {
                    this.freigabegrundId[lbu.lbuId] = lbu.freigabegrundId;
                }
                return lbu;
            });
        },
        isAllLbuSelectedOnPage() {
            return this.selectedLbu.filter(lbuId => this.allLbu.includes(lbuId)).length === this.allLbu.length;
        },
        setAllSelected() {
            this.isAllSelected = this.isAllLbuSelectedOnPage() && this.items.length > 0;
        },
        isLbuChecked(lbuId) {
            return this.selectedLbu.lastIndexOf(lbuId) !== -1;
        }
    }
}
