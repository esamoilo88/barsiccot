export default {
    computed: {
        filter() {

            this.filterOption = [
                {
                    field: "grund",
                    type: "select",
                    settings: {
                        preselected: preselected,
                        label: "Grund",
                        options: [
                            {id: "alle", text: "Alle"},
                            {id: "A1", text: "A1"},
                            {id: "A2", text: "A2"},
                            {id: "A3", text: "A3"}
                        ]
                    }
                }
            ];
            return this.filterOption;
        }
    }
}
