export default {
    namespaced: true,
    state: {
        filters: {
            representative: false,
            search: '',
            group: false
        },
    },
    mutations: {
        SET_SEARCH(state, search) {
            state.filters.search = search;
        },
        SET_HEADER_TAB(state, value) {
            state.filters.group = value === 2;
            state.filters.representative = state.filters.group === true ? null : !!value;
        },
    },
    actions: {

    },
    getters: {
        isInit(state) {
            //TODO later
            return true;
        }
    }
}
