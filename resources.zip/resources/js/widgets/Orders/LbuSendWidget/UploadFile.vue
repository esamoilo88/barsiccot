<template>
    <div class="simple-box box-shadow">
        <div>
            <!-- Styled -->
            <b-overlay :show="loading">
                <div class="pt-2">
                    <MultipleFileLoad
                            ref="files"
                            v-model="attachedfiles"
                            @uploadFiles="uploadFiles"
                            title="Dateianlagen"
                            label-text="Dateianhänge"
                            name="attachedfile"
                            placeholder="Datei auswählen / drag&drop"
                            browse-text="Dateien auswählen"
                            input-id="Dateien"
                            :is-button-typ="false"
                            icon-remove="icon-action-remove-default"
                            accept=".xlsx, .xls, .doc, .docx, .pdf, .p7f, .xia"
                        />
                </div>
            </b-overlay>
        </div>
    </div>
</template>

<script>
import {BOverlay, VBTooltip} from 'bootstrap-vue';
import dayjs from "res/js/utils/day";
import FormatBytes from "@comp/FileLoad/FormatBytes";
import MultipleFileLoad from "@comp/FileLoad/MultipleFileLoad";

export default {
    name: "FileUpload",
    components: {
        MultipleFileLoad,
        BOverlay
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [FormatBytes],
    created() {
        this.$eventBus.$on('clear-attachments',  async () => await this.clearAttachments());
    },
    data() {
        return {
            filesInfo: null,
            attachedfiles: [],
            formData: new FormData(),
            loading: false,
            file: null,
        }
    },
    methods: {
        formatedDate(date) {
            return dayjs(date.date).format('DD.MM.YYYY H:mm');
        },
        async uploadFiles(filesInfo) {
            this.filesInfo = filesInfo;
            if (this.filesInfo !== null) {
                await this.$axios.post('/file/getPath', this.filesInfo.formData, this.filesInfo.config).then(
                    response => {
                        this.attachedfiles = response.data.filesPath.map((elem, key) => {
                            return {
                                'savePath': elem['tempPath'],
                                'size': elem['size'],
                                'name': this.filesInfo.fileNames[key]
                            }
                        });
                    }
                );
                this.$emit('upload-files', this.attachedfiles);
            }
        },
        clearAttachments(){
            this.loading =true;
            this.$refs.files.clearTags();
            this.$refs.files.clearFiles();
            this.loading =false;
        }
    }
}
</script>
<style lang="scss" scoped>
::v-deep .simple-box {
    padding-bottom: 0px;
}
</style>
