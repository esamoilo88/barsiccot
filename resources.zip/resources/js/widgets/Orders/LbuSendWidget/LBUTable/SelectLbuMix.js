export default {
    methods: {
        addLbuToSelectedList(lbuId) {
            if (this.selectedLbu.includes(lbuId)) return;
            this.selectedLbu.push(lbuId);
        },
        chooseAll() {
            if (this.isAllSelected) {
                this.allLbu.forEach(lbuId => {
                    this.addLbuToSelectedList(lbuId)
                });
            } else {
                this.allLbu.forEach(lbuId => {
                    this.removeLbuFromSelectedList(lbuId);
                });
            }
        },
        removeLbuFromSelectedList(lbuId) {
            this.selectedLbu = this.selectedLbu.filter(item => item !== lbuId);
        },
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        handleCheck(lbuId) {
            this.isLbuChecked(lbuId) ? this.addLbuToSelectedList(lbuId) : this.removeLbuFromSelectedList(lbuId);
            this.setAllSelected();
        },
        isAllLbuSelectedOnPage() {
            return this.selectedLbu.filter(lbuId => this.allLbu.includes(lbuId)).length === this.allLbu.length;
        },
        setAllSelected() {
            this.isAllSelected = this.isAllLbuSelectedOnPage() && this.items.length > 0;
        },
        isLbuChecked(lbuId) {
            return this.selectedLbu.lastIndexOf(lbuId) !== -1;
        }
    }
}
