export default {
    data() {
        return {
            statusOption: [],
            filterOption: [],
            fakturaList: [],
            leistungsList: [],
        }
    },
    computed: {
        filterList() {
            let fakturaList = this.fakturaList.filter((c, index) => this.fakturaList.indexOf(c) === index);
            let leistungsList = this.leistungsList.filter((c, index) => this.leistungsList.indexOf(c) === index);
            this.filterOption = [
                {
                    field: "fakturaMonat",
                    type: "select",
                    settings: {
                        preselected: 'alle',
                        label: "Fakturamonat",
                        options: [{id: "alle", text: "Alle"}, ...fakturaList]
                    }
                },
                {
                    field: "leistungsMonat",
                    type: "select",
                    settings: {
                        preselected: 'alle',
                        label: "Leistungsmonat",
                        options: [{id: "alle", text: "Alle"}, ...leistungsList]
                    }
                },
                {
                    field: "typ",
                    type: "select",
                    settings: {
                        preselected: 'alle',
                        label: "Vorgangstyp",
                        options: [
                            {id: "alle", text: "Alle"},
                            {id: "A1", text: "A1"},
                            {id: "A2", text: "A2"},
                            {id: "A3", text: "A3"}
                        ]
                    }
                }
            ];
            return this.filterOption;
        }
    },
    methods: {
        async listOfFakturaDate() {
            try {
                const response = await this.$axios.get(`/orders/lbu/multi-send/fakturaDate/list`);
                this.fakturaList = response.data.map(year => year.Fakturazeitraum);
                this.leistungsList = response.data.map(year => year.Leistungszeitraum);
                this.filterList.map((fltr) => {
                    let preselected = fltr.settings.preselected ?? false;
                    if (preselected) {
                        this.filtersApplied[fltr.field] = preselected;
                    }
                    return fltr;
                });
                this.$eventBus.$emit('send-lbu-list-ready');
            } catch (err) {
                console.log(err);
                return [];
            }
        }
    }
}
