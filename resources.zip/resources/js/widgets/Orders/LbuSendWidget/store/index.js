import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import sendLbuList from './modules/send_lbu_list.store';

const store = new Vuex.Store({
    modules: {
        sendLbuList
    }
});

store.$axios = $axios;

export default store;
