export default {
    namespaced: true,
    state: {
        filters: {
            representative: false,
            search: '',
            fakturaMonat: '',
            leistungsMonat: '',
            typ:'',
            group: false
        }
    },
    mutations: {
        SET_SEARCH(state, search) {
            state.filters.search = search;
        },
        SET_FAKTURA_MONAT(state, fakturaMonat) {
            state.filters.fakturaMonat = fakturaMonat;
        },
        SET_LEISTYNGS_MONAT(state, leistungsMonat) {
            state.filters.leistungsMonat = leistungsMonat;
        },
        SET_TYP(state, typ) {
            state.filters.typ = typ;
        },
        SET_HEADER_TAB(state, value) {
            state.filters.group = value === 2;
            state.filters.representative = state.filters.group === true ? null : !!value;
        }
    },
    actions: {

    },
    getters: {
        isInit(state) {
            //TODO later
            return true;
        }
    }
}
