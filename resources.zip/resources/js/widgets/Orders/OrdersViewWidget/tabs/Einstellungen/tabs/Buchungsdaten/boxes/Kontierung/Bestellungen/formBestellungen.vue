<template>
    <modal-dialog
        :is-visible="isModalVisible"
        @hideModal="hideModal"
        title-dialog="Bestellung hinzufügen"
        modal-class="modal-bestellung"
    >
        <div @keyup.enter="submit">
            <div class="mb-3">Bitte fülle alle mit * gekennzeichneten Felder aus.</div>

            <div class="simple-box">
                <div class="form-group">
                    <FormInput
                        v-model="form.orderNumber"
                        label-text="SAP Bestellnummer*"
                        :error-conditions="[...errorConditions.orderNumber, ...bestellnummerErrorConditions]"
                        name="bezeichnung"
                        input-id="bezeichnung"
                    />
                </div>
                <div class="form-group">
                    <FormInputAppend
                        v-model="form.budget"
                        input-id="budget"
                        name="budget"
                        label-text="Budget"
                        :error-conditions="errorConditions.budget"
                        prepended
                        prepend="€"
                    />
                </div>

                <div class="form-group">
                    <b-form-checkbox switch v-model="form.active">Aktiv</b-form-checkbox>
                </div>

                <div class="form-group">
                    <FormDatepicker
                        v-model="form.expire"
                        label-text="Beauftragungsende"
                        name="expire"
                        input-id="expire-input"
                        aria-controls="date-input"
                        :error-conditions="errorConditions.expire"
                    />
                </div>

                <b-overlay :show="filePending">
                    <div class="form-group">
                        <div>Bestellung hochladen*</div>
                        <FormFileLoad
                            v-model="form.filePath"
                            ref="file"
                            type="file"
                            browse-text="Auswählen"
                            @uploadFile="uploadFile"
                            placeholder="Datei auswählen / drag&drop"
                            accept=".doc,.docx,.pdf,.p7f,.msg"
                            :error-conditions="errorConditions.filePath"
                        />
                        <div class="text-muted">Valide Dateitypen: doc, docx, pdf, p7f, msg</div>
                    </div>
                </b-overlay>
            </div>
        </div>

        <template v-slot:footer>
            <button
                v-if="updateBestellung === null"
                :key="'store-bestellung-btn'"
                @click="submit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Bestellung erstellen
            </button>
            <button
                v-if="updateBestellung !== null"
                :key="'update-bestellung-btn'"
                @click="submit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Speichern
            </button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {mapActions, mapGetters, mapState} from "vuex";
import {BButton, BSpinner, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import {helpers, required, numeric} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormDatepicker from '@comp/FormDatepicker/FormDatepicker'
import {isDate} from 'res/js/utils/Validators/DatesValidators'
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import IcpBestellnummerValidationMxn from "@mixins/IcpBestellnummerValidation/IcpBestellnummerValidationMxn";
import FormFileLoad from "@comp/FileLoad/FormFileLoad";

const intorfloat = helpers.regex('intorfloat', /^\d+,?\d*$/);

export default {
    components: {
        FormInput, ModalDialog, BButton, BSpinner, FormDatepicker, BOverlay,
        BFormCheckbox, FormInputAppend, FormFileLoad
    },
    mixins: [Validation, ObjectsProcessing, DatesProcessing, IcpBestellnummerValidationMxn],
    props: {
        updateBestellung: {
            type: Object,
            required: false,
            default: null
        },
        hasPermissions: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'order/simpleId'
        }),
        errorConditions() {
            return {
                orderNumber: [
                    {
                        name: 'invalid-orderNumber-required',
                        condition: this.isInvalid('orderNumber', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'SAP Bestellnummer'})
                    },
                    {
                        name: 'orderNumber-integer',
                        condition: this.isInvalid('orderNumber', 'numeric'),
                        text: this.$t.__('validation.numeric', {attribute: 'SAP Bestellnummer'})
                    }
                ],
                expire: [
                    {
                        name: 'invalid-date',
                        condition: this.isInvalid('expire', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Beauftragungsende'})
                    }
                ],
                budget: [
                    {
                        name: 'invalid-budget-decimal',
                        condition: this.isInvalid('budget', 'intorfloat'),
                        text: this.$t.__('validation.not_regex', {attribute: 'Budget'})
                    }
                ],
                filePath: [
                    {
                        name: 'invalid-filePath-required',
                        condition: this.isInvalid('filePath', 'required'),
                        text: 'Lade die Datei hoch.'
                    },
                ]

            }
        }

    },
    data() {
        return {
            isModalVisible: false,
            onSubmitPending: false,
            form: {
                orderNumber: null,
                expire: null,
                budget: null,
                active: true,
                filePath: null
            },
            filePending: false
        }
    },

    methods: {
        ...mapActions({
            fetchOrderData: "order/fetchOrderData",
            fetchFinanceOrderData: 'order/fetchFinanceData'
        }),

        async showModal(item = null) {
            this.isModalVisible = true;
            this.resetBestellnummerErrors();
            if (item) {
                this.fillData(item);
            }
        },
        fillData(item) {
            this.form.orderNumber = item.orderNumber;
            this.form.active = item.active;
            this.form.expire = this.formatDate(item.expire, 'DD.MM.YYYY','');
            if (item.budget) {
                this.form.budget = this.$f.dotToComma(Number(item.budget));
            }
        },
        /**
         * Create Bestellung
         * @returns {void}
         */
        async onCreate() {
            try {
                const res = await this.$axios.post(`/orders/${this.simpleId}/einstellungen/bestellungsdaten`, this.form);
                this.hideModal();
                window.flash.showMessagesFromAjax(res.data);
            } catch (err) {
                console.error("Couldn't create Bestellung", err);
                throw err;
            } finally {
                this.onSubmitPending = false;
            }
        },

        /**
         * Update Bestellung
         * @returns {void}
         */
        async onUpdate() {
            try {
                const res = await this.$axios.put(`/orders/${this.simpleId}/einstellungen/bestellungsdaten/${this.updateBestellung.id}`,
                    {...this.form}
                );
                window.flash.showMessagesFromAjax(res.data);
                this.hideModal();
            } catch (err) {
                console.error("Couldn't update Bestellung", err);
                throw err;
            } finally {
                this.onSubmitPending = false;
            }
        },
        async submit() {
            this.$v.$touch();

            if (this.$v.$anyError) {
                this.showValidationErrors = true;
                navigateToFirstInvalid();
                return;
            }
            this.onSubmitPending = true;

            if (!await this.checkPermissions()) return;

            try {
                if (this.updateBestellung) {
                    await this.onUpdate();
                } else {
                    await this.onCreate();
                }
                window.preloader.show();
                await this.fetchFinanceOrderData(this.simpleId);
                window.preloader.hide();
            } catch (err) {
                if (err.response.data.errors) {
                    this.setBestellnummerErrors(err.response.data.errors.sapBestellnummer);
                    navigateToFirstInvalid();
                    delete err.response.data.errors;
                }
                window.flash.showMessagesFromAjax(err.response.data);
            }
        },
        hideModal() {
            this.clearForm();
            this.isModalVisible = false;
        },
        clearForm(item) {
            this.showValidationErrors = false;
            if(item === null){
                this.form = {
                    orderNumber: null,
                    expire: null,
                    budget: null,
                    active: true
                };
            }
        },
        async checkPermissions() {
            this.pending = true;
            await this.fetchOrderData(this.simpleId);

            if (!this.hasPermissions) {
                window.flash.error('Du hast keine Berechtigung auf diese Funktion.');
            }

            this.pending = false;

            return this.hasPermissions;
        },
        async uploadFile(file) {
            this.filePending = true;

            try {
                const response = await this.$axios.post(`/orders/${this.simpleId}/einstellungen/bestellungsdaten/${this.form.orderNumber}/file`, file.formData, file.config);

                this.form.filePath = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);

                this.$refs.file.clearFiles();
            }

            this.filePending = false;
        },
    },
    validations: {
        form: {
            orderNumber: {
                required,
                numeric
            },
            expire: {
                isDate
            },
            budget: {
                intorfloat
            },
            filePath: {required}
        }
    }

}
</script>
