<template>
    <div>
        <b-tabs
            @input="onTabSwitch"
            v-model="tabIndex"
            class="einstellungen-tabs simple-tabs vertical"
            pills
            vertical
            @changed="onTabChanged(tab)"
            nav-wrapper-class="settings-menu-wrapper col-xl-6 col-lg-7 col-md-24 col-sm-24">

            <b-tab id="grundeinstellungen-tab" active>
                <template #title>
                    <span class="icon-service-seettings-default px-1"></span>
                    <span class="text">Grundeinstellungen</span>
                </template>
                <div v-if="visitedTabs.includes(0)">
                    <Grundeinstellungen :is-accessible="isAccessible"/>
                </div>
            </b-tab>

            <b-tab id="buchungsdaten-tab">
                <template #title>
                    <span class="icon-content-wallet-default px-1"></span>
                    <span class="text">Buchungsdaten</span>
                </template>
                <div v-if="visitedTabs.includes(1)">
                    <Buchungsdaten :is-accessible="isAccessible" :is-writable="isWritable"/>
                </div>
            </b-tab>

            <b-tab id="versandeinstellungen-tab">
                <template #title>
                    <span class="icon-communication-email-default px-1"></span>
                    <span class="text">LBU Empfänger</span>
                    <span
                        v-if="isInvalidLbuRecipient"
                        class="icon-alert-warning-default warning-icon ml-auto"
                        title="Mindestens eine Mailadresse ist ungültig"
                        v-b-tooltip.hover
                    ></span>
                </template>
                <div v-if="visitedTabs.includes(2)">
                    <Versandeinstellungen
                        :simpleId="simpleId"
                        :is-accessible="isAccessible"
                        :is-writable="isWritable"
                        @update-data="getData"
                    />
                </div>
            </b-tab>

            <b-tab id="automatisierung-tab">
                <template #title>
                    <span class="icon-action-loop-default px-1"></span>
                    <span class="text">Automatisierung</span>
                </template>
                <div v-if="visitedTabs.includes(3)">
                    <Automatisierung/>
                </div>
            </b-tab>

            <b-tab id="kostenstellenzuordnung-tab">
                <template #title>
                    <span class="icon-content-flexible-features-selected px-1"></span>
                    <span class="text">Kostenstellenzuordnung</span>
                </template>
                <div v-if="visitedTabs.includes(4)">
                    <Kostenstellenzuordnung/>
                </div>
            </b-tab>

            <b-tab id="rabattierung-abschlage-tab">
                <template #title>
                    <span class="icon-content-voucher-default px-1"></span>
                    <span class="text">Rabattierung & Abschläge</span>
                </template>
                <div v-if="visitedTabs.includes(5)">
                    <RabattierungAbschlage :chk-rabatt ="chkRabatt" class="ml-3"/>
                </div>
            </b-tab>
        </b-tabs>
    </div>
</template>

<script>
import {BTabs, BTab, VBTooltip} from 'bootstrap-vue';
import Grundeinstellungen from "./tabs/Grundeinstellungen/Grundeinstellungen";
import Loading from "@comp/DynamicImportHelpers/Loading";
import {mapGetters} from 'vuex';
const Buchungsdaten = () => ({loading: Loading, component: import('./tabs/Buchungsdaten/Buchungsdaten')});
const Versandeinstellungen = () => ({loading: Loading, component: import('./tabs/Versandeinstellungen/Versandeinstellungen')});
const Automatisierung = () => ({loading: Loading, component: import('./tabs/Automatisierung/Automatisierung')});
const RabattierungAbschlage = () => ({loading: Loading, component: import('./tabs/RabattierungAbschlage/RabattierungAbschlage')});
const Kostenstellenzuordnung = () => ({loading: Loading, component: import('./tabs/Kostenstellenzuordnung/Kostenstellenzuordnung')});

export default {
    name: "Einstellungen",
    components: {
        Grundeinstellungen, Buchungsdaten, Versandeinstellungen, Automatisierung,
        RabattierungAbschlage, Kostenstellenzuordnung, BTabs, BTab
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    props:{
        tab: {
            type: Number,
            required: false,
            default: 0
        }
    },
    data() {
        return {
            isAccessible: false,
            isWritable: false,
            isInvalidLbuRecipient: false,
            visitedTabs: [],
            tabIndex: 1,
            chkRabatt: null
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId'
        })
    },
    async created() {
        this.getData();
    },
    methods: {
        onTabSwitch(tab) {
            if (!this.visitedTabs.includes(tab)) {
                this.visitedTabs.push(tab)
            }
        },
        onTabChanged(tab){
            this.tabIndex= tab;
            this.$emit('tab-switch');
        },
        async getData() {
            try {
                const res = await this.$axios.get(`/orders/${this.simpleId}/einstellungen`);
                this.isAccessible = res.data.accessibility.isAccessible;
                this.isWritable = res.data.accessibility.isWritable;
                this.isInvalidLbuRecipient = res.data.isInvalidLbuRecipient;
                this.chkRabatt = res.data.chkRabatt;
            } catch (err) {
                console.error('Couldn\'t fetch data regarding permissions of einstellungen tab');
                window.flash.showMessagesFromAjax(err.response.data);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .settings-menu-wrapper {
    background: #e7e7e7;
    padding: 10px;
    border-radius: 5px 0 0 5px;

    li.nav-item {
        padding: 7px 5px;
    }
}

::v-deep .tab-content {
    border-top: 1px solid lightgrey;
    border-right: 1px solid lightgrey;
    border-bottom: 1px solid lightgrey;
    border-radius: 0 5px 5px 0;
    padding: 20px;
}

.warning-icon {
    font-size: 16px !important;
    padding-bottom: 5px;
}

.einstellungen-tabs {
    min-height: 515px;
}
</style>
