<template>
    <modal-dialog
        modal-class="edit-kontierung-dialog"
        :is-visible="isVisible"
        @hideModal="$emit('close-dialog')"
        title-dialog="Systemregeln bearbeiten"
        size="lg"
        scrollable
    >
        <div class="mb-3">Bitte fülle alle mit* gekennzeichneten Felder aus.</div>
        <div class="simple-box">
            <h2> Zeitpunkte und Einstellungen </h2>
            <b-form-group>
                <b-form-radio-group
                    id="btn-radios-1"
                    v-model="selected"
                    :options="options"
                    name="radios-btn-default"
                    buttons
                    @input="clearInputField"
                ></b-form-radio-group>
            </b-form-group>

            <b-form-group>
                <b-form-checkbox
                    switch
                    v-model="form.systemGlobalAutoCreate"
                    class="font-weight-bold mb-2"
                >
                    LBU automatisch erstellen
                </b-form-checkbox>

                <div class="text-muted w-75 mt-2">
                    Die Erstellung der LBU und LBU-Positionen kann nicht auf einen spezifischen Tag festgelegt werden, sondern erfolgt wenn ein Auftrag/Ticket abgeschlossen wurde
                </div>
            </b-form-group>
            <b-form-group>
                <div class="d-flex mt-5 mb-3">
                    <div class="w-75 mr-25">
                        <b-form-checkbox
                            switch
                            v-model="form.systemGlobalAutoSendOrBill"
                            class="font-weight-bold mb-2"
                            @change="value => handleAutoSendOrBillChange(value)"
                        >
                            LBU automatisch weiterverarbeiten
                        </b-form-checkbox>

                        <div class="text-muted mb-2">
                            <div class="mb-2" v-if="!settingsData.autoApprove">
                                <span class="icon-communication-email-default mt-2"></span>
                                Zum angegeben Zeitpunkt wird die LBU versendet.
                            </div>
                            <div v-else>
                                <span class="icon-user_file-billing-default mt-2"></span>
                                Zum angegeben Zeitpunkt wird die LBU abgerechnet.
                            </div>
                        </div>
                    </div>
                    <div class="zeitpunkt_input">
                        <FormInputAppend
                            v-if="selected==='at'"
                            v-model="form.at"
                            class="font-weight-bold mb-2"
                            input-id="at-id"
                            label-text=""
                            name="at"
                            prepend="AT"
                            @change="value => handleSentAtChange(value)"
                            @input="handleSentAtInput"
                            :error-conditions="[
                         {
                            name: 'at-valid-numeric',
                            condition: !$v.form.at.minValue || !$v.form.at.maxValue || !$v.form.at.required && $v.form.at.$dirty,
                            text: $t.__('validation.between.numeric',{attribute: 'AT', min:1, max:15})
                        }
                    ]"
                        />
                        <FormInputAppend
                            v-if="selected==='ultimo'"
                            v-model="form.ultimo"
                            class="font-weight-bold"
                            input-id="ultimo-id"
                            label-text=""
                            name="ultimo"
                            prepend="U-"
                            @change="value => handleSentAtChange(value)"
                            @input="handleSentAtInput"
                            :error-conditions="[
                         {
                            name: 'ultimo-valid-numeric',
                            condition: !$v.form.ultimo.minValue || !$v.form.ultimo.maxValue || !$v.form.ultimo.required && $v.form.ultimo.$dirty,
                            text: $t.__('validation.between.numeric',{attribute: 'Ultimo',min:3,max:12})
                        }
                    ]"
                        />

                    </div>
                </div>
            </b-form-group>

            <b-form-group class="mt-4">
                <b-form-checkbox
                    switch
                    v-model="form.billAfterDeadline"
                    class="font-weight-bold"
                    @change="activateProcess"
                    :disabled="settingsData.autoApprove"
                >
                    Nach Fristablauf automatisch abrechnen
                </b-form-checkbox>
            </b-form-group>

            <div class="horizontal-line mb-4 mt-4"></div>
            <b-form-group>
                <b-form-checkbox
                    switch
                    v-model="form.systemGlobalAutoIlv"
                    class="font-weight-bold mb-2"
                    :disabled="settingsData.planIlv && settingsData.autoIlv"
                >
                    Kosten automatisch erstellen
                </b-form-checkbox>

                <div class="text-muted">
                    Die Erstellung der Kosten und ILV erfolgt kumuliert auf der Kostenart und Leistungsart.
                </div>
            </b-form-group>
        </div>
        <div class="simple-box mt-3">
            <h2>IT-Systeme auswahlen</h2>
            <b-form-group class="mt-2">
                <template v-for="item in quellSystemArray">
                    <div>
                        <b-form-checkbox
                            v-model="item.checked"
                            :key="item.quellsystem_id"
                            @change="value => addQuellSystem(value, item.quellsystem_id)"
                            switch
                        >
                            {{ item.bezeichnung }}
                        </b-form-checkbox>
                    </div>
                </template>
            </b-form-group>
        </div>
        <template #footer="{methods}">
            <button @click="onSubmit" class="btn btn-primary">
                <b-spinner v-if="pending" small></b-spinner>
                Speichern
            </button>
            <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInput from "@comp/FormInput/FormInput";
import {
    BFormCheckbox,
    BSpinner,
    BOverlay,
    BFormInput,
    BInputGroup,
    BInputGroupPrepend,
    BFormRadioGroup,
    BFormGroup
} from "bootstrap-vue";
import {mapGetters, mapActions} from "vuex";
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {maxValue, minValue, numeric, requiredIf} from 'vuelidate/lib/validators';
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {deepCopy} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    name: "edit-form",
    components: {
        ModalDialog,
        FormInputAppend,
        FormSelect,
        BFormCheckbox,
        BSpinner,
        BOverlay,
        FormInput,
        BFormInput,
        BInputGroup,
        BInputGroupPrepend,
        BFormRadioGroup,
        BFormGroup
    },
    mixins: [ObjectsProcessing],
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        quellSystems: {
            type: Array,
            default: () => {
                return []
            }
        },
        settingsData: {
            type: Object,
            default: () => {
                return {}
            }
        }
    },
    data() {
        return {
            form: {
                systemGlobalAutoCreate: false,
                systemGlobalAutoSendOrBill: false,
                billAfterDeadline: false,
                quellSystem: [],
                at: null,
                ultimo: null
            },
            quellSystemArray: [],
            selected: 'at',
            options: [
                {text: 'Zeitpunkte in Arbeitszeit', value: 'at'},
                {text: 'Zeitpunkte in Ultimo', value: 'ultimo'}
            ],
            pending: false,
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId',
            vkVersionId: 'order/currentVersion'
        }),
        isAutoSendOrBill () {
            return this.settingsData.systemGlobalAutoBill || this.settingsData.systemGlobalAutoSend
        }
    },
    created() {
        this.init();
        this.quellSystemArray = deepCopy(this.quellSystems);
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        clearInputField() {
            this.setDefaultSentAt();
        },
        async onSubmit() {
            this.onSubmitPending = true;
            if (!this.isValid()) {
                navigateToFirstInvalid();
            } else {
                try {
                    let res = await this.$axios.post(`/orders/${this.simpleId}/automatisierung/systemAutomation/update`, {
                        ...this.form
                    });
                    this.$emit('close-dialog');
                    this.$eventBus.$emit('get-settings');
                    window.flash.showMessagesFromAjax(res.data);
                } catch (err) {
                    console.error(`Couldn't update system automation`, err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            }
            this.onSubmitPending = false;
        },
        init() {
            this.form.systemGlobalAutoCreate = this.settingsData.systemGlobalAutoCreate;
            this.form.systemGlobalAutoSendOrBill = this.isAutoSendOrBill;
            this.form.systemGlobalAutoIlv = this.settingsData.systemGlobalAutoIlv;
            this.form.billAfterDeadline = this.settingsData.billAfterDeadline;
            this.setDefaultSentAt();
            this.setRadio();
            this.form.quellSystem = this.quellSystems
                .filter(s => s.checked)
                .map(field => field.quellsystem_id);
        },
        isValid() {
            this.showValidationErrors = false;
            this.$v.form.$touch();

            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;
                return false;
            }

            return true;

        },
        handleAutoSendOrBillChange(value) {
            if (value === false) {
                this.form.at = null;
                this.form.ultimo = null;
            }
        },
        handleSentAtChange(value) {
            this.form.systemGlobalAutoSendOrBill = value !== null && value !== '';
        },
        handleSentAtInput() {
            if (this.selected === 'at') {
                this.form.ultimo = null;
            } else {
                this.form.at = null;
            }
        },
        setDefaultSentAt() {
            let sentAt = this.settingsData.systemGlobalSendAt;
            let billAt = this.settingsData.systemGlobalBillAt;


            if ((sentAt === null && billAt === null) || this.isAutoSendOrBill === false) return;

            this.form.systemGlobalAutoSendOrBill = true;

            if (sentAt) {
                if (sentAt.indexOf('AT') !== -1) {
                    this.form.at = sentAt.replace('AT','');
                } else {
                    this.form.ultimo = sentAt.replace('U-','');
                }
            } else if (billAt) {
                if (billAt.indexOf('AT') !== -1) {
                    this.form.at = billAt.replace('AT','');
                } else {
                    this.form.ultimo = billAt.replace('U-','');
                }
            }
        },
        setRadio() {
            if (this.form.at === null && this.form.ultimo !== null) {
                this.selected = 'ultimo';
            } else {
                this.selected = 'at';
            }
        },
        addQuellSystem(value, id) {
            this.form.quellSystem = this.form.quellSystem.filter(item => item !== id);
            if (value === true) {
                this.form.quellSystem.push(id);
            }
        },
        activateProcess() {
            if (this.form.billAfterDeadline) {
                this.form.systemGlobalAutoCreate = true;
                this.form.systemGlobalAutoSendOrBill = true;
            }
        }
    },
    validations: {
        form: {
            at: {
                required: requiredIf(function () { return this.form.systemGlobalAutoSendOrBill === true && this.selected === 'at' }),
                numeric,
                maxValue: maxValue(15),
                minValue: minValue(1),
            },
            ultimo: {
                required: requiredIf(function () { return this.form.systemGlobalAutoSendOrBill === true && this.selected === 'ultimo'}),
                numeric,
                maxValue: maxValue(12),
                minValue: minValue(3)
            }
        }

    }

}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.edit-kontierung-dialog {
    .modal-dialog {
        max-width: 665px;
    }

    .text-muted {
        font-size: 1rem;
    }
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.lightgrey_background {
    background-color: $lightgrey;
    width: 40%;
    padding: 9px;
    border-top-left-radius: 0.25rem;
    border-bottom-left-radius: 0.25rem;
}

.nav-item.nav-link {
    color: gray;
    border: 1px grey solid;

    &:hover {
        background-color: gray;
        color: #ffff;
    }
}

.nav-item.nav-link__at {
    border-top-left-radius: 0.25rem;
    border-bottom-left-radius: 0.25rem;
}

.nav-item.nav-link__ultimo {
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
}

.zeitpunkt_input {
    width: 15%;
}
</style>
