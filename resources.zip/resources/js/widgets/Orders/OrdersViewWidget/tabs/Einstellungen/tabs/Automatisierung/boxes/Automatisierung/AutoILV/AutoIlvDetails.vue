<template>
    <b-overlay :show="pending">
        <template v-if="!pending">
            <div class="text-success" v-if="autoIlv">
                <i class="icon-action-succsess-default"></i>
                Auto-ILV aktiviert
            </div>
            <div v-else>
                Keine Auto-ILV aktiviert
            </div>
        </template>

        <div class="mt-5">
            <div v-for="item in data" class="mb-2">
                <div class="mb-1">
                    Kostenmonat {{ monthYearConcat(item) }}
                </div>
                <div class="text-muted mb-1 d-flex">
                    <div>
                        Erstellen: {{ item.createAt }}
                    </div>
                    <div class="mx-3">
                        {{ format(item.kostenwert, true) }}
                    </div>
                </div>
                <div class="mb-1">
                    <button class="btn btn-outline-secondary btn-sm" title="Auto-ILV löschen" v-if="hasPermissions" @click="remove(item)">
                        <i class="icon-action-remove-default"></i>
                    </button>

                    <button class="btn btn-link btn-sm" @click="showDetailsDialog(item)">Details</button>
                </div>
            </div>
        </div>

        <modal-dialog
            modal-class="auto-ilv-details-dialog"
            :is-visible="detailsDialog.item.showDetails"
            @hideModal="hideDetailsDialog"
            title-dialog="Auto-ILV Details"
            scrollable
            size="lg"
            close-button="Schließen"
        >
            <b-overlay :show="detailsDialog.item.detailsPending">
                <table class="table">
                    <tr>
                        <th>Kostenart</th>
                        <th>Kostenwert</th>
                        <th>Kostenstelle</th>
                    </tr>
                    <tr v-for="item in detailsDialog.item.details">
                        <td>{{ item.kostenart }}</td>
                        <td>{{ format(item.kostenwert, false) }}</td>
                        <td>{{ item.kostenstelle }}</td>
                    </tr>
                </table>
            </b-overlay>
        </modal-dialog>
    </b-overlay>
</template>

<script>
import {uniqObjs} from "@helpers/ValueProcessing/ObjectsProcessing";
import {monthYearConcat} from "@helpers/ValueProcessing/DatesProcessing";
import {BOverlay} from 'bootstrap-vue';
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import ModalDialog from "@comp/ModalDialog/ModalDialog";

export default {
    name: "AutoIlvDetails",
    components: {BOverlay, ModalDialog},
    mixins: [ConfirmationModal],
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        hasPermissions: {
            type: Boolean,
            default: false
        },
        autoIlv: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            data: [],
            pending: false,
            detailsDialog: {
                item: {
                    showDetails: false,
                    detailsPending: false,
                    details: []
                }
            }
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            if (this.hasPermissions === false) return;

            this.pending = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/auto-ilv`);

                this.data = uniqObjs(response.data);
            } catch (e) {
                console.log(e);
            }

            this.pending = false;
        },
        async refreshData() {
            await this.getData();
        },
        format(value, withCurrency = true) {
            return this.$f.numberToString(value, withCurrency, false, '0,00 €');
        },
        async showDetailsDialog(item) {
            this.detailsDialog.item.detailsPending = true;
            this.detailsDialog.item.showDetails = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/auto-ilv/${item.monat}/${item.jahr}`);

                this.detailsDialog.item.details = response.data;

                this.detailsDialog.item.detailsPending = false;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        hideDetailsDialog() {
            this.detailsDialog.item.showDetails = false;
            this.detailsDialog.item.details = [];
        },
        monthYearConcat(item) {
            return monthYearConcat(item.monat, item.jahr);
        },
        async remove(item) {
            const date = this.monthYearConcat(item);
            const kostenwert = this.format(item.kostenwert, true);

            const confirmed = await this.showConfirmationModal({
                title: 'Auto-ILV löschen',
                message: `Bitte bestätige die Löschung der Auto-ILV ${date} mit dem Betrag ${kostenwert}`,
                okTitle: 'Löschen',
            });

            if (!confirmed) return;

            this.pending = true;

            try {
                await this.$axios.post(`/orders/${this.simpleId}/auto-ilv/delete`, {
                    selected: [item.id]
                });

                this.$eventBus.$emit('get-settings');

                window.flash.success('Erfolgreich gelöscht.');

                await this.getData();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.btn-sm {
    line-height: 1;
}
.btn-link {
    color: $blue;
}
</style>
