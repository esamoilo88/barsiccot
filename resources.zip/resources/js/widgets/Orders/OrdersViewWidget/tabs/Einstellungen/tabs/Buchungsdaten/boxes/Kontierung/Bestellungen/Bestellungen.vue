<template>
    <div class="simple-box h-100">
        <div class="row align-items-center no-gutters mb-4">
            <div class="col label-text">
                Bestellung
            </div>

            <div class="col-auto" v-if="canCreateDeleteUpdate">
                <button class="btn btn-secondary" @click="showModal()">
                    <span class="icon-action-add-default"></span>
                    Bestellung hinzufügen
                </button>
            </div>
        </div>

        <div v-if="ordersData.length === 0" class="text-center text-muted">Keine Daten vorhanden</div>

        <ol class="list">
            <li v-for="item in ordersData" class="border-bottom py-3">
                <div>{{ item.orderNumber }}</div>
                <div class="text-muted py-1">
                <span>
                    {{ item.active ? 'Aktiv' : 'Inaktiv' }}
                </span>

                    <span class="px-3">
                    Budget:
                    {{ $f.numberToString(item.budget, false, true, '0,00') + ' €' }}
                </span>

                    <span>
                    Endet am:
                    {{ formatDate(item.expire, 'DD.MM.YYYY') }}
                </span>
                </div>
                <div class="text-nowrap">
                    <template v-if="canCreateDeleteUpdate">
                        <button class="btn btn-secondary btn-sm" title="Bestellung bearbeiten" @click="showModal(item)">
                            <span class="icon-action-edit-default"></span>
                        </button>
                        <button class="btn btn-secondary btn-sm" title="Bestellung löschen" @click="deleteBestellung(simpleId, item.id)">
                            <span class="icon-action-remove-default"></span>
                        </button>
                    </template>

                    <button v-if="canProceedMapping" class="btn btn-secondary btn-sm" @click="openMapping(item.id)">
                        <span class="icon-action-upload-default"></span>
                    </button>
                    <a class="btn btn-link btn-sm" title="Bestellpositionen hochladen" v-if="item.fileName" :href="`/orders/${simpleId}/einstellungen/bestellungsdaten/file/${item.fileName}/download`">
                        <span class="icon-action-download-default"></span>
                        Download
                    </a>
                </div>
            </li>
        </ol>

        <UploadBestellpositionenDialog
            :is-visible="isUploadFormVisible"
            @close-dialog="closeMapping"
            ref="mapping"
        />
        <form-bestellungen
            ref="bestellungenForm"
            :update-bestellung="updateBestellung"
            :has-permissions="canCreateDeleteUpdate"
        />
    </div>
</template>

<script>
import {BFormCheckbox, VBTooltip} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import {mapGetters, mapState} from "vuex";
import UploadBestellpositionenDialog from "../UploadBestellpositionenDialog";
import FormBestellungen from "./formBestellungen";
import RemoveBestellungMxn from "./RemoveBestellungMxn";

export default {
    components: {BFormCheckbox, ButtonIcon, FormBestellungen,UploadBestellpositionenDialog},
    mixins: [ScalarsProcessing, DatesProcessing, RemoveBestellungMxn],
    props: {
        ordersData: {
            type: Array,
            default: () => {
                return []
            }
        }
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    computed: {
        ...mapState({
            order: state => state.order.order,
        }),
        ...mapGetters({
            isBillingWritable: 'order/isBillingWritable',
            simpleId: 'order/simpleId'
        }),
        canProceedMapping() {
            return (this.order.user.isAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FLU')) && this.isBillingWritable
        },
        canCreateDeleteUpdate() {
            return this.isBillingWritable && (this.order.user.isAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FLU')
                || this.order.user.userRoles.includes('FFU')
            )
        },
    },
    data() {
        return {
            updateBestellung: null,
            isUploadFormVisible: false
        }
    },
    methods: {
        showModal(item = null) {
            this.updateBestellung = item;
            this.$refs.bestellungenForm.clearForm(item);
            this.$refs.bestellungenForm.showModal(item);
        },
        openMapping(financeOrderId) {
            this.$refs.mapping.init(financeOrderId);
            this.isUploadFormVisible = true;
        },
        closeMapping() {
            this.$refs.mapping.clear();
            this.isUploadFormVisible = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.text-small {
    font-size: 14px;
}

.text-large {
    font-size: 24px;
}

.btn-sm {
    line-height: 1;
}

.list {
    list-style-type: none;
    padding: 0;
}

.btn-link {
    color: $blue;
}
</style>
