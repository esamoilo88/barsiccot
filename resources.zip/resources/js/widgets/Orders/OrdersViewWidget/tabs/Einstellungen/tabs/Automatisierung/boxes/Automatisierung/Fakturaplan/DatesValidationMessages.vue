<template>
    <div v-if="validationCondition">
        <div class="invalid-feedback d-block" v-if="!autoApprove">
            Das Versanddatum darf nicht vor dem Erstelldatum liegen.
        </div>
        <div class="invalid-feedback d-block" v-else>
            Das Abrechnungsdatum darf nicht vor dem Erstelldatum liegen.
        </div>
    </div>
</template>
<script>
export default {
    props: {
        autoApprove: {
            required: true
        },
        validationCondition: {
            type: Boolean,
            required: false
        }

    }
}
</script>
