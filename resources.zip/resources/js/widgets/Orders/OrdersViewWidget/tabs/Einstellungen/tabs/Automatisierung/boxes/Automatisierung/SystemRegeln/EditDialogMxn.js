export default {
    data() {
        return {
            isEditFormVisible: false,
            dataToEdit: null
        }
    },
    methods: {
     async showEditDialog() {
            this.loading = true;
            await this.checkPermissionsForUpdate();
            if (this.isBilling) {
                this.isEditFormVisible = true;
            } else {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
            }
            this.loading = false;
        },
        hideEditDialog() {
            this.isEditFormVisible = false;
        }
    }
}
