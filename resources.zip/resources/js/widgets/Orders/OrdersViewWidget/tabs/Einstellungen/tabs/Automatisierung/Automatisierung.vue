<template>
    <div>
        <b-overlay :show="pending">
            <div class="row no-gutters">
                <div class="col-xl-12">
                    <GlobaleEinstellungen
                        :settings-data="settingsData"
                        :lbu-daten-quellsystem="lbuDatenQuellsystem"
                        :has-auto-ilv-created="hasAutoIlvCreated"
                    ></GlobaleEinstellungen>
                </div>

                <div class="col-xl-12 pl-xl-3">
                    <AutomatisierungBox
                        :settings-data="settingsData"
                        :lbu-daten-quellsystem="lbuDatenQuellsystem"
                        :has-auto-ilv-created="hasAutoIlvCreated"
                        :pending-settings-data="pending"
                    ></AutomatisierungBox>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import GlobaleEinstellungen from './boxes/GlobaleEinstellungen/Index';
import AutomatisierungBox from './boxes/Automatisierung/Index';
import {mapGetters} from "vuex";
import {BOverlay} from 'bootstrap-vue';
import TabHeader from "res/js/widgets/Orders/OrdersViewWidget/tabs/Einstellungen/tabs/TabHeader";

export default {
    name: "Automatisierung",
    components: {BOverlay, GlobaleEinstellungen, AutomatisierungBox, TabHeader},
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId'
        })
    },
    data() {
        return {
            settingsData: [],
            lbuDatenQuellsystem: [],
            hasAutoIlvCreated: false,
            pending: false,
        }
    },
    created(){
        this.$eventBus.$on('get-settings', this.getSettings);
    },
    beforeDestroy() {
        this.$eventBus.$off('get-settings', this.getSettings);
    },
    async mounted() {
        await this.getSettings();
    },
    methods: {
        async getSettings() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/automatisierung`);

                this.settingsData = response.data.settings;
                this.lbuDatenQuellsystem = response.data.lbuDatenQuellsystem;
                this.hasAutoIlvCreated = response.data.hasAutoIlvCreated;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        }
    }

}
</script>

<style scoped>

</style>
