<template>
    <modal-dialog
        modal-class="edit-kontierung-dialog"
        :is-visible="isVisible"
        @hideModal="hide"
        title-dialog="Buchungsdaten bearbeiten"
        size="lg"
        scrollable
    >
        <b-overlay :show="dataLoading">
            <div class="simple-box">
                <div class="mb-3">
                    <FormSelect
                        v-model="form.debitorId"
                        @change="val => setChangedField('debitorId', val)"
                        name="debitorIdInput"
                        :options="debitorOptions"
                        type="select"
                        select-id="debitorIdInput"
                        label-text="Debitor*"
                        :error-conditions="ec.debitorId"
                    />

                    <div class="text-muted p-1">
                        Mit dem Debitorenkonto wird der Kunde eingestellt der die Leistung erhalten hat und per Rechnung
                        bezahlen muss. Der Debitor legt auch die Partnergesellschaft sowie die Rechnungsanschrift fest.
                    </div>
                </div>

                <div class="mb-3">
                    <FormSelect
                        v-model="form.ansprechpartnerId"
                        @change="val => setChangedField('ansprechpartnerId', val)"
                        name="ansprechpartnerIdInput"
                        :options="ansprechpartnerRechnungOptions"
                        type="select"
                        select-id="ansprechpartnerIdInput"
                        label-text="Ansprechpartner Rechnung*"
                        :error-conditions="ec.ansprechpartnerId"
                    />
                    <div class="text-muted p-1">
                        Bei der Rechnungsart Vertragsfaktura wird der ausgewählte Ansprechpartner inklusive der
                        hinterlegten Telefonnummer auf den Rechnungskopf gedruckt. Bei Rückfragen zur Rechnung wird sich
                        der Auftraggeber oder die DTSE zuerst an die hier hinterlegte Person werden.
                    </div>
                </div>

                <div class="mb-3">
                    <FormInput
                        v-model="form.billingSubjectExtension"
                        label-text="Rechnungsbetreff Zusatz"
                        name="billingSubjectExtensionInput"
                        input-id="billingSubjectExtensionInput"
                        :error-conditions="ec.billingSubjectExtension"
                    />

                    <div class="text-muted p-1">
                        Wenn ein Rechnungszusatz eingetragen wird, so wird dieser an den Betreff der Rechnung angehangen
                        und ist im SAP auf dem Rechnungsbeleg sichtbar.
                    </div>
                </div>

                <div class="mb-3" v-if="isHardBilling">
                    <FormSelect
                        v-model="form.fakturaziel"
                        @change="val => setChangedField('fakturaziel', val)"
                        select-id="fakturaziel"
                        name="fakturaziel"
                        label-text="Fakturaziel"
                        :options="fakturazielOptions"
                    />
                    <div class="text-muted p-1">
                        <b>Bestellung</b>: Die Leistung wird auf eine SAP Bestellung sowie auf eine IC-P Bestellposition
                        (z.B. Positionsnummer aus der eBANF) gebucht. <br/> <b>Kontierungselement</b>: Speziell für
                        diesen Vertrag
                        wurde ein Kontierungselement angelegt auf welches die Leistungen gebucht werden sollen
                        (z.B. IC-P Sachkonto, PSP-Element (extern), Kostenstelle, etc).
                    </div>
                </div>

                <div class="mb-3">
                    <FormSelect
                        v-model="form.matNr"
                        @change="val => setChangedField('matNr', val)"
                        select-id="matnr"
                        name="matnr"
                        label-text="Materialnummer"
                        :options="matnrOptions"
                    />
                    <div class="text-muted p-1">
                        Die Materialnummer steuert ob die fakturierten Beträge als Umsatz oder in seltenen Fällen als
                        sonstige betriebliche Erträge (z.B. Kostenweiterberechnung) gebucht werden.
                    </div>
                </div>

                <div class="mb-3">
                    <FormSelect
                        v-model="form.icpSachkonto"
                        @change="val => setChangedField('icpSachkonto', val)"
                        select-id="kontierung-sachkonto"
                        name="kontierung-sachkonto"
                        label-text="IC-P Kontierung Sachkonto"
                        :options="icpSachkontoOptions"
                        searchable
                    />
                    <div class="text-muted p-1">
                        Das Sachkonto ist erforderlich sofern bei Fakturaziel Kontierungselement ausgewählt wurde. Für
                        die
                        einzelnen Partnergesellschaften sind entsprechende Sachkontos in SAP hinterlegt. Die
                        auswählbaren
                        Sachkonten wurden durch den Debitor vorgefiltert.
                    </div>
                </div>

                <div class="mb-3">
                    <FormInput
                        v-model="form.icpKontelement"
                        input-id="kontierung-element"
                        name="kontierung-element"
                        label-text="IC-P Kontierungselement"
                        :error-conditions="icpKontPspKstErrorConditions"
                    />
                    <span class="d-inline-block mt-2 ml-1 text-muted">
                        Das Kontierungselement ist erforderlich sofern bei Fakturaziel Kontierungselement ausgewählt wurde.
                        Angabe des Buchungsobjekts des Auftraggebers speziell für diesen Vertrag (PSP-Element (extern),
                        Projektkostenstelle, etc.).
                    </span>
                </div>
            </div>
        </b-overlay>

        <template #footer="{methods}">
            <button @click="onSubmit" class="btn btn-primary">
                <b-spinner v-if="pending" small></b-spinner>
                Speichern
            </button>
            <button @click="hide" class="btn btn-secondary">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInput from "@comp/FormInput/FormInput";
import {BFormCheckbox, BSpinner, BOverlay} from "bootstrap-vue";
import {mapGetters, mapActions} from "vuex";
import {createOptions} from "@helpers/Form/InputsHelper";
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import {getValue} from "@helpers/ValueProcessing/ObjectsProcessing";
import IcpBestellnummerValidationMxn from "@mixins/IcpBestellnummerValidation/IcpBestellnummerValidationMxn";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {maxLength, required} from "vuelidate/lib/validators";
import {Form} from './Form';

export default {
    name: "EditForm",
    components: {
        ModalDialog, FormSelect, BFormCheckbox, BSpinner, BOverlay, FormInput,
    },
    mixins: [ObjectsProcessing, IcpBestellnummerValidationMxn],
    props: {
        isHardBilling: {
            type: Boolean,
            required: true
        },
        cbiSinControl: {
            required: true
        },
        cbiUsePcs: {
            required: true
        },
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        formData: Form
    },
    data() {
        return {
            form: {
                fakturaziel: this.formData.fakturaziel,
                matNr: this.formData.matNr,
                icpSachkonto: this.formData.icpSachkonto,
                icpKontelement: this.formData.icpKontelement,
                debitorId: this.formData.debitorId,
                ansprechpartnerId: this.formData.ansprechpartnerId,
                billingSubjectExtension: this.formData.billingSubjectExtension,
            },
            changedData: {},
            fakturazielOptions: [],
            matnrOptions: [],
            icpSachkontoOptions: [],
            pending: false,
            dataLoading: false,
            debitorData: [],
            ansprechpartnerRechnungOptions: []
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId',
            vkVersionId: 'order/currentVersion'
        }),
        ec() {
            return {
                debitorId: [
                    {
                        name: 'debitorId-required',
                        condition: !this.$v.form.debitorId.required && this.$v.form.debitorId.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Debitor'})
                    }
                ],
                ansprechpartnerId: [
                    {
                        name: 'ansprechpartnerId-required',
                        condition: !this.$v.form.ansprechpartnerId.required && this.$v.form.ansprechpartnerId.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Ansprechpartner Rechnung'})
                    }
                ],
                billingSubjectExtension: [
                    {
                        name: 'billingSubjectExtension-max',
                        condition: !this.$v.form.billingSubjectExtension.maxLength && this.$v.form.billingSubjectExtension.$dirty,
                        text: 'Rechnungsbetreff Zusatz sollten nicht mehr als 150 Zeichen sein.'
                    }
                ],
            }
        },
        debitorOptions() {
            return this.debitorData.map(item => ({
                id: item.debitorId,
                text: `${item.nummer} - ${item.name} (${item.gesellschaftsnummer})`
            }));
        },
    },
    async created() {
        this.dataLoading = true;

        await this.init();
        await this.getDebitorData();
        await this.getAnsprechpartners();

        this.dataLoading = false;
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),

        /**
         * Confirm or decline action handler
         * @returns {Promise<void>}
         */
        async onSubmit() {
            this.$v.$touch();
            if (this.$v.$anyError) return;

            this.pending = true;
            this.dataLoading = true;

            try {
                const res = await this.$axios.post(`/orders/${this.simpleId}/einstellungen/kontierung`, this.form);

                await this.refreshOrderData(this.simpleId);

                this.$emit('updated');

                this.hide();

                window.flash.showMessagesFromAjax(res.data);
            } catch (err) {
                console.error(err);
                window.flash.showMessagesFromAjax(err.response.data);
                if (err.response.data.errors) {
                    this.setIcpKontPspKstErrors(err.response.data.errors.icpKontPspKst);
                    navigateToFirstInvalid();
                }
            } finally {
                this.pending = false;
                this.dataLoading = false;
            }
        },
        /**
         * Initialize form
         * @returns {Promise<void>}
         */
        async init() {
            this.resetIcpKontPspKstErrors();
            // fetch options for select inputs
            try {
                const res = await this.$axios.get(`/orders/${this.simpleId}/einstellungen/kontierung/dialog-data/1`);
                this.fakturazielOptions.push(...createOptions(
                    res.data.fakturaziel,
                    f => f.fakturazielId,
                    f => f.name,
                    null,
                    true
                ));
                this.matnrOptions.push(...createOptions(
                    res.data.matNr,
                    m => m.matNrId,
                    m => `${m.matNr} (${m.bezeichnung})`,
                    null,
                    true
                ));
                this.icpSachkontoOptions.push(...createOptions(
                    res.data.icpSachkonto,
                    k => k.kontoId,
                    k => `${k.sachkonto} (PG-Nr: ${k.partnergesellschaft})`,
                    null,
                    true
                ));
            } catch (err) {
                console.error("Couldn't fetch data for initializing the form");
                window.flash.showMessagesFromAjax(err.response.data);
            }
        },
        async getDebitorData() {
            try {
                const response = await this.$axios.get(`/debitor/${this.simpleId}/list`);

                this.debitorData = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async getAnsprechpartners() {
            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/ansprechpartners`);

                let ansprechpartner = response.data;
                this.ansprechpartnerRechnungOptions.push(...createOptions(
                    ansprechpartner, a => a.id,(a) => (a.group) ? a.group : a.fullName, null, false
                ));
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        hide() {
            this.$emit('close-dialog');
        },
        setChangedField(field, value) {
            this.$set(this.form, field, value);
        }
    },
    validations: {
        form: {
            debitorId: {required},
            ansprechpartnerId: {required},
            billingSubjectExtension: {maxLength: maxLength(150)}
        }
    }
}
</script>

<style lang="scss">
.edit-kontierung-dialog {
    .modal-dialog {
        max-width: 665px;
    }

    .text-muted {
        font-size: 1rem;
    }
}
</style>
