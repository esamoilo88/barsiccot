import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import Formatter from "res/js/utils/formatter";

export default {
    mixins: [ConfirmationModal],
    methods: {
        async deleteFakturaplan(simpleId, item, lbuList) {

            let lbuItem = lbuList.filter(el => el.lbuId === item.lbuId)[0];

            let budget = (new Formatter).numberToString(item.preisTP2, true, false, '0,00 €');
            const confirmed = await this.showConfirmationModal({
                title: 'Fakturaplan löschen',
                message: `Bitte bestätige die Löschung des Fakturaplans LBU/${item.lbuId} mit dem Betrag ${budget}.`,
                okTitle: 'Fakturaplan löschen',
            });

            if (!confirmed) return;

            try {
                await this.$axios.delete(`/orders/automatisierung/fakturaplan/${item.fakturaplanId}`);

                window.flash.success('Autofaktura LBU erfolgreich gelöscht');
                this.$eventBus.$emit('get-settings');

            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
        }
    }
}
