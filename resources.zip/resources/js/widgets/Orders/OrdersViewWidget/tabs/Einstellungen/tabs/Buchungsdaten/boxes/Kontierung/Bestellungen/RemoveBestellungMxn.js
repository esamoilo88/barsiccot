import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {mapActions} from "vuex";

export default {
    mixins: [ConfirmationModal],
    methods: {
        ...mapActions({
            fetchFinanceOrderData: 'order/fetchFinanceData'
        }),
        async deleteBestellung(simpleId,id) {
            const confirmed = await this.showConfirmationModal({
                title: 'Bestellung löschen',
                message: `Bitte bestätige die Löschung der Bestellung.`,
                okTitle: 'Bestellung löschen',
            });

            if (!confirmed) return;

            window.preloader.show();
            try {
                await this.$axios.delete(`/orders/${simpleId}/einstellungen/bestellungsdaten/${id}`);
                await this.fetchFinanceOrderData(simpleId);

                window.flash.success('Bestellung erfolgreich gelöscht');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
