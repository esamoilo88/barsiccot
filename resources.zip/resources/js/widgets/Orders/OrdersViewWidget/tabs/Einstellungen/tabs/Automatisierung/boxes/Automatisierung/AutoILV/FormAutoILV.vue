<template>
    <modal-dialog
        :is-visible="isModalVisible"
        @hideModal="hideModal"
        title-dialog="Auto-ILV Details"
        size="lg"
        modal-class="modal-fakturaplan"
        scrollable
    >
        <div>
            <div class="mb-3">
                Bitte fülle alle mit * gekennzeichneten Felder aus.
            </div>
            <div class="simple-box mt-3 mb-3">
                <b-overlay :show="pending">
                <FormSelect
                    v-model="form.date"
                    :options="kostenMonatList"
                    label-text="Basis Kostenmonat*"
                    name="date"
                    select-id="date"
                    :error-conditions="[
                     {
                        name: 'date-required',
                        condition: this.isInvalid('date', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Kostenmonat'})
                     }
                    ]"
                />
                </b-overlay>
            </div>
            <div class="simple-box">
                <h2> Zeitpunkte</h2>
                <b-form-group>
                    <b-form-radio-group
                        id="btn-radios-1"
                        v-model="selected"
                        :options="options"
                        name="radios-btn-default"
                        buttons
                    ></b-form-radio-group>
                </b-form-group>

                <b-form-group>
                        <div class="zeitpunkt_input">
                            <FormInputAppend
                                v-if="selected==='at'"
                                v-model="form.createAT"
                                class="font-weight-bold mb-2"
                                input-id="create-at-id"
                                label-text=""
                                name="at"
                                prepend="AT"
                                @input="handleCreateAtInput"
                                :error-conditions="[
                                     {
                                        name: 'createAT-valid-numeric',
                                        condition: !$v.form.createAT.minValue || !$v.form.createAT.maxValue || this.isInvalid('createAT', 'required') && $v.form.createAT.$dirty,
                                        text: $t.__('validation.between.numeric',{attribute: 'AT',min:1,max:15})
                                    }
                              ]"
                            />
                            <FormInputAppend
                                v-if="selected==='ultimo'"
                                v-model="form.createUltimo"
                                class="font-weight-bold"
                                input-id="create-ultimo-id"
                                label-text=""
                                name="ultimo"
                                prepend="U-"
                                @input="handleCreateAtInput"
                                :error-conditions="[
                                     {
                                        name: 'createUltimo-valid-numeric',
                                        condition: !$v.form.createUltimo.minValue || !$v.form.createUltimo.maxValue || this.isInvalid('createUltimo', 'required') && $v.form.createUltimo.$dirty,
                                        text: $t.__('validation.between.numeric',{attribute: 'U',min:3,max:12})
                                    }
                              ]"
                            />
                        </div>
                </b-form-group>
                <div class="mt-2 text-muted text-small">
                    Bitte bedenke, dass die ILV an U-3 nach SAP übertragen wird.
                </div>
                <div class="mt-3 text-muted text-small">
                    Beträge werden auf Basis der aktuell hinterlegten Preis- und ggf.Abschlagsdaten
                    neu berechnet. Der Leistungzeitpunkt wird auf den aktuellen Kalendermonat gesetzt.
                </div>
            </div>
        </div>

        <template v-slot:footer>
            <button
                :key="'store-auto-ilv-btn'"
                @click="submit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Speichern
            </button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {mapActions, mapGetters} from "vuex";
import {BButton, BFormGroup, BSpinner, BFormCheckbox, BFormRadioGroup, BFormRadio, BOverlay} from 'bootstrap-vue';
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormDatepicker from '@comp/FormDatepicker/FormDatepicker'
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import FormSelect from '@comp/FormSelect/FormSelect';
import {maxValue, minValue, numeric, requiredIf, required} from "vuelidate/lib/validators";
import Formatter from "res/js/utils/formatter";

export default {
    name: "FormAutoIlv",
    components: {
        BFormRadio, BOverlay,
        SimpleDropdown, BFormRadioGroup, FormSelect,
        ModalDialog, BButton, BFormGroup, BSpinner, FormDatepicker, BFormCheckbox, FormInputAppend
    },
    mixins: [Validation, ObjectsProcessing, DatesProcessing],
    props: {
        updateAutoIlv: {
            type: Object,
            required: false,
            default: null
        }
    },
    data() {
        return {
            form: {
                createAT: null,
                createUltimo: null,
                date: null
            },
            onSubmitPending: false,
            isModalVisible: false,
            selected: 'at',
            options: [
                {text: 'Zeitpunkte in Arbeitstagen', value: 'at'},
                {text: 'Zeitpunkte in Ultimo', value: 'ultimo'}
            ],
            pending: false,
            kostenMonatList: []
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId',
            vkVersionId: 'order/currentVersion'
        }),
        isValidationError() {
            return (this.form.createUltimo !== ''
                && this.form.ultimo !== ''
                && parseInt(this.form.createUltimo) < parseInt(this.form.ultimo))
                || (this.form.createAT !== ''
                && this.form.at !== ''
                && parseInt(this.form.createAT) > parseInt(this.form.at));
        },
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        handleCreateAtInput() {
            if (this.selected === 'at') {
                this.form.createUltimo = null;
            } else {
                this.form.createAT = null;
            }
        },
        setDefaultCreateAt(item) {
            let createAt = item.createAt;
            if (createAt === null) return;

            if (createAt.indexOf('AT') !== -1) {
                this.form.createAT = createAt.replace('AT', '');
                this.form.createUltimo = null;
            } else {
                this.form.createUltimo = createAt.replace('U-', '');
                this.form.createAT = null;
            }
        },
        setRadio() {
            if (this.form.createAT === null && this.form.createUltimo !== null) {
                this.selected = 'ultimo';
            } else {
                this.selected = 'at';
            }
        },
        async showModal() {
            this.isModalVisible = true;
            await this.getKostenmonatList();
        },
        async onCreate() {
            try {
                const res = await this.$axios.post(`/orders/${this.simpleId}/auto-ilv`, {
                    monthYear: this.form.date,
                    createAt: this.form.createAT ? 'AT' + this.form.createAT : 'U-' + this.form.createUltimo
                });
                this.$emit('created');
                this.$eventBus.$emit('get-settings');
                this.hideModal();
                window.flash.showMessagesFromAjax(res.data);
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
                console.error("Couldn't create Auto ILV", error);
            }
            this.onSubmitPending = false;
        },
        async submit() {
            this.onSubmitPending = true;
            const isValid = this.isValid();
            if (!isValid) {
                navigateToFirstInvalid();
                this.onSubmitPending = false;
            } else {
                await this.onCreate();
            }
        },
        isValid() {
            this.$v.form.$touch();

            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;
                return false;
            }

            return true;
        },
        hideModal() {
            this.clearForm();
            this.isModalVisible = false;
        },
        clearForm() {
            this.setRadio();
            this.showValidationErrors = false;
            this.form = {
                createAT: 11,
                createUltimo: null
            };
            this.$v.form.createUltimo.$reset();
            this.$v.form.date.$reset();
        },
        async getKostenmonatList() {
            this.pending = true;
            const res = await this.$axios.get(`/orders/${this.simpleId}/costs/auto-cost-dates`);
            this.kostenMonatList = res.data.map(date => ({
                id: date.kostenMonat + '.' + date.kostenJahr,
                text: date.kostenMonat + '.' + date.kostenJahr + ' - ' + (new Formatter).numberToString(date.betrag, true, false, '0,00 €')
            }));
            this.pending = false;
        }
    },
    validations: {
        form: {
            date: {required},
            createAT: {
                required: requiredIf(function () {
                    return this.selected === 'at'
                }),
                numeric,
                maxValue: maxValue(15),
                minValue: minValue(1),
            },
            createUltimo: {
                required: requiredIf(function () {
                    return this.selected === 'ultimo'
                }),
                numeric,
                maxValue: maxValue(12),
                minValue: minValue(3)
            },
        }

    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.nav-item.nav-link {
    color: gray;
    border: 1px grey solid;

    &:hover {
        color: #ffff;
        background-color: gray;
    }
}

.nav-item.nav-link__at {
    border-top-left-radius: 0.25rem;
    border-bottom-left-radius: 0.25rem;
}

.nav-item.nav-link__ultimo {
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
}

.zeitpunkt_input {
    width: 25%;
}
.text-small {
    font-size: 15px;
}
</style>

