<template>
    <div class="simple-box mb-3" id="globale-einstellungen-box">
        <b-overlay :show="loading">
            <div class="row align-items-center no-gutters mb-5">
                <div class="col label-text pr-3">
                    Globale Einstellungen
                </div>

                <div class="col-auto">
                    <button class="btn btn-primary" id="global-einstellung-save-btn" v-if="isEdit" @click="submit">
                        Speichern
                    </button>
                    <button
                        v-if="isEditFormWritable && !isEdit"
                        class="btn btn-outline-secondary"
                        id="global-einstellung-edit-btn"
                        title="Globale Einstellungen bearbeiten"
                        v-b-tooltip.hover
                        @click="showEditMode"
                    >
                        <i class="icon-action-edit-default"></i>
                    </button>
                </div>
            </div>

            <div>
                <b-form-checkbox
                    v-model="global.autoApprove"
                    switch
                    :disabled="autoApproveDisabled"
                >
                    Dauerfreigabe
                </b-form-checkbox>

                <p class="text-muted pt-1 text-small">Aktiviere diese Option um den Versandprozess LBU zu überspringen.
                    Diese Einstellung wirkt global auf alle LBU, egal wie diese automatisch oder manuell erstellt
                    wurden.</p>
            </div>

            <div>
                <b-form-checkbox
                    v-model="global.planIlv"
                    switch
                    @change="controlIlv('plan')"
                    :disabled="true"
                >
                    Plan-ILV
                </b-form-checkbox>

                <p class="text-muted pt-1 text-small">Aktiviere diese Option um die Verrechnung automatisch auf
                    Basis
                    der Faktura durchzuführen. Nutze ggf. die Zuordnung von Teamkostenstellen. Das Aktivieren der
                    Plan-ILV führt zur Sperrung aller weiteren ILV Optionen.</p>
            </div>

            <div>
                <b-form-checkbox
                    v-model="global.autoAbgrenzung"
                    switch
                    :disabled="!isEdit"
                >
                    Auto-Abgrenzung
                </b-form-checkbox>

                <p class="text-muted pt-1 text-small">Aktiviere diese Option um die Abgrenzung des jeweils aktuellen
                    Leistungsmonat auf Basis des Umsatzforecasts zu erstellen.</p>
            </div>

            <div>
                <b-form-checkbox
                    v-model="global.autoForecast"
                    switch
                    :disabled="!isEdit"
                >
                    Auto-Forecast (experimentell)
                </b-form-checkbox>

                <p class="text-muted pt-1 text-small">Aktiviere diese Option um den Umsatz- und Kostenforecast
                    automatisch über die Knime KI des Datawarehouse biTS ausfüllen zu lassen.</p>
            </div>

            <div>
                <b-form-checkbox
                    v-model="global.autoBill"
                    switch
                    :disabled="!isEdit"
                >
                    Automatische Abrechnung nach Fristablauf
                </b-form-checkbox>

                <p class="text-muted pt-1 text-small">
                    Aktiviere diese Option um eine LBU automatisch in den Status "Fakturabereit" zu bringen. Dies geschieht 5 Arbeitstage nach dem Versand oder, bei aktivierter Dauerfreigabe, der Erstellung der LBU.
                </p>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BFormCheckbox, BOverlay, VBTooltip} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {mapActions, mapGetters, mapState} from "vuex";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    components: {BFormCheckbox, ButtonIcon, BOverlay},
    mixins: [ConfirmationModal],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        settingsData: {
            type: Array,
            default: () => {
                return []
            }
        },
        hasAutoIlvCreated: {
            type: Boolean,
            default: () => {
                return true
            }
        }
    },
    computed: {
        global() {
            return this.settingsData.length ? this.settingsData[0] : {}
        },
        autoApproveDisabled() {
            if (this.isEdit) return this.order.auftrag.profitcenterSettings.isIksl || this.order.auftrag.profitcenterSettings.isIksl === null;
            return true;
        },
        ...mapState({
            order: state => state.order.order
        }),
        ...mapGetters({
            isBillingWritable: 'order/isBillingWritable',
            simpleId: 'order/simpleId'
        }),
        isEditFormWritable() {
            return this.isBillingWritable && (
                this.order.user.isAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FLU')
                || this.order.user.userRoles.includes('FFU')
            )
        }
    },
    data() {
        return {
            isBilling: false,
            loading: false,
            isEdit: false,
            isAutoIlvActive: false
        }
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        async showEditMode() {
            this.loading = true;
            await this.checkPermissionsForUpdate();
            if (this.isBilling) {
                this.isEdit = true;
            } else {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
            }
            this.loading = false;
            this.isAutoIlvActive = this.global.autoIlv;
        },
        async submit() {
            try {
                if (this.isAutoIlvActive && !this.global.autoIlv && this.hasAutoIlvCreated) {
                    const confirmed = await this.showConfirmationModal({
                        title: 'Auto-ILV deaktivieren',
                        message: 'Alle Auto-ILV Einstellungen werden gelöscht. Bist du sicher?',
                        okTitle: 'Deaktivieren',
                    });

                    if (!confirmed) {
                        this.isEdit = false;
                        this.$eventBus.$emit('get-settings');
                        return;
                    }
                }
                this.loading = true;
                const res = await this.$axios.post(`/orders/${this.simpleId}/automatisierung/globalEinstellung/update`, this.global);
                window.flash.showMessagesFromAjax(res.data);
                this.loading = false;
                this.isEdit = false;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
            this.$eventBus.$emit('get-settings');
            this.refreshOrderData(this.simpleId);
        },
        async checkPermissionsForUpdate() {
            try {
                const res = await this.$axios.get(`/orders/${this.simpleId}/automatisierung/globalEinstellung/check-permissions`);
                this.isBilling = res.data
            } catch (err) {
                console.error('Couldn\'t fetch data regarding permissions of einstellungen tab');
            }
        },
        controlIlv(ilvType) {
            if (ilvType === 'plan' && this.global.planIlv) {
                this.global.autoIlv = !this.global.planIlv
            }
            if (ilvType === 'auto' && this.global.autoIlv) {
                this.global.planIlv = !this.global.autoIlv
            }
         }
    }
}
</script>

<style lang="scss" scoped>
.text-small {
    font-size: 14px;
}
</style>
