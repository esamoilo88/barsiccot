<template>
    <div class="simple-box mb-3" id="auto-ilv-box">
        <div class="mb-3 d-flex justify-content-between align-items-center">
            <div>
                <div class="label-text">
                    Auto-ILV
                </div>
                <div class="text-muted text-small">
                    Mit der Auto-ILV kannst du bereits erstellte Kosten automatisch wiederholen lassen.
                </div>
            </div>
            <div>
                <button
                    class="btn btn-outline-secondary"
                    id="new-auto-ilv-btn"
                    @click="showAutoIlvModal()"
                    title="Auto-ILV hinzufügen"
                    v-b-tooltip.hover
                >
                    <i class="icon-action-add-default"></i>
                </button>
            </div>
        </div>

        <AutoIlvDetails
            ref="details"
            :simple-id="simpleId"
            :has-permissions="canCreateDelete"
            :auto-ilv="settingsData.autoIlv"
        />

        <FormAutoIlv
            ref="formAutoIlv"
            :update-auto-ilv="updateAutoIlv"
            :disabled="!canCreateDelete"
            @created="updateDetails"
        />
    </div>
</template>

<script>
import FormAutoIlv from "./FormAutoILV";
import {mapGetters, mapState} from "vuex";
import AutoIlvDetails from "./AutoIlvDetails";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {VBTooltip} from "bootstrap-vue";

export default {
    name: "AutoILV",
    components: {AutoIlvDetails, FormAutoIlv, ButtonIcon},
    props: {
        settingsData: {
            type: Object,
            default: () => {
                return {}
            }
        }
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            updateAutoIlv: null,
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order
        }),
        ...mapGetters({
            simpleId: 'order/simpleId',
            isBillingWritable: 'order/isBillingWritable'
        }),
        canCreateDelete() {
            return this.isBillingWritable && (
                this.order.user.isAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FIU')
            )
        }
    },
    methods: {
        showAutoIlvModal(item = null) {
            this.updateAutoIlv = item;
            this.$refs.formAutoIlv.clearForm(item);
            this.$refs.formAutoIlv.showModal(item);
        },
        updateDetails() {
            this.$refs.details.getData();
        }
    }
}
</script>

<style lang="scss" scoped>
.text-small {
    font-size: 14px;
}
.text-large {
    font-size: 24px;
}
</style>
