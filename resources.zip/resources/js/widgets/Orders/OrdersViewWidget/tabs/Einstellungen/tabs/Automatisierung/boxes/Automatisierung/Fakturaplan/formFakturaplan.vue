<template>
    <modal-dialog
        :is-visible="isModalVisible"
        @hideModal="hideModal"
        :title-dialog="updateFakturaPlan === null ? 'Fakturaplan hinzufügen' : 'Fakturaplan bearbeiten'"
        size="small"
        modal-class="modal-fakturaplan"
        scrollable
    >
        <div>
            <div class="mb-3">
                Bitte fülle alle mit * gekennzeichneten Felder aus.
            </div>
            <div class="simple-box mt-3 mb-3">
                <FormSelect
                    v-model="form.lbuId"
                    :options="lbuListOptions"
                    label-text="Basis LBU*"
                    name="lbu"
                    select-id="lbuId"
                    :error-conditions="[
                     {
                        name: 'lbuId-required',
                        condition: this.isInvalid('lbuId', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'LBU'})
                     }
                    ]"
                    class="mb-3"
                />
                <FormSelect
                    v-if="showFinanceOrder"
                    v-model="form.financeOrderId"
                    :options="financeOrderListOptions"
                    label-text="SAP Bestellnummer*"
                    name="financeOrder"
                    select-id="financeOrderId"
                    :error-conditions="[
                     {
                        name: 'financeOrderId-required',
                        condition: this.isInvalid('financeOrderId', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Bestellung'})
                     }
                    ]"
                />
            </div>
            <div class="simple-box">
                <h2> Zeitpunkte</h2>
                <b-form-group>
                    <b-form-radio-group
                        id="btn-radios-1"
                        class="mb-3"
                        v-model="selected"
                        :options="options"
                        name="radios-btn-default"
                        @input="clearInputField"
                    ></b-form-radio-group>
                </b-form-group>

                <b-form-group>
                    <div class="w-100">
                        <b-form-checkbox
                            switch
                            v-model="form.fakturaplanAutoCreate"
                            class="mb-2"
                            disabled
                        >
                            LBU automatisch erstellen
                        </b-form-checkbox>
                    </div>
                    <div class="zeitpunkt_input">
                        <FormInputAppend
                            v-if="selected==='at'"
                            v-model="form.createAT"
                            class="font-weight-bold"
                            input-id="create-at-id"
                            label-text="Arbeitstag"
                            name="at"
                            prepend="AT"
                            @input="handleCreateAtInput"
                            :error-conditions="[
                                     {
                                        name: 'createAT-valid-numeric',
                                        condition: !$v.form.createAT.minValue || !$v.form.createAT.maxValue || this.isInvalid('createAT', 'required') && $v.form.createAT.$dirty,
                                        text: $t.__('validation.between.numeric',{attribute: 'AT',min:1,max:15})
                                    }
                              ]"
                        />
                        <FormInputAppend
                            v-if="selected==='ultimo'"
                            v-model="form.createUltimo"
                            class="font-weight-bold"
                            input-id="create-ultimo-id"
                            label-text="Ultimo"
                            name="ultimo"
                            prepend="U-"
                            @input="handleCreateAtInput"
                            :error-conditions="[
                                     {
                                        name: 'createUltimo-valid-numeric',
                                        condition: !$v.form.createUltimo.minValue || !$v.form.createUltimo.maxValue || this.isInvalid('createUltimo', 'required') && $v.form.createUltimo.$dirty,
                                        text: $t.__('validation.between.numeric',{attribute: 'U',min:3,max:12})
                                    }
                              ]"
                        />
                    </div>
                </b-form-group>
                <b-form-group>
                    <div class="d-flex mt-5 mb-3">
                        <div class="w-100 mr-25">
                            <b-form-checkbox
                                :disabled="settingsData.autoApprove"
                                switch
                                v-model="form.fakturaplanAutoSend"
                                class="mb-2"
                                @change="value => handleAutoSendOrBillChange(value)"
                            >
                                LBU automatisch versenden
                            </b-form-checkbox>
                            <div v-if="settingsData.autoApprove" class="is_auto_approve_info">Der Versand kann nicht aktiviert werden da eine Dauerfreigabe eingerichtet ist.</div>
                            <b-form-group>
                                <FormSelect
                                    v-model="form.userId"
                                    v-if="form.fakturaplanAutoSend"
                                    select-id="absender_id"
                                    name="absender"
                                    label-text="Absender*"
                                    :options="absenderOptions"
                                    :error-conditions="[
                                        {
                                            name: 'empty-kostenart',
                                            condition: !$v.form.userId.required  && $v.form.userId.$dirty,
                                            text: $t.__('validation.required', {attribute: 'Absender'})
                                        },
                                    ]"
                                />
                            </b-form-group>
                        </div>
                    </div>
                </b-form-group>
            </div>
            <div class="simple-box mt-3">
                <h2>Monatsversatz</h2>
                <b-form-group class="mt-2">
                    <div class="mb-3">
                        <b-form-radio v-model="form.offsetPeriod" :value="0">Kein Versatz (periodengleich)
                        </b-form-radio>
                        <div class="text-muted pt-1">Der Leistungsmonat entspricht dem Fakturamonat.</div>
                    </div>
                    <div class="mb-3">
                        <b-form-radio v-model="form.offsetPeriod" :value="-1">Fakturamonat - 1</b-form-radio>
                        <div class="text-muted pt-1">Der Leistungsmonat entspricht dem Fakturamonat - 1.</div>
                    </div>
                </b-form-group>
            </div>
        </div>

        <template v-slot:footer>
            <button
                v-if="updateFakturaPlan === null"
                :key="'store-bestellung-btn'"
                @click="submit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Fakturaplan erstellen
            </button>
            <button
                v-if="updateFakturaPlan !== null"
                :key="'update-bestellung-btn'"
                @click="submit"
                class="btn btn-primary"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Fakturaplan bearbeiten
            </button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {mapActions, mapGetters} from "vuex";
import {BButton, BFormGroup, BSpinner, BFormCheckbox, BFormRadioGroup, BFormRadio} from 'bootstrap-vue';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormDatepicker from '@comp/FormDatepicker/FormDatepicker'
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import FormSelect from '@comp/FormSelect/FormSelect';
import {maxValue, minValue, numeric, requiredIf, required} from "vuelidate/lib/validators";
import Formatter from "res/js/utils/formatter";
import DatesValidationMessages from "./DatesValidationMessages";
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import Validation from '@mixins/Validation/Validation';
import {createOptions} from "@helpers/Form/InputsHelper";

export default {
    components: {
        PeopleSearch, DatesValidationMessages, BFormRadio,
        SimpleDropdown, BFormRadioGroup, FormSelect,
        ModalDialog, BButton, BFormGroup, BSpinner, FormDatepicker, BFormCheckbox, FormInputAppend
    },
    mixins: [Validation, ObjectsProcessing, DatesProcessing],
    props: {
        settingsData: {
            type: Object,
            default: () => {
                return {}
            }
        },
        lbuList: {
            type: Array,
            required: true
        },
        updateFakturaPlan: {
            type: Object,
            required: false,
            default: null
        },
        hasPermissions: {
            type: Boolean,
            default: false
        },
        financeOrderList: {
            type: Array,
            required: true
        },
        dauerfreigabe: {
            type: Boolean,
            default: false
        }
    },
    async mounted() {
        await this.getMembersGroupsList();
    },
    data() {
        return {
            form: {
                fakturaplanAutoCreate: true,
                fakturaplanAutoSend: false,
                billAfterDeadline: false,
                createAT: null,
                offsetPeriod: 0,
                createUltimo: null,
                financeOrderId: null,
                lbuId: null,
                userId: null,
            },
            absenderOptions: [],
            isBestellungLbu: false,
            onSubmitPending: false,
            isModalVisible: false,
            selected: 'at',
            options: [
                {text: 'Zeitpunkte in Arbeitstagen', value: 'at'},
                {text: 'Zeitpunkte in Ultimo', value: 'ultimo'}
            ],
            pending: false,
            baseLbuId: null,
            baseFinanceOrderId: null
        }
    },
    watch: {
        'form.lbuId': function (newVal, oldVal) {
            let lbuList = this.lbuList;
            let isBestellung = false;

            lbuList.map(lbu => {
                if (newVal == lbu.lbuId) {
                    isBestellung = lbu.fakturazielName === 'Bestellung'
                }
            })

            this.isBestellungLbu = isBestellung;
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'order/simpleId',
            vkVersionId: 'order/currentVersion'
        }),
        lbuListOptions() {
            return this.lbuList.map(lbu => ({
                id: lbu.lbuId,
                text: 'LBU/' + lbu.lbuId + ' - ' + lbu.fm + '/' + lbu.fy + ' - ' + lbu.lm + '/' + lbu.ly + ' - ' + (new Formatter).numberToString(lbu.betrag, true, false, '0,00 €')
            }));
        },
        financeOrderListOptions() {
            return this.financeOrderList.map(order => ({
                id: order.id,
                text: order.orderNumber + ' - ' + (new Formatter).numberToString(order.betrag, true, false, '0,00 €')
            }));
        },
        showFinanceOrder() {
            if (!this.form.lbuId) return false;

            let isBestellung = false;
            let baseLbu = {};
            let lbuList = this.lbuList;

            lbuList.map(lbu => {
                if (this.form.lbuId == lbu.lbuId) {
                    baseLbu = lbu;
                    isBestellung = lbu.fakturazielName === 'Bestellung'
                }
            })

            if (isBestellung && this.form.lbuId == this.baseLbuId && this.baseFinanceOrderId) {
                this.form.financeOrderId = this.baseFinanceOrderId;
                return isBestellung;
            }

            if (isBestellung) {
                let financeOrderList = this.financeOrderList;
                financeOrderList.map(order => {
                    if (order.orderNumber == baseLbu.sapBestellnummer && !this.isLbuNotChanged) {
                        this.form.financeOrderId = order.id;
                    }
                })
            }

            return isBestellung;
        },
        isLbuNotChanged() {
            if (this.updateFakturaPlan === null) return false;

            return this.baseLbuId == this.form.lbuId;
        }
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        clearInputField() {
            if (this.updateFakturaPlan) {
                this.setDefaultSentAt(this.updateFakturaPlan);
                this.setDefaultCreateAt(this.updateFakturaPlan);
            }
        },
        userAdded(user) {
            this.form.userId = user.user_id;
        },
        userDropped() {
            this.form.userId = null;
        },
        async getMembersGroupsList(value) {
            let response = {data: []};

            response = await this.$axios.get(`/members-groups-list/${this.simpleId}`, {
                    params: {
                        search: value,
                        roleNames: ['SM','FLU'],
                    }
                });
            console.log(response)

            this.absenderOptions.push(...createOptions(
                response.data,
                (e) => e.id,
                (e) => (e.group) ? e.group : e.fullName
            ));
        },
        isAutoSendOrBill(item) {
            return item.fakturaplanAutoSend
        },
        switchOffsetOption() {
            this.aeYourSelf = !this.aeYourSelf
            this.aeByEingangstor = !this.aeByEingangstor;
        },
        handleAutoSendOrBillChange(value) {
            if (value === false) {
                this.form.at = null;
                this.form.ultimo = null;
            }
            if(!this.settingsData.autoApprove){
                if (!this.form.fakturaplanAutoSend) {
                    this.form.billAfterDeadline = false;
                }
            }
        },
        handleSentAtChange(value) {
            this.form.fakturaplanAutoSend = value !== null && value !== '';
        },
        handleSentAtInput() {
            if (this.selected === 'at') {
                this.form.ultimo = null;
            } else {
                this.form.at = null;
            }
        },
        handleCreateAtInput() {
            if (this.selected === 'at') {
                this.form.createUltimo = null;
            } else {
                this.form.createAT = null;
            }
        },
        setDefaultSentAt(item) {
            let sentAt = item.fakturaplanSendAt;
            let billAt = item.fakturaplanBillAt;
            if ((sentAt === null && billAt === null) || this.isAutoSendOrBill === false) return;


            if (sentAt) {
                if (sentAt.indexOf('AT') !== -1) {
                    this.form.at = sentAt.replace('AT', '');
                    this.form.ultimo = null;
                } else {
                    this.form.ultimo = sentAt.replace('U-', '');
                    this.form.at = null;
                }
            } else if (billAt) {
                if (billAt.indexOf('AT') !== -1) {
                    this.form.at = billAt.replace('AT', '');
                    this.form.ultimo = null;
                } else {
                    this.form.ultimo = billAt.replace('U-', '');
                    this.form.at = null;
                }
            }
        },
        setDefaultCreateAt(item) {
            let createAt = item.fakturaplanCreateAt;
            if (createAt === null) return;

            if (createAt.indexOf('AT') !== -1) {
                this.form.createAT = createAt.replace('AT', '');
                this.form.createUltimo = null;
            } else {
                this.form.createUltimo = createAt.replace('U-', '');
                this.form.createAT = null;
            }
        },
        setRadio() {
            if (this.form.at === null && this.form.ultimo !== null || this.form.createAT === null && this.form.createUltimo !== null) {
                this.selected = 'ultimo';
            } else {
                this.selected = 'at';
            }
        },
        activateProcess() {
            if (this.form.billAfterDeadline) {
                this.form.fakturaplanAutoSend= true;
            }
        },
        async showModal(item = null) {
            this.isModalVisible = true;
            if (item) {
                this.fillData(item);
            }
        },
        fillData(item) {
            this.form.fakturaplanAutoCreate = item.fakturaplanAutoCreate;
            this.form.fakturaplanAutoSend = this.isAutoSendOrBill(item);
            this.form.billAfterDeadline = item.fakturaplanBillAfterDeadline;
            this.form.offsetPeriod = (item.fakturaplanOffsetPeriod) ? item.fakturaplanOffsetPeriod : 0;
            this.form.lbuId = item.lbuId;
            this.baseLbuId = item.lbuId;
            this.form.financeOrderId = item.financeOrderId;
            this.baseFinanceOrderId = item.financeOrderId;
            this.setDefaultSentAt(item);
            this.setDefaultCreateAt(item);
            this.setRadio();
        },
        /**
         * Create Fakturaplan
         * @returns {void}
         */
        async onCreate() {
            let result = false;

            try {
                const res = await this.$axios.post(`/orders/${this.simpleId}/automatisierung/fakturaplan/create`, this.form);
                this.hideModal();
                window.flash.showMessagesFromAjax(res.data);
                result = true;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
                console.error("Couldn't create Bestellung", error);
                result = false;
            }
            this.onSubmitPending = false;
            return result;
        },

        /**
         * Update Fakturaplan
         * @returns {void}
         */
        async onUpdate() {
            let result = false;

            try {
                const res = await this.$axios.put(`/orders/${this.simpleId}/automatisierung/fakturaplan/update/${this.updateFakturaPlan.fakturaplanId}`,
                    {...this.form}
                );
                window.flash.showMessagesFromAjax(res.data);
                this.hideModal();
                result = true;
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't update Fakturaplan", err);
                result = false;
            }
            this.onSubmitPending = false;
            return result;
        },
        async submit() {
            this.onSubmitPending = true;
            const isValid = this.isValid();
            if (!isValid) {
                console.log('isValid',isValid)
                navigateToFirstInvalid();
                this.onSubmitPending = false;
            } else {
                let res = false;
                if (this.updateFakturaPlan) {
                    res = await this.onUpdate();
                } else {
                    res = await this.onCreate();
                }
                if (res) {
                    this.$eventBus.$emit('get-settings');
                }
            }
        },
        isValid() {
            this.$v.form.$touch();

            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;
                return false;
            }

            return true;

        },
        hideModal() {
            this.clearForm();
            this.isModalVisible = false;
        },
        clearForm(item) {
            this.setRadio();
            this.showValidationErrors = false;
            if (item === null) {
                this.form = {
                    fakturaplanAutoCreate: true,
                    fakturaplanAutoSend: false,
                    billAfterDeadline: false,
                    createAT: null,
                    offsetPeriod: 0,
                    createUltimo: null,
                    at: null,
                    ultimo: null,
                };
            }
        }
    },
    validations: {
        form: {
            financeOrderId: {
                required: requiredIf(function () {
                    return this.isBestellungLbu;
                })
            },
            userId: {
                required: requiredIf(function () {
                    return this.form.fakturaplanAutoSend === true;
                })
            },
            lbuId: {required},
            createAT: {
                required: requiredIf(function () {
                    return this.selected === 'at'
                }),
                numeric,
                maxValue: maxValue(15),
                minValue: minValue(1),
            },
            createUltimo: {
                required: requiredIf(function () {
                    return this.selected === 'ultimo'
                }),
                numeric,
                maxValue: maxValue(12),
                minValue: minValue(3)
            },
        }

    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.nav-item.nav-link {
    color: gray;
    border: 1px grey solid;

    &:hover {
        background-color: gray;
        color: #ffff;
    }
}

.nav-item.nav-link__at {
    border-top-left-radius: 0.25rem;
    border-bottom-left-radius: 0.25rem;
}

.nav-item.nav-link__ultimo {
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
}

::v-deep .custom-control-inline {
    display: block;
}
::v-deep .custom-radio {
    margin-bottom: 5px;
}
.is_auto_approve_info{
    font-weight: bold;
    margin-left: 35px;
    font-style: italic;
}
</style>

