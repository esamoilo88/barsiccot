<template>
    <div>
        <div class="simple-box mb-3" id="fakturaplan-box">
            <div class="mb-3 d-flex justify-content-between align-items-center">
                <div>
                    <div class="label-text">
                        Fakturaplan
                    </div>
                    <div class="text-muted text-small">
                        Mit einem Fakturaplan kannst du bereits erstellte LBU automatisch wiederholen lassen.
                    </div>
                </div>

                <div v-if="canCreateDeleteUpdate">
                    <button
                        class="btn btn-outline-secondary"
                        id="new-fakturaplan-btn"
                        @click="showFakturaplanModal()"
                        :disabled="!lbuList.length"
                        title="Fakturaplan hinzufügen"
                        v-b-tooltip.hover
                    >
                        <i class="icon-action-add-default"></i>
                    </button>
                </div>
            </div>

            <template v-if="!pendingSettingsData">
                <div class="text-success" v-if="isActive">
                    <i class="icon-action-succsess-default"></i>
                    Fakturaplan aktiviert
                </div>

                <div v-else>
                    Kein Fakturaplan aktiviert
                </div>
            </template>

            <div class="mt-5" v-if="global.fakturaplanId">
                <div v-for="item in settingsData" v-if="item.lbuId" class="mb-2">
                    <div class="mb-1">{{ leadingZeros(item.lbuId) }}</div>
                    <div class="text-muted mb-1 d-flex">
                        <div class="pr-3">
                            Erstellen: {{ item.fakturaplanCreateAt }}
                        </div>
                        <div class="pr-3" v-if="item.fakturaplanAutoSend">
                            Inklusive Versand
                        </div>
                        <div class="pr-3 text-nowrap">
                            {{ formatNumber(item.preisTP2) }}
                        </div>
                        <div>
                            Versatz: {{ item.fakturaplanOffsetPeriod }}
                        </div>
                    </div>

                    <div v-if="canCreateDeleteUpdate">
                        <button class="btn btn-outline-secondary btn-sm" title="Fakturaplan bearbeiten" @click="showFakturaplanModal(item)">
                            <i class="icon-action-edit-default"></i>
                        </button>
                        <button class="btn btn-outline-secondary btn-sm" title="Fakturaplan löschen" @click="deleteFakturaplan(simpleId,item, lbuList)">
                            <i class="icon-action-remove-default"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <AutoILV :settings-data="global" />

        <FakturaPlanDialog
            ref="fakturaPlanForm"
            :update-faktura-plan="updateFakturaPlan"
            :lbu-list="lbuList"
            :finance-order-list="financeOrderList"
            :has-permissions="canCreateDeleteUpdate"
            :settings-data="global"
            :dauerfreigabe="order.auftrag.dauerfreigabe"
        />
    </div>
</template>

<script>
import {BFormCheckbox, VBTooltip} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {mapGetters, mapState} from "vuex";
import FakturaPlanDialog from "./Fakturaplan/formFakturaplan"
import RemoveFakturaplanMxn from "./Fakturaplan/RemoveFakturaplanMxn";
import AutoILV from "./AutoILV/AutoILV";
import {leadingZeros} from "@helpers/ValueProcessing/ValueProcessing";

export default {
    components: {AutoILV, BFormCheckbox, ButtonIcon, FakturaPlanDialog},
    mixins: [RemoveFakturaplanMxn],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        settingsData: {
            type: Array,
            default: () => {
                return []
            }
        },
        lbuDatenQuellsystem: {
            type: Array,
            default: () => {
                return []
            }
        },
        pendingSettingsData: {
            type: Boolean,
            default: false
        }
    },
    async created() {
        await this.lbuListData();
    },
    data(){
        return{
            updateFakturaPlan: null,
            lbuList: [],
            financeOrderList: []
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order
        }),
        ...mapGetters({
            simpleId: 'order/simpleId',
            isBillingWritable: 'order/isBillingWritable'
        }),
        global() {
            return this.settingsData.length ? this.settingsData[0] : {}
        },
        canCreateDeleteUpdate() {
            return this.isBillingWritable && (
                this.order.user.isAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FLU')
                || this.order.user.userRoles.includes('FIU')
            )
        },
        isActive() {
            return this.settingsData.filter(item => item.lbuId && item.fakturaplanAutoCreate).length;
        }
    },
    methods: {
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                true,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
        showFakturaplanModal(item = null) {
            this.updateFakturaPlan = item;
            this.$refs.fakturaPlanForm.clearForm(item);
            this.$refs.fakturaPlanForm.showModal(item);
        },
        async checkPermissionsForUpdate() {
            try {
                const res = await this.$axios.get(`/orders/${this.simpleId}/automatisierung/globalEinstellung/check-permissions`);
                this.isBilling = res.data
            } catch (err) {
                console.error('Couldn\'t fetch data regarding permissions of einstellungen tab');
                window.flash.showMessagesFromAjax(err.response.data);
            }
        },
        getKey(item, extra = null) {
            let key = `${item.lbuId}_${item.automationFakturaplanId}`;

            if (extra) {
                key = `${key}_${extra}`;
            }

            return key;
        },
        async lbuListData() {
            this.pending = true;
            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/automatisierung/fakturaplan/lbu/list`);
                this.lbuList = response.data.lbuList;
                this.financeOrderList = response.data.financeOrderList;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
            this.pending = false;
        },
        leadingZeros(id) {
            return leadingZeros(id, 9, 'LBU');
        }
    }
}
</script>

<style lang="scss" scoped>
.text-small {
    font-size: 14px;
}
.text-large {
    font-size: 24px;
}
.btn-sm {
    line-height: 1;
}
</style>
