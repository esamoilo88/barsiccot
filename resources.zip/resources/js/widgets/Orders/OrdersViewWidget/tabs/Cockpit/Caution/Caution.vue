<template>
    <div class="simple-box mb-4">
        <h2 class="mb-4">Meldungen</h2>
        <b-overlay :show="loading">
            <div v-if="!loading">
                <div class="mb-3 border-bottom row pb-3">
                    <div v-if="hasWarnings" class="col-md-12 col-lg-12 pl-0">
                        <span class="icon-alert-warning-default text-danger"></span>
                        <span :class="colorText">{{ title }}</span>
                    </div>
                    <div v-else class="col-md-12 col-lg-12 pl-0">
                        <span class="icon-action-succsess-default text-success"></span>
                        <span :class="colorText">{{ title }}</span>
                    </div>
                    <div class="col-md-6 col-lg-6 pl-0">
                        <a href="#" @click="toggleVisibility(true)"> <span
                            class="icon-content-clipboard-default px-1 info"></span>
                            Prüfpunkte
                        </a>
                    </div>
                    <div class="col-md-6 col-lg-6 pl-0">
                        <a href="#" @click="openEinstellungenTab"> <span
                            class="icon-service-seettings-default info"></span>
                            Einstellungen
                        </a>
                    </div>
                </div>
                <div v-if="ifWarnings">
                    <div v-if="laufzeiten.remainingMonths < 3" class="w-100 text-sm-left p-lg-2 mb-2">
                        <span class="icon-alert-error-default text-danger"></span>
                        <span class="text-danger">Der Vertrag läuft in {{ laufzeiten.remainingDays }} Tagen aus.</span>
                    </div>
                    <div v-if="overbookedAPs.length > 0" class="w-100 text-sm-left p-lg-2 mb-2">
                        <span class="icon-alert-error-default text-danger"></span>
                        <span class="text-danger">Die Angebotsposition(en) {{
                                overbookedAPs
                            }} wurden bereits überbucht.</span>
                    </div>
                    <div v-if="order.isDiffUmsatz" class="w-100 text-sm-left p-lg-2 mb-2">
                        <span class="icon-alert-error-default text-danger"></span>
                        <span class="text-danger">Die Abweichung zwischen aktuellem Forecast und tatsächlichem Umsatz ist sehr hoch. Bitte überprüfe den Forecast.</span>
                    </div>
                    <div v-if="order.amountOfPastLbus >0" class="w-100 text-sm-left p-lg-2 mb-2">
                        <span class="icon-alert-error-default text-danger"></span>
                        <span class="text-danger">{{ pastLbuText }}</span>
                    </div>
                </div>
            </div>
        </b-overlay>
        <modal-dialog
            modal-class="modal-checkpoints"
            :is-visible="isVisible"
            @hideModal="toggleVisibility(false)"
            :title-dialog="title"
            close-button="Schließen"
        >
            <div class="simple-box">
                <div v-for="point in checkpoints" :key="point.text" class="d-flex align-items-center mb-2">
                    <img
                        class="icon mr-2"
                        :src="getIcon(point.value)"
                        :alt="point.value ? 'confirm' : 'warning'"
                        width="32px"
                    />
                    <span>{{ point.text }}</span>
                </div>
            </div>
        </modal-dialog>
    </div>
</template>
<script>
import {mapGetters} from "vuex";
import computeOverdueAps from "../computeOverdueAps";
import {BOverlay} from 'bootstrap-vue';
import ModalDialog from '@comp/ModalDialog/ModalDialog';

export default {
    name: "Caution",
    mixins: [computeOverdueAps],
    components: {BOverlay, ModalDialog},
    props: {
        simpleId: {
            required: true
        },
        order: {
            type: Object,
            required: true
        }
    },
    computed: {
        ...mapGetters({
            laufzeiten: 'forecast/laufzeiten'
        }),
        hasWarnings() {
            if (this.checkpoints.length) {
                return this.checkpoints.filter(item => !item.value).length
            }
            return true;
        },
        colorText() {
            return this.hasWarnings ? "text-danger" : "text-success";
        },
        title() {
            return this.hasWarnings ? 'Vertrag nicht fakturabereit' : 'Vertrag fakturabereit'
        },
        ifWarnings() {
            return this.laufzeiten.remainingMonths < 3 || this.overbookedAPs.length > 0 || this.order.isDiffUmsatz || this.order.amountOfPastLbus > 0;
        },
        pastLbuText() {
            return this.order.amountOfPastLbus > 1 ? 'Es sind ' + this.order.amountOfPastLbus + ' LBU aus Vormonaten vorhanden' : 'Es ist 1 LBU aus Vormonaten vorhanden.'

        }
    },
    async mounted() {
        await this.getCheckpoints();
    },
    data() {
        return {
            loading: false,
            overBookedApNames: [],
            checkpoints: [],
            isVisible: false
        }
    },
    methods: {
        async getCheckpoints() {
            this.loading = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/checkpoints`);

                this.checkpoints = response.data
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        },
        toggleVisibility(isVisible) {
            this.isVisible = isVisible;
        },

        openEinstellungenTab() {
            this.$eventBus.$emit('einstellungenShow');
        },
        getIcon(value) {
            let icon = 'warning_graphical';

            if (value) {
                icon = 'confirm_graphical';
            }

            return `/img/icons/${icon}.svg`;
        },
    }
}
</script>
<style lang="scss" scoped>
.left-box {
    border-right: 2px solid #dee2e6;
}

.simple-box {
    height: 350px;
    overflow: auto;
}
</style>
