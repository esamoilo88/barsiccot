<template>
    <div class="pt-3">
        <b-overlay :show="pending">
            <div class="row">
                <div class="col-12">
                    <canvas id="pieUmsatzChart" width="400" height="200"></canvas>
                </div>
                <div class="col-12">
                    <canvas id="pieKostenChart" width="400" height="200"></canvas>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import Chart from "chart.js";
import {BOverlay} from "bootstrap-vue";

export default {
    components: {BOverlay},
    props: {
        simpleId: {
            required: true
        }
    },
    data() {
        return {
            pending: false,
            data: [],
        }
    },
    async mounted() {
        await this.getData();

        this.build();
    },
    methods: {
        async getData() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/finance/charts/pie`);

                this.data = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        build() {
            this.buildUmsatzChart();
            this.buildKostenChart();
        },
        buildUmsatzChart() {
            const ctx = document.getElementById('pieUmsatzChart');

            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Erlöse', 'Offenes Volumen'],
                    datasets: [
                        {
                            data: [this.data.umsatz.total, this.data.umsatz.offene],
                            backgroundColor: ['#007bff', '#fd7e14'],
                        },
                    ],
                },
                options: {
                    tooltips: {
                        callbacks: {
                            label: (tooltipItem, data) => {
                                const value = data['datasets'][0]['data'][tooltipItem['index']];

                                return this.$f.numberToString(value, true, true)
                            },
                        }
                    },
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Umsatz'
                    },
                    maintainAspectRatio: false,
                }
            });
        },
        buildKostenChart() {
            const ctx = document.getElementById('pieKostenChart');

            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['IST-Kosten', 'Offene Kosten'],
                    datasets: [
                        {
                            data: [this.data.kosten.total, this.data.kosten.offene],
                            backgroundColor: ['#007bff', '#fd7e14'],
                        },
                    ],
                },
                options: {
                    tooltips: {
                        callbacks: {
                            label: (tooltipItem, data) => {
                                const value = data['datasets'][0]['data'][tooltipItem['index']];

                                return this.$f.numberToString(value, true, true)
                            },
                        }
                    },
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Kosten'
                    },
                    maintainAspectRatio: false,
                }
            });
        }
    }
}
</script>
