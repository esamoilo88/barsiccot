<template>
    <div class="simple-box mb-4">
        <h2 class="mb-4">Finanzverlauf</h2>

        <b-overlay :show="pending" class="mb-4">
            <canvas id="lineChart" width="400" height="212"></canvas>
        </b-overlay>

        <span v-if="!pending" class="text-muted">Vertragslaufzeit: {{data.start}} - {{data.end}} </span>
    </div>
</template>

<script>
import Chart from "chart.js/auto";
import {BOverlay} from "bootstrap-vue";

export default {
    components: {BOverlay},
    props: {
        simpleId: {
            required: true
        }
    },
    data() {
        return {
            pending: false,
            data: [],
        }
    },
    async mounted() {
        await this.getData();

        this.build();
    },
    methods: {
        async getData() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/orders/${this.simpleId}/finance/charts/line`);

                this.data = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        build() {
            const ctx = document.getElementById('lineChart');

            let labels = [];
            let umsatz = [];
            let kosten = [];

            this.data.result.map(item => {
                labels.push(item.month);
                umsatz.push(item.umsatz);
                kosten.push(item.kosten);
            });

            const skipped = (ctx, value) =>  ctx.p0.parsed.x >= this.data.futureIndex[0] ? value : undefined;
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Umsatz',
                            data: umsatz,
                            borderColor: '#4AAA06',
                            fill: false,
                            segment: {
                                borderDash: ctx => skipped(ctx, [6, 6]),
                            },
                            spanGaps: true
                        },
                        {
                            label: 'Kosten',
                            data: kosten,
                            borderColor: '#DD3B4A',
                            fill: false,
                            segment: {
                                borderDash: ctx => skipped(ctx, [6, 6]),
                            },
                            spanGaps: true
                        }
                    ]
                },
                options: {
                    tooltips: {
                        callbacks: {
                            title: (tooltipItem, data) => {
                                return `${data['datasets'][tooltipItem[0].datasetIndex].label} (${tooltipItem[0].label})`;
                            },
                            label: (tooltipItem) => {
                                return this.$f.numberToString(tooltipItem.value, true, true)
                            },
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                    },
                    elements: {
                        line: {
                            tension: 0
                        }
                    },
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            ticks: {
                                // forces step size to be 50 units
                                stepSize: 1000
                            }
                        }
                    }
                }
            });
        }
    }
}
</script>
<style lang="scss" scoped>
.simple-box {
    height: 350px;
    overflow:auto;
}
</style>
