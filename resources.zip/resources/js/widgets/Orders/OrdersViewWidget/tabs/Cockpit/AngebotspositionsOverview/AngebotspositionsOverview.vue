<template>
    <div class="simple-box mt-4" v-if="true">
        <h2 class="mb-4">Abrechnungsquote</h2>
        <b-overlay :show="pending">
        <table id="product-billung-ratio" class="table-sm w-100">
            <thead>
            <tr>
                <th>Angebotsposition</th>
                <th>Soll-Menge</th>
                <th>Ist-Menge</th>
                <th>Fortschritt</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="row in billedAps" :key="row.angebotspositionId"
                class="border-top">
                <td>{{ row.bezeichnung }}</td>
                <td>{{ row.menge }}</td>
                <td>{{ $f.removeTrailingZerosFromDB(row.billMenge) }}</td>
                <td :class="totalDiffClass(row)">
                    <CircleChart
                        :value="progress(row)"
                        :color="totalDiffClass(row)"
                        size="xsmall"
                        :step="1"
                    />
                </td>
            </tr>
            </tbody>
        </table>
        </b-overlay>

        <button
            v-if="billedAps.length <= 3 && !isAllAps "
            class="btn btn-link p-0 float-left mb-2"
            @click="showAllAps"
        >
            Weitere Daten anzeigen
        </button>

    </div>
</template>
<script>

import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import TableSimple from '@comp/TableSimple/TableSimple';
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {BTooltip, BOverlay} from "bootstrap-vue";
import computeOverdueAps from "../computeOverdueAps";
import CircleChart from "@comp/CircleChart/CircleChart";

export default {
    name: "AngebotspositionsOverview",
    mixins: [ScalarsProcessing, computeOverdueAps],
    components: {ButtonIcon, BTooltip, TableSimple, CircleChart, BOverlay},
    props: {
        simpleId: {
            required: true
        },
        order: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            pending: false,
            apData: [],
            isAllAps: false
        }
    },
    methods: {
        async showAllAps() {
            this.pending = true;
            try {
                this.isAllAps = !this.isAllAps;
                const response = await this.$axios.get('/orders/' + this.simpleId + '/get-all-billed-aps');
                this.order.amountOfBilledAPs = response.data;
            } catch (err) {
                window.flash.show({text: 'Couldn\'t get billed aps', type: 'error'});
            }
            this.pending = false;
        }
    }
}
</script>
<style lang="scss" scoped>
.years-sum-header {
    border-bottom: 1px solid lightgrey;
}

#forecast-jahresummen-table {
    width: 100%;
}

.simple-box {
    height: 350px;
    overflow:auto;
}
</style>
