<template>
    <div class="simple-box">
        <h2 class="mb-4">Weitere Finanzdaten</h2>
        <div class="finance-data row" v-cloak>
            <div class="finance-left col-md-12 col-lg-12 pl-0">
                <span class="text-uppercase font-weight-bold mb-1">Aktueller Umsatz</span>
                <div>{{ defVal(formatNumber(order.headerData.newestRevenue), '-') }} €</div>
                <div class="mb-3 text-muted">{{ order.headerData.newestRevenuePeriod }}</div>

                <span class="text-uppercase font-weight-bold mb-1">Aktuelle Kosten</span>
                <div> {{ defVal(formatNumber(order.headerData.newestCosts), '-') }} €</div>
                <div class="mb-3 text-muted">{{ order.headerData.newestCostsPeriod }}</div>

            </div>
            <div class="finance-right col-md-12 col-lg-12">
                <span class="text-uppercase font-weight-bold mb-1">Forecast Gesamt</span>
                <div class="mb-3">{{ defVal(item.forecastGesamt, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">Offener Umsatz-Forecast</span>
                <div class="mb-3">{{ defVal(item.offenerUmsatzForecast, '-') }}</div>
                <span class="text-uppercase font-weight-bold mb-1">Offener Kosten-Forecast</span>
                <div class="mb-3">{{ defVal(item.offenerKostenForecast, '-') }}</div>
            </div>
        </div>
        <div class="placeholder-preloader-wrapper">
            <div class="ph-item">
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import {mapGetters, mapState} from "vuex";
import {BTable} from "bootstrap-vue";
import ForecastSumsMxn from "../../Forecast/boxes/ForecastSumsMxn";

import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";

export default {
    name: "FinanceOverview",
    components: {
        BTable
    },
    props: {
        order: {
            type: Object,
            required: true
        }
    },
    mixins: [ForecastSumsMxn, ScalarsProcessing],
    computed: {
        ...mapGetters({
            groupedForecast: 'forecast/groupedForecast',
            laufzeiten: 'forecast/laufzeiten'
        }),
        totalDiffClass() {
            if (this.order.headerData.totalDiff > 0) return 'text-success';
            if (this.order.headerData.totalDiff < 0) return 'text-danger';
        },
        item() {
            return [{
                laufzeiten: (this.laufzeiten.vertragsbeginn !== null && this.laufzeiten.vertragsende !== null) ?
                    this.laufzeiten.vertragsbeginn + ' - ' + this.laufzeiten.vertragsende : '-',
                erloese: this.formatNumber(this.order.headerData.totalRevenue) + ' €',
                kosten: this.formatNumber(this.order.headerData.totalCosts) + ' €',
                wirtschaftlichkeit: this.formatNumber(this.order.headerData.totalDiff) + ' €',
                forecastGesamt: this.formatNumber(this.totals.umsatz) + ' €',
                offenerUmsatzForecast: this.formatNumber(this.order.headerData.offeneUmsatz) + ' €',
                offenerKostenForecast: this.formatNumber(this.order.headerData.offeneKosten) + ' €'
            }]
        }

    },
    methods: {
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        }
    },
}
</script>
<style lang="scss" scoped>
.finance-data {
    display: flex;

    td:nth-child(1) {
        padding: 5px 20px 5px 0;
        font-weight: bold;
    }
}
.simple-box {
    height: 350px;
    overflow:auto;
}

</style>
