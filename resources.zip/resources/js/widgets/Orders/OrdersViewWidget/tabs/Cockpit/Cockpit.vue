<template>
    <div class="row w-100">
        <div class="col-lg-12 col-md-26 col-sm-26 col-26 pr-lg-2 pr-md-0 pr-sm-0 pl-0">
            <Caution :simple-id="simpleId" :order="order"/>
            <AngebotspositionsOverview :simple-id="simpleId" :order="order" />
        </div>
        <div class="col-lg-12 col-md-26 col-sm-26 col-26 pr-lg-2 pr-md-0 pr-sm-0 pl-0">
            <LineChart :simple-id="simpleId" />
            <FinanceOverview :order="order" />
        </div>
    </div>
</template>

<script>
import {BOverlay} from 'bootstrap-vue';
import Caution from "./Caution/Caution";
import FinanceOverview from "./FinanceOverview/FinanceOverview";
import AngebotspositionsOverview from "./AngebotspositionsOverview/AngebotspositionsOverview";
import {mapActions, mapGetters, mapState} from "vuex";
import LineChart from './Charts/LineChart';

export default {
    name: "Cockpit",
    components: {AngebotspositionsOverview, Caution,LineChart, FinanceOverview, BOverlay},
    computed: {
        ...mapState({
            order: state => state.order.order
        }),
        ...mapGetters({
            simpleId: 'order/simpleId'
        }),
    },
    async created() {
        this.pending = true;
        await this.fetchOrderData(this.simpleId);
        await this.fetchForecastData(this.simpleId);
        this.pending = false;
    },
    data() {
        return {
            pending: false
        }
    },
    methods: {
        ...mapActions({
            fetchOrderData: 'order/fetchOrderData',
            fetchForecastData: 'forecast/fetchForecastData'
        })
    }
}
</script>

<style lang="scss" scoped>

</style>
