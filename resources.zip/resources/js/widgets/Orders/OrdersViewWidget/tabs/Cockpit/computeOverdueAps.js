export default {
    computed:{
        overbookedAPs(){
            this.overBookedApNames = [];
            this.order.amountOfBilledAPs.map(ap => {
                if(this.isOverdue(ap)){
                    this.overBookedApNames.push(ap['bezeichnung']);
                }
            });
            return this.overBookedApNames.join(', ');
        },
        billedAps(){
            return this.order.amountOfBilledAPs.reduce(function(ap, item) {
                if (item['billMenge']/ item['menge'] * 100  > 100) {
                    ap.unshift(item);
                } else {
                    ap.push(item);
                }
                return ap;
            }, []);
        }
    },
    methods:{
        totalDiffClass(ap) {
               return (this.isOverdue(ap)) ? '#dc3545' : '#46a800';
        },
        isOverdue(item){
            return item['ratio']  > 100;
        },
        progress(item) {
            if (parseFloat(item['ratio']) < 1) {
                return 0;
            }
            if (parseFloat(item['ratio']) < 999) {
                return parseInt(this.$f.removeTrailingZerosFromDB(item['ratio']));
            }else{
                return 999;
            }
        }
    }
}
