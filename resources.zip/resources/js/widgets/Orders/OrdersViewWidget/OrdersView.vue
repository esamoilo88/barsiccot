<template>
    <div>
        <div class="d-flex align-items-center bg-white pt-3 pb-3 pl-4 pr-4">
            <div id="dashboard-switch" v-cloak>
                <dashboards-switch :sin="simpleId" :customer-id="customerId" title="Finance Dashboard"></dashboards-switch>
            </div>
            <div class="ml-auto mr-3">
                <a href="#" onclick="history.go(-1)">Zurück</a>
            </div>
            <div class="text-right d-flex">
                <WorkflowButton
                    class="mr-3"
                    :simple-id="simpleId"
                    :status="status"
                    :has-ae-permission="order.user.isAngebotsersteller"
                    :user="order.user"
                    :can-reset-status-to-s0="order.can_reset_status_to_s0"
                    :can-switch-preorder="order.can_switch_preorder"
                    @switchedOrder="fetchOrderData(simpleId)"
                    no-tooltip
                />

                <simple-dropdown id="more-options" class="more-options-btn mr-3" :more="false" title="Weitere Optionen">
                    <b-dropdown-item :href="`/projects/${simpleId}/files`" link-class="px-1">
                        <span class="text-nowrap">
                            <span class="icon-folder-open"></span>
                            Dateiablage
                        </span>
                    </b-dropdown-item>
                    <b-dropdown-item :href="`/mails/${simpleId}`" link-class="px-1">
                        <span class="text-nowrap">
                            <span class="icon-communication-email-default"></span>
                            Mailhistorie
                        </span>
                    </b-dropdown-item>
                    <b-dropdown-item :href="`/seceit/${simpleId}/send`">
                        <span class="text-nowrap">Daten an SeCe-IT übertragen</span>
                    </b-dropdown-item>
                </simple-dropdown>
                <div class="billing-writable-icon mt-2">
                    <span
                        v-if="isBillingWritable"
                        :key="'unlocked-billing'"
                        title="Finanzen änderbar"
                        class="icon-content-unlock-selected text-success"
                        v-b-tooltip.hover
                    ></span>
                    <span
                        v-else
                        :key="'locked-billing'"
                        title="Finanzen schreibgeschützt"
                        class="icon-content-lock-selected text-danger"
                        v-b-tooltip.hover
                    ></span>
                </div>
            </div>
        </div>
        <dashboards-preloader v-if="!isStoreInit" class="content-padding"></dashboards-preloader>
        <div v-else>
            <HeaderData class="px-2 simple-header"/>
            <div v-if="!isEmptyData">
                <b-tabs @input="onTabSwitch" v-model="tabIndex" class="simple-tabs">
                    <b-tab id="cockpit-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[0] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(0)">
                            <div class="content-padding mb-5 mx-2">
                                <Cockpit class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="einstellungen-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[1] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(1)">
                            <div class="content-padding mb-5 mx-2">
                                <Einstellungen :tab="tab" @tab-switch="tab = 0" class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="forecast-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[2] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(2)">
                            <div class="content-padding mb-5 mx-2">
                                <Forecast class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="lbu-tab">
                        <template #title>
                            <span class="text">{{ tabsNames[3] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(3)">
                            <div class="content-padding mb-5 mx-2">
                                <LBUIndex/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="kosten-tab" v-if="checkKostenIlvPermissions">
                        <template #title>
                            <span class="text">{{ tabsNames[4] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(4)">
                            <div class="content-padding mb-5 mx-2">
                                <KostenILVIndex />
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="historie-tab" lazy v-if="canProcessTags">
                        <template #title>
                            <span class="text">{{ tabsNames[5] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(numberOfHistoryTab)">
                            <div class="content-padding mb-5 mx-2">
                                <Historie :simple-id="simpleId" class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                </b-tabs>
            </div>
            <NoData v-else/>
        </div>
    </div>
</template>

<script>
import WorkflowButton from "@comp/Common/WorkflowButton/WorkflowButton";
import DashboardsSwitch from "@comp/Common/DashboardsSwitchWidget/DashboardsSwitch";
import HeaderData from "./HeaderData";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BTabs, BTab, BBadge, BDropdownItem, BDropdownDivider, VBTooltip} from 'bootstrap-vue';
import {mapActions, mapGetters, mapMutations, mapState} from "vuex";
import Loading from "@comp/DynamicImportHelpers/Loading";
import NoData from "./NoData";
import Cockpit from "./tabs/Cockpit/Cockpit";
import DashboardMxn from "@mixins/Common/DashboardMxn";
import DashboardsPreloader from "@comp/ContentPreloader/DashboardsPreloader";

const Einstellungen = () => ({loading: Loading, component: import('./tabs/Einstellungen/Einstellungen')});
const Forecast = () => ({loading: Loading, component: import('./tabs/Forecast/Forecast')});
const LBUIndex = () => ({loading: Loading, component: import('./tabs/LBU/Index')});
const KostenILVIndex = () => ({loading: Loading, component: import('./tabs/KostenILV/Index')});
const Historie = () => ({loading: Loading, component: import('./tabs/Historie/Historie')});

export default {
    name: "orders-view",
    components: {
        Cockpit,
        DashboardsSwitch, SimpleDropdown, BTabs, BTab, BBadge,
        HeaderData, BDropdownItem, BDropdownDivider, WorkflowButton,
        Einstellungen, NoData, Forecast, LBUIndex, KostenILVIndex, Historie, DashboardsPreloader
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [DashboardMxn],
    props: {
        dataProp: {
            type: Object,
            required: true
        },
        simpleId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            tabsNames: [
                'Cockpit', 'Einstellungen', 'Forecast', 'Umsatz / LBU',
                'Kosten / ILV', 'Historie'
            ],
            visitedTabs: [],
            tabIndex: 0,
            isEmptyData: false,
            canProcessTags: false,
            tab: 0
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order,
        }),
        ...mapGetters({
            status: 'order/status',
            isBillingWritable: 'order/isBillingWritable',
            isStoreInit: 'order/isInit'
        }),
        numberOfHistoryTab(){
            return this.checkKostenIlvPermissions ? 5 :4;
        },
        checkKostenIlvPermissions() {
            return this.order.user.isAdmin
                || this.order.user.isFinanceAdmin
                || this.order.user.userRoles.includes('SM')
                || this.order.user.userRoles.includes('AD')
                || this.order.user.userRoles.includes('FIU')
        },
        customerId() {
            return (this.dataProp.customer) ? this.dataProp.customer.id : null;
        }
    },
    created() {
        this.isEmptyData = this.dataProp.notSuitableStatus;
        this.canProcessTags = this.dataProp.canProcessTags;
        this.setOrder(this.dataProp);
        this.$eventBus.$on('einstellungenShow', () => {
            this.tabIndex = 1;
            this.tab = 1;
        });
    },
    methods: {
        ...mapMutations({
            setOrder: "order/SET_ORDER"
        }),
        ...mapActions({
            fetchOrderData: "order/fetchOrderData",
        }),
        onTabSwitch(tab) {
            if (!this.visitedTabs.includes(tab)) {
                this.visitedTabs.push(tab)
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/features/dashboards";

.billing-writable-icon {
    font-size: 1.5rem;
}

.more-options ul {
    min-width: 200px;
}
</style>
