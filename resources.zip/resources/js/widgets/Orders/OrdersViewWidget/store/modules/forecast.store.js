import dayjs from "res/js/utils/day";
import {deepCopy, isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";
import Formatter from "res/js/utils/formatter";

export default {
    namespaced: true,
    state: {
        items: [],
        itemsToShow: [],
        clonedItems: [],
        previousMonthsItems: [],
        showPrevious: false,
        basicData: {},
        schemas: {list: [], selected: null},
        availability: {available: false, writable: false},
        isInit: false
    },
    mutations: {
        SET_FORECAST_ITEMS(state, items) {
            state.items = items;
        },
        SET_CLONED_ITEMS(state, items) {
            state.clonedItems = deepCopy(items);
        },
        SET_BASIC_DATA(state, data) {
            state.basicData = {...data};
        },
        SET_SCHEMAS_DATA(state, data) {
            state.schemas = {...data};
        },
        SET_APPLIED_SCHEMA(state, data) {
            state.schemas.selected = data;
        },
        SET_AVAILABILITY(state, data) {
            state.availability = {...data};
        },
        SET_SHOW_PREVIOUS(state, value) {
            state.showPrevious = value;
        }
    },
    actions: {
        /**
         * Get all the data for Forecast
         * @param context
         * @param simpleId
         * @returns {Promise<*>}
         */
        async fetchForecastData(context, simpleId) {
            await context.dispatch('resetState');
            try {
                const res = await this.$axios.get(`/orders/forecast/${simpleId}/get-data`);
                context.commit('SET_BASIC_DATA', res.data.basicData);
                context.commit('SET_SCHEMAS_DATA', res.data.schemas);

                const f = new Formatter();
                const formatMoney = (value) => f.numberToString(value, false, false, null, {
                    maximumFractionDigits: 2,
                    minimumFractionDigits: 2
                });
                // format values now to avoid inconsistency after user's interaction with the data
                let items = res.data.forecast.map(i => {
                    i.umsatzforecast = formatMoney(i.umsatzforecast);
                    i.umsatz = formatMoney(i.umsatz);
                    i.kostenforecast = formatMoney(i.kostenforecast);
                    i.kosten = formatMoney(i.kosten);
                    return i;
                })
                context.commit('SET_FORECAST_ITEMS', items);
                context.commit('SET_CLONED_ITEMS', items);
                context.commit('SET_AVAILABILITY', res.data.availability);

                await context.dispatch('fillItemsToShow');
                context.state.isInit = true;
            } catch (err) {
                console.error('err', err)
            }
        },
        /**
         * Reset state variables to initial values
         */
        resetState(context) {
            context.state.showPrevious = false;
            context.state.isInit = false;
            context.state.items.splice(0);
            context.state.itemsToShow.splice(0);
            context.state.clonedItems.splice(0);
            context.state.previousMonthsItems.splice(0);
            context.state.basicData = {};
            context.state.schemas = {list: [], selected: null};
            context.state.availability = {available: false, writable: false};
        },
        /**
         * Fill "this.itemsToShow" array with initial data
         */
        fillItemsToShow(context) {
            context.state.itemsToShow.splice(0);
            for (let item of context.state.items) {
                let now = dayjs().startOf('month');
                let monat = dayjs(item.monat);
                if (monat.isBefore(now)) {
                    context.state.previousMonthsItems.push(item);
                } else {
                    context.state.itemsToShow.push(item);
                }
            }
        },
        /**
         * Handle changing of "showPrevious" switch
         * If it's false - we show only future months + current month
         * If it's true - we show everything
         */
        changeItemsToShow(context) {
            if (!context.state.showPrevious) { // show only current and future month
                if (context.state.itemsToShow.length == context.state.items.length) {
                    let currMonthIndex = -1;
                    let currentDate = dayjs().startOf('month');
                    for (let [index, item] of context.state.itemsToShow.entries()) {
                        if (!dayjs(item.monat).isBefore(currentDate)) {
                            currMonthIndex = index;
                            break;
                        }
                    }
                    currMonthIndex !== -1 && context.state.itemsToShow.splice(0, currMonthIndex);
                }
            } else { // show every month
                if ((context.state.itemsToShow.length + context.state.previousMonthsItems.length) == context.state.items.length) {
                    context.state.itemsToShow.unshift(...context.state.previousMonthsItems);
                }
            }
        },
    },
    getters: {
        discount(state) {
            return !isEmpty(state.basicData) ? state.basicData.rabattierung : null
        },
        laufzeiten(state) {
            if (isEmpty(state.basicData)) {
                return {
                    vertragsbeginn: null,
                    vertragsende: null,
                    vertragsDifference: null,

                    rolloutbeginn: null,
                    rolloutende: null,
                    rolloutDifference: null,

                    betriebsbeginn: null,
                    betriebsende: null,
                    betriebsDifference: null
                }
            } else {
                return state.basicData.laufzeiten;
            }
        },
        /**
         * Group forecast values by year
         * @returns {Map<any, any>}
         */
        groupedForecast(state) {
            let forecastGrouped = new Map();
            state.items.map(f => {
                let forecastDate = dayjs(f.monat);
                if (forecastGrouped.get(forecastDate.format('YYYY')) === undefined) {
                    forecastGrouped.set(forecastDate.format('YYYY'), []);
                }
                forecastGrouped.get(forecastDate.format('YYYY')).push(f);
            });
            return forecastGrouped;
        },
    }
}
