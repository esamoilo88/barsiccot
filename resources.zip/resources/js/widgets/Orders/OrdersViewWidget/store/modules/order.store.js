import {asyncCall} from "@helpers/Async/AsyncRequests";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    namespaced: true,
    state: {
        order: {},
        finance: [],
        filters: {
            leistungsMonat: 'alle',
            typ: 'alle',
            merkmale: 'alle',
            search: '',
            searchQuery: '',
            status: 'alle',
            position: 'alle',
            search_ap: '',
            kostenMonat: 'alle',
        },
        statuses: []
    },
    mutations: {
        SET_ORDER(state, order) {
            state.order = {...order};
        },
        SET_FINANCE(state, finance) {
            state.finance = [...finance];
        },
        SET_OFFER_INFO(state, data) {
            state.order.offerInfo = {...data};
        },
        SET_HEADER_DATA(state, data) {
            state.order.headerData = {...data};
        },
        SET_MERKMALE(state, merkmale) {
            state.filters.merkmale = merkmale;
        },
        SET_LEISTUNGS_MONAT(state, leistungsMonat) {
            state.filters.leistungsMonat = leistungsMonat;
        },
        SET_TYP(state, typ) {
            state.filters.typ = typ;
        },
        SET_STATUS(state, status) {
            state.filters.status = status;
        },
        SET_SEARCH_LBU(state, search_lbu) {
            state.filters.search = search_lbu;
        },
        SET_POSITION(state, position) {
            state.filters.position = position;
        },
        SET_SEARCH_AP(state, search_ap) {
            state.filters.search_ap = search_ap;
        },
        SET_SEARCH_COST(state, search_cost) {
            state.filters.searchQuery = search_cost;
        },
        SET_ALL_STATUSES(state, statuses) {
            state.statuses = statuses;
        },
        SET_KOSTEN_MONAT(state, kostenMonat) {
            state.filters.kostenMonat = kostenMonat;
        },
    },
    actions: {
        /**
         * Get basic data for Order view page
         * @param context
         * @param simpleId
         * @returns {Promise<*>}
         */
        async fetchOrderData(context, simpleId) {
            await asyncCall(
                async () => {
                    if (simpleId) {
                        const response = await this.$axios.get(`/orders/${simpleId}/get-order-data`);
                        if (response.data) {
                            let order = response.data;
                            context.commit('SET_ORDER', order);
                        } else {
                            console.error("No data returned for fetchOrderData()")
                        }
                    } else {
                        console.error("SimpleId is not provided")
                    }
                },
                (err) => {
                    console.error('Couldn\'t fetch order data', err)
                },
                false
            );
        },

        /**
         * Get data for Order Finance data
         * @param context
         * @param simpleId
         * @returns {Promise<*>}
         */
        async fetchFinanceData(context, simpleId) {
            await asyncCall(
                async () => {
                    if (simpleId) {
                        try {
                            const response = await this.$axios.get(`/orders/${simpleId}/einstellungen/bestellungsdaten`);
                            if (response.data) {
                                let finance = response.data;
                                context.commit('SET_FINANCE', finance);
                            } else {
                                console.error("No data returned for fetchFinanceData()")
                            }
                        } catch (e) {
                            window.flash.showMessagesFromAjax(e.response.data);
                        }
                    } else {
                        console.error("SimpleId is not provided")
                    }
                },
                (err) => {
                    console.error('Couldn\'t fetch order data', err)
                },
                false
            );
        }
    },
    getters: {
        status(state) {
            return state.order.globalGate.sinStatus.status;
        },
        simpleId(state) {
            return state.order.globalGate.simpleId;
        },
        isBillingWritable(state) {
            return state.order.globalGate.sinStatus.status.billingWritable;
        },
        isInit(state) {
            return !isEmpty(state.order);
        },
        isHardBilling(state) {
            return state.order.auftrag.profitcenterSettings.billingType.hardBilling;
        },
        profitcenterSettings(state) {
            return state.order.auftrag.profitcenterSettings;
        },
        allStatuses(state) {
            return state.statuses;
        }
    }
}
