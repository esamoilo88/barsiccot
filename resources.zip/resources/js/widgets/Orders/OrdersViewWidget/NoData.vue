<template>
    <div class="mt-5 content-padding mx-2">
        <div class="simple-box w-100">
            <div class="row no-gutters mb-3 wrapper-icon">
                <span class="icon-alert-warning-default notice-icon"></span>
                <span>Es wurde noch <b>kein</b> Auftrag angelegt.</span>
            </div>
            <div class="row no-gutters mb-3">
                Um die Finanzen eines Auftrags zu erfassen muss eine Beauftragung oder Vorabbeauftragung vorliegen.
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "NoData"
}
</script>

<style scoped>
.notice-icon {
    font-size: 30px;
    margin-right: 10px;
}
.wrapper-icon {
    display: flex;
    align-items: center;
}
</style>
