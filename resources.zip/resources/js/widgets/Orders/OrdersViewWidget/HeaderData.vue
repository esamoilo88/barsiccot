<template>
    <div>
        <div class="row pl-3 pr-3 d-flex justify-content-between">
            <div class="col-lg-11 col-md-11 simple-box">
                <div class="d-flex justify-content-between">
                    <table class="w-70">
                        <tr class="row-height">
                            <td class="label-text">SIN</td>
                            <td class="">{{ defVal(simpleId, '-') }}</td>
                        </tr>
                        <tr class="row-height">
                            <td class="label-text">Vorhaben</td>
                            <td class="">{{ defVal(order.globalGate.thema, '-') }}</td>
                        </tr>
                        <tr class="row-height">
                            <td class="label-text">Kunde</td>
                            <td class="">{{ defVal(order.kundenname, '-') }}</td>
                        </tr>
                    </table>
                    <div class="d-flex flex-column justify-content-between">
                        <CircleChart
                            :content="status.shortName"
                            :value="status.progress"
                            :color="status.color"
                            size="xmsmall"
                            sr-text="Status"
                            class="align-self-end"

                        />
                        <ProjectTags :simple-id="simpleId" :readonly="true" class="align-self-end project-tags-component"/>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box d-flex flex-column justify-content-between">
                <BoxSpinner :busy="isBusy"/>
                <div class="label-text row-height">Finanzstatus</div>
                <div class="d-flex">
                    <CircleChart
                        :icon-class="order.headerData.icon"
                        :value="order.headerData.progress"
                        :color="order.headerData.color"
                        size="xsmall"
                        sr-text="Status"
                        class="mr-2"
                    />
                    <div class="d-flex flex-column align-self-end">
                        <span>{{ order.headerData.name }}</span>
                        <span class="text-muted">{{ order.headerData.updatedAt }}</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box d-flex flex-column justify-content-between">
                <BoxSpinner :busy="isBusy"/>
                <div class="label-text row-height"> Umsatz gesamt</div>
                <div class="big-number pb-1">{{ formatNumber(order.headerData.totalRevenue) }} €</div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box d-flex flex-column justify-content-between">
                <BoxSpinner :busy="isBusy"/>
                <div class="label-text row-height"> Kosten gesamt</div>
                <div class="big-number pb-1">{{ formatNumber(order.headerData.totalCosts) }} €</div>
            </div>
        </div>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownItem, BDropdownDivider} from 'bootstrap-vue';
import {mapGetters, mapState, mapMutations} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";
import Badge from "@comp/Badge/Badge";
import ProjectTags from "@comp/Common/ProjectTags/ProjectTags";

export default {
    name: "HeaderData",
    components: {
        CircleChart,
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider,
        BoxSpinner,
        Badge,
        ProjectTags
    },
    mixins: [ScalarsProcessing],
    created() {
        this.$eventBus.$on('orderHeaderUpdate', this.refreshHeaderData);
    },
    beforeDestroy() {
        this.$eventBus.$off('orderHeaderUpdate', this.refreshHeaderData);
    },
    data() {
        return {
            isBusy: false
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order,
        }),

        ...mapGetters({
            simpleId: 'order/simpleId',
            status: 'order/status'
        }),

        totalDiffClass() {
            if (this.order.headerData.totalDiff > 0) return 'text-success';
            if (this.order.headerData.totalDiff < 0) return 'text-danger';
        }
    },
    methods: {
        ...mapMutations({
            setHeaderData: 'order/SET_HEADER_DATA'
        }),

        async refreshHeaderData() {
            this.isBusy = true;
            try {
                const res = await this.$axios.get(`/orders/${this.simpleId}/recalculate-finance`);
                this.setHeaderData(JSON.parse(res.data));
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.isBusy = false;
        },

        formatNumber(value) {
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        padding: 5px 20px 5px 0;
    }
}

.header-data__sumTotal-title,
.header-data__sumRevenue-title {
    padding-right: 10px !important;
    font-weight: normal !important;
}

.header-data__sumTotal,
.header-data__sumRevenue {
    padding: 5px 0 5px 0 !important;
    text-align: right;
}

.marge-box {
    border-right: 2px solid #dee2e6;
    margin-right: 55px;
    padding-right: 55px;
}

[class*="header-data__"] {
    font-weight: bold;
}

.box-right {
    .text-muted {
        font-size: 1.125rem;
    }
}
.finance_status{
    padding: 0;
    border-right: 1px solid #dee2e6 !important;
}
.gesamt_preis{
    padding-right: 0;
}
.big-number {
    font-weight: bold;
    font-size: 1.5rem;
}
.row-height {
    line-height: 30px;
}
</style>
