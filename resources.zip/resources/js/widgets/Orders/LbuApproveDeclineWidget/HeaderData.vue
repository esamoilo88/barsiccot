<template>
    <div class="simple-box box-shadow">
        <div class="header-data">
            <table>
                <tr>
                    <td>SIN:</td>
                    <td class="header-data__simple-id">{{ simpleId }}</td>
                </tr>
                <tr>
                    <td>Vorhaben:</td>
                    <td class="header-data__vorhaben">{{ vorhaben }}</td>
                </tr>
                <tr>
                    <td>Kunde:</td>
                    <td class="header-data__kunde">{{ kunde }}</td>
                </tr>
            </table>
        </div>
    </div>
</template>

<script>
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownItem, BDropdownDivider} from 'bootstrap-vue';

export default {
    name: "HeaderData",
    components: {
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider
    },
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        vorhaben: {
            type: String,
            required: true
        },
        kunde: {
            type: String,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        font-size: 22px;
        padding: 5px 20px 5px 0;
    }
}

.header-data__simple-id,
.header-data__vorhaben,
.header-data__kunde {
    font-weight: bold;
}
</style>
