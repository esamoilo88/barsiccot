import Vue from 'vue';
import {$axios} from 'res/js/boot';
import LbuApproveDecline from "./LbuApproveDecline";
import Formatter from "res/js/utils/formatter";
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
const translations = require('res/lang/lang.translations.json');

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$t = new SimpleTranslator(translations);

Vue.use(Vuelidate);

export default new Vue({
    el: '#lbu-approve-decline', //resources/views/App/Orders/LBU/approve_decline.blade.php
    components: {
        LbuApproveDecline
    }
});
