<template>
    <div>
        <HeaderData
            v-once
            class="mb-4"
            :simple-id="headerData.simpleId"
            :kunde="headerData.kunde"
            :vorhaben="headerData.vorhaben"
        />

        <div class="simple-box box-shadow">
            <button v-if="items.length > 0" @click="onSave" class="btn btn-primary mb-3">Speichern</button>

            <b-table
                :items="items"
                :fields="fields"
                primary-key="id"
                class="lbu-approve-decline-table"
                empty-text="Keine Daten vorhanden"
                show-empty
            >
                <template #cell(id)="data">
                    LBU/{{ data.item.id }}
                </template>

                <template #cell(Leistungszeitraum)="data">
                    <span class="font-weight-bold">{{ data.item.Leistungszeitraum }}</span>
                </template>

                <template #cell(Fakturazeitraum)="data">
                    <span class="font-weight-bold">{{ data.item.Fakturazeitraum }}</span>
                </template>

                <template #cell(betrag)="data">
                    <span :class="{
                        'font-weight-bold': true,
                        'text-success': (data.item.betrag || 0) > 0,
                        'text-danger': (data.item.betrag || 0) < 0,
                    }">
                        {{ $f.numberToString(data.item.betrag, true, false, '0,00 €') }}
                    </span>
                </template>

                <template #cell(approve-decline)="data">
                    <div class="approve-decline-select-wrapper">
                        <FormSelect
                            :class="'approve-decline-select-' + data.item.id"
                            :name="'approve-decline-select-' + data.item.id"
                            :select-id="'approve-decline-select-' + data.item.id + '-id'"
                            label-text="Freigegeben/Abgelehnt"
                            :options="approveDeclineOptions"
                            :key="'lbu-' + data.item.id"
                            :value="calcPreselected(data.item)"
                            :readonly="calcPreselected(data.item) !== 'empty'"
                            @input="value => handleSelect(value, data.item)"
                        />
                    </div>
                </template>

                <template #cell(decline-reason)="data">
                    <div>
                        <FormTextArea
                            v-if="declined[data.item.id] || data.item.statusSysName === 'Rejected'"
                            v-model="data.item.declineReason"
                            :disabled="calcPreselected(data.item) === 'abgelehnt'"
                            :input-id="'decline-reason-' + data.item.id"
                            :name="'decline-reason-' + data.item.id"
                            rows="1"
                            label-text="Abgelehnt kommentar*"
                            :error-conditions="[
                                {
                                    name: 'empty-comment',
                                    condition: !$v.items.$each[data.index].declineReason.required
                                        && $v.items.$each[data.index].declineReason.$dirty,
                                    text: $t.__('validation.required', {attribute: 'Kommentar'})
                                }
                            ]"
                        />
                    </div>
                </template>
            </b-table>
        </div>
    </div>
</template>

<script>
import {BTable} from 'bootstrap-vue';
import HeaderData from "./HeaderData";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {deepCopy, isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";
import {requiredIf} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "lbu-approve-decline",
    components: {FormTextArea, FormSelect, HeaderData, BTable},
    props: {
        lbus: {
            type: Array,
            required: true,
            default: () => []
        },
        headerData: {
            type: Object,
            required: true,
            default: () => ({})
        }
    },
    data() {
        return {
            items: [],
            approved: {},
            declined: {},
            fields: [
                {key: "id", label: "LBU ID", class: "lbu-id-cell"},
                {key: "Leistungszeitraum", label: "Leistungszeitraum", class: "leistungszeitraum-cell"},
                {key: "Fakturazeitraum", label: "Fakturazeitraum", class: "fakturazeitraum-cell"},
                {key: "betrag", label: "Betrag", class: "betrag-cell"},
                {key: "approve-decline", label: "Freigegeben/Abgelehnt", class: "approve-decline-cell"},
                {key: "decline-reason", label: "", class: "decline-reason-cell"}
            ],
            approveDeclineOptions: [
                {id: 'empty', text: '-'},
                {id: 'freigegeben', text: 'Freigegeben'},
                {id: 'abgelehnt', text: 'Abgelehnt'}
            ]
        }
    },
    created() {
        this.items.push(...deepCopy(this.lbus));
    },
    methods: {
        async onSave() {
            window.preloader.show();
            this.$v.$reset();
            this.$v.$touch();
            if (!this.$v.$anyError && (!isEmpty(this.declined) || !isEmpty(this.approved))) {
                try {
                    let pathParts = window.location.pathname.split('/');
                    let token = pathParts[pathParts.length - 1];
                    const res = await this.$axios.post('/orders/lbu/approve-decline/' + token,
                        {approveDeclineProcess: {declined: this.declined, approved: this.approved}}
                    );
                    if (res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload(false);
                    }
                } catch (err) {
                    console.error("Couldn't approve/decline lbus! Err: ", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            } else {
                navigateToFirstInvalid();
            }
            window.preloader.hide();
        },
        calcPreselected(item) {
            switch (item.statusSysName) {
                case 'Ready':
                    return 'freigegeben';
                case 'Rejected':
                    return 'abgelehnt';
                default:
                    return 'empty';
            }
        },
        handleSelect(value, item) {
            switch (value) {
                case 'freigegeben':
                    this.$delete(this.declined, item.id); // remove if it was in declined before
                    this.$set(this.approved, item.id, item);
                    break;
                case 'abgelehnt':
                    this.$delete(this.approved, item.id); // remove if it was in approved before
                    this.$set(this.declined, item.id, item);
                    break;
                default:
                    this.$delete(this.declined, item.id);
                    this.$delete(this.approved, item.id);
            }
        }
    },
    validations: {
        items: {
            $each: {
                declineReason: {required: requiredIf(function (lbu) { return this.declined[lbu.id] !== undefined })}
            }
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep td {
    vertical-align: baseline;
}

::v-deep .lbu-id-cell, .betrag-cell {
    max-width: 150px;
}

::v-deep .leistungszeitraum-cell,
.fakturazeitraum-cell {
    max-width: 130px;
}

::v-deep .approve-decline-cell {
    max-width: 160px;
}

::v-deep .decline-reason-cell {
    max-width: 170px;
    vertical-align: bottom;

    textarea {
        height: 47px;
    }
}

</style>
