<template>
    <div class="simple-box box-shadow">
        <div class="header-data">
            <table>
                <tr>
                    <td>SIN:</td>
                    <td class="header-data__simple-id">{{ simpleId }}</td>
                </tr>
                <tr>
                    <td>Vorhaben:</td>
                    <td class="header-data__vorhaben">{{ defVal(order.globalGate.thema, '-') }}</td>
                </tr>
                <tr>
                    <td>Kunde:</td>
                    <td class="header-data__kunde">{{ defVal(order.kundenname, '-') }}</td>
                </tr>
            </table>

            <CircleChart
                :content="status.shortName"
                :value="status.progress"
                :color="status.color"
                size="small"
                sr-text="Status"
            />
        </div>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownItem, BDropdownDivider} from 'bootstrap-vue';

import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {mapGetters, mapState} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";

export default {
    name: "HeaderData",
    components: {
        CircleChart,
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider
    },
    mixins: [ConfirmationModal, ScalarsProcessing],
    computed: {
        ...mapState({
            order: state => state.order.order,
        }),

        ...mapGetters({
            simpleId: 'order/simpleId',
            status: 'order/status'
        }),
    },
    methods: {}
}
</script>

<style lang="scss" scoped>
.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        font-size: 22px;
        padding: 5px 20px 5px 0;
    }
}

.header-data__simple-id,
.header-data__vorhaben,
.header-data__kunde {
    font-weight: bold;
}
</style>
