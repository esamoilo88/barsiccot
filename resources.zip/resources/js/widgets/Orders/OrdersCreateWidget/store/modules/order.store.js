import {asyncCall} from "@helpers/Async/AsyncRequests";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    namespaced: true,
    state: {
        order: {}
    },
    mutations: {
        SET_ORDER(state, order) {
            state.order = {...order};
        },
        SET_OFFER_INFO(state, data) {
            state.order.offerInfo = {...data};
        }
    },
    actions: { },
    getters: {
        status(state) {
            return state.order.globalGate.sinStatus.status;
        },
        simpleId(state) {
            return state.order.globalGate.simpleId;
        },
        isBillingWritable(state) {
            return state.order.globalGate.sinStatus.status.billingWritable;
        },
        isInit(state) {
            return !isEmpty(state.order);
        },
        currentVersion(state) {
            return state.order.offerInfo.currentVersionId;
        },
        activeVersion(state) {
            return state.order.offerInfo.activeVersionId;
        },
        offerInfo(state) {
            return state.order.offerInfo
        }
    }
}
