import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import order from "./modules/order.store";

const store = new Vuex.Store({
    modules: {
        order
    }
});

store.$axios = $axios;

export default store;
