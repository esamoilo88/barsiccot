<template>
    <div class="simple-box d-flex flex-column">
        <b-overlay :show="pending">
            <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon w-5" src="/img/icons/information_graphical.svg" alt="price tag"/>
                <div class="d-flex flex-column">
                    <h2>Zusammenfassung und E-Mails</h2>
                    <span class="text-muted secondary-text">
                        Übersicht über die Beauftragung und den Mailversand.
                    </span>
                </div>
                <button @click="toggleBoxesVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible" class="zusammenfassung">
                <div class="horizontal-line mb-3"></div>
                <div v-if="selectedVersion" class="mt-2">
                    <span class="icon-action-succsess-default mr-2"></span>
                    Die Angebotsversion V{{ selectedVersion }} wird beauftragt.
                </div>
                <div v-else>
                    Bitte wähle eine Angebotsversion aus um die Beauftragung durchzuführen.
                </div>
                <div class="mt-3">
                    <span class="icon-service-maintanance-default mr-2"></span>
                    Es werden optionale Angebotspositionen beauftragt.
                </div>
                <div v-if="selectedVersion">
                    <div v-if="!formData.avMember">
                    <span>
                        Es wird eine Infomail an das Eingangstor {{ emailNames.email_entry_gate }} gesendet.
                    </span>
                    </div>
                    <div v-else>
                    <span>
                        Es wird eine Infomail an {{ formData.email }}, {{ formData.displayName }} gesendet (das Eingangstor {{
                            emailNames.email_entry_gate
                        }} erhält die E-Mail in CC).
                    </span>
                    </div>

                    <div v-if="this.order.isIksl && !formData.preorder">
                    <span>
                        Es wird eine Info an {{ emailNames.email_iksl_vldtag }} sowie den Anforderer gesendet.
                    </span>
                    </div>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BButton, BTooltip, BOverlay} from 'bootstrap-vue';
import TableSimple from '@comp/TableSimple/TableSimple';
import {mapState} from "vuex";

export default {
    name: 'zusammenfassung-email',
    components: {
        ButtonIcon, BTooltip, TableSimple, BButton, BOverlay
    },
    props: {
        selectedVersion: {
            type: Number,
            required: false
        },
        formData: {
            type: Object,
            required: true
        },
        emailNames: {
            type: Object,
            required: true
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order,
        })
    },
    data() {
        return {
            isContentVisible: false,
            pending: false
        }
    },
    methods: {
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        }
    }
}
</script>
<style lang="scss" scoped>
.horizontal-line {
    height: 1px;
    background-color: #dee2e6;
}

.zusammenfassung {
    height: auto;
}
</style>
