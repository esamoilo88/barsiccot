export default {
    methods: {
        onSelectVersion(value) {
            let currentVersionData = this.versionData.filter(version => version.vkVersionsId === parseInt(value));

            this.fillDateFields(currentVersionData[0]);
            this.form.vkVersion = value;
            this.form.avVersion = currentVersionData[0].afVersionsId;
            this.$eventBus.$emit('refresh-ap-list');
            this.$eventBus.$emit('reset-selected-ap');

            this.$emit('selected-aps', null);
            this.$emit('selected-version', currentVersionData[0].versionsnr);
        },
        onSelectDebitor(value) {
            this.form.debitor = value;
        },
        async getDebitorData() {
            try {
                let simpleId = this.dataProp.globalGate.simpleId;
                let res = await this.$axios.get(`/debitor/${simpleId}/list`);
                this.debitorData.splice(0);
                this.debitorData.push(...res.data);
            } catch (err) {
                console.error("Couldn't fetch debitor data list", err);
            }
        },
        async getVersionData() {
            try {
                this.pending = true;
                let simpleId = this.dataProp.globalGate.simpleId;
                let res = await this.$axios.get(`/orders/${simpleId}/versions`);
                this.versionData.splice(0);
                this.versionData.push(...res.data);
                this.pending = false;
            } catch (err) {
                console.error("Couldn't fetch version data list", err);
            }
        },
    }
}
