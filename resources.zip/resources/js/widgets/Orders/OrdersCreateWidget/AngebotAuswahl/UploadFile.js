export default {
    methods: {
        async uploadFile(filesInfo) {
            try {
                this.loading = true;
                await this.$axios.post('/file/getPath', filesInfo.formData, filesInfo.config).then(
                    response => {
                        let info = response.data.filesPath[0];
                        this.form.attachedfile = {
                            'savePath': info.tempPath,
                            'size': info.size,
                            'name': filesInfo.fileNames,
                            'date': filesInfo.date
                        }
                    }
                );
            } catch (error) {
                console.error('Couldn\'t upload file', error);
                window.flash.error(error.response.data.text);
                this.$refs.file.clearFiles();
            }
            this.loading = false;
        },
    }
}
