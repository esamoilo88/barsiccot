<template>
    <div class="simple-box d-flex flex-column">
        <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible} " class="fs2">
            <img class="mr-4 icon" src="/img/icons/contract_graphical.svg" alt="angebotsauswahl"/>
            <div class="d-flex flex-column">
                <h2>Angebotsauswahl und Beauftragung</h2>
                <span class="text-muted secondary-text">
                    Wähle die Angebotsversion aus und erfasse die Stammdaten des Vertrags.
                </span>
            </div>
            <button @click="toggleBoxesVisibility" class="btn btn-secondary ml-auto">
                {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
            </button>
        </div>

        <div v-if="isContentVisible">
            <div class="horizontal-line mb-3"></div>

            <b-overlay :show="pending">
                <div class="px-3 mb-3">
                    <div class="font-weight-bold mb-3">Beauftragung</div>

                    <div class="mb-3">
                        <b-form-radio v-model="form.preorder" :value="false">Reguläre Beauftragung</b-form-radio>
                        <div class="text-muted pt-2">Wähle reguläre Beauftragung wenn du eine SAP Bestellung vom Auftraggeber hast (z.B. eBanf, Order Purchase). Das Vorhaben wird in den Status Beauftragt überführt.</div>
                    </div>

                    <div class="mb-3">
                        <b-form-radio v-model="form.preorder" :value="true">Vorabbeauftragung</b-form-radio>
                        <div class="text-muted pt-2">Wähle Vorabbeauftragung wenn du noch keine SAP Bestellung hast aber bereits Leistungen erfolgt sind und eine Abgrenzung und ILV erfolgen muss. In diesem Fall kannst du SAP Bestellnummer zunächst weglassen. Das Vorhaben wird in den Status Vorabbeauftragt überführt und du musst im Nachgang die reguläre Beauftragung über die Funktion "Vorabbeauftragung fertigstellen" ergänzen.</div>
                    </div>
                </div>

                <div class="horizontal-line mb-3"></div>

                <div class="row">
                    <div class="col">
                        <p>Stammdaten</p>
                        <b-form-group>
                            <FormSelect
                                v-model="form.vkVersion"
                                name="vkVersion"
                                :options="versionOptions"
                                type="select"
                                class="mb-3"
                                @input="onSelectVersion"
                                select-id="vkVersion-input"
                                label-text="Angebotsversion*"
                                :error-conditions="errorConditions.vkVersion"
                            />
                            <FormDatepicker
                                v-model="form.auftragsdatum"
                                name="auftragsdatum"
                                class="w-100 mb-3"
                                label-text="Auftragsdatum*"
                                input-id="auftragsdatum-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.auftragsdatum"
                            >
                            </FormDatepicker>
                        </b-form-group>
                        <b-form-group>
                            <form-file-load
                                v-model="form.file"
                                ref="file"
                                type="file"
                                browse-text="Auswählen"
                                @uploadFile="uploadFile"
                                class="mt-4 mb-4"
                                placeholder="Beauftragungsdatei*"
                                accept=".doc, .docx, .pdf, .p7f, .xia"
                                :error-conditions="errorConditions.file"
                            />
                            <FormInput
                                v-if="!form.preorder"
                                v-model="form.sapAuftragsNr"
                                label-text="SAP Bestellnummer*"
                                name="sapAuftragsNr"
                                class="mb-4"
                                input-id="sapAuftragsNr"
                                :error-conditions="[...errorConditions.sapAuftragsNr, ...bestellnummerErrorConditions]"
                            />
                            <FormSelect
                                v-model="form.debitor"
                                name="debitor"
                                @select="onSelectDebitor"
                                :options="debitorOptions"
                                type="select"
                                select-id="debitor-input"
                                label-text="Debitor*"
                                :error-conditions="errorConditions.debitor"
                            />
                        </b-form-group>
                        <div class="mt-5">
                            <FormRadio
                                class="my-3 primary-white"
                                name="aeAssign"
                                id="radio_label_aeAssign"
                                v-model="selected"
                                @change="switchResponsibleOption"
                                :options="options"
                                stacked
                            />
                        </div>
                        <b-form-group v-if="aeYourSelf">
                            <PeopleSearch
                                ref="search"
                                type="default"
                                v-model="form.avMember"
                                label="Mitarbeiter suchen*"
                                :default-search="search"
                                :multiple="false"
                                @user-added="userAdded"
                                @user-dropped="userDropped"
                            />
                            <div class="invalid-feedback d-block" v-if="isInvalid('avMember')">
                                Das Mitglied ist erforderlich.
                            </div>
                        </b-form-group>
                        <div v-if="aeByEingangstor">
                            Der Auftragsverantwortliche wird nach der Beauftragung durch das zuständige Eingangstor
                            festgelegt.
                        </div>

                    </div>
                    <div class="col">
                        <p>Laufzeiten und Termine</p>

                        <b-form-group>
                            <FormDatepicker
                                v-model="form.vertragsbeginn"
                                name="vertragsbeginn"
                                label-text="Vertragsbeginn*"
                                class="w-100 mb-2"
                                input-id="vertragsbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.vertragsbeginn"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="vertragsbeginn" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                            <FormDatepicker
                                v-model="form.vertragsende"
                                name="vertragsende"
                                class="w-100 mb-5"
                                label-text="Vertragsende*"
                                input-id="vertragsende-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.vertragsende"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="vertragsende" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                        </b-form-group>
                        <b-form-group>
                            <FormDatepicker
                                v-model="form.rolloutbeginn"
                                name="rolloutbeginn"
                                class="w-100 mb-2"
                                label-text="Realisierungsbeginn"
                                input-id="rolloutbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.rolloutbeginn"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="rolloutbeginn" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                            <FormDatepicker
                                v-model="form.rolloutende"
                                name="rolloutende"
                                class="w-100 mb-5"
                                label-text="Realisierungsende"
                                input-id="rolloutende-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.rolloutende"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="rolloutende" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                        </b-form-group>
                        <b-form-group>
                            <FormDatepicker
                                v-model="form.betriebsbeginn"
                                name="betriebsbeginn"
                                class="w-100 mb-2"
                                label-text="Betriebsbeginn"
                                input-id="betriebsbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.betriebsbeginn"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="betriebsbeginn" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                            <FormDatepicker
                                v-model="form.betriebsende"
                                name="betriebsende"
                                class="w-100 mb-5"
                                label-text="Betriebsende"
                                input-id="betriebsende-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.betriebsende"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="betriebsende" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                        </b-form-group>
                        <b-form-group>
                            <FormDatepicker
                                v-model="form.beauftragungsende"
                                name="beauftragungsende"
                                class="w-100 mb-3"
                                label-text="Beauftragungsende"
                                input-id="beauftragungsende-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.beauftragungsende"
                            >
                                <template v-slot:button>
                                    <ChangeMonthButton field-name="beauftragungsende" :form="form" @change-field="changeField"/>
                                </template>
                            </FormDatepicker>
                            <span class="beauftragungsende-muted text-muted">
                            Das Feld Beauftragungsende stellt eine Ergänzung zum Feld Vertragsende dar.
                            Es wird nur dann befüllt, wenn die Beaftragung durch den Auftraggeber zunächst
                            nicht bis zum Vertragsende erfolgt. Das Beauftragungsende liegt zeitlich daher
                            immer vor dem Vertragsende.
                        </span>
                        </b-form-group>
                    </div>
                </div>
            </b-overlay>
        </div>
    </div>
</template>

<script>
import FormFileLoad from '@comp/FileLoad/FormFileLoad';
import FormSelect from "@comp/FormSelect/FormSelect";
import {BOverlay, BFormInput, BFormGroup, BFormRadio} from 'bootstrap-vue';
import FormRadio from "@comp/FormRadio/FormRadio";
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import {numeric, required, requiredIf} from 'vuelidate/lib/validators';
import FormInput from "@comp/FormInput/FormInput";
import {isDate} from "res/js/utils/Validators/DatesValidators";
import ChangeMonthButton from "@comp/ChangeMonthButton/ChangeMonthButton";
import dayjs from "dayjs";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import Validation from '@mixins/Validation/Validation';
import OrderSelectOptionMix from "./OrderSelectOptionMix";
import UploadFile from "res/js/widgets/Orders/OrdersCreateWidget/AngebotAuswahl/UploadFile";
import IcpBestellnummerValidationMxn from "@mixins/IcpBestellnummerValidation/IcpBestellnummerValidationMxn";

export default {
    name: "angebots-auswahl",
    components: {
        FormFileLoad,
        FormSelect,
        BOverlay,
        FormRadio,
        PeopleSearch,
        BFormInput,
        FormDatepicker,
        BFormGroup,
        FormInput,
        ChangeMonthButton,
        BFormRadio,
    },
    mixins: [Validation, OrderSelectOptionMix, UploadFile, IcpBestellnummerValidationMxn],
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    async created() {
        await this.getDebitorData();
        await this.getVersionData();
    },
    computed: {
        errorConditions() {
            return {
                vkVersion: [
                    {
                        name: 'vkVersion-required',
                        condition: this.isInvalid('vkVersion', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Angebotsversion'})
                    }
                ],
                auftragsdatum: [
                    {
                        name: 'auftragsdatum-required',
                        condition: this.isInvalid('auftragsdatum', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Auftragsdatum'})
                    },
                    {
                        name: 'auftragsdatum-isDate',
                        condition: this.isInvalid('auftragsdatum', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Auftragsdatum'})
                    }
                ],
                debitor: [
                    {
                        name: 'debitor-required',
                        condition: this.isInvalid('debitor', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Debitor'})
                    }
                ],
                file: [
                    {
                        name: 'file-required',
                        condition: this.isInvalid('file', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Datei'})
                    }
                ],
                avMember: [
                    {
                        name: 'avMember-required',
                        condition: this.isInvalid('avMember', 'requiredIf'),
                        text: 'Der Mitarbeiter ist erforderlich'
                    }

                ],
                sapAuftragsNr: [
                    {
                        name: 'sapAuftragsNr-required',
                        condition: this.isInvalid('sapAuftragsNr', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'SAP Bestellnummer'})
                    },
                    {
                        name: 'sapAuftragsNr-integer',
                        condition: this.isInvalid('sapAuftragsNr', 'numeric'),
                        text: this.$t.__('validation.numeric', {attribute: 'SAP Bestellnummer'})
                    }
                ],
                vertragsbeginn: [
                    {
                        name: 'vertragsbeginn-isDate',
                        condition: this.isInvalid('vertragsbeginn', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Vertragsbeginn'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.vertragsbeginn != null,
                        text: (this.termineErrors.vertragsbeginn != null) ? this.termineErrors.vertragsbeginn.join(' ') : ''
                    },
                    {
                        name: 'vertragsbeginn-required',
                        condition: this.isInvalid('vertragsbeginn', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Vertragsbeginn'})
                    }
                ],
                vertragsende: [
                    {
                        name: 'vertragsende-isDate',
                        condition: this.isInvalid('vertragsende', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Vertragsende'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.vertragsende != null,
                        text: (this.termineErrors.vertragsende != null) ? this.termineErrors.vertragsende.join(' ') : ''
                    },
                    {
                        name: 'vertragsende-required',
                        condition: this.isInvalid('vertragsende', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Vertragsende'})
                    }
                ],
                rolloutbeginn: [
                    {
                        name: 'rolloutbeginn-isDate',
                        condition: this.isInvalid('rolloutbeginn', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Rolloutbeginn'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.rolloutbeginn != null,
                        text: (this.termineErrors.rolloutbeginn != null) ? this.termineErrors.rolloutbeginn.join(' ') : ''
                    }
                ],
                rolloutende: [
                    {
                        name: 'rolloutende-isDate',
                        condition: this.isInvalid('rolloutende', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'rolloutende'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.rolloutende != null,
                        text: (this.termineErrors.rolloutende != null) ? this.termineErrors.rolloutende.join(' ') : ''
                    }
                ],
                betriebsbeginn: [
                    {
                        name: 'betriebsbeginn-isDate',
                        condition: this.isInvalid('betriebsbeginn', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Betriebsbeginn'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.betriebsbeginn != null,
                        text: (this.termineErrors.betriebsbeginn != null) ? this.termineErrors.betriebsbeginn.join(' ') : ''
                    }
                ],
                betriebsende: [
                    {
                        name: 'betriebsende-isDate',
                        condition: this.isInvalid('betriebsende', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'betriebsende'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.betriebsende != null,
                        text: (this.termineErrors.betriebsbeginn != null) ? this.termineErrors.betriebsbeginn.join(' ') : ''
                    }
                ],
                beauftragungsende: [
                    {
                        name: 'beauftragungsende-isDate',
                        condition: this.isInvalid('beauftragungsende', 'isDate'),
                        text: this.$t.__('validation.date', {attribute: 'Beauftragungsende'})
                    },
                    {
                        name: 'termine-date',
                        condition: this.termineErrors.beauftragungsende != null,
                        text: (this.termineErrors.beauftragungsende != null) ? this.termineErrors.beauftragungsende.join(' ') : ''
                    }
                ]
            }
        },
        debitorOptions() {
            return this.debitorData.map(db => ({
                id: db.debitorId,
                text: db.nummer + ' - ' + db.name + ' (' + db.gesellschaftsnummer + ')'
            }));
        },
        versionOptions() {
            return this.versionData.map(vr => ({
                id: vr.vkVersionsId,
                text: 'V' + vr.versionsnr + ' - ' + vr.versionsgrund
            }));
        },
    },
    data() {
        return {
            selected: 'aeByEingangstor',
            options: [
                {text: 'Auftragsverantwortlichen vom Eingangstor festlegen lassen', value: 'aeByEingangstor'},
                {text: 'Auftragsverantwortlichen selbst festlegen', value: 'aeYourSelf'}
            ],
            termineErrors: [],
            isContentVisible: false,
            showValidationErrors: false,
            aeByEingangstor: true,
            aeYourSelf: false,
            form: {
                vertragsbeginn: '',
                vertragsende: '',
                rolloutbeginn: '',
                rolloutende: '',
                betriebsbeginn: '',
                betriebsende: '',
                beauftragungsende: '',
                avMember: '',
                auftragsdatum: dayjs().format('DD.MM.YYYY'),
                preorder: false,
                debitor: '',
                sapAuftragsNr: ''
            },
            pending: false,
            debitorData: [],
            versionData: []
        }
    },
    watch: {
        form(newValue, oldValue) {
            this.$emit('fill-form', this.form);
        }
    },
    methods: {
        setTermineErrors(errors) {
            this.termineErrors = errors;
        },
        switchResponsibleOption() {
            this.aeYourSelf = !this.aeYourSelf
            this.aeByEingangstor = !this.aeByEingangstor;
        },
        fillDateFields(version) {
            this.form.vertragsbeginn = this.formatedDate(version.vertragsbeginn);
            this.form.vertragsende = this.formatedDate(version.vertragsende);
            this.form.rolloutbeginn = this.formatedDate(version.rolloutbeginn);
            this.form.rolloutende = this.formatedDate(version.rolloutende);
            this.form.betriebsbeginn = this.formatedDate(version.betriebsbeginn);
            this.form.betriebsende = this.formatedDate(version.betriebsende);
            this.form.beauftragungsende = this.formatedDate(version.beauftragungsende);
        },
        formatedDate(date) {
            return (date) ? dayjs(date.date).format('DD.MM.YYYY') : '';
        },
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        changeField(value,attribute){
            this.form[attribute] = value;
        },
        async search(value) {
            let response = {data: []};
            response = await this.$axios.get('/members', {
                params: {
                    search: value,
                    right_ids: this.dataProp.finance_permission,
                }
            });
            return response;
        },
        userAdded(user) {
            this.form.avMember = user.id;
            this.form.displayName = user.display_name;
            this.form.email = user.email;
        },
        isValid() {
            this.resetBestellnummerErrors();
            this.$v.form.$touch();
            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;
                this.isContentVisible = true;
                navigateToFirstInvalid();
                return false;
            }
            return true;
        },
        userDropped() {
            this.form.avMember = null;
        }
    },
    validations: {
        form: {
            vkVersion: {required},
            auftragsdatum: {required, isDate},
            debitor: {required},
            vertragsende: {required, isDate},
            vertragsbeginn: {required, isDate},
            file: {required},
            avMember: {
                required: requiredIf(function (model) {
                    return this.aeYourSelf
                }),
            },
            sapAuftragsNr: {
                required: requiredIf((model) => (!model.preorder)),
                numeric
            },
            rolloutbeginn: {isDate},
            rolloutende: {isDate},
            betriebsbeginn: {isDate},
            betriebsende: {isDate},
            beauftragungsende: {isDate}
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    width: 64px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.people-search-component {
    width: 450px;
    position: relative;
}

.form-group {
    margin-bottom: -1rem;
}
</style>
