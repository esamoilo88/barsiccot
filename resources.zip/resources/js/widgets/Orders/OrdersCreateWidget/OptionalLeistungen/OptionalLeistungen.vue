<template>
    <div class="simple-box d-flex flex-column">
        <slot name="title"></slot>

        <b-overlay :show="pending">
            <div v-if="showTab" :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon" src="/img/icons/tools_graphical.svg" alt="price tag"/>
                <div class="d-flex flex-column">
                    <h2>Optionale Leistungen</h2>
                    <span class="text-muted secondary-text">
                      Wähle aus, ob optional angebotene Leistungen beauftragt wurden
                    </span>
                </div>
                <button @click="toggleBoxesVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible || !showTab">
                <div v-if="showTab" class="horizontal-line mb-3"></div>
                <div>
                    <div class="mt-3">
                        <b-form-checkbox v-model="isAllSelected" class="select-all-checkbox" @change="chooseAll">
                            Alle Angebotspositionen auswählen
                        </b-form-checkbox>
                    </div>
                    <table-simple
                        table-id="angebotspositionen-table"
                        :fields="fields"
                        :filters="filters"
                        :total-rows-prop="totalRows"
                        :per-page-prop="perPage"
                        :sort-by-prop="sortBy"
                        :sort-desc-prop="sortDesc"
                        :items-provider="getData"
                        ref="table"
                        class="shadow-none mt-2"
                    >
                        <template #cell(sort)="data">
                            {{ data.item.sort }}
                        </template>

                        <template #cell(bezeichnung)="data">
                            <span class="h4" v-if="data.item.isHeadline">{{ data.item.bezeichnung }}</span>
                            <template v-else>{{ data.item.bezeichnung }}</template>
                        </template>

                        <template #cell(menge)="data">
                            <template v-if="!data.item.isHeadline">
                                {{ data.item.menge }} {{ data.item.mengentypBezeichnung }}
                            </template>
                        </template>

                        <template #cell(vollkostenGesamt)="data">
                            <template v-if="!data.item.isHeadline">
                                <div class="font-weight-bold">
                                    <span class="sr-only">Stückkosten:</span>
                                    {{ $f.numberToString(data.item.stueckkosten, true) }}
                                </div>
                                <div>
                                    <span class="sr-only">Gesamtkosten:</span>
                                    {{ $f.numberToString(data.item.vollkostenGesamt, true) }}
                                </div>
                            </template>
                        </template>

                        <template #cell(einzelpreisDttsGesamt)="data">
                            <template v-if="!data.item.isHeadline">
                                <div class="font-weight-bold">
                                    <span class="sr-only">Stückpreis:</span>
                                    {{ $f.numberToString(data.item.unitPriceTp2, true) }}
                                </div>
                                <div>
                                    <span class="sr-only">Gesamtpreis:</span>
                                    {{ $f.numberToString(data.item.totalPriceTp2, true) }}
                                </div>
                            </template>
                        </template>

                        <template #cell(marge_eff)="data">
                <span
                    v-if="!data.item.isHeadline"
                    class="font-weight-bold"
                    :class="getMEStyle(data.item.marginEffective)">
                    {{ $f.numberToString(data.item.marginEffective, false) }}%
                </span>
                        </template>
                        <template #cell(angebotspositionId)="item">
                            <b-form-checkbox
                                @change="handleCheck(item.item.angebotspositionId)"
                                :key="item.item.angebotspositionId"
                                :class="'ap' + item.item.angebotspositionId"
                                :value="item.item.angebotspositionId"
                                v-model="selectedAP"
                            >
                                <span class="sr-only">{{ item.item.bezeichnung }}</span>
                            </b-form-checkbox>
                        </template>

                    </table-simple>
                </div>
            </div>
        </b-overlay>
    </div>

</template>

<script>
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BButton, BTooltip, BOverlay, BFormCheckbox} from 'bootstrap-vue';
import TableSimple from '@comp/TableSimple/TableSimple';
import SelectAPMix from "./SelectAPMix";

export default {
    name: 'optionale-leistungen',
    components: {
        ButtonIcon, BTooltip, TableSimple, BButton, BOverlay, BFormCheckbox
    },
    mixins: [SelectAPMix],
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        formData: {
            type: Object,
            required: true
        },
        showTab: {
            type: Boolean,
            default: true
        },
        filter: {
            type: Array,
            default: () => {
                return [
                    ['optional']
                ]
            }
        }
    },
    created() {
        this.$eventBus.$on('refresh-ap-list', () => this.toggleAPTable());
        this.$eventBus.$on('reset-selected-ap', () => this.resetSelectedAP());
    },
    data() {
        return {
            data: [],
            selectedAP: [],
            items: [],
            allAps: [],
            isAllSelected: false,
            isContentVisible: false,
            fields: [
                {key: 'sort', label: 'Nr', sortable: true, sortKey: 'sort', thStyle: {width: '35px'}},
                {
                    key: 'bezeichnung',
                    label: 'Angebotsposition',
                    sortable: true,
                    sortKey: 'bezeichnung',
                    thStyle: {width: '400px'}
                },
                {key: 'menge', label: 'Menge', sortable: true, sortKey: 'menge', thStyle: {width: '140px'}},
                {
                    key: 'vollkostenGesamt',
                    label: 'Kosten',
                    sortable: true,
                    sortKey: 'vollkostenGesamt',
                    thStyle: {width: '140px'}
                },
                {
                    key: 'einzelpreisDttsGesamt',
                    label: 'Preis',
                    sortable: true,
                    sortKey: 'einzelpreisDttsGesamt',
                    thStyle: {width: '140px'}
                },
                {key: 'marge_eff', label: 'Marge (eff)', thStyle: {width: '100px'}},
                {
                    key: "angebotspositionId",
                    label: "Beauftragen",
                    class: "select-ap-checkbox",
                    thStyle: {width: '140px'}
                }
            ],
            filters: [],
            sortBy: 'sort',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            pending: false
        }
    },
    methods: {
        toggleAPTable() {
            if (this.isContentVisible) {
                this.isContentVisible = false;
                setTimeout(() => this.isContentVisible = true, 300);
            }
        },
        async getData(ctx) {
            try {
                if (!this.formData.vkVersion) {
                    return null;
                }

                const response = await this.$axios.get(`/offers/${this.simpleId}/calculations/aps/${this.formData.vkVersion}`, {
                    params: {
                        currentPage: ctx.currentPage,
                        sortBy: ctx.sortBy,
                        sortDesc: ctx.sortDesc ? 1 : 0,
                        filter: this.filter
                    }
                });
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                this.items.splice(0);
                this.items.push(...response.data.data);
                this.allAps = this.items.map(item => item.angebotspositionId);
                return response.data.data;
            } catch (error) {
                return []
            }
        },
        resetSelectedAP() {
            this.selectedAP = [];
            this.selectedListAP = [];
        },
        getMEStyle(value) {
            if (value > 0) {
                return 'text-success';
            }

            if (value < 0) {
                return 'text-danger';
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.horizontal-line {
    height: 1px;
    background-color: #dee2e6;
}
</style>
