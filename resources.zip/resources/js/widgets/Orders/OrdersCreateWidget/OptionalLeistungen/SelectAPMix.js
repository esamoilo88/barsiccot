export default {
    methods: {
        addApToSelectedList(apId) {
            this.$emit('selected-aps', this.selectedAP);
            if (this.selectedAP.includes(apId)) return;
            this.selectedAP.push(apId);
            this.$emit('selected-aps', this.selectedAP);
        },
        chooseAll() {
            if (this.isAllSelected) {
                this.allAps.forEach(apId => {
                    this.addApToSelectedList(apId)
                });
            } else {
                this.allAps.forEach(apId => {
                    this.removeApFromSelectedList(apId);
                });
            }
        },
        removeApFromSelectedList(apId) {
            this.selectedListAP = this.selectedListAP.filter(item => item.angebotspositionId !== apId);
            this.selectedAP = this.selectedAP.filter(item => item !== apId);
            this.$emit('selected-aps', this.selectedAP);
        },
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        handleCheck(apId) {
            this.isApChecked(apId) ? this.addApToSelectedList(apId) : this.removeApFromSelectedList(apId);
            this.setAllSelected();
        },
        isAllAPSelectedOnPage() {
            return this.selectedAP.filter(apId => this.allAps.includes(apId)).length === this.allAps.length;
        },
        setAllSelected() {
            this.isAllSelected = this.isAllAPSelectedOnPage() && this.items.length > 0;
        },
        isApChecked(apId) {
            return this.selectedAP.lastIndexOf(apId) !== -1;
        }
    }
}
