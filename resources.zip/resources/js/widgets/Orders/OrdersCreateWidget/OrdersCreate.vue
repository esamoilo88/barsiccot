<template>
    <div>
        <div class="headline">
            <h1>
                <span class="icon-user_file-contracts-default"></span>
                Angebot beauftragen
            </h1>
            <div class="ml-auto mr-3">
                <a href="#" onclick="history.go(-1)">Zurück</a>
            </div>
            <WorkflowButton
                class="mr-3"
                :simple-id="simpleId"
                :status="status"
                :has-ae-permission="order.user.isAngebotsersteller"
                :can-reset-status-to-s0="order.can_reset_status_to_s0"
                :user="order.user"
                no-tooltip
            />
        </div>
        <HeaderData class="my-2"/>
        <div class="simple-box box-shadow my-5">
            <div class="pl-lg-2 pl-md-0 pl-sm-0 pr-0 mt-lg-0 mt-md-2 mt-sm-2">
                <div class="d-flex flex-column" @keyup.enter="create">
                    <AngebotsAuswahl
                        :data-prop="dataProp"
                        ref="angebotForm"
                        @selected-aps="selectAps"
                        @selected-version="selectVersion"
                        @fill-form="fillForm"
                        class="mb-4"/>
                    <OptionalLeistungen
                        :simple-id="simpleId"
                        ref="optionaleAP"
                        @selected-aps="selectAps"
                        :form-data="formData"
                        class="mb-4"/>
                    <ZusammenfassungEMail
                        :selected-version="selectedVersion"
                        :form-data="formData"
                        :email-names="emailRecipientsName"
                        class="mb-4"/>
                </div>
            </div>
            <button @click="create" class="btn btn-primary">
                Angebot beauftragen
            </button>
            <button @click="redirectBack" class="btn btn-secondary">Abbrechen</button>
        </div>
    </div>
</template>

<script>
import WorkflowButton from "@comp/Common/WorkflowButton/WorkflowButton";
import HeaderData from "./HeaderData";
import {BTabs, BTab, BBadge} from 'bootstrap-vue';
import AngebotsAuswahl from "./AngebotAuswahl/AngebotsAuswahl";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import OptionalLeistungen from "./OptionalLeistungen/OptionalLeistungen";
import ZusammenfassungEMail from "./ZusammenfassungEMail";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {mapGetters, mapMutations, mapState} from "vuex";

export default {
    name: "orders-create",
    components: {
        WorkflowButton,
        BTabs,
        BTab,
        BBadge,
        HeaderData,
        AngebotsAuswahl,
        OptionalLeistungen,
        ZusammenfassungEMail
    },
    mixins: [ScalarsProcessing],
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            headerData: {
                thema: '-',
                kundenname: '-',
            },
            selectedVersion: null,
            errorTermineValidation: [],
            showValidationErrors: false,
            formData: {},
            emailRecipientsName: {}
        }
    },
    computed: {
        ...mapState({
            order: state => state.order.order,
        }),
        ...mapGetters({
            simpleId: 'order/simpleId',
            status: 'order/status'
        }),
    },
    created() {
        this.setOrder(this.dataProp);
    },
    mounted() {
        this.headerData.thema = this.dataProp.globalGate.thema;
        this.headerData.kundenname = this.dataProp.kundenname;
    },
    methods: {
        ...mapMutations({
            setOrder: "order/SET_ORDER"
        }),
        selectAps(apIds) {
            this.formData.getApIds = (apIds) ? apIds : [];
        },
        async fillForm(items) {
            this.formData = items;
            await this.detectRecipientsConfigNames();
        },
        async detectRecipientsConfigNames() {
            if(this.formData.vkVersion) {
                const version = this.formData.vkVersion;
                try {
                    const response = await this.$axios.get('/orders/send-mail/detect-recipients-names/' + version);
                    this.emailRecipientsName = response.data;
                } catch (error) {
                    window.flash.showMessagesFromAjax(error.response);
                }
            }
        },
        async create() {
            if (!this.$refs.angebotForm.isValid()) {
                return;
            }
            try {
                window.preloader.show();
                const res = await this.$axios.post('/orders/' + this.simpleId + '/store', this.formData);

                this.errorTermineValidation = [];
                if (res.data.errorTermineValidation != null) {
                    this.errorTermineValidation = res.data.errorTermineValidation;
                    this.$refs.angebotForm.setTermineErrors(this.errorTermineValidation);
                    window.flash.error('Ungültige Terminangaben vorhanden.');
                    navigateToFirstInvalid();
                    window.preloader.hide();
                } else {
                    window.flash.showMessagesFromAjax(res.data.text, 'success');
                    window.location.href = res.data.redirect;
                    window.preloader.hide();
                }
            } catch (error) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(error.response.data);
                if (error.response.data.errors) {
                    this.$refs.angebotForm.setBestellnummerErrors(error.response.data.errors.sapBestellnummer);
                    navigateToFirstInvalid();
                }
            }
        },
        redirectBack() {
            history.go(-1);
        },
        selectVersion(version) {
            this.selectedVersion = version;
        }

    }
}
</script>

<style lang="scss" scoped>

</style>
