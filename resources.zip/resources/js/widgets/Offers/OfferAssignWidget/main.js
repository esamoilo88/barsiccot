import Vue from 'vue';
import {$axios} from '../../../boot';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import OfferAssignWidget from "res/js/widgets/Offers/OfferAssignWidget/OfferAssignWidget";

Vue.prototype.$axios = $axios;
Vue.use(Vuelidate);
const translations = require('res/lang/lang.translations.json');

const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;

new Vue({
    el: "#angebot_assign", //resources/views/App/Angebote/Vorhaben/create_vorhaben.blade.php');
    components: {
        OfferAssignWidget
    }
});
