<template>
    <div>
        <headline :sin="data.sin" :customer="data.customer" :project-name="data.projectName"></headline>
        <div class="content">
            <table-simple
                table-id="projects-list-table"
                :fields="fields"
                :filters="filters"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="itemsProvider"
            >
                <template #cell(optionen)="row">
                    <ButtonIcon
                        icon-class="icon-user-plus"
                        :id="'angebot-anfordern-btn-' + row.item.simpleId"
                        variant="primary"
                        @click="assign(row.item.userId)"
                        title="Angebotsersteller zuordnen"
                    />
                </template>
            </table-simple>
            <a class="link" href="/requests">Zurück zur Anfrageliste</a>
        </div>
    </div>
</template>

<script>
import Headline from "@comp/Headline/Headline";
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";

export default {
    name: "OfferAssign",
    components: {Headline, TableSimple, ButtonIcon},
    props: {
        data: {
            type: Object
        }
    },
    data() {
        return {
            fields: [
                {key: "user", label: "Angebotsersteller", sortable: true, sortDirection: 'desc', sortKey: 'user'},
                {key: "department", label: "Bereich", sortKey: 'department'},
                {key: "count", label: "Offene Angebote", sortable: false, sortKey: 'count'},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            filters: [
                {
                    field: "search",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'user',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            users: []
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/users/assign', ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                this.users = response.data.data;
                return response.data.data;
            } catch (err) {
                window.preloader.hide();
            }
        },
        async assign(userId) {
            window.preloader.show();
            try {
                const response = await this.$axios.post('/offers/' + this.data.sin + '/assign', {userId});
                window.preloader.hide();
                window.flash.showMessagesFromAjax(response.data.text, 'success');
                window.location.href = response.data.redirect;
            } catch (err) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(err.response.data.text, 'error');
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
    ::v-deep .optionen-col {
        text-align: left;
    }
    ::v-deep th[role=columnheader] {
        color: $primary;
        &:last-child {
            color: black;
        }
    }
    .content {
        position: relative;
    }
    .link {
        position: absolute;
        right: 0;
        margin-right: 5px;
        top: 30px;
    }
</style>