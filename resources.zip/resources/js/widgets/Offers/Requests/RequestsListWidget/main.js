import Vue from 'vue';
import {$axios} from 'res/js/boot';
import RequestsList from "./RequestsList";
import Formatter from "res/js/utils/formatter";

Vue.prototype.$axios = $axios;
Vue.prototype.$f = new Formatter();

export default new Vue({
    el: '#requests-list', //resources/views/App/Offers/Requests/list.blade.php
    components: {
        RequestsList
    }
});
