<template>
    <div class="more-request-data py-2 row">
        <div class="col-lg-9">
            <div class="mt-2"><b>Portfolio</b></div>
            <div>
                <b-spinner v-if="portfolios === null" small label="wird heruntergeladen"></b-spinner>
                <div v-else-if="Array.isArray(portfolios) && portfolios.length > 0">
                    <div v-for="portfolio in portfolios" :key="portfolio.label.bezeichnung">
                        {{ portfolio.label.bezeichnung }} ({{ portfolio.prozent }}%)
                    </div>
                </div>
                <div v-else>-</div>
            </div>
            <div class="mt-2"><b>Volumen</b></div>
            <div>{{ $f.numberToString(request.volumenDtts, true) }}</div>
        </div>
        <div class="col-lg-8">
            <div class="mt-2"><b>Liegezeit Soll</b></div>
            <div>{{ defVal(request.liegezeitSoll, '-') }} <span v-if="request.liegezeitSoll">Stunden</span></div>
            <div class="mt-2"><b>Liegezeit Ist</b></div>
            <div>{{ defVal(request.liegezeitIst, '-') }} <span v-if="request.liegezeitIst">Stunden</span></div>
        </div>
        <div class="col-lg-7">
            <div class="mt-2"><b>Auftragswahrscheinlichkeit</b></div>
            <div>{{ defVal(request.auftragswahrscheinlichkeit, '-') }} <span v-if="request.auftragswahrscheinlichkeit">%</span></div>
            <div class="mt-2"><b>Angebotsersteller</b></div>
            <div>{{ defVal(request.benutzername, '-') }}</div>
        </div>
    </div>
</template>

<script>
import {BSpinner} from 'bootstrap-vue';
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";

export default {
    name: "RequestMoreData",
    components: {
        BSpinner
    },
    mixins: [ScalarsProcessing],
    props: {
        request: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            portfolios: null
        }
    },
    async mounted() {
        const response = await this.$axios.get('/projects/' + this.request.simpleId + '/portfolios');
        this.portfolios = response.data;
    }
}
</script>

<style lang="scss" scoped></style>
