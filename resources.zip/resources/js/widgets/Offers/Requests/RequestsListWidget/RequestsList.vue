<template>
    <div>
        <table-simple
            table-id="requests-list-table"
            ref="table"
            :fields="fields"
            :filters="filters"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
        >
            <template #head(lu)="data">
                <div>
                    <span title="Liegezeit überschritten">{{ data.label }}</span>
                </div>
            </template>

            <template #cell(lu)="data">
                <span
                    v-if="data.item.liegezeitSoll < data.item.liegezeitIst"
                    :key="'liegezeit-' + data.item.simpleId"
                    class="icon-alert-warning-default"
                    title="Liegezeit überschritten">
                </span>
            </template>

            <template #cell(simpleId)="data">
                <a :href="'/projects/' + data.item.simpleId">SIN/{{ data.item.simpleId }}</a>
            </template>

            <template #cell(status)="data">
                <badge :color="data.item.status.color">{{ data.item.status.shortName }}</badge>
            </template>

            <template #cell(lieferterminAngebot)="data">
                {{ formatLiefertermin(data.item.lieferterminAngebot) }}
            </template>

            <template #cell(optionen)="row">
                <ButtonIcon
                    icon-class="icon-user-plus"
                    variant="primary"
                    :id="'assign-offer-creator-btn-' + row.item.simpleId"
                    title="Angebotsersteller zuweisen"
                    @click="openAssignPage(row.item.simpleId)"
                />
                <ButtonIcon
                    icon-class="icon-cancel-circle"
                    variant="danger"
                    :id="'cancel-project-btn-' + row.item.simpleId"
                    title="Vorhaben stornieren"
                    @click="openCancelPage(row.item.simpleId)"
                />
                <ButtonIcon
                    @click="row.toggleDetails"
                    :disabled="isLoaded"
                    button-class="btn-icon-link details_class"
                    icon-class="icon-action-more-selected"
                    :id="'more-request-data-btn-' + row.item.simpleId"
                    :title="row.item._showDetails ? 'Schließen weitere Daten':'Zeige weitere Daten'"
                />
            </template>

            <template #row-details="row">
                <QuickViewSlot>
                    <RequestMoreData
                        class="px-1 py-1"
                        :request="row.item"
                    />
                </QuickViewSlot>
            </template>
        </table-simple>
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import Badge from "@comp/Badge/Badge";
import dayjs from 'res/js/utils/day';
import QuickViewMixin from "res/js/utils/Mixins/QuickView/QuickViewMixin";
import RequestMoreData from "./components/RequestMoreData";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";

export default {
    name: "requests-list",
    components: {
        TableSimple, ButtonIcon, Badge, RequestMoreData, QuickViewSlot
    },
    mixins: [QuickViewMixin],
    props: {
        prioritaetOptions: {
            type: Array,
            required: false,
            default: []
        },
        regionOptions: {
            type: Array,
            required: false,
            default: []
        }
    },
    mounted() {
        this.$refs.table.makeTableBusy(true);
        this.isLoaded = true;
    },
    data() {
        return {
            isLoaded: false,
            fields: [
                {key: "lu", label: "LÜ"},
                {key: "simpleId", label: "SIN", sortable: true, sortDirection: 'desc', sortKey: 'simpleId'},
                {key: "vorhabenname", sortable: true, sortKey: 'vorhabenname', label: "Vorhabenname"},
                {key: "kundenname", sortable: true, sortKey: 'kundenname', label: "Kundenname"},
                {key: "status", sortable: true, sortKey: 'status', label: "Status"},
                {key: "lieferterminAngebot", sortable: true, sortKey: 'lieferterminAngebot', label: "Liefertermin"},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            filters: [
                {
                    field: "status",
                    type: "select",
                    settings: {label: "Status", preselected: '1', options: [
                        {id: "1", text: "Offene Anfragen"}, {id: "2-3", text: "Zugeordnete Anfragen"},
                        {id: ">7", text: "Abgelehnte Anfragen"}, {id: "4-6", text: "Angebote und Aufträge"}
                    ]}
                },
                {
                    field: "prioritaet",
                    type: "select",
                    settings: {label: "Priorität", options: [{id: "empty", text: ""}, ...this.prioritaetOptions]}
                },
                {
                    field: "liegezeit",
                    type: "select",
                    settings: {label: "Liegezeit", options: [
                        {id: "empty", text: ""}, {id: "liegezeit", text: "Liegezeit Soll überschritten"}
                    ]}
                },
                {
                    field: "kundenregion",
                    type: "select",
                    settings: {searchable: true, label: "Kundenregion", options: [{id: "empty", text: ""}, ...this.regionOptions]}
                },
                {
                    field: "search",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'simpleId',
            sortDesc: true,
            totalRows: 0,
            perPage: 0
        }
    },
    methods: {
        formatLiefertermin(val) {
            if (val === null) {
                return '';
            }
            return dayjs(val).format('DD.MM.YYYY');
        },
        async itemsProvider(ctx, cancelToken) {
            this.$refs.table.makeTableBusy(true);

            const response = await this.$axios.post('/requests/list', ctx, {cancelToken: cancelToken.token});
            this.totalRows = response.data.total;
            this.perPage = response.data.perPage;
            this.isLoaded = false;

            return response.data.data;
        },
        openAssignPage(simpleId) {
            window.location.href = `/offers/${simpleId}/assign`;
        },
        openCancelPage(simpleId) {
            window.location.href = `/projects/${simpleId}/cancel/form`;
        }
    }
}
</script>

<style scoped>
::v-deep button.btn-icon {
    padding: 5px 7px;
}

::v-deep .btn-icon__icon {
    font-size: 21px;
}

::v-deep td.optionen-col {
    padding: 7px 0;
}

</style>
