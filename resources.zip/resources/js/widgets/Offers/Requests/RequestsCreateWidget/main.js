import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Vuelidate from "vuelidate";
import RequestsCreate from "./RequestsCreate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

Vue.prototype.$axios = $axios;
Vue.use(Vuelidate);
const translations = require('res/lang/lang.translations.json');

const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;

new Vue({
    el: "#angebot_request", //resources/views/App/Offers/Requests/create.blade.php');
    components: {
        RequestsCreate
    }
});
