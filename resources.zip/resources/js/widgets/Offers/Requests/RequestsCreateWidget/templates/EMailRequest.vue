<template>
    <div class="simple-box border row d-flex p-5 mb-5">
        <div class="w-100">
            <h2>E-Mail Anfrage</h2>
            <p>Die E-Mail Anfrage wird an das Eingangstor <a href="Entry-Gate-ISP-Solutions@telekom.de">
                FMB Entry Gate ISP Solutions</a> gesendet.</p>
        </div>
        <div class="col-xl-10 col-lg-10 col-md-18 col-sm-20 mb-2 form-fields-wrapper mr-5 pl-0">
            <div>
                <PeopleSearch type="ldap" label="CC Empfänger"
                              @user-added="userAdded"></PeopleSearch>
            </div>
            <MultipleFileLoad
                v-model="attachedfile"
                @uploadFiles="uploadFiles"
                title="Dateianlagen"
                name="attachedfile"
                browse-text="Dateien auswählen"
                input-id="Dateien"/>
        </div>
        <div class="col-xl-10 col-lg-10 col-md-18 col-sm-20 mb-2 d-flex flex-column">
            <FormTextArea
                input-id="text"
                v-model="nachricht"
                @handleTextArea="handleTextArea"
                label-text="Ergänzende Nachricht an das Eingangstor"
                name="nachricht"
                class="w-100 mb-3"
                rows="10"/>
        </div>
    </div>
</template>
<script>
import {BButton} from 'bootstrap-vue';
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import MultipleFileLoad from "@comp/FileLoad/MultipleFileLoad";
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import UserCardDialog from "@comp/Common/Ldap/UserCardDialog";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import FormInput from "@comp/FormInput/FormInput";

export default {
    name: "eMailRequest-template",
    components: {
        MultipleFileLoad,
        FormTextArea,
        BButton,
        PeopleSearch,
        UserCardDialog,
        ButtonIcon,
        FormInput
    },
    data() {
        return {
            filesInfo: null,
            emailsCC: [],
            isVisible: false,
            email: '',
            attachedfile: [],
            nachricht: ''
        }
    },

    methods: {
        userAdded(value) {
            this.emailsCC.push(value.email);
            this.$emit('userAdded', this.emailsCC);

        },
        handleTextArea(nachricht) {
            this.nachricht = nachricht
            this.$emit('handleTextArea', this.nachricht);
        },
        uploadFiles(filesInfo) {
            this.filesInfo = filesInfo;
            this.$emit('uploadFiles', this.filesInfo);

        }
    }
}
</script>
<style scoped>
.people-search-component {
    width: 450px;
    position: relative;
}
</style>

