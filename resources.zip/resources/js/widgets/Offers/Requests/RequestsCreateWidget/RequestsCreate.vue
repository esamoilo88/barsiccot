<template>
    <div class="justify-content-center">
        <div class="d-flex justify-content-center">
            <div id="offer-form" class="p-4 w-100">
                <div class="w-100"><h1>Angebot anfordern</h1></div>
                <p>Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>
                <form id="offerRequest" method="post" @keyup.enter="offerRequest">
                    <div class="simple-box border row d-flex p-5 mb-5">
                        <div class="w-100">
                            <h2>Plantermine</h2>
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-18 col-sm-20 mb-2 form-fields-wrapper mr-5 pl-0">
                            <FormDatepicker
                                v-model="vertragsbeginn"
                                name="vertragsbeginn"
                                class="w-100 mb-3"
                                label-text="Geplanter Vertragsbeginn*"
                                input-id="vertragsbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'empty-date',
                                        condition: !$v.vertragsbeginn.required  && $v.vertragsbeginn.$dirty,
                                        text: $t.__('validation.offer.vertragsbeginn.required')
                                    },
                                              {
                                        name: 'not-date',
                                        condition: !$v.vertragsbeginn.isDate && $v.vertragsbeginn.$dirty,
                                        text: $t.__('validation.offer.vertragsbeginn.isDate')
                                    },
                                              {
                                        name: 'termine-date',
                                        condition: errorTermineValidation.vertragsbeginn !=null,
                                        text: (errorTermineValidation.vertragsbeginn !=null)?errorTermineValidation.vertragsbeginn.join(' '):''
                                    }
                                ]"
                            />
                            <FormDatepicker
                                v-model="vertragsende"
                                name="vertragsende"
                                class="w-100 mb-5"
                                label-text="Geplantes Vertragsende*"
                                input-id="vertragsende-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'empty-date',
                                        condition: !$v.vertragsende.required && $v.vertragsende.$dirty,
                                        text: $t.__('validation.offer.vertragsende.required')
                                    },
                                     {
                                        name: 'not-valid-date',
                                        condition: !$v.vertragsende.isDate && $v.vertragsende.$dirty,
                                        text: $t.__('validation.offer.vertragsende.isDate')
                                    },
                                    {
                                        name: 'termine-date',
                                        condition: errorTermineValidation.vertragsende !=null,
                                        text: (errorTermineValidation.vertragsende !=null)?errorTermineValidation.vertragsende.join(' '):''
                                    }
                                ]"
                            />
                            <FormDatepicker
                                v-model="liefertermin_angebot"
                                name="liefertermin_angebot"
                                class="w-100 mb-3"
                                label-text="Liefertermin Angebot*"
                                input-id="liefertermin_angebot-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'empty-date',
                                        condition: !$v.liefertermin_angebot.required && $v.liefertermin_angebot.$dirty,
                                        text: $t.__('validation.offer.liefertermin_angebot.required')
                                    },
                                    {
                                        name: 'not-valid-date',
                                        condition: !$v.liefertermin_angebot.isDate && $v.liefertermin_angebot.$dirty,
                                        text: $t.__('validation.offer.liefertermin_angebot.isDate')
                                    },
                                    {
                                        name: 'termine-date',
                                        condition: errorTermineValidation.lieferterminAngebot !=null,
                                        text: (errorTermineValidation.lieferterminAngebot !=null)?errorTermineValidation.lieferterminAngebot.join(' '):''
                                    }
                                ]"
                            />
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-18 col-sm-20 mb-2 d-flex flex-column">
                            <FormDatepicker
                                v-model="rolloutbeginn"
                                name="rolloutbeginn"
                                class="w-100 mb-3"
                                label-text="Geplanter Realisierungsbeginn"
                                input-id="rolloutbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'not-valid-date',
                                        condition: !$v.rolloutbeginn.isDate && $v.rolloutbeginn.$dirty,
                                        text: $t.__('validation.offer.rolloutbeginn.isDate')
                                    },
                                    {
                                        name: 'termine-date',
                                        condition:  errorTermineValidation.rolloutbeginn !=null,
                                        text: (errorTermineValidation.rolloutbeginn !=null)?errorTermineValidation.rolloutbeginn.join(' '):''
                                    }
                                ]"
                            />
                            <FormDatepicker
                                v-model="rolloutende"
                                name="rolloutende"
                                class="w-100 mb-5"
                                label-text="Geplantes Realisierungsende"
                                input-id="rolloutende-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'not-valid-date',
                                        condition: !$v.rolloutende.isDate && $v.rolloutende.$dirty,
                                        text: $t.__('validation.offer.rolloutende.isDate')
                                    },
                                   {
                                        name: 'termine-date',
                                        condition:  errorTermineValidation.rolloutende !=null,
                                        text: (errorTermineValidation.rolloutende !=null)?errorTermineValidation.rolloutende.join(' '):''
                                    }
                                ]"
                            />
                            <FormDatepicker
                                v-model="betriebsbeginn"
                                name="betriebsbeginn"
                                class="w-100 mb-3"
                                label-text="Geplanter Betriebsbeginn"
                                input-id="betriebsbeginn-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'not-valid-date',
                                        condition: !$v.betriebsbeginn.isDate && $v.betriebsbeginn.$dirty,
                                        text: $t.__('validation.offer.betriebsbeginn.isDate')
                                    },
                                    {
                                        name: 'termine-date',
                                        condition: errorTermineValidation.betriebsbeginn !=null,
                                        text: (errorTermineValidation.betriebsbeginn !=null)?errorTermineValidation.betriebsbeginn.join(' '):''
                                    }
                                ]"
                            />
                            <FormDatepicker
                                v-model="betriebsende"
                                name="betriebsende"
                                class="w-100 mb-3"
                                label-text="Geplantes Betriebsende"
                                input-id="betriebsende-input"
                                aria-controls="date-input"
                                :error-conditions="[
                                    {
                                        name: 'not-valid-date',
                                         condition: !$v.betriebsende.isDate && $v.betriebsende.$dirty,
                                        text: $t.__('validation.offer.betriebsende.isDate')
                                    },
                                    {
                                        name: 'termine-date',
                                        condition:  errorTermineValidation.betriebsende !=null ,
                                        text: (errorTermineValidation.betriebsende !=null)?errorTermineValidation.betriebsende.join(' '):''
                                    }
                                ]"
                            />

                        </div>
                    </div>
                    <EMailRequest
                        @uploadFiles="uploadFiles"
                        @handleTextArea="handleTextArea"
                        @userAdded="userAdded"
                    />
                </form>
                <div class="mt-2">
                    <b-button @click="offerRequest" class="btn btn-lg btn-primary px-4 mr-3" variant="primary"
                              type="button">
                        Angebot anfordern
                    </b-button>
                    <b-button @click="redirectBack" class="btn btn-lg px-4" type="button">
                        Abbrechen
                    </b-button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import {BButton} from 'bootstrap-vue';
import {required} from 'vuelidate/lib/validators';
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import EMailRequest from "res/js/widgets/Offers/Requests/RequestsCreateWidget/templates/EMailRequest";
import {isDate} from 'res/js/utils/Validators/DatesValidators'


export default {
    name: "requests-create",
    components: {
        FormDatepicker,
        BButton,
        ButtonIcon,
        EMailRequest
    },
    props: {
        simpleId: {
            type: String
        }
    },
    data() {
        return {
            filesInfo: null,
            emailsCC: null,
            isVisible: false,
            errorTermineValidation: [],
            vertragsbeginn: '',
            vertragsende: '',
            liefertermin_angebot: '',
            rolloutbeginn: '',
            rolloutende: '',
            betriebsbeginn: '',
            betriebsende: '',
            attachedfile: [],
            nachricht: ''
        }
    },
    methods: {
        redirectBack() {
            history.go(-1);
        },
        uploadFiles(filesInfo) {
            this.filesInfo = filesInfo;
        },
        handleTextArea(nachricht) {
            this.nachricht = nachricht;
        },
        userAdded(emailCC) {
            this.emailsCC = emailCC;
        },
        async offerRequest() {
            this.$v.$touch();
            if (!this.$v.$anyError) {
                window.preloader.show();
                let data = {
                    vertragsbeginn: this.vertragsbeginn,
                    vertragsende: this.vertragsende,
                    lieferterminAngebot: this.liefertermin_angebot,
                    rolloutbeginn: this.rolloutbeginn,
                    rolloutende: this.rolloutende,
                    betriebsbeginn: this.betriebsbeginn,
                    betriebsende: this.betriebsende,
                    attachedfile: this.attachedfile,
                    nachricht: this.nachricht,
                    emailsCC: this.emailsCC
                }
                try {
                    this.errorTermineValidation = [];
                    if (this.filesInfo !== null) {
                        await this.$axios.post('/file/getPath', this.filesInfo.formData, this.filesInfo.config).then(
                            response => {
                                this.attachedfile = response.data.filesPath.map((elem, key) => {
                                    return {
                                        'savePath': elem['tempPath'],
                                        'size': elem['size'],
                                        'name': this.filesInfo.fileNames[key]
                                    }
                                })
                            }
                        );
                    }
                    data.attachedfile = this.attachedfile;
                    const response = await this.$axios.post('/offers/' + this.simpleId + '/request', data);
                    if (response.data.errorTermineValidation != null) {
                        window.scrollTo(0, 0);
                        this.errorTermineValidation = response.data.errorTermineValidation;
                        window.flash.showMessagesFromAjax(response.data.message, 'error');
                        window.preloader.hide();
                    } else {
                        window.location.href = response.data.redirect;
                        window.preloader.hide();
                    }
                } catch (error) {
                    window.preloader.hide();
                    window.flash.error(error.response.data.text, 'error');
                }

            } else {
                window.scrollTo(0, 0);
                window.flash.showMessagesFromAjax('Ungültige Terminangaben   vorhanden', 'error');
                window.preloader.hide();
            }
        }
    },

    validations: {
        vertragsbeginn: {required, isDate},
        vertragsende: {required, isDate},
        liefertermin_angebot: {required, isDate},
        rolloutbeginn: {isDate},
        rolloutende: {isDate},
        betriebsbeginn: {isDate},
        betriebsende: {isDate},
    }
}

</script>
<style lang="scss" scoped>
@import 'resources/sass/variables';

#offer-form {
    position: relative;

    &::before {
        content: '';
        height: 100%;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
        z-index: -1;

    }
}

.border {
    border-radius: 5px;
    box-shadow: 0 0px 5px rgba(0, 0, 0, 0.1);
}

.form-fields-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
}

h2 {
    font-size: $h2-font-size;
    font-weight: bold;
}

h3 {
    font-size: $font-size-base;
}

::v-deep .btn-secondary {
    border: 1px solid #b2b2b2;;
}
</style>
