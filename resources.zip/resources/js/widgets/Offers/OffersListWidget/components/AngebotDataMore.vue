<template>
    <div class="more-angebote-data py-2 row">
        <div class="spinner" v-if="details === []">
            <b-spinner label="wird heruntergeladen"></b-spinner>
        </div>
        <div class="d-flex w-100" v-else>

            <div class="col-lg-8">
                <div class="mt-2"><b>Versions-Nr</b></div>
                <div>{{ defVal(details.version, '-') }}</div>
                <div class="mt-2"><b>Angebot angefordert</b></div>
                <div>{{ dateFormatted(details.angebotAngefordertAm) }}</div>
            </div>
            <div class="col-lg-8">
                <div class="mt-2"><b>Gesamtkosten</b></div>
                <div>{{ $f.numberToString(details.vkGesamt, true, true, '-') }}</div>
                <div class="mt-2"><b>Bearbeitung begonnen</b></div>
                <div>{{ dateFormatted(details.bearbeitungBegonnenAm) }}</div>
            </div>
            <div class="col-lg-8">
                <div class="mt-2"><b>Gesamtpreis</b></div>
                <div>-</div>
                <div class="mt-2"><b>Angebot fertiggestellt</b></div>
                <div>{{ dateFormatted(details.weitergeleitetAm) }}</div>
            </div>
        </div>
    </div>

</template>

<script>
import dayjs from "res/js/utils/day";
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";
import {BSpinner} from 'bootstrap-vue';

export default {
    name: "angebot-data-more",
    components: {BSpinner},
    mixins: [ScalarsProcessing],
    props: {
        request: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            details: []
        }
    },
    async mounted() {
        let response = await this.$axios.get('offers/getDetails/' + this.request.simpleId);
        this.details = response.data.data;
    },
    methods: {
        dateFormatted(val) {
            if (val === undefined || val == null || !dayjs(val.date).isValid()) {
                return '-';
            } else {
                return dayjs(val.date, "YYYY-MM-DDTh:mm:ss").format('DD.MM.YYYY H:mm');
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.spinner {
    position: relative;
    padding: 40px;
    left: 45%
}
</style>
