<template>
    <table-simple
        table-id="offers-list-table"
        :fields="fields"
        :filters="filters"
        :total-rows-prop="totalRows"
        :per-page-prop="perPage"
        :sort-by-prop="sortBy"
        :sort-desc-prop="sortDesc"
        :items-provider="itemsProvider"
        ref="table"
    >
        <template #cell(simpleId)="data">
            <a :href="'/offers/' + data.item.simpleId">SIN/{{ data.item.simpleId }}</a>
        </template>

        <template #cell(volume)="data">
            {{ $f.numberToString(data.item.volume, true, true) }}
        </template>

        <template #cell(status)="data">
            <badge :color="data.item.color">{{ data.item.shortName }}</badge>
        </template>

        <template #cell(optionen)="row">
            <ButtonIcon
                icon-class="icon-calculator1"
                :id="'kalkulation-offnen-btn-' + row.item.simpleId"
                title="Kalkulation öffnen"
                variant="primary"
            />
            <ButtonIcon
                icon-class="icon-action-succsess-default"
                :id="'angebot-fertigstellen-btn-' + row.item.simpleId"
                title="Angebot fertigstellen"
            />
            <ButtonIcon
                icon-class="icon-user_file-contracts-default"
                :id="'angebot-fertigstellen-btn-' + row.item.simpleId"
                title="Angebot beauftragen"
            />
            <ButtonIcon
                button-class="btn-icon-link details_class"
                icon-class="icon-action-more-selected"
                :id="'angebot-fertigstellen-btn-' + row.item.simpleId"
                @click="toggleRow('', row, 'simpleId')"
                :title="row.item._showDetails ? 'Schließen weitere Optionen':'Zeigen weitere Optionen an'"
            />
        </template>
        <template #row-details="row">
            <div class="d-flex">
                <QuickViewSlot class="w-75">
                    <AngebotDataMore
                        :request="row.item"
                    />
                </QuickViewSlot>
                <button-list
                    class="w-25"
                    @click="handleClick"
                    :content="buttonsList"
                    :simple-id="row.item.simpleId"
                />
            </div>
            <div class="row-details-bottom"></div>
        </template>
    </table-simple>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import Badge from "@comp/Badge/Badge";
import AngebotDataMore from "./components/AngebotDataMore";
import ButtonList from "@comp/ButtonListe/ButtonList";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import QuickViewMixin from "res/js/utils/Mixins/QuickView/QuickViewMixin";

export default {
    name: "offers-list-widget",
    components: {
        TableSimple, ButtonIcon, Badge, AngebotDataMore, ButtonList, QuickViewSlot
    },
    mixins: [QuickViewMixin],
    data() {
        return {
            fields: [
                {key: "simpleId", label: "SIN", sortable: true, sortDirection: 'desc', sortKey: 'simpleId'},
                {key: "name", label: "Vorhabenname", sortable: true, sortKey: 'name'},
                {key: "client", label: "Kundenname", sortable: true, sortKey: 'client'},
                {key: "status", label: "Status", sortable: true, sortKey: 'status'},
                {key: "volume", label: "Netto-AE", sortable: true, sortKey: 'volume'},
                {key: "optionen", label: "Optionen", class: 'optionen-col', sortable: false}
            ],
            buttonsList: [
                {name: "Bearbeitung beginnen", icon: "icon-action-play_nb-selected"},
                {name: "Vorhaben stornieren", icon: "icon-action-circle-close-default"}
            ],

            filters: [
                {
                    field: "status",
                    type: "select",
                    settings: {
                        preselected: 'offene',
                        label: "Status",
                        options: [
                            {id: "offene", text: "Offene Angebote"},
                            {id: "erledigte", text: "Erledigte Angebote"},
                            {id: "beauftragte", text: "Beauftragte Angebote"},
                            {id: "stornierte", text: "Stornierte Angebote"},
                            {id: "alle", text: "Alle Angebote"}
                        ]
                    }
                },
                {
                    field: "suchen",
                    type: "text",
                    settings: {label: "Suchen..."}
                }
            ],
            sortBy: 'simpleId',
            sortDesc: true,
            totalRows: 0,
            perPage: 0
        }
    },
    methods: {
        async itemsProvider(ctx, cancelToken) {
            try {
                const response = await this.$axios.post('/offers/list', ctx, {cancelToken: cancelToken.token});
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        handleClick(data) {
            if (data.key === 'Bearbeitung beginnen') {
                this.startOffer(data.simpleId);
            }

            if (data.key === 'Vorhaben stornieren') {
                window.location.href = `/projects/${data.simpleId}/cancel/form`;
            }
        },
        async startOffer(simpleId) {
            let items = this.$refs.table.items;

            const project = items.filter(function (item) {
                if (item.simpleId === simpleId) {
                    return item;
                }
            });

            if (project[0].shortName !== 'S2') {
                window.flash.showMessagesFromAjax('Die Funktion kann nur im Status S2 aufgerufen werden.', 'error');
                return;
            }

            const result = await this.$bvModal.msgBoxConfirm('Bitte bestätige den Start der Angebotserstellung.', {
                okTitle: 'Bestätigen',
                cancelTitle: 'Abbrechen',
            });

            if (!result) return;

            window.preloader.show();

            try {
                const response = await this.$axios.post('/offers/' + simpleId + '/start');
                window.preloader.hide();
                window.flash.showMessagesFromAjax(response.data.text, 'success');
                window.location.href = response.data.redirect;
            } catch (err) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(err.response.data.text, 'error');
            }
        }
    }
}
</script>
<style scoped>

::v-deep .btn-icon__icon {
    font-size: 21px;
}
</style>
