import Vue from 'vue';
import {$axios} from 'res/js/boot';
import OffersListWidget from "../OffersListWidget/OffersListWidget";
import Formatter from "../../../utils/formatter";
import { ModalPlugin } from 'bootstrap-vue';


Vue.prototype.$axios = $axios;
Vue.prototype.$f = new Formatter();
Vue.use(ModalPlugin);


export default new Vue({
    el: '#offers-list', //resources/views/App/Offers/list.blade.php
    components: {
        OffersListWidget
    }
});
