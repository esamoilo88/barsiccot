import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import configurators from './modules/configurators.store';
import offer from "./modules/offer.store";
import configurations from './modules/configurations.store';
import cockpit from './modules/cockpit.store'

const store = new Vuex.Store({
    modules: {
        configurators,
        configurations,
        offer,
        cockpit

    }
});

store.$axios = $axios;

export default store;
