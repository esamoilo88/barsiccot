export default {
    namespaced: true,
    state: {
        configurators: []
    },
    mutations: {
        SET_CONFIGURATORS(state, configurators) {
            state.configurators = [...configurators];
        },
    },
    actions: {
        async fetchConfigurators(context) {
            try {
                const response = await this.$axios.get('/onka/getAllConfigurators');
                context.commit('SET_CONFIGURATORS', response.data);
            } catch (err) {
                console.error('Couldn\'t fetch configurators', err);
            }
        }
    }
}
