export default {
    namespaced: true,
    state: {
        configurations: []
    },
    mutations: {
        SET_CONFIGURATIONS(state, configurations) {
            state.configurations = [...configurations];
        },
        ADD_CONFIGURATION(state, configuration) {
            state.configurations.push(configuration);
        },
        REMOVE_CONFIGURATION(state, configurationId) {
            state.configurations = state.configurations.filter(conf => conf.id !== configurationId);
        },
        UPDATE_NAME(state, {configurationId, name}) {
            const conf = state.configurations.find(conf => conf.id == configurationId);

            if (conf) {
                conf.name = name;
            }
        }
    },
    actions: {
        /**
         * Fetch configuration for specific project
         * @param context
         * @param simpleId
         * @param vkVersionId
         * @returns {Promise<void>}
         */
        async fetchConfigurations(context, {simpleId, vkVersionId}) {
            try {
                if (simpleId) {
                    const response = await this.$axios.get(`/onka/${simpleId}/configurations/${vkVersionId}`);
                    context.commit('SET_CONFIGURATIONS', response.data);
                } else {
                    console.error('simpleId is not provided!');
                }
            } catch (err) {
                console.error('Couldn\'t fetch configurations', err);
            }
        },

        /**
         * Create configuration for specific project
         * @param context
         * @param configuratorId
         * @param simpleId
         * @param vkVersionId
         */
        async createConfiguration(context, {configurator, simpleId, vkVersionId}) {
            try {
                if (simpleId) {
                    const response = await this.$axios.post(`/onka/${simpleId}/configurations`, {
                        configuratorId: configurator.id
                    });
                    response.data.subtext = configurator.subtext;
                    await context.dispatch('fetchConfigurations', {simpleId, vkVersionId});
                    return response.data;
                } else {
                    console.error('simpleId is not provided!');
                    return false;
                }
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error('Couldn\'t create configurations', err);
                return false;
            }
        },

        /**
         * Delete configuration
         * @param context
         * @param configurationId
         * @param simpleId
         */
        async deleteConfiguration(context, {configurationId, simpleId}) {
            try {
                if (simpleId) {
                    let response = await this.$axios.delete(`/onka/${simpleId}/configurations/${configurationId}`);
                    context.commit('REMOVE_CONFIGURATION', configurationId);
                    window.flash.showMessagesFromAjax(response.data);
                    return true;
                } else {
                    window.flash.error('Fehler!');
                    console.error('simpleId is not provided!');
                    return false;
                }
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error('Couldn\'t delete configurations', err);
                return false;
            }
        },

        /**
         * @param context
         * @param configurationId
         * @param name
         * @returns {Promise<boolean>}
         */
        async updateName(context, {configurationId, name}) {
            try {
                await this.$axios.put(`/onka/configurations/${configurationId}/name`, {name});
                context.commit('UPDATE_NAME', {configurationId, name});
                window.flash.success('Konfiguration erfolgreich gespeichert');
                return true;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data, 'error');
                return false;
            }
        }
    }
}
