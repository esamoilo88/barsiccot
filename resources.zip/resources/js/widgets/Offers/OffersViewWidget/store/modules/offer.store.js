import {asyncCall} from "@helpers/Async/AsyncRequests";
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    namespaced: true,
    state: {
        offer: {},
        approvalItems: []
    },
    mutations: {
        SET_OFFER(state, offer) {
            state.offer = {...offer};
        },
        SET_PREISBILDUNG_FIELD(state, {field, value}) {
            state.offer.offerInfo[field] = value;
        },
        SET_OFFER_INFO(state, data) {
            state.offer.offerInfo = {...data};
        },
        SET_ANGEBOT_GUELTIG_BIS(state, value) {
            state.offer.offerInfo.angebotGueltigBis = value;
        },
        SET_APPROVAL_ITEMS(state, items) {
            state.approvalItems.splice(0);
            state.approvalItems.push(...items);
        }
    },
    actions: {
        /**
         * Get basic data for Offer view page
         * @param context
         * @param simpleId
         * @param currentVersion
         * @returns {Promise<*>}
         */
        async fetchOfferData(context, {simpleId, currentVersion}) {
            await asyncCall(
                async () => {
                    if (simpleId) {
                        const response = await this.$axios.get('/offers/' + simpleId + '/getOfferData/' + currentVersion);
                        if (response.data) {
                            let offer = response.data;
                            context.commit('SET_OFFER', offer);
                        }
                    }
            },
                (err) => {console.error('Couldn\'t fetch offer data', err)},
                false
            );
        },
        /**
         * @param context
         * @returns {Promise<void>}
         */
        async fetchApprovalItems(context) {
            try {
                let simpleId = context.getters.simpleId;
                let vkVersion = context.getters.currentVersion;
                let approvals = await this.$axios.get(`/offers/${simpleId}/vkVersions/${vkVersion}/approvals`);
                context.commit('SET_APPROVAL_ITEMS', approvals.data);
                this._vm.$eventBus.$emit('refresh-fertigstellen-box', {subject: 'approval-items'});
            } catch (err) {
                console.log("Couldn't fetch Approvals data", err);
            }
        }
    },
    getters: {
        status(state) {
            return state.offer.globalGate.sinStatus.status;
        },
        simpleId(state) {
            return state.offer.globalGate.simpleId;
        },
        isInit(state) {
            return !isEmpty(state.offer);
        },
        currentVersion(state) {
            return state.offer.offerInfo.currentVersionId;
        },
        activeVersion(state) {
            return state.offer.offerInfo.activeVersionId;
        },
        offerInfo(state) {
            return state.offer.offerInfo
        },
        hasAccess(state) {
            return state.offer.user.isAdmin || !isEmpty(state.offer.user.userRoles);
        },
        angebotGueltigBis(state) {
            return state.offer.offerInfo.angebotGueltigBis;
        }
    }
}
