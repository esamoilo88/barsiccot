export default {
    namespaced: true,
    state: {
        costrates: [],
        quotation: {}
    },
    mutations: {
        SET_COSTRATES(state, costrates) {
            state.costrates = [...costrates];
        },
        SET_QUOTATION(state, quotation) {
            state.quotation = {...quotation};
        }
    },
    actions: {
        /**
         * Get basic data for Costrates of offer view page
         * @param context
         * @param simpleId
         * @returns {Promise<*>}
         */
        async fetchCostrates(context, simpleId) {
            try {
                if (simpleId) {
                    const response = await this.$axios.get('/offers/' + simpleId + '/costrates');
                    if (response.data) {
                        let costrates = response.data;
                        context.commit('SET_COSTRATES', costrates);
                    }
                }
            } catch (error) {
                console.error('Couldn\'t fetch costrates data', error);
            }
        },
        /**
         *
         * @param context
         * @param simpleId
         * @returns {Promise<void>}
         */
        async fetchQuotation(context, simpleId) {
            try {
                if (simpleId) {
                    const response = await this.$axios.get('/offers/' + simpleId + '/quotationStyle');
                    if (response.data) {
                        let quotation = response.data;
                        context.commit('SET_QUOTATION', quotation);
                    }
                }
            } catch (error) {
                console.error('Couldn\'t fetch quotation data', error);
            }
        },
    },
}
