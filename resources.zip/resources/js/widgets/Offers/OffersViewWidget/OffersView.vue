<template>
    <div>
        <div class="d-flex align-items-center bg-white pt-3 pb-3 pl-4 pr-4">
            <div id="dashboard-switch" v-cloak>
                <dashboards-switch :sin="simpleId" :customer-id="customerId" title="Offer Dashboard"></dashboards-switch>
            </div>
            <div class="ml-auto mr-3">
                <a href="#" onclick="history.go(-1)">Zurück</a>
            </div>
            <div class="text-right" v-if="dataProp.is_active">
                <WorkflowButton
                    class="mr-3"
                    :simple-id="simpleId"
                    :status="status"
                    :has-ae-permission="dataProp.user.has_AE_permission"
                    :user="dataProp.user"
                    :can-reset-status-to-s0="dataProp.can_reset_status_to_s0"
                    :can-switch-preorder="dataProp.can_switch_preorder"
                    @switchedOrder="fetchOfferData({simpleId})"
                />

                <simple-dropdown class="more-options-btn" :more="false" title="Weitere Optionen">
                    <b-dropdown-item :href="`/projects/${simpleId}/files`" link-class="px-1">
                        <span class="text-nowrap">
                            <span class="icon-folder-open"></span>
                            Dateiablage
                        </span>
                    </b-dropdown-item>
                    <b-dropdown-item :href="`/mails/${simpleId}`" link-class="px-1">
                        <span class="text-nowrap">
                            <span class="icon-communication-email-default"></span>
                            Mailhistorie
                        </span>
                    </b-dropdown-item>
                </simple-dropdown>
            </div>
        </div>
        <dashboards-preloader v-if="!isStoreInit" class="content-padding"></dashboards-preloader>
        <div v-else>
            <HeaderData class="simple-header px-2"/>

            <div v-if="offer.offerInfo.isVersioned">
                <b-tabs @input="onTabSwitch" v-model="tabIndex" class="simple-tabs">
                    <b-tab id="cockpit-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[0] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(0)">
                            <div class="content-padding mb-5 mx-2">
                                <Cockpit :simple-id="simpleId" class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="einstellungen-tab">
                        <template #title>
                            <span class="text">{{ tabsNames[1] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(1)">
                            <div class="content-padding mb-5 mx-2">
                                <Einstellungen class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="konfigurator-tab">
                        <template #title>
                            <span class="text">{{ tabsNames[2] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(2)">
                            <div class="content-padding pt-0 mb-5 mx-2">
                                <Konfigurator />
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="katalog-import-tab">
                        <template #title>
                            <span class="text">{{ tabsNames[3] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(3)">
                            <div class="content-padding mb-5 mx-2">
                                <KatalogImport class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>

                    <b-tab id="angebotspositionen-tab">
                        <template #title>
                            <span class="text">{{ tabsNames[4] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(4)">
                            <div class="content-padding mb-5 mx-2">
                                <Angebotspositionen class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="angebot-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[5] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(5)">
                            <div class="content-padding mb-5 mx-2">
                                <Angebot class="simple-box box-shadow"/>
                            </div>
                        </div>
                    </b-tab>
                    <b-tab id="historie-tab" lazy>
                        <template #title>
                            <span class="text">{{ tabsNames[6] }}</span>
                        </template>
                        <div v-if="visitedTabs.includes(6)">
                            <div class="content-padding mb-5 mx-2">
                                <Historie class="simple-box box-shadow" :simple-id="simpleId"/>
                            </div>
                        </div>
                    </b-tab>
                </b-tabs>
            </div>
            <no-info v-else :offer-info="dataProp"></no-info>
        </div>
    </div>
</template>

<script>
import WorkflowButton from "@comp/Common/WorkflowButton/WorkflowButton";
import HeaderData from "./HeaderData";
import {BTabs, BTab, BBadge, BDropdownItem} from 'bootstrap-vue';
import {mapActions, mapState, mapMutations, mapGetters} from 'vuex';
import DashboardsPreloader from "@comp/ContentPreloader/DashboardsPreloader";
import DashboardsSwitch from "@comp/Common/DashboardsSwitchWidget/DashboardsSwitch";
import NoInfo from "res/js/widgets/Offers/OffersViewWidget/tabs/NoInfo";
import Loading from "@comp/DynamicImportHelpers/Loading";
import Cockpit from "./tabs/Cockpit/Cockpit";
const Konfigurator = () => ({loading: Loading, component: import('./tabs/Konfigurator/Konfigurator'), delay: 0});
const Einstellungen = () => ({loading: Loading, component: import('./tabs/Einstellungen/Einstellungen'), delay: 0});
const Angebotspositionen = () => ({loading: Loading, component: import('./tabs/Angebotspositionen/Index'), delay: 0});
const KatalogImport = () => ({loading: Loading, component: import('./tabs/KatalogImport/Index'), delay: 0});
const Angebot = () => ({loading: Loading, component: import('./tabs/Angebot/Angebot'), delay: 0});
const Historie = () => ({loading: Loading, component: import('./tabs/Historie/Historie'), delay: 0});
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import DashboardMxn from "@mixins/Common/DashboardMxn";

export default {
    name: "offer-view",
    components: {
        Historie,
        WorkflowButton,
        DashboardsSwitch,
        NoInfo,
        Konfigurator,
        Einstellungen,
        BTabs,
        BTab,
        BBadge,
        Cockpit,
        HeaderData,
        Angebotspositionen,
        Angebot,
        DashboardsPreloader,
        SimpleDropdown,
        BDropdownItem,
        KatalogImport
    },
    mixins: [DashboardMxn],
    props: {
        dataProp: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            tabsNames: [
                'Cockpit', 'Einstellungen', 'Konfigurator', 'Katalog',
                'Angebot', 'Workflow', 'Historie',
            ],
            visitedTabs: [],
            tabIndex: 0
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            isStoreInit: 'offer/isInit',
            status: 'offer/status'
        }),
        customerId(){
            return (this.dataProp.customer) ? this.dataProp.customer.id : null;
        }
    },
    created() {
        this.setOfferMutation(this.dataProp);
        this.$eventBus.$on('configurationAssumed', () => {
            this.tabIndex = 4;
        });
        this.$eventBus.$on('goToTab', (tabIndex) => this.tabIndex = tabIndex);
    },
    beforeDestroy() {
        this.$eventBus.$off('configurationAssumed');
        this.$eventBus.$off('goToTab');
    },
    methods: {
        ...mapActions({
            fetchOfferData: "offer/fetchOfferData"
        }),
        ...mapMutations({
            setOfferMutation: "offer/SET_OFFER"
        }),
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/features/dashboards";
</style>
