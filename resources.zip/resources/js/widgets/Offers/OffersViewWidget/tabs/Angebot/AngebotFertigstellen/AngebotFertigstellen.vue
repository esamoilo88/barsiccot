<template>
    <div class="simple-box ap-fertigstellen-box">
        <b-overlay :show="pending">
            <h2>Angebot fertigstellen</h2>
            <div class="d-flex flex-column mt-3">
                <div v-for="point in points" :key="point.text" class="d-flex align-items-center mb-2">
                    <img
                        class="icon mr-2"
                        :src="'/img/icons/' + (point.status === 'confirm' ? 'confirm_graphical' : 'warning_graphical') + '.svg'"
                        :alt="point.status === 'confirm' ? 'confirm' : 'warning'"
                    />
                    <span>{{ point.text }}</span>
                </div>
            </div>
            <button
                v-if="status.shortName === 'S3'"
                @click="showAngebotFertigstellenDialog = true"
                :disabled="!isComplete"
                class="btn btn-primary w-100 mt-5"
            >
              Angebot fertigstellen
            </button>
            <AngebotFertigstellenDialog
                :is-visible="showAngebotFertigstellenDialog"
                @close-angebot-fertigstellen-dialog="showAngebotFertigstellenDialog = false"
            />
        </b-overlay>
    </div>
</template>

<script>
import AngebotFertigstellenDialog from "./AngebotFertigstellenDialog";
import {mapState, mapGetters} from "vuex";
import {BOverlay} from "bootstrap-vue";

export default {
    name: "AngebotFertigstellen",
    components: {
        BOverlay,
        AngebotFertigstellenDialog
    },
    async created() {
        this.$eventBus.$on('refresh-fertigstellen-box', this.getChecklistPoints);
        await this.getChecklistPoints({});
    },
    beforeDestroy() {
        this.$eventBus.$off('refresh-fertigstellen-box', this.getChecklistPoints);
    },
    data() {
        return {
            gesamtkostenPoint: [],
            approvalItemsPoints: [],
            distributionPoints: [],
            angebotGueltigPoints: [],
            angebotDocumentPoints: [],
            pending: false,
            showAngebotFertigstellenDialog: false
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
            approvalItems: state => state.offer.approvalItems
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            angebotGueltigBis: 'offer/angebotGueltigBis',
            currentVersion: 'offer/currentVersion',
            status: 'offer/status'
        }),

        points() {
            return [
                ...this.gesamtkostenPoint,
                ...this.approvalItemsPoints,
                ...this.angebotGueltigPoints,
                ...this.angebotDocumentPoints
            ]
        },

        isComplete() {
            let warnings = this.points.filter(p => p.status === "warning");
            return warnings.length === 0;
        }
    },
    methods: {
        /**
         * The list of all checks for completing the offer
         */
        async getChecklistPoints({subject = undefined}) {
            this.pending = true;
            try {
                (subject === undefined) && this.getGesamtkostenChecks();
                (subject === undefined || subject === 'approval-items') && await this.getApprovalItemsChecks();
                (subject === undefined || subject === 'angebot-gueltig') && await this.getAngebotsGultigChecks();
                (subject === undefined || subject === 'angebot-document') && await this.getAngebotsdocumentChecks();
            } catch (err) {
                console.error("Couldn't get the data for checklist points", err);
            }
            this.pending = false;
        },
        /**
         * Get check of gesamtkosten for the checklist
         */
        getGesamtkostenChecks() {
            this.gesamtkostenPoint.splice(0);
            this.gesamtkostenPoint.push({
                id: "gesamtkosten",
                text: "Die Gesamtkosten sind > 0 €",
                status: this.offer.offerInfo.sumVk > 0 ? "confirm" : "warning"
            });
        },
        /**
         * Get checks of approval items for the checklist
         */
        async getApprovalItemsChecks() {
            let points = [];
            this.approvalItems.map(approval => {
                if (!approval.optional) {
                    let confirmed = approval.onkaApprovalResults.filter(r => r.result)
                    points.push({
                        id: `approval-item-${approval.id}`,
                        text: approval.name,
                        status: confirmed.length > 0 ? "confirm" : "warning"
                    });
                }
            });
            this.approvalItemsPoints.splice(0);
            this.approvalItemsPoints.push(...points);
            // without this return b-overlay is not shown (idk why)
            return new Promise((resolve) => setTimeout(() => resolve(true), 100));
        },
        /**
         * Get check of angebotsgultig for the checklist
         */
        async getAngebotsGultigChecks() {
            this.angebotGueltigPoints.splice(0);
            this.angebotGueltigPoints.push({
                id: "angebotsgultig",
                text: "Angebotsgültigkeit hinterlegt",
                status: this.angebotGueltigBis ? "confirm" : "warning"
            });
            // without this return b-overlay is not shown (idk why)
            return new Promise((resolve) => setTimeout(() => resolve(true), 100));
        },
        async getAngebotsdocumentChecks() {
            let status;
            try {
                const res = await this.$axios.get(`/offers/${this.simpleId}/angebot/upload/${this.currentVersion}/check-existence`);
                status = res.data;
            } catch (err) {
                status = false;
                console.error("Couldn't get the data for Angebotsdocument points")
            }
            this.angebotDocumentPoints.splice(0);
            this.angebotDocumentPoints.push({
                id: "angebotsdocument",
                text: "Angebotsdokument hochgeladen",
                status: status ? 'confirm' : 'warning'
            });
        }
    }
}
</script>

<style lang="scss" scoped>
.ap-fertigstellen-box {
    .icon {
        width: 32px;
    }
}
</style>
