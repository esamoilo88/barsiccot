<template>
    <div class="simple-box d-flex flex-column">
        <b-overlay :show="pending">
            <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon" src="/img/icons/todo-list_graphical.svg" alt="price tag"/>
                <div class="d-flex flex-column">
                    <h2>Angebotsfreigaben</h2>
                    <span class="text-muted secondary-text">
                        Zeigt die Liste der notwendigen Freigaben an.
                    </span>
                </div>
                <button @click="toggleContentVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible">
                <div class="horizontal-line"></div>
                    <ApprovalItem
                        v-for="item in approvalItems"
                        :key="item.id"
                        :class="'approval-' + item.id"
                        :item="item"
                        @anforder-clicked="value => showRequestApprovlDialog(value)"
                        @anzeigen-clicked="value => handleAnzeigen(value)"
                        @freigaben-clicked="value => showConfirmDeclineDialog('confirm', value)"
                        @ablehnen-clicked="value => showConfirmDeclineDialog('decline', value)"
                    />
            </div>
        </b-overlay>

        <AnzeigenDialog
            :is-visible="showDetails"
            @close-details-modal="closeAnzeigen"
            ref="detailsDialog"
        />

        <ConfirmDeclineDialog
            ref="confirmDecline"
            v-if="confirmDeclineVisible"
            :is-visible="confirmDeclineVisible"
            :action-type="confirmOrDecline"
            :item="confirmDeclineItem"
            @refresh-angebotsfreigaben="init"
            @close-confirm-decline-modal="hideConfirmDeclineDialog"
        />

        <RequestApprovalDialog
            ref="approval"
            v-if="requestApprovalVisible"
            :is-visible="requestApprovalVisible"
            :item="requestApprovalItem"
            @refresh-angebotsfreigaben="init"
            @close-approval-modal="hideRequestApprovalDialog"
        />

    </div>
</template>

<script>
import {mapGetters, mapActions, mapState} from "vuex";
import {BOverlay} from 'bootstrap-vue';
import ApprovalItem from "./ApprovalItem";
import ConfirmDeclineMxn from "./ConfirmDeclineApproval/ConfirmDeclineMxn";
import RequestApprovalMxn  from "./RequestApproval/RequestApprovalMxn";
import LoadingWholePage from "@comp/DynamicImportHelpers/LoadingWholePage";
const ConfirmDeclineDialog = () => ({ loading: LoadingWholePage, component: import('./ConfirmDeclineApproval/ConfirmDeclineDialog'), delay: 0 });
import AnzeigenDialog from "./AnzeigenDialog";
const RequestApprovalDialog = () => ({ loading: LoadingWholePage, component: import('./RequestApproval/RequestApprovalDialog'), delay: 0 });

export default {
    name: "Angebotsfreigaben",
    components: {
        BOverlay, ApprovalItem, ConfirmDeclineDialog, AnzeigenDialog,RequestApprovalDialog
    },
    mixins: [ConfirmDeclineMxn, RequestApprovalMxn],
    async created() {
        await this.init();
    },
    data() {
        return {
            isContentVisible: false,
            pending: false,
            showDetails: false
        }
    },
    computed: {
        ...mapState({
            approvalItems: state => state.offer.approvalItems
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion',
            hasAccess: 'offer/hasAccess'
        })
    },
    methods: {
        ...mapActions({
            fetchApprovalItems: 'offer/fetchApprovalItems'
        }),

        toggleContentVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        async init() {
            this.pending = true;
            await this.fetchApprovalItems();
            this.pending = false;
        },
        handleAnzeigen(item) {
            if (this.hasAccess === false) {
                window.flash.showMessagesFromAjax('Du hast keine Berechtigung auf diese Funktion.', 'error');
                return;
            }
            this.$refs.detailsDialog.setData(item);
            this.showDetails = true;
        },
        closeAnzeigen() {
            this.showDetails = false;
            this.$refs.detailsDialog.clearData();
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    width: 46px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.right-line {
    border-right: 3px solid #dee2e6;
}
</style>
