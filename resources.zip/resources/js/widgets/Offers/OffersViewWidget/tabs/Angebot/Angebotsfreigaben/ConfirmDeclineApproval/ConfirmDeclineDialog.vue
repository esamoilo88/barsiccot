<template>
    <modal-dialog
        modal-class="approval-confirm-decline-modal"
        :is-visible="isVisible"
        @hideModal="$emit('close-confirm-decline-modal')"
        :title-dialog="actionType === 'confirm' ? 'Angebotsfreigabe erteilen' : 'Angebotsfreigabe ablehnen'"
        scrollable
    >
        <div v-if="item !== null" class="d-flex flex-column">
            <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

            <div class="simple-box d-flex flex-column mb-4">
                <div class="d-flex align-items-center mb-2">
                    <span :class="item.icon +  ' item-name-icon mr-3'"></span>
                    <span>{{ item.name }}</span>
                </div>
                <div class="d-flex align-items-center">
                    <img
                        v-if="actionType === 'confirm'"
                        :key="'confirm-icon'"
                        class="mr-3 confirm-decline-icon"
                        src="/img/icons/confirm_graphical.svg"
                        alt="confirmation"
                    />
                    <img
                        v-else
                        :key="'decline-icon'"
                        class="mr-3 confirm-decline-icon"
                        src="/img/icons/error_graphical.svg"
                        alt="decline"
                    />
                    <span>Die Freigabe wird {{actionType === 'confirm' ? 'erteilt' : 'abgelehnt'}}</span>
                </div>

                <FormTextArea
                    v-model="form.comment"
                    rows="6"
                    class="my-4"
                    input-id="approval-confirm-decline-comment"
                    name="approval-confirm-decline-comment"
                    :label-text="'Kommentar' + ($v.form.comment.required !== undefined ? '*' : '')"
                    :error-conditions="[
                        {
                            name: 'empty-comment',
                            condition: $v.form.comment.required !== undefined
                                && !$v.form.comment.required
                                && this.$v.form.comment.$dirty,
                            text: $t.__('validation.required', {attribute: 'Kommentar'})
                        }
                    ]"
                />

                <div class="d-flex flex-column">
                    <b-form-checkbox v-model="form.withEmail" switch>E-Mail senden</b-form-checkbox>
                    <span class="text-muted switch-secondary-text">
                        Sendet eine Infomail an den Angebotsersteller.
                    </span>
                </div>
            </div>

        </div>

        <template #footer="{methods}">
            <button
                v-if="actionType === 'confirm'"
                :key="'approval-confirm-btn'"
                @click="onSubmit"
                class="btn btn-success"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Freigeben
            </button>
            <button
                v-if="actionType === 'decline'"
                :key="'approval-decline-btn'"
                @click="onSubmit"
                class="btn btn-danger"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Ablehnen
            </button>
            <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {BFormCheckbox} from "bootstrap-vue";
import {BSpinner} from "bootstrap-vue";
import {required} from 'vuelidate/lib/validators'
import {mapGetters} from "vuex";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "ConfirmDeclineDialog",
    components: {
        ModalDialog, FormTextArea, BFormCheckbox, BSpinner
    },
    props: {
        actionType: {
            type: String,
            required: true
        },
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        item: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {
                comment: null,
                withEmail: true
            },
            onSubmitPending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            vkVersionId: 'offer/currentVersion'
        })
    },
    methods: {
        /**
         * Confirm or decline action handler
         * @returns {Promise<void>}
         */
        async onSubmit() {
            this.onSubmitPending = true;
            if (this.validate()) {
                let id = this.item.id;
                let action = this.actionType;
                try {
                    let res = await this.$axios.post(`/offers/${this.simpleId}/vkVersions/${this.vkVersionId}/approvals/${id}/${action}`, {
                        ...this.form
                    });
                    window.flash.showMessagesFromAjax(res.data);
                    this.$emit('refresh-angebotsfreigaben');
                    this.$emit('close-confirm-decline-modal');
                } catch (err) {
                    console.error(`Couldn't confirm approval with id = ${id}`, err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onSubmitPending = false;
        },
        validate() {
            this.$v.$touch();
            return !this.$v.$anyError && this.item !== null;
        }
    },
    validations() {
        return this.actionType === 'decline' ? {form: {comment: {required} }} : {form: {comment: true }};
    }
}
</script>

<style scoped>
.confirm-decline-icon {
    width: 25px;
}

.switch-secondary-text {
    font-size: 16px;
}

.item-name-icon {
    font-size: 25px;
}
</style>
