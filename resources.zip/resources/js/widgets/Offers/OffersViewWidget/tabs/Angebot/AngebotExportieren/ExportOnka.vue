<template>
    <div>
        <h5>
            <span class="icon-user_file-draft-file-default"></span>
            ONKA
        </h5>

        <div class="text-muted">
            <p>Exportiere die ONKA als Excel-Datei.</p>
        </div>

        <button class="btn btn-primary" :disabled="!hasPermissions || loading" @click="exportOnka">
            <b-spinner v-if="loading" small></b-spinner>
            <span class="icon-action-download-default"></span>
            Export
        </button>
    </div>
</template>

<script>
import {mapGetters, mapState} from "vuex";
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BFormGroup, BSpinner} from 'bootstrap-vue';
import FormInput from '@comp/FormInput/FormInput';
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";

export default {
    components: {ModalDialog, BFormGroup, FormInput, FormDatepicker, BSpinner},
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        }),

        hasPermissions() {
            return this.offer.user.isAdmin || this.offer.user.userRoles.includes('SC') || this.offer.user.userRoles.includes('AE')
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        async exportOnka() {
            this.loading = true;

            try {
                window.open(`/offers/${this.simpleId}/onka/export`);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        }
    }
}
</script>
