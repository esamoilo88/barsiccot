<template>
    <div v-if="canUploadFile">
        <!-- Styled -->
        <b-overlay :show="loading">
            <h5>
                <span class="icon-user_file-attachment-default"></span>
                Angebot
            </h5>
            <div class="row no-gutters justify-content-between">
                <div class="col-18">
                    <p class="text-muted">
                        Das Angebot als Datei wird hier abgelegt. Es enthält die finale Beschreibung des Kundenvorhabens
                        inklusiver aller Details zu Preisen, Beschreibungen, Mitwirkungspflichten, etc.
                    </p>
                    <form-file-load
                        v-model="file"
                        ref="file"
                        type="file"
                        browse-text="Auswählen"
                        @uploadFile="uploadFile"
                        placeholder="Angebotsdokument auswählen oder drag&drop"
                        accept=".doc,.docx,.pdf,.p7f,.xia"
                    />
                    <div v-if="canDownload" class="mt-3">
                        <a
                            class="font-weight-bold"
                            :href="`/offers/${this.simpleId}/angebot/download/${this.filesInfo.name}`"
                            download
                        >
                            <span class="icon-action-download-default text-info"></span>
                            {{ filesInfo.name }}
                        </a>
                        <p class="text-muted mb-0">
                            {{ formatBytes(filesInfo.size) }} - {{formatedDate(filesInfo.date) }}
                        </p>
                    </div>
                </div>
                <div class="col-auto">
                    <img
                        v-if="canDownload"
                        :key="'confirm-apdoc-icon'"
                        class="icon mr-2"
                        src="/img/icons/confirm_graphical.svg"
                        alt="confirm"
                        title="Angebot hochgeladen"
                        v-b-tooltip.hover
                    />
                    <img
                        v-else
                        :key="'warning-apdoc-icon'"
                        class="icon mr-2"
                        src="/img/icons/warning_graphical.svg"
                        alt="warning"
                        title="Angebot nicht hochgeladen"
                        v-b-tooltip.hover
                    />
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BOverlay, VBTooltip} from 'bootstrap-vue';
import FormFileLoad from '@comp/FileLoad/FormFileLoad'
import {mapGetters, mapState} from "vuex";
import dayjs from "res/js/utils/day";
import FormatBytes from "@comp/FileLoad/FormatBytes";

export default {
    name: "AngebotsDocUpload",
    components: {
        FormFileLoad,
        BOverlay
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [FormatBytes],
    async created() {
        this.loading = true;
        await this.initFile();
        this.loading = false;
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
        canUploadFile() {
            return this.offer.is_onka_writable && (
                this.offer.user.isAdmin
                || this.offer.user.userRoles.includes('SC')
                || this.offer.user.userRoles.includes('AE')
                || this.offer.user.userRoles.includes('TK')
            )
        },
        getVersionNR() {
            return this.offer.offerInfo.version.replace("V", '');
        }
    },
    data() {
        return {
            filesInfo: {
                name: '',
                date: null,
                size: null
            },
            attachedfile: null,
            formData: new FormData(),
            loading: false,
            file: null,
            canDownload: false
        }
    },
    methods: {
        formatedDate(date) {
            return dayjs(date.date).format('DD.MM.YYYY H:mm');
        },
        async uploadFile(filesInfo) {
            try {
                this.loading = true;
                await this.$axios.post('/file/getPath', filesInfo.formData, filesInfo.config).then(
                    response => {
                        let info = response.data.filesPath[0];
                        this.attachedfile = {
                            'savePath': info.tempPath,
                            'size': info.size,
                            'name': filesInfo.fileNames,
                            'date': filesInfo.date
                        }
                    }
                );
                await this.initFile();
                window.flash.success('Angebot erfolgreich hochgeladen');
                this.$refs.file.clearFiles();
                this.$eventBus.$emit('refresh-fertigstellen-box', {subject: 'angebot-document'});
            } catch (error) {
                console.error('Couldn\'t upload file', error);
                window.flash.error(error.response.data.text);
                this.$refs.file.clearFiles();
            }
            this.loading = false;

        },
        async initFile() {
            let res = await this.$axios.post('/offers/' + this.simpleId + '/versions/' + this.getVersionNR + '/angebot/upload', {'attachedfile': this.attachedfile});
            if (res.data.length !== 0) {
                let data =res.data[0];
                this.canDownload = true;
                let fileName = data.name.split('/');
                this.filesInfo.name = fileName[fileName.length - 1];
                this.filesInfo.size = data.size;
                this.filesInfo.date = data.date;
            }
        }
    }
}
</script>
