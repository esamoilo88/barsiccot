<template>
    <div>
        <h5>
            <span class="icon-user_file-draft-file-default"></span>
            Word Export
        </h5>

        <div class="text-muted">
            <p>Exportiere die Stammdaten, Kontakte, Preisliste sowie allgemeingültige Angebotstexte in das Word Dateiformat.</p>
        </div>

        <button class="btn btn-primary" :disabled="!hasPermissions || loading" @click="exportQuote">
            <b-spinner v-if="loading" small></b-spinner>
            <span class="icon-action-download-default"></span>
            Export
        </button>
    </div>
</template>

<script>
import {mapGetters, mapState} from "vuex";
import {BSpinner} from 'bootstrap-vue';

export default {
    components: {BSpinner},
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        }),

        hasPermissions() {
            return this.offer.is_active &&
                (
                    this.offer.user.isAdmin ||
                    this.offer.user.userRoles.includes('SC') ||
                    this.offer.user.userRoles.includes('AE')
                )
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        async exportQuote() {
            this.loading = true;
            try {
                const url = `/offers/${this.simpleId}/versions/${this.currentVersion}/quote/export`;
                const response = await this.$axios.put(url) || {data: null};
                window.open(`${url}/${response.data}`, '_blank').focus();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
            this.loading = false;
        }
    }
}
</script>
