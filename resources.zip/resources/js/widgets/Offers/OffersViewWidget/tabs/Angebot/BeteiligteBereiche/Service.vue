<template>
    <div class="service-container mb-3">
        <FormSelect
            v-model="item.id"
            label-text="Bereich"
            :options="options"
            :name="itemDataStr"
            :select-id="`select_id_${itemDataStr}`"
            :key="`select_key_${itemDataStr}`"
            searchable
            @select="onSelect"
            :readonly="readonly"
        />
        <b-input-group class="percentage-input" size="lg" append="%">
            <b-form-input
                v-model="item.value"
                :key="`input_key_${itemDataStr}`"
                :id="`input_id_${itemDataStr}`"
                :readonly="readonly"
                type="number"
            ></b-form-input>
        </b-input-group>
    </div>
</template>

<script>
import FormSelect from '@comp/FormSelect/FormSelect';
import {BFormInput, BInputGroup} from 'bootstrap-vue';

export default {
    components: {
        FormSelect,
        BFormInput,
        BInputGroup
    },
    props: {
        item: {
            type: Object,
            required: true
        },
        index: {
            type: Number,
            required: true
        },
        selectedItems: {
            type: Array,
            default: () => {
                return [];
            }
        },
        optionsProp: {
            type: Array,
            default: () => {
                return [];
            }
        },
        readonly: {
            type: Boolean,
            default: false
        }
    },
    computed: {
        itemDataStr() {
            return `new_item_${this.index}`;
        },
        options() {
            const ids = this.selectedItems.map(({id}) => parseInt(id));

            return this.optionsProp.filter(item => item.id == this.item.id || !ids.includes(item.id));
        }
    },
    methods: {
        onSelect(id) {
            const service = this.options.find(item => item.id == id);

            this.item.text = service.text;
        }
    }
}
</script>

<style lang="scss" scoped>
.service-container {
    display: grid;
    grid-template-columns: 1fr auto;
}
.percentage-input {
    height: 44px;
    max-width: 95px;
    margin-left: 5px;
    padding: 2px 0;

    input {
        height: 44px;
        font-weight: bold;
        padding-left: 10px;
        padding-right: 10px;
    }
    .input-group-append {
        height: 44px;
    }
    .input-group-text {
        padding: 5px 10px;
    }
}
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Firefox */
input[type=number] {
    -moz-appearance: textfield;
}
</style>
