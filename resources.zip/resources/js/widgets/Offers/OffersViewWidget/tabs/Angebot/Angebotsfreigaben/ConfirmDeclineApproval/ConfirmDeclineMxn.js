export default {
    data() {
        return {
            confirmDeclineVisible: false,
            confirmDeclineItem: null,
            confirmOrDecline: 'confirm'
        }
    },
    methods: {
        async showConfirmDeclineDialog(type, item) {
            window.preloader.show();
            try {
                let res = await this.$axios.get(`/offers/${this.simpleId}/vkVersions/${this.currentVersion}/approvals/${item.id}/check-permissions`)
                this.confirmOrDecline = type;
                this.confirmDeclineItem = item;
                this.confirmDeclineVisible = true;
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data)
            }
            window.preloader.hide();
        },
        hideConfirmDeclineDialog() {
            let itemId = this.confirmDeclineItem.id;
            this.confirmDeclineItem = null;
            this.confirmDeclineVisible = false;
            let buttonSelector = this.confirmOrDecline === 'confirm' ? '.btn-freigaben' : '.btn-ablehnen';
            document.querySelector('.approval-' + itemId + ' ' + buttonSelector).focus();
        }
    }
}
