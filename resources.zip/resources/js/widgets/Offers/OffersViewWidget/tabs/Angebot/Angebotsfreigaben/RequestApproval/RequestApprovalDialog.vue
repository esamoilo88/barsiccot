<template>
    <modal-dialog
        :is-visible="isVisible"
        @hideModal="$emit('close-approval-modal')"
        title-dialog="Freigabe anfordern"
        close-button="Abbrechen"
        :static="true"
        :scrollable="true"
        modal-class="modal-approval"
    >
        <div v-if="item !== null">
            <div class="mb-4">
                Bitte fülle alle mit * gekennzeichneten Felder aus.
            </div>
            <b-overlay :show="pending">
                <div class="simple-box" @keyup.enter="submit">
                    <div class="d-flex align-items-center mb-3">
                        <span :class="item.icon +  ' item-name-icon mr-3'"></span>
                        <span>{{ item.name }}</span>
                    </div>
                    <b-form-group>
                        <PeopleSearch
                            ref="search"
                            type="default"
                            label="Mitarbeiter suchen*"
                            :default-search="search"
                            :multiple="false"
                            @user-added="userAdded"
                            @user-dropped="userDropped"
                        />

                        <div class="invalid-feedback d-block" v-if="isInvalid('user_id')">
                            Der Mitarbeiter ist erforderlich.
                        </div>
                    </b-form-group>

                    <div class="mt-5">
                        <b-form-group>
                            <b-form-checkbox
                                switch
                                v-model="form.sendEmail"
                                class="font-weight-bold"
                            >
                                E-Mail senden
                            </b-form-checkbox>

                            <div class="text-muted">
                                Sendet eine Infomail an den ausgewählten Benutzer.
                            </div>
                        </b-form-group>
                        <b-form-group>
                            <b-form-checkbox
                                switch
                                v-model="form.setTKRole"
                                class="font-weight-bold"
                                :disabled="!hasTKPermission"
                            >
                                Teilkalkulator Rolle zuweisen
                            </b-form-checkbox>

                            <div class="text-muted">
                                Wähle diese Option aus, wenn der ausgewählte Benutzer auch die Rolle Teilkalulator
                                erhalten
                                soll. Dies kann sinnvoll sein, wenn Service GrK Mitarbeiter einen Teil der Leistungen
                                selbst
                                kalkulieren. Die Rolle Angebotsprüfer erhält der ausgewählte Benutzer in jedem Fall.
                            </div>
                        </b-form-group>
                    </div>
                </div>
            </b-overlay>
        </div>

        <template #footer="{methods}">
            <b-button
                variant="primary"
                @click="submit"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Anfordern
            </b-button>

            <b-button variant="secondary" @click="methods.hideModal">
                Abbrechen
            </b-button>
        </template>
    </modal-dialog>
</template>

<script>
import {BTable, BButton, BBadge, BSpinner ,BOverlay} from 'bootstrap-vue';
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BFormGroup, BFormCheckbox} from 'bootstrap-vue';
import FormSelect from "@comp/FormSelect/FormSelect";
import PeopleSearch from "@comp/Common/PeopleSearch/PeopleSearch";
import {mapGetters} from "vuex";
import Validation from "@mixins/Validation/Validation";
import {required, requiredIf} from "vuelidate/lib/validators";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: 'ApprovalForm',
    components: {
        BTable,
        BButton,
        ModalDialog,
        BBadge,
        ButtonIcon,
        BFormGroup,
        BFormCheckbox,
        FormSelect,
        PeopleSearch,
        BSpinner,
        BOverlay
    },
    mixins: [Validation],
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        item: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {
                sendEmail: true,
                user_id: null,
                reqFromMail: null,
                setTKRole: false
            },
            pending: false,
            hasTKPermission: true,
            roles: [],
            onSubmitPending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion',
            offerInfo: 'offer/offerInfo'
        })
    },
    mounted() {
        this.presetUset();
    },
    methods: {
        async submit() {
            if (this.isValid()) {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.post(`/offers/${this.simpleId}/approvals/${this.currentVersion}/request/${this.item.id}`, this.form);
                    window.flash.showMessagesFromAjax(res.data);
                    this.$emit('refresh-angebotsfreigaben');
                    this.$emit('close-approval-modal');
                } catch (error) {
                    window.flash.showMessagesFromAjax(error.response.data);
                }
                this.onSubmitPending = false;
            }else {
                navigateToFirstInvalid();
            }
        },
        async search(value) {
            let response = {data: []};
            response = await this.$axios.get('/offers/approvals/members', {
                params: {
                    search: value,
                    right_ids: this.item.rechteIds,
                }
            });
            return response;
        },
        async userAdded(user) {
            this.form.user_id = user.id;
            let response = {data: []};
            response = await this.$axios.get('/offers/approvals/has-tk-permissions/' + user.id);
            this.hasTKPermission = response.data;
            if (!this.hasTKPermission) {
                this.form.setTKRole = false;
            }
        },
        userDropped() {
            this.form.user_id = null;
            this.form.reqFromMail = null;
            this.hasTKPermission = true;
        },
        roleChanged() {
            this.form.user_id = null;
            this.$refs.search.clear();
        },
        isInvalid(field) {
            return this.showValidationErrors && !this.$v.form[field].required;
        },
        isValid() {
            this.$v.$touch();

            if (this.$v.$invalid) {
                this.showValidationErrors = true;
                return false;
            }

            return true;
        },
        pushUser(user) {
            this.$refs.search.pushUser(user);
        },
        clearForm() {
            this.showValidationErrors = false;
            this.hasTKPermission = true;
            this.form.sendEmail = false;
            this.form.user_id = null;
            this.form.reqFromMail = null;
            this.form.setTKRole = true;
            this.$refs.search.clear();
        },
       async presetUset() {
            this.pending = true;
            let response = await this.$axios.get(`/offers/approvals/default-approval-user/${this.item.id}`);
            let user = response.data;
            if (user) {
                this.pushUser(user);
                this.form.reqFromMail = user.email;
                this.form.user_id = user.id;
            }
           this.pending = false;
       }
    },
    validations: {
        form: {
            user_id: {required: requiredIf(function(model) {
                    return model.reqFromMail === null
            })}
        }
    }
}

</script>
<style lang="scss" scoped>
.people-search-component {
    width: 100%;
}
</style>
