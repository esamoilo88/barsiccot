<template>
    <div>
        <b-overlay :show="pending">
            <div class="row no-gutters justify-content-between">
                <div class="col-18">
                    <p class="text-muted">Enthält eine grobe Aufteilung welche Produktionsbereiche an der Leistungserbringung beteiligt sind.</p>

                    <div>
                        <button class="btn btn-primary" v-if="hasPermissions" @click="showInWriteMode">
                            <span class="icon-action-edit-default"></span>
                            Beteiligte Bereiche ändern
                        </button>
                        <button class="btn btn-secondary" v-else @click="show">Beteiligte Bereiche anzeigen</button>
                    </div>
                </div>
            </div>
        </b-overlay>

        <modal-dialog
            :is-visible="isModalVisible"
            size="xl"
            @hideModal="hide"
            title-dialog="Beteiligte Bereiche"
            modal-class="manage-ap"
            :scrollable="true"
        >
            <p class="text-muted">
                Die beteiligten Bereiche enthalten eine grobe Aufteilung welche Produktionsbereiche an der Leistungserbringung beteiligt sind. Diese Daten fließen in die Rolling-Forecast Planung des Geschäftsbereich Service ein.
            </p>

            <div class="simple-box">
                <div class="row no-gutters">
                    <div class="col-24 col-lg-12 mb-4 pr-3">
                        <div class="mb-5">
                            <template v-for="(item, index) in items">
                                <Service
                                    :key="`item_key_${index}`"
                                    :item="item"
                                    :index="index"
                                    :selected-items="items"
                                    :options-prop="branches"
                                    :readonly="!writeMode"
                                />
                            </template>

                            <div v-if="hasPermissions">
                                <button class="btn btn-link" @click="addItem">+ Bereich hinzufügen</button>
                            </div>
                        </div>

                        <div>
                            Summe: <strong>{{ sum }}%</strong>
                        </div>
                    </div>
                    <div class="col-24 col-lg-12 pl-lg-3 box-right">
                        <Costrates :simple-id="simpleId" :cockpit-mode="false" />
                    </div>
                </div>
            </div>

            <template v-slot:footer>
                <button class="btn btn-primary" v-if="writeMode" @click="submit">
                    <b-spinner v-if="loading" small></b-spinner>

                    Speichern
                </button>

                <button class="btn btn-secondary" @click="hide">
                    <template v-if="writeMode">
                        Abbrechen
                    </template>
                    <template v-else>
                        Schließen
                    </template>
                </button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import Service from "./Service";
import {mapGetters, mapState} from "vuex";
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BOverlay, BSpinner, VBTooltip} from 'bootstrap-vue';
import DoughnutChart from "@comp/Charts/DoughnutChart";
import Costrates from "../../../tabs/Cockpit/Costrates/Costrates";

export default {
    components: {
        Service,
        ModalDialog,
        BOverlay,
        BSpinner,
        DoughnutChart,
        Costrates
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            branches: [],
            services: [],
            items: [
                {
                    id: null,
                    text: null,
                    value: null
                },
            ],
            loading: false,
            pending: true,
            isModalVisible: false,
            writeMode: false,
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer || {is_active: false, is_presales: false, user: {userRoles: []}}
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
        }),
        hasPermissions() {
            return this.offer.is_onka_writable &&
                (
                    this.offer.user.isAdmin ||
                    this.offer.user.userRoles.includes('TK') ||
                    this.offer.user.userRoles.includes('AE')
                )
        },
        sum() {
            return this.items.filter(item => item.id).reduce((a, b) => parseInt(a) + (parseInt(b.value) || 0), 0);
        },
        icon() {
            return this.isValid() ? 'confirm_graphical' : 'warning_graphical';
        },
        chartData() {
            return this.items.map(item => ({label: item.text, value: item.value}))
        },
        iconTitle() {
            return this.isValid() ? 'Beteiligte Bereiche ausgefüllt' : 'Beteiligte Bereich nicht ausgefüllt';
        }
    },
    async mounted() {
        await this.getBranches();
        await this.getServices();

        this.pending = false;
    },
    methods: {
        show() {
            this.isModalVisible = true;
        },
        showInWriteMode() {
            this.writeMode = true;
            this.isModalVisible = true;
        },
        hide() {
            this.writeMode = false;
            this.isModalVisible = false;
        },
        async getServices() {
            try {
                const response = await this.$axios.get(`/offers/${this.simpleId}/services`);

                if (response.data) this.services = response.data;

                if (this.services.length) {
                    this.items = this.services;
                }
            } catch (e) {
                console.error(e);

                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async getBranches() {
            try {
                const response = await this.$axios.get('/offers/branches') || {'data': null};

                if (response.data) this.branches = response.data;
            } catch (e) {
                console.error(e);

                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async submit() {
            if (!this.isValid()) {
                return window.flash.error('Die Aufteilung muss 100% in Summe ergeben.');
            }

            this.loading = true;

            try {
                await this.$axios.post(`/offers/${this.simpleId}/services`, {
                    services: this.items.filter(item => item.id && item.value)
                })

                this.items = [];

                this.hide();
                await this.getServices();

                window.flash.success('Daten gespeichert.');
                this.$eventBus.$emit('refresh-fertigstellen-box', {subject: 'angebot-distribution'});
            } catch (e) {
                console.error(e);

                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        },
        isValid() {
            return this.sum == 100;
        },
        addItem() {
            this.items.push({
                id: null,
                text: null,
                value: null
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.branch-value {
    display: grid;
    grid-template-columns: 1fr 0fr;
    justify-content: space-between;
    gap: 20px;
}

@media (min-width: 992px) {
    .box-right {
        border-left: 1px solid #dee2e6 !important;
    }
}
</style>
