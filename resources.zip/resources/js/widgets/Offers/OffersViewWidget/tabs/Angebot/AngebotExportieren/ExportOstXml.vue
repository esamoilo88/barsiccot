<template>
    <div>
        <h5>
            <span class="icon-user_file-draft-file-default"></span>
            Offer Support Tool
        </h5>

        <div class="text-muted">
            <p>Exportiere die Stammdaten und Angebotspositionen in das OST Format um das Angebot mittels der XML-Datei und den Makros aus der OST Vorlage erstellen zu können.</p>
        </div>

        <button class="btn btn-primary" :disabled="!hasPermissions || loading" @click="exportOstXml">
            <b-spinner v-if="loading" small></b-spinner>
            <span class="icon-action-download-default"></span>
            Export
        </button>
    </div>
</template>

<script>
import {mapGetters, mapState} from "vuex";
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BFormGroup, BSpinner} from 'bootstrap-vue';
import FormInput from '@comp/FormInput/FormInput';
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";

export default {
    components: {ModalDialog, BFormGroup, FormInput, FormDatepicker, BSpinner},
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        }),

        hasPermissions() {
            return this.offer.is_active &&
                (
                    this.offer.user.isAdmin ||
                    this.offer.user.userRoles.includes('SC') ||
                    this.offer.user.userRoles.includes('AE')
                )
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        async exportOstXml() {
            this.loading = true;

            try {
                const url = `/offers/${this.simpleId}/ost/export`;
                const response = await this.$axios.put(url) || {data: null};
                window.open(`${url}/${response.data}`, '_blank').focus();
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        }
    }
}
</script>
