<template>
    <modal-dialog
        :is-visible="isVisible"
        @hideModal="hideModal"
        modal-class="approval-item-details"
        title-dialog="Freigabedetails"
        footer-class="class-footer"
        header-class="class-header"
    >
        <div class="simple-box">
            <p>{{approvalItem.name}}</p>
            <p class="text-muted">{{approvalItem.subtext}}</p>
            <table class="table-fixed">
                <tr class="row"><td class="first-column">Angefordert von:</td><td><button class="link" @click="showUserModal(resultItem.requestByUser.email)">{{ resultItem.requestByUser.name }}</button></td></tr>
                <tr class="row"><td class="first-column">Angefordert bei:</td><td><button class="link" @click="showUserModal(resultItem.requestFromUser.email)">{{ resultItem.requestFromUser.name }}</button></td></tr>
                <tr class="row"><td class="first-column">Bewertet durch:</td><td><button class="link" @click="showUserModal(resultItem.checkedByUser.email)">{{ resultItem.checkedByUser.name }}</button></td></tr>
                <tr class="row"><td class="first-column">Angefordert am:</td><td>{{ resultItem.requestedAt }}</td></tr>
                <tr class="row"><td class="first-column">Bewertet am:</td><td>{{ resultItem.checkedAt }}</td></tr>
                <tr class="row">
                    <td class="first-column">Ergebnis:</td>
                    <td>
                        <img
                            v-if="getResult === 'Freigabe erteilt'"
                            class="message-content-icon"
                            src="/img/icons/confirm_graphical.svg"
                            alt="Freigabe erteilt"
                            :id="'success-icon-'+approvalItem.id"
                        />
                        <img
                            v-else-if="getResult === 'Freigabe abgelehnt'"
                            class="message-content-icon"
                            src="/img/icons/error_graphical.svg"
                            alt="Freigabe abgelehnt"
                            :id="'error-icon-'+approvalItem.id"
                        />
                        <img
                            v-else
                            class="message-content-icon"
                            src="/img/icons/help_graphical.svg"
                            alt="Freigabe offen"
                            :id="'question-icon-'+approvalItem.id"
                        />
                        {{ getResult }}
                    </td>
                </tr>
            </table>
            <p class="mt-4">Kommentar:</p>
            <p class="text-muted p-0">
                {{ comment }}
                <button
                    class="link"
                    v-if="typeof resultItem.comment === 'string' && resultItem.comment.length > 300"
                    @click="isCommentLong=!isCommentLong"
                >
                    {{ isCommentLong ? 'Weniger anzeigen' : 'Mehr anzeigen' }}
                </button>
            </p>
        </div>
        <template v-slot:footer>
            <b-button variant="secondary" @click="hideModal">Schließen</b-button>
        </template>
        <UserCardDialog
            @hideModal="hideUserModal"
            :email="email"
            :isVisible="isUserCardVisible"
        />
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import {BButton} from 'bootstrap-vue';
import UserCardDialog from "@comp/Common/Ldap/UserCardDialog";
import dayjs from 'res/js/utils/day';
import clip from "text-clipper";

export default {
    name: "AnzeigenDialog",
    components: {UserCardDialog, ModalDialog, BButton},
    mixins: [ScalarsProcessing],
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
    },
    data() {
        return {
            approvalItem: {
                name: '-',
                subtext: '-'
            },
            resultItem: {
                requestByUser: {
                    name: '-',
                    email: null
                },
                requestFromUser: {
                    name: '-',
                    email: null
                },
                checkedByUser: {
                    name: '-',
                    email: null
                },
                requestedAt: '-',
                checkedAt: '-',
                result: null,
                comment: null
            },
            email: '',
            isUserCardVisible: false,
            isCommentLong: false
        }
    },
    computed: {
        getResult() {
            switch (this.resultItem.result) {
                case true: return 'Freigabe erteilt';
                case false: return 'Freigabe abgelehnt';
                case null: return 'Freigabe offen';
            }
        },
        comment() {
            if (this.resultItem.comment === null) {
                return '-';
            } else if (this.isCommentLong) {
                return this.resultItem.comment;
            } else {
                return clip(this.resultItem.comment, 300);
            }
        }
    },
    methods: {
        hideModal() {
            this.$emit('close-details-modal');
        },
        setData(item) {
            this.approvalItem.name = item.name;
            this.approvalItem.subtext = item.subtext;
            if (item.onkaApprovalResults.length > 0) {
                let result = item.onkaApprovalResults[0];
                if (result.requestByUser) {
                    this.resultItem.requestByUser.name = result.requestByUser.surnameNameDividedByComma;
                    this.resultItem.requestByUser.email = result.requestByUser.email;
                }
                if (result.requestFromUser) {
                    this.resultItem.requestFromUser.name = result.requestFromUser.surnameNameDividedByComma;
                    this.resultItem.requestFromUser.email = result.requestFromUser.email;
                }
                if (result.checkedByUser) {
                    this.resultItem.checkedByUser.name = result.checkedByUser.surnameNameDividedByComma;
                    this.resultItem.checkedByUser.email = result.checkedByUser.email;
                }
                if (result.requestedAt) {
                    this.resultItem.requestedAt = dayjs(result.requestedAt).format('DD.MM.YYYY H:mm');
                }
                if (result.checkedAt) {
                    this.resultItem.checkedAt = dayjs(result.checkedAt).format('DD.MM.YYYY H:mm');
                }
                if (result.comment) {
                    this.resultItem.comment = result.comment;
                }
                this.resultItem.result = result.result;
            }
        },
        clearData() {
            this.approvalItem.name = '-'
            this.approvalItem.subtext = '-';
            this.resultItem.requestByUser.name = '-';
            this.resultItem.requestByUser.email = null;
            this.resultItem.requestFromUser.name = '-';
            this.resultItem.requestFromUser.email = null;
            this.resultItem.checkedByUser.name = '-';
            this.resultItem.checkedByUser.email = null;
            this.resultItem.requestedAt = '-';
            this.resultItem.checkedAt = '-';
            this.resultItem.comment = null;
            this.resultItem.result = null;
        },
        hideUserModal() {
            this.isUserCardVisible = false;
            this.email = '';
        },
        showUserModal(email) {
            if (email === null) return;
            this.email = email;
            this.isUserCardVisible = true;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.link {
    color: $link;
    cursor: pointer;
    background: none;
    border: none;
    padding: 0;
}
.link:hover {
    text-decoration: underline;
}
.row {
    margin-bottom: 10px;
}
.first-column {
    width: 35%;
}
.table-fixed {
    table-layout: fixed;
    width: 100%;
}
.message-content-icon {
    min-width: 20px;
    min-height: 20px;
    max-width: 20px;
    max-height: 20px;
    margin-right: 5px;
    vertical-align: sub;
}
</style>
