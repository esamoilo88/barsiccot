<template>
    <div>
        <span class="mb-4 d-block">Laufzeiten</span>
        <div>
            <div v-for="[name, values] in Object.entries(dates)" :key="name" class="d-flex flex-column mb-3">
                <span class="mb-1">{{ name }}:</span>
                <div v-if="values.start && values.end">
                    <span class="font-weight-bold">{{ values.start }} - {{ values.end }}</span>
                    <span class="ml-3">{{ monatText(values.difference) }}</span>
                </div>
                <div v-else class="font-weight-bold">-</div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Laufzeiten",
    props: {
        data: {
            type: Object,
            required: true,
            default: () => ({})
        }
    },
    data() {
        return {
            dates: {
                Vertragslaufzeit: {
                    start: this.data.dates.vertragsbeginn ?? null,
                    end: this.data.dates.vertragsende ?? null,
                    difference: this.data.dates.vertragsDifference ?? '-',
                },
                Realisierungslaufzeit: {
                    start: this.data.dates.rolloutbeginn ?? null,
                    end: this.data.dates.rolloutende ?? null,
                    difference: this.data.dates.rolloutDifference ?? '-',
                },
                Betriebslaufzeit: {
                    start: this.data.dates.betriebsbeginn ?? null,
                    end: this.data.dates.betriebsende ?? null,
                    difference: this.data.dates.betriebsDifference ?? '-',
                },
            }
        }
    },
    methods: {
        monatText(value) {
            switch(value) {
                case 0:
                    return '< 1 Monat';
                case 1:
                    return value + ' Monat';
                default:
                    return value + ' Monate';
            }
        }
    }
}
</script>

<style scoped>

</style>
