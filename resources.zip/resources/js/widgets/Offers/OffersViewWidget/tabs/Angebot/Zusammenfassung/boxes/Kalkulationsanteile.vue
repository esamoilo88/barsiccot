<template>
    <div>
        <span class="mb-4 d-block">Kalkulationsanteile</span>
        <div>
            <table v-if="data.costrates !== undefined && data.costrates.length > 0" id="kalkulationsanteile-tbl" class="w-100">
                <thead>
                <tr>
                    <th>Typ</th>
                    <th class="text-right">Kosten</th>
                    <th class="text-right">Anteil</th>
                    <th class="text-center">Info</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="cost in costratesToDisplay" :key="cost.kostenartId">
                    <td class="zuordnung-column">
                        {{ cost.approvalGroup }}
                    </td>
                    <td class="text-right kosten-column">
                        {{ $f.numberToString(cost.wert, true) }}
                    </td>
                    <td class="text-right anteil-column">
                        {{ $f.numberToString(cost.prozent, false, false, '0,0', {maximumFractionDigits: 2}) }} %
                    </td>
                    <td class="text-center info-column">
                            <span
                                class="icon-alert-information-default"
                                :title="getCostratesGroupTooltip(cost.approvalGroup)"
                                v-b-tooltip.hover
                            ></span>
                    </td>
                </tr>
                <tr class="expand-list-row">
                    <td colspan="4">
                        <button
                            v-if="costratesToDisplay.length > 5"
                            @click="isFullCostratesList=!isFullCostratesList"
                            class="btn btn-link pl-0 expand-list-btn"
                        >
                            {{
                                isFullCostratesList ? 'ausblenden' : 'Weitere Kostenarten anzeigen (' + (costratesToDisplay.length - 5) + ')'
                            }}
                        </button>
                    </td>
                </tr>
                </tbody>
                <tfoot>
                <tr>
                    <td class="text-left sum-column">Summe</td>
                    <td class="text-right">{{ $f.numberToString(sum, true) }}</td>
                </tr>
                </tfoot>
            </table>

            <div v-else class="text-center">Keine Daten vorhanden</div>
        </div>
    </div>
</template>

<script>
import {isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";
import {VBTooltip} from "bootstrap-vue";

export default {
    name: "Kalkulationsanteile",
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        data: {
            type: Object,
            required: true,
            default: () => ({})
        }
    },
    data() {
        return {
            isFullCostratesList: false
        }
    },
    computed: {
        costratesToDisplay() {
            if (!isEmpty(this.data.costrates)) {
                let costrates = this.groupCostrates(this.data.costrates);
                return !this.isFullCostratesList ? costrates.slice(0, 5) : costrates;
            } else {
                return [];
            }
        },
        sum() {
            let sum = 0;
            this.costratesToDisplay.map(cost => sum += cost.wert);
            return sum;
        },
    },
    methods: {
        groupCostrates(costrates) {
            let groups = new Map();
            costrates.map(c => {
                if (!groups.get(c.approvalGroup)) {
                    groups.set(c.approvalGroup, []);
                    groups.get(c.approvalGroup).push(c);
                    let item = groups.get(c.approvalGroup)[0];
                    delete item.bezeichnung;
                    delete item.kostenartId;
                    delete item.stundensatz;
                    delete item.zuordnung;
                    item.prozent = Math.round((item.prozent + Number.EPSILON) * 100) / 100
                } else {
                    groups.get(c.approvalGroup)[0].wert += c.wert
                    groups.get(c.approvalGroup)[0].prozent += Math.round((c.prozent + Number.EPSILON) * 100) / 100
                }
            });
            let result = [];
            groups.forEach(value => result.push(...value));
            return result;
        },
        getCostratesGroupTooltip(group) {
            switch (group) {
                case 'DTA':
                    return "Leistung DTA (EL + eEL + bei DTA verbuchte SaKo, Mako)";
                case 'ISP':
                    return "Eigenleistung DT ISP GmbH";
                case 'DTS':
                    return "Leistung DTS (EL + eEL + bei DTS verbuchte SaKo, Mako + MWW)";
                case 'Fremdleistung':
                    return "Bezogene Dienstleistungen (Dienstvertrag oder Werkvertrag) der DT ISP; nicht: " +
                        "Transportleistungen für Material (wenn bei DTS-MWW verbucht) oder FL der DTA";
                case 'Material':
                    return "Verbrauchsmaterial, Werkzeug, Messgeräte, soweit explizit für dieses Angebot verbraucht " +
                        "bzw. beschafft; Ersatzgeräte. Nur Material, dessen Aufwand direkt bei der DT ISP verbucht wird " +
                        "(durch den Kunden beigestelltes Material wird hier nicht aufgeführt). Der Aufwand für bereits " +
                        "vorhandenes Werkzeug und vorhandene Messgeräte aus dem Messgerätepool braucht nicht einzeln " +
                        "kalkuliert zu werden.";
                case 'Risiko':
                    return "Von der DT ISP zu tragende Risiken; gewichtete Schadenshöhe gem. Risikomatrix; auch " +
                        "Risiken durch Kostensteigerungen bei DTS/DTA";
                case 'Sachkosten':
                    return "Kosten für Material, Rechte, Lizenzen, Miete, Transportkosten, Domaingebühren, " +
                        "eTTs-Tickets, einzeln kalkulierte Reise- und Fortbildungskosten und sonstige Kosten, " +
                        "die nicht unter eine andere Kategorie fallen - soweit diese bei ISP anfallen";
                case 'Sonstiges':
                    return "Sonstige Kosten die in keine der anderen Kategorien fallen";
            }
        }
    }
}
</script>

<style lang="scss" scoped>
tfoot {
    font-weight: bold;
}

table {
    td {
        padding: 5px 0;
    }
}

.approval-group-column {
    width: 25%;
}

.kosten-column {
    width: 30%;
}

.anteil-column {
    width: 25%;
}

.info-column {
    width: 20%;
}
</style>
