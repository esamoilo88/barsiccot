<template>
    <div>
        <h5>
            <span class="icon-user_file-draft-file-default"></span>
            DIVEXML
        </h5>

        <div class="text-muted">
            <p>Exportiere die Stammdaten und Angebotspositionen in das DIVEXML Format um diese Datei per Mail an das DIVE/Flamingo System weiterleiten zu können.</p>

            <p>Flamingo Vorgangsnummer:
                <template v-if="offer.dive_telekom_reference">
                    {{ offer.dive_telekom_reference }}
                </template>
                <template v-else>
                    unbekannt
                </template>
            </p>
        </div>

        <button class="btn btn-primary" :disabled="!hasPermissions" @click="setVisible(true)">
            <span class="icon-action-download-default"></span>
            Export
        </button>

        <modal-dialog
            :is-visible="visible"
            @hideModal="setVisible(false)"
            title-dialog="DIVEXML Export"
            modal-class="dive-xml-export-modal-dialog"
        >
            <b-form-group>
                <FormInput
                    v-model="form.diveTelekomReference"
                    label-text="Flamingo Vorgangsnummer"
                    name="diveTelekomReference"
                    input-id="diveTelekomReference-input"
                    :error-conditions="errorConditions.diveTelekomReference"
                />
            </b-form-group>

            <b-form-group>
                <FormDatepicker
                    v-model="form.validity"
                    label-text="Angebot gültig bis"
                    name="validity"
                    input-id="validity-input"
                    aria-controls="date-input"
                    :error-conditions="errorConditions.validity"
                />
            </b-form-group>

            <template v-slot:footer>
                <button class="btn btn-primary" @click="exportDiveXml">
                    <b-spinner v-if="loading" small></b-spinner>
                    DIVEXML exportieren
                </button>
                <button class="btn btn-secondary" @click="setVisible(false)">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {mapGetters, mapMutations, mapState} from "vuex";
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {BFormGroup, BSpinner} from 'bootstrap-vue';
import FormInput from '@comp/FormInput/FormInput';
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import {required, numeric} from "vuelidate/lib/validators";
import {isDate, moreThanToday} from "res/js/utils/Validators/DatesValidators";
import dayjs from "res/js/utils/day";

export default {
    components: {ModalDialog, BFormGroup, FormInput, FormDatepicker, BSpinner},
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion',
            angebotGueltigBis: 'offer/angebotGueltigBis'
        }),

        hasPermissions() {
            return this.offer.is_active &&
                (
                    this.offer.user.isAdmin ||
                    this.offer.user.userRoles.includes('SC') ||
                    this.offer.user.userRoles.includes('AE')
                )
        },
        errorConditions() {
            return {
                diveTelekomReference: [
                    {
                        name: 'diveTelekomReference-required',
                        condition: !this.$v.form.diveTelekomReference.required && this.$v.form.diveTelekomReference.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Flamingo Vorgangsnummer'})
                    },
                    {
                        name: 'diveTelekomReference-numeric',
                        condition: !this.$v.form.diveTelekomReference.numeric && this.$v.form.diveTelekomReference.$dirty,
                        text: this.$t.__('validation.numeric', {attribute: 'Flamingo Vorgangsnummer'})
                    },
                ],
                validity: [
                    {
                        name: 'validity-required',
                        condition: !this.$v.form.validity.required && this.$v.form.validity.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Angebot gültig bis'})
                    },
                    {
                        name: 'validity-isDate',
                        condition: !this.$v.form.validity.isDate && this.$v.form.validity.$dirty,
                        text: this.$t.__('validation.date', {attribute: 'Angebot gültig bis'})
                    },
                    {
                        name: 'validity-moreThanToday',
                        condition: !this.$v.form.validity.moreThanToday && this.$v.form.validity.$dirty,
                        text: 'Das Datum muss in der Zukunft liegen.'
                    }
                ],
            }
        }
    },
    data() {
        return {
            visible: false,
            loading: false,
            link: null,
            form: {
                diveTelekomReference: null,
                validity: null
            }
        }
    },
    mounted() {
        this.form.validity = this.angebotGueltigBis
    },
    methods: {
        ...mapMutations({
            'updateValidity': 'offer/SET_ANGEBOT_GUELTIG_BIS'
        }),

        async exportDiveXml() {
            this.$v.$touch();

            if (this.$v.$anyError) return;

            this.loading = true;

            try {
                const url = `/offers/${this.simpleId}/versions/${this.currentVersion}/divexml/export`;

                const response = await this.$axios.put(url, this.form) || {data: null};

                window.open(`${url}/${response.data}`, '_blank').focus();

                this.setVisible(false);
                this.clearForm();

                this.updateValidity(this.form.validity);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.loading = false;
        },
        clearForm() {
            this.form.diveTelekomReference = null;

            this.$v.$reset();
        },
        setVisible(visible = true) {
            this.visible = visible;
        }
    },
    validations: {
        form: {
            diveTelekomReference: {required, numeric},
            validity: {
                moreThanToday,
                required,
                isDate
            },
        }
    }
}
</script>
