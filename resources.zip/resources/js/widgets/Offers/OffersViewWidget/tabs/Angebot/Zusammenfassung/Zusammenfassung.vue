<template>
    <div class="simple-box d-flex flex-column">
        <b-overlay :show="pending">
            <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon" src="/img/icons/price-tag_graphical.svg" alt="price tag"/>
                <div class="d-flex flex-column">
                    <h2>Zusammenfassung</h2>
                    <span class="text-muted secondary-text">
                        Zeigt Daten für die kaufmännische Freigabe an.
                    </span>
                </div>
                <button @click="toggleBoxesVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible">
                <div class="horizontal-line mb-3"></div>
                <div class="row">
                    <div class="col-lg-12 pl-0 pr-lg-4 right-line">
                        <Kalkulationsanteile :data="kalkulationsanteile"/>
                    </div>
                    <div class="col-lg-12 pl-lg-5">
                        <Auftragsvolumen :data="auftragsvolumen"/>
                    </div>
                </div>
                <div class="horizontal-line mt-3 mb-3"></div>
                <div class="row">
                    <div class="col-lg-12 pl-0 pr-lg-4 right-line">
                        <Laufzeiten :data="laufzeiten"/>
                    </div>
                    <div class="col-lg-12 pl-lg-5">
                        <Leistungsanteile :data="leistungsanteile"/>
                    </div>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import Kalkulationsanteile from "./boxes/Kalkulationsanteile";
import Auftragsvolumen from "./boxes/Auftragsvolumen";
import Laufzeiten from "./boxes/Laufzeiten";
import Leistungsanteile from "./boxes/Leistungsanteile";
import {mapGetters} from "vuex";
import {BOverlay} from 'bootstrap-vue';

export default {
    name: "Zusammenfassung",
    components: {
        Kalkulationsanteile, Auftragsvolumen, Laufzeiten, Leistungsanteile,
        BOverlay
    },
    async created() {
        await this.init();
    },
    data() {
        return {
            isContentVisible: false,
            kalkulationsanteile: {},
            auftragsvolumen: {},
            laufzeiten: {},
            leistungsanteile: {},
            pending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        })
    },
    methods: {
        toggleBoxesVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        async init() {
            this.pending = true;
            try {
                let res = await this.$axios.get(`/offers/${this.simpleId}/versions/${this.currentVersion}/angebot-data`);
                // kalkulationsanteile data
                this.kalkulationsanteile.costrates = [];
                this.kalkulationsanteile.costrates.push(...res.data.kalkulationsanteile.costrates);
                // auftragsvolumen data
                this.auftragsvolumen.avgInflation = res.data.auftragsvolumen.avgInflation;
                // laufzeiten data
                this.laufzeiten.dates = res.data.laufzeiten.dates;
                // leistungsanteile data
                this.leistungsanteile.itil = [];
                this.leistungsanteile.itil.push(...res.data.leistungsanteile.itil);
            } catch (err) {
                console.log("Couldn't fetch Angebot data", err);
            }
            this.pending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    width: 46px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}

.right-line {
    border-right: 3px solid #dee2e6;
}
</style>
