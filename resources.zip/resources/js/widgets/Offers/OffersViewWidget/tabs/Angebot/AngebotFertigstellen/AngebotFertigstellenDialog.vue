<template>
    <modal-dialog
        :is-visible="isVisible"
        modal-class="angebot-fertigstellen-dialog"
        size="md"
        title-dialog="Angebot fertigstellen"
        @hideModal="$emit('close-angebot-fertigstellen-dialog')"
    >
        <div class="text-muted mb-4">
            Das Angebot wird nun fertiggestellt und damit in den Status S5 überführt.<br>
            Du kannst diesen Schritt bis zu 2 Tage nach dem Fertigstellen selbst rückgängig machen.
        </div>
        <div class="simple-box mb-4">
            <table class="table-fixed mb-5">
                <tr class="row">
                    <td class="first-column">Gesamtkosten des Angebots:</td>
                    <td class="font-weight-bold">{{ formatNumber(offerInfo.sumVk) }} €</td>
                </tr>
                <tr class="row">
                    <td class="first-column">Gesamtpreis des Angebots:</td>
                    <td class="font-weight-bold">{{ formatNumber(offerInfo.sumTp) }} €</td>
                </tr>
                <tr class="row">
                    <td class="first-column">
                        Effektive Marge:
                    </td>
                    <td :class="{
                        'header-data__risiko': true,
                        'text-success': offerInfo.risiko > 0,
                        'text-danger': offerInfo.risiko < 0,
                        'font-weight-bold': true
                    }">
                        {{ formatNumber(offerInfo.risiko) }} %
                    </td>
                </tr>
            </table>
            <div class="d-flex flex-column">
                <b-form-checkbox v-model="withEmail" switch>E-Mail senden</b-form-checkbox>
                <span class="text-muted switch-secondary-text">
                    Sendet das Angebot per Mail an die hinterlegten Rollen Angebotsersteller und Sales Consultant.
                </span>
            </div>
        </div>
        <template #footer="{methods}">
            <button
                :key="'approval-confirm-btn'"
                @click="onSubmit"
                class="btn btn-primary"
                :disabled="onSubmitPending"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Angebot fertigstellen
            </button>
            <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {mapGetters, mapActions} from "vuex";
import {BFormCheckbox, BSpinner} from "bootstrap-vue";

export default {
    name: "AngebotFertigstellenDialog",
    components: {ModalDialog, BFormCheckbox, BSpinner},
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false,
        }
    },
    computed: {
        ...mapGetters({
            offerInfo: 'offer/offerInfo',
            simpleId: 'offer/simpleId',
            vkVersionId: 'offer/currentVersion'
        })
    },
    data() {
        return {
            withEmail: true,
            onSubmitPending: false
        }
    },
    methods: {
        ...mapActions({
            fetchOfferData: "offer/fetchOfferData"
        }),
        async onSubmit() {
            this.onSubmitPending = true;
            try {
                let res = await this.$axios.post(`/offers/${this.simpleId}/vkVersions/${this.vkVersionId}/complete`, {
                    'sendEmail': this.withEmail
                });
                window.flash.showMessagesFromAjax(res.data);
                this.$emit('refresh-angebotsfreigaben');
                this.$emit('close-angebot-fertigstellen-dialog');
            } catch (err) {
                console.error(`Couldn't complete offer`, err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            await this.fetchOfferData({simpleId: this.simpleId, currentVersion: this.vkVersionId});
            this.onSubmitPending = false;
        },
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
    }
}
</script>

<style lang="scss" scoped>
.row {
    margin-bottom: 10px;
}

.first-column {
    width: 55%;
}

.table-fixed {
    table-layout: fixed;
    width: 100%;
}
</style>
