export default {
    data() {
        return {
            requestApprovalVisible: false,
            requestApprovalItem: null,
        }
    },
    methods: {
        async showRequestApprovlDialog( item) {
            this.requestApprovalItem = item;
            this.requestApprovalVisible = true;
        },
        hideRequestApprovalDialog() {
            let itemId = this.requestApprovalItem.id;
            this.requestApprovalItem = null;
            this.requestApprovalVisible = false;
            this.$refs.approval.clearForm();
            let buttonSelector = '.btn-anfordern';
            document.querySelector('.approval-' + itemId + ' ' + buttonSelector).focus();

        }

    }
}
