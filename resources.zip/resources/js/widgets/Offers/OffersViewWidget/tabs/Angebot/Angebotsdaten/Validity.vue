<template>
    <div>
        <h5>
            <span class="icon-content-calendar-default"></span>
            Angebotsgültigkeit
        </h5>
        <div class="row no-gutters justify-content-between">
            <div class="col-md-18">
                <p class="text-muted">
                    Die Angebotsgültigkeit gibt Aufschluss darüber wie lange sich die DT ISP an die Konditionen im Angebot gebunden ist.
                </p>
                <div class="form-row">
                    <div class="col-auto">
                        <b-form-group>
                            <FormDatepicker
                                v-model="form.validity"
                                name="validity"
                                :label-text="label"
                                input-id="validity-input"
                                aria-controls="date-input"
                                :error-conditions="errorConditions.validity"
                                :readonly="!hasPermissions"
                                :datepicker-disabled="!hasPermissions"
                            />
                        </b-form-group>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-primary mt-2" v-if="hasPermissions" @click="submit">
                            <b-spinner v-if="loading" small></b-spinner>
                            Speichern
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-auto">
                <img
                    v-if="angebotGueltigBis"
                    v-b-tooltip.hover
                    class="icon mr-2"
                    :src="`/img/icons/confirm_graphical.svg`"
                    alt="Angebotsgültigkeit ausgefüllt"
                    title="Angebotsgültigkeit ausgefüllt"
                    v-b-tooltip.hover
                />
                <img
                    v-else
                    v-b-tooltip.hover
                    class="icon mr-2"
                    :src="`/img/icons/warning_graphical.svg`"
                    alt="Angebotsgültigkeit nicht ausgefüllt"
                    title="Angebotsgültigkeit nicht ausgefüllt"
                    v-b-tooltip.hover
                />
            </div>
        </div>
    </div>
</template>

<script>
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import {BFormGroup, BSpinner, VBTooltip} from 'bootstrap-vue';
import {required} from "vuelidate/lib/validators";
import {isDate, moreThanToday} from "res/js/utils/Validators/DatesValidators";
import {mapMutations, mapGetters, mapState} from "vuex";

export default {
    components: {FormDatepicker, BFormGroup, BSpinner, VBTooltip},
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            form: {
                validity: null
            },
            label: 'Angebot gültig bis',
            loading: false
        }
    },
    mounted() {
        this.form.validity = this.angebotGueltigBis;
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer || {is_active: false, is_presales: false, user: {userRoles: []}}
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion',
            angebotGueltigBis: 'offer/angebotGueltigBis'
        }),
        hasPermissions() {
            return this.offer.is_active &&
                this.offer.is_presales &&
                (
                    this.offer.user.isAdmin ||
                    this.offer.user.userRoles.includes('SC') ||
                    this.offer.user.userRoles.includes('AE')
                )
        },
        errorConditions() {
            return {
                validity: [
                    {
                        name: 'validity-required',
                        condition: !this.$v.form.validity.required && this.$v.form.validity.$dirty,
                        text: this.$t.__('validation.required', {attribute: this.label})
                    },
                    {
                        name: 'validity-isDate',
                        condition: !this.$v.form.validity.isDate && this.$v.form.validity.$dirty,
                        text: this.$t.__('validation.date', {attribute: this.label})
                    },
                    {
                        name: 'validity-moreThanToday',
                        condition: !this.$v.form.validity.moreThanToday && this.$v.form.validity.$dirty,
                        text: 'Das Datum muss in der Zukunft liegen.'
                    }
                ]
            }
        }
    },
    methods: {
        ...mapMutations({
            'updateValidity': 'offer/SET_ANGEBOT_GUELTIG_BIS'
        }),
        async submit() {
            this.$v.$touch();

            if (this.$v.$anyError) return;

            if (this.form.validity === this.angebotGueltigBis) {
                window.flash.error('Sie versuchen, denselben Wert zu speichern.');

                return;
            }

            this.loading = true;

            try {
                await this.$axios.put(`/offers/${this.simpleId}/versions/${this.currentVersion}/validity`, this.form);

                window.flash.success('Erfolgreich gespeichert.');

                this.updateValidity(this.form.validity);
                this.$eventBus.$emit('refresh-fertigstellen-box', {subject: 'angebot-gueltig'});
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            } finally {
                this.loading = false;
            }
        }
    },
    validations: {
        form: {
            validity: {required, isDate, moreThanToday}
        }
    }
}
</script>
