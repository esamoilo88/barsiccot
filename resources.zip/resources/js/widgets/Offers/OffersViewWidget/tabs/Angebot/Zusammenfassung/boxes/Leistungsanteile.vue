<template>
    <div>
        <span class="mb-4 d-block">Leistungsanteile</span>
        <div v-if="data.itil && data.itil.length > 0">
            <div v-for="itilMain in data.itil" :key="itilMain.itilMainId" class="row mb-2">
                <div class="pl-0 col-lg-7">
                    {{ itilMain.bezeichnung }}
                </div>
                <div class="col-lg-13 font-weight-bold">
                    {{ $f.numberToString(itilMain.percent, false, false, null, {maximumFractionDigits: 0}) }} %
                </div>
            </div>
        </div>

        <div v-else class="text-center">Keine Daten vorhanden</div>
    </div>
</template>

<script>
export default {
    name: "Leistungsanteile",
    props: {
        data: {
            type: Object,
            required: true,
            default: () => ({})
        }
    }
}
</script>

<style scoped></style>
