<template>
    <div class="simple-box d-flex flex-column">
        <b-overlay :show="pending">
            <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon" src="/img/icons/contract_graphical.svg" alt="contract"/>
                <div class="d-flex flex-column">
                    <h2>Angebotsdaten</h2>
                    <span class="text-muted secondary-text">
                        Lade das Angebotsdokument hoch und setze die Angebotsgültigkeit.
                    </span>
                </div>
                <button @click="toggleContentVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible">
                <div class="horizontal-line mb-3"></div>

                <AngebotsDocUpload/>
                <hr/>
                <Validity/>

            </div>
        </b-overlay>
    </div>
</template>

<script>
import {mapGetters} from "vuex";
import {BOverlay} from 'bootstrap-vue';
import Validity from "./Validity";
import AngebotsDocUpload from "./AngebotsDocUpload";

export default {
    name: "Angebotsdaten",
    components: {
        AngebotsDocUpload,
        BOverlay,
        Validity
    },
    data() {
        return {
            isContentVisible: false,
            pending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        })
    },
    methods: {
        toggleContentVisibility() {
            this.isContentVisible = !this.isContentVisible;
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    width: 46px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}
</style>
