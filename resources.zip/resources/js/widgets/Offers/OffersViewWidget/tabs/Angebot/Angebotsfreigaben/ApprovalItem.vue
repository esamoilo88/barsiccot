<template>
    <div class="approval-line-item mt-4">
        <img
            v-if="iconType === 'success'"
            v-b-tooltip.hover
            class="message-content-icon"
            src="/img/icons/confirm_graphical.svg"
            alt="Freigabe erteilt"
            :id="'success-icon-'+item.id"
            title="Freigabe erteilt"
        />
        <img
            v-else-if="iconType === 'error'"
            v-b-tooltip.hover
            class="message-content-icon"
            src="/img/icons/error_graphical.svg"
            alt="Freigabe abgelehnt"
            :id="'error-icon-'+item.id"
            title="Freigabe abgelehnt"
        />
        <img
            v-else
            v-b-tooltip.hover
            class="message-content-icon"
            src="/img/icons/help_graphical.svg"
            alt="Freigabe offen"
            :id="'question-icon-'+item.id"
            title="Freigabe offen"
        />
        <div class="d-flex align-items-center">
            <span
                :class="item.icon"
                style="font-size: 24px"
                :title="item.name"
            />
            <span class="ml-2">{{ item.name }}</span>
        </div>
        <p class="text-muted w-75 text-break mt-2">{{ item.subtext }}</p>
        <div class="d-flex justify-content-between pt-2 pb-3">
            <div>
                <b-button class="btn btn-anfordern" @click="$emit('anforder-clicked', item)"
                        v-if="canApprove">
                    <span class="icon-communication-email-default mr-1 align"></span>
                    <span class="align">Anfordern</span>
                </b-button>
                <button class="btn btn-secondary" @click="$emit('anzeigen-clicked', item)">Anzeigen</button>
            </div>
            <div>
                <button class="btn btn-freigaben" @click="$emit('freigaben-clicked', item)">
                    <span class="icon-action-succsess-default mr-1 align"></span>
                    <span class="align">Freigeben</span>
                </button>
                <button class="btn btn-ablehnen" @click="$emit('ablehnen-clicked', item)">
                    <span class="icon-action-circle-close-default mr-1 align"></span>
                    <span class="align">Ablehnen</span>
                </button>
            </div>
        </div>
        <div class="text-muted">
            <div v-if="result.requestedAt" v-for="result in item.onkaApprovalResults">
                Gesendet am {{ formatDate(result.requestedAt, 'DD.MM.YYYY H:mm') }} an {{ requestFromUser(result) }}
            </div>
        </div>
    </div>
</template>

<script>
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {VBTooltip,BButton} from 'bootstrap-vue';
import {mapState} from "vuex";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: "ApprovalItem",
    components: {ButtonIcon, VBTooltip, BButton},
    mixins: [DatesProcessing],
    props: {
        item: {
            required: true,
            type: Object
        }
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    computed: {
        ...mapState({
                offer: state => state.offer.offer
            }),
        canApprove(){
            return this.offer.is_onka_writable &&
            this.offer.is_active &&
            this.offer.is_presales &&(
                this.offer.user.isAdmin
                || this.offer.user.userRoles.includes('AE')
            )
        },
        iconType() {
            let result = this.item.onkaApprovalResults;
            if (result.length === 0 || result[0].result === null) {
                return null;
            }
            if (result[0].result === true) {
                return 'success';
            } else {
                return 'error';
            }
        }
    },
    methods:{
        anforderClicked(item){
            this.$refs.approval.showModal(item);
        },
        requestFromUser(result){
            return (result.requestFromUser != null) ? result.requestFromUser.email : result.reqFromMail;
        }
    }
}
</script>

<style scoped lang="scss">
@import "resources/sass/variables.scss";

.horizontal-line {
    height: 2px;
    background-color: #dee2e6;
}

.message-content-icon {
    position: absolute;
    min-width: 50px;
    min-height: 50px;
    max-width: 50px;
    max-height: 50px;
    right: 0;
}

.message-content-icon.error {
    fill: $error;
}

.message-content-icon.success {
    fill: $success;
}

.approval-line-item {
    position: relative;
}

.btn-freigaben {
    background-color: $success;
    border-color: $success;
    color: #fff;
}
.btn-anfordern {
    background-color: $primary;
    border-color: $primary;
    color: #fff;
}

.btn-ablehnen {
    background-color: $error;
    border-color: $error;
    color: #fff;
}
.align {
    vertical-align: text-top;
}
</style>
