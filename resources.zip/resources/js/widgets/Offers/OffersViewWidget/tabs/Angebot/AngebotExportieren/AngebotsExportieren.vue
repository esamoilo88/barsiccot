<template>
    <div class="simple-box d-flex flex-column">
        <b-overlay :show="pending">
            <div :class="{'d-flex': true, 'align-items-center': true, 'mb-4': isContentVisible}">
                <img class="mr-4 icon" src="/img/icons/download_graphical.svg" alt="download"/>
                <div class="d-flex flex-column">
                    <h2>Angebot runterladen</h2>
                    <span class="text-muted secondary-text">
                        Lade das Angebot in verschiedenen Formaten runter.
                    </span>
                </div>
                <button @click="toggleContentVisibility" class="btn btn-secondary ml-auto">
                    {{ isContentVisible ? "Ausblenden" : "Anzeigen" }}
                </button>
            </div>

            <div v-if="isContentVisible">
                <div class="horizontal-line mb-3"></div>
                <ExportDiveXml/>
                <div class="horizontal-line-thin mb-3 mt-3"></div>
                <ExportOstXml/>
                <div class="horizontal-line-thin mb-3 mt-3"></div>
                <ExportOnka/>
                <div class="horizontal-line-thin mb-3 mt-3"></div>
                <ExportQuote/>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {mapGetters} from "vuex";
import {BOverlay} from 'bootstrap-vue';
import ExportDiveXml from "./ExportDiveXml";
import ExportOstXml from "./ExportOstXml";
import ExportOnka from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebot/AngebotExportieren/ExportOnka";
import ExportQuote from "../AngebotExportieren/ExportQuote"
export default {
    name: "AngebotsExportieren",
    components: {
        ExportOnka,
        BOverlay, ExportDiveXml, ExportOstXml, ExportQuote
    },
    async created() {
        await this.init();
    },
    data() {
        return {
            isContentVisible: false,
            pending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        })
    },
    methods: {
        toggleContentVisibility() {
            this.isContentVisible = !this.isContentVisible;
        },
        async init() {
            this.pending = true;
            // TODO load any async data if necessary
            this.pending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    width: 46px;
}

.secondary-text {
    font-size: 17px;
}

.horizontal-line {
    height: 3px;
    background-color: #dee2e6;
}
.horizontal-line-thin {
    height: 1.5px;
    background-color: #dee2e6;
}
</style>
