<template>
    <div>
        <span class="mb-4 d-block">Auftragsvolumen ISP</span>
        <div>
            <div class="row av-gesamtkosten">
                <div class="pl-0 col-lg-10 col-md-10 col-sm-10 my-2">Gesamtkosten:</div>
                <div class="pr-0 col-lg-12 col-md-12 col-sm-12 font-weight-bold my-2">
                    {{ $f.numberToString(offer.offerInfo.sumVk, true) }}
                </div>
            </div>

            <div class="row av-gesamtpreis">
                <div class="pl-0 col-lg-10 col-md-10 col-sm-10 my-1">Gesamtpreis:</div>
                <div class="pr-0 col-lg-12 col-md-12 col-sm-12 font-weight-bold my-1">
                    {{ $f.numberToString(offer.offerInfo.sumTp, true) }}
                </div>
            </div>

            <div class="row av-ergebnis">
                <div class="pl-0 col-lg-10 col-md-10 col-sm-10 my-2">Ergebnis:</div>
                <div :class="{
                    'pr-0': true,
                    'col-lg-12': true,
                    'col-md-12': true,
                    'col-sm-12': true,
                    'font-weight-bold': true,
                    'text-danger': costsDifference < 0,
                    'text-success': costsDifference > 0,
                    'my-2': true
                }">
                    {{ $f.numberToString(costsDifference, true) }} <br/>
                    {{ $f.numberToString(offer.offerInfo.risiko, false, false, '0,0', {maximumFractionDigits: 1}) }} %
                </div>
            </div>

            <div class="row av-inflation">
                <div class="pl-0 col-lg-10 col-md-10 col-sm-10 my-1">&Oslash; Inflation:</div>
                <div class="pr-0 col-lg-12 col-md-12 col-sm-12 font-weight-bold my-1">
                    {{ $f.numberToString(data.avgInflation, false, false, '0,00', {maximumFractionDigits: 4}) }}
                    <span
                        class="icon-alert-information-default ml-3"
                        title="Im Angebot durchschnittliche erfasste Inflationsfaktoren."
                        v-b-tooltip.hover
                    >
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {VBTooltip} from 'bootstrap-vue';
import {mapState} from 'vuex';

export default {
    name: "Auftragsvolumen",
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        data: {
            type: Object,
            required: true,
            default: () => ({})
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        costsDifference() {
            return this.offer.offerInfo.sumTp - this.offer.offerInfo.sumVk
        }
    }
}
</script>

<style lang="scss" scoped>
.av-gesamtkosten,
.av-gesamtpreis,
.av-ergebnis,
.av-inflation {
    div:last-child {
        font-size: 1.3rem;
    }
}
</style>
