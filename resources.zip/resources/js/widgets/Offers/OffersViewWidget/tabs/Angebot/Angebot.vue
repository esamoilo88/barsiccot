<template>
    <div class="row">
        <div class="col-lg-7 pr-lg-2 pr-md-0 pr-sm-0 pl-0">
            <AngebotFertigstellen/>
        </div>
        <div class="col-lg-17 pl-lg-2 pl-md-0 pl-sm-0 pr-0 mt-lg-0 mt-md-2 mt-sm-2">
            <div class="d-flex flex-column">
                <Zusammenfassung class="mb-4"/>
                <Angebotsfreigaben class="mb-4"/>
                <AngebotsExportieren class="mb-4"/>
                <BeteiligteBereiche class="mb-4"/>
                <Angebotsdaten class="mb-4"/>
            </div>
        </div>
    </div>
</template>

<script>
import AngebotFertigstellen from "./AngebotFertigstellen/AngebotFertigstellen";
import Zusammenfassung from "./Zusammenfassung/Zusammenfassung";
import Angebotsfreigaben from "./Angebotsfreigaben/Angebotsfreigaben";
import AngebotsExportieren from "./AngebotExportieren/AngebotsExportieren";
import BeteiligteBereiche from "./BeteiligteBereiche/BeteiligteBereiche";
import Angebotsdaten from "./Angebotsdaten/Angebotsdaten";

export default {
    name: "Angebot",
    components: {
        Angebotsdaten, BeteiligteBereiche, AngebotsExportieren, Angebotsfreigaben,
        Zusammenfassung, AngebotFertigstellen,
    },
}
</script>

<style lang="scss" scoped></style>
