import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    mixins: [ConfirmationModal],
    methods: {
        async deleteVar(variable, simpleId, currentVersion) {
            const confirmed = await this.showConfirmationModal({
                title: 'Variable löschen',
                message: `Bitte bestätige die Löschung der Variable ${variable.bezeichnung}.`,
                okTitle: 'Variable löschen',
            });

            if (!confirmed) return;

            window.preloader.show();
            try {
                await this.$axios.delete(`/offers/${simpleId}/calculations/variables/${variable.variableId}`);

                window.flash.success('Variable erfolgreich gelöscht');
                this.updateData();
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
