<template>
    <modal-dialog
        :is-visible="isModalVisible"
        @hideModal="hideModal"
        :title-dialog="updateVariable === null ? 'Variable anlegen' : 'Variable bearbeiten'"

        modal-class="modal-var"
    >
        <div @keyup.enter="submit">
            <div class="mb-3">
                Bitte fülle alle mit * gekennzeichneten Felder aus.
            </div>
            <div class="simple-box">
                <b-form-group>
                    <FormInput
                        v-model="form.bezeichnung"
                        label-text="Bezeichnung*"
                        :error-conditions="errorConditions.bezeichnung"
                        name="bezeichnung"
                        input-id="bezeichnung"
                    />
                </b-form-group>
                <b-form-group>
                    <FormInput
                        v-model="form.wert"
                        label-text="Wert*"
                        :error-conditions="errorConditions.wert"
                        name="wert"
                        input-id="wert"
                        :use-formatter="true"
                        :formatter="formatWert"
                    />
                </b-form-group>
            </div>
        </div>

        <template v-slot:footer>
            <button
                v-if="updateVariable === null"
                :key="'store-var-btn'"
                @click="onCreate"
                class="btn btn-primary"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Variable erstellen
            </button>
            <button
                v-if="updateVariable !== null"
                :key="'update-var-btn'"
                @click="onUpdate"
                class="btn btn-primary"
            >
                <b-spinner v-if="onSubmitPending" small></b-spinner>
                Variable bearbeiten
            </button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import {mapGetters, mapState} from "vuex";
import {BButton, BFormGroup, BSpinner} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import {helpers, required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import Formatter from "res/js/utils/formatter";


const intorfloat = helpers.regex('intorfloat', /^(-?\d{1,8}(?:\,\d{1,10})?)$/);


export default {
    components: {FormInput, ModalDialog, BButton, BFormGroup, BSpinner},
    mixins: [Validation],
    props: {
        updateVariable: {
            type: Object,
            required: false,
            default: null
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'

        }),
        errorConditions() {
            return {
                wert: [
                    {
                        name: 'invalid-wert-required',
                        condition: this.isInvalid('wert', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Wert'})
                    },
                    {
                        name: 'invalid-wert-intorfloat',
                        condition: this.isInvalid('wert', 'intorfloat'),
                        text: this.$t.__('validation.not_regex', {attribute: 'Wert'})
                    }
                ],
                bezeichnung: [
                    {
                        name: 'invalid-bezeichnung-required',
                        condition: this.isInvalid('bezeichnung', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Bezeichnung'})
                    }
                ]
            }
        }

    },
    data() {
        return {
            isModalVisible: false,
            onSubmitPending: false,
            form: {
                bezeichnung: '',
                wert: ''
            }
        }
    },

    methods: {
        async showModal(item = null) {
            this.isModalVisible = true;
            if (item) {
                this.fillData(item);
            }
        },
        fillData(item) {
            this.form = {
                bezeichnung: item !== null ? item.bezeichnung : null,
                wert: item !== null ?
                    (new Formatter).numberToString(
                        item.wert, false, false, null, {maximumFractionDigits: 10})
                    : null
            }
        },

        /**
         * Format wert value
         */
        formatWert(value = null) {
            return value !== null ? value.toString().replace(/[^0-9,-]/, '') : null;
        },

        /**
         * Create Variable
         * @returns {void}
         */
        async onCreate() {
            if (!this.isValid()) {
                navigateToFirstInvalid();
            } else {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.post(`/offers/${this.simpleId}/calculations/variables/${this.currentVersion}`, this.form);
                    this.hideModal();
                    window.flash.showMessagesFromAjax(res.data);
                    this.$emit('getVariables');
                } catch (error) {
                    window.flash.showMessagesFromAjax(error.response.data);
                    console.error("Couldn't create VAR", error);
                }
                this.onSubmitPending = false;

            }

        },

        /**
         * Update Variable
         * @returns {void}
         */
        async onUpdate() {
            if (!this.isValid()) {
                navigateToFirstInvalid();
            } else {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.put(`/offers/${this.simpleId}/calculations/variables/${this.updateVariable.variableId}`,
                        {...this.form}
                    );
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    this.$emit('getVariables');
                    this.hideModal();
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't update VAR", err);
                }
                this.onSubmitPending = false;
            }
        },

        async submit() {
            if (this.updateVariable) {
                await this.onUpdate();
            } else {
                await this.onCreate();
            }
        },
        isValid() {
            this.showValidationErrors = false;

            this.$v.form.$touch();

            if (this.$v.form.$invalid) {
                this.showValidationErrors = true;

                return false;
            }

            return true;

        },
        hideModal() {
            this.clearForm();
            this.isModalVisible = false;
        },
        clearForm() {
            this.showValidationErrors = false;
            this.form = {};
        }

    },
    validations: {
        form: {
            bezeichnung: {
                required
            },
            wert: {
                required,
                intorfloat
            }
        }
    }

}
</script>
