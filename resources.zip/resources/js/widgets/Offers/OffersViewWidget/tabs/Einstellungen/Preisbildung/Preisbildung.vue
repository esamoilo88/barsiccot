<template>
    <div class="preisbildung-box simple-box d-flex flex-column mr-5">
        <div class="d-flex flex-column mb-3">
            <div class="row">
                <div class="col-lg-7 pl-0">
                    <label for="marge-input" class="marge-label">Marge:</label>
                </div>
                <div :class="{
                    'marge-value col-lg-11 pl-0': true,
                    'text-success': this.$f.stringToNumber(marge) > 0,
                    'text-danger': this.$f.stringToNumber(marge) < 0,
                }">
                    <InlineInputAppend
                        v-model="marge"
                        append-text="%"
                        input-id="marge-input"
                        :error-conditions="[
                            {
                                name: 'wrong-format-marge',
                                condition: !isValidNumber(marge, 'marge'),
                                text: $t.__('validation.wrong_data')
                            }
                        ]"
                        without-button
                        :disabled="!status.onkaWritable"
                    />
                </div>
            </div>
            <span class="text-muted mt-1">
                Die Marge wirkt multiplikativ auf die Stückkosten einer Angebotsposition
            </span>
        </div>
        <div class="gmkz d-flex flex-column mb-3">
            <div class="row">
                <div class="col-lg-7 pl-0">
                    <label for="gmkz-input" class="gmkz-label">GMKZ:</label>
                    <b-tooltip target="gmkz-input">
                        Gemeinkostenzuschlag
                    </b-tooltip>
                </div>
                <div :class="{
                    'gmkz-value col-lg-11 pl-0': true,
                    'text-success': this.$f.stringToNumber(gmkz) > 0,
                    'text-danger': this.$f.stringToNumber(gmkz) < 0,
                }">
                    <InlineInputAppend
                        v-model="gmkz"
                        append-text="%"
                        input-id="gmkz-input"
                        :error-conditions="[
                            {
                                name: 'wrong-format-gmkz',
                                condition: !isValidNumber(gmkz, 'gmkz'),
                                text: $t.__('validation.wrong_data')
                            }
                        ]"
                        without-button
                        :disabled="!status.onkaWritable"
                    />
                </div>
            </div>
            <span class="text-muted mt-1">
               Der Gemeinkostenzuschlag wird auf den Stückpreis der Angebotspositionen angewendet. Bei Angeboten ohne T-Systems Bezug beträgt der Zuschlag typischerweise 0%.            </span>
        </div>
        <div class="d-flex align-items-center mb-1 justify-content-between">
            <span class="font-weight-bold title-size mr-5"> Budgetangebot </span>
            <b-form-checkbox
                id="budgetangebot-switch"
                name="budgetangebot-switch"
                v-model="budgetangebot"
                :disabled="!status.onkaWritable"
                switch
            />
        </div>
        <div class="d-flex align-items-center mb-1 justify-content-between">
            <span class="font-weight-bold title-size"> Ausschreibung </span>
            <b-form-checkbox
                id="ausschreibung-switch"
                name="ausschreibung-switch"
                v-model="ausschreibung"
                :disabled="!status.onkaWritable"
                switch
            />
        </div>
        <div
            v-if="isUserHasRoles"
            class="mt-3">
            <b-form-group>
                <FormDatepicker
                    v-model="vertragsbeginn"
                    name="vertragsbeginn"
                    class="w-100 mb-1"
                    label-text="Geplanter Vertragsbeginn"
                    input-id="vertragsbeginn-input"
                    aria-controls="date-input"
                    :datepicker-disabled="!status.onkaWritable"
                    :readonly="!status.onkaWritable"
                    :error-conditions="[
                        {
                            name: 'not-date',
                            condition: !this.$v.vertragsbeginn.isDate,
                            text: this.$t.__('validation.offer.vertragsbeginn.isDate')
                        },
                        {
                            name: 'termine-date',
                            condition: this.termineErrors.vertragsbeginn !=null,
                            text: (this.termineErrors.vertragsbeginn !=null)?this.termineErrors.vertragsbeginn.join(' '):''
                        }
                    ]"
                >
                    <template v-slot:button>
                        <button
                            @click="addMonth('vertragsbeginn', vertragsbeginn)"
                            title="1 Monat hinzufügen"
                            :disabled="disabledButton(vertragsbeginn) || !status.onkaWritable"
                            class="btn btn-secondary submit-btn"
                        >
                            <span>+</span>
                        </button>
                        <button
                            @click="subtractsMonth('vertragsbeginn', vertragsbeginn)"
                            title="1 Monat abziehen"
                            :disabled="disabledButton(vertragsbeginn) || !status.onkaWritable"
                            class="btn btn-secondary submit-btn"
                        >
                            <span>-</span>
                        </button>
                    </template>
                </FormDatepicker>
            </b-form-group>

            <b-form-group>
                <FormDatepicker
                    v-model="vertragsende"
                    name="vertragsende"
                    class="w-100 mb-1"
                    label-text="Geplantes Vertragsende"
                    input-id="vertragsende-input"
                    aria-controls="date-input"
                    :datepicker-disabled="!status.onkaWritable"
                    :readonly="!status.onkaWritable"
                    :error-conditions="[
                        {
                            name: 'not-date',
                            condition: !this.$v.vertragsende.isDate,
                            text: this.$t.__('validation.offer.vertragsende.isDate')
                        },
                        {
                            name: 'termine-date',
                            condition: this.termineErrors.vertragsende !=null,
                            text: (this.termineErrors.vertragsende !=null)?this.termineErrors.vertragsende.join(' '):''
                        }
                    ]"
                >
                    <template v-slot:button>
                        <button
                            @click="addMonth('vertragsende', vertragsende)"
                            title="1 Monat hinzufügen"
                            :disabled="disabledButton(vertragsende) || !status.onkaWritable"
                            class="btn btn-secondary submit-btn"
                        >
                            <span>+</span>
                        </button>
                        <button
                            @click="subtractsMonth('vertragsende', vertragsende)"
                            title="1 Monat abziehen"
                            :disabled="disabledButton(vertragsende) || !status.onkaWritable"
                            class="btn btn-secondary submit-btn"
                        >
                            <span>-</span>
                        </button>
                    </template>
                </FormDatepicker>
            </b-form-group>
        </div>
        <b-button @click="onSave" class="" v-if="status.onkaWritable && isUserHasRoles" variant="primary">Speichern</b-button>
    </div>
</template>

<script>
import {BButton,BTooltip, BFormGroup, BFormCheckbox} from 'bootstrap-vue';
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import {mapState, mapGetters, mapActions} from "vuex";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import InlineInputAppend from "@comp/InlineInput/InlineInputAppend";
import FormDatepicker from "@comp/FormDatepicker/FormDatepicker";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import Validation from "@mixins/Validation/Validation";
import {isDate} from "res/js/utils/Validators/DatesValidators";
import {required} from 'vuelidate/lib/validators';

export default {
    name: "Preisbildung",
    components: {InlineInputAppend, ModalDialog, ButtonIcon, BButton, BTooltip, BFormGroup, FormDatepicker, BFormCheckbox},
    mixins: [ScalarsProcessing, Validation],
    created() {
        this.marge = this.formatNumber(this.offer.offerInfo.marge, 'marge');
        this.gmkz = this.formatNumber(this.offer.offerInfo.gmkz, 'gmkz');
        this.vertragsbeginn = this.offer.vertragsbeginn;
        this.vertragsende = this.offer.vertragsende;
        this.budgetangebot = this.offer.budgetangebot;
        this.ausschreibung = this.offer.ausschreibung;
    },
    data() {
        return {
            termineErrors: {},
            marge: null,
            gmkz: null,
            vertragsbeginn: null,
            vertragsende: null,
            budgetangebot: null,
            ausschreibung: null
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        }),
        ...mapGetters({
            status: 'offer/status',
            simpleId: 'offer/simpleId'
        }),
        isUserHasRoles() {
            return this.offer.user.userRoles.includes('AE') || this.offer.user.isAdmin;
        }
    },
    methods: {
        async onSave() {
            this.$v.$touch();

            if (!this.$v.$anyError && this.isValidNumber(this.marge, 'marge') && this.isValidNumber(this.gmkz, 'gmkz')) {
                window.preloader.show();
                try {
                    this.termineErrors = {};
                    let res = await this.$axios.post(`/offers/${this.simpleId}/preisbildung`, this.$data);

                    if (res.data.termineErrors) {
                        this.termineErrors = res.data.termineErrors;
                        window.preloader.hide();
                        return;
                    }

                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    window.flash.showMessagesFromAjax(res.data);
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                } finally {
                    window.preloader.hide();
                }
            } else {
                navigateToFirstInvalid();
            }
        },
        formatNumber(value, field) {
            let optionDigits = field === 'gmkz' ? 4: 2;
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: optionDigits, minimumFractionDigits: 2}
            ).replaceAll('.', '');
        },
        isValidNumber(value, field) {
            let test = String(value);
            return field === 'gmkz' ? this.validateGmkz(test): this.validateMargeOrPreisfaktor(test);
        },
        validateMargeOrPreisfaktor(test) {
            if (test.match(/^-?\d{1,7}$/) !== null) {
                return true;
            }
            return test.match(/^-?\d{1,7},\d{1,2}$/) !== null;
        },
        validateGmkz(test) {
            if (test.match(/^-?\d{1,3}$/) !== null) {
                return true;
            }
            return test.match(/^-?\d{1,3},\d{1,4}$/) !== null;
        },
        disabledButton(field) {
            return field == null;
        },
        addMonth(attribute, value) {
            let arr = value.split('.');
            let month = parseInt(arr[1]);
            let year = parseInt(arr[2]);
            if (month <= 11) {
                month = (month < 9) ? '0' + String(month + 1) : month + 1;
            } else {
                year = year + 1;
                month = '01';
            }
            this[attribute] = arr[0] + '.' + month + '.' + year;
        },
        subtractsMonth(attribute, value) {
            let arr = value.split('.');
            let month = parseInt(arr[1]);
            let year = parseInt(arr[2]);
            if (month >= 2) {
                month = (month < 11) ? '0' + String(month - 1) : month - 1;
            } else {
                year = year - 1;
                month = 12;
            }
            this[attribute] = arr[0] + '.' + month + '.' + year;
        },
    },
    validations: {
        gmkz: {required},
        marge: {required},
        vertragsbeginn: {isDate},
        vertragsende: {isDate}
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
.preisbildung-box {
    max-width: 430px;
    max-height: 800px;
}

.marge {
    margin-top: 30px;
}

.preisfaktor-label,
.marge-label,
.gmkz-label{
    display: inline-block;
    margin-top: 6px;
}

.preisfaktor-value,
.gmkz-value,
.marge-value {
    font-weight: bold;
}

.preisfaktor .text-muted,
.marge .text-muted,
.gmkz .text-muted{
    font-size: 1rem;
}

.edit-preisbildung-btn {
    align-self: flex-end;
}

.text-success {
    ::v-deep .form-control {
        color: #28a745 !important;
    }
}

.text-danger {
    ::v-deep .form-control {
        color: #dc3545 !important;
    }
}

.title-size {
    font-size: 24px;
}
</style>
