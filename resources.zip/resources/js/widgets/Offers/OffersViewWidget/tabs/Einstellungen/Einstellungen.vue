<template>
    <div class="einstellungen-tab">
        <Preisbildung/>
        <Variables/>
    </div>
</template>

<script>
import Preisbildung from "./Preisbildung/Preisbildung";
import Variables from "./Variables/Variables";

export default {
    name: "Einstellungen",
    components: {Preisbildung, Variables},
}
</script>

<style lang="scss" scoped>
.einstellungen-tab{
    display: flex;
}
</style>
