<template>
    <div class="variables-box simple-box d-flex flex-column">
        <div class="var_header">
        <h2>Variablen</h2>
        <div>
            <b-button href="#" @click="showCreateModal" class="mb-3 ml-3" v-if="canCreateOrUpdate"
            variant="primary">Neue Variable</b-button>
        </div>
            </div>
        <div class="w-100">
            <table-simple
                table-id="variable-table"
                :fields="fields"
                :filters="filters"
                :total-rows-prop="totalRows"
                :per-page-prop="perPage"
                :sort-by-prop="sortBy"
                :sort-desc-prop="sortDesc"
                :items-provider="getVariableList"
                ref="table"
                class="shadow-none"
            >
                <template #cell(bezeichnung)="data">
                    {{ data.item.bezeichnung }}
                </template>

                <template #cell(wert)="data">
                    {{$f.numberToString(data.item.wert, false,false, '0,00',{maximumFractionDigits: 10})}}
                </template>

                <template #cell(options)="data">
                    <div class="text-nowrap text-right">
                        <template v-if="canCreateOrUpdate">
                            <ButtonIcon
                                icon-class="icon-action-edit-default"
                                variant="secondary"
                                title="Variable bearbeiten"
                                hint-position="top"
                                @click = "editVar(data.item)"
                            />
                            <ButtonIcon
                                icon-class="icon-action-remove-default"
                                variant="danger"
                                title="Variable löschen"
                                hint-position="top"
                                @click="deleteVar(data.item, simpleId, currentVersion)"
                            />
                        </template>
                    </div>
                </template>
            </table-simple>
        </div>
        <form-variable
            ref="variableForm"
            :update-variable="updateVariable"
            @getVariables="updateData"
        />

    </div>
</template>

<script>
import {BButton} from 'bootstrap-vue';
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import {mapState, mapGetters} from "vuex";
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import TableSimple from '@comp/TableSimple/TableSimple';
import formVariable from "./formVariable";
import RemoveVarMxn from "./RemoveVarMxn";

export default {
    name: "Preisbildung",
    components: { ModalDialog, ButtonIcon, BButton, TableSimple,formVariable},
    mixins: [ScalarsProcessing,RemoveVarMxn],
    data() {
        return {
            fields: [
                {key: 'bezeichnung', label: 'Bezeichnung',thStyle: 'width: 60%'},
                {key: 'wert', label: 'Wert',thStyle: 'width: 30%'},
                {key: 'options', label: 'Optionen',thStyle: 'width: 10%'},
            ],
            filters: [],
            sortBy: 'sort',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            updateVariable: null
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        }),
        canCreateOrUpdate() {
            return this.offer.is_onka_writable && (
                this.offer.user.isAdmin
                || this.offer.user.userRoles.includes('TK')
                || this.offer.user.userRoles.includes('AE')
            )
        }
    },
    methods: {
        async getVariableList(ctx) {
            try {
                const response = await this.$axios.get(`/offers/${this.simpleId}/calculations/variables/${this.currentVersion}`, {
                    params: {
                        currentPage: ctx.currentPage,
                        sortBy: ctx.sortBy,
                        sortDesc: ctx.sortDesc ? 1 : 0
                    }
                });
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (error) {
                return []
            }
        },
        async updateData() {
            await this.$refs.table.manualCtxTrigger();
        },
        showCreateModal() {
            this.updateVariable = null;
            this.$refs.variableForm.clearForm();
            this.$refs.variableForm.showModal();
        },
        editVar(item){
            this.updateVariable = item;
            this.$refs.variableForm.showModal(item);
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.variables-box {
    width: 60%;
}
.var_header{
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}
</style>
