<template>
    <div class="d-inline-flex mt-5 content-padding mx-2">
        <div class="simple-box w-100">
            <div class="row no-gutters mb-3 wrapper-icon">
                <span class="icon-alert-warning-default notice-icon"></span>
                <span>Es wurde noch <b>kein</b> Angebot angelegt.</span>
            </div>
            <div class="row no-gutters mb-3">
                Angebote können während der aktiven Presales Phase durch die Rolle <br/>
                Angebotsersteller erstellt werden und bilden die <br/>
                Basis fur alle nachgelagerten Prozesse (z.B. Faktura).
            </div>
            <div v-show="showButtons" class="mt-4">
                <div class="button-wrapper">
                    <b-button
                        type="button"
                        :href="`/offers/${simpleId}/request`"
                        class="mb-3 mr-3 button"
                        variant="primary">Angebot anfordern
                    </b-button>
                    <span>Fordert ein neues Angebot beim <b>Entry Gate ISP</b> an.</span>
                </div>
                <div class="button-wrapper">
                    <b-button
                        type="button"
                        @click="handleFasttrack"
                        class="mb-3 mr-3 button"
                        variant="primary">Angebot erstellen
                    </b-button>
                    <span>Erstellt ein neues Angebot im <b>Fasttrack</b> Verfahren.</span>
                </div>
                <div class="button-wrapper">
                    <b-button
                        type="button"
                        @click="handleStartOffer"
                        class="mb-3 mr-3 button"
                        variant="primary"
                    >
                        Bearbeitung beginnen
                    </b-button>
                    <span>Startet die Angebotserstellung.</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import  {BButton} from 'bootstrap-vue';
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {mapGetters, mapState} from "vuex";

export default {
    name: "NoInfo",
    mixins: [ConfirmationModal],
    components: {
        BButton
    },
    props: {
        offerInfo: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            showButtons: false
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            status: 'offer/status'
        }),
    },
    methods: {
        async handleFasttrack() {
            const h = this.$createElement;
            const messageVNode = h('div',
                {
                    domProps:
                        {
                            innerHTML: '<div class="mb-3">Bitte bestätige die Erstellung eines neuen Angebots:</div> <ul>' +
                                '<li>Das Vorhaben wird direkt in den Status S3 überführt</li> ' +
                                '<li>Das Eingangstor wird nicht eingebunden</li>' +
                                '<li>Das Angebot wird dir zur Bearbeitung zugewiesen</li>' +
                                '<li>Sollte bereits eine Version in Arbeit sein, so wird eine neue Version angelegt</li>' +
                                '</ul>'
                        }
                }
            );

            const result = await this.showConfirmationModal({
                message: messageVNode,
                title: 'Angebot erstellen',
                okTitle: 'Angebot erstellen',
                okVariant: 'primary',
                cancelTitle: 'Abbrechen',
                footerClass: 'flex-row-reverse justify-content-start'
            });

            if (!result) return;

            try {
                window.preloader.show();
                const response = await this.$axios.post(`/offers/${this.simpleId}/fasttrack`);
                window.location.href = response.data.redirect;
                window.preloader.hide();
            } catch (error) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(error.response.data.text, 'error');
            }
        },
        async handleStartOffer() {
            if (this.status.shortName !== 'S2') {
                window.flash.showMessagesFromAjax('Die Funktion kann nur im Status S2 aufgerufen werden.', 'error');
                return;
            }

            const result = await this.$bvModal.msgBoxConfirm('Bitte bestätige den Start der Angebotserstellung.', {
                okTitle: 'Bestätigen',
                cancelTitle: 'Abbrechen',
            });

            if (!result) return;

            window.preloader.show();

            try {
                const response = await this.$axios.post('/offers/' + this.simpleId + '/start');
                window.preloader.hide();
                window.flash.showMessagesFromAjax(response.data.text, 'success');
                window.location.href = '/projects';
            } catch (err) {
                window.preloader.hide();
                window.flash.showMessagesFromAjax(err.response.data.text, 'error');
            }
        }
    },
    created() {
        this.showButtons =
            this.offer.is_active &&
            this.offer.is_presales &&
            (this.offer.user.isAdmin || this.offer.user.userRoles.includes('AE') || this.offer.user.userRoles.includes('SC'))
    }
}
</script>

<style lang="scss" scoped>
.buttons {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}
.button-wrapper {
    display: flex;
    align-items: baseline;
}
.button {
    width: 220px;
    height: 40px;
    font-size: 20px;
    line-height: 25px;
}
.notice-icon {
    font-size: 30px;
    margin-right: 10px;
}
.wrapper-icon {
    display: flex;
    align-items: center;
}
</style>
