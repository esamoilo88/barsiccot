<template>
    <div :class="cockpitMode ? 'simple-box' : ''">
        <h2 class="mb-4">Vollkosten-Aufteilung</h2>
        <div v-if="pending" class="placeholder-preloader-wrapper">
            <div class="ph-item">
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row no-gutters costrates-data" v-else-if="Object.keys(this.costrates).length">
            <div class="col-24 pr-3 left-box" :class="cockpitMode ? 'col-lg-10' : 'col-lg-14'">
                <table class="w-100">
                    <thead v-if="cockpitMode">
                        <tr>
                            <th style="width:20%;">
                                <div>Zuordnung</div>
                                <span class="sr-only">Zuordnung</span>
                            </th>
                            <th style="width:70%;">
                                <div>Kostenart</div>
                                <span class="sr-only">Kostenart</span>
                            </th>
                            <th style="width:10%;">
                                <div>Prozent</div>
                                <span class="sr-only">Prozent</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="costrate in costratesToDisplay">
                            <td>{{ costrate.zuordnung }}</td>
                            <td>{{ costrate.bezeichnung }}</td>
                            <td class="font-weight-bold text-right">{{ Math.round(costrate.prozent) }}%</td>
                        </tr>
                    </tbody>
                </table>
                <button class="btn btn-link p-0 mt-3"
                        v-if="Object.keys(this.costrates).length >5"
                        @click="showLessCostrates = !showLessCostrates">
                    {{ showLessCostratesText }}
                </button>
            </div>

            <div class="col-24 pl-3" :class="cockpitMode ? 'col-lg-14' : 'col-lg-10'">
                <div class="row no-gutters">
                    <div :class="cockpitMode ? 'col-12' : 'col-24 order-2'">
                        <div class="costrates-text">
                            <div class="costrates-text__block" :class="cockpitMode ? '' : 'small'" v-for="costrate in costratesChartData"
                                 :key="costrate.label">
                                <span class="costrates-text__percentage">{{ costrate.value }}% </span>
                                <span class="costrates-text__name">{{ costrate.label }}-Anteil </span>
                            </div>
                        </div>
                    </div>

                    <div :class="cockpitMode ? 'col-12' : 'col-24 order-1'">
                        <doughnut-chart
                            :data="costratesChartData"
                            :options="{labelSuffix: '%', cutoutPercentage: 10}"
                            :canvas-width="200"
                            :canvas-height="200"
                            id="costrates-chart"
                            class="costrates-chart"
                            custom-tooltip
                            show-legend
                        ></doughnut-chart>
                    </div>
                </div>
            </div>
        </div>
        <div v-else>Keine Daten vorhanden</div>

    </div>

</template>
<script>
import DoughnutChart from "@comp/Charts/DoughnutChart";
import {mapActions, mapState} from "vuex";

export default {
    name: "Costrates",
    components: {
        DoughnutChart
    },
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        cockpitMode: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {
            showLessCostrates: true,
            pending: false
        }
    },
    computed: {
        ...mapState({
            costrates: state => state.cockpit.costrates,
        }),
        costratesToDisplay() {
            if (this.showLessCostrates && Object.keys(this.costrates).length > 5) {
                return Object.keys(this.costrates).slice(0, 5).map(key => (this.costrates[key]));
            } else {
                return this.costrates;
            }
        },
        costratesChartData() {
            const groupBy = (array, key) => {
                return array.reduce((result, currentValue) => {
                    (result[currentValue[key]] = result[currentValue[key]] || []).push(
                        currentValue.prozent
                    );
                    return result;
                }, {});
            };
            const costrateData = groupBy(Object.values(this.costrates), 'zuordnung');
            return Object.keys(costrateData).map(key => {
                let value = costrateData[key].length === 1
                    ? Math.round(costrateData[key][0])
                    : costrateData[key].reduce((a, b) => Math.round(a) + Math.round(b));
                return {'label': key, 'value': value}
            });
        },
        showLessCostratesText() {
            if (this.showLessCostrates === true) {
                return "Weitere Kostenarten anzeigen (" + (Object.keys(this.costrates).length - 5) + ")"
            } else {
                return "ausblenden"
            }
        }
    },
    created() {
        this.getCostrates(this.simpleId);
    },
    methods: {
        ...mapActions('cockpit', ['fetchCostrates']),
        /**
         * Fetch all costrates
         */
        async getCostrates(simpleId) {
            this.pending = true;
            await this.fetchCostrates(simpleId);
            this.pending = false;
        },
    },
}
</script>
<style lang="scss" scoped>
.left-box {
    border-right: 2px solid #dee2e6;
}

.costrates-wrapper {
    display: flex;

}

@media (max-width: 992px) {
    .costrates-wrapper {
        flex-wrap: wrap;
    }
    .left-box {
        border: none;
    }
}

.costrates-data {

    .costrates-text {
        display: grid;
        grid-template-columns: 1fr 1fr;
        max-width: 370px;
        padding-top: 15px;

        &__block {
            display: flex;
            flex-direction: column;
            width: 130px;
            text-align: center;
            margin: 0 10px 30px 0;
        }

        &__block.small {
            width: auto;
            margin: 4px;
        }

        &__percentage {
            font-size: 25px;
            font-weight: bold;
        }

        &__name {
            font-size: 17px;
        }
    }
}

.costrates-data {
    td {
        font-size: 18px;
        padding: 5px 20px 5px 0;
    }
}

::v-deep .placeholder-preloader-wrapper {
    display: block;


    .ph-item {
        display: flex;
    }
}

.costrates-chart {
    width: 200px;
    height: 200px;
}
</style>
