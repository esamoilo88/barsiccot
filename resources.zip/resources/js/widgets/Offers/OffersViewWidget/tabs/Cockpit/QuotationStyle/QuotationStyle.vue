<template>
    <div class="simple-box mt-4">
        <h2 class="mb-4">Weitere Kennzahlen</h2>
        <div v-if="pending" class="placeholder-preloader-wrapper">
            <div class="ph-item">
                <div class="ph-col-6">
                    <div class="ph-row">
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                        <div class="ph-col-6"></div>
                        <div class="ph-col-6 empty"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="quotation_text">
            <div class="quotation_block">
                <span class="quotation_block__percentage">
                    {{ individualFormatted }}%
                </span>
                <span class="quotation_block__name">Individual </span>
            </div>
            <div class="quotation_block">
                <span class="quotation_block__percentage">
                    {{ konfigurationFormatted }}%
                </span>
                <span class="quotation_block__name">Katalognutzung </span>
            </div>
        </div>
    </div>

</template>
<script>

import {mapActions, mapState} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import dayjs from "res/js/utils/day";

export default {
    name: "Quotation",
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
    mixins: [ScalarsProcessing],
    data() {
        return {
            pending: false
        }
    },
    computed: {
        ...mapState({
            quotation: state => state.cockpit.quotation,
        }),
        individualFormatted() {
            if (this.pending) {
                return '-';
            } else {
                return (this.quotation.individual) ? Math.round(this.quotation.individual) : 0;
            }
        },
        konfigurationFormatted() {
            if (this.pending) {
                return '-';
            } else {
                return (this.quotation.konfiguration)? Math.round(this.quotation.konfiguration) : 0;
            }
        },
    },
    created() {
        this.getQuotation(this.simpleId);
    },

    methods: {
        ...mapActions('cockpit', ['fetchQuotation']),
        /**
         * Fetch all quotation
         */
        async getQuotation(simpleId) {
            this.pending = true;
            await this.fetchQuotation(simpleId);
            this.pending = false;

        }
    },

}
</script>
<style lang="scss" scoped>
.quotation_text {
    display: flex;
    flex-wrap: wrap;
    max-width: 370px;
    margin-left: 35px;

    .quotation_block {
        display: flex;
        flex-direction: column;
        margin-right: 40px;
        text-align: center;


        &__percentage {
            font-size: 25px;
            font-weight: bold;
        }

        &__name {
            font-size: 17px;
        }
    }
}
</style>
