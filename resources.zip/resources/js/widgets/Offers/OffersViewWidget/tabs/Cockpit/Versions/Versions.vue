<template>
    <div class="simple-box mt-4">
        <h2 class="mb-4">Angebotsversionen</h2>
        <table-simple
            table-id="versions-table"
            :fields="fields"
            :filters="filters"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="getVersionsData"
            ref="table"
            class="shadow-none"
        >
            <template #cell(status)="data">
                <div v-if="isCurrentVersion(data.item)">
                    <span class="icon-action-succsess-default ml-3"></span>
                    <span class="sr-only">Aktiv</span>
                </div>
                <span v-else class="sr-only">Inaktiv</span>
            </template>

            <template #cell(created)="data">
                <span>{{ formateDate(data.item) }}</span>
            </template>

            <template #cell(options)="data">
                <div class="text-nowrap">
                    <ButtonIcon
                        icon-class="icon-content-tarrifs-default"
                        variant="secondary"
                        title="Version öffnen"
                        hint-position="top"
                        @click="goToVersion(data.item)"
                    />
                    <ButtonIcon
                        v-if="canActivate && !isCurrentVersion(data.item)"
                        icon-class="icon-action-succsess-default"
                        variant="secondary"
                        title="Version aktivieren"
                        hint-position="top"
                        @click="activateVkVersion(data.item)"
                    />
                </div>
            </template>
        </table-simple>
    </div>
</template>
<script>

import {mapActions, mapGetters, mapState} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import TableSimple from '@comp/TableSimple/TableSimple';
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import {BTooltip} from "bootstrap-vue";
import dayjs from "res/js/utils/day";

export default {
    name: "Versions",
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
    mixins: [ScalarsProcessing],
    components: {ButtonIcon, BTooltip, TableSimple},
    data() {
        return {
            fields: [
                {key: 'versionsnr', label: 'Versions-Nr', sortable: false, sortKey: 'versionsnr'},
                {key: 'status', label: 'Aktiv', sortable: false, sortKey: 'status'},
                {key: 'versionsgrund', label: 'Beschreibung', sortable: false, sortKey: 'versionsgrund'},
                {key: 'created', label: 'Erstellt am', sortable: false, sortKey: 'created'},
                {key: 'options', label: 'Optionen'},
            ],
            filters: [],
            sortBy: 'versionsnr',
            sortDesc: false,
            totalRows: 0,
            perPage: 0
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,

        }),
        ...mapGetters({
            activeVersion: 'offer/activeVersion',
            status: 'offer/status'
        }),
        canActivate() {
            return this.status.onkaWritable &&
                (this.offer.user.isAdmin || this.offer.user.userRoles.includes('AE'))
        }
    },
    methods: {
        ...mapActions({
            fetchOfferData: "offer/fetchOfferData"
        }),
        async getVersionsData(ctx) {
            try {
                const response = await this.$axios.get(`/offers/${this.simpleId}/versions`, {
                    params: {
                        currentPage: ctx.currentPage,
                        sortBy: ctx.sortBy,
                        sortDesc: ctx.sortDesc ? 1 : 0
                    }
                });
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (error) {
                return []
            }
        },
        isCurrentVersion(item) {
            return item.vkVersionsId === this.activeVersion;
        },
        goToVersion(item) {
            window.location.href = `/offers/${this.simpleId}/${item.vkVersionsId}`;
        },
        formateDate(item) {
            return dayjs(item.created, "YYYY-MM-DDTh:mm:ss").format('DD.MM.YYYY, H:mm');
        },
        async activateVkVersion(item) {
            window.preloader.show();
            try {
                const res = await this.$axios.put(`/offers/${this.simpleId}/versions/${item.vkVersionsId}/activate`);
                this.$eventBus.$emit('offerHeaderUpdate');
                window.flash.showMessagesFromAjax(res.data);
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't activate Version", err);
            }
            window.preloader.hide();
        }
    }
}
</script>
