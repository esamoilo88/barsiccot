<template>
    <div>
        <Costrates :simple-id="simpleId"/>
        <QuotationStyle :simple-id="simpleId"/>
        <Versions :simple-id="simpleId"/>
    </div>
</template>

<script>
import Costrates from "./Costrates/Costrates";
import QuotationStyle from "./QuotationStyle/QuotationStyle";
import Versions from "./Versions/Versions";

export default {
    name: "cockpit",
    components: {Versions, Costrates, QuotationStyle},
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
}
</script>

<style lang="scss" scoped>

</style>
