<template>
    <div class="row">
        <div class="w-100">
            <span>Enhaltene Leistungen</span>
            <ul class="mt-2">
                <li
                    v-if="!service.optional"
                    v-for="service in item.service"
                    :key="service.id"
                    class="">
                    {{ service.katalogLp.bezeichnung }}
                    <span class="text-muted">
                        ({{ $f.numberToString(service.unitPrice, true) }})
                    </span>
                </li>
            </ul>
        </div>
        <div class="col">
            <div class="" v-if="optionalData.length">
                <b-form-checkbox
                    v-if="!service.radioGroup && service.optional"
                    v-for="service in item.service" :key="service.id"
                    v-model="service.selected"
                    @input="onSelectedChangeService(service)"
                    :disabled="checkboxBusy"
                >
                    <span class="services-item">
                        {{ service.katalogLp.bezeichnung }}
                        <span class="text-muted">
                            ({{ $f.numberToString(service.unitPrice, true) }})
                        </span>
                    </span>
                </b-form-checkbox>
                <div class="mt-3">
                    <div v-for="(radioGroup, index) in radioContent" :key="index">
                        <FormRadio
                            class="my-3 primary-white"
                            name="radio_label"
                            :label="index"
                            :id="`radio_label_${radioGroup.id}`"
                            v-model="radioGroup.selected"
                            @change="onSelectedChangeServiceRadio(radioGroup)"
                            :options="radioGroup.options"
                            stacked
                        />
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {BFormCheckbox, BFormGroup} from 'bootstrap-vue';
import {mapGetters} from "vuex";
import FormRadio from "@comp/FormRadio/FormRadio";

export default {
    name: "Services",
    components: {
        BFormCheckbox, BFormGroup, FormRadio
    },
    props: {
        item: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            checkboxBusy: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
        optionalData() {
            return this.item.service.filter(e => e.optional);
        },
        radioContent() {
            const content = {};
            this.item.service.forEach((item) => {
                if (item.radioGroup && item.optional) {
                    if (content[item.radioGroup] === undefined) {
                        content[item.radioGroup] = {
                            options: [],
                            selected: null
                        };
                    }

                    if (item.selected) {
                        content[item.radioGroup].selected = item.id;
                    }

                    content[item.radioGroup].options.push({
                        text: item.katalogLp.bezeichnung + ' <span class="text-muted">(' + this.$f.numberToString(item.unitPrice, true) + ')</span>',
                        value: item.id,
                    })
                }
            });
            return content;
        }
    },
    methods: {
        async onSelectedChangeService(service) {
            this.$emit('service-loading', true);
            this.checkboxBusy = true;
            try {
                await this.$axios.post(`/onka/${this.simpleId}/configurations/items/services/${service.id}/saveSelectedCheckboxService`, {
                    selected: service.selected,
                });

                this.$eventBus.$emit('refreshComputedItems');
                this.$emit('updated');
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't switch value", err);
            }
            this.$emit('service-loading', false);
            this.checkboxBusy = false;
        },
        async onSelectedChangeServiceRadio(service) {
            this.$emit('service-loading', true);
            this.checkboxBusy = true;
            try {
                await this.$axios.post(`/onka/${this.simpleId}/configurations/items/services/saveSelectedRadioService`, {
                    option: service.options, selectedId: service.selected
                });

                this.$eventBus.$emit('refreshComputedItems');
                this.$emit('updated');
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't switch value", err);
            }
            this.$emit('service-loading', false);
            this.checkboxBusy = false;
        }
    }

}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables';

::v-deep .col-form-label {
    font-weight: bold;
}

::v-deep .custom-radio {
    margin-bottom: 5px;
}

.services-switch {
    border-top: 2px solid;
}

.eos-warning {
    font-weight: bold;
    color: red;
}

.bundle-warning {
    //font-size: 1.6rem;
}

.bundle-item {
    margin-left: 40px;
}

</style>
