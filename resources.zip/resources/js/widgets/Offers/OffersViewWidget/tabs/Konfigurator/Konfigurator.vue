<template>
    <div>
        <h2 class="mb-3" v-if="isConfigurationSelected">{{ configurationName }}</h2>
        <div class="d-flex align-items-center mb-3">
            <button
                v-if="isConfigurationSelected && (status.onkaWritable && status.presales) && (offer.user.userRoles.includes('AE') || offer.user.isAdmin)"
                class="ubernehmen-configuration-btn btn btn-primary" @click="apply">
                <span class="icon-action-succsess-default"></span>
                Übernehmen
            </button>
            <div class="ml-auto">
                <a
                    class="mr-2"
                    v-if="isConfigurationSelected"
                    @click="selectedConfigurationId=-1;isConfigurationSelected=false"
                    href="#"
                >
                    Zurück zur Konfiguratorliste
                </a>
                <b-dropdown
                    v-if="configurations.length > 0"
                    class="configurations-dropdown"
                    ref="configurationsListDropdown"
                    text="Konfigurationen"
                    right
                >
                    <b-dropdown-item
                        v-for="conf in configurations"
                        :key="conf.id"
                        href="#"
                        :active="conf.id === selectedConfigurationId"
                        @click="onSelectConfiguration(conf.id)"
                    >
                        {{ conf.name }}
                        <span v-if="conf.id === selectedConfigurationId" class="sr-only">Zurzeit ausgewählt</span>
                    </b-dropdown-item>
                </b-dropdown>
            </div>
        </div>

        <div class="simple-box box-shadow">
            <div v-if="!isConfigurationSelected">
                <Configurators @configuration-created="onConfigurationCreation" :simple-id="offer.globalGate.simpleId"/>
            </div>
            <div v-else>
                <Configuration ref="configuration" @configuration-deleted="onConfigurationDeleted" :configuration-id="selectedConfigurationId"/>
            </div>
        </div>
    </div>

</template>

<script>
import {mapActions, mapState, mapGetters} from 'vuex';
import {BDropdown, BDropdownItem} from 'bootstrap-vue';
import Loading from "@comp/DynamicImportHelpers/Loading";

const Configuration = () => ({
    loading: Loading,
    component: import(/*webpackChunkName:"onka-configurations"*/ './Configuration/Configuration'),
    delay: 0
});
const Configurators = () => ({
    loading: Loading,
    component: import(/*webpackChunkName:"onka-configurators"*/ './Configurators/Configurators'),
    delay: 0
});

export default {
    name: "Konfigurator",
    components: {
        Configuration,
        Configurators,
        BDropdown,
        BDropdownItem
    },
    data() {
        return {
            isConfigurationSelected: false,
            selectedConfigurationId: -1,
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
            configurations: state => state.configurations.configurations
        }),
        ...mapGetters({
          status: 'offer/status',
          currentVersion: 'offer/currentVersion'
        }),
        configurationName() {
            if (!this.selectedConfigurationId) return 'Konfiguratoren';

            let configuration = this.configurations.filter(item => {
                return item.id === this.selectedConfigurationId;
            });

            return configuration.length > 0 ? configuration[0].configuratorName : 'Konfiguratoren';
        }
    },
    async created() {
        await this.fetchConfigurations({
            simpleId: this.offer.globalGate.simpleId,
            vkVersionId: this.currentVersion
        });
    },
    methods: {
        ...mapActions('configurations', ['fetchConfigurations']),

        /**
         * Handle selection of specific configuration in the dropdown
         * @param configurationId
         * @returns {Promise<void>}
         */
        async onSelectConfiguration(configurationId) {
            if (configurationId === this.selectedConfigurationId) {
                this.selectedConfigurationId = -1;
                this.isConfigurationSelected = false;
            } else {
                this.selectedConfigurationId = configurationId;
                this.isConfigurationSelected = true;
            }
        },

        /**
         * Open configuration after creation
         * @param configurationId
         */
        onConfigurationCreation(configurationId) {
            this.selectedConfigurationId = configurationId;
            this.isConfigurationSelected = true;
        },

        /**
         * Return back to a configurators list after
         * a configuration was deleted
         */
        onConfigurationDeleted() {
            this.selectedConfigurationId = -1;
            this.isConfigurationSelected = false;
        },
        apply() {
            this.$refs.configuration.assume(this.selectedConfigurationId);
        }
    }
}
</script>

<style lang="scss" scoped>
.configurations-dropdown {
    ::v-deep ul.dropdown-menu.show {
        max-height: 450px;
        overflow-y: auto;
    }
}
</style>
