<template>
    <div>
        <div class="mb-4">
            <div class="row">
                <div class="col-lg-6">
                    <h3> Konfiguration </h3>
                    <p>{{ defVal(configuration.name, '-') }}</p>
                    <div class="controls">
                        <ButtonIcon
                            v-if="canEditName"
                            class="edit-configuration-btn mr-1"
                            icon-class="icon-action-edit-default"
                            @click="showEditModal"
                        />
                        <ButtonIcon
                            v-if="(status.onkaWritable && status.presales) && (offer.user.userRoles.includes('AE') || offer.user.isAdmin)"
                            class="remove-configuration-btn mr-1"
                            icon-class="icon-action-remove-default"
                            @click="onDeleteConfiguration"
                        />
                    </div>
                    <div v-if="itemsGroupsOptions.length > 0" class="col-sm-24 col-md-24 col-lg-24 pl-0 pr-0">
                        <FormRadio
                            ref="itemsGroupFilter"
                            class="my-3 primary-white"
                            id="configuration-items-groups-filter"
                            v-model="itemsGroupsFilter"
                            @change="onGroupFilterChange"
                            :value="itemsGroupsFilter"
                            :options="itemsGroupsOptions"
                            :disabled="isLoadingMxn('items') || tabsDisabled"
                            buttons
                            stacked
                            tabindex="-1"
                        />
                    </div>
                    <div class="d-flex mt-3">
                        <span class="icon-action-shopping-cart-default mr-2"></span>
                        <a
                            @click="onResultVorshau()"
                            @keyup.enter="onResultVorshau()"
                            class="mr-2 cursorPointer">
                            Zusammenfassung
                        </a>
                        <b-badge class="item-requirement" variant="secondary">
                            {{ selectedItems }}
                        </b-badge>
                    </div>
                    <b-overlay :show="computedItemsPending">
                        <div class="mt-3">
                            <hr>
                            <div class="row no-gutters mb-2">
                                <div class="col text-uppercase font-weight-bold">
                                    Einmalig
                                </div>
                                <div class="col-auto text-right text-monospace">
                                    {{ computedItems.einmalig }}
                                </div>
                            </div>
                            <div class="row no-gutters mb-2">
                                <div class="col text-uppercase font-weight-bold">
                                    Monatlich
                                </div>
                                <div class="col-auto text-right">
                                    <div class="d-flex justify-content-between" v-for="item in computedItems.monatlich">
                                        <div class="text-muted">{{ item.quantity }} x&nbsp;</div>
                                        <div class="text-monospace">{{ $f.numberToString(item.value, true) }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="row no-gutters font-weight-bold">
                                <div class="col text-uppercase">
                                    Gesamt
                                </div>
                                <div class="col-auto text-right text-monospace">
                                    {{ computedItems.gesamt }}
                                </div>
                            </div>
                        </div>
                    </b-overlay>
                </div>
                <div class="col-lg-18">
                    <div v-if="showParams">
                        <Params
                            ref="paramsList"
                            @refresh-selected="refreshSelected"
                            @refresh-selected-ended="tabsDisabled = false"
                            @fresh-params="setParams"
                            :cached-params="cachedParams"
                            :configuration-id="configurationId"
                        />
                    </div>
                    <div v-else-if="isOverview">
                        <Zusammenfassung ref="zusammenfassung" :simple-id="offer.globalGate.simpleId" :configuration-id="configurationId" />
                    </div>
                    <div v-else class="configuration-items">
                        <ItemsList
                            ref="itemsList"
                            @refresh-selected="refreshSelected"
                            :items-groups-filter="itemsGroupsFilter"
                            :configuration-id="configurationId"
                        />
                    </div>
                </div>
            </div>
        </div>

        <div v-if="eosItemsNumber > 0" class="mb-4">
            <h2 class="ml-3">Meldungen</h2>
            <p class="ml-3">
                Die Konfiguration enthält
                <span v-if="eosItemsNumber === 1">1 veraltetes Produkt</span>
                <span v-else-if="eosItemsNumber > 1">{{ eosItemsNumber }} veraltete Produkte</span>
                <abbr title="End of Service">(EOS)</abbr>
            </p>
        </div>

        <button class="ubernehmen-configuration-btn btn btn-secondary sr-only" @click="assume(configuration.id)">
            <span class="icon-action-succsess-default"></span>
            Übernehmen
        </button>

        <ConfigurationEdit ref="edit" :configuration="configuration"/>
    </div>
</template>

<script>
import clip from 'text-clipper';
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import ItemsList from "./Items/ItemsList";
import Params from "./Params/Params";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import ConfigurationEdit from "./ConfigurationEdit";
import {mapState, mapGetters, mapActions} from 'vuex';
import FormRadio from "@comp/FormRadio/FormRadio";
import LoaderGroup from "@mixins/LoaderGroup/LoaderGroup";
import {BOverlay, BBadge} from 'bootstrap-vue';
import Zusammenfassung from "./Zusammenfassung";
export default {
    name: "Configuration",
    components: {
        ItemsList,
        ButtonIcon,
        Params,
        ConfigurationEdit,
        FormRadio,
        BBadge,
        BOverlay,
        Zusammenfassung
    },
    mixins: [ScalarsProcessing, ConfirmationModal, LoaderGroup],
    props: {
        configurationId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            isConfSubtextLong: false,
            eosItemsNumber: 0,
            itemsGroupsOptions: [],
            itemsGroupsFilter: null,
            showParams: true,
            isOverview: false,
            paramsFilter: [
                {
                    text: "Einstellungen",
                    value: "Einstellungen"
                }
            ],
            cachedParams: [],
            computedItems: {
                gesamt: 0,
                einmalig: 0,
                monatlich: [],
            },
            computedItemsPending: false,
            tabsDisabled: false,
            selectedItems: 0
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        ...mapGetters({
            status: 'offer/status',
            currentVersion: 'offer/currentVersion'
        }),
        configuration() {
            let configuration = this.$store.state.configurations.configurations.filter(conf => conf.id === this.configurationId);
            return configuration[0] ?? {};
        },
        configurationSubtext() {
            if (this.configuration.subtext === null) {
                return '-';
            } else if (this.isConfSubtextLong) {
                return this.configuration.subtext;
            } else {
                return clip(this.configuration.subtext, 150);
            }
        }
    },
    watch: {
        async configurationId() {
            this.itemsGroupsFilter = 'Einstellungen';
            this.showParams = true;
            this.isOverview = false;
            this.itemsGroupsOptions = await this.fetchItemsGroups();
            await this.$refs.paramsList.fetchConfigurationParams(this.configurationId);
            await this.getComputedItems();
            this.setFocus();
        }
    },
    async created() {
        this.initLoaderGroupsMxn(['items']);
        this.itemsGroupsFilter = 'Einstellungen';
        this.itemsGroupsOptions = await this.fetchItemsGroups();
        this.$eventBus.$on('itemsWithEOS', arg => this.eosItemsNumber = arg.eosCount > 0 ? arg.eosCount : 0);
        this.$eventBus.$on('refreshComputedItems', this.getComputedItems);
        this.setFocus();
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshComputedItems');
    },
    async mounted() {
        await this.getComputedItems();
    },
    methods: {
        ...mapActions({
            deleteConfiguration: 'configurations/deleteConfiguration',
        }),

        /**
         * Handler for configuration removing process
         * @returns {Promise<void>}
         */
        async onDeleteConfiguration() {
            const confirmed = await this.showConfirmationModal({
                title: 'Konfiguration löschen',
                message: `Bitte bestätige die Löschung der Konfiguration ${this.configuration.name}`,
                okTitle: 'Konfiguration löschen',
            });

            if (confirmed) {
                window.preloader.show();
                let success = await this.deleteConfiguration({
                    configurationId: this.configurationId,
                    simpleId: this.offer.globalGate.simpleId
                });
                if (success) {
                    this.$emit('configuration-deleted');
                }
                window.preloader.hide();
            }
        },
        showEditModal() {
            if (this.$refs.edit) {
                this.$refs.edit.show()
            }
        },
        canEditName() {
            return (this.status.onkaWritable && this.status.presales) && (this.offer.user.userRoles.includes('AE') || this.offer.user.isAdmin);
        },
        async assume(configurationId) {
            if (this.eosItemsNumber === 0) {
                window.preloader.show();
                try {
                    await this.$axios.post(`/onka/configurations/${configurationId}/assume`, {
                        vkVersions: this.currentVersion
                    });
                    window.flash.success('Konfiguration erfolgreich übernommen');
                    this.$eventBus.$emit('configurationAssumed');
                    this.$eventBus.$emit('offerHeaderUpdate');
                } catch (err) {
                    console.error('Couldn\'t assume configuration', err);
                    window.flash.showMessagesFromAjax(err.response.data);
                } finally {
                    window.preloader.hide();
                }
            } else {
                window.flash.error('Angebotserstellung nicht möglich. Die Konfiguration beinhaltet veraltete Produkte (EOS).');
            }
        },
        /**
         * Fetch groups which represent all of the configuration items
         * @returns {Promise<*[]|*>}
         */
        async fetchItemsGroups() {
            this.showLoader('items', 'filter');
            try {
                let response = await this.$axios.get(`/onka/configurations/${this.configurationId}/items/groups`);
                this.hideLoader('items', 'filter');
                let data = response.data.groups.map(group => ({text: group, value: group}));
                this.selectedItems = response.data.countSelected;
                data.unshift({text: 'Einstellungen', value: 'Einstellungen', icon: 'icon-service-seettings-default mr-2'});
                return data;
            } catch (err) {
                console.error("Couldn't fetch items groups: ", err)
            }
            this.hideLoader('items', 'filter');
            return [];
        },

       async onResultVorshau() {
            this.isOverview = true;
            this.showParams = false;
            this.itemsGroupsFilter = null;
             if (this.$refs.zusammenfassung) {
                 await this.$refs.zusammenfassung.onResultVorshau();
             }
        },
        /**
         * Fetch configuration items filtering it with group name
         * @param value
         * @returns {Promise<void>}
         */
        async onGroupFilterChange(value) {
            if (value == 'Einstellungen') {
                this.showParams = true;
                this.isOverview = false;
                return;
            }
            this.showParams = false;
            this.isOverview = false;
            this.itemsGroupsFilter = value;
            if (this.$refs.itemsList) {
                await this.$refs.itemsList.fetchConfigurationItems(this.offer.globalGate.simpleId, this.configurationId, this.getFilter());
            }
            let activeFilter = this.$refs.itemsGroupFilter.$el.querySelector('label.active');
            activeFilter !== null ? activeFilter.focus() : '';
        },
        getFilter() {
            if (this.itemsGroupsFilter) {
                return {
                    groupName: this.itemsGroupsFilter
                }
            }

            return null;
        },
        setParams(value) {
            this.cachedParams = value;
        },
        setFocus() {
            setTimeout(function () {
                document.getElementById('Einstellungen').focus();
            }, 10);
        },
        async refreshSelected() {
            this.tabsDisabled = true;
            try {
                let response = await this.$axios.get(`/onka/configurations/${this.configurationId}/items/selected-count`);
                this.selectedItems = response.data;
            } catch (err) {
                console.error("Couldn't refresh selected count: ", err)
            }
        },
        async getComputedItems() {
            this.computedItemsPending = true;

            try {
                const response = await this.$axios.get(`/onka/configurations/${this.configurationId}/items/computing`);
                this.computedItems.gesamt = this.$f.numberToString(response.data.gesamt, true);
                this.computedItems.einmalig = this.$f.numberToString(response.data.einmalig, true);
                this.computedItems.monatlich = response.data.monatlich;
            } catch (err) {
                console.error("Couldn't compute on demand: ", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }

            this.computedItemsPending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.controls {
    margin-top: auto;
    margin-left: auto;
}

.configuration-items {
    //margin-top: 130px;
}

::v-deep .remove-configuration-btn,
::v-deep .edit-configuration-btn {
    button.btn-icon {
        padding: 6px 8px;
    }

    span.btn-icon__icon {
        font-size: 20px;
    }
}

.ubernehmen-configuration-btn {
    span {
        vertical-align: middle;
    }
}


::v-deep #configuration-items-groups-filter {
    label.btn:first-child {
        border-top: 1.5px solid rgba(0, 0, 0, 0.1);
        border-bottom: 2.5px solid rgba(0, 0, 0, 0.1) !important;
        border-radius: 0;
        padding-bottom: 40px;
        padding-top: 20px;
    }
    label.btn {
        text-align: left;
        padding: 10px 15px 10px 0;
    }
    label.btn:last-child {
        border-bottom: 2.5px solid rgba(0, 0, 0, 0.1) !important;
        border-radius: 0;
        padding-bottom: 40px;
    }
}

.primary-white {
    background-color: #ffffff;
    border: 0;
}
.primary-white.focus,
.primary-white:focus {
    box-shadow: 0 0 0 0 !important;
    border: 0;
}
.primary-white.active,
.primary-white:active {
    color: $primary;
    background-color: #ffffff;
    border: 0;
}
::v-deep .primary-white {
    label.btn {
        background-color: #ffffff;
        border: 0;
    }
    label.btn:focus,
    label.btn.focus {
        box-shadow: 0 0 0 0 !important;
        border: 0;
    }
    label.btn.active,
    label.btn:active {
        color: $primary;
        background-color: #ffffff;
        border: 0;
    }
}
</style>
