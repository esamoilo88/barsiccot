<template>
    <div>
        <h2 class="mb-4"> Konfiguratoren </h2>
        <div class="container_card">
            <div class="placeholder-preloader-wrapper" v-if="pending">
                <b-card
                    v-for="item in 4"
                    :key="item"
                    img-alt="Image"
                    img-top
                    tag="article"
                    style="width: 17rem;"
                    class="mb-2 mr-3">
                    <div class="ph-item ph-image">
                        <div class="ph-col-12">
                            <div class="ph-row">
                                <div class="ph-col-12 big"></div>
                            </div>
                        </div>
                    </div>
                    <b-card-text>
                        <div class="ph-item">
                            <div class="ph-col-12">
                                <div class="ph-row">
                                    <div class="ph-col-8 big"></div>
                                    <div class="ph-col-12"></div>
                                    <div class="ph-col-12"></div>
                                </div>
                            </div>
                        </div>
                    </b-card-text>
                    <b-button class="mb-3 ml-3" variant="primary">Konfigurieren</b-button>
                </b-card>
            </div>
            <div v-else-if="configurators.length">
                <p>Bitte wähle einen Konfigurator aus und klicke auf Konfigurieren.</p>
                <div class="konfigurator_cards">
                    <b-card
                        v-for="configurator in configurators"
                        :key="configurator.id"
                        :img-src="configurator.imagePath"
                        img-alt="Image"
                        img-top
                        tag="article"
                        style="max-width: 17rem;"
                        class="mb-2 mr-3 card"
                    >
                        <h3 class="mb-2">{{ configurator.name }}</h3>
                        <b-card-text>
                            {{ configurator.subtext }}
                        </b-card-text>
                        <div class="konfigurieren_button">
                            <b-button
                                @click="onKonfigurieren(configurator)"
                                :disabled="!offer.is_onka_writable || (!offer.user.userRoles.includes('AE') && !offer.user.isAdmin)"
                                variant="primary">
                                Konfigurieren
                            </b-button>
                        </div>
                    </b-card>
                </div>
            </div>
            <div v-else>
                <p>Es sind keine Konfiguratoren verfügbar.</p>
            </div>
        </div>
    </div>
</template>

<script>
import {BCard, BButton, BCardText, BCardTitle} from 'bootstrap-vue';
import {mapActions, mapState, mapGetters} from "vuex";

export default {
    name: "Configurators",
    components: {BCard, BButton, BCardText, BCardTitle},
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
    async created() {
        await this.getConfigurators();
    },
    computed: {
        ...mapState({
            configurators: state => state.configurators.configurators,
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        })
    },
    data() {
        return {
            pending: false
        }
    },
    methods: {
        ...mapActions({
            fetchConfigurators: "configurators/fetchConfigurators",
            createConfiguration: 'configurations/createConfiguration'
        }),
        /**
         * Fetch all configurators
         */
        async getConfigurators() {
            this.pending = true;
            await this.fetchConfigurators();
            this.pending = false;
        },
        /**
         * Create a configuration by clicking at Konfigurieren button
         * @param configurator
         * @returns {Promise<void>}
         */
        async onKonfigurieren(configurator) {
            window.preloader.show();
            try {
                let configuration = await this.createConfiguration({
                    configurator,
                    simpleId: this.simpleId,
                    vkVersionId: this.currentVersion
                });
                if (configuration) {
                    this.$emit('configuration-created', configuration.id);
                }
            } catch (err) {
                console.error("Couldn't create configuration")
            }
            window.preloader.hide();
        }
    }

}
</script>

<style lang="scss" scoped>
.container_card {
    margin-bottom: 500px;
}

.konfigurator_cards {
    display: flex;
    position: relative;
    flex-wrap: wrap;

    .konfigurieren_button {
        position: absolute;
        bottom: 1rem;
    }

    .card-text {
        margin-bottom: 3rem;
    }
}

::v-deep .placeholder-preloader-wrapper {
    display: flex;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        border: none;
        border-radius: 0;
        box-shadow: none;
        margin: 0;

        .ph-col-12 {
            padding: 0;
        }

    }
}

.card:hover {
    box-shadow: 0 0 18px rgb(0 0 0 / 30%);
}

.ph-image.ph-item {
    padding: 0;

    .ph-row .big {
        margin-bottom: 0;
        height: 150px;
    }
}
</style>
