<template>
    <div>
        <div v-if="!isLoaded">
            <div v-for="item in [1,2,3,4,5]" class="ph-item">
                <div class="ph-col-24">
                    <div class="ph-row">
                        <div class="ph-col-8"></div>
                        <div class="ph-col-12 empty"></div>
                        <div class="ph-col-8"></div>
                        <div class="ph-col-8"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="parameter position-relative" v-if="configurationParams.length > 0">
            <div class="mb-3" v-for="paramsByGroup in paramsByGroups">
                <h4>{{paramsByGroup.name}}</h4>
                <div class="row no-gutters">
                    <div
                        v-if="!configurationParam.hide"
                        class="col-lg-12 mb-3 pr-4"
                        v-for="configurationParam in paramsByGroup.params"
                        :key="configurationParam.id"
                    >
                        <template v-if="configurationParam.uiType === 'checkbox'">
                            <ConfigurationParam
                                :param="configurationParam"
                                :ref="`param-${configurationParam.id}`"
                            />

                            <div class="text-muted subtext">{{ configurationParam.subtext }}</div>
                        </template>

                        <div v-else class="param-container">
                            <div>
                                <label :for="`configuration-param-${configurationParam.id}`">
                                    {{ configurationParam.name }}
                                </label>

                                <div class="text-muted subtext">{{ configurationParam.subtext }}</div>
                            </div>

                            <ConfigurationParam
                                :param="configurationParam"
                                :ref="`param-${configurationParam.id}`"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <BoxSpinner :busy="busy" />
        </div>
    </div>
</template>

<script>
import ConfigurationParam from './ConfigurationParam';
import {mapState} from "vuex";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";

export default {
    name: 'Params',
    components: {BoxSpinner, ConfigurationParam},
    props: {
        configurationId: {
            type: Number,
            required: true
        },
        cachedParams: {
            type: Array,
            required: false,
            default: []
        }
    },
    data() {
        return {
            configurationParams: [],
            busy: false,
            paramsByGroups: [],
            isLoaded: false,
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        })
    },
    async created() {
        if (this.cachedParams.length) {
            this.groupParams(this.cachedParams);
        } else {
            await this.fetchConfigurationParams();
        }

        this.$eventBus.$on('refreshParams', this.fetchConfigurationParams);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshParams');
    },
    methods: {
        async fetchConfigurationParams() {
            this.busy = true;

            try {
                const response = await this.$axios.get(`/onka/configurations/${this.configurationId}/params`);

                if (response.data) {
                    this.groupParams(response.data)
                    this.$emit('fresh-params', response.data);
                }
            } catch (err) {
                console.error('Couldn\'t fetch configuration params', err);
            }

            this.busy = false;
        },
        groupParams(data) {
            this.configurationParams = data;

            let groups = [];
            let withoutGroups = [];
            withoutGroups[0] = [];
            withoutGroups[0]['name'] = 'Ohne Gruppe';
            withoutGroups[0]['params'] = [];

            for (let key in data) {
                let param = data[key];
                let groupId = param.groupId;
                if (groupId) {
                    if (!groups[groupId]) {
                        groups[groupId] = [];
                        groups[groupId]['params'] = [];
                    }
                    groups[groupId]['name'] = param.groupName;
                    groups[groupId]['params'].push(param);
                } else {
                    withoutGroups[0]['params'].push(param);
                }
            }


            groups = groups.filter(item => item.length == 0);
            withoutGroups = withoutGroups.filter(item => item.length == 0);
            if (withoutGroups[0]['params'].length > 0) {
                groups.push(withoutGroups[0])
            }

            this.paramsByGroups = groups;
        }
    }
}
</script>

<style lang="scss" scoped>

.parameter {
    background-color: white;
}

.edit-control {
    align-self: center;
    margin-right: 10px;
}

.subtext {
    white-space: normal;
    word-break: break-word;
    font-size: 15px;
}

.placeholder-preloader-wrapper {
    display: flex;
    flex-direction: column;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        box-shadow: none;

        .ph-col-12 {
            padding: 0;
        }
    }

    .ph-row div {
        width: 350px;
    }
}

.param-container {
    display: grid;
    grid-template-columns: 1fr 0fr;
    justify-content: space-between;
    gap: 1rem;
}
</style>
