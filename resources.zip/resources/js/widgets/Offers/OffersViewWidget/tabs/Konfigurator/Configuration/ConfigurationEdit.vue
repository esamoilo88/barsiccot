<template>
    <div>
        <modal-dialog
            :is-visible="visible"
            @hideModal="hide"
            title-dialog="Konfiguration bearbeiten"
            modal-class="modal-edit"
        >
            <div class="mb-3">Bitte fülle alle mit* gekennzeichneten Felder aus.</div>

            <div class="simple-box">
                <b-form-group>
                    <FormInput
                        v-model="form.name"
                        name="name"
                        input-id="name"
                        label-text="Name*"
                        :error-conditions="[
                            {
                                name: 'required-name',
                                condition: isInvalid('name'),
                                text: 'Name muss ausgefüllt werden.'
                            }
                        ]"
                    />
                </b-form-group>
            </div>

            <template v-slot:footer>
                <b-button
                    variant="primary"
                    @click="submit"
                >
                    Konfiguration ändern
                </b-button>

                <b-button
                    variant="secondary"
                    @click="hide"
                >
                    Abbrechen
                </b-button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BButton, BFormGroup} from 'bootstrap-vue';
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import FormInput from '@comp/FormInput/FormInput';
import Validation from 'res/js/utils/Mixins/Validation/Validation';
import {required} from 'vuelidate/lib/validators';
import {mapActions} from 'vuex';

export default {
    components: {ModalDialog, BButton, FormInput, BFormGroup},
    props: {
        configuration: {
            type: Object,
            required: true
        }
    },
    mixins: [Validation],
    watch: {
        configuration(newVal) {
            this.form.name = newVal.name;
        }
    },
    data() {
        return {
            visible: false,
            form: {
                name: this.configuration.name
            }
        }
    },
    methods: {
        ...mapActions({
            updateName: 'configurations/updateName',
        }),

        hide() {
            this.visible = false;
        },
        show() {
            this.visible = true;
        },
        async submit() {
            if (!this.isValid()) {
                return;
            }

            window.preloader.show();

            const result = await this.updateName({
                configurationId: this.configuration.id,
                name: this.form.name
            });

            if (result) {
                this.hide();
            }

            window.preloader.hide();
        },
        isValid() {
            this.showValidationErrors = false;

            this.$v.$touch();

            if (this.$v.$invalid) {
                this.showValidationErrors = true;

                return false;
            }

            return true;
        },
        isInvalid(field) {
            return this.showValidationErrors && !this.$v.form[field].required;
        },
    },
    validations: {
        form: {
            name: {required},
        }
    }
}
</script>
