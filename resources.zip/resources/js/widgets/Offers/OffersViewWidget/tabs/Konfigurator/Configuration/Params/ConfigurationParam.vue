<template>
    <div class="param-value-container" :class="{'checkbox': param.uiType === 'checkbox'}">
        <div>
            <FormSelectSubmit
                v-if="param.uiType === 'dropdown' && !param.hide"
                v-model="form.value"
                class="params-select"
                @input="onInput"
                :input-id="`configuration-param-${param.id}`"
                @submit="submit"
                :disabled="param.locked"
                :options="options(param.options)"
                submit-button-title="Parameter speichern"
                :label="param.name"
                ref="input"
                :subtext="param.subtext"
                :without-button="true"
            />
            <InlineInputAppend
                class="pt-1"
                v-if="param.uiType === 'input' && !param.hide"
                v-model="form.value"
                :type="getInputType()"
                submit-button-title="Parameter speichern"
                @submit="submit"
                @input="onInput"
                :step="param.stepsize"
                :input-id="`configuration-param-${param.id}`"
                :key="`configuration-param-${param.id}`"
                :error-conditions="errorConditions"
                :disabled="param.locked || param.computed"
                :readonly="false"
                ref="input"
                :subtext="param.subtext"
                :without-button="true"
                :alignright="false"
            />
            <b-form-checkbox
                v-model="form.value"
                @change="onCheckboxInput"
                v-if="param.uiType === 'checkbox' && !param.hide"
                :id="`configuration-param-${param.id}`"
                :key="`configuration-param-${param.id}`"
                name="ausgeblendet-input"
                :disabled="param.locked || loading || param.computed"
                switch
            >
                {{ param.name }}
            </b-form-checkbox>
        </div>

        <div>
            <b-spinner v-if="loading" small variant="primary"></b-spinner>
        </div>
    </div>
</template>

<script>
import {required, helpers} from 'vuelidate/lib/validators';
import {mapState} from 'vuex';
import FormSelect from "@comp/FormSelect/FormSelect";
import InlineInputAppend from "@comp/InlineInput/InlineInputAppend";
import {BFormSelect, BFormCheckbox, BSpinner} from 'bootstrap-vue';
import FormSelectSubmit from "@comp/FormSelect/FormSelectSubmit";

const intorfloat = helpers.regex('intorfloat', /^(\d+(?:\,\d+)?)$/);
const errorMsg = 'Ungültiger Wert';

function minValue (value) {
    if (this.param.minValue === null) return true;

    try {
        return parseFloat(value) >= parseFloat(this.param.minValue);
    } catch (e) {
        return false;
    }
}

function maxValue (value) {
    if (this.param.maxValue === null) return true;

    try {
        return parseFloat(value) <= parseFloat(this.param.maxValue);
    } catch (e) {
        return false;
    }
}

export default {
    components: {
        FormSelectSubmit, BFormSelect, FormSelect, InlineInputAppend, BFormCheckbox, BSpinner
    },
    props: {
        param: {
            type: Object,
            required: true
        }
    },
    created() {
        let itemsOptions = this.getParseJsonString(this.param.options);
        if (itemsOptions) {
            this.previousItemsIds = itemsOptions.filter(param => param.key === this.form.value).map(param => param.items)[0];
        }
    },
    data() {
        return {
            form: {
                value: this.param.value
            },
            key: null,
            selectedItemsIds: [],
            errorMsg: errorMsg,
            showCustomValidationErrors: false,
            previousItemsIds: [],
            changed: false,
            loading: false
        }
    },
    mounted() {
        this.prepareValue();
    },
    watch: {
        param(newVal) {
            this.form.value = newVal.value;
            this.prepareValue();
        }
    },
    methods: {
        getInputType() {
            return this.param.stepsize ? 'number' : 'text';
        },
        prepareValue() {
            if (this.param.uiType === 'input') {
                let value = parseFloat(this.form.value);

                value = value.toString().replace('.', ',');

                this.form.value = value;
            } else if (this.param.uiType === 'checkbox') {
                this.form.value = Boolean(Number(this.form.value));
            }
        },
        canEdit() {
            return this.offer.is_onka_writable && (this.offer.user.userRoles.includes('AE') || this.offer.user.isAdmin);
        },
        async submit() {
            this.loading = true;
            if (this.param.uiType === 'input' && this.$v.form.value.$invalid) return;

            if (this.param.uiType === 'dropdown') {
                this.setSelectedItemsId();
            }

            this.showCustomValidationErrors = false;
            this.errorMsg = errorMsg;

            if (!this.changed) {
                return;
            }

            if (this.param.uiType !== 'checkbox') {
                this.$refs.input.setSpinner(true);
            }
            try {
                await this.$axios.put(`/onka/configurations/${this.param.configurationId}/params/${this.param.id}`,
                    {
                        'value': this.form.value,
                        'selectedItemsIds': this.selectedItemsIds,
                        'previousItemsIds': this.previousItemsIds
                    });

                this.changed = false;

                this.$eventBus.$emit('refreshParams');
                this.$eventBus.$emit('refreshComputedItems');
            } catch (e) {
                if (e.response.status === 422) {
                    this.showCustomValidationErrors = true;

                    this.errorMsg = e.response.data;
                } else {
                    window.flash.showMessagesFromAjax(e.response.data);
                }
            } finally {
                if (this.param.uiType !== 'checkbox') {
                    this.$refs.input.setSpinner(false);
                }
                this.loading = false;
            }
        },
        updateItems() {
            let itemsOptions = this.getParseJsonString(this.param.options);
            if (itemsOptions) {
                this.previousItemsIds = itemsOptions.filter(param => param.key === this.form.value).map(param => param.items)[0];
            }
        },
        onInput() {
            this.changed = true;
        },
        async onCheckboxInput() {
            this.changed = true;
            await this.submit();
        },
        options(options) {
            let itemsOptions = this.getParseJsonString(options);

            return itemsOptions.map(product => ({
                value: product.key,
                text: product.value
            }));
        },
        getParseJsonString(str) {
            try {
                return JSON.parse(str);
            } catch (e) {
                return [];
            }
        },
        setSelectedItemsId() {
            let itemsOptions = this.getParseJsonString(this.param.options);
            this.key = this.form.value;
            let key = this.key;
            if (itemsOptions) {
                this.selectedItemsIds = itemsOptions.filter(function (val) {
                    return (key == null) ? val.key === 'empty' : val.key == key;
                })[0].items;
            }
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        }),

        errorConditions() {
            return [
                {
                    name: 'param-invalid',
                    condition: this.showCustomValidationErrors,
                    text: this.errorMsg
                },
                {
                    name: 'param-required',
                    condition: !this.$v.form.value.required,
                    text: this.errorMsg
                },
                {
                    name: 'param-intorfloat',
                    condition: !this.$v.form.value.intorfloat,
                    text: this.errorMsg
                },
                {
                    name: 'param-minValue',
                    condition: !this.$v.form.value.minValue,
                    text: `Minimalwert ${this.param.minValue} unterschritten`
                },
                {
                    name: 'param-maxValue',
                    condition: !this.$v.form.value.maxValue,
                    text: `Maximalwert ${this.param.maxValue} überschritten`
                }
            ]
        }
    },
    validations: {
        form: {
            value: {
                required,
                intorfloat,
                minValue,
                maxValue
            },
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.param-value-container {
    width: 150px;
    @media (min-width: 1600px) {
        width: 200px;
    }
    &.checkbox {
        width: initial;
    }

    display: grid;
    grid-template-columns: 1fr 2rem;
    align-items: center;
    gap: 1rem;
}
::v-deep .inline-input .form-control:read-only {
    background-color: $disabled;
    pointer-events: none;
}
::v-deep .btn {
    height: 38px;
}
</style>
