<template>
    <div v-if="loading" class="placeholder-preloader-wrapper">
        <div v-for="item in [1,2,3,4,5]" class="ph-item">
            <div class="ph-col-24">
                <div class="ph-row">
                    <div class="ph-col-8"></div>
                    <div class="ph-col-12 empty"></div>
                    <div class="ph-col-8"></div>
                </div>
            </div>
        </div>
    </div>
    <div v-else>
        <div class="position-relative">
            <h4> {{ itemsGroupsFilter }} </h4>
            <div>
                <ul
                    :class="(itemsGroupsOptions.length > 0 ? 'col-lg-20' : 'col-lg-24') + ' col-md-24 configuration-items-list__wrapper items-list pl-0'">
                    <li :key="computedKey" id="configuration-items-list" class="list-wrapper">
                        <Item
                            v-for="item in items"
                            @refresh-selected="$emit('refresh-selected')"
                            :item-prop="item"
                            :key="item.itemId"
                        />
                    </li>
                </ul>
                <div class="pagination-wrapper">
                    <span class="total-rows-text">{{ paginationEntriesText }}</span>
                    <b-pagination
                        v-model="currentPage"
                        @input="fetchConfigurationItems(offer.globalGate.simpleId, configurationId)"
                        :total-rows="totalRows"
                        :per-page="perPage"
                        aria-controls="configuration-items-list"
                    ></b-pagination>
                </div>
            </div>
        </div>
        <BoxSpinner :busy="isLoadingMxn('items')"/>
    </div>

</template>

<script>
import {BPagination} from 'bootstrap-vue';
import {mapState} from 'vuex';
import Item from './Item';
import FormRadio from "@comp/FormRadio/FormRadio";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";
import LoaderGroup from "@mixins/LoaderGroup/LoaderGroup";
import Pagination from "@mixins/Pagination/Pagination";

export default {
    name: 'ItemsList',
    components: {
        FormRadio,
        Item, BPagination, BoxSpinner
    },
    mixins: [LoaderGroup, Pagination],
    props: {
        configurationId: {
            type: Number,
            required: true
        },
        itemsGroupsFilter: {
            type: String,
            required: false
        }
    },
    data() {
        return {
            items: [],
            itemsGroupsOptions: [],
            itemsWrapperKey: 0,
            loading: false,
            currentPage: 1,
            totalRows: 0
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),

        computedKey() {
            return this.itemsWrapperKey + 'itemsWrapper';
        }
    },
    watch: {
        async configurationId() {
            await this.fetchConfigurationItems(this.offer.globalGate.simpleId, this.configurationId);
        },
    },
    async created() {
        this.loading = true;
        this.initLoaderGroupsMxn(['items']);
        this.initPaginationMxn(1, 0, 20, '', true, 'tables.position', 'tables.positions');

        await this.fetchConfigurationItems(this.offer.globalGate.simpleId, this.configurationId, this.getFilter());

        this.loading = false;
        this.$eventBus.$on('configurationItemsUpdate', () => this.fetchConfigurationItems(
            this.offer.globalGate.simpleId,
            this.configurationId,
            this.getFilter()
        ));
    },
    methods: {
        /**
         * Fetch configuration items and update pagination variables
         */
        async fetchConfigurationItems(simpleId, configurationId, filter = null) {
            this.showLoader('items', 'list');
            try {
                if (simpleId && configurationId) {
                    const res = await this.$axios.post(`/onka/${simpleId}/configurations/${configurationId}/items`, {
                        currentPage: this.currentPage,
                        perPage: this.perPage,
                        filter
                    });
                    this.totalRows = res.data.total;
                    this.items = res.data.data;
                    this.itemsWrapperKey++;
                    this.$eventBus.$emit('itemsWithEOS', {eosCount: this.getEOSItems(this.items).length});
                } else {
                    console.error('simpleId or configurationId is not provided!');
                }
            } catch (err) {
                console.error('Couldn\'t fetch configuration items', err);
            }
            this.hideLoader('items', 'list');
        },
        /**
         * Get items with 'end of service'
         */
        getEOSItems(items) {
            return items.filter(item => item.item.katalogAp.eos !== null);
        },
        getFilter() {
            if (this.itemsGroupsFilter) {
                return {
                    groupName: this.itemsGroupsFilter
                }
            }

            return null;
        },
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

#configuration-items-list {
    position: relative;
    min-height: 100px;
}

.pagination-wrapper {
    display: flex;
    align-items: center;
    position: relative;

    & > span {
        position: absolute;
    }

    .pagination.b-pagination {
        margin: 0 auto;
    }

    .total-rows-text {
        margin-left: 20px;
    }
}

::v-deep #configuration-items-groups-filter {
    label.btn {
        text-align: left;
        padding: 10px 15px;
    }
}

@media (max-width: 995px) {
    .configuration-items-list__wrapper {
        padding: 0;
    }
}

.placeholder-preloader-wrapper {
    display: flex;
    flex-direction: column;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        box-shadow: none;

        .ph-col-12 {
            padding: 0;
        }
    }

    .ph-row div {
        width: 350px;
    }
}

.items-list {
    list-style: none;
}
</style>
