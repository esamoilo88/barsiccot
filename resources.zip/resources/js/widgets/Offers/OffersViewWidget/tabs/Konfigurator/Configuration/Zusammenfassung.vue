<template>
    <b-overlay :show="pending">
        <h4>Zusammenfassung</h4>
        <table class="table b-table">
            <tr>
                <th>Position</th>
                <th>Menge</th>
                <th class="text-right">Einmalig</th>
                <th class="text-right">Monatlich</th>
            </tr>

            <tr v-for="item in mergedObjects">
                <td v-if="item.group" colspan="5" class="group_row">
                    {{ item.group }}
                </td>
                <td v-if="item.item" class="item_row">
                    {{ item.item.apName }}
                    <div v-if="serviceComputed(item.item.item.service).length >0 "  class="text-muted mt-2">
                        Ausgewählte Optionen:
                        <div v-for="service in serviceComputed(item.item.item.service)">
                            - {{ service }}
                        </div>
                    </div>
                </td>
                <td v-if="item.item">
                    {{ item.item.quantity }} {{ item.item.mengentype }}
                </td>
                <td v-if="item.item" class="text-right text-monospace">
                    {{ einmalig(item.item) }}
                </td>
                <td v-if="item.item" class="text-right text-monospace">
                    {{ monatlich(item.item) }}
                </td>
            </tr>
        </table>
        <div class="pagination-wrapper">
            <span class="total-rows-text">{{ paginationEntriesText }}</span>
            <b-pagination
                v-model="currentPage"
                @input="onResultVorshau()"
                :total-rows="totalRows"
                :per-page="perPage"
                aria-controls="configuration-items-list"
            ></b-pagination>
        </div>
    </b-overlay>
</template>
<script>
import {BPagination, BOverlay} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";

export default {
    components: {BPagination, BOverlay},
    mixins: [Pagination],
    props: {
        simpleId: {
            type: Number,
            required: true
        },
        configurationId: {
            type: Number,
            required: true
        }
    },
    computed: {
        mergedObjects() {
            let result = [];
            let sumArray = [];
            this.items.forEach((item) => {
                if (sumArray.includes(item['groupName'])) {
                    result.push({
                        'item': item
                    });
                } else {
                    sumArray.push(item['groupName']);
                    result.push({
                        'group': item['groupName']
                    });
                    result.push({
                        'item': item
                    });
                }

            });
            return result;
        },
    },
    data() {
        return {
            pending: false,
            items: [],
            currentPage: 1,
            totalRows: 0
        }
    },
    async created() {
        await this.onResultVorshau();
    },
    methods: {
        serviceComputed(service) {
          return service
              .filter(item => item.selected && item.optional)
              .map(item => item.katalogLp.bezeichnung)
        },
        async onResultVorshau() {
            this.pending = true;
            try {
                if (this.simpleId && this.configurationId) {
                    const res = await this.$axios.post(`/onka/${this.simpleId}/configurations/${this.configurationId}/items`, {
                        currentPage: this.currentPage,
                        perPage: this.perPage
                    });
                    this.totalRows = res.data.total;
                    this.items = res.data.data;
                } else {
                    console.error('simpleId or configurationId is not provided!');
                }
            } catch (err) {
                console.error('Couldn\'t fetch configuration items', err);
            }
            this.pending = false;
        },
        monatlich(item) {
            return item.recurrent ? this.$f.numberToString(item.item.unitPrice, true) : '- €'
        },
        einmalig(item) {
            return !item.recurrent ? this.$f.numberToString(item.item.unitPrice, true) : '- €'
        }
    }
}
</script>
<style lang="scss" scoped>
::v-deep table tr:first-child th {
    font-size: inherit !important;
    font-weight: 700;
    border-bottom: 1px solid #6C6C6C;
    border-top: none;
    color: #000;
    padding: 0.7rem 0.8rem;
}
::v-deep th[role=columnheader] {
    height: 42px;
    vertical-align: middle;
    border-top: none;
}
.group_row {
    background-color: #F8F8F8;
    font-weight: bold;
}

.item_row {
    padding-left: 35px;
}
</style>
