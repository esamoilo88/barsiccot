<template>
    <div class="simple-box configuration-item my-3 mini-padding" :class="{'bundle-item': item.item.parentItemId}">
        <div class="row">
            <div class="col-xl-18 col-lg-17 col-md-18 col-sm-18 col-18 mr-5">
                <div class="d-flex justify-content-between">
                    <div class="item-header">
                        <div class="">
                            <div class="item-switch">
                                <IconTooltip
                                    class="mr-2"
                                    v-if="!item.selected && !item.fixed && !item.required "
                                    icon-class="icon-alert-warning-default"
                                    title="Auswahl erfordert Anpassungen"
                                    hint-position="top"
                                />
                                <b-form-checkbox
                                    class="item-switch-input ml-auto"
                                    v-model="item.selected"
                                    @change="onSelectedChange"
                                    size="lg"
                                    :disabled="item.fixed || item.required || checkboxBusy"
                                ></b-form-checkbox>
                            </div>
                        </div>
                        <div class="item-basic-info">
                        <span v-if="item.item.katalogAp.eos !== null" class="eos-warning mb-2">
                            Dieses Produkt ist seit dem {{ formatDate(item.item.katalogAp.eos, 'DD.MM.YYYY') }} veraltet (EOS).
                        </span>
                            <div class="d-flex align-items-center">
                                <span class="item-apName">{{ item.apName }}</span>
                                <IconTooltipModal
                                    v-if="item.item.katalogAp.description"
                                    class="info-tooltip ml-2"
                                    icon-class="icon-alert-information-default"
                                    title="Details anzeigen"
                                    modal-title="Details"
                                    :modal-body="getModalBody(item)"
                                />
                                <b-badge v-if="item.item.parentItemId" class="item-requirement ml-2" variant="secondary">
                                    Bundle
                                </b-badge>
                            </div>
                        </div>
                    </div>
                    <div class="item-footer">
                        <div>
                            <IconTooltip
                                v-if="item.fixedPrice"
                                class="mr-2"
                                icon-class="icon-content-lock-default"
                                title="Festpreis"
                            />
                        </div>
                        <b-overlay :show="unitPricePending">
                            <div>
                                <div class="item-price">{{ $f.numberToString(item.item.unitPrice, true) }}</div>
                                <div>pro {{ item.mengentype }}</div>
                            </div>
                        </b-overlay>
                    </div>
                </div>
            </div>

            <div class="configuration-item-right d-flex align-items-center pr-0">
                <div class="item-quantity">
                    <InlineInputAppend
                        v-model="item.quantity"
                        :input-id="'item-quantity-input-' + item.itemId"
                        submit-button-title="Speichern"
                        @submit="onQuantityEdit"
                        :error-conditions="[
                            {
                                name: 'empty-quantity',
                                condition: isEmpty(this.item.quantity),
                                text: $t.__('validation.required', {attribute: 'Menge'})
                            },{
                                name: 'wrong-format-quantity',
                                condition: !isEmpty(this.item.quantity) && String(this.item.quantity).match(/^\d+$/) === null,
                                text: $t.__('validation.numeric', {attribute: 'Menge'})
                            }
                        ]"
                        ref="input"
                        class="mb-2 width-control"
                        :without-button="true"
                    />
                    <span class="text-muted"> {{ item.paramSourcingName }} </span>
                </div>
            </div>
        </div>
        <div class="" v-if="item.item.service.length > 0">
            <button class="btn btn-link" @click="showServices = !showServices">
                Weitere Details {{ showServices ? 'ausblenden' : 'anzeigen' }}
            </button>
            <b-badge v-if="optionalDataCount > 0" class="item-requirement" variant="success">
                {{ optionalDataCount }} {{ optionalDataCount > 1 ? ' Optionen ' : ' Option ' }} verfügbar
            </b-badge>
        </div>
        <div v-if="showServices">
            <hr class="mt-2">
            <Services :item="item.item" @service-loading="loading" @updated="refreshItem"/>
        </div>
    </div>
</template>
<script>
import IconTooltip from "@comp/IconTooltip/IconTooltip";
import IconTooltipModal from "@comp/IconTooltip/IconTooltipModal";
import {
    BFormCheckbox, BInputGroup, BButton, BFormInput,
    BInputGroupAppend, BBadge, BTooltip, BSpinner, BOverlay
} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {mapGetters} from "vuex";
import Services from "./Services/Services";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import InlineInputAppend from "@comp/InlineInput/InlineInputAppend";

export default {
    name: "Item",
    components: {
        InlineInputAppend,
        IconTooltip, IconTooltipModal, BFormCheckbox, ButtonIcon, BBadge, BTooltip,
        BInputGroup, BButton, BFormInput, BInputGroupAppend, Services, BSpinner, BOverlay
    },
    mixins: [ScalarsProcessing, DatesProcessing],
    props: {
        itemProp: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            item: this.itemProp,
            checkboxBusy: false,
            showServices: false,
            unitPricePending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
        optionalDataCount() {
            return this.item.item.service.filter(e => e.optional).length;
        }
    },
    methods: {
        /**
         * Handler for saving quantity
         */
        async onQuantityEdit() {
            this.loading(true);

            try {
                await this.$axios.post(`/onka/${this.simpleId}/configurations/items/${this.item.itemId}/saveQuantity`, {
                    quantity: this.item.quantity
                });

                this.$eventBus.$emit('refreshComputedItems');
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't save quantity", err);
            }
            this.loading(false);

            this.isQuantityEdit = false;
        },

        /**
         * Save the value of switch
         * @param value
         */
        async onSelectedChange(value) {
            const result = await this.checkBundles();
            if (!result) return;

            this.loading(true);
            try {
                await this.$axios.post(`/onka/${this.simpleId}/configurations/items/${this.item.itemId}/saveSelected`, {
                    selected: this.item.selected
                });
                this.$emit('refresh-selected');

                this.$eventBus.$emit('refreshComputedItems');
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't switch value", err);
            }
            this.loading(false);
        },
        async checkBundles() {
            if (
                !(this.item.selected
                && !this.item.fixed
                && !this.item.required
                && this.item.item.katalogAp.bundles.length)
            ) return true;

            const confirmed = await this.$bvModal.msgBoxConfirm(this.getBundleModalBody(this.item), {
                title: 'Auswahl-Assistent',
                okTitle: 'In Konfiguration übernehmen',
                cancelTitle: 'Abbrechen',
                footerClass: 'confirmation-modal-footer flex-row-reverse justify-content-center',
                titleTag: 'h2',
            })

            this.$root.$on('bv::modal::shown', (bvEvent) => {
                const modalTitle = bvEvent.vueTarget.$refs.header.querySelector('.modal-title');

                modalTitle.setAttribute('tabindex', '0');
                modalTitle.focus();
            })

            if (confirmed) {
                await this.onBundleOk(this.item);
                return true;
            }

            this.item.selected = false;
            return false;
        },
        getModalBody(item) {
            const h = this.$createElement;

            const messageVNode = h('div', {}, [
                h('h6', {domProps: {innerHTML: item.apName}}),
                h('div', {style: {'white-space': 'pre-line'}, domProps: {innerHTML: item.item.katalogAp.description}})
            ])

            return messageVNode;
        },
        getBundleModalBody(item) {
            const h = this.$createElement;

            let list = '';

            item.item.katalogAp.bundles.forEach(bundle => {
                list += `<li>${bundle.bundleAngebotsposition.name}</li>`
            });

            return h('div',
                {
                    domProps:
                        {
                            innerHTML:
                                `<div class="mb-3">Die Auswahl der Angebotsposition <strong>${item.apName}</strong> erfordert eine Anpassung der Konfiguration.</div>` +
                                '<div class="simple-box">' +
                                    '<div class="mb-3">Es werden folgende Angebotsposition zusätzlich hinzugefügt:</div>' +
                                    `<ul>${list}</ul>` +
                                '</div>'
                        }
                }
            );
        },
        async onBundleOk(item) {
            try {
                await this.$axios.post(`/onka/${this.simpleId}/configurations/items/${item.itemId}/bundles`);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        loading(bool) {
            this.checkboxBusy = bool;
            this.$refs.input.setSpinner(bool);
        },
        async refreshItem() {
            this.unitPricePending = true;

            try {
                const response = await this.$axios.get(`/onka/configurations/items/${this.item.itemId}`);

                this.item.item.unitPrice = response.data.unitPrice;
            } catch (e) {
                console.log(e.response.data);
            }

            this.unitPricePending = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
.width-control {
    width: 150px;
    @media (min-width: 1600px) {
        width: 200px;
    }
}
.item-quantity__wrapper {
    display: flex;
    flex-direction: column;

    .item-mengentyp {
        //font-size: 1.2rem;
        color: $grey;
    }
}

.item-apName {
    max-width: 670px;
    //font-size: 22px;
}

::v-deep .inline-input__container .input-wrapper {
    width: 62px;
}

::v-deep .quantity-input input {
    padding: 4px 6px 4px 0;
    max-height: 38px;
}
::v-deep .btn {
    height: 38px;
}
::v-deep .edit-quantity-btn {
    .btn-icon__icon {
        font-size: 15px;
    }

    button {
        padding: 3px 7px;
    }
}

.item-basic-info {
    display: flex;
    flex-direction: column;
}

::v-deep .info-tooltip {
    //font-size: 25px;
}

.item-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.item-footer {
    display: grid;
    align-items: center;
    grid-template-columns: 1rem 6rem;
    gap: 1rem;
}

.item-price {
    //font-size: 1.7rem;
    font-weight: bold;
}

.item-switch {
    min-height: 25px;
    margin-left: auto;
    display: grid;
    grid-template-columns: 0fr 0fr 0fr;
    align-items: baseline;

    .custom-control {
        margin-top: -5px;
    }

    .switch-warning {
        //font-size: 1.6rem;
    }
}

@media (max-width: 995px) {
    .item-switch-input {
        margin-left: 0 !important;
    }
    .item-quantity__wrapper {
        padding-left: 15px;
    }
    .item-quantity__wrapper {
        align-items: center !important;
    }
    .item-switch {
        justify-content: center;
    }
    .item-switch {
        margin-top: 15px;
    }
}

.eos-warning {
    font-weight: bold;
    color: red;
}

.bundle-warning {
    //font-size: 1.6rem;
}

.bundle-item {
    margin-left: 40px;
}

.mini-padding {
    padding-left: 10px;
}
::v-deep .btn-link {
    font-weight: 400;
    color: $link;
    text-decoration: none;
}
.configuration-item-right {
    width: 130px;
}
</style>
