<!--Service between Form.vue and Index.vue that manages data-->
<template>
    <modal-dialog
        :is-visible="isModalVisible"
        size="lg"
        @hideModal="hideModal"
        :title-dialog="getModalTitle()"
        modal-class="manage-ap"
        scrollable
    >
        <div @keyup.enter="submit">
            <Form
                ref="form"
                :form="form"
                @onMargeTypeInput="onMargeTypeInput"
                @onPreisfaktorTypeInput="onPreisfaktorTypeInput"
                :insert-before-btn-title="insertBeforeBtnTitle"
                :insert-after-btn-title="insertAfterBtnTitle"
            />
        </div>

        <template v-slot:footer>
            <b-button variant="primary" @click="submit">{{ getSubmitBtnTitle() }}</b-button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import Form from './Form';
import {mapActions, mapGetters, mapState} from "vuex";
import {BButton} from 'bootstrap-vue';

const defaultType = 1;
const customType = 2;

const insertBeforeBtnTitleCreate = 'Einfügen vor';
const insertAfterBtnTitleCreate = 'Einfügen nach';

const insertBeforeBtnTitleUpdate = 'Verschiebe vor';
const insertAfterBtnTitleUpdate = 'Verschiebe nach';

const cleanForm = {
    name: null,
    producttypeId: null,
    quantity: null,
    fixedPrice: false,
    unitPrice: null,
    preisfaktor: null,
    marge: null,
    optional: false,
    deaktiviert: false,
    beschreibung: null,
    margeType: defaultType,
    preisfaktorType: defaultType,
}

export default {
    components: {Form, ModalDialog, BButton},
    computed: {
        ...mapState({
            offer: state => state.offer.offer || {
                globalGate: {simpleId: null},
                offerInfo: {preisfaktor: null, marge: null}
            }
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        }),
    },
    data() {
        return {
            isModalVisible: false,
            form: {...{}, ...cleanForm},
            angebotspositionId: null,
            insertBeforeBtnTitle: insertBeforeBtnTitleCreate,
            insertAfterBtnTitle: insertAfterBtnTitleCreate,
        }
    },
    mounted() {
        this.setDefault();
    },
    methods: {
        ...mapActions({
            fetchOfferData: "offer/fetchOfferData"
        }),
        async showModal() {
            this.isModalVisible = true;

            await this.fetchOfferData({simpleId: this.offer.globalGate.simpleId, currentVersion: this.currentVersion});
            this.setDefault();
        },
        hideModal() {
            this.clearForm();
            this.$refs.form.clear();

            this.isModalVisible = false;
        },
        setForm(item) {
            this.angebotspositionId = item.angebotspositionId;

            this.form.name = item.bezeichnung;
            this.form.producttypeId = item.producttypeId;
            this.form.quantity = item.menge;
            this.form.fixedPrice = item.fixedPrice;
            this.form.optional = item.optional;
            this.form.deaktiviert = item.deaktiviert;
            this.form.beschreibung = item.beschreibung;
            this.form.isChangeLpMenge = false;
            this.form.angebotspositionId = item.angebotspositionId;

            if (item.fixedPrice) {
                this.form.unitPrice = this.$f.dotToComma(item.unitPrice);
            }

            if (item.preisfaktor) {
                this.form.preisfaktorType = 2;
                this.form.preisfaktor = this.$f.dotToComma(item.preisfaktor);
            }

            if (item.marge) {
                this.form.margeType = 2;
                this.form.marge = this.$f.dotToComma(item.marge);
            }

            this.insertBeforeBtnTitle = insertBeforeBtnTitleUpdate;
            this.insertAfterBtnTitle = insertAfterBtnTitleUpdate;
        },
        clearForm() {
            this.form = {...{}, ...cleanForm};

            this.angebotspositionId = null;

            this.insertBeforeBtnTitle = insertBeforeBtnTitleCreate;
            this.insertAfterBtnTitle = insertAfterBtnTitleCreate;

            this.setDefault();
        },
        setDefault() {
            if (this.form.preisfaktorType == defaultType) {
                this.form.preisfaktor = this.$f.dotToComma(this.offer.offerInfo.preisfaktor);
            }

            if (this.form.margeType == defaultType) {
                this.form.marge = this.$f.dotToComma(this.offer.offerInfo.marge);
            }

            this.form.vkVersionsId = this.currentVersion;
        },
        getModalTitle() {
            if (this.angebotspositionId) {
                return 'Angebotsposition bearbeiten'
            }

            return 'Neue Angebotsposition'
        },
        getSubmitBtnTitle() {
            if (this.angebotspositionId) {
                return 'Angebotsposition bearbeiten'
            }

            return 'Angebotsposition anlegen'
        },
        onMargeTypeInput() {
            if (this.form.margeType == defaultType) {
                this.form.marge = this.$f.dotToComma(this.offer.offerInfo.marge);
            }
        },
        onPreisfaktorTypeInput() {
            if (this.form.preisfaktorType == defaultType) {
                this.form.preisfaktor = this.$f.dotToComma(this.offer.offerInfo.preisfaktor);
            }
        },
        async submit() {
            if (!this.$refs.form.validate()) return;

            window.preloader.show();

            try {
                const simpleId = this.offer.globalGate.simpleId;

                if (this.angebotspositionId) {
                    await this.$axios.put(`/offers/${simpleId}/aps/${this.angebotspositionId}`, this.form);
                } else {
                    await this.$axios.post(`/offers/${simpleId}/aps`, this.form);
                }

                this.hideModal();
                this.clearForm();

                this.$emit('submit');

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshLPList');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
</script>
