<template>
    <div>
        <p>Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

        <div class="simple-box mb-4">
            <b-form-group>
                <FormInput
                    v-model="form.name"
                    :error-conditions="errorConditions.name"
                    label-text="Name*"
                    name="name"
                    input-id="name"
                />
            </b-form-group>

            <b-overlay :show="pending">
                <b-form-group>
                    <FormSelect
                        v-model="form.producttypeId"
                        :options="producttypes"
                        :error-conditions="errorConditions.producttypeId"
                        label-text="Produkttyp*"
                        name="producttypeId"
                        select-id="producttypeId"
                        searchable
                    />
                </b-form-group>
            </b-overlay>

            <b-form-group>
                <div class="row">
                    <div class="col-6">
                        Mengentyp:
                    </div>
                    <div class="col-auto">
                        <strong>{{ producttype.mengentypName }}</strong>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        Preistyp:
                    </div>
                    <div class="col-auto">
                        <strong>{{ producttype.preistypName }}</strong>
                    </div>
                </div>
            </b-form-group>

            <b-form-group>
                <FormInput
                    v-model="form.quantity"
                    :error-conditions="errorConditions.menge"
                    label-text="Menge*"
                    name="menge"
                    input-id="menge"
                />
            </b-form-group>

            <b-form-group v-if="this.form.angebotspositionId">
                <b-form-checkbox switch v-model="form.isChangeLpMenge">
                    Menge der zugeordneten Leistungspositionen ebenfalls anpassen
                </b-form-checkbox>
            </b-form-group>
        </div>

        <div class="simple-box mb-4">
            <b-form-group>
                <b-form-checkbox switch v-model="form.fixedPrice">
                    Festpreis
                </b-form-checkbox>

                <p class="text-muted">Wenn Festpreis aktiviert wird, wird der Stückpreis nicht anhand der Stückkosten berechnet sondern kann direkt festgelegt werden. Dies kann die effektive Marge beeinflussen.</p>
            </b-form-group>

            <template v-if="form.fixedPrice">
                <b-form-group>
                    <FormInputAppend
                        v-model="form.unitPrice"
                        input-id="unitPrice"
                        name="unitPrice"
                        label-text="Stückpreis*"
                        :error-conditions="errorConditions.unitPrice"
                        prepended
                        prepend="€"
                    />
                    <p class="text-muted mt-2">Auf den hier erfassten Festpreis wird der Gemeinkostenzuschlag nachträglich angewendet. Bitte trage daher den Festpreis als TP1 ein.</p>
                </b-form-group>
            </template>

            <template v-else>
                <div class="row">
                    <div class="col-12">
                        <b-form-group>
                            <FormSelect
                                v-model="form.preisfaktorType"
                                name="artDesPreisfaktors"
                                label-text="Art des Preisfaktors"
                                select-id="artDesPreisfaktors"
                                :options="options"
                                @input="$emit('onPreisfaktorTypeInput')"
                            />
                        </b-form-group>
                    </div>
                    <div class="col-12">
                        <b-form-group>
                            <FormInputAppend
                                v-model="form.preisfaktor"
                                input-id="preisfaktor"
                                name="preisfaktor"
                                label-text="Preisfaktor*"
                                :disabled="isDisabled(form.preisfaktorType)"
                                :error-conditions="errorConditions.preisfaktor"
                                prepended
                                prepend="%"
                            />
                        </b-form-group>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <b-form-group>
                            <FormSelect
                                v-model="form.margeType"
                                name="margeType"
                                label-text="Art der Marge"
                                select-id="margeType"
                                :options="options"
                                @input="$emit('onMargeTypeInput')"
                            />
                        </b-form-group>
                    </div>
                    <div class="col-12">
                        <b-form-group>
                            <FormInputAppend
                                v-model="form.marge"
                                input-id="marge"
                                name="marge"
                                label-text="Marge*"
                                :disabled="isDisabled(form.margeType)"
                                :error-conditions="errorConditions.marge"
                                prepended
                                prepend="%"
                            />
                        </b-form-group>
                    </div>
                </div>
            </template>
        </div>

        <div class="simple-box mb-4">
            <b-form-group>
                <FormTextArea
                    v-model="form.beschreibung"
                    @handleTextArea="handleTextArea"
                    label-text="Langbeschreibung"
                    name="beschreibung"
                    input-id="beschreibung"
                    rows="8"
                />
            </b-form-group>

            <b-form-group>
                <b-form-checkbox switch v-model="form.optional">
                    Optional
                </b-form-checkbox>

                <p class="text-muted">Die Angebotsposition wird optional angeboten. Solange das Angebot nicht beauftragt ist wird der Preis dieser Angebotsposition nicht in die Gesamtsumme eingerechnet.</p>
            </b-form-group>

            <b-form-group>
                <b-form-checkbox switch v-model="form.deaktiviert">
                    Gesperrt
                </b-form-checkbox>

                <p class="text-muted">Alle weiterführenden interaktionen mit dieser Angebotsposition werden abgeschaltet. Dies betrifft Schnittstellen, Faktura und den Gesamtbetrag des Angebots.</p>
            </b-form-group>
        </div>

        <div class="simple-box">
            <b-form-group>
                <FormSelect
                    v-model="form.sortBefore"
                    :options="aps"
                    :label-text="insertBeforeBtnTitle"
                    name="sortBefore"
                    select-id="sortBefore"
                />
            </b-form-group>
            <b-form-group>
                <FormSelect
                    v-model="form.sortAfter"
                    :options="aps"
                    :label-text="insertAfterBtnTitle"
                    name="sortAfter"
                    select-id="sortAfter"
                />
            </b-form-group>
        </div>
    </div>
</template>
<script>
import {BButton, BFormGroup, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import FormInput from '@comp/FormInput/FormInput';
import FormInputAppend from '@comp/FormInput/FormInputAppend';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormTextArea from '@comp/FormTextArea/FormTextArea';
import Validation from '@mixins/Validation/Validation';
import {mapGetters, mapState} from "vuex";
import {required, integer, requiredIf, helpers} from "vuelidate/lib/validators";

const intorfloat = helpers.regex('intorfloat', /^(-?\d+(?:\,\d+)?)$/);

const defaultType = 1;
const customType = 2;

export default {
    components: {BButton, FormInput, FormSelect, FormTextArea, BFormGroup, BFormCheckbox, FormInputAppend, BOverlay},
    mixins: [Validation],
    props: {
        insertBeforeBtnTitle: {
            type: String,
            default: 'Einfügen vor'
        },
        insertAfterBtnTitle: {
            type: String,
            default: 'Einfügen nach'
        },
        form: {
            required: true,
            type: Object
        }
    },
    data() {
        return {
            producttype: {
                mengentypName: null,
                preistypName: null,
            },
            producttypes: [],
            aps: [],
            options: [
                {
                    id: defaultType,
                    text: 'Angebot'
                },
                {
                    id: customType,
                    text: 'Individual'
                }
            ],
            pending: true
        }
    },
    watch: {
        'form.producttypeId': function () {
            this.onProducttypeInput(this.form.producttypeId)
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        }),
        errorConditions() {
            return {
                menge: [
                    {
                        name: 'invalid-quantity-required',
                        condition: this.isInvalid('quantity', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Menge'})
                    },
                    {
                        name: 'invalid-quantity-integer',
                        condition: this.isInvalid('quantity', 'integer'),
                        text: 'Falscher Wert für das Feld Menge.'
                    }
                ],
                name: [
                    {
                        name: 'invalid-name',
                        condition: this.isInvalid('name'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    }
                ],
                producttypeId: [
                    {
                        name: 'invalid-producttypeId',
                        condition: this.isInvalid('producttypeId'),
                        text: 'Produkttyp muss ausgefüllt werden.'
                    }
                ],
                unitPrice: [
                    {
                        name: 'invalid-unitPrice-required',
                        condition: this.isInvalid('unitPrice', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Stückpreis'})
                    },
                    {
                        name: 'invalid-unitPrice-intorfloat',
                        condition: this.isInvalid('unitPrice', 'intorfloat'),
                        text: 'Falscher Wert für das Feld Stückpreis.'
                    }
                ],
                marge: [
                    {
                        name: 'invalid-marge',
                        condition: this.isInvalid('marge'),
                        text: 'Falscher Wert für das Feld Marge.'
                    }
                ],
                preisfaktor: [
                    {
                        name: 'invalid-preisfaktor',
                        condition: this.isInvalid('preisfaktor'),
                        text: 'Falscher Wert für das Feld Preisfaktor.'
                    }
                ]
            }
        }
    },
    async mounted() {
        await this.getAPs();
        await this.getProducttypes();
        this.onProducttypeInput(this.form.producttypeId)
    },
    methods: {
        clear() {
            this.producttype.mengentypName = null;
            this.producttype.preistypName = null;

            this.showValidationErrors = false;
        },
        async getAPs() {
            try {
                const simpleId = this.offer.globalGate.simpleId;

                const response = await this.$axios.get(`/offers/${simpleId}/vkVersions/${this.currentVersion}/aps`);

                this.aps = response.data;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
        },
        async getProducttypes() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/onka/producttypes`);

                this.producttypes = response.data;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }

            this.pending = false;
        },
        onProducttypeInput(id) {
            const producttype = this.producttypes.find(item => item.id == id);

            if (producttype) this.producttype = producttype;
        },
        handleTextArea(value) {
            this.form.beschreibung = value;
        },
        isDisabled(value) {
            return value == defaultType;
        },
    },
    validations: {
        form: {
            name: {
                required
            },
            producttypeId: {
                required,
                integer
            },
            quantity: {
                required,
                integer
            },
            unitPrice: {
                required: requiredIf('fixedPrice'),
                intorfloat
            },
            marge: {
                required,
                intorfloat
            },
            preisfaktor: {
                required,
                intorfloat
            }
        }
    }
}
</script>
