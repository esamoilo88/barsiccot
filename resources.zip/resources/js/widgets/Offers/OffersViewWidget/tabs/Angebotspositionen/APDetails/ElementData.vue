<template>
    <div>
        <abbr
            :class="getBadge(item.kostenart.zuordnung)"
            :id="getUniqName(item.kostenart.zuordnung, item.elementId)"
            :title="item.kostenart.zuordnung">
            {{ item.kostenart.zuordnung }}
        </abbr>

        <b-tooltip :target="getUniqName(item.kostenart.zuordnung, item.elementId)">
            {{ item.kostenart.zuordnung }}
        </b-tooltip>

        {{ item.kostenart.bezeichnung }}

        <span class="icon-navigation-right-default lightgrey"/>

        {{ item.bezeichnung }}
    </div>
</template>

<script>
import {BTooltip} from 'bootstrap-vue';

export default {
    components: {BTooltip},
    props: {
        item: {
            type: Object,
            required: true
        }
    },
    methods: {
        getUniqName(name, id) {
            return `${name}_${id}`;
        },
        getBadge(zuordnung) {
            let badge = 'badge-secondary';

            switch (zuordnung) {
                case 'ISP': badge = 'badge-info'; break;
                case 'DTS': badge = 'badge-success'; break;
                case 'DTA': badge = 'badge-warning'; break;
            }

            return `badge ${badge}`;
        }
    }
}
</script>
