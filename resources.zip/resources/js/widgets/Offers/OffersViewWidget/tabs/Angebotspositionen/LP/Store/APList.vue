<template>
    <div>
        <b-overlay :show="pending">
            <b-table-lite id="ap-list-for-lp-creation" :items="items" :fields="fields">
                <template #cell(bezeichnung)="item">
                    <truncated-text
                        :text="item.item.bezeichnung"
                        title="Angebotsposition bezeichnung"
                        :width=350
                    />
                </template>

                <template #cell(menge)="item">
                    <input
                        v-model="item.item.menge"
                        :id="`ap-menge-${item.item.angebotspositionId}`"
                        :key="`ap-menge-${item.item.angebotspositionId}`"
                        name="ap-menge"
                        class="quantity-input form-control"
                        maxlength="7"
                        autocomplete="off"
                        @change="mengeChanged"
                    />
                    <div
                        v-if="$v.items.$each[item.index].$invalid"
                        :id="'menge-validation-error-' + item.item.angebotspositionId"
                        class="error-message invalid-feedback d-block">
                        <span
                            role="alert"
                            aria-live="assertive"
                            aria-atomic="true"

                        >
                            Ungültiger Wert
                      </span>
                    </div>
                </template>

                <template #custom-foot>
                    <b-tr v-if="items.length === 0">
                        <b-td colspan="3" class="text-center">Keine Daten vorhanden</b-td>
                    </b-tr>
                </template>
            </b-table-lite>

            <div v-if="items.length" class="pagination-wrapper">
                <b-pagination
                    v-model="currentPage"
                    @input="fetchAPs"
                    :total-rows="totalRows"
                    :per-page="perPage"
                    aria-controls="lp-list-for-element-creation"
                ></b-pagination>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BTableLite, BOverlay, BPagination, BFormCheckbox, BTfoot, BTr, BTd} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";
import {mapGetters} from 'vuex';
import {required, numeric} from 'vuelidate/lib/validators';
import FormInput from "@comp/FormInput/FormInput";
import InlineInput from "@comp/InlineInput/InlineInput";
import TruncatedText from "@comp/TruncatedText/TruncatedText";

export default {
    name: "APList",
    components: {
        TruncatedText,
        InlineInput,
        FormInput,
        BTableLite, BOverlay, BPagination, BFormCheckbox,
        BTfoot, BTr, BTd
    },
    mixins: [Pagination],
    async created() {
        this.initPaginationMxn(1, 0, 10);
        await this.fetchAPs();
    },
    data() {
        return {
            items: [],
            fields: [
                {key: "sort", label: "Nr"},
                {key: "bezeichnung", label: "Angebotsposition"},
                {key: "menge", label: "Menge"},
            ],
            pending: false,
            isValidMenge: true,
            selected: []
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        })
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            this.$v.isMengeValid = this.isValidMenge;
            return this.$v;
        },
        /**
           * Fetch the list of project APs
         * @returns {Promise<void>}
         */
        async fetchAPs() {
            this.pending = true;
            try {
                let res = await this.$axios.post(`/offers/calculations/aps/paginated-custom`, {
                    simpleId: this.simpleId,
                    vkVersionId: this.currentVersion,
                    perPage: 20,
                    currentPage: this.currentPage,
                });
                this.items.splice(0);
                this.items.push(...res.data.data);
                this.totalRows = res.data.total;
            } catch (err) {
                console.error("Couldn't fetch AP list.", err);
                window.flash.error('Ein Fehler ist aufgetreten.');
            }
            this.pending = false;
        },
        mengeChanged() {
            this.selected = this.items.filter(item => item.menge).map(item => ({id: item.angebotspositionId, menge: item.menge}));

            this.$emit('change', this.selected);
        }
    },
    validations: {
        items: {
            $each: {
                menge: {numeric}
            }
        }
    }
}
</script>

<style lang="scss" scoped>
    @import "resources/sass/variables";

    .invalid {
        border: 1px solid $error;
        border-radius: 5px;
    }
    .error-message {
        .invalid-feedback {
            color: $error;
            margin-bottom: 0;
            border: none;
        }
    }
    .quantity-input {
        max-height: 30px;
        max-width: 80px;
        font-size: 1.125rem !important;
    }
    .link {
        color: #00739F;
        &:hover {
            text-decoration: underline;
            cursor: pointer;
        }
    }
</style>
