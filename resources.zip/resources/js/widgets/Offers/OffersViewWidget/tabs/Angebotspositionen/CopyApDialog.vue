<template>
    <modal-dialog
        :is-visible="show"
        @hideModal="hide"
        title-dialog="Angebotsposition kopieren"
        modal-class="copy-ap-dialog"
    >
        <b-overlay :show="pending">
            <div class="simple-box">
                <div class="form-group">
                    <FormInput
                        v-model="form.anzahl"
                        :error-conditions="errorConditions.anzahl"
                        label-text="Anzahl*"
                        name="anzahl"
                        input-id="anzahl"
                    />
                </div>

                <div class="form-group">
                    <FormSelect
                        v-model="form.sortBefore"
                        :options="aps"
                        label-text="Einfügen vor"
                        name="sortBefore"
                        select-id="sortBefore"
                    />
                </div>
                <div class="form-group">
                    <FormSelect
                        v-model="form.sortAfter"
                        :options="aps"
                        label-text="Einfügen nach"
                        name="sortAfter"
                        select-id="sortAfter"
                    />
                </div>
            </div>
        </b-overlay>

        <template #footer="{methods}">
            <button class="btn btn-primary" @click="submit">Angebotsposition kopieren</button>
            <button class="btn btn-secondary" @click="hide">Abbrechen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import FormInput from '@comp/FormInput/FormInput';
import FormSelect from '@comp/FormSelect/FormSelect';
import {mapGetters, mapState} from "vuex";
import {integer, required} from "vuelidate/lib/validators";
import Validation from '@mixins/Validation/Validation';
import {BOverlay} from 'bootstrap-vue';

export default {
    components: {ModalDialog, FormInput, FormSelect, BOverlay},
    mixins: [Validation],
    props: {
        show: {
            type: Boolean,
            default: false
        },
        apId: {
            required: true
        }
    },
    data() {
        return {
            pending: true,
            aps: [],
            form: {
                anzahl: 1,
                sortBefore: null,
                sortAfter: null,
            }
        }
    },
    async mounted() {
        this.pending = true;

        await this.getAPs();

        this.pending = false;
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        }),
        errorConditions() {
            return {
                anzahl: [
                    {
                        name: 'invalid-anzahl-required',
                        condition: this.isInvalid('anzahl', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Anzahl'})
                    },
                    {
                        name: 'invalid-anzahl-integer',
                        condition: this.isInvalid('anzahl', 'integer'),
                        text: 'Falscher Wert für das Feld Anzahl.'
                    }
                ],
            }
        }
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        clear() {
            this.form = {
                anzahl: 1,
                sortBefore: null,
                sortAfter: null,
            }

            this.$v.$reset();
        },
        async getAPs() {
            try {
                const simpleId = this.offer.globalGate.simpleId;

                const response = await this.$axios.get(`/offers/${simpleId}/vkVersions/${this.currentVersion}/aps`);

                this.aps = response.data;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
        },
        async submit() {
            if (!this.validate() || this.pending) return;

            this.pending = true;

            try {
                const simpleId = this.offer.globalGate.simpleId;

                await this.$axios.post(`/offers/${simpleId}/aps/${this.apId}/copy`, this.form);

                this.clear();
                this.hide();

                this.$eventBus.$emit('refreshAPList');

                window.flash.success('Angebotsposition wurde kopiert');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }

            this.pending = false;
        }
    },
    validations: {
        form: {
            anzahl: {
                required,
                integer
            },
        }
    }
}
</script>
