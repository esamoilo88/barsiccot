<template>
    <div class="w-100 conditional-input-wrapper d-flex flex-column">
        <!-- If a field is an input represented by a custom component -->
        <component
            v-if="isCustomInput"
            v-model="input.content"
            ref="customInput"
            :is="customInputComponent()"
            :key="settings.id"
        ></component>
        <!-- If a field is a text or a number -->
        <FormInput
            v-else-if="(settings.inputType === 'text' || settings.inputType === 'number') && settings.prefix === null"
            v-model="input.content"
            ref="input"
            :name="`${settings.object}-${settings.sysField}`"
            :label-text="inputLabel"
            :input-id="`${settings.object}-${settings.sysField}-input`"
            :key="settings.id"
            :error-conditions="errorMessages"
        />
        <!-- If a field is one of a select tag options -->
        <FormSelect
            v-else-if="settings.inputType === 'select'"
            v-model="input.content"
            ref="selectInput"
            :name="`${settings.object}-${settings.sysField}`"
            :label-text="inputLabel"
            :select-id="`${settings.object}-${settings.sysField}-input`"
            :options="input.options"
            :searchable="input.searchable"
            :key="settings.id"
            :error-conditions="errorMessages"
        />
        <!-- If a field is an input with prefix -->
        <FormInputAppend
            v-else-if="settings.prefix !== null"
            v-model="input.content"
            :label-text="inputLabel"
            :name="`${settings.object}-${settings.sysField}`"
            :input-id="`${settings.object}-${settings.sysField}-input`"
            :key="settings.id"
            :error-conditions="errorMessages"
            prepended
        >
            <template #prepend>
                <b-input-group-prepend is-text>
                    <span v-if="settings.prefix.match(/^icon-/) !== null" :class="settings.prefix + ' pb-1'"></span>
                    <template v-else> {{ settings.prefix }} </template>
                </b-input-group-prepend>
            </template>
        </FormInputAppend>
        <!-- If input is a checkbox -->
        <b-form-checkbox
            v-else-if="settings.inputType === 'checkbox'"
            v-model="input.content"
            class="multiedit-checkbox"
            :key="settings.id"
            switch
        >
            {{ inputLabel }}
        </b-form-checkbox>
        <!-- If input is a textarea -->
        <FormTextArea
            v-else-if="settings.inputType === 'textarea'"
            v-model="input.content"
            :input-id="`${settings.object}-${settings.sysField}-input`"
            :label-text="inputLabel"
            :name="`${settings.object}-${settings.sysField}`"
        />
        <b-overlay :show="pending" no-wrap></b-overlay>
    </div>
</template>

<script>
import FormInput from "@comp/FormInput/FormInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import CustomInputs from "./CustomInputs";
import {BOverlay, BInputGroupPrepend, BFormCheckbox} from "bootstrap-vue";
import {fieldsPreparators} from "./InputsPreparation";
import {required} from "vuelidate/lib/validators";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
const translations = require('res/lang/lang.translations.json');
const $t = new SimpleTranslator(translations);

export default {
    name: "ConditionalInput",
    components: {
        FormInput, FormSelect, FormInputAppend, BInputGroupPrepend,
        BOverlay, BFormCheckbox, FormTextArea, ...CustomInputs
    },
    props: {
        value: null,
        settings: {
            type: Object,
            required: true
        },
        errorConditions: {
            type: Array,
            required: false
        },
    },
    async created() {
        this.isCustomInput = this.isCustomInputComponent();
        if (!this.isCustomInput) {
            this.pending = true;
            await this.prepareInput();
            this.pending = false;
        }
    },
    data() {
        return {
            /**
             * input object is common for every conditional input
             * if it's a regular input it will use only content,
             * if it's a select input it will also use options array
             */
            input: {
                content: null,
                options: [],
                searchable: false
            },
            validationRules: {
                input: {
                    content: {}
                }
            },
            errorMessages: [],
            isCustomInput: false,
            pending: false
        }
    },
    computed: {
        inputLabel() {
            return this.settings.required ? this.settings.uiField + '*' : this.settings.uiField;
        }
    },
    watch: {
        value(newVal, oldVal) {
            this.input.content = newVal;
        },
        'input.content': function(newValue, oldValue) {
            if (!this.isCustomInput) {
                this.refreshErrorMessages();
            }
            this.$emit('input', {field: this.settings.sysField, value: newValue});
        }
    },
    methods: {
        /**
         * Validate the input and return the object of validation
         */
        validate() {
            if (this.isCustomInput) {
                return this.$refs.customInput.validate();
            } else {
                this.resetValidation();
                this.$v.$touch();
                this.refreshErrorMessages();
                return this.$v;
            }
        },
        /**
         * resetting is placed in separate method just for
         * ability to call it outside of this component
         */
        resetValidation() {
            if (this.isCustomInput) {
                this.$refs.customInput.resetValidation();
            } else {
                this.$v.$reset();
                this.refreshErrorMessages();
            }
        },
        /**
         *  Prepare all the data for rendering input
         */
        async prepareInput() {
            if (!this.isCustomInput) {
                let preparator = fieldsPreparators[this.settings.object][this.settings.sysField];
                if (preparator !== undefined) {
                    let data = await preparator(this.$axios);
                    this.input = {...this.input, ...data.input};
                    this.validationRules.input.content = this.settings.required
                        ? {...data.validationRules, required}
                        : {...data.validationRules};
                    this.createErrorMessages(
                        this.settings.required
                        ? [...data.errorMessages, {
                            name: 'empty-' + this.settings.sysField,
                            rule: 'required',
                            text: $t.__('validation.required', {attribute: this.settings.uiField})
                        }]
                        : [...data.errorMessages]
                    );
                    this.settings.inputType === 'select' && this.refreshSelectInput();
                } else {
                    this.validationRules.input.content = this.settings.required ? {required} : {};
                    this.settings.required && this.createErrorMessages([{
                        name: 'empty-' + this.settings.sysField,
                        rule: 'required',
                        text: $t.__('validation.required', {attribute: this.settings.uiField})
                    }]);
                }
            }
        },
        /**
         * Reinit select2 because some settings were dynamically added
         */
        refreshSelectInput() {
            this.input.searchable && (this.$refs.selectInput.settings.minimumResultsForSearch = undefined);
            this.$refs.selectInput.reinitialize();
        },
        /**
         * Define is an input a custom component or not
         * @returns boolean
         */
        isCustomInputComponent() {
            let registeredComponents = Object.keys(this.$options.components);
            return registeredComponents.includes(this.settings.object.toUpperCase() + this.settings.sysField);
        },
        /**
         * Create the name of component for custom input
         * @returns string
         */
        customInputComponent() {
            return this.settings.object.toUpperCase() + this.settings.sysField;
        },
        /**
         * Create error messages from preparator data
         * @param messages
         */
        createErrorMessages(messages) {
            this.errorMessages.splice(0);
            messages.map(msg => {
                this.errorMessages.push({name: msg.name, rule: msg.rule, condition: false, text: msg.text});
            });
        },
        /**
         * Since our errorMessages array cannot react to $v object changes
         * we must manually refresh its conditions
         */
        refreshErrorMessages() {
            let rules = Object.keys(this.$v.input.content.$params);
            this.errorMessages.map(msg => {
                if (rules.includes(msg.rule)) {
                    msg.condition = !this.$v.input.content[msg.rule] && this.$v.input.content.$dirty
                }
                return msg;
            });
        }
    },
    validations() {
        return this.validationRules;
    }
}
</script>

<style lang="scss" scoped>
.conditional-input-wrapper {
    min-height: 49px;
    position: relative;
}
.multiedit-checkbox {
    margin: auto 0;
}
</style>
