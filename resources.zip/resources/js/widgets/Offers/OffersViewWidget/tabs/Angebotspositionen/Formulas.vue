<template>
    <modal-dialog
        modal-class="formulas-dialog"
        :is-visible="visible"
        @hideModal="hide"
        :title-dialog="info.title"
        :scrollable="true"
        size="lg"
    >
        <div class="simple-box">
            <b-overlay :show="pending">
                <div class="mb-4">{{ info.description }}</div>
                <table v-if="isVisibleItem('ap')" class="table">
                    <tr>
                        <th>Leistungsposition</th>
                        <th>Berechnung</th>
                        <th>Ergebnis</th>
                    </tr>
                    <tr v-for="item in data" :class="{'table-secondary font-weight-bold': item.total}">
                        <td>{{ item.bezeichnung }}</td>
                        <td>{{ item.menge }}</td>
                        <td class="text-nowrap">
                            <template v-if="item.more.length">
                                <a href="#" @click="showLp(item)">{{ item.vollkosten_final }}</a>
                            </template>
                            <template v-else>{{ item.vollkosten_final }}</template>
                        </td>
                    </tr>
                </table>

                <template v-if="isVisibleItem('lp')">
                    <table class="table">
                        <tr>
                            <th>Rechenschritt</th>
                            <th>Berechnung</th>
                            <th>Ergebnis</th>
                        </tr>
                        <tr v-for="item in lp.more" :class="{'table-secondary font-weight-bold': item.total}">
                            <td>{{ item.rechenschritt }}</td>
                            <td v-html="item.berechnung"></td>
                            <td class="text-nowrap">
                                <template v-if="item.more.length">
                                    <a href="#" @click="showEl(item)">{{ item.ergebnis }}</a>
                                </template>
                                <template v-else>{{ item.ergebnis }}</template>
                            </td>
                        </tr>
                    </table>
                </template>

                <template v-if="isVisibleItem('el')">
                    <table class="table">
                        <tr>
                            <th>Rechenschritt</th>
                            <th>Berechnung</th>
                            <th>Ergebnis</th>
                        </tr>
                        <tr v-for="item in el.more" :class="{'table-secondary font-weight-bold': item.total}">
                            <td>{{ item.rechenschritt }}</td>
                            <td v-html="item.berechnung"></td>
                            <td class="text-nowrap">{{ item.ergebnis }}</td>
                        </tr>
                    </table>
                </template>

            </b-overlay>
        </div>
        <template v-slot:footer>
            <button v-if="!isVisibleItem('ap')" @click="changeVisibleItem" class="btn btn-primary">Zurück</button>
            <button @click="hide" class="btn btn-secondary">Schließen</button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {BOverlay} from 'bootstrap-vue';

export default {
    components: {ModalDialog, BOverlay},
    props: {
        simpleId: {
            required: true,
            type: Number
        },
        apId: {
            required: true,
            type: String
        },
        visible: {
            required: true,
            type: Boolean
        },
        item: {
            type: String,
            default: 'ap'
        },
        itemId: {
            default: null
        }
    },
    data() {
        return {
            pending: false,
            data: [],
            ap: null,
            lp: {bezeichnung: null, more: []},
            el: {rechenschritt: null, more: []},
            visibleItem: 'ap'
        }
    },
    computed: {
        info() {
            if (this.visibleItem === 'ap') {
                return {
                    title: 'Formelerklärung Angebotsposition',
                    description: `Die Kosten der Angebotsposition ${this.ap} ergeben sich aus den Summen der enthaltenen Leistungspositionen.`
                }
            }

            if (this.visibleItem === 'lp') {
                return {
                    title: 'Formelerklärung Leistungsposition',
                    description: `Die Kosten der Leistungsposition ${this.lp.bezeichnung} ergeben sich aus den Rechenschritten in der untenstehenden Tabelle. Bitte beachte, dass SIMPLE immer mit allen Nachkommastellen rechnet und für die Anzeige Beträge rundet.`
                }
            }

            if (this.visibleItem === 'el') {
                return {
                    title: 'Formelerklärung Kalkulationselement',
                    description: `Die Kosten des Elements ${this.el.rechenschritt} ergeben sich aus den Rechenschritten in der untenstehenden Tabelle. Bitte beachte, dass SIMPLE immer mit allen Nachkommastellen rechnet und für die Anzeige Beträge rundet.`
                }
            }

            return {
                title: null,
                description: null,
            }
        }
    },
    async mounted() {
        await this.getData();

        this.setVisibleItem(this.item);
        this.goToItem();
    },
    methods: {
        async getData() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/offers/${this.simpleId}/formulas/aps/${this.apId}`);

                this.ap = response.data.ap;
                this.data = response.data.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        hide() {
            this.$emit('hide');
        },
        showLp(item) {
            this.lp = item;

            this.setVisibleItem('lp');
        },
        showEl(item) {
            this.el = item;

            this.setVisibleItem('el');
        },
        isVisibleItem(item) {
            return this.visibleItem === item;
        },
        setVisibleItem(item) {
            this.visibleItem = item;
        },
        changeVisibleItem() {
            if (this.isVisibleItem('lp')) {
                this.setVisibleItem('ap');
            }

            if (this.isVisibleItem('el')) {
                this.setVisibleItem('lp');
            }
        },
        goToItem() {
            if (this.itemId) {
                if (this.visibleItem === 'lp') {
                    const lp = this.data.find(item => item.id == this.itemId);

                    this.showLp(lp);
                }

                if (this.visibleItem === 'el') {
                    const lp = this.data.find(lp => lp.more.find(el => el.id == this.itemId));
                    const el = lp.more.find(el => el.id == this.itemId);

                    this.showEl(el);
                }
            }
        }
    }
}
</script>
