/**
 * Preparators for inputs which need specific logic
 * for getting its data. E.g. getting options for kostenart.
 * Every preparator must return an object {input: {}, validationRules, errorMessages},
 * "input" contains either of these fields: content, options,
 * searchable (or any other field from input{} object in ConditionalInput component)
 * The mandatory arguments of all preparator functions are:
 * "$axios" - the instance of axios from the vuejs component
 */


/**
 * Get the data for kostenstelle select input
 * @param $axios
 * @returns {Promise<{input: {options: [], searchable: boolean}, validationRules: {}, errorMessages: []}>}
 */
const prepareOperator = async ($axios) => {
    let operatorOptions = [
        {id: 'empty', text: ' '}, {id: '+', text: 'Addition'}, {id: '-', text: 'Subtraktion'},
        {id: '*', text: 'Multiplikation'}, {id: '/', text: 'Division'}
    ];

    return {input: {options: operatorOptions, searchable: false}, validationRules: {}, errorMessages: []};
}

export default {
    operator: prepareOperator
};
