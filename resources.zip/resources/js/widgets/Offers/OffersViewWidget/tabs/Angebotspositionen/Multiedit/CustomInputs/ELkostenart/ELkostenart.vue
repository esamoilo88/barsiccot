<template>
    <div>
        <b-overlay :show="pending">
            <div class="kostenart-filter d-flex pb-2">
                <span class="mr-4">Kostenarten filtern:</span>
                <b-form-checkbox-group v-model="zuordnungOptionsSelected">
                    <b-form-checkbox
                        v-for="zuordnung in zuordnungOptions"
                        :key="zuordnung"
                        :value="zuordnung"
                        @change="getKostenartList(true)"
                    >
                        <span>{{ zuordnung }}</span>
                    </b-form-checkbox>
                </b-form-checkbox-group>
            </div>
            <FormSelect
                @input="onSelect"
                :value="kostenart"
                select-id="element-kostenart"
                name="element-kostenart"
                label-text="Kostenart*"
                :options="kostenartOptions"
                searchable
                :error-conditions="[
                    {
                        name: 'empty-kostenart',
                        condition: !$v.kostenart.required  && $v.kostenart.$dirty,
                        text: $t.__('validation.required', {attribute: 'Kostenart'})
                    },
                ]"
            />
        </b-overlay>

        <DependantInputs
            ref="dependantInputs"
            class="mt-3"
            :kostenart-object="kostenartObject"
            @stundensatz-changed="value => (form.stundensatz = value)"
            @gmkz-changed="value => (form.gmkz = value)"
        />
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckboxGroup, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import {mapGetters} from "vuex";
import {createOptions} from "@helpers/Form/InputsHelper";
import {required} from "vuelidate/lib/validators";
import DependantInputs from "./DependantInputs";

export default {
    name: "ELkostenart",
    components: {DependantInputs, BFormCheckboxGroup, BFormCheckbox, BOverlay, FormSelect},
    async mounted() {
        await this.init();
    },
    data() {
        return {
            form: {
                stundensatz: null,
                gmkz: null,
            },
            kostenart: null,
            kostenartObject: null,
            zuordnungOptionsSelected: [],
            zuordnungOptions: [],
            kostenartOptions: [],
            kostenartData: [],
            isAnyDependantInputsErrors: false,
            pending: false,
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
    },
    watch: {
        form: {
            deep: true,
            handler(newValue, oldValue) {
                newValue.kostenart = this.kostenart;
                newValue.kostentyp = this.kostenartObject.kostentype;
                this.$emit('input', newValue);
            }
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.resetValidation();
            this.$refs.dependantInputs.validate();
            this.isAnyDependantInputsErrors = this.$refs.dependantInputs.$v.$anyError;
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
            this.$refs.dependantInputs.$v.$reset();
        },
        /**
         * When kostenart changed emit value to
         * StoreElement component and to Berechnungsart component
         */
        onSelect(value) {
            this.kostenart = value;
            this.kostenartObject = value !== null ? this.kostenartData.filter(k => k.kostenartId == value)[0] : null;
            if (this.kostenart !== null) {
                let form = {...this.form, kostenart: this.kostenart};
                form.kostentyp = this.kostenartObject.kostentype;
                this.$emit('input', form);
            }
        },
        /**
         * Get the list of zuordnung for filtering kostenart
         */
        async getZuordnungList() {
            try {
                let zuordnung = await this.$axios.get(`/offers/costs/kostenart-zuordnung`);
                this.zuordnungOptions.push(...zuordnung.data);
            } catch (err) {
                throw err;
            }
        },
        /**
         * Get the list of kostenart items
         */
        async getKostenartList(withOverlay = false) {
            withOverlay && (this.pending = true);
            this.onSelect(null);
            try {
                let kostenart = await this.$axios.post(`/offers/costs/kostenart`, {
                    fields: ['kostenartId', 'bezeichnung', 'zuordnung', 'kostentyp.bezeichnung AS kostentype', 'gruppe'],
                    filters: {
                        onkaRelevant: 1,
                        zuordnung: this.zuordnungOptionsSelected,
                    }
                });
                this.kostenartOptions.splice(0);
                this.kostenartOptions.push(...createOptions(
                    kostenart.data,
                    (k) => k.kostenartId,
                    (k) => k.zuordnung + ' - ' + k.bezeichnung,
                    'gruppe'
                ));
                this.kostenartData.splice(0);
                this.kostenartData.push(...kostenart.data);
            } catch (err) {
                throw err;
            }
            withOverlay && (this.pending = false);
        },
        /**
         * Initialize kostenart input and filters
         * @returns {Promise<void>}
         */
        async init() {
            this.pending = true;
            try {
                await this.getZuordnungList();
                await this.getKostenartList();
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Error appeared while initializing kostenart input! ", err);
            }
            this.pending = false;
        }
    },
    validations: {
        kostenart: { required },
        isAnyDependantInputsErrors: { isValid: value => !value }
    }
}
</script>

<style lang="scss" scoped>
.kostenart-filter {
    padding-left: 2px;
}
</style>
