<template>
    <b-overlay :show="show" rounded="sm">
        <div class="more-angebote-data py-2">
            <div class="lp-box-wrapper mb-2" v-if="lpData.length > 0">
                <div v-for="lp in mergedObjects" class="lp-box mb-2">
                    <div class="lp_header">
                        <div>
                            {{ lp.lp_info.bezeichnung }}
                        </div>
                        <div>
                            <div class="text-nowrap" v-if="canCreateOrUpdate">
                                <button
                                    class="btn btn-secondary ml-1"
                                    @click="$emit('create-element', lp.lp_info.leistungspositionId)"
                                    title="Neues Element"
                                >
                                    <span class="icon-content-clipboard-default"></span>
                                </button>
                                <button
                                    class="btn btn-secondary ml-1"
                                    @click="$emit('create-ber', {type: 'LP', id: lp.lp_info.leistungspositionId})"
                                    title="Neue Berechnung"
                                >
                                    <span class="icon-function-mathematical-symbol"></span>
                                </button>
                                <button
                                    class="btn btn-secondary ml-1"
                                    @click="$emit('copy-lp', lp.lp_info)"
                                    title="Leistungsposition kopieren"
                                >
                                    <span class="icon-action-copy-paste-default"></span>
                                </button>
                                <button
                                    class="btn btn-secondary ml-1"
                                    @click="$emit('edit-lp', lp)"
                                    title="Leistungsposition bearbeiten"
                                >
                                    <span class="icon-action-edit-default"></span>
                                </button>
                                <button
                                    class="btn btn-secondary ml-1"
                                    @click="deleteLp(lp.lp_info, simpleId, currentVersion)"
                                    title="Leistungsposition löschen"
                                >
                                    <span class="icon-action-remove-default"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="lp_info">
                        <div>Menge: <b>{{ $f.stringToFloat(lp.lp_info.menge) }}</b></div>
                        <div>Inflation Ressourcen: <b>{{
                                $f.numberToString(lp.lp_info.ifWertRessourcen,false,false, '0,00',{maximumFractionDigits: 10})
                            }}</b>
                        </div>
                        <div>Inflation Kosten: <b>{{ $f.numberToString(lp.lp_info.ifWertKosten, false,false, '0,00',{maximumFractionDigits: 10}) }}</b></div>
                        <div>Kosten: <a class="font-weight-bold" @click.stop.prevent="showFormulas(lp.lp_info.leistungspositionId, 'lp')">{{
                                $f.numberToString(lp.lp_info.vollkostenFinal, true, true, '0,00')
                            }}</a>
                        </div>
                        <div>Portfolio: <span class="font-weight-bold">{{ lp.lp_info.portfolio ? lp.lp_info.portfolio.bezeichnung : '-'}}</span>
                        </div>
                        <div>Skill: <span class="font-weight-bold">{{
                                lp.lp_info.skillprofile ? lp.lp_info.skillprofile.name : null
                            }}</span>
                        </div>
                    </div>


                    <div class="elements_list" v-if="lp.lp_info.elements.length > 0 || lp.lp_info.berechnungGrid.length > 0">
                        <table class="w-100">
                            <thead>
                            <tr>
                                <th style="width: 8%">Objekt</th>
                                <th style="width: 40%">Bezeichnung</th>
                                <th style="width: 10%">Wert</th>
                                <th style="width: 10%">Stundensatz</th>
                                <th style="width: 10%">Kosten</th>
                                <th style="width: 10%">Merkmale</th>
                                <th class="optionen-col" style="width: 12%">Optionen</th>
                            </tr>
                            </thead>
                            <tbody>
                                <template v-for="(item, index) in lp.objects" v-if="lp.objects.length > 0">
                                    <!-- EL row -->
                                    <tr v-if="!item.berechnungId" :key="item.elementId">
                                        <td class="pl-0 border-top" v-if="!item.berechnungId">
                                            <span class="icon-content-clipboard-default"></span>
                                            EL
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId">
                                            <ElementData :item="item" />
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId && item.berechnungsart">
                                            {{$f.numberToString(item.wert, true, true)}}
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId && !item.berechnungsart">
                                            {{item.zeitstunden}}
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId">
                                            {{ $f.numberToString(item.stundensatz, true, true) }}
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId">
                                            <a href="#" @click.stop.prevent="showFormulas(item.elementId, 'el')">{{ $f.numberToString(item.vollkosten, true, true) }}</a>
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId">
                                            <div v-if="item.ifApply">
                                                <abbr
                                                    class="badge badge-info"
                                                    :id="getUniqName('ifApply', item.elementId)"
                                                    title="Inflation">
                                                    INF
                                                </abbr>
                                                <b-tooltip :target="getUniqName('ifApply', item.elementId)">
                                                    Inflation
                                                </b-tooltip>
                                            </div>
                                            <div v-if="item.ma" class="mt-1">
                                                <abbr
                                                    class="badge badge-info"
                                                    :id="getUniqName('ma', item.elementId)"
                                                    title="Mengeabhängig">
                                                    MA
                                                </abbr>
                                                <b-tooltip :target="getUniqName('ma', item.elementId)">
                                                    Mengeabhängig
                                                </b-tooltip>
                                            </div>
                                        </td>
                                        <td class="border-top" v-if="!item.berechnungId">
                                            <div v-if="canCreateOrUpdate" class="element-controls">
                                                <button
                                                    class="btn btn-secondary ml-1"
                                                    @click="$emit('create-ber', {type: 'EL', id: item.elementId})"
                                                    title="Neue Berechnung"
                                                >
                                                    <span class="icon-function-mathematical-symbol"></span>
                                                </button>
                                                <button
                                                    class="btn btn-secondary ml-1"
                                                    @click="$emit('edit-element', item)"
                                                    title="Element bearbeiten"
                                                >
                                                    <span class="icon-action-edit-default"></span>
                                                </button>
                                                <button
                                                    class="btn btn-secondary ml-1"
                                                    @click="handleElementRemove(
                                                        simpleId,
                                                        item.elementId,
                                                        item.bezeichnung,
                                                        lp.lp_info.leistungspositionId
                                                    )"
                                                    title="Element löschen"
                                                >
                                                    <span class="icon-action-remove-default"></span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <!-- EL end -->

                                    <!-- EL Berechnung start -->
                                    <tr
                                        is="BerechnungRow"
                                        v-if="item.berechnungId"
                                        :key="item.berechnungId"
                                        :item="item"
                                        :parent-type="'EL'"
                                        :calc-data="berCalcData(
                                            item,
                                            isBerFirst(index, 'el', lp.objects),
                                            item.elementId,
                                            'el'
                                        )"
                                        :can-create-or-update="canCreateOrUpdate"
                                        @edit-ber="onBerEdit"
                                        @delete-ber="ber => deleteBer(ber, simpleId, currentVersion)"
                                    ></tr>
                                    <!-- EL Berechnung end -->
                                </template>

                                <!-- LP Berechnung start -->
                                <tr
                                    is="BerechnungRow"
                                    v-for="(item, index) in lp.lp_info.berechnungGrid"
                                    v-if="lp.lp_info.berechnungGrid"
                                    :key="item.berechnungId"
                                    :item="item"
                                    :parent-type="'LP'"
                                    :calc-data="berCalcData(item, isBerFirst(index, 'lp'), lp.lp_info.leistungspositionId,'lp')"
                                    :can-create-or-update="canCreateOrUpdate"
                                    @edit-ber="onBerEdit"
                                    @delete-ber="ber => deleteBer(ber, simpleId, currentVersion)"
                                ></tr>
                                <!-- LP Berechnung end -->
                            </tbody>
                        </table>
                    </div>
                    <div v-else class="elements_list"><p class="no-data">Keine Elemente vorhanden</p></div>
                </div>
            </div>
            <div v-else-if="!show" class="lp-box"><p class="no-data text-center">Keine Daten vorhanden</p></div>
        </div>
    </b-overlay>
</template>

<script>
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";
import {BSpinner, BTooltip, BOverlay} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import Badge from "@comp/Badge/Badge";
import RemoveElementMxn from "../EL/Remove/RemoveElementMxn";
import RemoveLpMxn from "../LP/RemoveLpMxn";
import RemoveBerMxn from "../BER/RemoveBerMxn";
import {mapGetters, mapState} from "vuex";
import BerechnungRow from './BerechnungRow';
import ElementData from "./ElementData";

export default {
    name: "angebotsposition-details",
    components: {BSpinner, ButtonIcon, Badge, BTooltip, BOverlay, BerechnungRow, ElementData},
    mixins: [ScalarsProcessing, RemoveElementMxn, RemoveLpMxn, RemoveBerMxn],
    props: {
        canCreateOrUpdate: {
            type: Boolean,
            required: true
        },
        request: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            show: false,
            lpData: [],
            berechnungKosten: { el: {}, lp: {} }
        }
    },
    created() {
        this.$eventBus.$on('refreshLPList', this.refreshHandler);
        this.$eventBus.$on('refreshAPList', this.refreshHandler);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshLPList', this.refreshHandler);
        this.$eventBus.$off('refreshAPList', this.refreshHandler);
    },
    async mounted() {
        await this.getData();
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        }),

        mergedObjects() {
            let result = [];
            this.lpData.forEach((lp) => {
                let sumArray = [];
                lp['elements'].forEach((el) => {
                    sumArray.push(...[el, ...el['berechnungGrid']]);
                });
                result.push({
                    'lp_info': lp,
                    'objects': sumArray
                });
            });
            return result;
        }
    },
    methods: {
        async getData() {
            this.show = true;
            try {
                const response = await this.$axios.get('/offers/calculations/aps/'+ this.request.angebotspositionId +'/lps');
                this.lpData = response.data;
            } catch (err) {
                console.log("Couldn't fetch lp data");
            }
            this.show = false;
        },
        /**
         * Use synchronous handler for eventBus, otherwise it
         * cannot remove event handler after component is destroyed
         */
        refreshHandler() {
            this.getData().then();
        },
        /**
         * Define the position of berechnung regarding its parent element
         * @param index
         * @param parentType - either 'lp' or 'el'
         * @param objectsArray - array for EL's berechnungsart
         */
        isBerFirst(index, parentType, objectsArray = []) {
            if (parentType === 'lp') {
                return index === 0;
            } else if (parentType === 'el') {
                let previousObj = objectsArray[index-1];
                return previousObj.berechnungId === undefined;
            }
        },
        /**
         * Get initial vollkosten for BER and the result after BER is applied
         * @param item
         * @param isFirst
         * @param objId
         * @param objType
         * @returns {{result: *, initial: *}}
         */
        berCalcData(item, isFirst, objId, objType) {
            let operator   = item.operator;
            let wert       = item.wert;
            let vollkosten = item.vollkosten;
            if (isFirst) {
                this.berechnungKosten[objType][objId] = [];
                this.berechnungKosten[objType][objId].unshift(this.getSumVollkosten(operator, wert, vollkosten));
                return {initial: vollkosten, result: this.berechnungKosten[objType][objId][0]};
            } else {
                let previousVollkosten = this.berechnungKosten[objType][objId][0];
                this.berechnungKosten[objType][objId].unshift(this.getSumVollkosten(operator, wert, previousVollkosten));
                return {initial: previousVollkosten, result: this.berechnungKosten[objType][objId][0]};
            }
        },
        getSumVollkosten(operator, wert, vollkosten) {
            wert = (wert) ? parseFloat(wert) : 0;
            vollkosten = (vollkosten) ? parseFloat(vollkosten) : 0;
            switch (operator) {
                case '+':
                    vollkosten += wert;
                    break;
                case '-':
                    vollkosten -= wert;
                    break;
                case '*':
                    vollkosten *= wert;
                    break;
                case '/':
                    if (wert !== 0) {
                        vollkosten /= wert;
                    }
                    break;
            }
            return vollkosten;
        },
        getUniqName(name, id) {
            return `${name}_${id}`;
        },
        async handleElementRemove(simpleId, elementId, bezeichnung, lpId) {
            try {
                await this.onElementRemove(simpleId, elementId, bezeichnung);
                await this.postRemoveElement(this.lpData, lpId, elementId);
            } catch (err) {}
        },
        /**
         * Pass emitted event up to parent
         * @param item
         */
        onBerEdit(item) {
            this.$emit('edit-ber', item);
        },
        showFormulas(itemId, item) {
            this.$eventBus.$emit('showFormulas', {apId: this.request.angebotspositionId, itemId: itemId, item: item})
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/lpTable';
.element-controls {
    min-width: 148px;
}

.optionen-col {
    min-width: 120px;
}
</style>
