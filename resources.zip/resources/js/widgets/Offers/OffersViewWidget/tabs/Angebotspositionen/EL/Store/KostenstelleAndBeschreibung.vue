<template>
    <div>
        <FormSelect
            @input="value => $emit('kostenstelle-changed', value)"
            @select="val => $emit('change', {field: 'kostenstelle', value: val})"
            :value="kostenstelle"
            select-id="element-kostenstelle"
            name="element-kostenstelle"
            label-text="Kostenstelle"
            :options="kostenstelleOptions"
            searchable
        />
        <div class="text-muted mt-1 mb-4 pl-1">
            Die Kostenstelle kann ausgewählt werden um die kalkulierten Kosten im Falle einer
            automatischen Plan-ILV auf die ausgewählte Teamkostenstelle zu buchen.
        </div>

        <FormTextArea
            input-id="element-beschreibung"
            name="element-beschreibung"
            label-text="Tätigkeitsbeschreibung"
            :value="beschreibung"
            @handleTextArea="value => $emit('beschreibung-changed', value)"
            @change="val => $emit('change', {field: 'beschreibung', value: val})"
        />
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import Kostenstelle from "@mixins/Kostenstelle/Kostenstelle";

export default {
    name: "KostenstelleAndBeschreibung",
    components: {FormTextArea, FormSelect},
    mixins: [Kostenstelle],
    props: {
        elementToUpdate: {
            type: Object,
            required: false,
            default: null
        }
    },
    async created() {
        this.$eventBus.$on('setElementFormValues', this.setValues);
        await this.fetchKostenstelleData();
        this.elementToUpdate !== null && this.setValues(this.elementToUpdate);
    },
    beforeDestroy() {
        this.$eventBus.$off('setElementFormValues', this.setValues);
    },
    data() {
        return {
            kostenstelle: null,
            beschreibung: null,
        }
    },
    methods: {
        setValues(element) {
            this.kostenstelle = element.kostenstelle !== null ? element.kostenstelle.kostenstelleId : null;
            this.beschreibung = element.beschreibung;
        }
    }
}
</script>

<style scoped></style>
