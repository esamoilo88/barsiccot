<template>
    <div id="ap-index">
        <TopButtons
            v-if="canCreateOrUpdate"
            :can-create="canCreateOrUpdate"
            @ap-create="showCreateModal"
            @el-create="isELFormActive=true"
            @lp-create="isCreatingLP=true"
            @ber-create="createBER"
            @multiedit="isMultiediting=true"
            @copy-onka="isCopyOnka=true"
            @lotex-import="isImportLotex=true"
            @activate-drag-n-drop="activateDragAndDrop"
            @deactivate-drag-n-drop="saveSorting"
            :is-extended="isExtended"
            @collapse-extend="collapseExtend"
            @search-ap="handleSearchAp"
        />

        <table-simple
            v-if="!isImportLotex"
            table-id="angebotspositionen-table"
            :fields="fields"
            :filters="[]"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="getData"
            ref="table"
            class="shadow-none mt-2"
            primary-key="angebotspositionId"
            :draggable-rows="isDraggable"
            @drag-ended="setReorderedItems"
            :per-page-variants="perPageVariants"
            @per-page-changed="val => perPage = val"
        >
            <template #head(vollkostenGesamt)="row">
                <div class="d-flex flex-column my-1 text-monospace text-right">
                    <span class="text-muted">Stückkosten</span>
                    <span>Gesamtkosten</span>
                </div>
            </template>

            <template #head(einzelpreisDttsGesamt)="row">
                <div class="d-flex flex-column my-1 text-monospace text-right">
                    <span class="text-muted">Stückpreis</span>
                    <span>Gesamtpreis</span>
                </div>
            </template>

            <template #head(menge)="row">
                <div class="text-right"><span>Menge</span></div>
            </template>

            <template #head(marge_eff)="row">
                <div class="text-monospace text-right"><span>Marge (eff)</span></div>
            </template>

            <template #cell(drag)="data">
                <span v-if="isDraggable" class="icon-action-move-default drag-handle"></span>
            </template>

            <template #cell(sort)="data">
                <span :class="{'font-weight-bold': data.item.isHeadline}">{{ data.item.sort }}</span>
            </template>

            <template #cell(bezeichnung)="data">
                <span :class="{'font-weight-bold': data.item.isHeadline}">{{ data.item.bezeichnung }}</span>
            </template>

            <template #cell(menge)="data">
                <div class="d-flex flex-column text-right" v-if="!data.item.isHeadline">
                    <span>{{ data.item.menge }}</span>
                    <span class="text-muted">{{ data.item.mengentypBezeichnung }}</span>
                </div>
            </template>

            <template #cell(vollkostenGesamt)="data">
                <div v-if="!data.item.isHeadline" class="d-flex flex-column text-monospace text-right">
                    <div>
                        <span class="sr-only">Stückkosten:</span>
                        <span class="text-muted">{{ $f.numberToString(data.item.stueckkosten, true, false, '0,00', {maximumFractionDigits: 2, minimumFractionDigits: 2}) }}</span>
                    </div>
                    <div>
                        <span class="sr-only">Gesamtkosten:</span>
                        <a href="#" @click.stop.prevent="showFormulas(data.item.angebotspositionId)">
                            {{ $f.numberToString(data.item.vollkostenGesamt, true, false, '0,00', {maximumFractionDigits: 2, minimumFractionDigits: 2}) }}
                        </a>
                    </div>
                </div>
            </template>

            <template #cell(einzelpreisDttsGesamt)="data">
                <div v-if="!data.item.isHeadline" class="d-flex flex-column text-monospace text-right">
                    <div>
                        <span class="sr-only">Stückpreis:</span>
                        <span class="text-muted">{{ $f.numberToString(data.item.unitPriceTp2, true, false, '0,00', {maximumFractionDigits: 2, minimumFractionDigits: 2}) }}</span>
                    </div>
                    <div>
                        <span class="sr-only">Gesamtpreis:</span>
                        {{ $f.numberToString(data.item.totalPriceTp2, true, false, '0,00', {maximumFractionDigits: 2, minimumFractionDigits: 2}) }}
                    </div>
                </div>
            </template>

            <template #cell(marge_eff)="data">
                <div class="text-right">
                    <span
                        v-if="!data.item.isHeadline"
                        class="text-monospace"
                        :class="getMEStyle(data.item.marginEffective)">
                        {{ $f.numberToString(data.item.marginEffective, false, false, '0,00', {maximumFractionDigits: 2, minimumFractionDigits: 2}) }}%
                    </span>
                </div>
            </template>

            <template #cell(merkmale)="data">
                <template v-if="!data.item.isHeadline">
                    <template v-for="merkmal in merkmale">
                        <template v-if="data.item[merkmal.key]">
                            <span
                                :class="merkmal.class"
                                :id="getUniqName(merkmal.key, data.item)"
                                :title="merkmal.title"
                            ></span>
                            <b-tooltip :target="getUniqName(merkmal.key, data.item)">
                                {{ merkmal.title }}
                            </b-tooltip>
                        </template>
                    </template>
                </template>
            </template>

            <template #cell(options)="data">
                <div class="text-nowrap text-right">
                    <button
                        v-if="!data.item.isHeadline"
                        :disabled="isDraggable"
                        class="btn btn-primary details_class"
                        @click="toggleRowAnyway(data.item, 'angebotspositionId')"
                        :title="data.item._showDetails ? 'Schließen Details zu dieser Angebot':'Zeigen Details zu dieser Angebot'"
                    >
                        Details
                    </button>
                    <template v-if="canCreateOrUpdate">
                        <button
                            class="btn btn-secondary"
                            title="Angebotsposition bearbeiten"
                            @click="showUpdateModal(data.item)"
                        >
                            <span class="icon-action-edit-default"></span>
                        </button>
                        <button
                            class="btn btn-secondary"
                            title="Angebotsposition löschen"
                            @click="deleteAp(data.item)"
                            :button-id="'deleteApButton-' + data.item.angebotspositionId"
                        >
                            <span class="icon-action-remove-default"></span>
                        </button>
                    </template>
                </div>
            </template>
            <template #row-details="data">
                <div class="d-flex">
                    <QuickViewSlot class="quickview" :key="data.item.angebotspositionId">
                        <AngebotspositionDetails
                            :view-type="viewType"
                            :ap="data.item"
                            :can-create-or-update="canCreateOrUpdate"
                            @edit-element="onElementUpdate"
                            @create-element="onElementCreate"
                            @create-ber="obj => createBER(obj.type, obj.id)"
                            @edit-ber="ber => updateBER(ber)"
                            @edit-lp="updateLP"
                            @copy-lp="copyLp"
                            @copy-ap="copyAp(data.item.angebotspositionId)"
                        />
                    </QuickViewSlot>
                </div>
            </template>
        </table-simple>

        <StoreElement
            v-if="isELFormActive"
            :is-visible="isELFormActive && canCreateOrUpdate"
            :can-create-element="canCreateOrUpdate"
            :element-to-update="elementToUpdate"
            :parent-lp-id="parentLpId"
            :is-single-create="parentLpId !== null"
            @close-store-element-modal="isELFormActive = false; elementToUpdate = null"
            @updated="elementToUpdate=null"
        />

        <StoreLP
            v-if="isCreatingLP"
            :is-visible="isCreatingLP && canCreateOrUpdate"
            :canCreateLp="canCreateOrUpdate"
            @close-create-lp-modal="isCreatingLP = false"
        />

        <UpdateLP
            ref="updateLP"
            v-if="canCreateOrUpdate && isUpdatingLP"
            :item="lpToUpdate"
            :visible="isUpdatingLP"
            @close-update-lp-modal="isUpdatingLP = false"
        />
        <CopyLP
            ref="copyLP"
            v-if="canCreateOrUpdate && isCopyLP"
            :lp-data="lpToCopy"
            :is-visible="isCopyLP"
            :canCopyLp="canCreateOrUpdate"
            @close-copy-lp-modal="closeCopyModal"
        />

        <StoreBER
            v-if="isBERFormActive"
            :is-visible="isBERFormActive && canCreateOrUpdate"
            :target="berTargetObj"
            :can-create-ber="canCreateOrUpdate"
            :ber-to-update="berToUpdate"
            @close-store-ber-modal="closeBERDialog"
            @updated="berToUpdate=null"
        />

        <MultieditDialog
            v-if="isMultiediting"
            :is-visible="isMultiediting && canCreateOrUpdate"
            :has-rights="canCreateOrUpdate"
            @close-onka-multiedit-modal="isMultiediting = false"
        />

        <CopyOnka
            v-if="isCopyOnka"
            :is-visible="isCopyOnka && canCopyOnka"
            :can-copy-onka="canCopyOnka"
            @close-copy-onka-modal="isCopyOnka = false"
            :target-sin="offer.globalGate.simpleId"
        />
        <LotexImport v-if="isImportLotex" @close-import-lotex="isImportLotex = false" />

        <Manage ref="manage" @submit="updateData"/>

        <template v-if="formulas.apId">
            <Formulas
                :ap-id="formulas.apId"
                :simple-id="offer.globalGate.simpleId"
                :visible="formulas.visible"
                :item="formulas.item"
                :item-id="formulas.itemId"
                @hide="hideFormulas"
            />
        </template>

        <template v-if="copyApId">
            <CopyApDialog :ap-id="copyApId" :show="showCopyApDialog" @hide="hideCopyApDialog"/>
        </template>
    </div>
</template>

<script>
import AngebotspositionDetails from "./APDetails/AngebotspositionDetails";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import QuickViewMixin from "res/js/utils/Mixins/QuickView/QuickViewMixin";
import Manage from './Manage';
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import {mapGetters, mapState} from "vuex";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {BButton, BTooltip, BOverlay, VBTooltip} from 'bootstrap-vue';
import TableSimple from '@comp/TableSimple/TableSimple';
import LoadingWholePage from "@comp/DynamicImportHelpers/LoadingWholePage";
import TopButtons from "./TopButtons";
import BERMxn from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebotspositionen/BER/BERMxn";
import StoreElementMxn from "./EL/Store/StoreElementMxn";
import {getUserPreferences} from "@helpers/SimpleBussiness/UserPreferences/userPreferences";
import Formulas from "./Formulas";
import CopyApDialog from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebotspositionen/CopyApDialog";

const StoreElement = () => ({loading: LoadingWholePage, component: import('./EL/Store/StoreElement'), delay: 0});
const StoreBER = () => ({loading: LoadingWholePage, component: import('./BER/Store/StoreBER'), delay: 0});
const StoreLP = () => ({loading: LoadingWholePage, component: import('./LP/Store/StoreLP'), delay: 0});
const MultieditDialog = () => ({loading: LoadingWholePage, component: import('./Multiedit/MultieditDialog'), delay: 0});
const UpdateLP = () => ({loading: LoadingWholePage, component: import('./LP/Update/UpdateLP'), delay: 0});
const CopyLP = () => ({loading: LoadingWholePage, component: import('./LP/Copy/CopyLP'), delay: 0});
const CopyOnka = () => ({loading: LoadingWholePage, component: import('./CopyKalkulation/CopyOnka'), delay: 0});
const LotexImport = () => ({ loading: LoadingWholePage, component: import('./LotexImport/LotexImport'), delay: 0 });

export default {
    name: 'AngebotspositionenIndex',
    components: {
        LotexImport, TopButtons, StoreElement, StoreBER, StoreLP, CopyLP, ButtonIcon, BTooltip, TableSimple, BButton, BOverlay,
        Manage, AngebotspositionDetails, QuickViewSlot, MultieditDialog, UpdateLP, CopyOnka, Formulas, CopyApDialog
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    mixins: [ConfirmationModal, QuickViewMixin, BERMxn, StoreElementMxn],
    data() {
        return {
            data: [],
            producttypes: [],
            fields: [
                {key: 'drag', label: '', class: 'drag-col'},
                {key: 'sort', label: 'Nr', sortable: true, sortKey: 'sort', class: 'sort-col'},
                {key: 'bezeichnung', label: 'Angebotsposition', sortable: true, sortKey: 'bezeichnung', class: 'bezeichnung-col'},
                {key: 'menge', label: 'Menge', sortable: true, sortKey: 'menge', class: 'menge-col'},
                {key: 'vollkostenGesamt', label: 'Kosten', sortable: true, sortKey: 'vollkostenGesamt', class: 'vollkosten-col'},
                {key: 'einzelpreisDttsGesamt', label: 'Preis', sortable: true, sortKey: 'einzelpreisDttsGesamt', class: 'einzelpreis-col'},
                {key: 'marge_eff', label: 'Marge (eff)', class: 'marge-col'},
                {key: 'merkmale', label: 'Merkmale', class: 'merkmale-col'},
                {key: 'options', label: 'Optionen', class: 'optionen-col'},
            ],
            sortBy: 'sort',
            sortDesc: false,
            totalRows: 0,
            perPage: 0,
            perPageVariants: [20, 40, 60, 80, 100, -1],
            merkmale: [
                {
                    title: 'Optional',
                    key: 'optional',
                    class: 'icon-alert-help-default'
                },
                {
                    title: 'Beauftragt',
                    key: 'beauftragt',
                    class: 'icon-alert-compliance-default text-info'
                },
                {
                    title: 'Gesperrt',
                    key: 'deaktiviert',
                    class: 'icon-content-lock-default text-danger'
                },
                {
                    title: 'Monatlich wiederholend',
                    key: 'recurrentPayment',
                    class: 'icon-action-loop-default'
                }
            ],
            isELFormActive: false,
            isImportLotex: false,
            elementToUpdate: null,
            isMultiediting: false,
            isCreatingLP: false,
            isUpdatingLP: false,
            isCopyLP: false,
            lpToUpdate: null,
            lpToCopy: null,
            isCopyOnka: false,
            reorderedItems: {},
            startSortIndex: null,
            isDraggable: false,
            pending: false,
            formulas: {
                apId: null,
                visible: false,
                item: 'ap',
                itemId: null
            },
            isExtended: false,
            apData: {},
            copyApId: null,
            showCopyApDialog: false,
            viewType: 'calculation-mode'
        }
    },
    async created() {
        this.$eventBus.$on('configurationAssumed', async () => await this.updateData());
        this.$eventBus.$on('refreshAPList', async () => await this.updateData());
        this.$eventBus.$on('showFormulas', (data) => this.showFormulas(data.apId, data.item, data.itemId));

        let userPreferences = getUserPreferences();
        this.perPage = userPreferences && userPreferences['base-per-page'] ? Number(userPreferences['base-per-page'].value) : 20;
        this.viewType = userPreferences && userPreferences['ap-details-viewtype'] ? userPreferences['ap-details-viewtype'].value : 'calculation-mode';
    },
    beforeDestroy() {
        this.$eventBus.$off('configurationAssumed', async () => await this.updateData());
        this.$eventBus.$off('refreshAPList', async () => await this.updateData());
        this.$eventBus.$off('showFormulas');
    },
    async mounted() {
        await this.getProducttypes();
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        }),
        canCreateOrUpdate() {
            return this.offer.is_onka_writable && (
                this.offer.user.isAdmin
                || this.offer.user.userRoles.includes('TK')
                || this.offer.user.userRoles.includes('AE')
            )
        },
        canCopyOnka() {
            return this.offer.is_onka_writable && (
                this.offer.user.isAdmin || this.offer.user.userRoles.includes('AE')
            )
        },
    },
    methods: {
        async updateData() {
            await this.$refs.table.manualCtxTrigger();
        },
        async handleSearchAp(data) {
            this.pending = true;
            let ctx = this.$refs.table.getContext();
            ctx.filter === undefined && (ctx.filter = {});
            ctx.filter['search'] = data;
            ctx.isCustomFilter = true;
            await this.$refs.table.handleCtxChange(ctx);
            this.pending = false;
        },
        async getData(ctx) {
            try {
                const simpleId = this.offer.globalGate.simpleId;

                const response = await this.$axios.get(`/offers/${simpleId}/calculations/aps/${this.currentVersion}`, {
                    params: {
                        currentPage: ctx.currentPage,
                        sortBy: ctx.sortBy,
                        sortDesc: ctx.sortDesc ? 1 : 0,
                        perPage: this.perPage,
                        'filter[search]': ctx.filter.search,
                        'filter[optional]': ctx.filter.optional,
                        'filter[nachAufwand]': ctx.filter.nachAufwand,
                        'filter[produkttyp]': ctx.filter.produkttyp,
                    }
                });

                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                this.apData = this.insertShowDetailsField(response.data.data, 'angebotspositionId');
                return this.apData;
            } catch (error) {
                return []
            }
        },
        getUniqName(name, item) {
            return `${name}_${item.angebotspositionId}`;
        },
        getMEStyle(value) {
            if (value > 0) {
                return 'text-success';
            }

            if (value < 0) {
                return 'text-danger';
            }
        },
        showCreateModal() {
            this.$refs.manage.clearForm();
            this.$refs.manage.showModal();
        },
        showUpdateModal(item) {
            this.$refs.manage.setForm(item);
            this.$refs.manage.showModal();
        },
        onElementEdit(element) {
            this.isELFormActive = true;
            this.elementToUpdate = element;
        },
        async deleteAp(ap) {
            const result = await this.showConfirmationModal({
                title: 'Angebotsposition löschen',
                message: `Bitte bestätige die Löschung der Angebotsposition ${ap.bezeichnung}.`,
                size: 'md',
                okTitle: 'Löschen',
                cancelTitle: 'Abbrechen',
                okVariant: 'danger'
            });

            if (!result) return;

            try {
                const simpleId = this.offer.globalGate.simpleId
                const response = await this.$axios.delete(`/offers/${simpleId}/aps/${ap.angebotspositionId}`);
                window.flash.showMessagesFromAjax(response.data);
                await this.updateData();
                this.$eventBus.$emit('offerHeaderUpdate');
                document.querySelector('[id*="deleteApButton-"]').focus();
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
        },
        updateLP(item) {
            this.lpToUpdate = item;
            this.isUpdatingLP = true;
        },
        copyLp(lp) {
            this.lpToCopy = lp;
            this.isCopyLP = true;
        },
        activateDragAndDrop() {
            this.$refs.table.items.map(i => {
                if (i._showDetails) {
                    this.toggleRowAnyway(i, 'angebotspositionId');
                }
            });
            this.startSortIndex = this.$refs.table.items[0].sort;
            this.isDraggable = true;
        },
        async saveSorting() {
            window.preloader.show();
            try {
                const simpleId = this.offer.globalGate.simpleId;
                const res = await this.$axios.post(`/offers/${simpleId}/aps/save-sorting`, {aps: this.reorderedItems});
                window.flash.showMessagesFromAjax(res.data);
                this.refreshClientSort();
            } catch (err) {
                this.$refs.table.manualCtxTrigger();
                console.log("Couldn't save sorting! Err:", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            window.preloader.hide();
            this.reorderedItems = {};
            this.isDraggable = false;
        },
        refreshClientSort() {
            this.$refs.table.items.map(el => {
                if (this.reorderedItems[el.angebotspositionId]) {
                    el.sort = this.reorderedItems[el.angebotspositionId];
                }
            });
        },
        setReorderedItems() {
            this.$refs.table.items.map((el, index) => {
                if (el.sort != this.startSortIndex + index) {
                    this.reorderedItems[el.angebotspositionId] = this.startSortIndex + index;
                } else if (this.reorderedItems[el.angebotspositionId]) {
                    delete this.reorderedItems[el.angebotspositionId];
                }
            });
        },
        async getProducttypes() {
            this.pending = true;

            try {
                const response = await this.$axios.get(`/onka/producttypes`);

                this.producttypes = response.data;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }

            this.pending = false;
        },
        showFormulas(apId, item = 'ap', itemId = null) {
            this.formulas.apId = apId;
            this.formulas.item = item;
            this.formulas.itemId = itemId;
            this.formulas.visible = true;
        },
        hideFormulas() {
            this.formulas.apId = null;
            this.formulas.item = 'ap';
            this.formulas.itemId = null;
            this.formulas.visible = false;
        },
        collapseExtend() {
            if (this.apData.length > 100) {
                window.flash.info('Die Anzahl der Angebotspositionen ist zu hoch - die Funktion kann nicht ausgeführt werden.');
                return;
            }
            this.toggleAllRows(this.apData, 'angebotspositionId', !this.isExtended)

            this.isExtended = !this.isExtended;
        },
        closeCopyModal() {
            this.isCopyLP = false;
            this.lpToCopy = null;
        },
        copyAp(apId) {
            this.copyApId = apId;
            this.showCopyApDialog = true;
        },
        hideCopyApDialog() {
            this.copyApId = null;
            this.showCopyApDialog = false;
        }
    }
}
</script>
<style lang="scss" scoped>
.quickview {
    min-height: 75px;
    width: 100%;
    background-color: white;
}
::v-deep .drag-col {
    width: 1%;
}
::v-deep .sort-col {
    width: 4%;
}
::v-deep .bezeichnung-col {
    width: 40%;
}
::v-deep .menge-col {
    width: 7%;
}
::v-deep .vollkosten-col {
    width: 10%;
}
::v-deep .einzelpreis-col {
    width: 10%;
}
::v-deep .marge-col {
    width: 10%;
}
::v-deep .merkmale-col {
    width: 10%;
}
::v-deep .optionen-col {
    width: 8%;
}

</style>
