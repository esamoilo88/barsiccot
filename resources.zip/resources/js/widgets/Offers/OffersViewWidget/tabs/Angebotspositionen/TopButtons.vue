<template>
    <div class="d-flex justify-content-between">
        <div id="sticky-buttons" :class="{'fixed-container': sticky}">
            <b-dropdown @click="$emit('ap-create')" class="create-buttons mr-2" variant="primary" right split>
                <template #button-content><span class="icon-action-add-default pr-2"></span>Neue Angebotsposition</template>
                <b-dropdown-item-button class="d-flex" @click="$emit('lp-create')">
                    <span class="icon-action-add-default pr-2"></span>
                    Neue Leistungspositionen
                </b-dropdown-item-button>

                <template v-if="!forKatalog">
                    <b-dropdown-item-button @click="$emit('el-create')" class="d-flex">
                        <span class="icon-action-add-default pr-2"></span>
                        Neue Elemente
                    </b-dropdown-item-button>
                    <b-dropdown-item-button @click="$emit('ber-create')" class="d-flex">
                        <span class="icon-action-add-default pr-2"></span>
                        Neue Berechnungen
                    </b-dropdown-item-button>
                    <b-dropdown-divider></b-dropdown-divider>
                    <b-dropdown-item-button @click="$emit('kosten-create')" class="d-flex">
                        <span class="icon-action-add-default pr-2"></span>
                        Neue indirekte Kosten
                    </b-dropdown-item-button>
                </template>
            </b-dropdown>

            <b-dropdown
                v-if="!forKatalog"
                title="Importieren"
                class="upload-options mr-2 btn-icon"
                v-b-tooltip.hover
                no-caret
            >
                <template #button-content class="d-flex">
                    <span class="icon-action-upload-default align-self-center"></span>
                </template>
                <b-dropdown-item-button>
                    <span class="icon-action-upload-default pr-2"></span>
                    Exceldaten importieren
                </b-dropdown-item-button>
                <b-dropdown-item-button @click="$emit('copy-onka')">
                    <span class="icon-action-upload-default pr-2"></span>
                    Kalkulation importieren
                </b-dropdown-item-button>
                <b-dropdown-item-button @click="$emit('lotex-import')">
                    <span class="icon-action-upload-default pr-2"></span>
                    Lotex-Import
                </b-dropdown-item-button>
            </b-dropdown>

            <b-dropdown
                v-if="!forKatalog"
                title="Weitere Optionen"
                class="more-options btn-icon"
                v-b-tooltip.hover
                no-caret
            >
                <template #button-content class="d-flex">
                    <span class="icon-action-more-default align-self-center" ref="moreBtn"></span>
                </template>
                <b-dropdown-item-button @click="$emit('multiedit')">
                    <span class="icon-action-edit-default pr-2"></span>
                    Mehrfachänderung
                </b-dropdown-item-button>
                <MultiDelete @onClose="onCloseModal" />
                <b-dropdown-divider></b-dropdown-divider>
                <b-dropdown-item-button v-if="!isDraggable" @click="isDraggable = true; $emit('activate-drag-n-drop')">
                    <span class="icon-action-drag-and-drop-default pr-2"></span>
                    Angebotspositionen verschieben
                </b-dropdown-item-button>
                <b-dropdown-item-button v-else @click="isDraggable = false; $emit('deactivate-drag-n-drop')">
                    <span class="icon-action-drag-and-drop-default pr-2"></span>
                    Sortierung speichern
                </b-dropdown-item-button>
                <b-dropdown-item-button @click="$emit('collapse-extend')">
                    <span class="icon-action-changelog-default pr-2"></span>
                    {{ isExtended ? 'Alle Angebotspositionen einklappen' : 'Alle Angebotspositionen ausklappen' }}
                </b-dropdown-item-button>
            </b-dropdown>
        </div>

        <FormInput
            name="search-filter"
            label-text="Suchen"
            input-id="search-filter-input"
            v-debounce:600ms="value => $emit('search-ap', value)" debounce-events="input"
        />
    </div>
</template>

<script>
import {BDropdown, BDropdownDivider, BDropdownItemButton, VBTooltip} from 'bootstrap-vue';
import MultiDelete from './MultiDelete';
import FormInput from "@comp/FormInput/FormInput";
import vueDebounce from 'vue-debounce';
import Vue from "vue";

Vue.use(vueDebounce);

export default Vue.extend({
    name: "TopButtons",
    components: {BDropdown, BDropdownDivider, BDropdownItemButton, MultiDelete, FormInput},
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        canCreate: {
            type: Boolean,
            required: true,
            default: false
        },
        isExtended: {
            type: Boolean,
            required: true,
            default: false
        },
        forKatalog: {
            type: Boolean,
            default: false
        }
    },
    mounted() {
        const fixTopButtons = () => {
            let controls = document.getElementById('sticky-buttons');
            let apIndex = document.getElementById('ap-index');
            this.sticky = window.scrollY > apIndex.offsetTop;
            let rect = apIndex.getBoundingClientRect();
            if (this.sticky) {
                controls.style.marginLeft = rect.x + 'px';
                controls.style.width = rect.width + 'px';
            } else {
                controls.style.marginLeft = '';
                controls.style.width = '';
            }
        };
        window.document.onscroll = fixTopButtons;
        if (window.afterSidebarChanged !== undefined) {
            window.afterSidebarChanged.push(fixTopButtons);
        } else {
            window.afterSidebarChanged = []
            window.afterSidebarChanged.push(fixTopButtons);
        }
    },
    data() {
        return {
            isDraggable: false,
            sticky: false,
            startTop: null
        }
    },
    methods: {
        onCloseModal() {
            this.$refs.moreBtn.parentElement.focus();
        }
    }
});
</script>

<style lang="scss" scoped>
.fixed-container {
    left: 0 !important;
    transform: none !important;
}

::v-deep .create-buttons button:not([aria-expanded]) {
    display: flex;
}

::v-deep .more-options button {
    display: flex;

    .icon-action-more-default {
        font-size: 21px;
    }
}

::v-deep .create-buttons .btn.btn-primary {
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
