<template>
    <div>
        <b-overlay :show="pending">
            <div class="inputs-list d-flex">
                <FormSelect
                    v-model="stundensatzIdSelected"
                    @input="onStundensatzSelect"
                    class="element-stundensatz mr-3"
                    select-id="element-stundensatz"
                    name="stundensatz"
                    label-text="Stundensatz*"
                    :options="stundensatzOptions"
                    :error-conditions="[
                        {
                            name: 'empty-stundensatz',
                            condition: !$v.form.stundensatz.required  && $v.form.stundensatz.$dirty,
                            text: $t.__('validation.required', {attribute: 'Stundensatz'})
                        },
                    ]"
                />

                <FormInputAppend
                    v-model="form.gmkz"
                    @input="value => $emit('gmkz-changed', value)"
                    @submit="$emit('submit')"
                    class="element-gmkz"
                    input-id="element-gmkz"
                    name="gmkz"
                    label-text="GMKZ"
                    prepend="%"
                    :disabled="kostentype === 'Ressourcen'"
                    :error-conditions="[
                        {
                            name: 'invalid-number',
                            condition: !$v.form.gmkz.decimal  && $v.form.gmkz.$dirty,
                            text: $t.__('validation.numeric', {attribute: 'GMKZ'})
                        }
                    ]"
                />
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {
    BOverlay, BFormGroup, BFormRadioGroup,
    BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
} from 'bootstrap-vue';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {isEmpty} from "@helpers/ValueProcessing/ScalarProcessing";
import {required, requiredIf} from 'vuelidate/lib/validators';
import {
    aufwandHourValidator,
    aufwandMinuteValidator, aufwandSecondValidator
} from "res/js/utils/Validators/SimpleCommonValidators";

export default {
    name: "DependantInputs",
    components: {
        FormSelect, FormInputAppend, BOverlay, BFormGroup,
        BFormRadioGroup, BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
    },
    props: {
        kostenartObject: {
            type: Object,
            required: false
        }
    },
    data() {
        return {
            kostentype: null,
            form: {
                stundensatz: null,
                gmkz: null
            },
            stundensatzIdSelected: null,
            stundensatzData: [],
            pending: false
        }
    },
    watch: {
        kostenartObject(newValue, oldvalue) {
            this.onKostenartChanged(newValue);
        }
    },
    computed: {
        stundensatzOptions() {
            return this.stundensatzData.map(st => ({id: st.id, text: st.stundensatz}));
        }
    },
    methods: {
        /**
         * Fetch necessary data when kostenart is changed
         */
        async onKostenartChanged(kostenart) {
            this.pending = true;
            this.$v.$reset();
            if (!isEmpty(kostenart)) {
                this.kostentype = kostenart.kostentype;
                this.form.zeitstunden = this.kostentype === 'Kosten' ? null : this.form.zeitstunden;
                this.form.wert = this.kostentype === 'Ressourcen' ? null : this.form.wert;

                await this.getStundensatzData(kostenart.kostenartId);
                this.stundensatzIdSelected = this.stundensatzData[0].id;
                this.onStundensatzSelect(this.stundensatzIdSelected);
            } else {
                this.kostentype = null;
                this.stundensatzIdSelected = null;
                this.stundensatzData.splice(0);
                this.form.zeitstunden = null;
                this.form.stundensatz = null;
                this.form.gmkz = null;
            }
            this.pending = false;
        },
        /**
         * @param kostenartId
         */
        async getStundensatzData(kostenartId) {
            try {
                let res = await this.$axios.get(`/offers/calculations/els/on-kostenart-change/${kostenartId}`);
                this.stundensatzData.splice(0);
                this.stundensatzData.push(...res.data);
            } catch (err) {
                console.error("Couldn't fetch new data for changed kostenart", err);
            }
        },
        /**
         * Emit event to StoreComponent when Stundensatz is changed
         */
        onStundensatzSelect(stundensatzId) {
            if (!isEmpty(stundensatzId)) {
                let st = this.stundensatzData.filter(st => st.id == stundensatzId)[0];
                this.form.stundensatz = st.stundensatz;
                this.form.gmkz = st.gmkz;
            } else {
                this.form.stundensatz = null;
                this.form.gmkz = null;
            }
            this.$emit('stundensatz-changed', this.form.stundensatz);
            this.$emit('gmkz-changed', this.form.gmkz);
        },
        /**
         * Method for triggering validation from ELkostenart
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        }
    },
    validations: {
        form: {
            stundensatz: { required },
            gmkz: { decimal(value) { return String(value).match(/^\d+,?\d*$/) !== null } },
        }
    }
}
</script>

<style lang="scss" scoped>
.element-gmkz {
    max-width: 32%;
}
.element-stundensatz {
    max-width: 22%;
}
.switches-list {
    margin-top: 30px;

    .inflationsfaktor-switch {
        margin-top: 25px;
    }

    .text-muted {
        margin-top: 10px;
    }
}

fieldset {
    margin-bottom: 0;
}

.berechnungsart-wrapper {
    padding-left: 2px;
}
</style>
