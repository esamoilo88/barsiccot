<template>
    <b-overlay :show="show" rounded="sm">
        <span class="ml-3">Die nachfolgende Tabelle zeigt die Verrechnungswerte für 1 Stück der Angebotposition.</span>
        <div class="billing_list" v-if="tableData.length > 0">
            <table class="w-100">
                <thead>
                <tr>
                    <th style="width: 8%">Zuordnung</th>
                    <th style="width: 40%">Kostenart</th>
                    <th style="width: 10%">Kostenstelle</th>
                    <th style="width: 10%">Leistungart</th>
                    <th style="width: 10%">Stückwert</th>
                    <th style="width: 10%">Stundensatz</th>
                    <th style="width: 12%">Gesamtwert</th>
                    <th style="width: 5%">ILV</th>
                    <th style="width: 5%">VLV</th>
                </tr>
                </thead>
                <tbody>
                <template v-for="item in tableData" v-if="tableData.length > 0">
                    <tr>
                        <td class="border-top">
                            <abbr
                                :class="getBadge(item.zuordnung)"
                                :id="getUniqName(item.zuordnung, item.kostenartIdNew)"
                                :title="item.zuordnung">
                                {{ item.zuordnung }}
                            </abbr>

                            <b-tooltip :target="getUniqName(item.zuordnung, item.kostenartIdNew)">
                                {{ item.zuordnung }}
                            </b-tooltip>
                        </td>
                        <td class="border-top">
                            {{ defVal(item.kostenartNeu, '-') }}
                        </td>
                        <td class="border-top">
                            {{ defVal(item.kostenstelle, '-') }}
                        </td>
                        <td class="border-top">
                            {{ defVal(item.ofiLa, '-') }}
                        </td>

                        <td class="border-top">
                            {{
                                $f.numberToString(item.kostenwert, false, false, '0,00', {
                                    maximumFractionDigits: 2,
                                    minimumFractionDigits: 2
                                })
                            }}
                        </td>
                        <td class="border-top">
                            {{
                                $f.numberToString(item.stundensatz, true, false, '0,00', {
                                    maximumFractionDigits: 2,
                                    minimumFractionDigits: 2
                                })
                            }}
                        </td>
                        <td class="border-top">
                            {{ getGesamtwert(item) }}
                        </td>
                        <td class="border-top">
                            <span class="icon-action-succsess-default" v-if="item.ilvRelevant"/>
                        </td>
                        <td class="border-top">
                            <span class="icon-action-succsess-default" v-if="item.vlvRelevant"/>
                        </td>
                    </tr>
                </template>
                </tbody>
            </table>
        </div>
        <div v-else class="billing_list"><p class="no-data">Keine Daten vorhanden</p></div>
    </b-overlay>
</template>

<script>
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";
import {BSpinner, BTooltip, BTable, BOverlay} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import Badge from "@comp/Badge/Badge";
import FormSelect from "@comp/FormSelect/FormSelect";

export default {
    name: "ap-billing-details",
    components: {BSpinner, FormSelect, Badge, ButtonIcon, BTooltip, BOverlay, BTable},
    mixins: [ScalarsProcessing],
    props: {
        canCreateOrUpdate: {
            type: Boolean,
            required: true
        },
        request: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            show: false,
            tableData: []
        }
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        getUniqName(name, id) {
            return `${name}_${id}`;
        },
        getGesamtwert(item) {
            return this.$f.numberToString(item.kostenwert * item.stundensatz, true, false, '0,00', {
                maximumFractionDigits: 2,
                minimumFractionDigits: 2
            });
        },
        async getData(ctx) {
            this.show = true;
            try {
                const response = await this.$axios.get('/offers/calculations/aps/' + this.request.angebotspositionId + '/billing-details');
                this.show = false;
                this.tableData = response.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        getBadge(zuordnung) {
            let badge = 'badge-secondary';

            switch (zuordnung) {
                case 'ISP':
                    badge = 'badge-info';
                    break;
                case 'DTS':
                    badge = 'badge-success';
                    break;
                case 'DTA':
                    badge = 'badge-warning';
                    break;
            }

            return `badge ${badge}`;
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/lpTable';
</style>

