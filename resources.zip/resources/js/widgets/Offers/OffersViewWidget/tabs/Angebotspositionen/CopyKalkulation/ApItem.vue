<template>
    <b-table
        responsive
        :fields="fields"
        :items="items"
        sort-icon-left
        @sort-changed="ctx => $emit('sort-changed', ctx)"
        class="table-wrapper"
    >
        <template #cell(options)="row">
            <div class="text-nowrap">
                <template>
                    <b-spinner
                        v-if="isProcessing(row.item.angebotspositionId)"
                        class="ml-2 mt-2"
                        small
                    />
                    <ButtonIcon
                        v-else
                        icon-class="icon-action-download-default"
                        :variant=getVariant(row.item.angebotspositionId)
                        @click="$emit('copy-ap', row.item.angebotspositionId)"
                        title="Angebotsposition importieren"
                        v-b-tooltip.hover
                    />
                </template>
            </div>
        </template>
        <template #cell(bezeichnung)="row">
            <truncated-text
                :text="row.item.bezeichnung"
                title="Angebotsposition bezeichnung"
                :width=280
            />
        </template>
        <template #cell(unitPriceTp2)="row">
            <span class="font-weight-bold"> {{ $f.numberToString(row.item.unitPriceTp2, true) }} </span>
        </template>
    </b-table>
</template>
<script>
import {BButton, BTable, BBadge, BSpinner, VBTooltip} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {mapGetters} from "vuex";
import TruncatedText from "@comp/TruncatedText/TruncatedText";

export default {
    name: "ap-item",
    components: {
        TruncatedText,
        BButton, BTable, ButtonIcon, BBadge, BSpinner
    },
    props: {
        items: {
            required: true
        },
        copiedAp: {
            type: Array,
            required: true
        },
        processingAp: {
            type: Array,
            required: true
        },
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            isDetailsVisible: false,
            fields: [
                {key: 'bezeichnung', label: 'Bezeichnung', sortable: true, sortDirection: 'asc', sortKey: 'bezeichnung'},
                {key: 'simpleId', label: 'SIN', sortable: true, sortDirection: 'desc', sortKey: 'simpleId'},
                {key: 'versionsnr', label: 'Versions-Nr'},
                {key: 'unitPriceTp2', label: 'Price', sortable: true, sortDirection: 'desc', sortKey: 'unitPriceTp2'},
                {key: 'options', label: 'Optionen'},
            ]
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        })
    },
    methods: {
        getVariant(angebotspositionId) {
            return this.copiedAp.includes(angebotspositionId) ? 'secondary': 'primary';
        },
        isProcessing(angebotspositionId) {
            return this.processingAp.includes(angebotspositionId);
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables';

.table-wrapper {
    margin-bottom: 10px;
    border: 1px solid lightgrey;
    border-radius: 4px;
    padding: 10px;
    position: relative;
    background-color: #ffffff;
}
::v-deep th[role="columnheader"] {
    border-top: none;

    &:focus {
        outline-color: $primary;
    }
}
</style>
