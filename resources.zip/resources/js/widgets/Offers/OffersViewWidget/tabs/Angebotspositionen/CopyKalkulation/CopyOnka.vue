<template>
    <div>
        <modal-dialog
            modal-class="copy-onka-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-copy-onka-modal')"
            title-dialog='Kalkulation importieren'
            scrollable
            size="lg"
        >
            <div class="d-flex mb-4">
                <b-form-checkbox
                    :id="copyAp ? 'select-ap-search' : 'select-onka-search'"
                    name="select-search-ap"
                    v-model="copyAp"
                    switch
                />
                <span> Einzelne Angebotspositionen suchen </span>
            </div>
            <div class="mb-4">
                <b-input-group size="sm">
                    <div class="w-75">
                        <FormInput
                            v-model="searchString"
                            ref="input"
                            @keyup.native.enter="search"
                            input-id="ap_suchen-input"
                            name="ap_suchen"
                            size="small"
                            label-text="Suchen"
                            :error-conditions="[
                            {
                                name: 'empty-search',
                                condition: (!$v.searchString.required || !$v.searchString.minLength) && $v.searchString.$dirty,
                                text: 'Der Suchbegriff muss mindestens 3 Zeichen lang sein.'
                            }
                        ]"
                        />
                    </div>
                    <b-button
                        class="ml-3 mt-1 h-50"
                        variant="primary"
                        @click="search">Suchen
                    </b-button>
                </b-input-group>
            </div>
            <SearchApForm
                v-if="copyAp"
                :target-sin="targetSin"
                @close-copy-onka-modal="$emit('close-copy-onka-modal')"
                ref="searchAp"
                :searchAp="searchString"
            />
            <SearchProjectForm
                v-else
                :target-sin="targetSin"
                @close-copy-onka-modal="$emit('close-copy-onka-modal')"
                ref="searchProject"
                :searchProject="searchString"
            />

            <template #footer="{methods}">
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BInputGroup, BButton} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {mapGetters} from 'vuex';
import SearchProjectForm from "./SearchProjectForm";
import SearchApForm from "./SearchApForm";
import FormInput from "@comp/FormInput/FormInput";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {required, minLength} from "vuelidate/lib/validators";

export default {
    name: "CopyOnka",
    components: {
        SearchApForm,
        SearchProjectForm,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        FormInput,
        BInputGroup,
        BButton
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCopyOnka: {
            type: Boolean,
            required: true,
            default: false
        },
        targetSin: {
            required: true
        }
    },
    data() {
        return {
            copyAp: false,
            searchString: null,
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            vkVersionId: 'offer/currentVersion'
        })
    },
    methods: {
        async search() {
            this.$v.$touch();

            if (!this.$v.$anyError) {
                if (this.copyAp) {
                    this.$refs.searchAp.search();
                } else {
                    this.$refs.searchProject.search();
                }
            } else {
                navigateToFirstInvalid();
            }
        }
    },
    validations: {
        searchString: {required, minLength: minLength(3)}
    }
}
</script>

<style lang="scss" scoped>

</style>
