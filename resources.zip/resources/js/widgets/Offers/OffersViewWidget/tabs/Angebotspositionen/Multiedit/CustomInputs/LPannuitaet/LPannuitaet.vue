<template>
    <div class="inf-second-column">
        <b-form-checkbox
            v-model="checkbox"
            @change="value => useZinzats(value)"
            switch
            class="zinssatz-checkbox mb-2"
        >
            Annuitätenrechnung
        </b-form-checkbox>
        <FormInputAppend
            v-model="form.anZinssatz"
            @input="value => handleInput('anZinssatz', value)"
            @change="setCheckbox"
            class="lp-anZinssatz"
            input-id="lp-anZinssatz"
            name="anZinssatz"
            label-text="Annuität Zinssatz"
            prepend="%"
            :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.anZinssatz.decimal  && $v.form.anZinssatz.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Annuität Zinssatz'})
                }
            ]"
        />
        <div class="d-flex">
            <FormInputAppend
                v-model="form.anLaufzeit"
                @input="value => handleInput('anLaufzeit', value)"
                @change="setCheckbox"
                class="lp-anLaufzeit"
                input-id="lp-anLaufzeit"
                name="anLaufzeit"
                label-text="Annuität Laufzeit"
                :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.anLaufzeit.decimal  && $v.form.anLaufzeit.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Annuität Laufzeit'})
                }
            ]"
            />
            <FormInputAppend
                v-model="form.anKwert"
                @input="value => handleInput('anKwert', value)"
                @change="setCheckbox"
                class="lp-anKwert"
                input-id="lp-anKwert"
                name="anKwert"
                label-text="Annuität K-Wert"
                :error-conditions="[
                {
                  name: 'invalid-number',
                  condition: !$v.form.anKwert.decimal  && $v.form.anKwert.$dirty,
                  text: $t.__('validation.numeric', {attribute: 'Annuität K-Wert'})
                }
            ]"
            />
        </div>
    </div>
</template>

<script>
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {BFormCheckbox} from 'bootstrap-vue';
import {mapGetters} from 'vuex';

const invalidZero = /^[0]*[,]?[0]*$/;
const valid4Fraction = /^[0-9]*[,]?[0-9]{1,4}$/;
const valid2Fraction = /^[0-9]*[,]?[0-9]{1,2}$/;

export default {
    name: "LPannuitaet",
    components: {FormInputAppend, BFormCheckbox},
    computed: {
        ...mapGetters({
            offerInfo: 'offer/offerInfo'
        })
    },
    data() {
        return {
            checkbox: false,
            form: {
                anZinssatz: '',
                anLaufzeit: '',
                anKwert: '',
            }
        }
    },
    methods: {
        /**
         * Validate fields
         */
        validate() {
            this.useZinzats(this.setCheckbox());
            this.$v.$touch();
            return this.$v;
        },
         /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
        },
        /**
         * Handle input of anKwert, anLaufzeit and anZinssatz
         * @param field
         * @param value
         */
        handleInput(field, value) {
            this.form[field] = value;
            this.$emit('input', {...this.form});
        },
        isEmptyString(value) {
            return value === null || String(value).length === 0;
        },
        isInvalidZero(value) {
            return String(value).match(invalidZero) !== null;
        },
        useZinzats(value) {
            this.form.anZinssatz = value ? this.offerInfo.zinssatz : '';
            this.$emit('input', {...this.form});
        },
        setCheckbox() {
            let isNotEmptyAnyField = this.isNotEmptyField('anZinssatz')
                || this.isNotEmptyField('anLaufzeit')
                || this.isNotEmptyField('anKwert');
            this.checkbox = isNotEmptyAnyField;
            return isNotEmptyAnyField;
        },
        isNotEmptyField(fieldName) {
            return this.form[fieldName] !== '' && this.form[fieldName] !== null;
        }
    },
    validations: {
        form: {
            anZinssatz: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid2Fraction) !== null;
                }
            },
            anLaufzeit: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(/^\d+$/) !== null;
                },
            },
            anKwert: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid2Fraction) !== null;
                }
            }
        }
    }
}
</script>

<style scoped>
.lp-anZinssatz {
    margin-bottom: 10px;
}

.lp-anLaufzeit {
    margin-right: 20px;
}
</style>
