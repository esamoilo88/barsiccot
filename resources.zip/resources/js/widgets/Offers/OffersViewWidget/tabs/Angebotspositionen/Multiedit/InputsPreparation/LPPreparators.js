/**
 * Preparators for inputs which need specific logic
 * for getting its data. E.g. getting options for kostenart.
 * Every preparator must return an object {input: {}, validationRules, errorMessages},
 * "input" contains either of these fields: content, options,
 * searchable (or any other field from input{} object in ConditionalInput component)
 * The mandatory arguments of all preparator functions are:
 * "$axios" - the instance of axios from the vuejs component
 */

import SimpleTranslator from "res/js/utils/SimpleTranslator";
import {createOptions} from "@helpers/Form/InputsHelper";

const translations = require('res/lang/lang.translations.json');
const $t = new SimpleTranslator(translations);

/**
 * @param $axios
 * @returns {Promise<{input: {}, validationRules, errorMessages}>}
 */
const prepareIfWertRessourcen = async ($axios) => {
    let validationRules = {
        float_4: function (value) {
            return value !== null ? String(value).match(/^-?\d+,?\d{0,4}$/) !== null : true;
        }
    };
    let errorMessages = [
        {
            name: 'wrong-format-menge',
            rule: 'float_4',
            text: $t.__('validation.custom_rules.float_4', {attribute: 'Inflationsfaktor Ressourcen'})
        }
    ];
    return {input: {}, validationRules, errorMessages};
}

/**
 * @param $axios
 * @returns {Promise<{input: {}, validationRules, errorMessages}>}
 */
const prepareLeistungstyp = async ($axios) => {
    let leistungstyp = [];
    try {
        let res = await $axios.get('/offers/costs/leistungtyp');
        leistungstyp.push(...createOptions(
            res.data,
            (l) => l.id,
            (l) => l.bezeichnung,
            'group',
            false
        ));
    } catch (err) {
        console.error("Couldn't fetch leistungtyp.", err);
    }
    return {input: {options: leistungstyp}, validationRules: {}, errorMessages: []};
}

/**
 * @param $axios
 * @returns {Promise<{input: {}, validationRules, errorMessages}>}
 */
const prepareServicelevel = async ($axios) => {
    let servicelevel = [];
    try {
        let res = await $axios.get('/offers/costs/servicelevel');
        servicelevel.push(...createOptions(
            res.data,
            (k) => k.servicelevelId,
            (k) => k.beschreibung,
            'bezeichnung',
            true
        ));
    } catch (err) {
        console.error("Couldn't fetch servicelevel.", err);
    }
    return {input: {options: servicelevel}, validationRules: {}, errorMessages: []};
}


export default {
    ifWertRessourcen: prepareIfWertRessourcen,
    leistungstyp: prepareLeistungstyp,
    servicelevel: prepareServicelevel,
};
