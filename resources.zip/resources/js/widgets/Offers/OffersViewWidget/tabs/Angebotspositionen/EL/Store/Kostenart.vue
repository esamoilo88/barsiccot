<template>
    <div class="mt-4">
        <b-overlay :show="pending" class="p-1">
            <div class="kostenart-filter d-flex pb-2">
                <span class="mr-4">Kostenarten filtern:</span>
                <b-form-checkbox-group v-model="zuordnungOptionsSelected">
                    <b-form-checkbox
                        v-for="zuordnung in zuordnungOptions"
                        :key="zuordnung"
                        :value="zuordnung"
                        @change="getKostenartList(true)"
                    >
                        <span>{{ zuordnung }}</span>
                    </b-form-checkbox>
                </b-form-checkbox-group>
            </div>
            <FormSelect
                @input="onSelect"
                @select="onUserChange"
                :value="kostenart"
                select-id="element-kostenart"
                name="element-kostenart"
                label-text="Kostenart*"
                :options="kostenartOptions"
                searchable
                :error-conditions="[
                    {
                        name: 'empty-kostenart',
                        condition: !$v.kostenart.required  && $v.kostenart.$dirty,
                        text: $t.__('validation.required', {attribute: 'Kostenart'})
                    },
                ]"
            />
        </b-overlay>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckboxGroup, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import {mapGetters} from "vuex";
import {createOptions} from "@helpers/Form/InputsHelper";
import {required} from "vuelidate/lib/validators";

export default {
    name: "Kostenart",
    components: {BFormCheckboxGroup, BFormCheckbox, BOverlay, FormSelect},
    props: {
        value: {
            type: Object,
            required: false,
            default: null
        },
        elementToUpdate: {
            type: Object,
            required: false,
            default: null
        }
    },
    async mounted() {
        await this.init();
    },
    data() {
        return {
            kostenart: this.elementToUpdate !== null ? this.elementToUpdate.kostenart.kostenartId : null,
            zuordnungOptionsSelected: [],
            zuordnungOptions: [],
            kostenartOptions: [],
            kostenartenData: [],
            pending: false,
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * When kostenart changed emit value to
         * StoreElement component and to Berechnungsart component
         */
        onSelect(value) {
            this.kostenart = value;
            let emitKostenart = value !== null ? this.kostenartenData.filter(k => k.kostenartId == value)[0] : null;
            this.$emit('input', emitKostenart);
            this.$eventBus.$emit('kostenart-changed', emitKostenart);
        },
        /**
         * Emit when kostenart changed by user and not programmatically
         */
        onUserChange(value) {
            let emitKostenart = value !== null ? this.kostenartenData.filter(k => k.kostenartId == value)[0] : null;
            this.$eventBus.$emit('kostenart-user-changed', emitKostenart);
            this.$emit('change', {field: 'kostenart', value: emitKostenart});
        },
        /**
         * Get the list of zuordnung for filtering kostenart
         */
        async getZuordnungList() {
            try {
                let zuordnung = await this.$axios.get(`/offers/costs/kostenart-zuordnung`);
                this.zuordnungOptions.push(...zuordnung.data);
            } catch (err) {
                throw err;
            }
        },
        /**
         * Get the list of kostenart items
         */
        async getKostenartList(withOverlay = false) {
            if (withOverlay) {
                this.pending = true;
                this.kostenart = null;
            }

            try {
                let kostenart = await this.$axios.post(`/offers/costs/kostenart`, {
                    fields: ['kostenartId', 'bezeichnung', 'zuordnung', 'kostentyp.bezeichnung AS kostentype', 'gruppe'],
                    filters: {
                        onkaRelevant: 1,
                        zuordnung: this.zuordnungOptionsSelected,
                    }
                });
                this.kostenartOptions.splice(0);
                this.kostenartOptions.push(...createOptions(
                    kostenart.data,
                    (k) => k.kostenartId,
                    (k) => k.zuordnung + ' - ' + k.bezeichnung,
                    'gruppe'
                ));
                this.kostenartenData.splice(0);
                this.kostenartenData.push(...kostenart.data);
            } catch (err) {
                throw err;
            }
            withOverlay && (this.pending = false);
        },
        /**
         * Initialize kostenart input and filters
         * @returns {Promise<void>}
         */
        async init() {
            this.pending = true;
            try {
                await this.getZuordnungList();
                await this.getKostenartList();
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Error appeared while initializing kostenart input! ", err);
            }
            this.pending = false;
        },
    },
    validations: {
        kostenart: { required }
    }
}
</script>

<style lang="scss" scoped>
.kostenart-filter {
    padding-left: 2px;
}
</style>
