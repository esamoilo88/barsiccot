<template>
    <div>
        <div v-if="options && options.only_ap > 0" class="badge badge-warning w-100 text-sm-left p-lg-2 mb-2" >
            <span class="icon-alert-error-default"></span>
            Es werden nur leere Angebotspositionen importiert.
        </div>
        <div v-if="errorData.length > 0" class="mb-4 mt-2">
            <div class="d-flex align-items-center mb-2">
                <img
                    class="icon-info mr-2"
                    :src="'/img/icons/warning_graphical.svg'"
                    :alt="'fehler'"
                />
                <span>Es sind fehlerhafte Positionen vorhanden, die nicht importiert werden können. </span>
            </div>
        </div>
        <b-table
            responsive
            :fields="fields"
            :items="errorData"
            striped
        >
            <template #cell(message)="row">
                <div>
                    <img
                        class="icon-info mr-2"
                        :src="'/img/icons/error_graphical.svg'"
                        :alt="'fehler'"
                    />
                    {{row.item}}
                </div>
             </template>
        </b-table>
    </div>
</template>

<script>
import {BTable} from "bootstrap-vue";

export default {
    name: "ErrorForm",
    components: {
        BTable
    },
    props: {
        errorData: {
            type: Array,
            required: true,
            default: () => []
        },
        options:{
            type: Object,
            required: false
        }
    },
    data() {
        return {
            fields: [
                {key: 'message', label: 'Fehler'}
            ]
        }
    }
}
</script>

<style scoped>
    .icon-info {
        width: 32px;
    }
</style>
