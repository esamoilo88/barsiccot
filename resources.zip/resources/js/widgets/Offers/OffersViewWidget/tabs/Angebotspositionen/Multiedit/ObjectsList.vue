<template>
    <div>
        <div class="simple-box d-flex flex-column mb-4">
            <b-overlay :show="pending">
                <p class="mb-2">Bitte wähle aus, in welchen Objekten die Änderung vorgenommen werden soll.</p>

                <span
                    v-if="(!$v.selectedObjects.required && $v.selectedObjects.$dirty) || this.kostentypError"
                    :class="{
                        'my-2': true,
                        'invalid-feedback': true,
                        'd-block': (!$v.selectedObjects.required && $v.selectedObjects.$dirty) || this.kostentypError
                    }"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true"
                >
                    {{ errorMessage }}
                </span>
                <div :class="{'invalid': (!$v.selectedObjects.required && $v.selectedObjects.$dirty) || this.kostentypError}">

                    <b-table-lite id="objects-list" :items="items" :fields="fields">
                        <template #cell(id)="item">
                            <b-form-checkbox
                                v-model="selectedObjects"
                                :key="item.item.id"
                                :class="'object' + item.item.id"
                                :value="item.item.id"
                                @input="$emit('objects-selected', selectedObjects)"
                            >
                                <span class="sr-only">{{ item.item.object }}</span>
                            </b-form-checkbox>
                        </template>

                        <template #cell(object)="item">
                            <span class="mr-2">{{ item.item.object }}</span>
                            <span v-if="object.toUpperCase() === 'AP'" class="text-muted">(Nr {{ item.item.sort }})</span>
                            <span v-else-if="object.toUpperCase() === 'EL'" class="text-muted" v-html="elSpan(item.item)"></span>
                            <span v-else class="text-muted">{{ item.item.parent }}</span>
                            <br>
                            <div :id="'error-div-' + item.item.id" class="alert-message not-show"></div>
                        </template>

                        <template #custom-foot>
                            <b-tr v-if="items.length === 0">
                                <b-td colspan="2" class="text-center">Keine Daten vorhanden</b-td>
                            </b-tr>
                        </template>
                    </b-table-lite>

                    <div v-if="items.length > 0" class="pagination-wrapper">
                        <span class="total-rows-text">{{ paginationEntriesText }}</span>
                        <b-pagination
                            v-model="currentPage"
                            @input="fetchObjects"
                            :total-rows="totalRows"
                            :per-page="perPage"
                            aria-controls="lp-list-for-element-creation"
                        ></b-pagination>
                    </div>

                </div>
            </b-overlay>
        </div>
    </div>
</template>

<script>
import {BFormCheckbox, BOverlay, BPagination, BTableLite, BTd, BTfoot, BTr} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";
import {mapGetters} from 'vuex';
import {required} from 'vuelidate/lib/validators';

export default {
    name: "ObjectsList",
    components: {
        BTableLite, BOverlay, BPagination, BFormCheckbox,
        BTfoot, BTr, BTd
    },
    mixins: [Pagination],
    props: {
        object: {
            type: String,
            required: true
        },
        selectedFields: {
            type: Array,
            required: false,
            default: () => []
        }
    },
    async created() {
        this.initPaginationMxn(1, 0, 10);
        await this.fetchObjects();
    },
    data() {
        return {
            items: [],
            fields: [{key: "id", label: "", class: "select-object-checkbox"}, {key: "object", label: "Objekt"}],
            selectedObjects: [],
            pending: false,
            kostentypError: false
        }
    },
    computed: {
        ...mapGetters({
            currentVersion: 'offer/currentVersion'
        }),
        errorMessage() {
            return this.kostentypError ? '' : 'Bitte wähle mindestens eine Objekt aus.';
        }
    },
    watch: {
        object(newValue, oldvalue) {
            this.selectedObjects.splice(0);
            this.$emit('objects-selected', []);
            this.fetchObjects();
            this.$v.$reset();
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * resetting is placed in separate method just for
         * ability to call it outside of this component
         */
        resetValidation() {
            this.$v.$reset();
        },
        alertError() {
            this.kostentypError = true;
        },
        hideError() {
            this.kostentypError = false;
        },
        /**
         * Fetch the list of project Leistungspositions
         * @returns {Promise<void>}
         */
        async fetchObjects() {
            this.pending = true;
            try {
                let res = await this.$axios.post(`/offers/calculations/multiedit/objects/${this.object}/${this.currentVersion}`, {
                    perPage: this.perPage,
                    currentPage: this.currentPage
                });
                this.items.splice(0);
                this.items.push(...this.reformatTableItems(res.data.data));
                this.totalRows = res.data.total;
                this.$emit('objects-loaded', res.data.data);
            } catch (err) {
                console.error("Couldn't fetch onka multiedit objects.", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        /**
         * Set additional fields for objects
         * @param objects
         * @returns {*}
         */
        reformatTableItems(objects) {
            let mapping = {'AP': object => object, 'LP': this.lpParent, 'EL': this.elParent, 'BER': this.berParent};
            return objects.map(obj => mapping[this.object.toUpperCase()](obj));
        },
        /**
         * Set parent field for LP objects
         * @param object
         * @returns {*}
         */
        lpParent(object) {
            object.parent = object.apBezeichnung !== null ? `(AP ${object.apBezeichnung} (Nr ${object.apSort}))` : null;
            return object;
        },
        /**
         * Set parent field for EL objects
         * @param object
         * @returns {*}
         */
        elParent(object) {
            object.parent = `(LP ${object.lpBezeichnung}, AP ${object.apBezeichnung} (Nr ${object.apSort}))`;
            return object;
        },
        /**
         * Set parent field for BER objects
         * @param object
         * @returns {*}
         */
        berParent(object) {
            if (object.lpBezeichnung) {
                object.parent = 'LP ' + object.lpBezeichnung + ', AP ' + object.apBezeichnung
            } else if (object.elBezeichnung) {
                object.parent = `EL ${object.elBezeichnung}, LP ${object.elLPBezeichnung}, AP ${object.elLPAPBezeichnung} (Nr ${object.elLPAPSort})`;
            } else {
                object.parent = null;
            }
            return object;
        },
        elSpan(item) {
            return '<br>' + item.kostenartBezeichnung + ' - ' + item.kostentypBezeichnung + '<br>' + item.parent;
        }
    },
    validations: {
        selectedObjects: {required}
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

::v-deep .select-object-checkbox {
    width: 50px;
}

.invalid {
    border: 1px solid $error;
    border-radius: 5px;
}

.invalid-feedback {
    color: $error;
    margin-bottom: 0;
    border: none;
}

.selected-objects-number {
    margin: 20px 0 0 20px;
    display: block;
}

.icon-20 {
    font-size: 20px;
}
.not-show {
    display: none;
}
.alert-message {
    color: red !important;
    font-size: 1rem;
}
</style>
