/**
 * Preparators for inputs which need specific logic
 * for getting its data. E.g. getting options for kostenart.
 * Every preparator must return an object {input: {}, validationRules, errorMessages},
 * "input" contains either of these fields: content, options,
 * searchable (or any other field from input{} object in ConditionalInput component)
 * The mandatory arguments of all preparator functions are:
 * "$axios" - the instance of axios from the vuejs component
 */

import {createOptions} from "@helpers/Form/InputsHelper";

/**
 * Get the data for kostenart select input
 * @param $axios
 * @returns {Promise<{input: {options: [], searchable: boolean}, validationRules, errorMessages}>}
 */
const prepareKostenart = async ($axios) => {
    let kostenartOptions = [];
    try {
        let kostenart = await $axios.post(`/offers/costs/kostenart`, {
            fields: ['kostenartId', 'bezeichnung', 'zuordnung', 'gruppe'],
            filters: {onkaRelevant: 1}
        });
        kostenartOptions.push(...createOptions(
            kostenart.data,
            (k) => k.kostenartId,
            (k) => k.zuordnung + ' - ' + k.bezeichnung,
            'gruppe'
        ));
    } catch (err) {
        console.error("Couldn't fetch kostenart options", err);
    }

    return {input: {options: kostenartOptions, searchable: true}, validationRules: {}, errorMessages: []};
}

/**
 * Get the data for kostenstelle select input
 * @param $axios
 * @returns {Promise<{input: {options: [], searchable: boolean}, validationRules: {}, errorMessages: []}>}
 */
const prepareKostenstelle = async ($axios) => {
    let kostenstelleOptions = [];
    try {
        let res = await $axios.post('/offers/costs/kostenstelle', {
            fields: ['kostenstelleId', 'gruppe', 'kostenstelle', 'beschreibung']
        });
        kostenstelleOptions.push(...createOptions(
            res.data,
            (k) => k.kostenstelleId,
            (k) => k.kostenstelle + ' - ' + k.beschreibung,
            'gruppe',
            true
        ));
    } catch (err) {
        console.error("Couldn't fetch kostenstelle.", err);
    }

    return {input: {options: kostenstelleOptions, searchable: true}, validationRules: {}, errorMessages: []};
}


export default {
    kostenart: prepareKostenart,
    kostenstelle: prepareKostenstelle
};
