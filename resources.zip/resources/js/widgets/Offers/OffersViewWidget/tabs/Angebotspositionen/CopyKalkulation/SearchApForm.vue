<template>
    <div>
        <div v-if="totalRows > 0">
            <ap-item
                :items="searchData"
                @copy-ap="value => copyAp(value)"
                :copied-ap="copiedAp"
                :processing-ap="processingAp"
                @sort-changed="ctx => sort(ctx)"
            />
        </div>

        <div v-else-if="clearForm === false" class="text-center">
            Keine Daten vorhanden
        </div>

        <Pagination
            v-model="currentPage"
            @input="search"
            v-if="totalRows > 0"
            :per-page-prop="perPage"
            :current-page="currentPage"
            table-id="customer-items-list"
            :total-rows-prop="totalRows"
        />
    </div>
</template>

<script>
import {BButton, BInputGroup} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import ApItem from "./ApItem";
import Pagination from "@comp/Pagination/Pagination";

export default {
    name: "search-ap-form",
    components: {
        ApItem,
        FormInput,
        BButton,
        BInputGroup,
        Pagination,
    },
    props: {
        targetSin: {
            required: true,
            type: Number
        },
        searchAp: {
            required: true,
            type: String
        }
    },
    data() {
        return {
            totalRows: 0,
            currentPage: 1,
            perPage: (window.innerHeight > 700) ? 10 : 5,
            sortDesc: false,
            searchData: [],
            clearForm: true,
            copiedAp: [],
            processingAp: [],
            previousSearchString: null,
            sortBy: 'bezeichnung'
        }
    },
    methods: {
        async search() {
            window.preloader.show();

            let data = {
                filter: {"search": this.searchAp},
                currentPage: this.previousSearchString === this.searchAp ? this.currentPage : 1,
                perPage: this.perPage,
                sortDesc: this.sortDesc,
                sortBy: this.sortBy,
                searchByAp: true
            }
            this.currentPage = data.currentPage;
            try {
                const response = await this.$axios.post('/copy-onka/search', data);
                this.searchData = response.data.data;
                this.totalRows = response.data.total > 300 ? 300 : response.data.total;
                this.clearForm = false;
                this.previousSearchString = this.searchAp
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data, 'error');
            } finally {
                window.preloader.hide();
            }
        },
        async sort(ctx) {
            this.sortBy = ctx.sortBy;
            this.sortDesc = ctx.sortDesc;

            await this.search();
        },
        async copyAp(apId) {
            this.processingAp.push(apId);

            try {
                await this.$axios.post(`/offers/${this.targetSin}/copy-ap/${apId}`);
                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');
                this.copiedAp.push(apId);
                window.flash.success('Angebotsposition erfolgreich kopiert.');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                this.processingAp = this.processingAp.filter(ap => ap !== apId);
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.spinner {
    position: relative;
    padding: 40px;
    left: 45%
}

.input-tooltip {
    position: absolute;
    right: -30px;
    top: 15px;
}

.table {
    table-layout: fixed
}

.input-group {
    flex-wrap: nowrap;
}

.search-box {
    display: flex;
    grid-template-columns: 1fr 40px;

    .icon-container {
        padding-top: 14px;
        text-align: center;
    }

}

::v-deep .table.b-table.b-table-stacked > tbody > tr > [data-label]::before {
    text-align: left;
}

::v-deep .modal-content button.btn.btn-primary {
    justify-content: center
}
.pagination-wrapper {
    display: flex;
    align-items: center;
    position: relative;

    & > span {
        position: absolute;
    }

    .pagination.b-pagination {
        margin: 0 auto;
    }

    .total-rows-text {
        margin-left: 20px;
    }
}
</style>
