<template>
    <b-overlay :show="dataLoading" class="p-1">
        <b>Für direkt in Lotex kalkulierte Inhalte können Kosten- oder Tätigkeitselemente hinzugefügt werden.</b>
        <b-form-checkbox v-model="options.create_el" class="py-2">
            <span>Kosten- und Tätigkeitselemente hinzufügen</span>
        </b-form-checkbox>
        <div class="m-2 mb-4" v-if="options.create_el">
            <FormSelect
                v-model="options.pug3_hoeherw_service"
                class="mb-3 px-0"
                select-id="pug3_hoeherw_service"
                name="pug3_hoeherw_service"
                label-text="PUG3 höherw. Service"
                :options="kostenartOptions"
                :error-conditions="errorConditions.pug3_hoeherw_service"
            />
            <FormSelect
                v-model="options.zusaetzliche_kosten_vorleister"
                class="mb-3 px-0"
                select-id="zusaetzliche_kosten_vorleister"
                name="zusaetzliche_kosten_vorleister"
                label-text="Zusätzliche Kosten Vorleister"
                :options="kostenartOptions"
                :error-conditions="errorConditions.zusaetzliche_kosten_vorleister"
            />
            <FormSelect
                v-model="options.kraeftegruppe_1"
                class="mb-3 px-0"
                select-id="kraeftegruppe_1"
                name="kraeftegruppe_1"
                label-text="Kräftegruppe 1"
                :options="kostenartOptions"
                :error-conditions="errorConditions.kraeftegruppe_1"
            />
            <FormSelect
                v-model="options.kraeftegruppe_2"
                class="mb-3 px-0"
                select-id="kraeftegruppe_2"
                name="kraeftegruppe_2"
                label-text="Kräftegruppe 2"
                :options="kostenartOptions"
                :error-conditions="errorConditions.kraeftegruppe_2"
            />
            <FormSelect
                v-model="options.kraeftegruppe_3"
                class="mb-3 px-0"
                select-id="kraeftegruppe_3"
                name="kraeftegruppe_3"
                label-text="Kräftegruppe 3"
                :options="kostenartOptions"
                :error-conditions="errorConditions.kraeftegruppe_3"
            />
            <FormSelect
                v-model="options.installationspauschale"
                class="mb-3 px-0"
                select-id="installationspauschale"
                name="installationspauschale"
                label-text="Installationspauschale"
                :options="kostenartOptions"
                :error-conditions="errorConditions.installationspauschale"
            />
            <FormSelect
                v-model="options.tp_betrag_simple_ep"
                class="mb-3 px-0"
                select-id="tp_betrag_simple_ep"
                name="tp_betrag_simple_ep"
                label-text="TP Betrag SIMPLE EP"
                :options="kostenartOptions"
                :error-conditions="errorConditions.tp_betrag_simple_ep"
            />
        </div>
        <div class="mt-5">
            <b>Weitere Einstellungen</b>
            <b-form-checkbox v-model="options.create_empty_lp" class="py-2">
                <span>Leistungspositionen bei leeren Angebotspositionen hinzufügen</span>
            </b-form-checkbox>
            <b-form-checkbox v-model="options.only_ap" class="py-2">
                <span>Nur Angebotspositionen importieren</span>
            </b-form-checkbox>
        </div>
    </b-overlay>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckbox, BOverlay} from 'bootstrap-vue';
import {mapGetters} from "vuex";
import {required} from "vuelidate/lib/validators";
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {createOptions} from "@helpers/Form/InputsHelper";

export default {
    name: "Step3",
    components: {
        FormSelect, BFormCheckbox, BOverlay
    },
    mixins: [Validation],
    props: {
        startSimpleId: {
            type: Number,
            required: false,
            default: null
        },
        arrayForDisplay: {
            type: Object,
            required: false
        }
    },
    computed: {
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        }),
        errorConditions() {
            return {
                pug3_hoeherw_service: [
                    {
                        name: 'pug3-hoeherw-service-required',
                        condition: !this.$v.options.pug3_hoeherw_service.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'PUG3 höherw. Service'})
                    }
                ],
                zusaetzliche_kosten_vorleister: [
                    {
                        name: 'zusaetzliche-kosten-vorleister-required',
                        condition: !this.$v.options.zusaetzliche_kosten_vorleister.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'Zusätzliche Kosten Vorleister'})
                    }
                ],
                kraeftegruppe_1: [
                    {
                        name: 'kraeftegruppe-1-required',
                        condition: !this.$v.options.kraeftegruppe_1.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'Kräftegruppe 1'})
                    }
                ],
                kraeftegruppe_2: [
                    {
                        name: 'kraeftegruppe-2-required',
                        condition: !this.$v.options.kraeftegruppe_2.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'Kräftegruppe 2'})
                    }
                ],
                kraeftegruppe_3: [
                    {
                        name: 'kraeftegruppe-3-required',
                        condition: !this.$v.options.kraeftegruppe_3.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'Kräftegruppe 3'})
                    }
                ],
                installationspauschale: [
                    {
                        name: 'installationspauschale-required',
                        condition: !this.$v.options.installationspauschale.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'Installationspauschale'})
                    }
                ],
                tp_betrag_simple_ep: [
                    {
                        name: 'tp-betrag-simple-ep-required',
                        condition: !this.$v.options.tp_betrag_simple_ep.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'TP Betrag SIMPLE EP'})
                    }
                ],
            }
        }
    },
    validations: {
        options: {
            pug3_hoeherw_service: {required},
            zusaetzliche_kosten_vorleister: {required},
            kraeftegruppe_1: {required},
            kraeftegruppe_2: {required},
            kraeftegruppe_3: {required},
            installationspauschale: {required},
            tp_betrag_simple_ep: {required},
        }
    },
    async mounted() {
        await this.init();
    },
    data() {
        return {
            isDirty: false,
            dataLoading: false,
            kostenartOptions: [],
            options: {
                create_el: false,
                pug3_hoeherw_service: null,
                zusaetzliche_kosten_vorleister: null,
                kraeftegruppe_1: null,
                kraeftegruppe_2: null,
                kraeftegruppe_3: null,
                installationspauschale: null,
                tp_betrag_simple_ep: null,
                create_empty_lp: null,
                only_ap: false
            }
        }
    },
    methods: {
        /**
         * Get the list of kostenart items
         */
        async getKostenartList(withOverlay = false) {
            if (withOverlay) {
                this.dataLoading = true;
                this.kostenart = null;
            }

            try {
                let kostenart = await this.$axios.post(`/offers/costs/kostenart`, {
                    fields: ['kostenartId', 'bezeichnung', 'zuordnung', 'kostentyp.bezeichnung AS kostentype', 'gruppe'],
                    filters: {
                        onkaRelevant: 1,
                        zuordnung: this.zuordnungOptionsSelected,
                    }
                });
                console.log('kostenar1t', kostenart.data)
                this.kostenartOptions.splice(0);
                this.kostenartOptions.push(...createOptions(
                    kostenart.data,
                    (k) => k.kostenartId,
                    (k) => k.zuordnung + ' - ' + k.bezeichnung,
                    'gruppe'
                ));
                console.log('kostenart8', kostenart.data)
            } catch (err) {
                throw err;
            }
            withOverlay && (this.dataLoading = false);
        },

        /**
         * Initialize kostenart input and filters
         * @returns {Promise<void>}
         */
        async init() {
            this.dataLoading = true;
            try {
                await this.getKostenartList();
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Error appeared while initializing kostenart input! ", err);
            }
            this.dataLoading = false;
        },

        validate() {
            this.isDirty = true;
            this.$v.options.$touch();
            if (this.$v.options.$invalid && this.options.create_el) {
                this.showValidationErrors = true;
                navigateToFirstInvalid();
                return false;
            }
            this.addOptions();

            return true;
        },
        async addOptions() {
            let res = await this.$axios.post(`/offers/${this.simpleId}/katalog/${this.currentVersion}/lotex/final-preview`,
                {
                    options: this.options,
                    dataForDisplay: this.arrayForDisplay,
                }
            );
            this.$emit('final-data-for-display', res.data, this.options);
        }
    }
}
</script>
