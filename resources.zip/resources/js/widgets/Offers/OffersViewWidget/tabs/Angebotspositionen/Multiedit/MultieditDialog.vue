<template>
    <div>
        <modal-dialog
            modal-class="onka-multiedit-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-onka-multiedit-modal')"
            title-dialog="Mehrfachänderung"
            :scrollable="true"
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <b-overlay :show="onFieldsPending">
                        <FormSelect
                            v-model="object"
                            class="mb-4"
                            name="object-selection-input"
                            label-text="Objekt*"
                            select-id="object-selection-input"
                            :options="objectSelectionOptions"
                            @change="onObjectTypeChange"
                        />

                        <div v-if="object !== null" class="fields-list">
                            <div class="d-flex mb-2 p-2 field-wrapper" v-for="field in fields" :key="field.id">
                                <b-form-checkbox
                                    class="field-checkbox mr-4"
                                    v-model="selectedFields"
                                    :value="field.id"
                                    @change="onFieldSelect(field.id, field.sysField)"
                                    :key="'fieldSelect'+field.id"
                                ></b-form-checkbox>
                                <div class="field-container d-flex flex-column">
                                    <ConditionalInput
                                        ref="fieldInput"
                                        :class="{'negative-margin': field.info !== null && field.inputType === 'checkbox'}"
                                        :settings="field"
                                        :key="'fieldInputKey'+field.id"
                                        @input="onFieldInput"
                                    />
                                    <span v-if="field.info" class="text-muted mt-2"> {{ field.info }} </span>
                                </div>
                            </div>
                        </div>
                    </b-overlay>
                </div>

                <ObjectsList
                    v-if="object !== null"
                    ref="objectsList"
                    :object="object"
                    @objects-selected="onObjectsSelect"
                    @objects-loaded="setLoadedObject"
                />

                <div v-if="object !== null">
                    <div class="d-flex mb-3">
                        <span class="icon-action-succsess-default mr-3 icon-20"></span>
                        <span>Es werden <b>{{ selectedFieldsText }}</b> in <b>{{ selectedObjectsText }}</b> ({{ objectLong }}) geändert.</span>
                    </div>
                </div>
            </div>

            <template #footer="{methods}">
                <button
                    v-if="hasRights"
                    @click="onSave" class="btn btn-primary"
                    :disabled="onSavePending"
                >
                    <b-spinner v-if="onSavePending" small></b-spinner>
                    Änderungen durchführen
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import ConditionalInput from "./ConditionalInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import {BSpinner, BOverlay, BFormCheckbox} from "bootstrap-vue";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import ObjectsList from "./ObjectsList";
import {mapGetters} from 'vuex';

export default {
    name: "MultieditDialog",
    components: {
        ObjectsList, ModalDialog, BSpinner, BOverlay, BFormCheckbox,
        ConditionalInput, FormSelect
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        hasRights: {
            type: Boolean,
            required: true,
            default: false
        }
    },
    data() {
        return {
            form: {},
            object: null,
            objectSelectionOptions: [
                {id: "AP", text: "Angebotspositionen"}, {id: "LP", text: "Leistungspositionen"},
                {id: "EL", text: "Elemente"}, {id: "BER", text: "Berechnungen"}
            ],
            fields: [],
            selectedFields: [],
            selectedObjects: [],
            onFieldsPending: false,
            onSavePending: false,
            objectsToSelect: {}
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            vkVersion: 'offer/currentVersion',
        }),
        selectedObjectsText() {
            return this.selectedObjects.length + ' ' + (this.selectedObjects.length === 1 ? 'Objekt' : 'Objekten');
        },
        selectedFieldsText() {
            return this.selectedFields.length + ' ' + (this.selectedFields.length === 1 ? 'Feld' : 'Felder');
        },
        objectLong() {
            let mapping = {'AP': 'Angebotsposition', 'LP': 'Leistungsposition', 'EL': 'Kalkulationselement', 'BER': 'Berechnung'};
            return this.object !== null ? mapping[this.object.toUpperCase()] : '';
        }
    },
    methods: {
        /**
         * Handle saving process
         * @returns {Promise<void>}
         */
        async onSave() {
            this.clearKostentypErrors();

            if (this.selectedFields.length === 0) {
                window.flash.error(this.$t.__('errors.offer.calculations.multiedit.select_fields'));
            }
            if (this.isValid() && this.selectedFields.length > 0 && this.isKostentypValid()) {
                this.onSavePending = true;
                try {
                    let fields = {};
                    this.fields.map(field => {
                        if (this.selectedFields.includes(field.id) && this.form[field.sysField] !== undefined) {
                            fields[field.sysField] = this.form[field.sysField];
                        }
                    })
                    let res = await this.$axios.post(`/offer/${this.simpleId}/calculations/multiedit`, {
                        vkVersion: this.vkVersion,
                        object: this.object,
                        fields,
                        objectsList: this.selectedObjects
                    });
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    this.$emit('close-onka-multiedit-modal');
                } catch (err) {
                    console.error("Couldn't save fields", err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
                this.onSavePending = false;
            } else {
                navigateToFirstInvalid();
            }
        },
        /**
         * When any input from ConditionalInput is firing
         * 'input' event we update respective field in 'this.form'
         * @param field
         * @param value
         */
        onFieldInput({field, value}) {
            if (this.form.field === undefined) {
                this.$set(this.form, field, value);
            } else {
                this.form.field = value;
            }
        },
        /**
         * Checking whether all ConditionalInput components are valid or not
         * @returns {boolean}
         */
        isValid() {
            let anyErrors = false;
            if (this.$refs.fieldInput !== undefined) {
                this.$refs.fieldInput.map(input => {
                    input.resetValidation && input.resetValidation();
                    if (this.selectedFields.includes(input.settings.id)) {
                        input.validate().$anyError && (anyErrors = true);
                    }
                });
                this.$refs.objectsList.resetValidation();
                let objectsListErrors = this.selectedFields.length > 0 ? this.$refs.objectsList.validate().$anyError : false;
                anyErrors = anyErrors || objectsListErrors;
            }
            return !anyErrors;
        },
        /**
         * Handle changing onka object's type in select input
         * @returns {Promise<void>}
         */
        async onObjectTypeChange() {
            this.selectedFields.splice(0);
            this.form = {};
            await this.fetchFields();
        },
        /**
         * Handle selecting objects from objects list
         * @param objects
         */
        onObjectsSelect(objects) {
            this.selectedObjects.splice(0);
            this.selectedObjects.push(...objects);
        },
        /**
         * Handle selecting fields to update
         * @param id
         * @param field
         */
        onFieldSelect(id, field) {
            let isCheckBox = false;
            this.fields.map(f =>  { if(f.id === id) isCheckBox = f.inputType === 'checkbox' });
            // if you choose field with type checkbox it should be initially considered as false if you didn't specify another value
            if (isCheckBox && this.selectedFields.includes(id) && this.form[field] === undefined) {
                this.form[field] = false;
            } else if (this.form[field] === undefined) {
                this.form[field] = null;
            }
        },
        /**
         * Fetch the list of available fields for specific object
         * @returns {Promise<void>}
         */
        async fetchFields() {
            this.onFieldsPending = true;
            try {
                let res = await this.$axios.get(`/offers/calculations/multiedit/fields/${this.object}`);
                this.fields.splice(0);
                this.fields.push(...res.data);
            } catch (err) {
                console.error("Couldn't fetch inputs info", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.onFieldsPending = false;
        },
        isKostentypValid() {
            if (this.object !== 'EL') return true;

            let result = true;

            for (let key in this.selectedObjects) {
                let selectedId = this.selectedObjects[key];

                let selectedObject = this.objectsToSelect[selectedId];

                let errorDiv = document.querySelector('#error-div-' + selectedId);
                let wertChosen = false;
                let aufwandChosen = false;
                let kostenartChosen = false;

                let kostentypBezeichnung = selectedObject.kostentypBezeichnung;

                this.fields.map(field => {
                    if (field.sysField === 'wert' && this.selectedFields.includes(field.id)) {
                        wertChosen = true;
                    }
                    if (field.sysField === 'aufwand' && this.selectedFields.includes(field.id)) {
                        aufwandChosen = true;
                    }
                    if (field.sysField === 'kostenart' && this.selectedFields.includes(field.id)) {
                        kostenartChosen = true;
                    }
                })

                if (wertChosen && this.form.wert && kostentypBezeichnung === 'Ressourcen') {
                    let wertErrorSpan = document.createElement("span");

                    wertErrorSpan.innerHTML = 'Die Eingabe eines Kostenbetrags ist für Kostentyp Ressourcen nicht möglich. <br>';
                    errorDiv.appendChild(wertErrorSpan);
                    errorDiv.classList.remove('not-show');

                    result = false;
                }

                if (aufwandChosen && this.form.aufwand && kostentypBezeichnung === 'Kosten') {
                    let aufwandErrorSpan = document.createElement("span");

                    aufwandErrorSpan.innerHTML = 'Die Eingabe von Aufwand ist für Kostentyp Kosten nicht möglich. <br>';
                    errorDiv.appendChild(aufwandErrorSpan);
                    errorDiv.classList.remove('not-show');

                    result = false;
                }


                if (kostenartChosen && this.form.kostenart) {
                    if (this.form.kostenart.kostentyp === 'Kosten' && kostentypBezeichnung === 'Ressourcen') {
                        let kostenartKostenErrorSpan = document.createElement("span");

                        kostenartKostenErrorSpan.innerHTML = 'Der Wechsel des Kostentyps ist nicht möglich. <br>';
                        errorDiv.appendChild(kostenartKostenErrorSpan);
                        errorDiv.classList.remove('not-show');

                        result = false;
                    }

                    if (this.form.kostenart.kostentyp === 'Ressourcen' && kostentypBezeichnung === 'Kosten') {
                        let kostenartRessourcenErrorSpan = document.createElement("span");

                        kostenartRessourcenErrorSpan.innerHTML = 'Der Wechsel des Kostentyps ist nicht möglich. <br>';
                        errorDiv.appendChild(kostenartRessourcenErrorSpan);
                        errorDiv.classList.remove('not-show');

                        result = false;
                    }
                }
            }

            if (result === false) {
                this.$refs.objectsList.alertError();
            }

            return result;
        },
        setLoadedObject(objects) {
            let result = {};

            for (let key in objects) {
                let data = objects[key];
                result[data.id] = data;
            }

            this.objectsToSelect = result;
        },
        clearKostentypErrors() {
            this.$refs.objectsList.hideError();

            for (let key in this.objectsToSelect) {
                let errorDiv = document.querySelector('#error-div-' + key);
                errorDiv.classList.add('not-show');
                errorDiv.innerHTML = '';
            }
        }
    }
}
</script>

<style lang="scss">
.onka-multiedit-modal {
    .modal-dialog {
        max-width: 660px;
    }

    .field-checkbox {
        margin-top: 13px;
    }

    .field-wrapper {
        background-color: #f5f5f5;
        border-radius: 5px;
    }

    .negative-margin {
        margin-bottom: -10px;
    }

    .field-container {
        width: 91%;
    }
}
</style>
