import APPreparators from "./APPreparators";
import LPPreparators from "./LPPreparators";
import ELPreparators from "./ELPreparators";
import BERPreparators from "./BERPreparators";

/**
 * Preparators for inputs which need specific logic
 * for getting its data. E.g. getting options for kostenart.
 */
export const fieldsPreparators = {
    AP: {
        ...APPreparators
    },
    LP: {
        ...LPPreparators
    },
    EL: {
        ...ELPreparators
    },
    BER: {
        ...BERPreparators
    }
}
