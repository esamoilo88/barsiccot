<template>
    <tr>
        <!-- LP Berechnung -->
        <template v-if="parentType === 'LP'">
            <td class="pl-0 border-top">
                <span class="icon-function-mathematical-symbol"/>
                <span class="object_text">BER</span>
            </td>
            <td colspan="5" class="object_text border-top">
                {{ item.bezeichnung }}:
                {{ $f.numberToString(calcData.initial, false, false, 0, {maximumFractionDigits: 10}) }}
                {{ item.operator }}
                {{ $f.numberToString(item.wert, false, false, 0, {maximumFractionDigits: 10}) }} =
                <a href="#" class="font-weight-bold">
                    {{ $f.numberToString(calcData.result, true, true) }}
                </a>
            </td>
            <td class="pl-5 border-top">
                <div v-if="canCreateOrUpdate" class="text-right">
                    <button
                        class="btn btn-secondary mr-1"
                        title="Berechnung bearbeiten"
                        @click="$emit('edit-ber', item)"
                    >
                        <span class="icon-action-edit-default"></span>
                    </button>
                    <button
                        class="btn btn-secondary"
                        title="Berechnung löschen"
                        @click="$emit('delete-ber', item)"
                    >
                        <span class="icon-action-remove-default"></span>
                    </button>
                </div>
            </td>
        </template>

        <!-- EL Berechnung -->
        <template v-else>
            <td class="pl-2">
                <div class="d-flex">
                    <div>L</div>
                    <div class="pt-1">
                        <span class="icon-function-mathematical-symbol"/>
                        <span class="object_text">BER</span>
                    </div>
                </div>
            </td>
            <td colspan="5" class="object_text">
                {{ item.bezeichnung }}:
                {{ $f.numberToString(calcData.initial, false, false, null, {maximumFractionDigits: 10}) }}
                {{ item.operator }}
                {{ $f.numberToString(item.wert, false, false, null, {maximumFractionDigits: 10}) }} =
                <a href="#" class="font-weight-bold">
                    {{ $f.numberToString(calcData.result, true, true) }}
                </a>
            </td>
            <td>
                <div v-if="canCreateOrUpdate" class="text-right">
                    <button
                        class="btn btn-secondary mr-1"
                        title="Berechnung bearbeiten"
                        @click="$emit('edit-ber', item)"
                    >
                        <span class="icon-action-edit-default"></span>
                    </button>
                    <button
                        class="btn btn-secondary"
                        title="Berechnung löschen"
                        @click="$emit('delete-ber', item)"
                    >
                        <span class="icon-action-remove-default"></span>
                    </button>
                </div>
            </td>
        </template>
    </tr>
</template>

<script>
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";

export default {
    name: "BerechnungRow",
    components: {ButtonIcon},
    props: {
        parentType: {
            type: String,
            required: true
        },
        calcData: {
            type: Object,
            required: true
        },
        item: {
            type: Object,
            required: true
        },
        canCreateOrUpdate: {
            type: Boolean,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
.object_text {
    font-size: 16px;
    color: #0065ff;
}
.table th, .table td {
    border-top: none;
    vertical-align: middle;
}
.btn {
    padding-left: 0.7rem;
    padding-right: 0.7rem;
}
</style>
