<template>
    <div>
        <div>
            <b-form-checkbox
                v-model="form.fixedPrice"
                @input="value => handleInput('fixedPrice', value)"
                class="mb-2"
                switch
            >
                Festpreis
            </b-form-checkbox>
            <p class="text-muted">
                Wenn Festpreis aktiviert wird, wird der Stückpreis nicht anhand der Stückkosten
                berechnet sondern kann direkt festgelegt werden. Dies kann die effektive Marge beeinflussen.
            </p>
        </div>

        <template v-if="form.fixedPrice">
            <FormInputAppend
                v-model="form.unitPrice"
                input-id="unitPrice"
                name="unitPrice"
                label-text="Stückpreis*"
                :error-conditions="errorConditions.unitPrice"
                prepended
                prepend="€"
                @input="value => handleInput('unitPrice', value)"
            />
            <p class="text-muted mt-2">
                Auf den hier erfassten Festpreis wird der Gemeinkostenzuschlag nachträglich
                angewendet. Bitte trage daher den Festpreis als TP1 ein.
            </p>
        </template>

        <template v-else>
            <div class="row">
                <div class="col-12 pl-0">
                    <FormSelect
                        v-model="form.preisfaktorType"
                        name="artDesPreisfaktors"
                        label-text="Art des Preisfaktors"
                        select-id="artDesPreisfaktors"
                        :options="options"
                        @input="value => handleInput('preisfaktorType', value)"
                    />
                </div>
                <div class="col-12 pr-0">
                    <FormInputAppend
                        v-model="form.preisfaktor"
                        @input="value => handleInput('preisfaktor', value)"
                        input-id="preisfaktor"
                        name="preisfaktor"
                        label-text="Preisfaktor*"
                        :disabled="form.preisfaktorType == 1"
                        :error-conditions="errorConditions.preisfaktor"
                        prepended
                        prepend="%"
                    />
                </div>
            </div>

            <div class="row">
                <div class="col-12 pl-0">
                    <FormSelect
                        v-model="form.margeType"
                        name="margeType"
                        label-text="Art der Marge"
                        select-id="margeType"
                        :options="options"
                        @input="value => handleInput('margeType', value)"
                    />
                </div>
                <div class="col-12 pr-0">
                    <FormInputAppend
                        v-model="form.marge"
                        @input="value => handleInput('marge', value)"
                        input-id="marge"
                        name="marge"
                        label-text="Marge*"
                        :disabled="form.margeType == 1"
                        :error-conditions="errorConditions.marge"
                        prepended
                        prepend="%"
                    />
                </div>
            </div>
        </template>
    </div>
</template>

<script>
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormCheckbox} from "bootstrap-vue";
import {mapGetters} from 'vuex';
import {isValidFloat} from "res/js/utils/Validators/NumbersValidators";
import {required, requiredIf} from "vuelidate/lib/validators";
import Formatter from "res/js/utils/formatter";

export default {
    name: "APprice",
    components: {
        FormInputAppend, FormSelect, BFormCheckbox
    },
    mounted() {
        let formatter = new Formatter;
        this.form.marge = formatter.numberToString(this.offerInfo.marge);
        this.form.preisfaktor = formatter.numberToString(this.offerInfo.preisfaktor);
    },
    data() {
        return {
            form: {
                fixedPrice: false,
                unitPrice: null,
                margeType: 1,
                preisfaktorType: 1,
                marge: null,
                preisfaktor: null
            },
            options: [{id: 1, text: 'Angebot'}, {id: 2, text: 'Individual'}]
        }
    },
    computed: {
        ...mapGetters({
            offerInfo: 'offer/offerInfo'
        }),

        errorConditions() {
            return {
                unitPrice: [
                    {
                        name: 'invalid-unitPrice-required',
                        condition: !this.$v.form.unitPrice.required && this.$v.form.unitPrice.$dirty,
                        text: this.$t.__('validation.required', {attribute: 'Stückpreis'})
                    },
                    {
                        name: 'invalid-unitPrice-intorfloat',
                        condition: !this.$v.form.unitPrice.isValidFloat && this.$v.form.unitPrice.$dirty,
                        text: 'Falscher Wert für das Feld Stückpreis.'
                    }
                ],
                marge: [
                    {
                        name: 'invalid-marge',
                        condition: !this.$v.form.marge.isValidFloat && this.$v.form.marge.$dirty,
                        text: 'Falscher Wert für das Feld Marge.'
                    }
                ],
                preisfaktor: [
                    {
                        name: 'invalid-preisfaktor',
                        condition: !this.$v.form.preisfaktor.isValidFloat && this.$v.form.preisfaktor.$dirty,
                        text: 'Falscher Wert für das Feld Preisfaktor.'
                    }
                ]
            }
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.resetValidation();
            this.$v.$touch();
            this.showValidationErrors = this.$v.$invalid;
            return this.$v;
        },
        /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
            this.showValidationErrors = false;
        },
        /**
         * Emit form object to parent component whenever any input is affected
         * @param field
         * @param value
         */
        handleInput(field, value) {
            this.form[field] = value;
            this.$emit('input', {...this.form});
        }
    },
    validations: {
        form: {
            unitPrice: {
                required: requiredIf(function (model) { return this.form.fixedPrice === true }),
                isValidFloat: (value, model) => {
                    return model.fixedPrice ? isValidFloat(value, 2, 16) : true;
                }
            },
            marge: {
                required: requiredIf(function (model) { return this.form.fixedPrice === false }),
                isValidFloat: value => {
                    return isValidFloat(value, 2, 7)
                }
            },
            preisfaktor: {
                required: requiredIf(function (model) { return this.form.fixedPrice === false }),
                isValidFloat: value => {
                    return isValidFloat(value, 2, 7)
                }
            }
        }
    }
}
</script>

<style scoped>

</style>
