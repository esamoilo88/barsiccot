<template>
    <div class="more-angebote-data">
        <div class="d-flex align-items-center mb-2">
            <FormSelect
                v-model="viewTypeSelected"
                class="view-type-select ml-auto w-25"
                @select="onViewTypeChange"
                label-text="Sichtweise"
                :select-id="`view-type-select+${ap.angebotspositionId}`"
                name="view-type-select"
                :options="viewTypesOptions"
                with-html
                with-html-selection
            />
            <button
                class="btn btn-secondary ml-2"
                @click="$emit('copy-ap')"
                :id="'copyApButton-' + ap.angebotspositionId"
                title="Angebotsposition kopieren"
                v-b-tooltip.hover.lefttop
            >
                <span class="icon-action-copy-paste-default"></span>
            </button>
        </div>

        <div class="quick-view py-2">
            <KalkulationMode
                v-if="modeType === 'calculation-mode'"
                :request="ap"
                :can-create-or-update="canCreateOrUpdate"
                @edit-element="editEl"
                @create-element="createEl"
                @create-ber="createBer"
                @edit-ber="editBer"
                @edit-lp="editLp"
                @copy-lp="copyLp"
            />
            <BillingMode
                v-else
                class="mt-3"
                :request="ap"
                :can-create-or-update="canCreateOrUpdate"
            />
        </div>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import KalkulationMode from "./KalkulationMode";
import BillingMode from "./BillingMode";
import {createOptions} from "@helpers/Form/InputsHelper";
import {VBTooltip} from 'bootstrap-vue';

export default {
    name: "ap-details",
    components: {KalkulationMode, BillingMode, FormSelect},
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        canCreateOrUpdate: {
            type: Boolean,
            required: true
        },
        ap: {
            type: Object,
            required: true
        },
        viewType: {
            type: String,
            required: true
        },
    },
    computed: {
        viewTypesOptions() {
            return createOptions(
                this.viewTypes,
                v => v.id,
                v => v.text,
                null,
                false,
                v => '<span class="' + v.icon + ' mr-1"></span> ' + v.text
            );
        },
        viewTypeSelected:
            {
                get() {
                    return this.viewType;
                },
                set(value) {
                    this.modeType = value;
                }
            }
    },
    data() {
        return {
            viewTypes: [
                {id: 'calculation-mode', text: "Kalkulation", icon: "icon-user_file-billing-default"},
                {id: 'billing-mode', text: "Verrechnung", icon: "icon-user_file-billing-default"}
            ],
            modeType: this.viewType
        }
    },
    methods: {
        editEl(item) {
            this.$emit('edit-element', item);
        },
        createEl(lpId) {
            this.$emit('create-element', lpId)
        },
        editBer(item) {
            this.$emit('edit-ber', item)
        },
        createBer(data) {
            this.$emit('create-ber', data);
        },
        copyLp(lp) {
            this.$emit('copy-lp', lp);
        },
        editLp(lp) {
            this.$emit('edit-lp', lp);
        },
        async onViewTypeChange(value) {
            this.viewTypeSelected = value;
        },
    }
}
</script>

<style lang="scss" scoped>
.quick-view {
    background-color: #ededed;
    border-radius: 5px;
    min-height: 85px;
}
.btn {
    padding-left: 0.7rem;
    padding-right: 0.7rem;
}
</style>
