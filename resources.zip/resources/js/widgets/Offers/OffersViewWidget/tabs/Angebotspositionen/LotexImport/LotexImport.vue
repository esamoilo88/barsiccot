<template>
    <div>
        <div class="simple-box box-shadow">
            <div class="d-flex">
                <h2> Lotex-Import</h2>
                <div class="ml-auto">
                    <a
                        class="mr-2"
                        @click="$emit('close-import-lotex')"
                        href="#"
                    >
                        Zurück
                    </a>
                </div>
            </div>

            <div v-if="!showResult" class="mt-4">
                <b-overlay :show="pending">
                    <div id="seceit-mpf">
                        <multi-page-form
                            ref="form"
                            :steps="[
                                {number: 1, icon: 'icon-action-upload-default'},
                                {number: 2, icon: 'icon-content-clipboard-default'},
                                {number: 3, icon: ' icon-user_file-file-default'},
                                {number: 4, icon: 'icon-action-succsess-default', lazy: true},
                            ]"
                            submit-button-text="Import starten"
                            :on-submit="onSubmit"
                            :active-step-prop="1"
                        >
                            <template #desc1>
                                <span> Datei auswählen </span>
                            </template>
                            <template #1>
                                <step :number="1" key="step1" :on-switch="validateFirstStep">
                                    <Step1 ref="step1" @prepared-array-for-display="(val) => arrayForDisplay = val"/>
                                </step>
                            </template>

                            <template #desc2>
                                <span> Datei prüfen   </span>
                            </template>
                            <template #2>
                                <step :number="2" key="step2">
                                    <LotexTablePreview
                                        table-id="lotex-list"
                                        :array-for-display="arrayForDisplay"/>
                                </step>
                            </template>

                            <template #desc3>
                                <span>Optionen einstellen</span>
                            </template>
                            <template #3>
                                <step :number="3" key="step3" :on-switch="validateThirdStep">
                                    <Step3 ref="step3"
                                           :array-for-display="arrayForDisplay"
                                           @final-data-for-display="getFinalDataForDisplay"
                                    />
                                </step>
                            </template>

                            <template #desc4>
                                <span>Vorschau</span>
                            </template>

                            <template #4>
                                <step :number="4" key="step4">
                                    <LotexTablePreview
                                        table-id="lotex-vorschau-list"
                                        :array-for-display="finalArrayForDisplay"
                                        :options="options"
                                    />

                                </step>
                            </template>
                        </multi-page-form>

                        <div class="d-flex">
                            <button @click="$emit('close-import-lotex')" class="btn btn-secondary mt-2 mx-auto">Abbrechen</button>
                        </div>
                    </div>
                </b-overlay>
            </div>

            <div v-else class="mt-4">
                <Results
                    @close-results="showResult = false"
                    @close="$emit('close-import-lotex')"
                    :result-errors="resultErrors"
                    :count-all="countAll"
                />
            </div>
        </div>
    </div>
</template>

<script>
import {BOverlay} from 'bootstrap-vue';
import MultiPageForm from "@comp/MultiPageForm/MultiPageForm";
import Step from "@comp/MultiPageForm/Step";
import Step1 from "./steps/Step1";
import LotexTablePreview from "./LotexTablePreview";
import Step3 from "./steps/Step3";
import Results from "./Results";
import Container from "@comp/QueueTasksStatus/Container";
import {mapGetters} from "vuex";

export default {
    name: "lotex-import",
    components: {
        Container, Results, Step1, LotexTablePreview, Step3, MultiPageForm, Step, BOverlay
    },
    computed: {
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        }),
        resultErrors(){
            return this.zusammenfassungError.concat(this.arrayForDisplay['arrSkippedRows']);
        }
    },
    data() {
        return {
            arrayForDisplay: {},
            finalArrayForDisplay: {},
            pending: false,
            countAll:0,
            zusammenfassungError:[],
            data: [],
            showResult: false,
            options: {},
            results: false
        }
    },
    methods: {
        validateFirstStep() {
            this.finalArrayForDisplay = {};
            this.options = {};
            return this.$refs.step1.validate();
        },
        validateThirdStep() {
            return this.$refs.step3.validate();
        },
        getFinalDataForDisplay(data, options) {
            this.finalArrayForDisplay = data;
            this.options = options;
        },
        async onSubmit() {
            this.pending=true;
            try {
                let response = await this.$axios.post(`/offers/${this.simpleId}/katalog/${this.currentVersion}/lotex/import`,
                    {options: this.options}
                );
                this.zusammenfassungError = response.data.zusammenfassungError;
                this.countAll = response.data.countAll;
                this.$eventBus.$emit('offerHeaderUpdate');
                this.showResult = true;
            } catch (err) {
                console.error(err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        goBack() {
            history.go(-1);
        }
    }
}
</script>
