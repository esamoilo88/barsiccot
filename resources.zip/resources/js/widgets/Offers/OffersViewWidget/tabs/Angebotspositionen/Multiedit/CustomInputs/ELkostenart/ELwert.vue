<template>
    <div>
        <b-overlay :show="pending">
            <div class="inputs-list d-flex justify-content-between">
                <FormInputAppend
                    v-model="wert"
                    @input="value => $emit('kostenwert-changed', value)"
                    @submit="$emit('submit')"
                    class=""
                    :key="'kostenwert'"
                    input-id="element-kostenwert"
                    name="kostenwert"
                    label-text="Kostenwert*"
                    prepend="€"
                    :error-conditions="[
                        {
                            name: 'empty-kostenwert',
                            condition: !$v.wert.required  && $v.wert.$dirty,
                            text: $t.__('validation.required', {attribute: 'Kostenwert'})
                        },{
                            name: 'wrong-format-kostenwert',
                            condition: !$v.wert.decimal  && $v.wert.$dirty,
                            text: $t.__('validation.wrong_data')
                        },
                    ]"
                />
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {
    BOverlay, BFormGroup, BFormRadioGroup,
    BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
} from 'bootstrap-vue';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {required, requiredIf} from 'vuelidate/lib/validators';

export default {
    name: "DependantInputs",
    components: {
        FormSelect, FormInputAppend, BOverlay, BFormGroup,
        BFormRadioGroup, BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
    },
    props: {
        kostenartObject: {
            type: Object,
            required: false
        },
        kostentype: {
            type: String,
            required: false
        }
    },
    data() {
        return {
            wert: null,
            pending: false
        }
    },
    computed: {
    },
    watch: {
        wert: {
            handler(newValue, oldValue) {
                this.$emit('input', newValue);
            }
        }
    },
    methods: {
        /**
         * Method for triggering validation from ELkostenart
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
        },
    },
    validations: {
        wert: {
            required: requiredIf(function (model) { return true; }),
            decimal(value) {
                return  String(value).match(/^\d+,?\d*$/) !== null;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.element-gmkz,
.element-kostenwert,
.element-aufwand {
    max-width: 32%;
}
.element-stundensatz {
    max-width: 22%;
}
.switches-list {
    margin-top: 30px;

    .inflationsfaktor-switch {
        margin-top: 25px;
    }

    .text-muted {
        margin-top: 10px;
    }
}

fieldset {
    margin-bottom: 0;
}

.berechnungsart-wrapper {
    padding-left: 2px;
}
</style>
