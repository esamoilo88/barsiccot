<template>
    <div>
        <modal-dialog
            modal-class="create-element-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-create-lp-modal')"
            title-dialog="Neue Leistungspositionen"
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <FormInput
                        v-model="lp.name"
                        @submit="onCreate"
                        input-id="lp-name"
                        name="lp-name"
                        label-text="Leistungsposition*"
                        class="lp-name"
                        :error-conditions="[
                            {
                                name: 'empty-name',
                                condition: !$v.lp.name.required  && $v.lp.name.$dirty,
                                text: $t.__('validation.required', {attribute: 'Name'})
                            }
                        ]"
                    />
                    <Leistungtyp
                        ref="leistungtyp"
                        @leistungtyp-selected="value => lp.leistungtyp = value"
                    />
                </div>

                <div class="simple-box mb-4">
                    <InflationsfaktorAndAnnuitat
                        ref="InflationsfaktorAndAnnuitat"
                        @inRessourcen-changed="value => lp.inRessourcen = value"
                        @inKosten-changed="value => lp.inKosten = value"
                        @AnZinssatz-changed="value => lp.AnZinssatz = value"
                        @AnLaufzeit-changed="value => lp.AnLaufzeit = value"
                        @AnKWert-changed="value => lp.AnKWert = value"
                        @submit="onCreate"
                    />
                </div>

                <div class="simple-box mb-4">
                    <OptionsAndDesc
                        ref="OptionsAndDesc"
                        @nachAufwand-changed="value => lp.nachAufwand = value"
                        @indirekteKosten-changed="value => lp.indirekteKosten = value"
                        @beschreibung-changed="value => lp.beschreibung = value"
                    />
                </div>

                <div class="simple-box">
                  <APList ref="apList" @change="apListChanged" />
                </div>
            </div>

            <template #footer="{methods}">
                <button v-if="canCreateLp" @click="onCreate" class="btn btn-primary">
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Leistungspositionen anlegen
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import {mapGetters} from 'vuex';
import FormSelect from "@comp/FormSelect/FormSelect";
import Leistungtyp from "./Leistungtyp";
import {required} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import InflationsfaktorAndAnnuitat from "./Inflationsfaktor&Annuitat";
import OptionsAndDesc from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebotspositionen/LP/Store/OptionsAndDesc";
import APList from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebotspositionen/LP/Store/APList";

export default {
    name: "StoreLP",
    components: {
      APList,
        OptionsAndDesc,
        InflationsfaktorAndAnnuitat,
        Leistungtyp,
        FormSelect,
        FormInput,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCreateLp: {
            type: Boolean,
            required: true,
            default: false
        }
    },
    data() {
        return {
            lp: {
                name: '',
                leistungtyp: null,
                inRessourcen: null,
                inKosten: null,
                AnZinssatz: null,
                AnLaufzeit: null,
                AnKWert: null,
                nachAufwand: false,
                indirekteKosten: false,
                beschreibung: null,
                aps: []
            },
            onCreatePending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        })
    },
    methods: {
        /**
         * Create LP
         * @returns {void}
         */
        async onCreate() {
            this.$v.$touch();
            let leistungtyp = this.$refs.leistungtyp.validate();
            let InflationsfaktorAndAnnuitat = this.$refs.InflationsfaktorAndAnnuitat.validate();
            let APList = this.$refs.apList.validate();
            if (!this.$v.$anyError && !leistungtyp.$anyError && !InflationsfaktorAndAnnuitat.$anyError && !APList.$anyError && APList.isMengeValid) {
                this.onCreatePending = true;
                try {
                    await this.$axios.post(`/offers/${this.simpleId}/calculations/lps`, {...this.lp});
                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    this.$eventBus.$emit('refreshLPList');
                    this.$emit('close-create-lp-modal');
                    window.flash.success('Leistungspositionen erfolgreich gespeichert.');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create LP", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCreatePending = false;
        },
        apListChanged(selected) {
            this.lp.aps = selected;
        },
    },
    validations: {
        lp: {
            name: {required}
        }
    }
}
</script>

<style lang="scss">
    .create-element-modal {
        .modal-dialog {
            min-width: 750px;
        }
    }
    .lp-name {
        margin-bottom: 15px;
    }
</style>
