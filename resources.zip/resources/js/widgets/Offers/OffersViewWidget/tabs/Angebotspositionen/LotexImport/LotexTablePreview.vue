<template>
    <div>
        <ErrorForm
            class="mb-5"
            v-if="this.arrSkippedRows.length > 0"
            :error-data="arrSkippedRows"
            :options="options"
        />
        <b-overlay :show="pending">
            <b-table :id="tableId"
                     ref="table"
                     :items="arrData"
                     :fields="fields"
                     :per-page="perPage"
                     :current-page="currentPage"
                     empty-text="Keine Daten vorhanden"
                     :show-empty ="pending"
            >
                <template #cell(angebotsposition)="data">
                    <template>{{ data.item.bezeichnung }}</template>
                </template>

                <template #cell(menge)="data">
                    {{ data.item.menge }}
                </template>

                <template #cell(stueckpreis)="data">
                    <div class="font-weight-bold">
                        <span class="sr-only">Stückpreis:</span>
                        {{ $f.numberToString(data.item.einzelpreis_dtts, true) }}
                    </div>
                </template>

                <template #cell(gesamtpreis)="data">
                    <div class="font-weight-bold">
                        <span class="sr-only">Gesamtpreis:</span>
                        {{ $f.numberToString(data.item.transferpreis_dtts, true) }}
                    </div>
                </template>


                <template #cell(gesamtkosten)="data">
                    <div class="font-weight-bold">
                        <span class="sr-only">Gesamtkosten:</span>
                        {{ $f.numberToString(data.item.gesamtkosten, true) }}
                    </div>
                </template>
                <template #cell(options)="data">
                    <div class="text-nowrap text-right">
                        <ButtonIcon
                            icon-class="icon-action-more-default"
                            button-class="details_class"
                            variant="light"
                            :title="row.item._showDetails ? 'Schließen Details':'Zeigen Details an'"
                            @click="toggleRowAnyway(data.item, 'id')"
                            hint-position="top"
                        />
                    </div>
                </template>
                <template #row-details="data">
                    <div class="d-flex">
                        <QuickViewSlot class="quickview" :key="data.item.id">
                            <LotexItemDetails
                                :request="arrayForDisplay['ARRDATALP'][data.index]"
                                :index-ap="data.index"
                                :array-for-display="arrayForDisplay"
                            />
                        </QuickViewSlot>
                    </div>
                </template>
            </b-table>

            <div class="pagination-wrapper" v-if="arrayForDisplay['ARRDATA']">
                <span class="total-rows-text">{{ paginationEntriesText }}</span>
                <b-pagination
                    v-model="currentPage"
                    :total-rows="arrayForDisplay['ARRDATA'].length"
                    :per-page="perPage"
                    aria-controls="lotex-list"
                ></b-pagination>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BTable, BOverlay, BPagination, BTr, BTd} from 'bootstrap-vue';

import TableSimple from "@comp/TableSimple/TableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import ErrorForm from "./ErrorForm";
import LotexItemDetails from "./LotexItemDetails";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import QuickViewMixin from "res/js/utils/Mixins/QuickView/QuickViewMixin";

export default {
    name: "LotexTable",
    components: {
        BTable, BOverlay, BPagination,BTr, BTd,
        TableSimple, ErrorForm, ButtonIcon, LotexItemDetails, QuickViewSlot
    },
    mixins: [Pagination,QuickViewMixin],
    props: {
        tableId: {
            type: String,
            required: false
        },
        arrayForDisplay: {
            type: Object,
            required: false,
            default: () => {}
        },
        options: {
            type: Object,
            required: false,
            default: () => {}
        }
    },
    data() {
        return {
            fields: [
                {key: "angebotsposition", label: "Angebotsposition"},
                {key: "menge", label: "Menge"},
                {key: "stueckpreis", label: "Stückpreis"},
                {key: "gesamtpreis", label: "Gesamtpreis"},
                {key: "gesamtkosten", label: "Gesamtkosten"},
                {key: "options", label: "Optionen"}
            ],
            perPage: 10,
            currentPage: 1,
            selectedAps: [],
            isAllSelected: false,
            isDirty: false,
            errors: [],
            pending:false
        }
    },
    computed:{
        arrSkippedRows(){
            return (this.arrayForDisplay['arrSkippedRows'])?this.arrayForDisplay['arrSkippedRows']:[];
        },
        arrData() {
            this.pending =true;
            if(this.arrayForDisplay['ARRDATA']){
                this.pending =false;
                return this.insertShowDetailsField(this.arrayForDisplay['ARRDATA'], 'id');
            }
            return [];
        },
        paginationEntriesText() {
            if (this.arrayForDisplay['ARRDATA'].length === 1) {
                return this.$t.__(this.entriesSingular);
            } else {
                return this.$t.__(this.entriesPlural, {entries: this.arrayForDisplay['ARRDATA'].length});
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.lps-select-wrapper {
    max-width: 630px;
}
::v-deep .quick-view {
    width: 100%;
}
::v-deep .lp-box {
    border-bottom: 1px solid lightgrey;
}

.error-message {
    color: $error;
}
</style>
