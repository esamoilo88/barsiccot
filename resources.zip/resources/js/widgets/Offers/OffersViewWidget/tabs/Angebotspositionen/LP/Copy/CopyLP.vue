<template>
    <div>
        <modal-dialog
            modal-class="create-element-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-copy-lp-modal')"
            title-dialog="Leistungsposition kopieren"
        >
            <div class="d-flex flex-column">
                <div class="simple-box">
                  <APList
                      ref="apList"
                      :lp-menge="lpData.menge"
                      @aps-changed="value => {lp.aps.splice(0); lp.aps.push(...value)}"
                  />
                </div>
            </div>

            <template #footer="{methods}">
                <button v-if="canCopyLp" @click="onCopy" class="btn btn-primary">
                    <b-spinner v-if="onCopyPending" small></b-spinner>
                    Leistungsposition kopieren
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import {mapGetters} from 'vuex';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import APList from "./APList";

export default {
    name: "CopyLP",
    components: {
      APList,
        FormInput,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCopyLp: {
            type: Boolean,
            required: true,
            default: false
        },
        lpData: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            lp:{
                aps: [],
            },
            onCopyPending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        })
    },
    methods: {
        /**
         * Copy LP
         * @returns {void}
         */
        async onCopy() {
            if (this.$refs.apList.isValid()) {
                this.onCopyPending = true;
                let lpId = parseInt(this.lpData.leistungspositionId);
                try {
                    await this.$axios.post(`/offers/${this.simpleId}/calculations/lps/${lpId}/copy`, {...this.lp});
                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    this.$eventBus.$emit('refreshLPList');
                    this.$emit('close-copy-lp-modal');
                    window.flash.success('Leistungsposition erfolgreich kopiert.');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't copy LP", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCopyPending = false;
        }
    }
}
</script>

<style lang="scss">
    .create-element-modal {
        .modal-dialog {
            min-width: 750px;
        }
    }
    .lp-name {
        margin-bottom: 15px;
    }
</style>
