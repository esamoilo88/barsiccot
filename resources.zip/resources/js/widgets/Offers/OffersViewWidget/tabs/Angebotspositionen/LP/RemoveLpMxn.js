import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    components: {ConfirmationModal},
    methods: {
        async deleteLp(lp, simpleId, currentVersion) {
            const confirmed = await this.showConfirmationModal({
                title: 'Leistungsposition löschen',
                message: `Bitte bestätige die Löschung der Leistungsposition ${lp.bezeichnung}.`,
                okTitle: 'Leistungsposition löschen',
            });

            if (!confirmed) return;

            window.preloader.show();

            try {
                await this.$axios.delete(`/offers/${simpleId}/vkVersions/${currentVersion}/lp/${lp.leistungspositionId}`);

                window.flash.success('Leistungsposition erfolgreich gelöscht');

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
