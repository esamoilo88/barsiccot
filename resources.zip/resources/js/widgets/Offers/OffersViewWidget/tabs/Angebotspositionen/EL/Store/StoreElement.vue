<template>
    <div>
        <modal-dialog
            modal-class="create-element-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-store-element-modal')"
            :title-dialog="elementToUpdate === null ? 'Neues Element' : 'Element Bearbeiten'"
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <FormInput
                        v-model="element.name"
                        @submit="onCreate"
                        @change="val => onUserChangeField({field: 'name', value: val})"
                        input-id="element-name"
                        name="element-name"
                        label-text="Name*"
                        :error-conditions="[
                            {
                                name: 'empty-name',
                                condition: !$v.element.name.required  && $v.element.name.$dirty,
                                text: $t.__('validation.required', {attribute: 'Name'})
                            }
                        ]"
                    />
                    <Kostenart
                        ref="kostenart"
                        v-model="element.kostenart"
                        :element-to-update="elementToUpdate"
                        @change="onUserChangeField"
                    />
                </div>

                <div class="simple-box mb-4">
                    <Berechnungsart
                        ref="berechnungsart"
                        @berechnungsart-changed="value => element.berechnungsart = value"
                        @stundensatz-changed="value => element.stundensatz = value"
                        @gmkz-changed="value => element.gmkz = value"
                        @aufwand-changed="value => element.zeitstunden = value"
                        @kostenwert-changed="value => element.kostenwert = value"
                        @ma-changed="value => element.ma = value"
                        @inflation-changed="value => element.inflation = value"
                        @submit="onCreate"
                        @change="onUserChangeField"
                        :kostenart="element.kostenart"
                        :element-to-update="elementToUpdate"
                    />
                </div>

                <div v-if="elementToUpdate === null && isSingleCreate === false" class="simple-box mb-4">
                    <LPList @lps-changed="value => {element.lps.splice(0); element.lps.push(...value)}" ref="lpList"/>
                </div>

                <div class="simple-box">
                    <KostenstelleAndBeschreibung
                        ref="kostenstelleAndBeschreibung"
                        @kostenstelle-changed="value => (element.kostenstelle = value)"
                        @beschreibung-changed="value => (element.beschreibung = value)"
                        :element-to-update="elementToUpdate"
                        @change="onUserChangeField"
                    />
                </div>
            </div>

            <template #footer="{methods}">
                <button
                    v-if="canCreateElement && elementToUpdate === null"
                    :key="'store-element-btn'"
                    @click="onCreate"
                    class="btn btn-primary"
                    :disabled="onCreatePending"
                >
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Element anlegen
                </button>
                <button
                    v-if="canCreateElement && elementToUpdate !== null"
                    :key="'update-element-btn'"
                    @click="onUpdate"
                    class="btn btn-primary"
                    :disabled="onCreatePending"
                >
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Element bearbeiten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import {mapGetters} from 'vuex';
import FormSelect from "@comp/FormSelect/FormSelect";
import Kostenart from "./Kostenart";
import Berechnungsart from "./Berechnungsart";
import LPList from "./LPList";
import KostenstelleAndBeschreibung from "./KostenstelleAndBeschreibung";
import {required} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "StoreElement",
    components: {
        KostenstelleAndBeschreibung,
        LPList,
        Berechnungsart,
        Kostenart,
        FormSelect,
        FormInput,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCreateElement: {
            type: Boolean,
            required: true,
            default: false
        },
        elementToUpdate: {
            type: Object,
            required: false,
            default: null
        },
        isSingleCreate: { // if we create a single EL for the specific LP
            type: Boolean,
            required: false,
            default: false
        },
        parentLpId: { // necessary if isSingleCreate is true
            type: Number,
            required: false
        }
    },
    data() {
        return {
            element: {
                name: this.elementToUpdate !== null ? this.elementToUpdate.bezeichnung : '',
                kostenart: this.elementToUpdate !== null ? this.elementToUpdate.kostenart : null,
                berechnungsart: 'Aufwand',
                stundensatz: null,
                gmkz: null,
                aufwand: null,
                kostenwert: null,
                ma: false,
                inflation: true,
                kostenstelle: null,
                beschreibung: null,
                zeitstunden: null,
                lps: []
            },
            isDirty: false,
            fieldsToUpdate: {},
            onCreatePending: false
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        })
    },
    created() {
        if (this.isSingleCreate) {
            this.element.lps.push(this.parentLpId);
        }
    },
    methods: {
        /**
         * Create EL
         * @returns {void}
         */
        async onCreate() {
            this.$v.$touch();
            let kostenart = this.$refs.kostenart.validate();
            let berechnungsart = this.$refs.berechnungsart.validate();
            let lpListErrors = !this.parentLpId ? this.$refs.lpList.validate().$anyError : false;
            if (!this.$v.$anyError && !kostenart.$anyError && !berechnungsart.$anyError && !lpListErrors) {
                this.onCreatePending = true;
                try {
                    const res = await this.$axios.post(`/offers/${this.simpleId}/calculations/els`, {...this.prepareData()});
                    this.showMessages(res.data.creationErrors);
                    this.$eventBus.$emit('offerHeaderUpdate');
                    this.$eventBus.$emit('refreshAPList');
                    this.$emit('close-store-element-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create EL", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCreatePending = false;
        },
        /**
         * Update EL
         * @returns {void}
         */
        async onUpdate() {
            if (this.isDirty) {
                this.$v.$touch();
                let kostenart = this.$refs.kostenart.validate();
                let berechnungsart = this.$refs.berechnungsart.validate();
                if (!this.$v.$anyError && !kostenart.$anyError && !berechnungsart.$anyError) {
                    this.onCreatePending = true;
                    try {
                        const res = await this.$axios.post(`/offers/${this.simpleId}/calculations/els/${this.elementToUpdate.elementId}`,
                            {...this.prepareData(this.fieldsToUpdate)}
                        );
                        window.flash.showMessagesFromAjax(res.data);
                        this.$eventBus.$emit('offerHeaderUpdate');
                        this.$eventBus.$emit('refreshAPList');
                        this.$emit('close-store-element-modal');
                    } catch (err) {
                        window.flash.showMessagesFromAjax(err.response.data);
                        console.error("Couldn't update EL", err);
                    }
                } else {
                    navigateToFirstInvalid();
                }
                this.onCreatePending = false;
            } else {
                this.$emit('close-store-element-modal');
            }
        },
        /**
         * Map data from component object to request object
         * @returns {Object} element
         */
        prepareData(fieldsToUpdate = null) {
            const condition = (field) => this.fieldsToUpdate[field] !== undefined || fieldsToUpdate === null;
            let element = {};
            condition('name')           && (element.bezeichnung    = this.element.name);
            condition('kostenart')      && (element.kostenart      = this.element.kostenart.kostenartId);
            condition('berechnungsart') && (element.berechnungsart = this.element.berechnungsart);
            condition('stundensatz')    && (element.stundensatz    = this.element.stundensatz);
            condition('gmkz')           && (element.gmkz           = this.element.gmkz);
            condition('kostenwert')     && (element.wert           = this.element.kostenwert);
            condition('ma')             && (element.ma             = this.element.ma);
            condition('inflation')      && (element.ifApply        = this.element.inflation);
            condition('kostenstelle')   && (element.kostenstelle   = this.element.kostenstelle);
            condition('beschreibung')   && (element.beschreibung   = this.element.beschreibung);
            condition('zeitstunden')    && (element.zeitstunden    = this.element.zeitstunden);
            fieldsToUpdate === null && (element.lps = this.element.lps);
            return element;
        },
        /**
         * Show success or error messages
         * @param creationErrors
         */
        showMessages(creationErrors) {
            let errorsNumber = Object.entries(creationErrors).length;
            if (errorsNumber > 0) {
                if (this.element.lps.length !== errorsNumber) {
                    let savedNumber = this.element.lps.length - errorsNumber;
                    window.flash.success(`${savedNumber} von ${this.element.lps.length} Elementen erfolgreich gespeichert`);
                }
                for (let lp in creationErrors) {
                    creationErrors[lp].map(errorMsg => window.flash.error(errorMsg));
                }
            } else {
                window.flash.success('Elemente erfolgreich gespeichert');
            }
        },
        /**
         * Determine which fields user changed during element update process.
         * We need to separate those changes from programmatic changes which we do
         * inside our components during initialization and other internal processes
         * @param obj - {field, value}
         */
        onUserChangeField(obj) {
            this.isDirty = true;
            if (this.fieldsToUpdate[obj.field] === undefined) {
                this.$set(this.fieldsToUpdate, obj.field, obj.value);
            } else {
                this.fieldsToUpdate[obj.field] = obj.value;
            }
        }
    },
    validations: {
        element: {
            name: {required}
        }
    }
}
</script>

<style lang="scss">
.create-element-modal {
    .modal-dialog {
        min-width: 750px;
    }
}
</style>
