<template>
    <div>
        <b-overlay :show="pending">
            <b-form-group>
                <FormSelect
                    v-model="form.producttype"
                    @change="$emit('input', form.producttype)"
                    :options="producttypes"
                    :error-conditions="errorConditions.producttype"
                    label-text="Produkttyp*"
                    name="producttypeId"
                    select-id="producttypeId"
                    searchable
                />
            </b-form-group>

            <b-form-group>
                <div class="row">
                    <div class="col-6">Mengentyp:</div>
                    <div class="col-auto"><strong>{{ producttype.mengentypName }}</strong></div>
                </div>
                <div class="row">
                    <div class="col-6">Preistyp:</div>
                    <div class="col-auto"><strong>{{ producttype.preistypName }}</strong></div>
                </div>
            </b-form-group>
        </b-overlay>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {BFormGroup, BOverlay} from 'bootstrap-vue';
import {integer, required} from "vuelidate/lib/validators";

export default {
    name: "APprodukttyp",
    components: {
        FormSelect, BFormGroup, BOverlay
    },
    async mounted() {
        await this.getProducttypes();
    },
    data() {
        return {
            form: {
                producttype: null
            },
            producttype: {
                mengentypName: null,
                preistypName: null,
            },
            producttypes: [],
            pending: false,
            showValidationErrors: false
        }
    },
    watch: {
        'form.producttype': function () {
            this.onProducttypeInput(this.form.producttype)
        }
    },
    computed: {
        errorConditions() {
            return {
                producttype: [
                    {
                        name: 'invalid-producttype',
                        condition: this.isInvalid('producttype', 'required'),
                        text: 'Produkttyp muss ausgefüllt werden.'
                    }
                ],
            }
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.resetValidation();
            this.$v.$touch();
            this.showValidationErrors = this.$v.$invalid;
            return this.$v;
        },
        /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
            this.showValidationErrors = false;
        },
        async getProducttypes() {
            this.pending = true;
            try {
                const response = await this.$axios.get(`/onka/producttypes`);
                this.producttypes = response.data;
            } catch (error) {
                console.error("Couldn't fetch producttypes", error.response.data);
            }
            this.pending = false;
        },
        onProducttypeInput(id) {
            const producttype = this.producttypes.find(item => item.id == id);
            if (producttype) {
                this.producttype = producttype
            }
            this.$emit('input', this.form.producttype);
        },
        isInvalid(field, rule) {
            if (rule) {
                return this.showValidationErrors && !this.$v.form[field][rule];
            }
            return this.showValidationErrors && this.$v.form[field].$invalid;
        },
    },
    validations: {
        form: {
            producttype: {
                required,
                integer
            }
        }
    }
}
</script>

<style scoped>
</style>
