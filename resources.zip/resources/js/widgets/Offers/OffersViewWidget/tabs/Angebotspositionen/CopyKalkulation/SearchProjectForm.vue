<template>
    <div>
        <div v-if="totalRows > 0">
            <project-item
                v-for="(item, index) in searchData"
                :item-prop="item"
                :simple-id-item="index"
                :key="index"
                @copy-onka="value => copyVersion(value)"
                :copied-onka="copiedVersions"
                :processing-onka="processingOnka"
            />
        </div>

        <div v-else-if="clearForm === false" class="text-center">
            Keine Daten vorhanden
        </div>

        <Pagination
            v-model="currentPage"
            @input="search"
            v-if="totalRows > 0"
            :per-page-prop="perPage"
            :current-page="currentPage"
            table-id="customer-items-list"
            :total-rows-prop="totalRows"
        />
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {
    BButton,
    BModal,
    BTable,
    BCol,
    BRow,
    BInputGroup,
    BPagination
} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import ProjectItem from "./ProjectItem"
import Pagination from "@comp/Pagination/Pagination";

export default {
    name: "search-project-form",
    components: {
        FormInput,
        BButton,
        BModal,
        BTable,
        BCol,
        BRow,
        BInputGroup,
        BPagination,
        ProjectItem,
        FormSelect,
        Pagination
    },
    props: {
        targetSin: {
            required: true,
            type: Number
        },
        searchProject: {
            required: true,
            type: String
        }
    },
    data() {
        return {
            totalRows: 0,
            currentPage: 1,
            perPage: (window.innerHeight > 700) ? 10 : 5,
            sortDesc: false,
            sortDirection: 'asc',
            searchString: this.searchValue,
            searchData: [],
            clearForm: true,
            copiedVersions: [],
            processingOnka: [],
            previousSearchString: null,
        }
    },
    methods: {
        async search() {
            window.preloader.show();

            let data = {
                filter: {"search": this.searchProject},
                currentPage: this.previousSearchString === this.searchProject ? this.currentPage : 1,
                perPage: this.perPage,
                sortDesc: true,
                searchByAp: false
            }

            this.currentPage = data.currentPage;
            try {
                const response = await this.$axios.post('/copy-onka/search', data);
                this.orderResult(response.data.data);
                this.totalRows = response.data.total;
                this.clearForm = false;
                this.previousSearchString = this.searchProject
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data, 'error');
            } finally {
                window.preloader.hide();
            }
        },
        orderResult(data) {
            let result = {};

            for (let key in data) {
                if (data.hasOwnProperty(key)) {
                    let simpleId = data[key].simpleId;
                    if (!result[simpleId]) {
                        result[simpleId] = [];
                    }
                    result[simpleId].push(data[key]);
                }
            }

            this.searchData = result;
        },
        async copyVersion(vkVersionId) {
            this.processingOnka.push(vkVersionId);

            try {
                await this.$axios.post(`/offers/${this.targetSin}/copy-onka/${vkVersionId}`);
                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');
                this.copiedVersions.push(vkVersionId);
                window.flash.success('Kalkulation erfolgreich importiert.');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                this.processingOnka = this.processingOnka.filter(version => version !== vkVersionId);
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.spinner {
    position: relative;
    padding: 40px;
    left: 45%
}

.input-tooltip {
    position: absolute;
    right: -30px;
    top: 15px;
}

.table {
    table-layout: fixed
}

.input-group {
    flex-wrap: nowrap;
}

.search-box {
    display: flex;
    grid-template-columns: 1fr 40px;

    .icon-container {
        padding-top: 14px;
        text-align: center;
    }

}
.pagination-wrapper {
    display: flex;
    align-items: center;
    position: relative;

    & > span {
        position: absolute;
    }

    .pagination.b-pagination {
        margin: 0 auto;
    }

    .total-rows-text {
        margin-left: 20px;
    }
}
</style>
