export default {
    data() {
        return {
            isBERFormActive: false,
            berToUpdate: null,
            berTargetObj: null // object for which we create BER
        }
    },
    methods: {
        createBER(objectType = null, objectId = null) {
            this.isBERFormActive = true;
            this.berTargetObj = objectId !== null && objectType !== null ? {type: objectType, id: objectId} : null;
        },
        updateBER(ber) {
            this.isBERFormActive = true;
            this.berToUpdate = ber;
        },
        closeBERDialog() {
            this.berTargetObj = null;
            this.berToUpdate = null;
            this.isBERFormActive = false;
        }
    }
}
