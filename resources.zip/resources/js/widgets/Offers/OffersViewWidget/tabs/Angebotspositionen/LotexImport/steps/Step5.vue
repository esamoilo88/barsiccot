<template>
    <div>
        <b-overlay :show="pending">
            <div v-if="!pending">
                <div class="mb-4 mt-2">
                    <div v-if="zusammenfassungError !== [] && countAll === 0" class="d-flex align-items-center mb-2">
                        <img
                            class="icon-info mr-2"
                            :src="'/img/icons/error_graphical.svg'"
                            :alt="'fehler'"
                        />
                        <span>Es konnten keine Daten importiert werden.</span>
                    </div>
                    <div v-if="zusammenfassungError.length > 0 && countAll > 0" class="d-flex align-items-center mb-2">
                        <img
                            class="icon-info mr-2"
                            :src="'/img/icons/warning_graphical.svg'"
                            :alt="'warning'"
                        />
                        <span>Es konnten nicht alle Daten importiert werden.</span>
                    </div>
                    <div v-if="zusammenfassungError.length === 0" class="d-flex align-items-center mb-2">
                        <img
                            class="icon mr-2"
                            :src="'/img/icons/confirm_graphical.svg'"
                            :alt="'erfolgreich'"
                        />
                        <span> Alle Daten wurden erfolgreich importiert.</span>
                    </div>
                </div>
                <div v-if="zusammenfassungError.length > 0">
                        <span v-if="countAll > 0">
                            {{ importedElText }}
                        </span>
                    <b-table
                        responsive
                        :fields="fields"
                        :items="zusammenfassungError"
                        striped
                    >
                        <template #cell(message)="row">
                            <truncated-text
                                :text="row.item.message"
                                title="Fehler Anzeigen"
                                :width=450
                                :max-length="80"
                            />
                        </template>
                        <template #cell(type)="row">
                            <img
                                class="icon mr-2"
                                :src="'/img/icons/' + (row.item.type === 'error' ? 'error_graphical' : 'warning_graphical') + '.svg'"
                                :alt="row.item.type === 'error' ? 'error' : 'warning'"
                            />
                        </template>
                    </b-table>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BSpinner, BOverlay, BTable, BButton} from "bootstrap-vue";
import TruncatedText from "@comp/TruncatedText/TruncatedText";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import DetailsLBU from "res/js/widgets/Orders/OrdersViewWidget/tabs/LBU/Excel/DetailsLBU";
import {mapGetters} from "vuex";

export default {
    name: "Step5",
    components: {
        DetailsLBU,
        BSpinner, BOverlay, BTable, TruncatedText, BButton, ButtonIcon
    },
    mixins: [DatesProcessing],
    computed: {
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        }),
        importedElText() {
            if (this.countAll === 1) {
                return '1 Element wurde erfolgreich importiert';
            } else {
                return `${this.countAll} Elemente wurden erfolgreich importiert`;
            }
        }
    },
    data() {
        return {
            fields: [
                {key: 'type', label: 'Typ'},
                {key: 'message', label: 'Fehler'}
            ],
            zusammenfassungError: [],
            countAll: null,
            pending: false
        }
    }
}
</script>

<style scoped>
.icon-info {
    width: 32px;
}

.icon {
    width: 26px;
}
</style>
