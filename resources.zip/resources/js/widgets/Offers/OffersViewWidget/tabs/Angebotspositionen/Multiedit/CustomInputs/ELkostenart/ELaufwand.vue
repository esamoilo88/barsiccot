<template>
    <div>
        <b-overlay :show="pending">
            <span style="margin-left: 3px">Aufwand (hhh:mm:ss):*</span>
            <div class="inputs-list d-flex justify-content-between">
                <div>
                    <div :class="{'invalid': aufwandValidation, 'd-flex align-items-center p-1': true}">
                        <b-form-input
                            v-model="form.hour"
                            :key="'hour'"
                            @input="value => $emit('hour-changed', value)"
                            @change="value => $emit('change', {field: 'hour', value})"
                            id="hour"
                            name="hour"
                            class="width-aufwand"
                        />
                        <span class="mr-1 ml-1 font-weight-bold"> : </span>
                        <b-form-input
                            v-model="form.minute"
                            :key="'minute'"
                            @input="value => $emit('minute-changed', value)"
                            @change="value => $emit('change', {field: 'minute', value})"
                            id="minute"
                            name="minute"
                            class="width-aufwand"
                        />
                        <span class="mr-1 ml-1 font-weight-bold"> : </span>
                        <b-form-input
                            v-model="form.second"
                            :key="'second'"
                            @input="value => $emit('second-changed', value)"
                            @change="value => $emit('change', {field: 'second', value})"
                            id="second"
                            name="second"
                            class="width-aufwand"
                        />
                    </div>
                    <div
                        v-if="aufwandValidation"
                        class="error-message my-2">
                        <span
                            :class="{'invalid-feedback': true, 'd-block': aufwandValidation}"
                            role="alert"
                            aria-live="assertive"
                            aria-atomic="true"
                        >
                            Aufwand muss ausgefüllt werden (gültig: hhh:mm:ss)
                        </span>
                    </div>
                </div>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {
    BOverlay, BFormGroup, BFormRadioGroup,
    BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
} from 'bootstrap-vue';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {requiredIf} from 'vuelidate/lib/validators';
import {
    aufwandHourValidator,
    aufwandMinuteValidator, aufwandSecondValidator
} from "res/js/utils/Validators/SimpleCommonValidators";

export default {
    name: "DependantInputs",
    components: {
        FormSelect, FormInputAppend, BOverlay, BFormGroup,
        BFormRadioGroup, BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
    },
    props: {
        kostenartObject: {
            type: Object,
            required: false
        },
        kostentype: {
            type: String,
            required: false
        }
    },
    data() {
        return {
            form: {
                hour: null,
                minute: null,
                second: null
            },
            pending: false
        }
    },
    computed: {
        aufwandValidation() {
            return (!this.$v.form.hour.required && this.$v.form.hour.$dirty) ||
                (!this.$v.form.hour.format && this.$v.form.hour.$dirty) ||
                (!this.$v.form.minute.required && this.$v.form.minute.$dirty) ||
                (!this.$v.form.minute.format && this.$v.form.minute.$dirty) ||
                (!this.$v.form.second.required && this.$v.form.second.$dirty) ||
                (!this.$v.form.second.format && this.$v.form.second.$dirty)
        }
    },
    watch: {
        form: {
            deep: true,
            handler(newValue, oldValue) {
                this.$emit('input', newValue);
            }
        }
    },
    methods: {
        /**
         * Method for triggering validation from ELkostenart
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Reset validation
         */
        resetValidation() {
            this.$v.$reset();
        },
    },
    validations: {
        form: {
            hour: {
                required: requiredIf(function (model) {
                    return true;
                }),
                format(value) {
                    return  aufwandHourValidator(value);
                }
            },
            minute: {
                required: requiredIf(function (model) {
                    return true;
                }),
                format(value) {
                    return aufwandMinuteValidator(value);
                }
            },
            second: {
                required: requiredIf(function (model) {
                    return true;
                }),
                format(value) {
                    return aufwandSecondValidator(value);
                }
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.element-gmkz,
.element-kostenwert,
.element-aufwand {
    max-width: 32%;
}
.element-stundensatz {
    max-width: 22%;
}
.switches-list {
    margin-top: 30px;

    .inflationsfaktor-switch {
        margin-top: 25px;
    }

    .text-muted {
        margin-top: 10px;
    }
}

fieldset {
    margin-bottom: 0;
}

.berechnungsart-wrapper {
    padding-left: 2px;
}
</style>
