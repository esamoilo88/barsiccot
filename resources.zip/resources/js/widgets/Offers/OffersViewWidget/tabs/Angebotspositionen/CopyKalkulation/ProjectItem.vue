<template>
    <div class="simple-box configuration-item my-3">
            <div class="mb-3">
                <span class="font-weight-bold"> {{"SIN/" + simpleIdItem}} · </span> {{ projectName }}
            </div>
        <b-table
            responsive
            :fields="fields"
            :items="itemProp"
        >
            <template #cell(versionsgrund)="row">
                <truncated-text
                    :text="row.item.versionsgrund"
                    title="Versionsgrund"
                    :width=150
                />
            </template>
            <template #cell(vkGesamt)="row">
                <span class="font-weight-bold"> {{ $f.numberToString(row.item.vkGesamt, true, false, '0,00 €') }} </span>
            </template>
            <template #cell(totalPrice)="row">
                <span class="font-weight-bold"> {{ $f.numberToString(row.item.totalPrice, true, false, '0,00 €' ) }} </span>
            </template>
            <template #cell(options)="row">
                <div class="text-nowrap">
                    <template>
                        <b-spinner
                            v-if="isProcessing(row.item.vkVersionsId)"
                            small
                        />
                        <ButtonIcon
                            v-else
                            icon-class="icon-action-download-default"
                            :variant=getVariant(row.item.vkVersionsId)
                            @click="$emit('copy-onka', row.item.vkVersionsId)"
                            title="Kalkulation importieren"
                            v-b-tooltip.hover
                        />
                    </template>
                </div>
            </template>
        </b-table>
    </div>
</template>
<script>
import {BButton, BTable, BBadge, BSpinner, VBTooltip} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';
import {mapGetters} from "vuex";
import TruncatedText from "@comp/TruncatedText/TruncatedText";

export default {
    name: "ProjectItem",
    components: {
        BButton, BTable, ButtonIcon, BBadge, BSpinner, TruncatedText
    },
    props: {
        itemProp: {
            type: Array,
            required: true
        },
        simpleIdItem: {
            required: true
        },
        copiedOnka: {
            type: Array,
            required: true
        },
        processingOnka: {
            type: Array,
            required: true
        },
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    data() {
        return {
            item: this.itemProp,
            isDetailsVisible: false,
            projectName: this.itemProp[0].thema,
            fields: [
                {key: 'versionsnr', label: 'Versions-Nr',},
                {key: 'vkGesamt', label: 'Gesamtkosten',},
                {key: 'totalPrice', label: 'Gesamtpreis',},
                {key: 'versionsgrund', label: 'Versionsgrund'},
                {key: 'options', label: 'Optionen'},
            ]
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        })
    },
    methods: {
        getVariant(vkVersionId) {
            return this.copiedOnka.includes(vkVersionId) ? 'secondary': 'primary';
        },
        isProcessing(vkVersionId) {
            return this.processingOnka.includes(vkVersionId);
        }
    }
}
</script>
<style lang="scss" scoped>

</style>
