<template>
    <b-overlay :show="dataLoading">
        <div class="font-weight-bold">Bitte wähle eine Lotex Datei im XML-Format aus.</div>
        <div class="simple-box pr-5 mb-4">
            <form-file-load
                v-model="file"
                ref="file"
                type="file"
                browse-text="Auswählen"
                @uploadFile="upload"
                placeholder="Lotex Datei auswählen / drag&drop"
                accept=".xml"
                class="mt-3 w-50"
                :error-conditions="errorConditions.file"
            />
        </div>
    </b-overlay>

</template>

<script>
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import {BSpinner, BOverlay, BTable} from "bootstrap-vue";
import {mapGetters, mapActions} from "vuex";
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import FormFileLoad from '@comp/FileLoad/FormFileLoad'
import {required} from 'vuelidate/lib/validators';
import Validation from "@mixins/Validation/Validation";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";


export default {
    name: "Step1",
    components: {
        ModalDialog, BSpinner, BOverlay, FormFileLoad, BTable
    },
    mixins: [Validation, ObjectsProcessing],
    computed: {
        ...mapGetters({
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        }),
        errorConditions() {
            return {
                file: [
                    {
                        name: 'file-required',
                        condition: !this.$v.file.required && this.isDirty,
                        text: this.$t.__('validation.required', {attribute: 'eine Lotex XML-Datei'})
                    }
                ]
            }
        }
    },
    data() {
        return {
            isDirty: false,
            pending: false,
            dataLoading: false,
            attachedFile: null,
            file: {},
            showErrorForm: false,
            showSuccessForm: false,
            successData: [],
            errorData: []
        }
    },
    methods: {
        ...mapActions({
            refreshOrderData: 'order/fetchOrderData'
        }),
        validate() {
            this.isDirty = true;
            this.$v.file.$touch();
             if (this.$v.file.$invalid) {
                 this.showValidationErrors = true;
                 navigateToFirstInvalid();
                 return false;
             }
            this.clearFile();
            this.showValidationErrors = false;
            return true;
        },
        async upload(filesInfo) {
            this.dataLoading = true;
            try {
                let res = await this.$axios.post(`/offers/${this.simpleId}/katalog/${this.currentVersion}/lotex/first-preview`,
                    filesInfo.formData
                );
                this.$emit('prepared-array-for-display', res.data);
                this.$emit('arr-skipped-rows', res.data.arrSkippedRows);

            } catch (err) {
                console.error(err);
                window.flash.showMessagesFromAjax(err.response.data);
            } finally {
                this.dataLoading = false;
            }
        },
        clearFile() {
            this.file = {};
            this.$refs.file.clearFiles();
            this.dataLoading = false;
        },
    },
    validations: {
        file: {required}
    }
}
</script>

