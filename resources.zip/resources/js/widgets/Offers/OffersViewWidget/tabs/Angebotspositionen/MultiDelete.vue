<template>
    <div>
        <b-dropdown-item-button v-if="canDelete" @click="showModal">
            <span class="icon-action-remove-default pr-2"></span>
            Mehrfachlöschung
        </b-dropdown-item-button>

        <modal-dialog
            :is-visible="isModalVisible"
            @hideModal="hideModal"
            title-dialog="Mehrfachlöschung"
            modal-class="multi-delete-dialog"
        >
            <div class="simple-box">
                <b-form-group>
                    <p class="text-muted">
                        Bitte wähle den Objekttyp und die gewünschten Einträge aus die gelöscht werden sollen.
                    </p>

                    <FormSelect
                        v-model="form.objectType"
                        :options="objectTypes"
                        name="objectType"
                        select-id="objectType"
                        label-text="Objekt"
                        @input="onObjectTypeInput"
                    />
                </b-form-group>

                <b-form-group>
                    <template v-if="form.objectType">
                        <span class="text-muted" v-if="!itemsLength()">Keine Einträge vorhanden</span>

                        <table class="table">
                            <tbody>
                                <tr class="table-secondary">
                                    <td v-if="itemsLength()">
                                        <b-form-checkbox v-model="form.selectAll" @change="onSelectAllChange">Alle auswählen</b-form-checkbox>
                                    </td>
                                </tr>
                                <tr v-for="item in items[form.objectType]" :key="item.id">
                                    <td>
                                        <b-form-checkbox
                                            v-model="form.selected"
                                            :value="item.id"
                                            @change="onItemChange">
                                            <span class="text-muted">
                                                {{ getParent(item) }}
                                            </span>
                                            {{ item.name }}
                                        </b-form-checkbox>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </template>
                </b-form-group>
            </div>

            <template #footer="{methods}">
                <b-button @click="remove" variant="danger" :disabled="loading || form.selected.length === 0">
                    <b-spinner v-if="loading" small></b-spinner>
                    Löschen
                </b-button>
                <b-button @click="hideModal" variant="secondary">Abbrechen</b-button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BDropdownItemButton, BFormCheckbox, BFormGroup, BButton, BSpinner} from 'bootstrap-vue';
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import FormSelect from '@comp/FormSelect/FormSelect';
import {mapGetters, mapState} from "vuex";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    components: {
        BDropdownItemButton,
        ModalDialog,
        FormSelect,
        BFormCheckbox,
        BFormGroup,
        BButton,
        BSpinner,
        ConfirmationModal
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        }),
        ...mapState({
            offer: state => state.offer.offer || {is_onka_writable: false, user: {isAdmin: false, userRoles: []}}
        }),
    },
    mixins: [ConfirmationModal],
    data() {
        return {
            isModalVisible: false,
            loading: false,
            form: {
                objectType: null,
                selected: [],
                selectAll: false
            },
            items: {
                ap: [],
                lp: [],
                el: [],
                ber: [],
            },
            objectTypes: [
                {id: 'ap', text: 'Angebotspositionen'},
                {id: 'lp', text: 'Leistungspositionen'},
                {id: 'el', text: 'Elemente'},
                {id: 'ber', text: 'Berechnungen'},
            ]
        }
    },
    methods: {
        async getItems() {
            const response = await this.$axios.get(`/offers/${this.simpleId}/vkVersions/${this.currentVersion}/multidelete/items`) || {data: this.items}

            this.items = response.data;
        },
        async remove() {
            const confirmed = await this.showConfirmationModal({
                title: 'Objekte löschen',
                message: 'Bitte bestätige die Löschung',
                okTitle: 'Löschen',
            });

            if (!confirmed) return;

            this.loading = true;

            try {
                await this.$axios.post(`/offers/${this.simpleId}/vkVersions/${this.currentVersion}/multidelete`, this.form);

                this.hideModal();

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');

                window.flash.success('Erfolgreich gelöscht.');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                this.loading = false;
            }
        },
        showModal() {
            this.getItems();

            this.isModalVisible = true;
        },
        hideModal() {
            this.isModalVisible = false;

            this.$emit('onClose');

            this.clear();
        },
        getParent(item) {
            let result = '';

            let parent = item.parent;

            while (parent) {
                result += ` ${parent.name}`;

                parent = parent.parent;
            }

            return result;
        },
        clear() {
            this.form = {
                objectType: null,
                selected: [],
                selectAll: false
            }
        },
        canDelete() {
            return this.offer.is_onka_writable
                && (this.offer.user.isAdmin
                    || this.offer.user.userRoles.includes('TK')
                    || this.offer.user.userRoles.includes('AE')
                )
        },
        itemsLength() {
            if (this.form.objectType) {
                return Object.values(this.items[this.form.objectType]).length;
            }

            return 0;
        },
        onItemChange() {
            if (this.form.selected.length >= this.itemsLength()) {
                this.form.selectAll = true;
            } else {
                this.form.selectAll = false;
            }
        },
        onSelectAllChange() {
            if (this.form.selectAll) {
                this.form.selected = Object.keys(this.items[this.form.objectType]);
            } else {
                this.form.selected = [];
            }
        },
        onObjectTypeInput() {
            this.form.selected = [];
            this.form.selectAll = false;
        }
    }
}
</script>
