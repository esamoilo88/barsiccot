<template>
    <div>
        <modal-dialog
            modal-class="update-lp-modal"
            :is-visible="visible"
            size="lg"
            @hideModal="$emit('close-update-lp-modal')"
            title-dialog="Leistungsposition bearbeiten"
        >
            <b-overlay :show="!dataLoaded">
                <div class="d-flex flex-column">
                    <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                    <div class="simple-box d-flex flex-column mb-4">
                        <FormInput
                            v-model="form.name"
                            label-text="Leistungsposition*"
                            name="name"
                            input-id="name"
                            :error-conditions="errorConditions.name"
                        />
                        <Leistungtyp
                            ref="leistungtyp"
                            :item-data="form"
                            @leistungtyp-selected="value => form.leistungtyp = value"
                            @requestDone="() => leistungtypLoaded = true"
                        />

                        <FormInput
                            v-model="form.menge"
                            :error-conditions="errorConditions.menge"
                            label-text="Menge*"
                            name="menge"
                            input-id="menge"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <InflationsfaktorAndAnnuitat
                            ref="InflationsfaktorAndAnnuitat"
                            :item-data="form"
                            @inRessourcen-changed="value => form.inRessourcen = value"
                            @inKosten-changed="value => form.inKosten = value"
                            @AnZinssatz-changed="value => form.AnZinssatz = value"
                            @AnLaufzeit-changed="value => form.AnLaufzeit = value"
                            @AnKWert-changed="value => form.AnKWert = value"
                            @submit="onUpdate"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <OptionsAndDesc
                            ref="OptionsAndDesc"
                            :nach-aufwand="form.nachAufwand"
                            :indirekte-kosten="form.indirekteKosten"
                            :beschreibung="form.beschreibung"
                            @nachAufwand-changed="value => form.nachAufwand = value"
                            @indirekteKosten-changed="value => form.indirekteKosten = value"
                            @beschreibung-changed="value => form.beschreibung = value"
                        />
                    </div>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="onUpdate" class="btn btn-primary">
                    <b-spinner v-if="loading" small></b-spinner>
                    Leistungsposition bearbeiten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>
<script>
import {BSpinner, BOverlay} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import Validation from '@mixins/Validation/Validation';
import Leistungtyp from "../Store/Leistungtyp";
import InflationsfaktorAndAnnuitat from "../Store/Inflationsfaktor&Annuitat";
import OptionsAndDesc from "../Store/OptionsAndDesc";
import {required, helpers} from "vuelidate/lib/validators";
import {mapGetters} from "vuex";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

const intorfloat = helpers.regex('intorfloat', /^(-?\d+(?:\,\d+)?)$/);

export default {
    components: {
        ModalDialog,
        FormInput,
        Leistungtyp,
        InflationsfaktorAndAnnuitat,
        OptionsAndDesc,
        BSpinner,
        BOverlay
    },
    mixins: [Validation],
    props: {
        visible: {
            type: Boolean,
            required: true
        },
        item: {
            type: Object,
            required: true
        }
    },
    mounted() {
        this.setForm(this.item.lp_info);
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId'
        }),
        errorConditions() {
            return {
                name: [
                    {
                        name: 'invalid-name-required',
                        condition: this.isInvalid('name', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    }
                ],
                menge: [
                    {
                        name: 'invalid-menge-required',
                        condition: this.isInvalid('menge', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Menge'})
                    },
                    {
                        name: 'invalid-menge-intorfloat',
                        condition: this.isInvalid('menge', 'intorfloat'),
                        text: 'Falscher Wert für das Feld Menge.'
                    }
                ]
            }
        },
        dataLoaded() {
            return this.leistungtypLoaded
        }
    },
    data() {
        return {
            form: {
                id: null,
                name: null,
                leistungtyp: null,
                inRessourcen: null,
                inKosten: null,
                AnZinssatz: null,
                AnLaufzeit: null,
                AnKWert: null,
                nachAufwand: false,
                indirekteKosten: false,
                beschreibung: null,
                menge: null,
            },
            loading: false,
            leistungtypLoaded: false,
        }
    },
    methods: {
        setForm(item) {
            this.form.id = item.leistungspositionId;
            this.form.name = item.bezeichnung;
            this.form.inRessourcen = this.$f.stringToFloat(item.ifWertRessourcen, 4);
            this.form.inKosten = this.$f.stringToFloat(item.ifWertKosten, 4);
            this.form.AnZinssatz = this.$f.stringToFloat(item.anZinssatz);
            this.form.AnLaufzeit = item.anLaufzeit;
            this.form.AnKWert = this.$f.stringToFloat(item.anKwert);
            this.form.nachAufwand = item.nachAufwand ? item.nachAufwand : false;
            this.form.indirekteKosten = item.sharedCosts ? item.sharedCosts : false;
            this.form.beschreibung = item.beschreibung;
            this.form.menge = this.$f.dotToComma(Number(item.menge));

            if (item.itilMainId) {
                this.form.leistungtyp = `${item.itilMainId}_`;
            }

            if (item.itilSubId) {
                this.form.leistungtyp += item.itilSubId
            }
        },
        hide() {
            this.$emit('close-update-lp-modal');
        },
        async onUpdate() {
            this.$v.$touch();
            let leistungtyp = this.$refs.leistungtyp.validate();
            let InflationsfaktorAndAnnuitat = this.$refs.InflationsfaktorAndAnnuitat.validate();

            if (
                this.$v.$anyError
                || leistungtyp.$anyError
                || InflationsfaktorAndAnnuitat.$anyError
            ) {
                this.showValidationErrors = true;

                navigateToFirstInvalid();

                return;
            }

            this.loading = true;

            try {
                await this.$axios.put(`/offers/${this.simpleId}/calculations/lps/${this.form.id}`, this.form)

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');

                this.hide();

                window.flash.success('Erfolgreich gespeichert.');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                this.loading = false;
            }
        }
    },
    validations: {
        form: {
            name: {required},
            menge: {required, intorfloat},
        }
    }
}
</script>
