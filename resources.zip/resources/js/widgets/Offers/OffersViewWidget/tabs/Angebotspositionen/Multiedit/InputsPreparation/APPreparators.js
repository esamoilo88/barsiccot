/**
 * Preparators for inputs which need specific logic
 * for getting its data. E.g. getting options for kostenart.
 * Every preparator must return an object {input: {}, validationRules, errorMessages},
 * "input" contains either of these fields: content, options,
 * searchable (or any other field from input{} object in ConditionalInput component)
 * The mandatory arguments of all preparator functions are:
 * "$axios" - the instance of axios from the vuejs component
 */

import {integer} from "vuelidate/lib/validators";
import SimpleTranslator from "res/js/utils/SimpleTranslator";
const translations = require('res/lang/lang.translations.json');
const $t = new SimpleTranslator(translations);

/**
 * @param $axios
 * @returns {Promise<{input: {}, validationRules, errorMessages}>}
 */
const prepareMenge = async ($axios) => {
    let validationRules = {integer};
    let errorMessages = [
        {
            name: 'non-integer-menge',
            rule: 'integer',
            text: $t.__('validation.integer', {attribute: 'Menge'})
        }
    ];
    return { input: {}, validationRules, errorMessages };
}


export default {
    menge: prepareMenge
};
