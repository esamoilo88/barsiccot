<template>
    <b-overlay :show="show" rounded="sm">
        <div class="more-angebote-data py-2">
            <div class="lp-box-wrapper mb-2" v-if="request.length > 0">
                <div v-for="(lp,index) in request" class="lp-box mb-2">
                    <div class="lp_header">
                        <div>
                            {{ lp.bezeichnung }}
                        </div>
                    </div>
                    <div class="lotex_lp_info">
                        <div class="mr-3">Menge: <b>{{ $f.stringToFloat(lp.menge) }}</b></div>
                        <div class="mr-3">Stückkosten: <b>{{ formatData(lp.stueckkosten) }}</b></div>
                        <div class="mr-3">Gesamtkosten: <b>{{ formatData(lp.gesamtkosten) }}</b></div>
                        <div>In SIMPLE vorhanden?:
                            <span
                                :style="[lp.color ==='green' ? {'color': 'green'} : {'color': 'red'}]"> {{ lp.in_simple_text }}</span>
                        </div>
                    </div>
                    <div class="elements_list" v-if="arrayForDisplay['ARRDATAEL'] && arrayForDisplay['ARRDATAEL'].length > 0">
                        <table class="w-100">
                            <thead>
                            <tr>
                                <th style="width: 10%">Element</th>
                                <th style="width: 10%">Kostenart</th>
                                <th style="width: 10%">Vollkosten</th>
                                <th style="width: 10%">Stundensatz</th>
                                <th style="width: 12%">Zeitstunden</th>
                            </tr>
                            </thead>
                            <tbody>
                            <template v-if="arrayForDisplay['ARRDATAEL'][indexAp][index]">
                                <!-- EL row -->
                                <tr  v-for="el in arrayForDisplay['ARRDATAEL'][indexAp][index]">
                                    <td class="border-top">{{ el.bezeichnung }}</td>
                                    <td class="border-top"> {{ el.kostenart_bezeichnung }}</td>
                                    <td class="border-top"> {{ formatData(el.vollkosten) }}</td>
                                    <td class="border-top">{{ formatData(el.stundensatz) }}</td>
                                    <td class="border-top">{{ el.zeitstunden }}</td>
                                </tr>
                                <!-- EL end -->
                            </template>
                            <template v-else>
                                <tr><td colspan="5">Keine Elemente vorhanden</td></tr>
                            </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div v-else-if="!show" class="lp-box"><p class="no-data text-center">Keine Daten vorhanden</p></div>
        </div>
    </b-overlay>
</template>

<script>
import ScalarsProcessing from "res/js/utils/Mixins/ValuesProcessing/ScalarsProcessing";
import {BTooltip, BOverlay} from 'bootstrap-vue';
import ButtonIcon from '@comp/ButtonIcon/ButtonIcon';

export default {
    name: "lotex-items-details",
    components: {ButtonIcon, BTooltip, BOverlay},
    mixins: [ScalarsProcessing],
    props: {
        request: {
            type: Array,
            required: true
        },
        indexAp: {
            type: Number,
            required: true
        },
        arrayForDisplay: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            show: false
        }
    },
    methods: {
        formatData(val) {
            return this.$f.numberToString(val, true, true, '0,00 €', {maximumFractionDigits: 10})
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/lpTable';
.lotex_lp_info {
    margin-bottom: 5px;
    display: inline-flex;
    justify-content: space-between;
    flex-wrap: wrap;
}
</style>
