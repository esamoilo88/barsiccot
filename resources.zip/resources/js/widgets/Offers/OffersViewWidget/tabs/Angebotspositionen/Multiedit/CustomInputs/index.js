import ELkostenart from "./ELkostenart/ELkostenart";
import LPannuitaet from "./LPannuitaet/LPannuitaet";
import APproducttype from "./APproducttype/APproducttype";
import APprice from "./APprice/APprice";
import ELaufwand from "./ELkostenart/ELaufwand"
import ELwert from "./ELkostenart/ELwert"

export default {
    ELkostenart,
    LPannuitaet,
    APproducttype,
    APprice,
    ELaufwand,
    ELwert
}
