import Formatter from "res/js/utils/formatter";

export const fieldsTranslation = {
    anKwert: 'Annuität K-Wert',
    anLaufzeit: 'Annuität Laufzeit in Monaten',
    anZinssatz: 'Annuität Zinssatz',
    beschreibung: 'Leistungsbeschreibung',
    bezeichnung: 'Bezeichnung',
    deaktiviert: 'Deaktiviert',
    einzelpreisDttsIndividual: 'Stückpreis',
    gmkz: 'Gemeinkostenzuschlag',
    hide: 'Beschreibung ausblenden',
    ifWertKosten: 'Inflationsfaktor Kosten',
    ifWertRessourcen: 'Inflationsfaktor Ressourcen',
    ifApply: 'Inflationsfaktor  anwenden',
    itilMain: 'Leistungstyp (Main)',
    itilSub: 'Leistungstyp (Sub)',
    kostenart: 'Kostenart',
    ma: 'Mengenabhängig',
    marge: 'Marge',
    margeArt: 'Art der Marge',
    material: 'Material',
    menge: 'Menge',
    nachAufwand: 'Nach Aufwand',
    operator: 'Operator',
    optional: 'Optional',
    preisfaktor: 'Preisfaktor',
    preisbildungArt: 'Art der Preisbildung',
    presales: 'Presales',
    servicelevel: 'Servicelevel',
    servicelevelWert: 'Servicelevel Faktor',
    stundensatz: 'Stundensatz',
    tsIdKategorie1: 'Technischer Skill (1)',
    tsIdKategorie2: 'Technischer Skill (2)',
    tsIdProdukt: 'Technischer Skill (3)',
    vollkosten: 'Vollkosten',
    wert: 'Wert',
    zeitstunden: 'Zeitstunden'
}

export const formatFieldValue = (field, value) => {
    return formatters[field] ? formatters[field](value) : value;
}

const f = new Formatter();
const formatters = {
    menge: val => Math.trunc(val),
    wert: val => f.numberToString(val, false, false, '-', {maximumFractionDigits: 4, minimumFractionDigits: 2})
}
