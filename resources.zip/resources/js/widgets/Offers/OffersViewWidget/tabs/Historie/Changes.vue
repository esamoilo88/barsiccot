<template>
    <div class="d-flex align-items-start flex-wrap">
        <div v-for="field in fields" :key="field" class="mr-4 mb-3">
            <span>{{translateFieldName(field)}}:</span>
            <span class="font-weight-bold px-2">{{ format(field, changes[field]['old']) }}</span> ->
            <span class="font-weight-bold px-2">{{ format(field, changes[field]['new']) }}</span>
        </div>

        <div v-if="fields.length == 0">-</div>
    </div>
</template>

<script>
import {fieldsTranslation, formatFieldValue} from "./onka_fields";

export default {
    name: "Changes",
    props: {
        changes: {
            type: Object,
            required: false
        }
    },
    computed: {
        fields() {
            return this.changes ? Object.keys(this.changes) : [];
        }
    },
    methods: {
        translateFieldName(field) {
            return fieldsTranslation[field] ? fieldsTranslation[field] : field;
        },
        format(field, value) {
            return formatFieldValue(field, value);
        }
    }
}
</script>

<style scoped></style>
