<template>
    <div class="d-flex align-items-start">
        <div class="mr-5">
            <b-form-group label="Historie filtern" v-slot="{ariaDescribedby}">
                <b-form-checkbox-group
                    v-model="filters.entityType"
                    :options="entityTypeOpts"
                    :aria-describedby="ariaDescribedby"
                    name="entity-type-filter"
                    :disabled="disabled"
                    stacked
                ></b-form-checkbox-group>
            </b-form-group>
        </div>

        <div class="d-flex flex-column">
            <b-form-group label="Aktion filtern" v-slot="{ariaDescribedby}" class="action-type-group">
                <b-form-checkbox-group
                    v-model="filters.actionType"
                    :options="actionTypeOpts"
                    :aria-describedby="ariaDescribedby"
                    name="action-type-filter"
                    :disabled="disabled"
                    stacked
                ></b-form-checkbox-group>
            </b-form-group>

            <div class="d-flex align-items-center">
                <FormInput
                    name="search-filter"
                    v-model="filters.search"
                    label-text="Suchbegriff:"
                    input-id="search-filter-input"
                    :disabled="disabled"
                />
                <button :disabled="disabled" @click="handleFiltersChange" class="btn btn-primary ml-2">Suchen</button>
            </div>
        </div>
    </div>
</template>

<script>
import {BFormGroup, BFormCheckboxGroup} from 'bootstrap-vue';
import FormInput from "@comp/FormInput/FormInput";
import vueDebounce from 'vue-debounce';
import Vue from "vue";

export default {
    name: "Filters",
    components: {BFormGroup, BFormCheckboxGroup, FormInput},
    props: {
        disabled: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    data() {
        return {
            filters: {
                entityType: ["onka_ap", "onka_lp", "onka_el", "onka_ber", "onka_var"],
                actionType: ["created", "updated", "removed"],
                search: ""
            },
            entityTypeOpts: [
                {text: "Angebotspositionen", value: "onka_ap"},
                {text: "Leistungspositionen", value: "onka_lp"},
                {text: "Kalkulationselemente", value: "onka_el"},
                {text: "Berechnungen", value: "onka_ber"},
                {text: "Variablen", value: "onka_var"}
            ],
            actionTypeOpts: [
                {text: "Hinzugefügt", value: "created"},
                {text: "Geändert", value: "updated"},
                {text: "Gelöscht", value: "removed"}
            ]
        }
    },
    methods: {
        handleFiltersChange() {
            this.$emit('filters-changed', this.filters);
        }
    }
}
</script>

<style scoped>
::v-deep legend {
    font-weight: bold;
}

::v-deep .action-type-group {
    margin-bottom: 0.5rem;
}
</style>
