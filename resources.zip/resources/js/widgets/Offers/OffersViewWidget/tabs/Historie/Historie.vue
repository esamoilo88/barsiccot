<template>
    <div>
        <Filters @filters-changed="handleFilters" :disabled="pending"/>

        <table-simple
            ref="table"
            class="mt-2"
            table-id="onka-history-table"
            :fields="fields"
            :filters="[]"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
        >
            <template #cell(objectType)="row">
                <div><span>{{ defineObjectType(row.item.groupSysName) }}</span></div>
            </template>

            <template #cell(action)="row">
                <div><span>{{ translateAction(row.item.action) }}</span></div>
            </template>

            <template #cell(user)="row">
                <div><span>{{ row.item.userSecondName + ', ' + row.item.userName }}</span></div>
            </template>

            <template #cell(timestamp)="row">
                <div><span>{{ formatDate(row.item.timestamp, 'DD.MM.YYYY HH:mm:ss') }}</span></div>
            </template>

            <template #cell(changes)="row">
                <ButtonIcon
                    @click="toggleRowAnyway(row.item, 'id')"
                    button-class="btn-icon-link details_class"
                    icon-class="icon-action-more-selected"
                    :id="'show-changes-btn-' + row.item.id"
                    :title="row.item._showDetails ? 'Schließen weitere Daten':'Zeige weitere Daten'"
                />
            </template>

            <template #row-details="row">
                <QuickViewSlot>
                    <Changes :changes="JSON.parse(row.item.changes)" class="p-3"/>
                </QuickViewSlot>
            </template>
        </table-simple>
    </div>
</template>

<script>
import {BOverlay} from 'bootstrap-vue';
import TableSimple from "@comp/TableSimple/TableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import QuickViewMixin from "@mixins/QuickView/QuickViewMixin";
import {getFilterParams} from "@helpers/Tables/tableSimple";
import ValuesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import Changes from "./Changes";
import Filters from "res/js/widgets/Offers/OffersViewWidget/tabs/Historie/Filters";

export default {
    name: "Historie",
    mixins: [Pagination, QuickViewMixin, ValuesProcessing],
    components: {
        Filters, TableSimple, ButtonIcon, QuickViewSlot, Changes, BOverlay
    },
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
    created() {
        this.initPaginationMxn(1, 0, 20, 'timestamp');
    },
    data() {
        return {
            pending: false,
            fields: [
                {key: "objectType", label: "Objekt", class: 'object-col'},
                {key: "objectName", label: "Objektname", class: 'object-name-col'},
                {key: "action", label: "Aktion", class: 'action-col'},
                {key: "user", label: "Benutzer", class: 'user-col'},
                {key: "timestamp", label: "Zeitpunkt", sortable: true, class: 'timestamp-col'},
                {key: "changes", label: "Änderungen", class: 'changes-col'}
            ],
        }
    },
    methods: {
        async itemsProvider(ctx, cancelToken) {
            try {
                const response = await this.$axios.get(`/onka/${this.simpleId}/history`,
                    {
                        params: {
                            currentPage: ctx.currentPage,
                            sortBy: ctx.sortBy,
                            sortDesc: ctx.sortDesc ? 1 : 0,
                            ...getFilterParams(ctx)
                        }
                    },
                    {cancelToken: cancelToken.token}
                );
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return this.insertShowDetailsField(response.data.data, 'id');
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        async handleFilters(data) {
            this.pending = true;
            let ctx = this.$refs.table.getContext();
            ctx.filter === undefined && (ctx.filter = {});
            for (let filterName in data) {
                if (data.hasOwnProperty(filterName)) {
                    ctx.filter[filterName] = data[filterName];
                }
            }
            ctx.isCustomFilter = true;
            await this.$refs.table.handleCtxChange(ctx);
            this.pending = false;
        },
        defineObjectType(groupSysName) {
            switch (groupSysName) {
                case 'onka_ap':
                    return 'AP';
                case 'onka_lp':
                    return 'LP';
                case 'onka_el':
                    return 'EL';
                case 'onka_ber':
                    return 'BER';
                case 'onka_var':
                    return 'VAR';
            }
        },
        translateAction(action) {
            switch (action) {
                case 'created':
                    return 'Hinzugefügt';
                case 'updated':
                    return 'Geändert';
                case 'removed':
                    return 'Gelöscht';
            }
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .changes-col {
    text-align: end;
}
</style>
