export default {
    data() {
        return {
            tableConf: {
                fields: [
                    {
                        key: 'bezeichnung',
                        label: 'Produkt',
                        sortable: true,
                        sortKey: 'bezeichnung',
                        thStyle: {width: '65%'}
                    },
                    {
                        key: 'betrag',
                        label: 'Betrag',
                        thStyle: {width: '20%'},
                        thClass: ['text-right', 'pr-4'],
                        tdClass: ['pr-4']
                    },
                    {
                        key: 'options',
                        label: 'Optionen',
                        thStyle: {width: '15%'}
                    }
                ],
                filters: [],
                sortBy: 'itemSort',
                sortDesc: false,
                totalRows: 0,
                perPage: 0,
                search: null
            }
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                ctx.filter = {search: this.tableConf.search};

                if (!this.selectedTreeItem.kategorieId && !this.tableConf.search) return;

                const response = await this.$axios.post(this.getRoute(), ctx);

                this.tableConf.totalRows = response.data.total;
                this.tableConf.perPage = response.data.perPage;

                return response.data.data.map(function (item) {
                    item._showDetails = true;
                    return item;
                });
            } catch (err) {
                console.log(err);
                return [];
            }
        },
        getRoute() {
            let route = `/offers/katalog/list/${this.selectedCatalogType}`;

            if (this.selectedTreeItem.kategorieId) {
                route += `/${this.selectedTreeItem.kategorieId}`;
            }

            return route;
        }
    }
}
