<template>
    <div>
        <modal-dialog
            modal-class="import-lp-modal"
            :is-visible="isVisible"
            size="lg"
            @hideModal="hide"
            title-dialog="Leistungsposition hinzufügen"
        >
            <b-overlay :show="pending">
                <div class="row no-gutters">
                    <div class="col">
                        <div class="h3 mb-2">{{ item.bezeichnung }}</div>
                        <p class="mb-0 lp-description" :class="{full: fullText}">
                            {{ item.beschreibung }}
                        </p>
                    </div>

                    <div class="col-auto text-nowrap px-5">
                        {{ formatNumber(item.unitCosts) }} <br> <span class="text-muted">pro Stück</span>
                    </div>
                </div>

                <a v-if="!fullText && (item.beschreibung && item.beschreibung.length)" href="#" @click.prevent="fullText = true">Mehr anzeigen</a>

                <div class="pt-4">
                    <APList ref="apList" @change="apListChanged" />
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="onImport" :disabled="selected.length === 0" class="btn btn-primary">Leistungsposition hinzufügen</button>
                <button @click="hide" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>
<script>
import {BSpinner, BOverlay} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import {mapGetters} from "vuex";
import APList from "../Angebotspositionen/LP/Store/APList";

export default {
    name: "import-lp-modal",
    components: {
        APList,
        ModalDialog,
        FormInput,
        BSpinner,
        BOverlay
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canImportLp: {
            type: Boolean,
            required: true,
            default: false
        },
        item: {
            type: Object,
            required: true
        }
    },
    computed: {
        ...mapGetters({
            simpleId: 'offer/simpleId',
            currentVersion: 'offer/currentVersion'
        })
    },
    data() {
        return {
            selected: [],
            fullText: false,
            pending: false
        }
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async onImport() {
            if (this.pending || this.$refs.apList.validate().$anyError) return;

            this.pending = true;

            try {
                await this.$axios.put(`/offers/${this.simpleId}/katalog/${this.currentVersion}/lp/${this.item.id}/import`, {aps: this.selected});

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshAPList');
                this.$eventBus.$emit('refreshLPList');

                this.hide();

                window.flash.success('Leistungsposition erfolgreich importiert.');
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error("Couldn't create LP", err);
            }

            this.pending = false;
        },
        apListChanged(selected) {
            this.selected = selected;
        },
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                true,
                false,
                '0,00 €',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
    }
}
</script>

<style scoped>
.lp-description {
    overflow: hidden;
    height: 44px;
}

.lp-description.full {
    height: auto;
}
</style>
