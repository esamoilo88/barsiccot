<template>
    <div>
        <KatalogList class="mb-4"/>
    </div>
</template>


<script>
import KatalogList from "./KatalogList";


export default {
    name: "Katalog-Import",
    components: {
        KatalogList
    }
}

</script>
