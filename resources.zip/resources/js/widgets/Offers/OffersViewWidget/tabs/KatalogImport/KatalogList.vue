<template>
    <div>
        <catalog ref="catalog" :tree-data="treeData" @search="search" @catalogTypeChange="catalogTypeChange">
            <template v-slot:table>
                <div class="w-100" v-show="isTableOpen">
                    <table-simple
                        table-id="katalog-table"
                        :fields="tableConf.fields"
                        :filters=tableConf.filters
                        :total-rows-prop="tableConf.totalRows"
                        :per-page-prop="tableConf.perPage"
                        :sort-by-prop="tableConf.sortBy"
                        :sort-desc-prop="tableConf.sortDesc"
                        :items-provider="itemsProvider"
                        ref="table"
                        class="shadow-none"
                    >
                        <template #cell(betrag)="data">
                            <div class="text-right">
                                <template v-if="selectedCatalogType === 'ap'">
                                    {{ formatNumber(data.item.fixedPrice ? data.item.unitPrice : data.item.unitCosts) }}
                                </template>
                                <template v-else>
                                    {{ formatNumber(data.item.unitPrice) }}
                                </template>

                                <span class="text-muted"><br> pro {{ data.item.mengentypBezeichnung }}</span>
                            </div>
                        </template>

                        <template #cell(options)="data">
                            <div class="text-nowrap">
                                <button
                                    v-if="(status.onkaWritable) && (offer.user.userRoles.includes('AE') || offer.user.isAdmin)"
                                    class="btn btn-primary btn-icon"
                                    @click="selectedCatalogType === 'ap' ? importAp(data.item) : importLp(data.item)"
                                    :class="{'btn-pending': importPending === data.item.id}"
                                    :disabled="importPending === data.item.id"
                                >
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    <span class="icon-action-add-selected"></span>
                                    Hinzufügen
                                </button>

                                <span
                                    v-if="data.item.isOutdated"
                                    class="icon-alert-warning-default"
                                    title="Achtung, diese Position enthält veraltete Daten."
                                    v-b-tooltip.hover
                                ></span>
                            </div>
                        </template>
                    </table-simple>
                </div>

                <div class="no-table" v-if="!isTableOpen">
                    <p>
                        Nutze den Produktkatalog um Angebots- oder Leistungspositionen zu deinem Angebot hinzuzufügen um so Angebote schneller zu erstellen.
                    </p>

                    <p class="mb-5">Tipp: Für ausgewählte Portfolios gibt es Konfigurationen die dir beim Erstellen des Angebots helfen.</p>

                    <div>
                        <button class="btn btn-primary" @click="goToKonfigurator">Konfiguratoren anzeigen</button>
                    </div>
                </div>
            </template>
        </catalog>

        <ImportLpModal
            v-if="isImportLpModal"
            :is-visible="isImportLpModal"
            @hide="isImportLpModal = false"
            :can-import-lp="true"
            :item="lpDataPrefilled"
        />
    </div>
</template>
<script>
import {VBTooltip} from 'bootstrap-vue';
import TableSimple from "@comp/TableSimple/TableSimple";
import {mapGetters, mapState} from "vuex";
import TableConf from "./TableConf";
import ImportLpModal from './ImportLpModal';
import Catalog from "@comp/Catalog/Catalog";

export default {
    mixins: [TableConf],
    components: {
        TableSimple,
        ImportLpModal,
        Catalog
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    async mounted() {
        await this.getKatalogList();
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer
        }),
        ...mapGetters({
            status: 'offer/status',
            currentVersion: 'offer/currentVersion',
            simpleId: 'offer/simpleId'
        })
    },
    data() {
        return {
            lpDataPrefilled: {},
            isTableOpen: false,
            treeData: [],
            isImportLpModal: false,
            selectedTreeItem: {
                kategorieId: null
            },
            selectedCatalogType: 'ap',
            importPending: null
        }
    },
    methods: {
        async getKatalogList() {
            this.$refs.catalog.setPending(true);

            try {
                const response = await this.$axios.get('/offers/katalog/tree');

                this.treeData = response.data;
            } catch (err) {
                console.error("Couldn't fetch recent projects: ", err);
            }

            this.$refs.catalog.setPending(false);
        },
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                true,
                false,
                '0,00 €',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
        async triggerTable() {
            this.isTableOpen = true;

            await this.$refs.table.manualCtxTrigger();
        },
        async importLp(item) {
            this.lpDataPrefilled = item;
            this.isImportLpModal = true;
        },
        async importAp(item) {
            this.importPending = item.id;

            try {
                await this.$axios.put(`/offers/${this.simpleId}/katalog/${this.currentVersion}/ap/${item.id}/import`);

                this.$eventBus.$emit('offerHeaderUpdate');
                this.$eventBus.$emit('refreshLPList');
                this.$eventBus.$emit('refreshAPList');

                window.flash.success('Angebotsposition erfolgreich importiert');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }

            this.importPending = null;
        },
        goToKonfigurator() {
            this.$eventBus.$emit('goToTab', 2);
        },
        async search(data) {
            this.tableConf.search = data.search;
            this.selectedTreeItem = data.selectedTreeItem;

            await this.triggerTable();
        },
        async catalogTypeChange(value) {
            this.selectedCatalogType = value;

            await this.triggerTable();
        }
    }
}
</script>
<style lang="scss" scoped>
@import 'resources/sass/variables.scss';

::v-deep .table-wrapper {
    border: none;
}

.no-table {
    padding: 10rem 9rem;
    text-align: center;
}

.btn-icon {
    display: inline-grid;
    grid-template-columns: 0fr 1fr;
    width: 140px;

    .spinner-border {
        display: none;
    }
}

.btn-pending {
    .spinner-border {
        display: inline-block;
    }

    .icon-action-add-selected {
        display: none;
    }
}
</style>
