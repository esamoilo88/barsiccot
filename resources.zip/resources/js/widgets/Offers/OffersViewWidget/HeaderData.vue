<template>
    <div>
        <div class="row pl-3 pr-3 d-flex justify-content-between">
            <div class="col-lg-11 col-md-11 simple-box">
                <div class="d-flex justify-content-between">
                    <table class="w-70">
                        <tr class="row-height">
                            <td class="label-text">SIN / Version</td>
                            <td class="">{{ defVal(simpleId, '-') }} / ({{ defVal(offer.offerInfo.version, '-') }}<span
                                class="font-weight-normal"> - {{ getVersionSuffix }})</span></td>
                        </tr>
                        <tr class="row-height">
                            <td class="label-text">Vorhaben</td>
                            <td class="">{{ defVal(offer.globalGate.thema, '-') }}</td>
                        </tr>
                        <tr class="row-height">
                            <td class="label-text">Kunde</td>
                            <td class="">{{ defVal(offer.kundenname, '-') }}</td>
                        </tr>
                    </table>
                    <div class="d-flex flex-column justify-content-between">
                        <CircleChart
                            :content="status.shortName"
                            :value="status.progress"
                            :color="status.color"
                            size="xmsmall"
                            sr-text="Status"
                            class="align-self-end"
                        />
                        <ProjectTags :simple-id="simpleId" :readonly="true" class="align-self-end project-tags-component"/>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box">
                <BoxSpinner :busy="isBusy"/>
                <div class="d-flex justify-content-between row-height">
                    <div class="label-text">Marge</div>
                    <div :class="{
                                'header-data__marge': true,
                                'text-monospace': true,
                                'text-success': offer.offerInfo.marge > 0,
                                'text-danger': offer.offerInfo.marge < 0
                            }"> {{ formatNumber(offer.offerInfo.marge) }} % </div>
                </div>
                <div class="d-flex justify-content-between row-height">
                    <div class="label-text">Marge (eff)</div>
                    <div :class="{
                                'header-data__risiko': true,
                                'text-monospace': true,
                                'text-success': offer.offerInfo.risiko > 0,
                                'text-danger': offer.offerInfo.risiko < 0
                            }"> {{ formatNumber(offer.offerInfo.risiko) }} % </div>
                </div>
                <div class="d-flex justify-content-between row-height">
                    <div class="label-text">GMKZ</div>
                    <div :class="{
                                'header-data__gmkz': true,
                                'text-monospace': true,
                                'text-success': offer.offerInfo.gmkz > 0,
                                'text-danger': offer.offerInfo.gmkz < 0
                            }"> {{
                            $f.numberToString(offer.offerInfo.gmkz, false, false, '0,00', {
                                maximumFractionDigits: 4,
                                minimumFractionDigits: 2
                            })
                        }} % </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box d-flex flex-column justify-content-between">
                <BoxSpinner :busy="isBusy"/>
                <div class="label-text row-height"> Gesamtkosten </div>
                <div class="big-number pb-1">{{ formatNumber(offer.offerInfo.sumVk) }} €</div>
            </div>
            <div class="col-lg-4 col-md-4 simple-box d-flex flex-column justify-content-between">
                <BoxSpinner :busy="isBusy"/>
                <div class="label-text row-height"> Gesamtpreis </div>
                <div class="big-number pb-1">{{ formatNumber(offer.offerInfo.sumTp) }} €</div>
            </div>
        </div>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownItem, BDropdownDivider} from 'bootstrap-vue';
import {mapGetters, mapState, mapMutations} from "vuex";
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";
import ProjectTags from "@comp/Common/ProjectTags/ProjectTags";

export default {
    name: "HeaderData",
    components: {
        CircleChart,
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider,
        BoxSpinner,
        ProjectTags
    },
    mixins: [ScalarsProcessing],
    created() {
        this.$eventBus.$on('offerHeaderUpdate', async () => {
            this.isBusy = true;
            let res = await this.$axios.get(`/offers/${this.simpleId}/offerInfo/${this.currentVersion}`);
            this.setOfferInfo(res.data);
            this.isBusy = false;
        });
    },
    data() {
        return {
            isBusy: false
        }
    },
    computed: {
        ...mapState({
            offer: state => state.offer.offer,
        }),

        ...mapGetters({
            simpleId: 'offer/simpleId',
            status: 'offer/status',
            currentVersion: 'offer/currentVersion'
        }),

        getVersionSuffix() {
            return this.offer.offerInfo.isActiveVersion !== null
                ? this.offer.offerInfo.isActiveVersion ? 'Aktiv': 'Inaktiv'
                : '';
        }
    },
    methods: {
        ...mapMutations({
            setOfferInfo: 'offer/SET_OFFER_INFO'
        }),

        formatNumber(value) {
            return this.$f.numberToString(
                value,
                false,
                false,
                '0,00',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';

.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        padding: 5px 20px 5px 0;
    }
}

.marge-box {
    border-right: 2px solid #dee2e6;
    margin-right: 55px;
    padding-right: 55px;
}

[class*="header-data__"] {
    font-weight: bold;
}

@media (max-width: 1199px) {

    .marge-box {
        margin-right: 20px;
        padding-right: 0;
    }
}
.row-height {
    line-height: 30px;
}
.big-number {
    font-weight: bold;
    font-size: 1.5rem;
}
</style>
