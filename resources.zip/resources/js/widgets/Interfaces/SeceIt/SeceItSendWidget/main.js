import Vue from 'vue';
import {$axios} from 'res/js/boot';
import Formatter from "res/js/utils/formatter";
import SeceItSend from "./SeceItSend";
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;
Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;

Vue.use(Vuelidate);

export default new Vue({
    el: '#seceit-mpf-wrapper', //resources/views/App/Interfaces/SeceIt/manual_send.blade.php
    components: {
        SeceItSend
    }
});
