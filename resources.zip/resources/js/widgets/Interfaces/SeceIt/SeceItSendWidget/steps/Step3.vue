<template>
    <div class="summary d-flex flex-column">
        <span class="mb-3">
            Zuweisungstyp: {{ startSimpleId ? `Die Daten werden dem bestehenden SeCeIT Projekt ${startSimpleId} zugewiesen`
            : 'Die Daten werden einem eigenständigen SeCeIT Projekt zugewiesen.' }}
        </span>

        <b-table-lite id="aps-list" :items="items" :fields="apFields">
            <template #cell(angebotspositionId)="data">
                <div class="ap-id">{{ data.item.angebotspositionId }}</div>
            </template>

            <template #cell(bezeichnung)="data">
                <div class="ap-bezeichnung">{{ data.item.bezeichnung }}</div>
            </template>

            <template #cell(seceitNr)="data">
                <div class="ap-seceit-nr">{{ data.item.seceitNr }}</div>
            </template>

            <template #cell(menge)="data">
                <div class="ap-menge">{{ data.item.menge }}</div>
            </template>

            <template #cell(einzelpreisDttsIndividual)="data">
                <div class="ap-stuckpreis">{{ $f.numberToString(data.item.einzelpreisDttsIndividual, true, false, '0,00') }}</div>
            </template>

            <template #cell(action)="data">
                <span>{{ data.item.seceitNr ? 'Aktualisieren' : 'Hinzufügen' }}</span>
            </template>

            <template #row-details="data">
                <div>
                    <QuickViewSlot>
                        <b-table-lite
                            :fields="lpFields"
                            :items="data.item.lps"
                            :id="`ap-${data.item.angebotspositionId}-lps-table`"
                        >
                            <template #cell(leistungspositionId)="lp">
                                <div class="lp-id">{{ lp.item.leistungspositionId }}</div>
                            </template>
                            <template #cell(mz)="lp">
                                <div class="lp-mz">
                                    {{ data.item.selectedMz.leistungspositionId == lp.item.leistungspositionId ? 'Ja' : 'Nein' }}
                                </div>
                            </template>
                            <template #cell(seceitNr)="lp">
                                <div class="lp-seceit-nr">{{ lp.item.seceitNr }}</div>
                            </template>
                            <template #cell(bezeichnung)="lp">
                                <div class="lp-bezeichnung">{{ lp.item.bezeichnung }}</div>
                            </template>
                            <template #cell(menge)="lp">
                                <div class="lp-menge">{{ lp.item.menge }}</div>
                            </template>
                            <template #cell(nachAufwand)="lp">
                                <div class="lp-nach-aufwand">{{ lp.item.nachAufwand ? 'Ja' : 'Nein' }}</div>
                            </template>
                            <template #cell(action)="lp">
                                <div class="lp-action">{{ lp.item.seceitNr ? 'Aktualisieren' : 'Hinzufügen' }}</div>
                            </template>
                        </b-table-lite>
                    </QuickViewSlot>
                </div>
            </template>

            <template #custom-foot>
                <b-tr v-if="aps.length === 0">
                    <b-td colspan="6" class="text-center">Keine Daten vorhanden</b-td>
                </b-tr>
            </template>
        </b-table-lite>
    </div>
</template>

<script>
import QuickViewSlot from "@comp/QuickView/QuickViewSlot";
import {BTableLite, BTd, BTr} from 'bootstrap-vue';

export default {
    name: "Step3",
    components: {
        BTableLite, QuickViewSlot, BTr, BTd
    },
    props: {
        startSimpleId: {
            type: Number,
            required: false,
            default: null
        },
        aps: {
            type: Array,
            required: true,
            default: () => []
        }
    },
    data() {
        return {
            apFields: [
                {key: "angebotspositionId", label: "ID"},
                {key: "seceitNr", label: "SeCeIT-Nr"},
                {key: "bezeichnung", label: "Angebotsposition"},
                {key: "menge", label: "Menge"},
                {key: "einzelpreisDttsIndividual", label: "Stückpreis"},
                {key: "action", label: "Aktion"},
            ],
            lpFields: [
                {key: "leistungspositionId", label: "ID"},
                {key: "mz", label: "MZ"},
                {key: "seceitNr", label: "SeCeIT-Nr"},
                {key: "bezeichnung", label: "Leistungsposition"},
                {key: "menge", label: "Menge"},
                {key: "nachAufwand", label: "Nach Aufwand"},
                {key: "action", label: "Aktion"},
            ],

        }
    },
    computed: {
        items() {
            return this.aps.map(a => {
                a._showDetails = true;
                return a;
            });
        }
    },
}
</script>

<style lang="scss" scoped>
.summary {
    .lp-id, .ap-id {
        width: 65px;
    }

    .lp-seceit-nr, .ap-seceit-nr {
        width: 100px;
    }

    .lp-mz, .lp-nach-aufwand {
        width: 40px;
    }

    .lp-bezeichnung, .ap-bezeichnung {
        width: 430px;
    }

    .lp-menge, .ap-menge {
        width: 100px;
    }
}
</style>
