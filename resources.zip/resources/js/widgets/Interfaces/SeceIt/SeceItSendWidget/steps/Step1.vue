<template>
    <div class="d-flex">
        <FormSelect
            @select="onSelect"
            :value="value"
            class="project-select"
            select-id="seceit-project"
            name="seceit-project"
            label-text="Bestehendes SeCeIT Projekt"
            :options="projects"
        />
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {createOptions} from "@helpers/Form/InputsHelper";

export default {
    name: "Step1",
    components: {
        FormSelect
    },
    props: {
        value: null,
        seceItProjects: {
            type: Array,
            default: () => []
        }
    },
    data() {
        return {
            projects: []
        }
    },
    created() {
        this.projects.push(...createOptions(
            this.seceItProjects,
            (p) => p.simpleId,
            (p) => 'SIN/' + p.simpleId + ' - ' + p.thema,
            null,
            true
            )
        );
    },
    methods: {
        onSelect(value) {
            this.$emit('input', value);
        }
    }
}
</script>

<style scoped>
.project-select {
    width: 255px;
}
</style>
