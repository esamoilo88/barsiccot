<template>
    <div>
        <div v-if="errors.length > 0" class="error-message mb-3">
            <span v-for="err in errors" :key="err" aria-live="assertive" role="alert" aria-atomic="true">{{ err }}</span>
        </div>

        <b-form-checkbox v-model="isAllSelected" @change="selectAll" class="mb-2 select-all-checkbox">
            Alle AP auswählen
        </b-form-checkbox>

        <table-simple
            ref="apsTable"
            table-id="aps-list-table"
            :fields="fields"
            :filters="[]"
            :total-rows-prop="totalRows"
            :per-page-prop="perPage"
            :sort-by-prop="sortBy"
            :sort-desc-prop="sortDesc"
            :items-provider="itemsProvider"
            primary-key="angebotspositionId"
        >
            <template #cell(checkAp)="data">
                <div>
                    <b-form-checkbox
                        :key="`select-ap-checkbox-${data.item.angebotspositionId}`"
                        :checked="isSelected(data.item.angebotspositionId)"
                        @change="toggleAP(data.item)"
                    ></b-form-checkbox>
                </div>
            </template>

            <template #cell(lps)="data">
                <div class="lps-select-wrapper">
                    <FormSelect
                        @select="val => onLpSelect(data.item, val)"
                        :value="defineLpSelectValue(data.item)"
                        class="mz-lp-select"
                        :select-id="'mz-lp-' + data.item.angebotspositionId"
                        :name="'mz-lp-' + data.item.angebotspositionId"
                        label-text="Mengenzähler"
                        :options="getLpOptions(data.item.lps)"
                        :error-conditions="[
                            {
                                name: 'empty-mz-lp',
                                condition: selectedAps[selectedApIndex(data.item.angebotspositionId)]
                                    && !selectedAps[selectedApIndex(data.item.angebotspositionId)].selectedMz
                                    && isDirty,
                                text: $t.__('validation.required', {attribute: 'Mengenzähler'})
                            }
                        ]"
                    />
                </div>
            </template>
        </table-simple>
    </div>
</template>

<script>
import {BFormCheckbox} from 'bootstrap-vue';
import TableSimple from "@comp/TableSimple/TableSimple";
import Pagination from "@mixins/Pagination/Pagination";
import FormSelect from "@comp/FormSelect/FormSelect";
import {createOptions} from "@helpers/Form/InputsHelper";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";

export default {
    name: "Step2",
    components: {
        TableSimple, BFormCheckbox, FormSelect
    },
    mixins: [Pagination],
    props: {
        simpleId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            fields: [
                {key: "checkAp", label: ""},
                {key: "angebotspositionId", label: "Id"},
                {key: "bezeichnung", label: "Angebotsposition", class: 'ap-bezeichnung-col'},
                {key: "lps", label: "Mengenzähler (Leistungsposition)"}
            ],
            selectedAps: [],
            isAllSelected: false,
            isDirty: false,
            errors: []
        }
    },
    created() {
        this.initPaginationMxn(1, 0, 20);
    },
    watch: {
        simpleId() {
            if (this.$refs.apsTable) {
                this.$refs.apsTable.manualCtxTrigger();
                this.selectedAps.splice(0);
                this.$emit('input', this.selectedAps);
            }
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post(`/seceit/${this.simpleId}/ap-list`, ctx);
                this.totalRows = response.data.total;
                this.perPage = response.data.perPage;
                return response.data.data;
            } catch (err) {
                console.log(err);
                this.totalRows = 0;
                return [];
            }
        },
        isSelected(apId) {
            return this.selectedApIndex(apId) !== -1;
        },
        getLpOptions(lps) {
            return createOptions(
                lps,
                (l) => l.leistungspositionId,
                (l) => l.bezeichnung,
                null,
                true
            )
        },
        defineLpSelectValue(ap) {
            if (this.isSelected(ap.angebotspositionId)) {
                return ap.selectedMz ? ap.selectedMz.leistungspositionId : null;
            } else if (ap.lps.length === 1) {
                ap.selectedMz = ap.lps[0];
                return ap.selectedMz.leistungspositionId;
            }
            return null;
        },
        selectAll() {
            this.$refs.apsTable.items.map(a => {
                let selectedApIndex = this.selectedApIndex(a.angebotspositionId);
                if (selectedApIndex === -1) {
                    this.isAllSelected && this.selectedAps.push(a);
                } else {
                    !this.isAllSelected && this.selectedAps.splice(selectedApIndex, 1);
                }
            });
            this.$emit('input', this.selectedAps);
        },
        toggleAP(ap) {
            let index = this.selectedApIndex(ap.angebotspositionId);
            if (index !== -1) {
                this.selectedAps.splice(index, 1);
            } else {
                this.selectedAps.push(ap);
            }
            this.$emit('input', this.selectedAps);
        },
        onLpSelect(ap, lpId) {
            ap.selectedMz = lpId ? ap.lps.filter(l => lpId == l.leistungspositionId)[0] : null;
        },
        selectedApIndex(apId) {
            let index = -1;
            this.selectedAps.map((a, i) => {
                if (a.angebotspositionId == apId) {
                    index = i;
                }
            });
            return index;
        },
        validate() {
            this.isDirty = true;
            let isValid = false;
            this.errors.splice(0);
            if (this.selectedAps.length == 0) {
                this.errors.push("Wähle mindestens eine Angebotsposition aus");
                document.querySelector('.select-all-checkbox input').focus();
                return isValid;
            } else {
                let errors = this.selectedAps.filter(a => !a.selectedMz);
                isValid = errors.length == 0;
            }

            !isValid && navigateToFirstInvalid();
            return isValid;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.lps-select-wrapper {
    max-width: 630px;
}

.error-message {
    color: $error;
}
</style>
