<template>
    <div class="d-flex flex-column align-items-center">
        <div class="d-flex">
            <span class="icon-action-succsess-selected mr-2"></span>
            <span>Das Projekt befindet sich nun in der Warteschlange. Dies kann mehrere Minuten dauern.</span>
        </div>

        <div class="controls mt-4">
            <button @click="$emit('close-results')" class="btn btn-secondary">Zurück</button>
        </div>
    </div>
</template>

<script>
export default {
    name: "Results"
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

.errors-messages {
    color: $error;
}
</style>
