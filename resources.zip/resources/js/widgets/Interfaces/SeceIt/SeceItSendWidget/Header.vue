<template>
    <div class="simple-box box-shadow">
        <div class="header-data">
            <table>
                <tr>
                    <td>SIN:</td>
                    <td class="header-data__simple-id">{{ data.globalGate.simpleId }}</td>
                </tr>
                <tr>
                    <td>Vorhaben:</td>
                    <td class="header-data__vorhaben">{{ data.globalGate.thema }}</td>
                </tr>
                <tr>
                    <td>Kunde:</td>
                    <td class="header-data__kunde">{{ data.kundenname }}</td>
                </tr>
            </table>

            <CircleChart
                :content="data.globalGate.sinStatus.status.shortName"
                :value="data.globalGate.sinStatus.status.progress"
                :color="data.globalGate.sinStatus.status.color"
                size="small"
                sr-text="Status"
            />
        </div>
    </div>
</template>

<script>
import SimpleDropdown from "@comp/SimpleDropdown/SimpleDropdown";
import {BDropdownDivider, BDropdownItem} from "bootstrap-vue";
import CircleChart from "@comp/CircleChart/CircleChart";
import {mapGetters, mapMutations, mapState} from 'vuex';

export default {
    name: "Header",
    components: {
        SimpleDropdown,
        BDropdownItem,
        BDropdownDivider,
        CircleChart
    },
    props: {
        data: {
            type: Object,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
.header-data {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    td {
        font-size: 22px;
        padding: 5px 20px 5px 0;
    }
}

.header-data__simple-id,
.header-data__vorhaben,
.header-data__kunde {
    font-weight: bold;
}
</style>
