<template>
    <div>
        <Header :data="data.project" class="mb-4"/>

        <div class="simple-box box-shadow">
            <Container
                ref="queueTasksStatuses"
                collapse-title="Die Anfragen nach SeCeIT in der letzten Stunde"
                :key-prop="`seceit-send-${data.project.globalGate.simpleId}`"
            />

            <div v-if="!results" class="mt-4">
                <b-overlay :show="pending">
                    <div id="seceit-mpf">
                        <multi-page-form
                            ref="form"
                            :steps="[
                                {number: 1, icon: 'icon-user_file-file-default'},
                                {number: 2, icon: 'icon-content-tarrifs-default'},
                                {number: 3, icon: 'icon-alert-compliance-default', lazy: true}
                            ]"
                            :on-submit="onSubmit"
                            :active-step-prop="1"
                        >
                            <template #desc1>
                                <span>
                                    Die Vertragsdaten können als neues Projekt angelegt werden oder einem bestehenden Projekt zugewiesen werden.
                                </span>
                            </template>
                            <template #1>
                                <step :number="1" key="step1">
                                    <Step1 v-model="step1.startSimpleId" :sece-it-projects="data.alreadySentProjects"/>
                                </step>
                            </template>

                            <template #desc2>
                                <span>
                                    Bitte lege für jede Angebotsposition fest, welche Leistungsposition als Mengenzähler in SeCeIT genutzt werden soll.
                                </span>
                            </template>
                            <template #2>
                                <step :number="2" key="step2" :on-switch="validateSecondStep">
                                    <Step2 ref="step2" v-model="step2.aps" :simple-id="step1.startSimpleId ? Number(step1.startSimpleId) : data.project.globalGate.simpleId"/>
                                </step>
                            </template>

                            <template #desc3>
                                <span>Zuweisungstyp und Verantwortliche</span>
                            </template>
                            <template #3>
                                <step :number="3" key="step3">
                                    <Step3 :start-simple-id="Number(step1.startSimpleId)" :aps="step2.aps"/>
                                </step>
                            </template>
                        </multi-page-form>

                        <div class="d-flex">
                            <button @click="goBack" class="btn btn-secondary mt-2 mx-auto">Abbrechen</button>
                        </div>
                    </div>
                </b-overlay>
            </div>

            <div v-else class="mt-4">
                <Results @close-results="closeResults"/>
            </div>
        </div>
    </div>
</template>

<script>
import {BOverlay} from 'bootstrap-vue';
import MultiPageForm from "@comp/MultiPageForm/MultiPageForm";
import Step from "@comp/MultiPageForm/Step";
import Header from './Header';
import Step1 from "./steps/Step1";
import Step2 from "./steps/Step2";
import Step3 from "./steps/Step3";
import Results from "./Results";
import Container from "@comp/QueueTasksStatus/Container";

export default {
    name: "sece-it-send",
    components: {
        Container, Results, Step1, Step2, Step3, MultiPageForm, Step, Header, BOverlay
    },
    props: {
        data: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            pending: false,
            step1: {
                startSimpleId: null
            },
            step2: {
                aps: []
            },
            results: false
        }
    },
    methods: {
        validateSecondStep() {
            return this.$refs.step2.validate();
        },
        async onSubmit() {
            this.pending = true;
            try {
                await this.$axios.post(`/seceit/${this.data.project.globalGate.simpleId}/send`, this.prepareData());
                this.results = true;
                await this.$refs.queueTasksStatuses.refresh();
            } catch (err) {
                console.error("Couldn't send data to seceit! Err: ", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        prepareData() {
            let data = {};
            data.startSimpleId = this.step1.startSimpleId;

            let aps = [];
            this.step2.aps.map(a => {
                let ap = {id: a.angebotspositionId, selectedMz: a.selectedMz.leistungspositionId};
                aps.push(ap);
            });
            data.aps = aps;
            data.ts = Math.round(+new Date()/1000);

            return data;
        },
        closeResults() {
            this.step1.startSimpleId = null;
            this.step2.aps.splice(0);
            this.results = false;
        },
        goBack() {
            history.go(-1);
        }
    }
}
</script>

<style scoped>

</style>
