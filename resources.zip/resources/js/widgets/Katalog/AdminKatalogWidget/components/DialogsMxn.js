import {AngebotspositionForm} from "res/js/widgets/Katalog/AdminKatalogWidget/components/AngebotspositionForm";

export default {
    data() {
        return {
            dialogs: {
                ap: {
                    create: {
                        show: false
                    },
                    update: {
                        show: false,
                        item: null
                    }
                },
                lp: {
                    create: {
                        show: false
                    },
                    update: {
                        show: false,
                        item: null
                    }
                }
            }
        }
    },
    methods: {
        showCreateApDialog() {
            this.dialogs.ap.create.show = true;
        },
        hideCreateApDialog() {
            this.dialogs.ap.create.show = false;
        },

        showCreateLpDialog() {
            this.dialogs.lp.create.show = true;
        },
        hideCreateLpDialog() {
            this.dialogs.lp.create.show = false;
        },

        showUpdateApDialog(item) {
            this.dialogs.ap.update.show = true;
            this.dialogs.ap.update.item = this.getAngebotspositionForm(item);
        },
        hideUpdateApDialog() {
            this.dialogs.ap.update.show = false;
            this.dialogs.ap.update.item = null;
        },

        showUpdateLpDialog(item) {
            this.dialogs.lp.update.show = true;
            this.dialogs.lp.update.item = item;
        },
        hideUpdateLpDialog() {
            this.dialogs.lp.update.show = false;
            this.dialogs.lp.update.item = null;
        },

        showCreateDialog() {
            this.dialogs[this.selectedCatalogType].create.show = true;
        },
        showUpdateDialog(item) {
            this.isApCatalogType ? this.showUpdateApDialog(item) : this.showUpdateLpDialog(item.entity);
        },
        getAngebotspositionForm(item) {
            return new AngebotspositionForm(
                item.id,
                item.bezeichnung,
                item.producttypId,
                item.entity.quantity,
                item.entity.fixedPrice,
                item.entity.unitPrice,
                item.beschreibung,
                {id: item.kategorieId, bezeichnung: ''},
                item.entity.code
            );
        }
    }
}
