<template>
    <div>
        <catalog
            ref="catalog"
            :tree-data="treeData"
            @search="search"
            @catalogTypeChange="catalogTypeChange"
            :focus-nav="!!detailsItem"
            :position-name="detailsItem ? detailsItem.bezeichnung : null"
        >
            <template v-slot:buttons>
                <div class="mb-3">
                    <button class="btn btn-primary" @click="showCreateDialog">
                        <span class="icon-action-add-default pr-2"></span>
                        Neues Produkt
                    </button>
                </div>
            </template>

            <template v-slot:nav>
                <div v-if="detailsItem" class="col-auto">
                    <button
                        @click="showUpdateDialog(detailsItem)"
                        class="btn-light"
                    >
                        <i class="icon-action-edit-default"></i>
                        Bearbeiten
                    </button>
                    <button
                        @click="deletePosition(detailsItem.bezeichnung, detailsItemId, selectedCatalogType)"
                        class="btn-light"
                    >
                        <i class="icon-action-remove-default"></i>
                        Löschen
                    </button>
                    <button @click="toTableView" class="btn-light text-link-color">
                        <i class="icon-navigation-left-default"></i>
                        Zurück
                    </button>
                </div>
            </template>

            <template v-slot:belownav>
                <template v-if="detailsItem">
                    <hr>
                    <div class="table-responsive">
                        <table class="light-table mb-4">
                            <thead>
                            <tr>
                                <th>Katalog</th>
                                <th>Produkttyp</th>
                                <th>Stückpreis</th>
                                <th>Festpreis</th>
                                <th>Menge</th>
                                <th>End of sale</th>
                                <th>Beschreibung</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    {{ positionName }}
                                </td>
                                <td>{{ detailsItem.producttyp }}</td>
                                <td>{{ formatNumber(detailsItem.unitPrice) }}</td>
                                <td>
                                    <b-form-checkbox
                                        v-model="detailsItem.entity.fixedPrice"
                                        name="fixprice-check-button"
                                        switch
                                        disabled
                                    ></b-form-checkbox>
                                </td>
                                <td>{{ isApCatalogType ? detailsItem.entity.quantity : 1 }}</td>
                                <td>
                                    <b-form-checkbox
                                        v-model="detailsItem.entity.outdated"
                                        name="outdated-check-button"
                                        switch
                                        disabled
                                    ></b-form-checkbox>
                                </td>
                                <td>
                                    <LongText v-if="detailsItem.beschreibung" :text="detailsItem.beschreibung" />
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </template>
            </template>

            <template v-slot:table>
                <div class="pl-5 pt-5" v-if="detailsItem">
                    <div class="mb-3" v-if="detailsItem.entity.outdated">
                        Dieses Produkt enthält veraltete Daten
                    </div>
                    <ApContent
                        v-if="isApCatalogType"
                        ref="apContent"
                        :ap-id="detailsItemId"
                        @updateLp="showUpdateLpDialog"
                        @deleteLp="deleteLp"
                    />

                    <LpContent
                        v-else
                        ref="lpContent"
                        :lp-id="parseInt(detailsItemId)"
                    />
                </div>

                <div v-show="isTableOpen && !detailsItem">
                    <table-simple
                        ref="table"
                        table-id="katalog-table"
                        :fields="tableConf.fields"
                        :filters=tableConf.filters
                        :total-rows-prop="tableConf.totalRows"
                        :per-page-prop="tableConf.perPage"
                        :sort-by-prop="tableConf.sortBy"
                        :sort-desc-prop="tableConf.sortDesc"
                        :items-provider="itemsProvider"
                        class="shadow-none"
                        primary-key="id"
                        :fetch-on-mount="false"
                    >
                        <template #cell(betrag)="data">
                            <div class="text-right">
                                <template v-if="selectedCatalogType === 'ap'">
                                    {{ formatNumber(data.item.entity.fixedPrice ? data.item.entity.unitPrice : data.item.entity.unitCosts) }}
                                </template>
                                <template v-else>
                                    {{ formatNumber(data.item.unitPrice) }}
                                </template>

                                <span class="text-muted"><br> pro {{ data.item.mengentypBezeichnung }}</span>
                            </div>
                        </template>

                        <template #cell(options)="data">
                            <div class="text-nowrap">
                                <button
                                    @click="toDetailsView(data.item)"
                                    class="btn btn-primary"
                                    :id="`more-${selectedCatalogType}-btn-${data.item.id}`"
                                >
                                    Details
                                </button>

                                <button
                                    class="btn btn-outline-secondary btn-icon"
                                    :id="`del-${selectedCatalogType}-btn-${data.item.id}`"
                                    @click="deletePosition(data.item.bezeichnung, data.item.id, selectedCatalogType)"
                                    :title="`${positionName} löschen`"
                                >
                                    <i class="icon-action-remove-default"></i>
                                </button>

                                <span v-if="data.item.entity.outdated"
                                      class="icon-alert-warning-default"
                                      title="Achtung, diese Position enthält veraltete Daten."
                                ></span>
                            </div>
                        </template>
                    </table-simple>
                </div>

                <div class="text-center pt-5" v-if="!isTableOpen">
                    <div class="mb-4">
                        <i class="icon-action-shopping-cart-selected empty-catalog-icon"></i>
                    </div>

                    <p>Willkommen im Adminbereich des Produktkatalogs.</p>
                    <p>Bitte wähle eine Kategorie aus.</p>
                </div>
            </template>
        </catalog>

        <Manage
            v-if="dialogs.ap.create.show"
            :show="dialogs.ap.create.show"
            :selected-category-id="selectedTreeItem.kategorieId"
            @hide="hideCreateApDialog"
            @success="triggerTable"
        />

        <Manage
            v-if="dialogs.ap.update.show"
            :show="dialogs.ap.update.show"
            :item="dialogs.ap.update.item"
            @hide="hideUpdateApDialog"
            @success="triggerTable"
        />

        <StoreLP
            v-if="dialogs.lp.create.show"
            :show="dialogs.lp.create.show"
            :canCreateLp="true"
            :selected-category-id="selectedTreeItem.kategorieId"
            @hide="hideCreateLpDialog"
            @success="triggerTable"
        />

        <UpdateLP
            v-if="dialogs.lp.update.show"
            :show="dialogs.lp.update.show"
            :item="dialogs.lp.update.item"
            :selected-category-id="selectedTreeItem.kategorieId"
            @hide="hideUpdateLpDialog"
            @success="triggerTable"
        />

        <ElBerManage />
    </div>
</template>

<script>
import {BFormCheckbox} from 'bootstrap-vue';
import TableSimple from "@comp/TableSimple/TableSimple";
import StoreLP from "./entities/LP/Store/StoreLP";
import UpdateLP from "./entities/LP/Update/UpdateLP";
import Manage from "./entities/AP/Manage";
import ApContent from "./entities/AP/ApContent/ApContent";
import LpContent from "./entities/LP/LpContent/LpContent";
import {mapState, mapActions} from 'vuex';
import Catalog from "@comp/Catalog/Catalog";
import TableConf from './TableConf';
import LongText from "@comp/LongText";
import DeletePositionMxn from "res/js/widgets/Katalog/AdminKatalogWidget/components/DeletePositionMxn";
import DialogsMxn from "res/js/widgets/Katalog/AdminKatalogWidget/components/DialogsMxn";
import ElBerManage from "res/js/widgets/Katalog/AdminKatalogWidget/components/ElBerManage";

export default {
    name: "KatalogList",
    mixins: [TableConf, DeletePositionMxn, DialogsMxn],
    components: {
        ApContent,
        TableSimple,
        BFormCheckbox,
        StoreLP,
        UpdateLP,
        Manage,
        LpContent,
        Catalog,
        LongText,
        ElBerManage
    },
    async mounted() {
        this.$refs.catalog.setPending(true);

        await this.fetchCategories();

        this.$refs.catalog.setPending(false);

        this.$eventBus.$on('refreshTable', this.triggerTable);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshTable', this.triggerTable);
    },
    computed: {
        ...mapState({
            treeData: state => state.katalog.categories,
        }),
        detailsItemId() {
            return this.detailsItem ? this.detailsItem.id : null;
        },
        positionName() {
            return this.selectedCatalogType === 'ap' ? 'Angebotsposition' : 'Leistungsposition';
        },
        isApCatalogType() {
            return this.selectedCatalogType === 'ap';
        }
    },
    data() {
        return {
            isTableOpen: false,
            pending: false,
            selectedTreeItem: {
                kategorieId: null
            },
            selectedCatalogType: 'ap',
            detailsItem: null
        }
    },
    methods: {
        ...mapActions({
            fetchCategories: 'katalog/fetchCategories'
        }),
        formatNumber(value) {
            return this.$f.numberToString(
                value,
                true,
                false,
                '0,00 €',
                {maximumFractionDigits: 2, minimumFractionDigits: 2}
            );
        },
        async triggerTable() {
            if (!this.selectedTreeItem.kategorieId && !this.tableConf.search) return;

            if (this.$refs.apContent) {
                this.$refs.apContent.getData();
            }

            if (this.$refs.lpContent) {
                this.$refs.lpContent.getData();
            }

            await this.$refs.table && this.$refs.table.manualCtxTrigger();

            if (this.detailsItem) {
                const item = this.tableConf.data.find(item => item.id === this.detailsItemId);

                if (item) {
                    this.detailsItem = item;
                }
            }
        },
        async search(data) {
            this.tableConf.search = data.search;
            this.selectedTreeItem = data.selectedTreeItem;

            this.toTableView();

            await this.triggerTable();
        },
        async catalogTypeChange(value) {
            this.selectedCatalogType = value;

            this.toTableView();

            await this.triggerTable();
        },
        toDetailsView(item) {
            this.detailsItem = item;

            this.$refs.catalog.setToggleCatalogView(true);
        },
        toTableView() {
            this.isTableOpen = true;
            this.detailsItem = null;

            this.$refs.catalog.setToggleCatalogView(false);
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables.scss';
@import 'resources/sass/tables/new-table';

::v-deep .table-wrapper {
    border: none;
}

.empty-catalog-icon {
    font-size: 3rem;
}

</style>
