import Formatter from "res/js/utils/formatter";

export class AngebotspositionForm {
    constructor(
        id = null,
        name = null,
        producttypeId = null,
        quantity = null,
        fixedPrice = false,
        unitPrice = null,
        beschreibung = null,
        categories = {id: -1, bezeichnung: ''},
        code = null,
    ) {
        this.id = id;
        this.name = name;
        this.producttypeId = producttypeId;
        this.quantity = quantity;
        this.fixedPrice = fixedPrice;
        this.unitPrice = new Formatter().dotToComma(unitPrice);
        this.beschreibung = beschreibung;
        this.categories = categories;
        this.code = code;
    }

    setCategories(value) {
        this.categories = value;
    }
}
