export default {
    data() {
        return {
            tableConf: {
                fields: [
                    {
                        key: 'bezeichnung',
                        label: 'Produkt',
                        sortKey: 'bezeichnung',
                        thStyle: {width: '65%'}
                    },
                    {
                        key: 'betrag',
                        label: 'Betrag',
                        thStyle: {width: '20%'},
                        thClass: ['text-right', 'pr-4'],
                        tdClass: ['pr-4']
                    },
                    {
                        key: 'options',
                        label: 'Optionen',
                        thStyle: {width: '15%'}
                    }
                ],
                filters: [],
                sortBy: 'bezeichnung',
                sortDesc: false,
                totalRows: 0,
                perPage: 20,
                search: null,
                data: []
            }
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                ctx.filter = {search: this.tableConf.search};

                const response = await this.$axios.get(`/admin/katalog/list/${this.selectedCatalogType}/${this.selectedTreeItem.kategorieId ? this.selectedTreeItem.kategorieId : ''}`, {
                    params: {
                        currentPage: ctx.currentPage,
                        sortBy: ctx.sortBy,
                        sortDesc: ctx.sortDesc ? 1 : 0,
                        perPage: this.tableConf.perPage,
                        'filter[search]': ctx.filter.search,
                    }
                });
                this.tableConf.totalRows = response.data.total;
                this.tableConf.perPage = response.data.perPage;

                this.tableConf.data = response.data.data;

                return this.tableConf.data;
            } catch (err) {
                console.log(err);
                return [];
            }
        },
    }
}
