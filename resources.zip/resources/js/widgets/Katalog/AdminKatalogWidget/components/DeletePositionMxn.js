import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    mixins: [ConfirmationModal],
    methods: {
        async showConfirmationMessage(name, positionName) {
            return await this.showConfirmationModal({
                title: `${positionName} löschen`,
                message: `Bitte bestätige die Löschung der ${this.positionName} ${name}.`,
                okTitle: `${positionName} löschen`,
            });
        },
        async deletePosition(name, id, position) {
            const positionName = position === 'ap' ? 'Angebotsposition' : 'Leistungsposition';

            const confirmed = await this.showConfirmationMessage(name, positionName)

            if (!confirmed) return;

            const catalog = position ? position : this.selectedCatalogType;

            window.preloader.show();

            try {
                await this.$axios.delete(`/admin/katalog/${catalog}/${id}`);

                window.flash.success(`${positionName} erfolgreich gelöscht`);

                this.toTableView();

                await this.triggerTable();
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }

            window.preloader.hide();
        },
        async deleteLp(lp) {
            await this.deletePosition(lp.bezeichnung, lp.leistungspositionId, 'lp');
        }
    }
}
