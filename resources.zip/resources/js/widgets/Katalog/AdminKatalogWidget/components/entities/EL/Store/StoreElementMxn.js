export default {
    data() {
        return {
            isELFormActive: false,
            elementToUpdate: null,
            parentLpId: null // LP for which we create single EL
        }
    },
    methods: {
        onElementCreate(lpId) {
            this.isELFormActive = true;
            this.parentLpId = parseInt(lpId);
        },
        onElementUpdate(data) {
            this.isELFormActive = true;
            this.elementToUpdate = data.item;
            this.parentLpId = data.lpParentId;
        },
        onElementDialogClose() {
            this.parentLpId = null;
            this.elementToUpdate = null;
            this.isELFormActive = false;
        }
    }
}
