import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";

export default {
    mixins: [ConfirmationModal],
    methods: {
        async deleteBer(ber) {
            const confirmed = await this.showConfirmationModal({
                title: 'Berechnung löschen',
                message: `Bitte bestätige die Löschung der Berechnung ${ber.bezeichnung}.`,
                okTitle: 'Berechnung löschen',
            });

            if (!confirmed) return;

            window.preloader.show();

            try {
                await this.$axios.delete(`/admin/katalog/ber/${ber.berechnungId}`);
                window.flash.success('Berechnung erfolgreich gelöscht');
                this.$eventBus.$emit('refreshTable');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
