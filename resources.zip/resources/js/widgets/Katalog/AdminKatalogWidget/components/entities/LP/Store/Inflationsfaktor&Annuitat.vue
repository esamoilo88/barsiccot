<template>
    <div class="d-flex justify-content-between pt-5 position-relative">
        <div class="inf-first-column">
            <FormInputAppend
                v-model="form.inRessourcen"
                @input="value => $emit('inRessourcen-changed', value)"
                @submit="$emit('submit')"
                class="lp-inRessourcen"
                input-id="lp-inRessourcen"
                name="inRessourcen"
                label-text="Inflationsfaktor Ressourcen"
                prepend="%"
                :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.inRessourcen.decimal  && $v.form.inRessourcen.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Ressourcen'})
                }
            ]"
            />
            <FormInputAppend
                v-model="form.inKosten"
                @input="value => $emit('inKosten-changed', value)"
                @submit="$emit('submit')"
                class="lp-inKosten"
                input-id="lp-inKosten"
                name="inKosten"
                label-text="Inflationsfaktor Kosten"
                prepend="%"
                :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.inKosten.decimal  && $v.form.inKosten.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Kosten'})
                }
            ]"
            />
        </div>
        <div class="inf-second-column">
            <b-form-checkbox
                v-model="checkbox"
                @change="value => useZinzats(value)"
                switch
                class="zinssatz-checkbox"
            >
                Annuitätenrechnung
            </b-form-checkbox>
            <FormInputAppend
                v-model="form.AnZinssatz"
                @input="value => $emit('AnZinssatz-changed', value)"
                @change="setCheckbox"
                @submit="$emit('submit')"
                class="lp-AnZinssatz"
                input-id="lp-AnZinssatz"
                name="AnZinssatz"
                label-text="Annuität Zinssatz"
                prepend="%"
                :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.AnZinssatz.decimal  && $v.form.AnZinssatz.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Annuität Zinssatz'})
                }
            ]"
            />
            <div class="d-flex">
                <FormInputAppend
                    v-model="form.AnLaufzeit"
                    @input="value => $emit('AnLaufzeit-changed', value)"
                    @change="setCheckbox"
                    @submit="$emit('submit')"
                    class="lp-AnLaufzeit"
                    input-id="lp-AnLaufzeit"
                    name="AnLaufzeit"
                    label-text="Annuität Laufzeit"
                    :error-conditions="[
                {
                    name: 'invalid-number',
                    condition: !$v.form.AnLaufzeit.decimal  && $v.form.AnLaufzeit.$dirty,
                    text: $t.__('validation.numeric', {attribute: 'Annuität Laufzeit'})
                }
            ]"
                />
                <FormInputAppend
                    v-model="form.AnKWert"
                    @input="value => $emit('AnKWert-changed', value)"
                    @change="setCheckbox"
                    @submit="$emit('submit')"
                    class="lp-AnKWert"
                    input-id="lp-AnKWert"
                    name="AnKWert"
                    label-text="Annuität K-Wert"
                    :error-conditions="[
                {
                  name: 'invalid-number',
                  condition: !$v.form.AnKWert.decimal  && $v.form.AnKWert.$dirty,
                  text: $t.__('validation.numeric', {attribute: 'Annuität K-Wert'})
                }
            ]"
                />
            </div>
        </div>
    </div>
</template>

<script>
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {mapGetters} from "vuex";
import {BFormCheckbox} from 'bootstrap-vue';

const valid4Fraction = /^[0-9]*[,]?[0-9]{1,4}$/;
const valid2Fraction = /^[0-9]*[,]?[0-9]{1,2}$/;
const invalidZero = /^[0]*[,]?[0]*$/
export default {
    name: "InflationsfaktorAndAnnuitat",
    components: { FormInputAppend, BFormCheckbox },
    props: {
        itemData: {
            type: Object,
            default: () => {
                return {
                    inRessourcen: '',
                    inKosten: '',
                    AnZinssatz: '',
                    AnLaufzeit: '',
                    AnKWert: '',
                }
            }
        }
    },
    data() {
        return {
            checkbox: false,
            form: {
                inRessourcen: this.itemData.inRessourcen,
                inKosten: this.itemData.inKosten,
                AnZinssatz: this.itemData.AnZinssatz,
                AnLaufzeit: this.itemData.AnLaufzeit,
                AnKWert: this.itemData.AnKWert,
            }
        }
    },
    computed: {
        ...mapGetters({
            offerInfo: 'offer/offerInfo'
        })
    },
    methods: {
        validate() {
            this.useZinzats(this.setCheckbox());
            this.$v.$touch();
            return this.$v;
        },
        isEmptyString(value) {
            return value === null || String(value).length === 0;
        },
        isInvalidZero(value) {
            return String(value).match(invalidZero) !== null;
        },
        useZinzats(value) {
            this.form.AnZinssatz = value ? this.offerInfo.zinssatz: '';
        },
        setCheckbox() {
            let isNotEmptyAnyField = this.isNotEmptyField('AnZinssatz') || this.isNotEmptyField('AnLaufzeit') || this.isNotEmptyField('AnKWert');
            this.checkbox = isNotEmptyAnyField;
            return isNotEmptyAnyField;
        },
        isNotEmptyField(fieldName) {
            return this.form[fieldName] !== '' && this.form[fieldName] !== null;
        }
    },
    created() {
        this.setCheckbox();
    },
    validations: {
        form: {
            inRessourcen: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            inKosten: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            AnZinssatz: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid2Fraction) !== null;
                }
            },
            AnLaufzeit: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(/^\d+$/) !== null;
                },
            },
            AnKWert: {
                decimal(value) {
                    let isEmptyString = this.isEmptyString(value);
                    if (this.checkbox && isEmptyString) return false;
                    if (isEmptyString) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid2Fraction) !== null;
                }
            }
        }
    }
}
</script>

<style lang="scss" scoped>
    .inf-first-column {
        flex: 0.4;
    }
    .inf-second-column {
        flex: 0.5;
    }
    .lp-inRessourcen {
        margin-bottom: 10px;
    }
    .lp-AnZinssatz {
        margin-bottom: 10px;
    }
    .lp-AnLaufzeit {
        margin-right: 20px;
    }
    .zinssatz-checkbox {
        position: absolute;
        top: 9%;
        left: 50%;
    }
</style>
