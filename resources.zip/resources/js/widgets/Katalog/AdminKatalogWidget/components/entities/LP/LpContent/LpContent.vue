<template>
    <b-overlay :show="show" rounded="sm">
        <div class="simple-box mb-3">
            <template v-if="lpData.length">
                <div class="item-header mb-3">
                    <div class="item-label">LP</div>
                    <div class="font-weight-bold">
                        {{ lpData[0].bezeichnung }}
                    </div>
                </div>
                <div class="lp_info mb-4">
                    <table class="light-table">
                        <thead>
                        <tr>
                            <th>Leistungstyp</th>
                            <th>Menge</th>
                            <th>Inflationsfaktor</th>
                            <th>Nach Aufwand</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>
                                <span class="text-uppercase">{{ lpData[0].itilMain ? lpData[0].itilMain.bezeichnung : '' }}</span>
                                <span>{{ lpData[0].itilSub ? lpData[0].itilSub.bezeichnung : '' }}</span>
                            </td>
                            <td>1</td>
                            <td class="text-nowrap">
                                {{ $f.numberToString(lpData[0].inflationsfaktorRessourcen, false, false, '0,00', {maximumFractionDigits: 10}) }}
                                (Ressourcen)
                                &#183;
                                {{ $f.numberToString(lpData[0].inflationsfaktorKosten, false, false, '0,00', {maximumFractionDigits: 10}) }}
                                (Kosten)
                            </td>
                            <td>
                                <b-form-checkbox
                                    v-model="lpData[0].nachAufwand"
                                    name="lp-nach-aufwand-check-button"
                                    switch
                                    disabled
                                ></b-form-checkbox>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </template>

            <div v-if="mergedObjects.els.length > 0 || mergedObjects.bers.length > 0">
                <div class="elements_list" v-if="mergedObjects.els.length > 0 || mergedObjects.bers.length > 0">
                    <table class="w-100" id="el-ber-table">
                        <thead>
                        <tr>
                            <th style="width: 8%">Objekt</th>
                            <th style="width: 50%">Bezeichnung</th>
                            <th style="width: 10%">Wert</th>
                            <th style="width: 10%">Stundensatz</th>
                            <th style="width: 10%">Merkmale</th>
                            <th style="width: 12%">Optionen</th>
                        </tr>
                        </thead>
                        <tbody>
                        <template v-for="(item, index) in mergedObjects.els">
                            <!-- EL row -->
                            <tr v-if="!item.berechnungId" :key="item.elementId">
                                <td class="pl-0 border-top" v-if="!item.berechnungId">
                                    <span class="icon-content-clipboard-default"></span>
                                    EL
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    <ElementData :item="item"/>
                                </td>
                                <td class="border-top" v-if="!item.berechnungId && item.berechnungsart">
                                    {{ $f.numberToString(item.wert, true, true) }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId && !item.berechnungsart">
                                    {{ item.zeitstunden }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    {{ $f.numberToString(item.stundensatz, true, true) }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    <div v-if="item.ma" class="mt-1">
                                        <abbr class="badge badge-info" :id="'ma_' + item.elementId" title="Mengeabhängig">
                                            MA
                                        </abbr>
                                    </div>
                                </td>
                                <td class="border-top text-nowrap" v-if="!item.berechnungId">
                                    <button
                                        @click="emitAction('create-ber', {type: 'EL', id: item.katalogEl.elementId})"
                                        title="Neue Berechnung"
                                        class="options-btn"
                                    >
                                        <i class="icon-function-mathematical-symbol"></i>
                                    </button>

                                    <button
                                        @click="emitAction('update-el', {lpParentId: lpId, item: item.katalogEl})"
                                        title="Element bearbeiten"
                                        class="options-btn"
                                    >
                                        <i class="icon-action-edit-default"></i>
                                    </button>

                                    <button
                                        @click="emitAction('delete-el', item.katalogEl)"
                                        title="Element löschen"
                                        class="options-btn"
                                    >
                                        <i class="icon-action-remove-default"></i>
                                    </button>
                                </td>
                            </tr>
                            <!-- EL end -->

                            <!-- EL Berechnung start -->
                            <tr
                                is="BerechnungRow"
                                v-for="ber in item.katalogEl.katalogBer"
                                v-if="ber.berechnungId"
                                :key="ber.berechnungId + '-' + index"
                                :item="ber"
                                :parent-type="'EL'"
                                :can-create-or-update="true"
                                @edit-ber="emitAction('update-ber', {ber: ber, target: {type: 'EL', id: item.katalogEl.elementId}})"
                                @delete-ber="emitAction('delete-ber', ber)"
                            ></tr>
                            <!-- EL Berechnung end -->
                        </template>

                        <!-- LP Berechnung start -->
                        <template v-if="mergedObjects.bers.length > 0">
                            <tr
                                is="BerechnungRow"
                                v-for="item in mergedObjects.bers"
                                :key="'lp-ber-' + item.id"
                                :item="item.katalogBer"
                                :parent-type="'LP'"
                                :can-create-or-update="true"
                                @edit-ber="emitAction('update-ber', {ber: item.katalogBer, target: {type: 'LP', id: lpId}})"
                                @delete-ber="emitAction('delete-ber', item)"
                            ></tr>
                        </template>
                        <!-- LP Berechnung end -->
                        </tbody>
                    </table>
                </div>
                <div v-else-if="!show" class="elements_list"><p class="no-data">Keine Elemente vorhanden</p></div>
            </div>
            <div v-else-if="!show">
                <p class="no-data text-center">Keine Daten vorhanden</p>
            </div>
        </div>
    </b-overlay>
</template>

<script>
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import BerechnungRow from "./BerechnungRow";
import ElementData from "./ElementData";
import {BOverlay, BFormCheckbox} from 'bootstrap-vue';

export default {
    name: "LpContent",
    mixins: [ScalarsProcessing],
    components: {
        ButtonIcon, BerechnungRow, ElementData, BOverlay, BFormCheckbox
    },
    props: {
        lpId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            show: false,
            lpData: []
        }
    },
    computed: {
        mergedObjects() {
            let result = {els: [], bers: []};
            if (this.lpData.length > 0) {
                this.lpData[0].els.forEach((el) => {
                    let bers = el.bers ? el.bers : [];
                    result.els.push(...[el, ...bers]);
                });
                let lpBers = this.lpData[0].bers ? this.lpData[0].bers : [];
                result.bers.push(...lpBers);
            }
            return result;
        }
    },
    created() {
        this.$eventBus.$on('refreshTable', this.refreshHandler);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshTable', this.refreshHandler);
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            this.show = true;
            try {
                const response = await this.$axios.get(`/admin/katalog/lp/${this.lpId}/content`);
                this.lpData = response.data;
            } catch (err) {
                console.log("Couldn't fetch lp content");
            }
            this.show = false;
        },
        /**
         * Use synchronous handler for eventBus, otherwise it
         * cannot remove event handler after component is destroyed
         */
        refreshHandler() {
            this.getData().then();
        },
        emitAction(name, data) {
            this.$eventBus.$emit(name, data);
        },
        getElementId(index) {
            for (let i = index; i >= 0; i--) {
                if (this.mergedObjects.els[i].berechnungId === undefined) {
                    return this.mergedObjects.els[i].elementId;
                }
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/lpTable';
@import 'resources/sass/components/onkaPositions';
@import 'resources/sass/tables/new-table';

.options {
    min-width: 135px;
    text-align: end;
}
</style>
