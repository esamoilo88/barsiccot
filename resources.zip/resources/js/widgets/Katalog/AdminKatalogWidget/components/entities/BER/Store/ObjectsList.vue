<template>
    <div>
        <div class="simple-box d-flex flex-column mb-4">
            <b-overlay :show="pending">
                <p class="mb-2">Bitte wähle aus, in welchen Objekten die Änderung vorgenommen werden soll.</p>

                <FormSelect
                    v-model="objectsType"
                    class="mb-3"
                    @select="onObjectsTypeSelect"
                    select-id="ber-object-type-select"
                    name="ber-object-type-select"
                    label-text="Zielobjekt*"
                    :options="objectsTypeOptions"
                />

                <span
                    v-if="!$v.selectedObjects.required && $v.selectedObjects.$dirty"
                    :class="{
                        'my-2': true,
                        'invalid-feedback': true,
                        'd-block': !$v.selectedObjects.required && $v.selectedObjects.$dirty
                    }"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true"
                >
                    Bitte wähle mindestens ein Objekt aus.
                </span>
                <div :class="{'invalid': !$v.selectedObjects.required && $v.selectedObjects.$dirty}">

                    <b-table-lite id="objects-list" :items="items" :fields="fields">
                        <template #cell(id)="item">
                            <b-form-checkbox
                                v-model="selectedObjects"
                                :key="item.item.id"
                                :class="'object' + item.item.id"
                                :value="item.item.id"
                                @input="$emit('objects-selected', {type: objectsType, objects: selectedObjects})"
                            >
                                <span class="sr-only">{{ item.item.object }}</span>
                            </b-form-checkbox>
                        </template>

                        <template #cell(object)="item">
                            <span class="mr-2">{{ item.item.object }}</span>
                            <span v-if="objectsType === 'AP'" class="text-muted">(Nr {{
                                    item.item.sort
                                }})</span>
                            <span v-else class="text-muted">{{ item.item.parent }}</span>
                        </template>

                        <template #custom-foot>
                            <b-tr v-if="items.length === 0">
                                <b-td colspan="2" class="text-center">Keine Daten vorhanden</b-td>
                            </b-tr>
                        </template>
                    </b-table-lite>

                    <div v-if="items.length > 0" class="pagination-wrapper">
                        <span class="total-rows-text">{{ paginationEntriesText }}</span>
                        <b-pagination
                            v-model="currentPage"
                            @input="fetchObjects"
                            :total-rows="totalRows"
                            :per-page="perPage"
                            aria-controls="lp-list-for-element-creation"
                        ></b-pagination>
                    </div>

                </div>
            </b-overlay>
        </div>

        <span>{{ selectedObjects.length }} ({{ objectsType }}) ausgewählt.</span>
    </div>
</template>

<script>
import {BFormCheckbox, BOverlay, BPagination, BTableLite, BTd, BTfoot, BTr} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";
import FormSelect from "@comp/FormSelect/FormSelect";
import {mapGetters} from 'vuex';
import {required} from 'vuelidate/lib/validators';

export default {
    name: "ObjectsList",
    components: {
        BTableLite, BOverlay, BPagination, BFormCheckbox,
        BTfoot, BTr, BTd, FormSelect
    },
    mixins: [Pagination],
    async created() {
        this.initPaginationMxn(1, 0, 10);
        await this.fetchObjects();
    },
    data() {
        return {
            items: [],
            fields: [{key: "id", label: "", class: "select-object-checkbox"}, {key: "object", label: "Objekt"}],
            selectedObjects: [],
            objectsType: 'EL',
            objectsTypeOptions: [{id: 'EL', text: 'Kalkulationselement'}, {id: 'LP', text: 'Leistungsposition'}],
            pending: false
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Fetch the list of objects where we want to create BER
         * @returns {Promise<void>}
         */
        async fetchObjects() {
            this.pending = true;
            try {
                let res = await this.$axios.post(`/offers/calculations/multiedit/objects/${this.objectsType}/${this.currentVersion}`, {
                    perPage: this.perPage,
                    currentPage: this.currentPage
                });
                this.items.splice(0);
                this.items.push(...this.reformatTableItems(res.data.data));
                this.totalRows = res.data.total;
            } catch (err) {
                console.error("Couldn't fetch objects.", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            this.pending = false;
        },
        /**
         * Handle switching from one objects type to another
         */
        onObjectsTypeSelect() {
            this.selectedObjects.splice(0);
            this.$emit('objects-selected', {type: this.objectsType, objects: []});
            this.fetchObjects();
            this.$v.$reset();
        },
        /**
         * Set additional fields for objects
         * @param objects
         * @returns {*}
         */
        reformatTableItems(objects) {
            let mapping = {'AP': object => object, 'LP': this.lpParent, 'EL': this.elParent};
            return objects.map(obj => mapping[this.objectsType](obj));
        },
        /**
         * Set parent field for LP objects
         * @param object
         * @returns {*}
         */
        lpParent(object) {
            object.parent = object.apBezeichnung !== null ? `AP ${object.apBezeichnung} (Nr ${object.apSort})` : null;
            return object;
        },
        /**
         * Set parent field for EL objects
         * @param object
         * @returns {*}
         */
        elParent(object) {
            object.parent = `LP ${object.lpBezeichnung}, AP ${object.apBezeichnung} (Nr ${object.apSort})`;
            return object;
        },
    },
    validations: {
        selectedObjects: {required}
    }
}
</script>

<style scoped>

</style>
