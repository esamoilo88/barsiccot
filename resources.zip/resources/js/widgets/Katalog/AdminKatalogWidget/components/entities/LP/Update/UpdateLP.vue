<template>
    <div>
        <modal-dialog
            modal-class="update-lp-modal"
            :is-visible="show"
            size="lg"
            @hideModal="hide"
            title-dialog="Leistungsposition bearbeiten"
        >
            <b-overlay :show="!dataLoaded">
                <div class="d-flex flex-column">
                    <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                    <div class="simple-box d-flex flex-column mb-4">
                        <FormSelect
                            v-model="form.categories.id"
                            :options="categoriesOptions()"
                            :error-conditions="errorConditions.categories"
                            label-text="Kategorie*"
                            name="kategorie"
                            select-id="kategorie"
                            searchable
                        />

                        <FormInput
                            v-model="form.name"
                            label-text="Bezeichnung*"
                            name="name"
                            input-id="name"
                            :error-conditions="errorConditions.name"
                        />

                        <Leistungtyp
                            class="p-0 pb-1"
                            ref="leistungtyp"
                            :item-data="form"
                            @leistungtyp-selected="value => form.leistungtyp = value"
                            @requestDone="() => leistungtypLoaded = true"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <FormInputAppend
                            v-model="form.inRessourcen"
                            @input="value => $emit('inRessourcen-changed', value)"
                            @submit="$emit('submit')"
                            class="lp-inRessourcen"
                            input-id="lp-inRessourcen"
                            name="inRessourcen"
                            label-text="Inflationsfaktor Ressourcen"
                            prepend="%"
                            :error-conditions="[
                                {
                                    name: 'invalid-number',
                                    condition: !$v.form.inRessourcen.decimal  && $v.form.inRessourcen.$dirty,
                                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Ressourcen'})
                                }
                            ]"
                        />
                        <FormInputAppend
                            v-model="form.inKosten"
                            @input="value => $emit('inKosten-changed', value)"
                            @submit="$emit('submit')"
                            class="lp-inKosten"
                            input-id="lp-inKosten"
                            name="inKosten"
                            label-text="Inflationsfaktor Kosten"
                            prepend="%"
                            :error-conditions="[
                                {
                                    name: 'invalid-number',
                                    condition: !$v.form.inKosten.decimal  && $v.form.inKosten.$dirty,
                                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Kosten'})
                                }
                            ]"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <OptionsAndDesc
                            ref="OptionsAndDesc"
                            :nach-aufwand="form.nachAufwand"
                            :beschreibung="form.beschreibung"
                            @nachAufwand-changed="value => form.nachAufwand = value"
                            @beschreibung-changed="value => form.beschreibung = value"
                        />
                    </div>
                </div>
            </b-overlay>

            <template #footer="{methods}">
                <button @click="onUpdate" class="btn btn-primary">
                    <b-spinner v-if="loading" small></b-spinner>
                    Leistungsposition bearbeiten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>
<script>
import {BSpinner, BOverlay} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import Validation from '@mixins/Validation/Validation';
import Leistungtyp from "../Store/Leistungtyp";
import OptionsAndDesc from "../Store/OptionsAndDesc";
import {required, helpers} from "vuelidate/lib/validators";
import {mapState} from "vuex";
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import FormSelect from "@comp/FormSelect/FormSelect";
import {createOptions} from "@helpers/Form/InputsHelper";
import {deepCopy} from "@helpers/ValueProcessing/ObjectsProcessing";

const intorfloat = helpers.regex('intorfloat', /^(-?\d+(?:\,\d+)?)$/);
const valid4Fraction = /^[0-9]*[,]?[0-9]{1,4}$/;
const valid2Fraction = /^[0-9]*[,]?[0-9]{1,2}$/;
const invalidZero = /^[0]*[,]?[0]*$/

export default {
    components: {
        ModalDialog,
        FormInput,
        Leistungtyp,
        OptionsAndDesc,
        BSpinner,
        BOverlay,
        FormInputAppend,
        FormSelect
    },
    mixins: [Validation],
    props: {
        show: {
            type: Boolean,
            required: true
        },
        item: {
            type: Object,
            required: true
        },
        selectedCategoryId: {
            default: -1,
        }
    },
    mounted() {
        this.setForm(this.item);
    },
    computed: {
        ...mapState({
            // selectedCategory: state => state.katalog.selectedCategory,
            categoriesFlat: state => state.katalog.categoriesFlat
        }),

        errorConditions() {
            return {
                name: [
                    {
                        name: 'invalid-name-required',
                        condition: this.isInvalid('name', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    }
                ],
                categories: [
                    {
                        name: 'invalid-categories',
                        condition: this.$v.form.categories.id.$dirty && !this.$v.form.categories.id.isNotEmpty,
                        text: 'Falscher Wert für das Feld Kategorie.'
                    }
                ],
            }
        },
        dataLoaded() {
            return this.leistungtypLoaded;
        }
    },
    data() {
        return {
            form: {
                id: null,
                name: null,
                leistungtyp: null,
                inRessourcen: null,
                inKosten: null,
                nachAufwand: false,
                beschreibung: null,
                categories: {id: this.selectedCategoryId, bezeichnung: ''},
            },
            loading: false,
            leistungtypLoaded: false
        }
    },
    methods: {
        categoriesOptions() {
            let opts = createOptions(
                this.categoriesFlat,
                (c) => c.id,
                (c) => c.bezeichnung,
                null
            );
            opts.unshift({id: -1, text: '-', html: '-'});
            return opts;
        },
        setForm(item) {
            this.form.id = item.leistungspositionId;
            this.form.name = item.bezeichnung;
            this.form.inRessourcen = this.$f.stringToFloat(item.inflationsfaktorRessourcen, 4);
            this.form.inKosten = this.$f.stringToFloat(item.inflationsfaktorKosten, 4);
            this.form.nachAufwand = item.nachAufwand ? item.nachAufwand : false;
            this.form.beschreibung = item.beschreibung;

            if (item.itilMain) {
                this.form.leistungtyp = `${item.itilMain.itilMainId}_`;
            }

            if (item.itilSub) {
                this.form.leistungtyp += item.itilSub.itilSubId;
            }
        },
        hide() {
            this.$emit('hide');
        },
        async onUpdate() {
            this.$v.$touch();
            let leistungtyp = this.$refs.leistungtyp.validate();

            if (this.$v.$anyError || leistungtyp.$anyError) {
                this.showValidationErrors = true;
                navigateToFirstInvalid();
                return;
            }

            this.loading = true;

            try {
                let categories = [this.form.categories.id];
                await this.$axios.put(`/admin/katalog/lp/${this.form.id}`, {...this.form, categories});

                this.$emit('success');
                this.hide();
                window.flash.success('Erfolgreich gespeichert.');
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                this.loading = false;
            }
        },
        isEmptyString(value) {
            return value === null || String(value).length === 0;
        },
        isInvalidZero(value) {
            return String(value).match(invalidZero) !== null;
        },
    },
    validations: {
        form: {
            name: {required},
            inRessourcen: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            inKosten: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            categories: {
                id: {isNotEmpty: val => val >= 0}
            }
        }
    }
}
</script>
