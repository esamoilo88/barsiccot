<template>
    <div>
        <b-overlay :show="pending">
            <p class="mb-2">Elemente werden in Leistungspositionen hinzugefügt, bitte wähle die gewünschten Leistungspositionen aus.</p>

            <div v-if="!$v.selectedLPs.required && $v.selectedLPs.$dirty" class="error-message my-2">
                <span
                    :class="{'invalid-feedback': true, 'd-block': !$v.selectedLPs.required && $v.selectedLPs.$dirty}"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true"
                >
                    Bitte wähle mindestens ein Leistungsposition aus.
                </span>
            </div>
            <div :class="{'invalid': !$v.selectedLPs.required && $v.selectedLPs.$dirty}">

                <b-table-lite id="lp-list-for-element-creation" :items="items" :fields="fields">
                    <template #cell(leistungspositionId)="item">
                        <b-form-checkbox
                            v-model="selectedLPs"
                            :key="item.item.leistungspositionId"
                            :class="'lp' + item.item.leistungspositionId"
                            :value="item.item.leistungspositionId"
                        >
                            <span class="sr-only">{{ item.item.bezeichnung }}</span>
                        </b-form-checkbox>
                    </template>

                    <template #custom-foot>
                        <b-tr v-if="items.length === 0">
                            <b-td colspan="3" class="text-center">Keine Daten vorhanden</b-td>
                        </b-tr>
                    </template>
                </b-table-lite>

                <div v-if="items.length > 0" class="pagination-wrapper">
                    <span class="total-rows-text">{{ paginationEntriesText }}</span>
                    <b-pagination
                        v-model="currentPage"
                        @change="fetchLPs"
                        :total-rows="totalRows"
                        :per-page="perPage"
                        aria-controls="lp-list-for-element-creation"
                    ></b-pagination>
                </div>

                <span class="selected-lps-number">{{ selectedLPs.length }} LP ausgewählt</span>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BTableLite, BOverlay, BPagination, BFormCheckbox, BTfoot, BTr, BTd} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";
import {mapGetters} from 'vuex';
import {required} from 'vuelidate/lib/validators';

export default {
    name: "LPList",
    components: {
        BTableLite, BOverlay, BPagination, BFormCheckbox,
        BTfoot, BTr, BTd
    },
    mixins: [Pagination],
    async created() {
        this.initPaginationMxn(1, 0, 10);
        await this.fetchLPs();
    },
    data() {
        return {
            items: [],
            fields: [
                {key: "leistungspositionId", label: "", class: "select-lp-checkbox"},
                {key: "bezeichnung", label: "Leistungsposition"},
                {key: "apBezeichnung", label: "Angebotsposition"},
                {key: "apSort", label: "Nr"},
            ],
            selectedLPs: [],
            isNothingSelected: false,
            pending: false
        }
    },
    computed: {
    },
    watch: {
        selectedLPs(newValue, oldValue) {
            this.$emit('lps-changed', this.selectedLPs);
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Fetch the list of project Leistungspositions
         * @returns {Promise<void>}
         */
        async fetchLPs() {
            this.pending = true;
            try {
                let res = await this.$axios.post(`/offers/calculations/lps/paginated-custom`, {
                    simpleId: this.simpleId,
                    fields: ['leistungspositionId', 'bezeichnung', 'ap.bezeichnung AS apBezeichnung', 'ap.sort AS apSort'],
                    withAP: true,
                    perPage: this.perPage,
                    currentPage: this.currentPage,
                    filter: {
                        currentVersionId: this.currentVersion
                    }
                });
                this.items.splice(0);
                this.items.push(...res.data.data);
                this.totalRows = res.data.total;
            } catch (err) {
                console.error("Couldn't fetch LP list.", err);
                window.flash.error('Ein Fehler ist aufgetreten.');
            }
            this.pending = false;
        }
    },
    validations: {
        selectedLPs: {required}
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";

::v-deep .select-lp-checkbox {
    width: 50px;
}

.invalid {
    border: 1px solid $error;
    border-radius: 5px;
}

.error-message {
    .invalid-feedback {
        color: $error;
        margin-bottom: 0;
        border: none;
    }
}

.selected-lps-number {
    margin: 20px 0 0 20px;
    display: block;
}
</style>
