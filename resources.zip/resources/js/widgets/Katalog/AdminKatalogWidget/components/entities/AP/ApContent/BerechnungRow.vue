<template>
    <tr>
        <!-- LP Berechnung -->
        <template v-if="parentType === 'LP'">
            <td class="pl-0 border-top">
                <span class="icon-function-mathematical-symbol"/>
                <span class="object_text">BER</span>
            </td>
            <td colspan="4" class="object_text border-top">
                {{ item.bezeichnung }}:
                {{ item.operator }}
                {{ $f.numberToString(item.wert, false, false, 0, {maximumFractionDigits: 10}) }}
            </td>
            <td class="pl-5 border-top">
                <div v-if="canCreateOrUpdate" class="options">
                    <button
                        @click="$emit('edit-ber', item)"
                        title="Berechnung bearbeiten"
                        class="options-btn"
                    >
                        <i class="icon-action-edit-default"></i>
                    </button>

                    <button
                        @click="$emit('delete-ber', item)"
                        title="Berechnung löschen"
                        class="options-btn"
                    >
                        <i class="icon-action-remove-default"></i>
                    </button>
                </div>
            </td>
        </template>

        <!-- EL Berechnung -->
        <template v-else>
            <td class="d-flex pl-2">
                <div>L</div>
                <div class="pt-1">
                    <span class="icon-function-mathematical-symbol"/>
                    <span class="object_text">BER</span>
                </div>
            </td>
            <td colspan="4" class="object_text">
                {{ item.bezeichnung }}:
                {{ item.operator }}
                {{ $f.numberToString(item.wert, false, false, null, {maximumFractionDigits: 10}) }}
            </td>
            <td class="text-nowrap">
                <button
                    @click="$emit('edit-ber', item)"
                    title="Berechnung bearbeiten"
                    class="options-btn"
                >
                    <i class="icon-action-edit-default"></i>
                </button>

                <button
                    @click="$emit('delete-ber', item)"
                    title="Berechnung löschen"
                    class="options-btn"
                >
                    <i class="icon-action-remove-default"></i>
                </button>
            </td>
        </template>
    </tr>
</template>

<script>
export default {
    name: "BerechnungRow",
    props: {
        parentType: {
            type: String,
            required: true
        },
        item: {
            type: Object,
            required: true
        },
        canCreateOrUpdate: {
            type: Boolean,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/components/onkaPositions';

.object_text {
    font-size: 16px;
    color: #0065ff;
}
.table th, .table td {
    border-top: none;
    vertical-align: middle;
}
</style>
