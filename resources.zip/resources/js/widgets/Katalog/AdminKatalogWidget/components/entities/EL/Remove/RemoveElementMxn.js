import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import Vue from 'vue';

export default Vue.util.mergeOptions(ConfirmationModal, {
    methods: {
        /**
         * Confirmation for EL removing process
         * @param element
         * @returns {Promise<void>}
         */
        async onElementRemove(element) {
            const confirmed = await this.showConfirmationModal({
                title: 'Element löschen',
                message: `Bitte bestätige die Löschung des Elements ${element.bezeichnung}`,
                okTitle: 'Element löschen',
            });

            if (confirmed) {
                window.preloader.show();
                try {
                    await this.deleteElement(element.elementId);
                    this.$eventBus.$emit('refreshTable');
                    window.preloader.hide();
                    return Promise.resolve();
                } catch (err) {
                    window.preloader.hide();
                    return Promise.reject();
                }
            } else {
                return Promise.reject();
            }
        },

        /**
         * Delete EL
         * @param elementId
         */
        async deleteElement(elementId) {
            try {
                let response = await this.$axios.delete(`/admin/katalog/el/${elementId}`);
                window.flash.showMessagesFromAjax(response.data);
                return Promise.resolve();
            } catch (err) {
                window.flash.showMessagesFromAjax(err.response.data);
                console.error('Couldn\'t delete element', err);
                return Promise.reject();
            }
        },

        // /**
        //  * Refresh LP data after deleting element
        //  * @param lpData
        //  * @param lpId
        //  * @param elementId
        //  * @returns {Promise<void>}
        //  */
        // async postRemoveElement(lpData, lpId, elementId) {
        //     try {
        //         let res = await this.$axios.get(`/offers/calculations/lps/${lpId}`);
        //         lpData.map(lp => {
        //             if (lp.leistungspositionId == lpId) {
        //                 let {ifWertKosten, ifWertRessourcen, menge, vollkostenFinal} = res.data;
        //                 lp = {...lp, ifWertKosten, ifWertRessourcen, menge, vollkostenFinal};
        //                 if (Array.isArray(lp.elements)) {
        //                     lp.elements.splice(lp.elements.map(el => el.elementId).indexOf(elementId), 1);
        //                 }
        //                 return lp;
        //             }
        //         });
        //     } catch (err) {
        //         window.flash.error("LP konnte nicht aktualisiert werden");
        //         console.error("Couldn't refresh LP", err);
        //     }
        // }
    }
});
