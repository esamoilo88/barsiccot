<template>
    <div>
        <abbr
            :class="getBadge(zuordnung)"
            :id="getUniqName(zuordnung, item.id)"
            :title="zuordnung"
        >
            {{ zuordnung }}
        </abbr>

        {{ item.katalogEl.kostenart.bezeichnung }}

        <span class="icon-navigation-right-default lightgrey"/>

        {{ item.katalogEl.bezeichnung }}
    </div>
</template>

<script>
export default {
    props: {
        item: {
            type: Object,
            required: true
        }
    },
    computed: {
        zuordnung() {
            try {
                return this.item.katalogEl.kostenart.zuordnung;
            } catch (e) {
                return null;
            }
        }
    },
    methods: {
        getUniqName(name, id) {
            return `${name}_${id}`;
        },
        getBadge(zuordnung) {
            let badge = 'badge-secondary';

            switch (zuordnung) {
                case 'ISP': badge = 'badge-info'; break;
                case 'DTS': badge = 'badge-success'; break;
                case 'DTA': badge = 'badge-warning'; break;
            }

            return `badge ${badge}`;
        }
    }
}
</script>
