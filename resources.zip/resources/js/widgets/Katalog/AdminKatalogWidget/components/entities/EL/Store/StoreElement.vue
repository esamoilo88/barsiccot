<template>
    <div>
        <modal-dialog
            modal-class="create-element-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-store-element-modal')"
            :title-dialog="elementToUpdate === null ? 'Neues Element' : 'Element Bearbeiten'"
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <FormInput
                        v-model="element.name"
                        input-id="element-name"
                        name="element-name"
                        label-text="Name*"
                        :error-conditions="[
                            {
                                name: 'empty-name',
                                condition: !$v.element.name.required  && $v.element.name.$dirty,
                                text: $t.__('validation.required', {attribute: 'Name'})
                            }
                        ]"
                    />
                    <Kostenart
                        ref="kostenart"
                        v-model="element.kostenart"
                        :element-to-update="elementToUpdate"
                    />
                </div>

                <div class="simple-box mb-4">
                    <Berechnungsart
                        ref="berechnungsart"
                        @berechnungsart-changed="value => element.berechnungsart = value"
                        @stundensatz-changed="value => element.stundensatz = value"
                        @gmkz-changed="value => element.gmkz = value"
                        @aufwand-changed="value => element.zeitstunden = value"
                        @kostenwert-changed="value => element.kostenwert = value"
                        @ma-changed="value => element.ma = value"
                        @inflation-changed="value => element.inflation = value"
                        :kostenart="element.kostenart"
                        :element-to-update="elementToUpdate"
                    />
                </div>

                <div class="simple-box">
                    <FormTextArea
                        input-id="element-beschreibung"
                        name="element-beschreibung"
                        label-text="Tätigkeitsbeschreibung"
                        v-model="element.beschreibung"
                        @handleTextArea="value => element.beschreibung = value"
                    />
                </div>
            </div>

            <template #footer="{methods}">
                <button
                    v-if="canCreateElement && elementToUpdate === null"
                    :key="'store-element-btn'"
                    @click="onCreate"
                    class="btn btn-primary"
                    :disabled="onCreatePending"
                >
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Element anlegen
                </button>
                <button
                    v-if="canCreateElement && elementToUpdate !== null"
                    :key="'update-element-btn'"
                    @click="onUpdate"
                    class="btn btn-primary"
                    :disabled="onCreatePending"
                >
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Element bearbeiten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import FormSelect from "@comp/FormSelect/FormSelect";
import Kostenart from "./Kostenart";
import Berechnungsart from "./Berechnungsart";
import LPList from "./LPList";
import {required} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {computeGmkz} from "@helpers/SimpleBussiness/Onka/Onka";

export default {
    name: "StoreElement",
    components: {
        FormTextArea,
        LPList,
        Berechnungsart,
        Kostenart,
        FormSelect,
        FormInput,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        BSpinner
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCreateElement: {
            type: Boolean,
            required: true,
            default: false
        },
        elementToUpdate: {
            type: Object,
            required: false,
            default: null
        },
        isSingleCreate: { // if we create a single EL for the specific LP
            type: Boolean,
            required: false,
            default: false
        },
        parentLpId: { // necessary if isSingleCreate is true
            type: Number,
            required: false
        }
    },
    data() {
        return {
            element: {
                name: this.elementToUpdate !== null ? this.elementToUpdate.name : '',
                kostenart: this.elementToUpdate !== null ? this.elementToUpdate.kostenart : null,
                berechnungsart: this.elementToUpdate ? this.elementToUpdate.berechnungsart : 'Aufwand',
                stundensatz: null,
                gmkz: this.elementToUpdate ? this.elementToUpdate.gmkz : null,
                kostenwert: null,
                ma: this.elementToUpdate ? this.elementToUpdate.ma : false,
                inflation: this.elementToUpdate ? this.elementToUpdate.inflationsfaktor : true,
                beschreibung: this.elementToUpdate ? this.elementToUpdate.beschreibung : null,
                zeitstunden: this.elementToUpdate ? this.elementToUpdate.zeitstunden : null,
                lps: []
            },
            onCreatePending: false
        }
    },
    created() {
        if (this.isSingleCreate) {
            this.element.lps.push(this.parentLpId);
        }
        if (this.elementToUpdate) {
            this.setForm();
        }
    },
    methods: {
        /**
         * Create EL
         * @returns {void}
         */
        async onCreate() {
            this.$v.$touch();
            let kostenart = this.$refs.kostenart.validate();
            let berechnungsart = this.$refs.berechnungsart.validate();
            if (!this.$v.$anyError && !kostenart.$anyError && !berechnungsart.$anyError) {
                this.onCreatePending = true;
                try {
                    const res = await this.$axios.post(`/admin/katalog/el`, {...this.prepareData(this.element)});
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('refreshTable');
                    this.$emit('close-store-element-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create EL", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCreatePending = false;
        },
        /**
         * Update EL
         * @returns {void}
         */
        async onUpdate() {
            this.$v.$touch();
            let kostenart = this.$refs.kostenart.validate();
            let berechnungsart = this.$refs.berechnungsart.validate();
            if (!this.$v.$anyError && !kostenart.$anyError && !berechnungsart.$anyError) {
                this.onCreatePending = true;
                try {
                    const res = await this.$axios.put(`/admin/katalog/el/${this.elementToUpdate.elementId}`,
                        {...this.prepareData(this.element)}
                    );
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('refreshTable');
                    this.$emit('close-store-element-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't update EL", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCreatePending = false;
        },
        /**
         * Map data from component object to request object
         * @returns {Object} element
         */
        prepareData() {
            let element = {};
            element.bezeichnung      = this.element.name;
            element.kostenart        = this.element.kostenart.kostenartId;
            element.berechnungsart   = this.element.berechnungsart;
            element.stundensatz      = this.element.stundensatz;
            element.gmkz             = this.element.gmkz.includes(',') === false ? computeGmkz(this.element.gmkz) : this.element.gmkz;
            element.wert             = this.element.kostenwert;
            element.ma               = this.element.ma;
            element.inflationsfaktor = this.element.inflation;
            element.beschreibung     = this.element.beschreibung;
            element.zeitstunden      = this.element.zeitstunden;
            element.lps              = this.element.lps;
            return element;
        },
        setForm() {
            this.element.name = this.elementToUpdate.bezeichnung;
            this.element.kostenart = this.elementToUpdate.kostenart;
            this.element.berechnungsart = this.elementToUpdate.zeitstunden ? 'Aufwand' : 'Euro';
            this.element.stundensatz = this.$f.numberToString(this.elementToUpdate.stundensatz, false);
            this.element.gmkz = this.elementToUpdate.gmkz;
            this.element.kostenwert = this.$f.numberToString(this.elementToUpdate.wert, false);
            this.element.ma = this.elementToUpdate.ma;
            this.element.inflation = this.elementToUpdate.inflationsfaktor;
            this.element.beschreibung = this.elementToUpdate.beschreibung;
            this.element.zeitstunden = this.elementToUpdate.zeitstunden;
            this.element.lps.push(this.parentLpId);
        }
    },
    validations: {
        element: {
            name: {required}
        }
    }
}
</script>

<style lang="scss">
.create-element-modal {
    .modal-dialog {
        min-width: 750px;
    }
}
</style>
