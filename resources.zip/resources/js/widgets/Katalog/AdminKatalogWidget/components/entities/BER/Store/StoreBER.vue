<template>
    <div>
        <modal-dialog
            modal-class="create-ber-modal"
            :is-visible="isVisible"
            @hideModal="$emit('close-store-ber-modal')"
            :title-dialog="berToUpdate === null ? 'Berechnung erstellen' : 'Berechnung bearbeiten'"
            scrollable
        >
            <div class="d-flex flex-column">
                <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                <div class="simple-box d-flex flex-column mb-4">
                    <FormInput
                        v-model="ber.bezeichnung"
                        class="mb-3"
                        input-id="ber-name"
                        name="ber-name"
                        label-text="Name*"
                        :error-conditions="[
                            {
                                name: 'empty-name',
                                condition: !$v.ber.bezeichnung.required  && $v.ber.bezeichnung.$dirty,
                                text: $t.__('validation.required', {attribute: 'Name'})
                            }
                        ]"
                    />

                    <FormSelect
                        v-model="ber.operator"
                        class="mb-3"
                        select-id="ber-operator"
                        name="ber-operator"
                        label-text="Operator*"
                        :options="operatorOptions"
                        :error-conditions="[
                            {
                                name: 'empty-operator',
                                condition: !$v.ber.operator.required  && $v.ber.operator.$dirty,
                                text: $t.__('validation.required', {attribute: 'Operator'})
                            }
                        ]"
                    />

                    <FormInput
                        v-model="ber.wert"
                        class="mb-3"
                        input-id="ber-wert"
                        name="ber-wert"
                        label-text="Wert*"
                        :use-formatter="true"
                        :formatter="formatWert"
                        :error-conditions="[
                            {
                                name: 'empty-wert',
                                condition: !$v.ber.wert.required  && $v.ber.wert.$dirty,
                                text: $t.__('validation.required', {attribute: 'Wert'})
                            }, {
                                name: 'wrong-wert',
                                condition: !$v.ber.wert.decimal  && $v.ber.wert.$dirty,
                                text: $t.__('validation.custom_rules.float_x_y', {x: '8', y: '10'})
                            }
                        ]"
                    />

                    <FormTextArea
                        v-model="ber.kommentar"
                        input-id="ber-kommentar"
                        name="ber-kommentar"
                        label-text="Kommentar"
                    />
                </div>
            </div>

            <template #footer="{methods}">
                <button
                    v-if="canCreateBer && berToUpdate === null"
                    :key="'store-ber-btn'"
                    @click="onCreate"
                    class="btn btn-primary"
                >
                    <b-spinner v-if="onSubmitPending" small></b-spinner>
                    Berechnung erstellen
                </button>
                <button
                    v-if="canCreateBer && berToUpdate !== null"
                    :key="'update-ber-btn'"
                    @click="onUpdate"
                    class="btn btn-primary"
                >
                    <b-spinner v-if="onSubmitPending" small></b-spinner>
                    Berechnung bearbeiten
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import FormTextArea from "@comp/FormTextArea/FormTextArea";
import {mapGetters} from 'vuex';
import FormSelect from "@comp/FormSelect/FormSelect";
import {required} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import ObjectsList from "res/js/widgets/Offers/OffersViewWidget/tabs/Angebotspositionen/BER/Store/ObjectsList";
import {asyncCall} from "@helpers/Async/AsyncRequests";
import {createOptions} from "@helpers/Form/InputsHelper";
import Formatter from "res/js/utils/formatter";

export default {
    name: "StoreBER",
    components: {
        ObjectsList,
        FormSelect, FormInput, ModalDialog, BFormCheckboxGroup, BFormCheckbox,
        BOverlay, BSpinner, FormTextArea
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
            default: false
        },
        canCreateBer: {
            type: Boolean,
            required: true,
            default: false
        },
        berToUpdate: {
            type: Object,
            required: false,
            default: null
        },
        target: {
            type: Object,
            required: false,
            default: null
        }
    },
    async created() {
        if (this.target !== null) {
            this.objects.push(this.target.id);
            this.objectsType = this.target.type;
        }
    },
    data() {
        return {
            ber: {
                bezeichnung: this.berToUpdate !== null ? this.berToUpdate.bezeichnung : null,
                operator: this.berToUpdate !== null ? this.berToUpdate.operator : null,
                wert: this.berToUpdate !== null
                    ? (new Formatter).numberToString(
                        this.berToUpdate.wert, false, false, null, {maximumFractionDigits: 10})
                    : null,
                kommentar: this.berToUpdate !== null ? this.berToUpdate.kommentar : null
            },
            objects: [],
            objectsType: 'EL',
            onSubmitPending: false,
            operatorOptions: [
                {id: 'empty', text: ' '}, {id: '+', text: 'Addition'}, {id: '-', text: 'Subtraktion'},
                {id: '*', text: 'Multiplikation'}, {id: '/', text: 'Division'}
            ]
        }
    },
    methods: {
        /**
         * Create BER
         * @returns {void}
         */
        async onCreate() {
            let errors = false;
            this.$v.$touch();
            errors = this.$v.$anyError;
            if (!errors) {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.post(`/admin/katalog/ber`, {
                        ...this.ber,
                        objectsType: this.objectsType,
                        objects: this.objects,
                        wert: this.ber.wert.toString().replace('.', '')
                    });
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('refreshTable');
                    this.$emit('close-store-ber-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create BER", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onSubmitPending = false;
        },
        /**
         * Update BER
         * @returns {void}
         */
        async onUpdate() {
            this.$v.$touch();
            if (!this.$v.$anyError) {
                this.onSubmitPending = true;
                try {
                    const res = await this.$axios.put(`/admin/katalog/ber/${this.berToUpdate.berechnungId}`,
                        {
                            ...this.ber,
                            objectsType: this.objectsType,
                            objects: this.objects,
                            wert: this.ber.wert.toString().replace('.', '')
                        }
                    );
                    window.flash.showMessagesFromAjax(res.data);
                    this.$eventBus.$emit('refreshTable');
                    this.$emit('close-store-ber-modal');
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't update BER", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onSubmitPending = false;

        },
        /**
         * Show success or error messages
         * @param creationErrors
         */
        showMessages(creationErrors) {
            let errorsNumber = Object.entries(creationErrors).length;
            if (errorsNumber > 0) {
                if (this.objects.length !== errorsNumber) {
                    let savedNumber = this.objects.length - errorsNumber;
                    window.flash.success(`${savedNumber} von ${this.objects.length} Berechnungen erfolgreich gespeichert`);
                }
                creationErrors.map(errorMsg => window.flash.error(errorMsg));
            } else {
                window.flash.success((this.target !== null ? 'Berechnung' : 'Berechnungen') + ' erfolgreich gespeichert');
            }
        },
        /**
         * Handle selection of objects in objects list
         */
        onObjectsSelected(data) {
            this.objects.splice(0);
            this.objects.push(...data.objects);
            this.objectsType = data.type;
        },
        /**
         * Format wert value
         */
        formatWert(value = null) {
            return value !== null ? value.toString().replace(/[^0-9,-]/, '') : null;
        },
        setForm() {

        }
    },
    validations: {
        ber: {
            bezeichnung: {required},
            operator: {required},
            wert: {
                required,
                decimal(value) {
                    return String(value).match(/^-?\d{1,8},?\d{0,10}$/) !== null;
                }
            }
        }
    }
}
</script>

<style lang="scss">
.create-ber-modal {
    .modal-dialog {
        min-width: 750px;
    }
}
</style>
