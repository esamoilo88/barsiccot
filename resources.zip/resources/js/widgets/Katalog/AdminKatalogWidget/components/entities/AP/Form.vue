<template>
    <div>
        <p>Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

        <div class="simple-box mb-4">
            <b-form-group>
                <FormSelect
                    v-model="form.categories.id"
                    :options="categoriesOptions()"
                    :error-conditions="errorConditions.categories"
                    label-text="Kategorie*"
                    name="kategorie"
                    select-id="kategorie"
                    searchable
                />
            </b-form-group>

            <b-form-group>
                <FormInput
                    v-model="form.name"
                    :error-conditions="errorConditions.name"
                    label-text="Name*"
                    name="name"
                    input-id="name"
                />
            </b-form-group>

            <b-overlay :show="pending">
                <b-form-group>
                    <FormSelect
                        v-model="form.producttypeId"
                        :options="producttypes"
                        :error-conditions="errorConditions.producttypeId"
                        label-text="Produkttyp*"
                        name="producttypeId"
                        select-id="producttypeId"
                        searchable
                    />
                </b-form-group>
            </b-overlay>

            <b-form-group>
                <div class="row">
                    <div class="col-6">
                        Mengentyp:
                    </div>
                    <div class="col-auto">
                        <strong>{{ producttype.mengentypName }}</strong>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        Preistyp:
                    </div>
                    <div class="col-auto">
                        <strong>{{ producttype.preistypName }}</strong>
                    </div>
                </div>
            </b-form-group>

            <b-form-group>
                <FormInput
                    v-model="form.quantity"
                    :error-conditions="errorConditions.quantity"
                    label-text="Menge*"
                    name="menge"
                    input-id="menge"
                />
            </b-form-group>

            <b-form-group>
                <FormInput
                    v-model="form.code"
                    :error-conditions="errorConditions.code"
                    label-text="Code*"
                    name="code"
                    input-id="code"
                />
            </b-form-group>
        </div>

        <div class="simple-box mb-4">
            <b-form-group>
                <b-form-checkbox switch v-model="form.fixedPrice">
                    Festpreis
                </b-form-checkbox>

                <p class="text-muted">Wenn Festpreis aktiviert wird, wird der Stückpreis nicht anhand der Stückkosten berechnet sondern kann direkt festgelegt werden. Dies kann die effektive Marge beeinflussen.</p>
            </b-form-group>

            <template v-if="form.fixedPrice">
                <b-form-group>
                    <FormInputAppend
                        v-model="form.unitPrice"
                        input-id="unitPrice"
                        name="unitPrice"
                        label-text="Stückpreis*"
                        :error-conditions="errorConditions.unitPrice"
                        prepended
                        prepend="€"
                    />
                    <p class="text-muted mt-2">Auf den hier erfassten Festpreis wird der Gemeinkostenzuschlag nachträglich angewendet. Bitte trage daher den Festpreis als TP1 ein.</p>
                </b-form-group>
            </template>
        </div>

        <div class="simple-box mb-4">
            <b-form-group>
                <FormTextArea
                    v-model="form.beschreibung"
                    @handleTextArea="handleTextArea"
                    label-text="Langbeschreibung"
                    name="beschreibung"
                    input-id="beschreibung"
                    rows="8"
                />
            </b-form-group>
        </div>
    </div>
</template>
<script>
import {BButton, BFormGroup, BFormCheckbox, BOverlay} from 'bootstrap-vue';
import FormInput from '@comp/FormInput/FormInput';
import FormInputAppend from '@comp/FormInput/FormInputAppend';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormTextArea from '@comp/FormTextArea/FormTextArea';
import Validation from '@mixins/Validation/Validation';
import {mapGetters, mapState} from "vuex";
import {required, integer, requiredIf, helpers} from "vuelidate/lib/validators";
import {createOptions} from "@helpers/Form/InputsHelper";

const intorfloat = helpers.regex('intorfloat', /^(-?\d+(?:\,\d+)?)$/);

const defaultType = 1;
const customType = 2;

export default {
    components: {BButton, FormInput, FormSelect, FormTextArea, BFormGroup, BFormCheckbox, FormInputAppend, BOverlay},
    mixins: [Validation],
    props: {
        insertBeforeBtnTitle: {
            type: String,
            default: 'Einfügen vor'
        },
        insertAfterBtnTitle: {
            type: String,
            default: 'Einfügen nach'
        },
        form: {
            required: true,
            type: Object
        }
    },
    data() {
        return {
            producttype: {
                mengentypName: null,
                preistypName: null,
            },
            producttypes: [],
            aps: [],
            options: [
                {
                    id: defaultType,
                    text: 'Angebot'
                },
                {
                    id: customType,
                    text: 'Individual'
                }
            ],
            pending: true
        }
    },
    watch: {
        'form.producttypeId': function () {
            this.onProducttypeInput(this.form.producttypeId)
        }
    },
    computed: {
        ...mapState({
            selectedCategory: state => state.katalog.selectedCategory,
            categoriesFlat: state => state.katalog.categoriesFlat
        }),

        errorConditions() {
            return {
                quantity: [
                    {
                        name: 'invalid-quantity-required',
                        condition: this.isInvalid('quantity', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Menge'})
                    },
                    {
                        name: 'invalid-quantity-integer',
                        condition: this.isInvalid('quantity', 'integer'),
                        text: 'Falscher Wert für das Feld Menge.'
                    }
                ],
                name: [
                    {
                        name: 'invalid-name',
                        condition: this.isInvalid('name'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    }
                ],
                producttypeId: [
                    {
                        name: 'invalid-producttypeId',
                        condition: this.isInvalid('producttypeId'),
                        text: 'Produkttyp muss ausgefüllt werden.'
                    }
                ],
                unitPrice: [
                    {
                        name: 'invalid-unitPrice-required',
                        condition: this.isInvalid('unitPrice', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Stückpreis'})
                    },
                    {
                        name: 'invalid-unitPrice-intorfloat',
                        condition: this.isInvalid('unitPrice', 'intorfloat'),
                        text: 'Falscher Wert für das Feld Stückpreis.'
                    }
                ],
                categories: [
                    {
                        name: 'invalid-categories',
                        condition: this.$v.form.categories.id.$dirty && !this.$v.form.categories.id.isNotEmpty,
                        text: 'Falscher Wert für das Feld Kategorie.'
                    }
                ],
                code: [
                    {
                        name: 'invalid-code',
                        condition: this.isInvalid('code'),
                        text: 'Falscher Wert für das Feld Code.'
                    }
                ]
            }
        }
    },
    async mounted() {
        await this.getProducttypes();
        this.onProducttypeInput(this.form.producttypeId)
    },
    methods: {
        categoriesOptions() {
            let opts = createOptions(
                this.categoriesFlat,
                (c) => c.id,
                (c) => c.bezeichnung,
                null
            );
            opts.unshift({id: -1, text: '-', html: '-'});
            return opts;
        },
        clear() {
            this.producttype.mengentypName = null;
            this.producttype.preistypName = null;

            this.showValidationErrors = false;
        },
        async getProducttypes() {
            this.pending = true;
            try {
                const response = await this.$axios.get(`/onka/producttypes`);
                this.producttypes = response.data;
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            }
            this.pending = false;
        },
        onProducttypeInput(id) {
            const producttype = this.producttypes.find(item => item.id == id);
            if (producttype) this.producttype = producttype;
        },
        handleTextArea(value) {
            this.form.beschreibung = value;
        },
        isDisabled(value) {
            return value == defaultType;
        },
    },
    validations: {
        form: {
            name: {required},
            producttypeId: {
                required,
                integer
            },
            quantity: {
                required,
                integer
            },
            unitPrice: {
                required: requiredIf('fixedPrice'),
                intorfloat
            },
            categories: {
                id: {isNotEmpty: val => val >= 0}
            },
            code: {required}
        }
    }
}
</script>
