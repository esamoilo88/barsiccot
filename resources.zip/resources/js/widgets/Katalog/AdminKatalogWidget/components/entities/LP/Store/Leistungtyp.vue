<template>
    <div>
        <b-overlay :show="pending" class="p-1">
            <FormSelect
                v-model="leistungtyp"
                @input="onSelect"
                select-id="lp-leistungtyp"
                name="lp-leistungtyp"
                label-text="Leistungstyp*"
                :options="leistungtypOptions"
                searchable
                :error-conditions="[
                    {
                        name: 'empty-leistungtyp',
                        condition: !$v.leistungtyp.required  && $v.leistungtyp.$dirty,
                        text: $t.__('validation.required', {attribute: 'Leistungstyp'})
                    },
                ]"
            />
        </b-overlay>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {createOptions} from "@helpers/Form/InputsHelper";
import {required} from "vuelidate/lib/validators";
import {BOverlay} from 'bootstrap-vue';

export default {
    name: "Leistungtyp",
    components: {FormSelect, BOverlay},
    async created() {
        await this.fetchLeistungtypData();
    },
    props: {
        itemData: {
            type: Object,
            default: () => {
                return {
                    leistungtyp: null
                }
            }
        }
    },
    data() {
        return {
            leistungtyp: this.itemData.leistungtyp,
            leistungtypOptions: [],
            pending: false
        }
    },
    methods: {
        /**
         * Fetch the list of leistungtyp and create
         * options array out of it
         * @returns {Promise<void>}
         */
        async fetchLeistungtypData() {
            this.pending = true;
            try {
                let res = await this.$axios.get('/offers/costs/leistungtyp');
                this.leistungtypOptions.splice(0);
                this.leistungtypOptions.push(...createOptions(
                    res.data,
                    (l) => l.id,
                    (l) => l.bezeichnung,
                    'group',
                    false
                ));
            } catch (err) {
                this.leistungtypOptions.splice(0);
                console.error("Couldn't fetch leistungtyp.", err);
            } finally {
                this.$emit('requestDone');
                this.pending = false;
            }
        },
        onSelect(value) {
            this.leistungtyp = value;
            this.$emit('leistungtyp-selected', value)
        },
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
    },
    validations: {
        leistungtyp: { required },
    }
}
</script>
