export default {
    data() {
        return {
            isBERFormActive: false,
            berToUpdate: null,
            berTargetObj: null // object for which we create BER
        }
    },
    methods: {
        createBER(data) {
            this.isBERFormActive = true;
            this.berTargetObj = data.id ? {type: data.type, id: data.id} : null;
        },
        updateBER(data) {
            this.isBERFormActive = true;
            this.berToUpdate = data.ber;
            let objectId = data.target.id;
            let objectType = data.target.type;
            this.berTargetObj = objectId !== null && objectType !== null ? {type: objectType, id: objectId} : null;
        },
        closeBERDialog() {
            this.berTargetObj = null;
            this.berToUpdate = null;
            this.isBERFormActive = false;
        }
    }
}
