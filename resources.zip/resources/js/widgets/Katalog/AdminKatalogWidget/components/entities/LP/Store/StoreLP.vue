<template>
    <div>
        <modal-dialog
            modal-class="create-element-modal"
            :is-visible="show"
            @hideModal="hide"
            title-dialog="Neue Leistungspositionen"
        >
            <b-overlay :show="!dataLoaded">
                <div class="d-flex flex-column">
                    <p class="mt-2 mb-4">Bitte fülle alle mit einem * gekennzeichneten Felder aus.</p>

                    <div class="simple-box d-flex flex-column mb-4">
                        <FormSelect
                            v-model="form.categories.id"
                            :options="categoriesOptions()"
                            :error-conditions="errorConditions.categories"
                            label-text="Kategorie*"
                            name="kategorie"
                            select-id="kategorie"
                            searchable
                        />

                        <FormInput
                            v-model="form.name"
                            label-text="Bezeichnung*"
                            name="name"
                            input-id="name"
                            :error-conditions="errorConditions.name"
                        />

                        <Leistungtyp
                            class="p-0 pb-1"
                            ref="leistungtyp"
                            :item-data="form"
                            @leistungtyp-selected="value => form.leistungtyp = value"
                            @requestDone="() => leistungtypLoaded = true"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <FormInputAppend
                            v-model="form.inRessourcen"
                            @input="value => $emit('inRessourcen-changed', value)"
                            @submit="$emit('submit')"
                            class="lp-inRessourcen"
                            input-id="lp-inRessourcen"
                            name="inRessourcen"
                            label-text="Inflationsfaktor Ressourcen"
                            prepend="%"
                            :error-conditions="[
                                {
                                    name: 'invalid-number',
                                    condition: !$v.form.inRessourcen.decimal  && $v.form.inRessourcen.$dirty,
                                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Ressourcen'})
                                }
                            ]"
                        />
                        <FormInputAppend
                            v-model="form.inKosten"
                            @input="value => $emit('inKosten-changed', value)"
                            @submit="$emit('submit')"
                            class="lp-inKosten"
                            input-id="lp-inKosten"
                            name="inKosten"
                            label-text="Inflationsfaktor Kosten"
                            prepend="%"
                            :error-conditions="[
                                {
                                    name: 'invalid-number',
                                    condition: !$v.form.inKosten.decimal  && $v.form.inKosten.$dirty,
                                    text: $t.__('validation.numeric', {attribute: 'Inflationsfaktor Kosten'})
                                }
                            ]"
                        />
                    </div>

                    <div class="simple-box mb-4">
                        <OptionsAndDesc
                            ref="OptionsAndDesc"
                            :nach-aufwand="form.nachAufwand"
                            :beschreibung="form.beschreibung"
                            @nachAufwand-changed="value => form.nachAufwand = value"
                            @beschreibung-changed="value => form.beschreibung = value"
                        />
                    </div>

                    <div class="simple-box">
                      <APList
                          ref="apList"
                          @aps-changed="value => {form.aps.splice(0); form.aps.push(...value)}"
                      />
                    </div>
                </div>
            </b-overlay>


            <template #footer="{methods}">
                <button v-if="canCreateLp" @click="onCreate" class="btn btn-primary">
                    <b-spinner v-if="onCreatePending" small></b-spinner>
                    Leistungspositionen anlegen
                </button>
                <button @click="methods.hideModal" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import {BFormCheckboxGroup, BFormCheckbox, BOverlay, BSpinner} from 'bootstrap-vue';
import ModalDialog from "@comp/ModalDialog/ModalDialog";
import FormInput from "@comp/FormInput/FormInput";
import {mapState} from 'vuex';
import FormSelect from "@comp/FormSelect/FormSelect";
import Leistungtyp from "./Leistungtyp";
import {helpers, required} from 'vuelidate/lib/validators';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import OptionsAndDesc from "./OptionsAndDesc";
import APList from "./APList";
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {createOptions} from "@helpers/Form/InputsHelper";
import Validation from "@mixins/Validation/Validation";
import {deepCopy} from "@helpers/ValueProcessing/ObjectsProcessing";

const intorfloat = helpers.regex('intorfloat', /^(-?\d+(?:\,\d+)?)$/);
const valid4Fraction = /^[0-9]*[,]?[0-9]{1,4}$/;
const valid2Fraction = /^[0-9]*[,]?[0-9]{1,2}$/;
const invalidZero = /^[0]*[,]?[0]*$/

export default {
    name: "StoreLP",
    components: {
        APList,
        OptionsAndDesc,
        Leistungtyp,
        FormSelect,
        FormInput,
        ModalDialog,
        BFormCheckboxGroup,
        BFormCheckbox,
        BOverlay,
        BSpinner,
        FormInputAppend
    },
    mixins: [Validation],
    props: {
        show: {
            type: Boolean,
            required: true,
            default: false
        },
        canCreateLp: {
            type: Boolean,
            required: true,
            default: false
        },
        selectedCategoryId: {
            default: -1,
        }
    },
    data() {
        return {
            form: {
                id: null,
                name: null,
                leistungtyp: null,
                inRessourcen: null,
                inKosten: null,
                nachAufwand: false,
                beschreibung: null,
                categories: {id: this.selectedCategoryId, bezeichnung: ''},
                aps: []
            },
            leistungtypLoaded: false,
            onCreatePending: false
        }
    },
    computed: {
        ...mapState({
            categoriesFlat: state => state.katalog.categoriesFlat
        }),

        errorConditions() {
            return {
                name: [
                    {
                        name: 'invalid-name-required',
                        condition: this.isInvalid('name', 'required'),
                        text: this.$t.__('validation.required', {attribute: 'Name'})
                    }
                ],
                categories: [
                    {
                        name: 'invalid-categories',
                        condition: this.$v.form.categories.id.$dirty && !this.$v.form.categories.id.isNotEmpty,
                        text: 'Falscher Wert für das Feld Kategorie.'
                    }
                ],
            }
        },
        dataLoaded() {
            return this.leistungtypLoaded;
        }
    },
    methods: {
        categoriesOptions() {
            let opts = createOptions(
                this.categoriesFlat,
                (c) => c.id,
                (c) => c.bezeichnung,
                null
            );
            opts.unshift({id: -1, text: '-', html: '-'});
            return opts;
        },
        /**
         * Create LP
         * @returns {void}
         */
        async onCreate() {
            this.$v.$touch();
            let leistungtyp = this.$refs.leistungtyp.validate();
            let APList = this.$refs.apList.validate();
            if (!this.$v.$anyError && !leistungtyp.$anyError && !APList.$anyError) {
                this.onCreatePending = true;
                try {
                    let form = {...this.form, categories: [this.form.categories.id]};
                    const res = await this.$axios.post(`/admin/katalog/lp`, {...form});
                    window.flash.showMessagesFromAjax(res.data);

                    this.$emit('success');
                    this.hide();
                } catch (err) {
                    window.flash.showMessagesFromAjax(err.response.data);
                    console.error("Couldn't create LP", err);
                }
            } else {
                navigateToFirstInvalid();
            }
            this.onCreatePending = false;
        },
        hide() {
            this.$emit('hide');
        },
        isEmptyString(value) {
            return value === null || String(value).length === 0;
        },
        isInvalidZero(value) {
            return String(value).match(invalidZero) !== null;
        },

    },
    validations: {
        form: {
            name: {required},
            inRessourcen: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            inKosten: {
                decimal(value) {
                    if (this.isEmptyString(value)) return true;
                    if (this.isInvalidZero(value)) return false;
                    return String(value).match(valid4Fraction) !== null;
                }
            },
            categories: {
                id: {isNotEmpty: val => val >= 0}
            }
        }
    }
}
</script>

<style lang="scss">
    .create-element-modal {
        .modal-dialog {
            min-width: 750px;
        }
    }
    .lp-name {
        margin-bottom: 15px;
    }
</style>
