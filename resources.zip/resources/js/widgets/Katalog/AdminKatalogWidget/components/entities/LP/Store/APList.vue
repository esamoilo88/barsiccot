<template>
    <div>
        <b-overlay :show="pending">
            <p class="mb-2">Bitte wähle die Angebotspositionen aus in denen die Leistungsposition erstellt werden soll.</p>

            <div v-if="!$v.selectedAP.required && $v.selectedAP.$dirty" class="error-message my-2">
                <span
                    :class="{'invalid-feedback': true, 'd-block': !$v.selectedAP.required && $v.selectedAP.$dirty}"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true"
                >
                    Bitte wähle mindestens eine Angebotsposition aus.
                </span>
            </div>
            <div :class="{'invalid': !$v.selectedAP.required && $v.selectedAP.$dirty}">

                <b-table-lite id="ap-list-for-lp-creation" :items="items" :fields="fields">
                    <template #cell(id)="data">
                        <b-form-checkbox
                            @change="handleCheck(data.item.id)"
                            :key="data.item.id"
                            :class="'ap' + data.item.id"
                            :value="data.item.id"
                            v-model="selectedAP"
                        >
                            <span class="sr-only">{{ data.item.bezeichnung }}</span>
                        </b-form-checkbox>
                    </template>
                    <template #cell(name)="data">
                        <truncated-text
                            :text="data.item.name"
                            title="Angebotsposition bezeichnung"
                            :width=350
                        />
                    </template>

                    <template #custom-foot>
                        <b-tr v-if="items.length === 0">
                            <b-td colspan="3" class="text-center">Keine Daten vorhanden</b-td>
                        </b-tr>
                    </template>
                </b-table-lite>

                <div v-if="items.length > 0" class="pagination-wrapper">
                    <span class="total-rows-text">{{ paginationEntriesText }}</span>
                    <b-pagination
                        v-model="currentPage"
                        @input="fetchAPs"
                        :total-rows="totalRows"
                        :per-page="perPage"
                        aria-controls="lp-list-for-element-creation"
                    ></b-pagination>
                </div>

                <div class="d-flex align-items-md-baseline">
                    <span class="selected-lps-number mr-3">{{ selectedAP.length }} AP ausgewählt</span>
                </div>

            </div>
        </b-overlay>
    </div>
</template>

<script>
import {BTableLite, BOverlay, BPagination, BFormCheckbox, BTfoot, BTr, BTd} from 'bootstrap-vue';
import Pagination from "@mixins/Pagination/Pagination";
import {required} from 'vuelidate/lib/validators';
import FormInput from "@comp/FormInput/FormInput";
import InlineInput from "@comp/InlineInput/InlineInput";
import TruncatedText from "@comp/TruncatedText/TruncatedText";

export default {
    name: "APList",
    components: {
        TruncatedText,
        InlineInput,
        FormInput,
        BTableLite, BOverlay, BPagination, BFormCheckbox,
        BTfoot, BTr, BTd
    },
    mixins: [Pagination],
    async created() {
        this.initPaginationMxn(1, 0, 10);
        await this.fetchAPs();
    },
    data() {
        return {
            items: [],
            fields: [
                {key: "id", label: "", class: "select-ap-checkbox"},
                {key: "name", label: "Angebotsposition"},
                {key: "categoryName", label: "Kategorie"},
                {key: "sort", label: "Nr"}
            ],
            selectedAP: [],
            isAllSelected: false,
            pending: false,
            allAps: [],
        }
    },
    methods: {
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            this.$v.$touch();
            return this.$v;
        },
        /**
           * Fetch the list of project APs
         * @returns {Promise<void>}
         */
        async fetchAPs() {
            this.pending = true;
            try {
                let res = await this.$axios.get(`/admin/katalog/ap/list`, {
                    params: {
                        perPage: 10,
                        currentPage: this.currentPage,
                    }
                });
                this.items.splice(0);
                this.items.push(...res.data.data);
                this.totalRows = res.data.total;
                this.allAps = this.items.map(item => item.angebotspositionId);
            } catch (err) {
                console.error("Couldn't fetch AP list.", err);
                window.flash.error('Ein Fehler ist aufgetreten.');
            }
            this.setAllSelected();
            this.pending = false;
        },
        handleCheck(value) {
            this.isApChecked(value) ? this.addApToSelectedList(value): this.removeApFromSelectedList(value);
            this.setAllSelected();
            this.emitEvent();
        },
        addApToSelectedList(apId) {
            if (this.selectedAP.includes(apId)) return;
            this.selectedAP.push(apId);
        },
        removeApFromSelectedList(apId) {
            this.selectedAP = this.selectedAP.filter(item => item !== apId);
        },
        isApChecked(apId) {
            return this.selectedAP.lastIndexOf(apId) !== -1;
        },
        chooseAll() {
            if (this.isAllSelected) {
                this.allAps.forEach(apId => {this.addApToSelectedList(apId)});
            } else {
                this.allAps.forEach(apId => {this.removeApFromSelectedList(apId)});
            }
            this.emitEvent();
        },
        emitEvent() {
            this.$emit('aps-changed', this.selectedAP);
        },
        isAllAPSelectedOnPage() {
            return this.selectedAP.filter(ap => this.allAps.includes(ap)).length === this.allAps.length;
        },
        setAllSelected() {
            this.isAllSelected = this.isAllAPSelectedOnPage() && this.items.length > 0;
        }
    },
    validations: {
        selectedAP: {required}
    }
}
</script>

<style lang="scss" scoped>
    @import "resources/sass/variables";

    ::v-deep .select-lp-checkbox {
        width: 50px;
    }
    .invalid {
        border: 1px solid $error;
        border-radius: 5px;
    }
    .select-all-checkbox {
        margin-left: 11px;
        margin-top: 15px;
        margin-bottom: 15px;
    }
    .error-message {
        .invalid-feedback {
            color: $error;
            margin-bottom: 0;
            border: none;
        }
    }
    .selected-lps-number {
        margin: 20px 0 0 20px;
        display: block;
    }
    .quantity-input {
        max-height: 30px;
        max-width: 80px;
        font-size: 1.125rem !important;
    }
    .link {
        color: #00739F;
        &:hover {
            text-decoration: underline;
            cursor: pointer;
        }
    }
</style>
