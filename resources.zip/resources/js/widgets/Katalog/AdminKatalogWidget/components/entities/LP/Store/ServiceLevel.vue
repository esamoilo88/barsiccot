<template>
    <div>
        <b-overlay :show="pending" class="p-1">
            <FormSelect
                v-model="servicelevel"
                @input="value => $emit('servicelevel-selected', value)"
                :value="servicelevel"
                select-id="lp-servicelevel"
                name="lp-servicelevel"
                label-text="Servicelevel"
                :options="servicelevelOptions"
                searchable
            />
        </b-overlay>
    </div>
</template>

<script>
import FormSelect from "@comp/FormSelect/FormSelect";
import {createOptions} from "@helpers/Form/InputsHelper";
import {BOverlay} from 'bootstrap-vue';

export default {
    name: "ServiceLevel",
    components: {FormSelect, BOverlay},
    async created() {
        await this.fetchServicelevelData();
    },
    props: {
        itemData: {
            type: Object,
            default: () => {
                return {
                    serviceLevel: null
                }
            }
        }
    },
    data() {
        return {
            servicelevel: this.itemData.serviceLevel,
            servicelevelOptions: [],
            pending: false
        }
    },
    methods: {
        /**
         * Fetch the list of kostenstelle and create
         * options array out of it
         * @returns {Promise<void>}
         */
        async fetchServicelevelData() {
            this.pending = true;

            try {
                let res = await this.$axios.get('/offers/costs/servicelevel');
                this.servicelevelOptions.splice(0);
                this.servicelevelOptions.push(...createOptions(
                    res.data,
                    (k) => k.servicelevelId,
                    (k) => k.beschreibung,
                    'bezeichnung',
                    true
                ));
            } catch (err) {
                this.servicelevelOptions.splice(0);
                console.error("Couldn't fetch servicelevel.", err);
            } finally {
                this.$emit('requestDone');
                this.pending = false;
            }
        }
    }
}
</script>
