<template>
    <div>
        <FormTextArea
            v-model="form.beschreibung"
            input-id="lp-beschreibung"
            name="lp-beschreibung"
            rows="5"
            label-text="Leistungsbeschreibung"
            @handleTextArea="handleTextArea"
        />
        <div class="switches-list">
            <b-form-group class="mb-0">
                <b-form-checkbox
                    v-model="form.nachAufwand"
                    @input="value => $emit('nachAufwand-changed', value)"
                    switch
                >
                    Leistung nach Aufwand
                </b-form-checkbox>
                <div class="text-muted">
                    Dieses Feld hat nur Einfluss auf die Verdatung in SeCeIT. Wenn aktiviert, kann bei der
                    Verdatung nur die aufgewendete Zeit erfasst werden. Die erledigte Stückzahl ergibt sich
                    dann aus der erfassten Zeit. Bitte setze diesen Haken nicht wenn es sich um eine optionale
                    Leistung handelt.
                </div>
            </b-form-group>
        </div>
    </div>
</template>

<script>
import {
    BOverlay, BFormGroup, BFormCheckbox
} from 'bootstrap-vue';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormTextArea from "@comp/FormTextArea/FormTextArea";

export default {
    name: "OptionsAndDesc",
    components: {
        FormSelect, BOverlay, BFormGroup,
        BFormCheckbox, FormTextArea
    },
    props: {
        nachAufwand: {type: Boolean, default: false},
        beschreibung: {type: String, default: null},
    },
    data() {
        return {
            form: {
                nachAufwand: this.nachAufwand,
                beschreibung: this.beschreibung
            },
        }
    },
    methods: {
        handleTextArea(value) {
            this.form.beschreibung = value;
            this.$emit('beschreibung-changed', value)
        },
    }
}
</script>

<style lang="scss" scoped>
.switches-list {
    margin-top: 30px;
    .indirekteKosten-switch {
        margin-top: 25px;
    }
    .text-muted {
        margin-top: 10px;
    }
}
</style>
