<!--Service between Form.vue and Index.vue that manages data-->
<template>
    <modal-dialog
        :is-visible="show"
        size="lg"
        @hideModal="hideModal"
        :title-dialog="modalTitle"
        modal-class="manage-ap"
    >
        <div @keyup.enter="submit">
            <Form
                ref="form"
                :form="form"
            />
        </div>

        <template v-slot:footer>
            <b-button variant="primary" @click="submit">{{ submitBtnTitle }}</b-button>
            <b-button variant="secondary" @click="hideModal">Abbrechen</b-button>
        </template>
    </modal-dialog>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import Form from './Form';
import {BButton} from 'bootstrap-vue';
import {navigateToFirstInvalid} from "@helpers/Form/ValidationHelper";
import {AngebotspositionForm} from "res/js/widgets/Katalog/AdminKatalogWidget/components/AngebotspositionForm";

export default {
    components: {Form, ModalDialog, BButton},
    data() {
        return {
            form: new AngebotspositionForm(),
        }
    },
    props: {
        show: {
            type: Boolean,
            default: false
        },
        item: {
            type: AngebotspositionForm,
            default: () => {
                return null;
            }
        },
        selectedCategoryId: {
            default: -1,
        }
    },
    mounted() {
        this.form.setCategories({id: this.selectedCategoryId, bezeichnung: ''});

        if (this.item) {
            this.setForm();
        }
    },
    computed: {
        modalTitle() {
            return this.form.id ? 'Angebotsposition bearbeiten' : 'Neue Angebotsposition';
        },
        submitBtnTitle() {
            return this.form.id ? 'Angebotsposition bearbeiten' : 'Angebotsposition anlegen';
        }
    },
    methods: {
        hideModal() {
            this.clearForm();
            this.$refs.form.clear();

            this.$emit('hide');
        },
        setForm() {
            this.form = this.item;
        },
        clearForm() {
            this.form = new AngebotspositionForm();
        },
        async submit() {
            if (!this.$refs.form.validate()) {
                navigateToFirstInvalid();
                return;
            }

            window.preloader.show();

            try {
                const response = this.form.id ?
                    await this.$axios.put(`/admin/katalog/ap/${this.form.id}`, this.form) :
                    await this.$axios.post('/admin/katalog/ap', this.form);

                window.flash.showMessagesFromAjax(response.data);

                this.$emit('success');

                this.hideModal();
            } catch (error) {
                window.flash.showMessagesFromAjax(error.response.data);
            } finally {
                window.preloader.hide();
            }
        }
    }
}
</script>
