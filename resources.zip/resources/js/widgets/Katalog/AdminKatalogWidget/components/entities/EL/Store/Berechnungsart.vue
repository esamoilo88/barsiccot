<template>
    <div>
        <b-overlay :show="pending">
            <div class="d-flex pb-2">
                <span class="mr-4">Berechnungsart:</span>
                <b-form-group v-slot="{ ariaDescribedby }">
                    <b-form-radio-group
                        id="berechnungsart-type-radio"
                        v-model="berechnungsartType"
                        :aria-describedby="ariaDescribedby"
                        name="berechnungsart-type-radio"
                        @input="onBerechnungsartChange"
                        @change="val => $emit('change', {field: 'berechnungsart', value: val})"
                    >
                        <b-form-radio value="Aufwand" :disabled="kostentype === 'Kosten'">Aufwand</b-form-radio>
                        <b-form-radio value="Euro">Euro</b-form-radio>
                    </b-form-radio-group>
                </b-form-group>
            </div>
            <span v-if="berechnungsartType === 'Aufwand'">Aufwand (hhh:mm:ss):*</span>
            <div class="inputs-list d-flex justify-content-between">
                <FormInputAppend
                    v-if="berechnungsartType === 'Euro'"
                    v-model="form.kostenwert"
                    @input="value => $emit('kostenwert-changed', value)"
                    @change="value => $emit('change', {field: 'kostenwert', value})"
                    @submit="$emit('submit')"
                    class="element-kostenwert"
                    :key="'kostenwert'"
                    input-id="element-kostenwert"
                    name="kostenwert"
                    label-text="Kostenwert*"
                    prepend="€"
                    :error-conditions="[
                        {
                            name: 'empty-kostenwert',
                            condition: !$v.form.kostenwert.required  && $v.form.kostenwert.$dirty,
                            text: $t.__('validation.required', {attribute: 'Kostenwert'})
                        },
                        {
                            name: 'wrong-format-kostenwert',
                            condition: !$v.form.kostenwert.decimal  && $v.form.kostenwert.$dirty,
                            text: $t.__('validation.wrong_data')
                        },
                    ]"
                />
                <div
                    v-else
                    class="width-30"
                >
                    <div :class="{'invalid': aufwandValidation, 'd-flex align-items-center p-1': true}">
                        <b-form-input
                            v-model="form.hour"
                            :key="'hour'"
                            @input="value => $emit('aufwand-changed', aufwand)"
                            @change="value => $emit('change', {field: 'zeitstunden', value: aufwand})"
                            id="hour"
                            name="hour"
                            class="width-aufwand"
                        />
                        <span class="mr-1 ml-1 font-weight-bold"> : </span>
                        <b-form-input
                            v-model="form.minute"
                            :key="'minute'"
                            @input="value => $emit('aufwand-changed', aufwand)"
                            @change="value => $emit('change', {field: 'zeitstunden', value: aufwand})"
                            id="minute"
                            name="minute"
                            class="width-aufwand"
                        />
                        <span class="mr-1 ml-1 font-weight-bold"> : </span>
                        <b-form-input
                            v-model="form.second"
                            :key="'second'"
                            @input="value => $emit('aufwand-changed', aufwand)"
                            @change="value => $emit('change', {field: 'zeitstunden', value: aufwand})"
                            id="second"
                            name="second"
                            class="width-aufwand"
                        />
                    </div>
                    <div
                        v-if="aufwandValidation"
                        class="error-message my-2">
                        <span
                            :class="{'invalid-feedback': true, 'd-block': aufwandValidation}"
                            role="alert"
                            aria-live="assertive"
                            aria-atomic="true"
                        >
                            Aufwand muss ausgefüllt werden (gültig: hhh:mm:ss)
                        </span>
                    </div>
                </div>
                <FormSelect
                    v-model="stundensatzIdSelected"
                    @input="onStundensatzSelect"
                    @select="val => $emit('change', {field: 'stundensatz', value: val})"
                    class="element-stundensatz"
                    select-id="element-stundensatz"
                    name="stundensatz"
                    label-text="Stundensatz*"
                    :options="stundensatzOptions"
                    :error-conditions="[
                        {
                            name: 'empty-stundensatz',
                            condition: !$v.form.stundensatz.required  && $v.form.stundensatz.$dirty,
                            text: $t.__('validation.required', {attribute: 'Stundensatz'})
                        },
                    ]"
                />

                <FormInputAppend
                    v-model="form.gmkz"
                    @input="value => $emit('gmkz-changed', value)"
                    @change="val => $emit('change', {field: 'gmkz', value: val})"
                    @submit="$emit('submit')"
                    class="element-gmkz"
                    input-id="element-gmkz"
                    name="gmkz"
                    label-text="GMKZ"
                    prepend="%"
                    :disabled="kostentype === 'Ressourcen'"
                    :error-conditions="[
                        {
                            name: 'invalid-number',
                            condition: !$v.form.gmkz.decimal  && $v.form.gmkz.$dirty,
                            text: $t.__('validation.numeric', {attribute: 'GMKZ'})
                        }
                    ]"
                />
            </div>

            <div class="switches-list">
                <b-form-group class="mb-0">
                    <b-form-checkbox
                        v-model="form.ma"
                        @input="value => $emit('ma-changed', value)"
                        @change="val => $emit('change', {field: 'ma', value: val})"
                        switch
                    >
                        Mengenabhängig
                    </b-form-checkbox>
                    <div class="text-muted">
                        Die kalkulierten Kosten werden mit der Menge der Leistungsposition multipliziert.
                        Aktiviere diese Option nicht wenn es sich bei dem Element um einmalige Kosten handelt.
                    </div>

                    <b-form-checkbox
                        v-model="form.inflation"
                        @input="value => $emit('inflation-changed', value)"
                        @change="val => $emit('change', {field: 'inflation', value: val})"
                        class="inflationsfaktor-switch"
                        switch
                    >
                        Inflationsfaktor anwenden
                    </b-form-checkbox>
                    <div class="text-muted">
                        Die kalkulierten Kosten werden mit dem Inflationsfaktor der Leistungsposition multipliziert.
                    </div>
                </b-form-group>

            </div>
        </b-overlay>
    </div>
</template>

<script>
import {
    BOverlay, BFormGroup, BFormRadioGroup,
    BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
} from 'bootstrap-vue';
import FormSelect from '@comp/FormSelect/FormSelect';
import FormInputAppend from "@comp/FormInput/FormInputAppend";
import {isEmpty} from "@helpers/ValueProcessing/ScalarProcessing";
import {required, requiredIf} from 'vuelidate/lib/validators';
import {
    aufwandHourValidator,
    aufwandMinuteValidator,
    aufwandSecondValidator
} from "res/js/utils/Validators/SimpleCommonValidators";
import Formatter from "res/js/utils/formatter";
import {computeGmkz} from "@helpers/SimpleBussiness/Onka/Onka";
import FormInput from "@comp/FormInput/FormInput";

export default {
    name: "Berechnungsart",
    components: {
        FormInput,
        FormSelect, FormInputAppend, BOverlay, BFormGroup,
        BFormRadioGroup, BFormRadio, BInputGroupPrepend, BFormCheckbox, BFormInput
    },
    props: {
        elementToUpdate: {
            type: Object,
            required: false,
            default: null
        }
    },
    created() {
        this.$eventBus.$on('kostenart-changed', this.onKostenartChanged);
        // if kostenart was changed by user interaction with select tag
        this.$eventBus.$on('kostenart-user-changed', this.onKostenartUserChanged);
    },
    mounted() {
        this.elementToUpdate !== null && this.setValues(this.elementToUpdate);
    },
    beforeDestroy() {
        this.$eventBus.$off('kostenart-changed', this.onKostenartChanged);
        this.$eventBus.$off('kostenart-user-changed', this.onKostenartUserChanged);
    },
    data() {
        return {
            kostentype: null,
            form: {
                kostenwert: null,
                stundensatz: null,
                gmkz: null,
                ma: false,
                inflation: true,
                hour: null,
                minute: null,
                second: null
            },
            stundensatzIdSelected: null,
            berechnungsartType: 'Aufwand',
            stundensatzData: [],
            pending: false
        }
    },
    computed: {
        stundensatzOptions() {
            return this.stundensatzData.map(st => ({id: st.id, text: st.stundensatz}));
        },
        aufwandValidation() {
            return (!this.$v.form.hour.required && this.$v.form.hour.$dirty) ||
                (!this.$v.form.hour.format && this.$v.form.hour.$dirty) ||
                (!this.$v.form.minute.required && this.$v.form.minute.$dirty) ||
                (!this.$v.form.minute.format && this.$v.form.minute.$dirty) ||
                (!this.$v.form.second.required && this.$v.form.second.$dirty) ||
                (!this.$v.form.second.format && this.$v.form.second.$dirty)
        },
        aufwand() {
            return this.form.hour+':'+this.form.minute+':'+this.form.second
        }
    },
    methods: {
        /**
         * Handle user interaction with kostenart
         * @param kostenart - object
         */
        async onKostenartUserChanged(kostenart) {
            await this.onKostenartChanged(kostenart);
            this.$emit('change', {field: 'stundensatz', value: this.form.stundensatz});
            this.$emit('change', {field: 'aufwand', value: this.form.aufwand});
            this.$emit('change', {field: 'kostenwert', value: this.form.kostenwert});
            this.$emit('change', {field: 'gmkz', value: this.form.gmkz});
            this.$emit('change', {field: 'berechnungsart', value: this.berechnungsartType});
            this.$emit('change', {field: 'hour', value: this.form.hour});
            this.$emit('change', {field: 'minute', value: this.form.minute});
            this.$emit('change', {field: 'second', value: this.form.second});
            this.$emit('change', {field: 'zeitstunden', value: this.aufwand});
        },
        /**
         * Fetch necessary data when kostenart is changed
         */
        async onKostenartChanged(kostenart) {
            this.pending = true;
            this.$v.$reset();
            if (!isEmpty(kostenart)) {
                this.kostentype = kostenart.kostentype;

                this.berechnungsartType = this.kostentype === 'Ressourcen' ? 'Aufwand' : 'Euro';
                await this.getStundensatzData(kostenart.kostenartId);
                this.stundensatzIdSelected = this.stundensatzData[0].id;
                this.onStundensatzSelect(this.stundensatzIdSelected);
            } else {
                this.kostentype = null;
                this.berechnungsartType = 'Aufwand';
                this.stundensatzIdSelected = null;
                this.stundensatzData.splice(0);
                this.form.aufwand = null;
                this.form.kostenwert = null;
                this.form.stundensatz = null;
                this.form.gmkz = null;
                this.form.hour = null;
                this.form.minute = null;
                this.form.second = null;
            }
            this.pending = false;
        },
        /**
         * @param kostenartId
         */
        async getStundensatzData(kostenartId) {
            try {
                let res = await this.$axios.get(`/offers/calculations/els/on-kostenart-change/${kostenartId}`);
                this.stundensatzData.splice(0);
                this.stundensatzData.push(...res.data);
            } catch (err) {
                console.error("Couldn't fetch new data for changed kostenart", err);
            }
        },
        /**
         * Emit event to StoreComponent when Stundensatz is changed
         * @param stundensatzId
         */
        onStundensatzSelect(stundensatzId) {
            if (!isEmpty(stundensatzId)) {
                let st = this.stundensatzData.filter(st => st.id == stundensatzId)[0];
                this.form.stundensatz = st.stundensatz;
                this.form.gmkz = st.gmkz;
            } else {
                this.form.stundensatz = null;
                this.form.gmkz = null;
            }
            this.$emit('stundensatz-changed', this.form.stundensatz);
            this.$emit('gmkz-changed', this.form.gmkz);
        },
        /**
         * Emit event to StoreComponent when Berechnungsart is changed
         * @param value
         */
        onBerechnungsartChange(value) {
            this.$v.form.kostenwert.$reset();
            this.$v.form.hour.$reset();
            this.$v.form.minute.$reset();
            this.$v.form.second.$reset();
            this.$emit('berechnungsart-changed', value);
        },
        /**
         * Method for triggering validation from StoreComponent
         * @returns object - validation object
         */
        validate() {
            if (this.kostentype === 'Ressourcen' && this.berechnungsartType === 'Aufwand') {
                this.form.kostenwert = null;
                this.$emit('kostenwert-changed', null);
            } else {
                this.form.aufwand = null;
                this.form.hour = null;
                this.form.minute = null;
                this.form.second = null;
                this.$emit('aufwand-changed', null);
            }
            this.$v.$touch();
            return this.$v;
        },
        /**
         * Set values for inputs if dialog was opened for editing
         * existing element
         * @param element
         * @returns {Promise<void>}
         */
        async setValues(element) {
            await this.getStundensatzData(this.elementToUpdate.kostenart.kostenartId);
            this.form.aufwand = element.zeitstunden;
            this.form.stundensatz = this.stundensatzData.map(st => {
                if (element.stundensatz == (new Formatter).stringToNumber(st.stundensatz)) {
                    this.stundensatzIdSelected = st.id;
                    this.form.stundensatz = st.stundensatz;
                }
                if (computeGmkz(element.gmkz) != st.gmkz) {
                    this.form.gmkz = computeGmkz(element.gmkz);
                } else {
                    this.form.gmkz = st.gmkz;
                }
            });
            this.kostentype = element.kostenart.kostentyp.bezeichnung;
            this.berechnungsartType = element.zeitstunden ? 'Aufwand' : 'Euro';
            if (this.berechnungsartType === 'Aufwand') {
                let aufwand = element.zeitstunden.split(':');
                this.form.hour = aufwand[0];
                this.form.minute = aufwand[1];
                this.form.second = aufwand[2];
            } else {
                this.form.hour = null;
                this.form.minute = null;
                this.form.second = null;
            }
            this.form.kostenwert = this.berechnungsartType === 'Euro' ? (new Formatter).numberToString(element.wert).replace('.', '') : null;
            this.form.ma = element.ma;
            this.form.inflation = element.ifApply;
        }
    },
    validations: {
        form: {
            hour: {
                required: requiredIf(function (model) {
                    return this.berechnungsartType === 'Aufwand'
                }),
                format(value) {
                    return this.berechnungsartType === 'Aufwand' ? aufwandHourValidator(value) : true
                }
            },
            minute: {
                required: requiredIf(function (model) {
                    return this.berechnungsartType === 'Aufwand'
                }),
                format(value) {
                    return this.berechnungsartType === 'Aufwand' ? aufwandMinuteValidator(value) : true
                }
            },
            second: {
                required: requiredIf(function (model) {
                    return this.berechnungsartType === 'Aufwand'
                }),
                format(value) {
                    return this.berechnungsartType === 'Aufwand' ? aufwandSecondValidator(value) : true
                }
            },
            kostenwert: {
                required: requiredIf(function (model) {
                    return this.berechnungsartType === 'Euro'
                }),
                decimal(value) {
                    return this.berechnungsartType === 'Euro' ? String(value).match(/^-?\d+,?\d*$/) !== null : true
                }
            },
            stundensatz: {required},
            gmkz: {
                decimal(value) {
                    return String(value).match(/^-?\d+,?\d*$/) !== null
                }
            },
        }
    }
}
</script>

<style lang="scss" scoped>
.element-stundensatz,
.element-gmkz,
.element-kostenwert,
.element-aufwand {
    max-width: 32%;
}

.switches-list {
    margin-top: 30px;

    .inflationsfaktor-switch {
        margin-top: 25px;
    }

    .text-muted {
        margin-top: 10px;
    }
}

.width-aufwand {
    max-width: 60px;
}
.width-30 {
    max-width: 33%;
}
</style>
