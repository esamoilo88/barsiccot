<template>
    <b-overlay :show="show" rounded="sm">
        <div v-for="lp in mergedObjects" class="simple-box mb-3">
            <div class="item-header mb-3">
                <div class="item-label">LP</div>
                <div class="font-weight-bold item-description">
                    {{ lp.lp_info.bezeichnung }}
                </div>
                <div>
                    <div class="dropdown">
                        <button
                            title="Optionen"
                            type="button"
                            class="item-dropdown-toggle-btn mr-3"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <i class="icon-action-more-default"></i>
                        </button>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="itemDropdown">
                            <button
                                v-for="item in dropdownOptions"
                                class="dropdown-item item-dropdown-option-btn"
                                @click="item.action(lp.lp_info)"
                            >
                                <i :class="item.icon"></i>
                                {{ item.title }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="lp_info mb-4">
                <table class="light-table">
                    <thead>
                    <tr>
                        <th>Leistungstyp</th>
                        <th>Menge</th>
                        <th>Inflationsfaktor</th>
                        <th>Nach Aufwand</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>
                            <span class="text-uppercase">{{ lp.lp_info.itilMain ? lp.lp_info.itilMain.bezeichnung : '' }}</span>
                            <span>{{ lp.lp_info.itilSub ? lp.lp_info.itilSub.bezeichnung : '' }}</span>
                        </td>
                        <td>1</td>
                        <td class="text-nowrap">
                            {{ $f.numberToString(lp.lp_info.inflationsfaktorRessourcen, false, false, '0,00', {maximumFractionDigits: 10}) }}
                            (Ressourcen)
                            &#183;
                            {{ $f.numberToString(lp.lp_info.inflationsfaktorKosten, false, false, '0,00', {maximumFractionDigits: 10}) }}
                            (Kosten)
                        </td>
                        <td>
                            <b-form-checkbox
                                v-model="lp.lp_info.nachAufwand"
                                name="lp-nach-aufwand-check-button"
                                switch
                                disabled
                            ></b-form-checkbox>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div v-if="lp.lp_info.els.length > 0 || lp.lp_info.bers.length > 0">
                <table class="w-100" id="el-ber-table">
                    <thead>
                    <tr>
                        <th style="width: 8%">Objekt</th>
                        <th style="width: 50%">Bezeichnung</th>
                        <th style="width: 10%">Wert</th>
                        <th style="width: 10%">Stundensatz</th>
                        <th style="width: 10%">Merkmale</th>
                        <th style="width: 12%">Optionen</th>
                    </tr>
                    </thead>
                    <tbody>
                        <template v-for="(item, index) in lp.objects" v-if="lp.objects.length > 0">
                            <!-- EL row -->
                            <tr v-if="!item.berechnungId" :key="item.elementId">
                                <td class="pl-0 border-top" v-if="!item.berechnungId">
                                    <span class="icon-content-clipboard-default"></span>
                                    EL
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    <ElementData :item="item"/>
                                </td>
                                <td class="border-top" v-if="!item.berechnungId && !item.zeitstunden">
                                    {{ $f.numberToString(item.wert, true, true) }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId && item.zeitstunden">
                                    {{ item.zeitstunden }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    {{ $f.numberToString(item.stundensatz, true, true) }}
                                </td>
                                <td class="border-top" v-if="!item.berechnungId">
                                    <div v-if="item.ma" class="mt-1">
                                        <abbr class="badge badge-info" :id="'ma_' + item.elementId" title="Mengeabhängig">
                                            MA
                                        </abbr>
                                    </div>
                                </td>
                                <td class="border-top text-nowrap" v-if="!item.berechnungId">
                                    <button
                                        @click="emitAction('update-el', {lpParentId: lp.lp_info.leistungspositionId, item})"
                                        title="Element bearbeiten"
                                        class="options-btn"
                                    >
                                        <i class="icon-action-edit-default"></i>
                                    </button>
                                    <button
                                        @click="emitAction('delete-el', item)"
                                        title="Element löschen"
                                        class="options-btn"
                                    >
                                        <i class="icon-action-remove-default"></i>
                                    </button>
                                    <button
                                        @click="emitAction('create-ber', {type: 'EL', id: getElementId(index, lp)})"
                                        title="Neue Berechnung"
                                        class="options-btn"
                                    >
                                        <i class="icon-function-mathematical-symbol"></i>
                                    </button>
                                </td>
                            </tr>
                            <!-- EL end -->

                            <!-- EL Berechnung start -->
                            <tr
                                is="BerechnungRow"
                                v-if="item.berechnungId"
                                :key="item.berechnungId"
                                :item="item"
                                :parent-type="'EL'"
                                :can-create-or-update="true"
                                @edit-ber="emitAction('update-ber', {ber: item, target: {type: 'EL', id: getElementId(index, lp)}})"
                                @delete-ber="emitAction('delete-ber', item)"
                            ></tr>
                            <!-- EL Berechnung end -->
                        </template>

                        <!-- LP Berechnung start -->
                        <template v-if="lp.lp_info.bers">
                            <tr
                                is="BerechnungRow"
                                v-for="(item, index) in lp.lp_info.bers"
                                :key="item.berechnungId"
                                :item="item"
                                :parent-type="'LP'"
                                :can-create-or-update="true"
                                @edit-ber="emitAction('update-ber', {ber: item, target: {type: 'LP', id: lp.lp_info.leistungspositionId}})"
                                @delete-ber="emitAction('delete-ber', item)"
                            ></tr>
                        </template>
                        <!-- LP Berechnung end -->
                    </tbody>
                </table>
            </div>
            <div v-else class="elements_list"><p class="no-data">Keine Elemente vorhanden</p></div>
        </div>
        <div v-if="!show && lpData.length == 0" class="lp-box"><p class="no-data text-center">Keine Daten vorhanden</p></div>
    </b-overlay>
</template>

<script>
import ScalarsProcessing from "@mixins/ValuesProcessing/ScalarsProcessing";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";
import BerechnungRow from "./BerechnungRow";
import ElementData from "./ElementData";
import {BOverlay, BFormCheckbox} from 'bootstrap-vue';

export default {
    name: "ApContent",
    mixins: [ScalarsProcessing],
    components: {
        ButtonIcon, BerechnungRow, ElementData, BOverlay, BFormCheckbox
    },
    props: {
        apId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            show: false,
            lpData: [],
            berechnungKosten: { el: {}, lp: {} },
            dropdownOptions: [
                {
                    title: 'Neues Element',
                    icon: 'icon-content-clipboard-default',
                    action: (lp) => {
                        this.emitAction('create-el', lp.leistungspositionId);
                    }
                },
                {
                    title: 'Neue Berechnung',
                    icon: 'icon-function-mathematical-symbol',
                    action: (lp) => {
                        this.emitAction('create-ber', {type: 'LP', id: lp.leistungspositionId});
                    }
                },
                {
                    title: 'Leistungsposition bearbeiten',
                    icon: 'icon-action-edit-default',
                    action: (lp) => {
                        this.$emit('updateLp', lp);
                    }
                },
                {
                    title: 'Leistungsposition löschen',
                    icon: 'icon-action-remove-default',
                    action: (lp) => {
                        this.$emit('deleteLp', lp);
                    }
                }
            ]
        }
    },
    computed: {
        mergedObjects() {
            let result = [];
            this.lpData.forEach((lp) => {
                let sumArray = [];
                lp[0]['els'] && lp[0]['els'].forEach((el) => {
                    let bers = el['bers'] ? el['bers'] : [];
                    sumArray.push(...[el, ...bers]);
                });
                result.push({'lp_info': lp[0], 'objects': sumArray});
            });
            return result;
        }
    },
    created() {
        this.$eventBus.$on('refreshTable', this.refreshHandler);
    },
    beforeDestroy() {
        this.$eventBus.$off('refreshTable', this.refreshHandler);
    },
    async mounted() {
        await this.getData();
    },
    methods: {
        async getData() {
            this.show = true;
            try {
                const response = await this.$axios.get(`/admin/katalog/ap/${this.apId}/content`);
                this.lpData = response.data;
            } catch (err) {
                console.log("Couldn't fetch ap content");
            }
            this.show = false;
        },
        /**
         * Use synchronous handler for eventBus, otherwise it
         * cannot remove event handler after component is destroyed
         */
        refreshHandler() {
            this.getData().then();
        },
        emitAction(name, data) {
            this.$eventBus.$emit(name, data);
        },
        getElementId(index, lp) {
            for (let i = index; i >= 0; i--) {
                if (lp.objects[i].berechnungId === undefined) {
                    return lp.objects[i].elementId;
                }
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/lpTable';
@import 'resources/sass/components/onkaPositions';
@import 'resources/sass/tables/new-table';

.lp_info {
    justify-content: flex-start;
}
</style>
