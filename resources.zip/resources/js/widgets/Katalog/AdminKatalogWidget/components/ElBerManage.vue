<template>
    <div>
        <StoreElement
            v-if="isELFormActive"
            :is-visible="isELFormActive"
            :can-create-element="true"
            :element-to-update="elementToUpdate"
            :parent-lp-id="parentLpId"
            :is-single-create="parentLpId !== null"
            @close-store-element-modal="isELFormActive = false; elementToUpdate = null"
            @updated="elementToUpdate=null"
        />

        <StoreBER
            v-if="isBERFormActive"
            :is-visible="isBERFormActive"
            :target="berTargetObj"
            :can-create-ber="true"
            :ber-to-update="berToUpdate"
            @close-store-ber-modal="closeBERDialog"
            @updated="berToUpdate=null"
        />
    </div>
</template>

<script>
import StoreElement from "./entities/EL/Store/StoreElement";
import StoreBER from "./entities/BER/Store/StoreBER";
import BERMxn from "./entities/BER/BERMxn";
import StoreElementMxn from "./entities/EL/Store/StoreElementMxn";
import RemoveElementMxn from "./entities/EL/Remove/RemoveElementMxn";
import RemoveBerMxn from "./entities/BER/RemoveBerMxn";

export default {
    mixins: [
        BERMxn, StoreElementMxn,
        RemoveElementMxn, RemoveBerMxn
    ],
    components: {
        StoreElement,
        StoreBER
    },
    created() {
        this.$eventBus.$on('create-el', this.onElementCreate);
        this.$eventBus.$on('update-el', this.onElementUpdate);
        this.$eventBus.$on('delete-el', this.onElementRemove);
        this.$eventBus.$on('create-ber', this.createBER);
        this.$eventBus.$on('update-ber', this.updateBER);
        this.$eventBus.$on('delete-ber', this.deleteBer);
    },
    beforeDestroy() {
        this.$eventBus.$off('create-el', this.onElementCreate);
        this.$eventBus.$off('update-el', this.onElementUpdate);
        this.$eventBus.$off('delete-el', this.onElementRemove);
        this.$eventBus.$off('create-ber', this.createBER);
        this.$eventBus.$off('update-ber', this.updateBER);
        this.$eventBus.$off('delete-ber', this.deleteBer);
    },
    methods: {
        showCreateModal() {
            this.$refs.manage.clearForm();
            this.$refs.manage.showModal();
        },
        showUpdateModal(item) {
            this.$refs.manage.setForm(item);
            this.$refs.manage.showModal();
        }
    }
}
</script>

<style lang="scss" scoped>
.fixed-container {
    display: flex;
}

::v-deep .create-buttons {
    margin-left: auto;
}
</style>
