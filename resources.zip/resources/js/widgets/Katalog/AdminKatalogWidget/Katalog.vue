<template>
    <KatalogList />
</template>

<script>
import KatalogList from './components/KatalogList'

export default {
    name: "Katalog",
    components: {
        KatalogList
    }
}
</script>
