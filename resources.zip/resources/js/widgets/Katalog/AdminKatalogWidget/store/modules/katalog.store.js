import {deepCopy, isEmpty} from "@helpers/ValueProcessing/ObjectsProcessing";

export default {
    namespaced: true,
    state: {
        categories: [],
        categoriesFlat: [],
        selectedCategory: {id: -1, name: ''},
        selector: 'ap'
    },
    mutations: {
        SET_CATEGORIES(state, categories) {
            state.categories.splice(0);
            state.categories.push(...categories);
        },
        SET_FLAT_CATEGORIES(state, categories) {
            state.categoriesFlat.splice(0);
            state.categoriesFlat.push(...categories);
        },
        SET_SELECTOR(state, value) {
            state.selector = value;
        },
        SET_SELECTED_CATEGORY(state, {id, name}) {
            state.selectedCategory = {id, name};
        },
        RESET_SELECTED_CATEGORY(state) {
            state.selectedCategory = {id: -1, name: ''};
        }
    },
    actions: {
        /**
         * Get categories tree
         * @param context
         * @returns {Promise<*>}
         */
        async fetchCategories(context) {
            try {
                let res = await this.$axios.get('/admin/katalog/tree');
                let result = [];
                const treeToFlat = (tree, result) => {
                    for (let obj of tree) {
                        let resultObj = {id: obj.kategorieId, bezeichnung: obj.bezeichnung};
                        result.push(resultObj);
                        if (!isEmpty(obj.children)) {
                            treeToFlat(obj.children, result);
                        }
                    }
                    return result;
                }
                context.commit('SET_FLAT_CATEGORIES', treeToFlat(deepCopy(res.data), result));
                context.commit('SET_CATEGORIES', res.data);
            } catch (err) {
                console.error("Couldn't fetch katalog tree: ", err);
            }
        },
    },
}
