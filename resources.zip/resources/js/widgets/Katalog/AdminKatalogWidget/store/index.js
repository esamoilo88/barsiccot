import Vue from 'vue';
import Vuex from 'vuex';
import {$axios} from 'res/js/boot';

Vue.use(Vuex);

import katalog from "./modules/katalog.store";
const store = new Vuex.Store({
    modules: {katalog}
});

store.$axios = $axios;

export default store;
