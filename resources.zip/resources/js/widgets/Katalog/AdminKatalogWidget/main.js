import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Formatter from "res/js/utils/formatter";
import Katalog from "./Katalog";
import {ModalPlugin} from 'bootstrap-vue';
import SimpleTranslator from "res/js/utils/SimpleTranslator";
import Vuelidate from "vuelidate";
import store from "./store";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$t = t;
Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);

export default new Vue({
    el: '#admin-katalog', //resources/views/App/Katalog/index.blade.php
    components: {Katalog},
    store
});
