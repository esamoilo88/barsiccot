export default {
    methods: {
        async uploadFile(file, addToList = false) {
            file.pending = true;

            if (addToList) this.pendingFiles = true;

            try {
                const formData = new FormData();
                formData.append('file', file.File);
                formData.append('folderPath', file.folderPath);

                const response = await this.$axios.post(`/projects/${this.simpleId}/files/upload`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                })

                window.flash.success('Datei hochgeladen.');

                file.uploadedAt = response.data.uploadedAt;
                file.path = response.data.path;
                file.canBeDeleted = response.data.canBeDeleted;

                if (addToList) {
                    this.files.unshift(file)
                }

                this.updateFolderCount();
            } catch (e) {
                file.error = true;

                if (e.response.statusText && e.response.statusText.includes('Request Entity Too Large')) {
                    window.flash.error('Dateigröße mehr als 50MB.');
                }

                window.flash.showMessagesFromAjax(e.response.data);
            }

            file.pending = false;
            this.pendingFiles = false;
        },
        async deleteFile(file) {
            const confirmed = await this.showConfirmationModal({
                title: 'Datei löschen',
                message: `Bitte bestätigen Sie das Löschen der Datei ${file.name}`,
                okTitle: 'Datei löschen',
            });

            if (!confirmed) return;

            this.pendingFiles = true;

            try {
                await this.$axios.delete(`/projects/${this.simpleId}/files/delete`, {
                    params: {
                        path: file.path
                    }
                });

                this.pendingFiles = false;

                window.flash.success('Datei gelöscht');

                this.updateFolderCount(false);

                await this.openFolder(file.folderPath)
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pendingFiles = false;
        },
        async deleteFolder() {
            if (this.pendingFiles) return;

            const confirmed = await this.showConfirmationModal({
                title: 'Ordner löschen',
                message: `Bitte bestätigen Sie das Löschen des Ordners`,
                okTitle: 'Ordner löschen',
            });

            if (!confirmed) return;

            this.pendingFiles = true;

            try {
                await this.$axios.delete(`/projects/${this.simpleId}/files/folders`, {
                    params: {path: this.selectedFolder.path}
                });

                window.flash.success('Ordner gelöscht');

                this.selectedFolder.delete();

                this.selectedFolder = {path: null};
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pendingFiles = false;
        },
    }
}
