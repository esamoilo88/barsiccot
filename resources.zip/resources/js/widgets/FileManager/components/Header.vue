<template>
    <div class="card mb-5">
        <div class="card-body">
            <div class="row no-gutters">
                <div class="col pr-3">
                    <div class="row no-gutters">
                        <div class="col">
                            <div class="row no-gutters mb-3">
                                <div class="col">
                                    <div class="font-weight-bold">SIN</div>
                                    <div>{{ project.globalGate.simpleId }}</div>
                                </div>
                                <div class="col">
                                    <div class="font-weight-bold">VORHABEN</div>
                                    <div>{{ project.globalGate.thema }}</div>
                                </div>
                            </div>

                            <div>
                                <div class="font-weight-bold">KUNDE</div>
                                <div>{{ project.kundenname }}</div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <CircleChart
                                :content="status.shortName"
                                :value="status.progress"
                                :color="status.color"
                                size="small"
                                sr-text="Status"
                            />
                        </div>
                    </div>
                </div>

                <div class="col pl-3 pt-3 border-left">
                    <b-overlay :show="pending">
                        <div class="row no-gutters justify-content-center">
                            <div class="col-12 pr-3">
                                <div class="font-weight-bold">ANGEBOT</div>
                                <div v-if="angebotFile">
                                    <div>
                                        <a :href="`/offers/${project.globalGate.simpleId}/angebot/download/${angebotFile.shortName}`" download>
                                            {{ angebotFile.shortName }}
                                        </a>
                                    </div>
                                    <div class="text-muted">{{ getSize(angebotFile.size) }} KB - {{ formatDate(angebotFile.date.date, 'DD.MM.YYYY HH:mm') }}</div>
                                </div>
                                <div v-else>Nicht vorhanden</div>
                            </div>

                            <div class="col-12 pl-3">
                                <div class="font-weight-bold">BEAUFTRAGUNG</div>
                                <div v-if="beauftragungFile">
                                    <div>
                                        <a :href="getDownloadLink(beauftragungFile)" download>
                                            {{ beauftragungFile.name }}
                                        </a>
                                    </div>
                                    <div class="text-muted">{{ beauftragungFile.size }} KB - {{ beauftragungFile.uploadedAt }}</div>
                                </div>
                                <div v-else>Nicht vorhanden</div>
                            </div>
                        </div>
                    </b-overlay>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";
import {BOverlay} from "bootstrap-vue";

export default {
    components: {CircleChart, BOverlay},
    mixins: [DatesProcessing],
    props: {
        project: {
            type: Object,
            required: true
        },
        versionnr: {
            required: true
        }
    },
    data() {
        return {
            pending: false,
            angebotFile: null,
            beauftragungFile: null
        }
    },
    computed: {
        status() {
            return this.project.globalGate.sinStatus.status;
        }
    },
    async mounted() {
        this.pending = true;

        await this.getAngebotFile();
        await this.getBeauftragungFile();

        this.pending = false;
    },
    methods: {
        async getAngebotFile() {
            if (!this.versionnr) return;

            const response = await this.$axios.post(`/offers/${this.project.globalGate.simpleId}/versions/${this.versionnr}/angebot/upload`, {'attachedfile': null});

            if (response.data.length) {
                this.angebotFile = response.data[0];
            }
        },
        async getBeauftragungFile() {
            const response = await this.$axios.get(`/projects/${this.project.globalGate.simpleId}/files/beauftragung`);

            if (response.data.name) {
                this.beauftragungFile = response.data;
            }
        },
        getSize(size) {
            if (!size) return;

            return Number(size / 1024).toFixed(0);
        },
        getDownloadLink(file) {
            return `/projects/${this.project.globalGate.simpleId}/files/download?path=${file.path}`;
        },
    }
}
</script>
