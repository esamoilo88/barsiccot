<template>
    <ul class="list">
        <li v-for="folder in folders">
            <span class="folder">
                <span class="icon-content-folder-default"></span>
                <a @click="openFolder(folder)" href="#" :class="{'font-weight-bold': selected === folder.path}">
                    {{ folder.name }}
                    <template v-if="folder.count">({{ folder.count }})</template>
                </a>
            </span>

            <div class="pl-3" v-if="folder.open">
                <folders
                    :key="folder.name"
                    :folders="folder.folders"
                    :parent="folder"
                    :simple-id="simpleId"
                    :selected="selected"></folders>
            </div>
        </li>
    </ul>
</template>

<script>
export default {
    name: "folders",
    props: {
        folders: {
            type: Array
        },
        parent: {
            type: Object
        },
        simpleId: {
            required: true,
            type: Number
        },
        selected: {}
    },
    data() {
        return {
            pending: false,
            icon: {
                open: 'icon-navigation-collapse-down-default',
                close: 'icon-navigation-right-default',
            }
        }
    },
    methods: {
        toggle(folder) {
            folder.open = !folder.open;
        },
        async openFolder(folder) {
            folder.delete = () => {
                const index = this.folders.findIndex(item => item === folder);

                this.folders.splice(index, 1);
            }

            this.$eventBus.$emit('openFolder', folder);
        }
    }
}
</script>

<style lang="scss" scoped>
.btn-sm {
    width: 18px;
    height: 18px;
    font-size: 12px;
    padding: 2px;
}

.folder {
    display: inline-block;
    margin-bottom: 8px;

    a {
        color: inherit;
    }
}

.list {
    list-style-type: none;
    padding-left: 0;
}
</style>
