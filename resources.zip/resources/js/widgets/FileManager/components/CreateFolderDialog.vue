<template>
    <div>
        <modal-dialog
            :is-visible="show"
            @hideModal="hide"
            title-dialog="Neuer Ordner"
            modal-class="create-folder-dialog"
        >
            <b-overlay :show="pending">
                <FormInput
                    v-model="form.name"
                    label-text="Ordnernamen"
                    name="folder-name-input"
                    input-id="folder-name-input"
                />
            </b-overlay>

            <template #footer="{methods}">
                <button @click="create" class="btn btn-primary" :disabled="!form.name">Erstellen</button>
                <button @click="hide" class="btn btn-secondary">Abbrechen</button>
            </template>
        </modal-dialog>
    </div>
</template>

<script>
import ModalDialog from '@comp/ModalDialog/ModalDialog';
import FormInput from "@comp/FormInput/FormInput";
import {BOverlay} from "bootstrap-vue";

export default {
    components: {ModalDialog, FormInput, BOverlay},
    props: {
        show: {
            default: false
        },
        simpleId: {
            required: true,
            type: Number
        },
        path: {
            type: String
        },
        parent: {
            default: null
        }
    },
    data() {
        return {
            pending: false,
            form: {
                name: null
            }
        }
    },
    methods: {
        hide() {
            this.$emit('hide');
        },
        async create() {
            if (this.pending) return;

            this.pending = true;

            try {
                const response = await this.$axios.post(`/projects/${this.simpleId}/files/folders`, {
                    name: this.form.name,
                    path: this.path
                });

                window.flash.success('Ordner erstellt');

                const folder = response.data;
                folder.parent = this.parent;

                this.clear();
                this.hide();
                this.$emit('created', folder);
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pending = false;
        },
        clear() {
            this.form.name = null;
        }
    }
}
</script>
