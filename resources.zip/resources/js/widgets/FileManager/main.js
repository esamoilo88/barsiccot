import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Index from "./Index";
import {ModalPlugin} from 'bootstrap-vue';

Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;

Vue.use(ModalPlugin);

export default new Vue({
    el: "#filemanager-widget", //resources/views/App/FileManager/index.blade.php
    components: {
        Index
    }
});
