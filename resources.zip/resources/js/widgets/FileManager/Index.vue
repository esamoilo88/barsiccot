<template>
    <div>
        <Header :project="project" :versionnr="versionnr" />

        <div class="simple-box">
            <div class="mb-3 d-flex justify-content-end">
                <input @input="search" v-model="searchValue" type="text" placeholder="Dateien durchsuchen" class="form-control search-input">
            </div>

            <div class="row no-gutters">
                <div class="col-8">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-muted title mb-5">Ordnerliste</div>
                            <b-overlay :show="pending">
                                <Folders :folders="folders" :simple-id="simpleId" :selected="selectedFolder.path" />
                            </b-overlay>
                        </div>
                    </div>
                </div>

                <div class="col-16 pl-3">
                    <div class="card" :class="{'border-0': !files.length}">
                        <div class="card-body" @dragover.prevent @drop.prevent>
                            <div class="mb-3" v-if="selectedFolder.path || searchRun">
                                <div class="text-muted title mb-5">{{ searchRun ? 'Suchergebnisse' : 'Ordnerinhalt' }}</div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col">
                                        <template v-if="!searchRun" v-for="(item, index) in breadcrumbs(selectedFolder, [selectedFolder.name])">
                                            {{ index ? '>' : '' }} {{ item }}
                                        </template>
                                    </div>
                                    <div class="col-auto" v-if="!searchRun">
                                        <button @click="openCreateFolderDialog" id="btn-new-folder" type="button" class="btn btn-primary">
                                            <span class="icon-action-add-default"></span>
                                            Neuer Ordner
                                        </button>
                                        <b-tooltip target="btn-new-folder" title="Neuer Ordner"></b-tooltip>

                                        <label id="btn-upload" class="btn btn-primary" for="fileUpload">
                                            <span class="icon-action-upload-default"></span>
                                            Datei hochladen
                                        </label>
                                        <input hidden id="fileUpload" type="file" @change="uploadFromInput" />
                                        <b-tooltip target="btn-upload" title="Datei hochladen"></b-tooltip>
                                    </div>
                                </div>
                            </div>

                            <div @drop="dropFile">
                                <b-overlay :show="pendingFiles">
                                    <div v-if="files.length" class="table-responsive" >
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>Typ</th>
                                                <th>Name</th>
                                                <th>Größe</th>
                                                <th>Geändert</th>
                                                <th>Optionen</th>
                                            </tr>
                                            </thead>

                                            <tbody>
                                            <tr v-for="file in files" :class="{'table-info': !file.path, 'table-danger': file.error}">
                                                <td>
                                                    <img class="fileicon" :src="getFileIcon(file.ext)" onerror="this.src='/img/icons/fileicons/default.svg'" alt="fileicon" />
                                                </td>
                                                <td>{{ file.name }}</td>
                                                <td>{{ file.size }} KB</td>
                                                <td>{{ file.uploadedAt }}</td>
                                                <td class="text-nowrap">
                                                    <template v-if="file.path">
                                                        <a
                                                            id="btn-download"
                                                            :href="getDownloadLink(file)"
                                                            download
                                                            class="btn btn-secondary">
                                                            <span class="icon-action-download-default"></span>
                                                        </a>
                                                        <b-tooltip target="btn-download" title="Herunterladen"></b-tooltip>
                                                        <button :disabled="!file.canBeDeleted" id="btn-delete" @click="deleteFile(file)" class="btn btn-secondary">
                                                            <span class="icon-action-remove-selected"></span>
                                                        </button>
                                                        <b-tooltip target="btn-delete" title="Löschen"></b-tooltip>
                                                    </template>
                                                    <template v-else>
                                                        <b-overlay :show="file.pending">
                                                            <button id="btn-upload-file" @click="uploadFile(file)" class="btn btn-secondary">
                                                                <span class="icon-action-upload-default"></span>
                                                            </button>
                                                            <b-tooltip target="btn-upload-file" title="Datei hochladen"></b-tooltip>
                                                            <button id="btn-delete-temp" @click="deleteTempFile(file)" class="btn btn-secondary">
                                                                <span class="icon-action-remove-selected"></span>
                                                            </button>
                                                            <b-tooltip target="btn-delete-temp" title="Löschen"></b-tooltip>
                                                        </b-overlay>
                                                    </template>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div v-else class="text-center pt-5">
                                        <div>
                                            <div class="text-center">
                                                <div class="mb-3">
                                                    <span class="icon-user_file-attachment-selected"></span>
                                                </div>
                                                <div class="font-weight-bold mb-3">Dateiablage</div>
                                                <div v-if="selectedFolder.path">Nicht vorhanden</div>
                                                <div v-else>Bitte wähle einen Ordner auf der linken Seite oder benutze <br> die Suche um Dateien anzuzeigen.</div>
                                            </div>
                                        </div>

                                        <button v-if="selectedFolder.path && selectedFolder.count === 0" @click="deleteFolder" class="btn btn-primary mt-3">
                                            <span class="icon-action-remove-default"></span>
                                            Ordner löschen
                                        </button>
                                    </div>
                                </b-overlay>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <CreateFolderDialog
                :show="showCreateFolderDialog"
                :simple-id="simpleId"
                :path="selectedFolder.path"
                :parent="selectedFolder"
                @hide="closeCreateFolderDialog"
                @created="folderCreated"
            />
        </div>
    </div>
</template>

<script>
import {BOverlay, BTooltip} from "bootstrap-vue";
import Folders from "res/js/widgets/FileManager/components/Folders";
import ConfirmationModal from "@mixins/ConfirmationModal/ConfirmationModal";
import CreateFolderDialog from "res/js/widgets/FileManager/components/CreateFolderDialog";
import Header from "res/js/widgets/FileManager/components/Header";
import CRUD from "res/js/widgets/FileManager/Mixins/CRUD";

export default {
    components: {BOverlay, BTooltip, Folders, CreateFolderDialog, Header},
    mixins: [ConfirmationModal, CRUD],
    props: {
        project: {
            type: Object,
            required: true
        },
        versionnr: {
            required: true
        }
    },
    computed: {
        simpleId() {
            return this.project.globalGate.simpleId;
        }
    },
    data() {
        return {
            folders: [],
            pending: true,
            pendingFiles: false,
            files: [],
            selectedFolder: {path: null},
            showCreateFolderDialog: false,
            searchValue: null,
            searchRun: false
        }
    },
    async mounted() {
        this.$eventBus.$on('openFolder', (folder) => {
            this.selectedFolder = folder;

            this.openFolder(folder.path)
        })

        this.pending = true;

        await this.getFolders();

        this.pending = false;
    },
    methods: {
        async getFolders() {
            try {
                const response = await this.$axios.get(`/projects/${this.simpleId}/files/folders`);

                this.folders = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async openFolder(path) {
            if (this.pendingFiles) return;

            this.pendingFiles = true;
            this.searchRun = false;

            try {
                const response = await this.$axios.get(`/projects/${this.simpleId}/files/folders/open`, {
                    params: {path}
                });

                this.files = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pendingFiles = false;
        },
        getDownloadLink(file) {
            return `/projects/${this.simpleId}/files/download?path=${file.path}`;
        },
        getFileIcon(ext) {
            return `/img/icons/fileicons/${ext}.svg`;
        },
        dropFile(e) {
            if (!this.selectedFolder.path) {
                window.flash.error('Wählen Sie einen Ordner aus.');

                return;
            }

            Array.from(e.dataTransfer.files).forEach(file => {
                const fileObj = this.getFileObj(file);

                this.uploadFile(fileObj, true);
            })
        },
        getFileObj(file) {
            return {
                'name': file.name,
                'size': Number(file.size / 1024).toFixed(0),
                'ext': file.type,
                'uploadedAt': null,
                'path': null,
                'folderPath': this.selectedFolder.path,
                'File': file,
                'error': false,
                'pending': false,
                'canBeDeleted': true,
            }
        },
        deleteTempFile(file) {
            const index = this.files.indexOf(file);

            this.files.splice(index, 1);
        },
        uploadFromInput(e) {
            if (!this.selectedFolder.path) {
                window.flash.error('Wählen Sie einen Ordner aus.');
                e.target.value = null;

                return;
            }

            Array.from(e.target.files).forEach(file => {
                const fileObj = this.getFileObj(file);

                this.uploadFile(fileObj, true);
            })

            e.target.value = null;
        },
        updateFolderCount(plus = true) {
            this.selectedFolder.count += (plus ? 1 : -1);
        },
        openCreateFolderDialog() {
            this.showCreateFolderDialog = true;
        },
        closeCreateFolderDialog() {
            this.showCreateFolderDialog = false;
        },
        folderCreated(folder) {
            if (this.selectedFolder.path) {
                this.selectedFolder.folders.push(folder);

                this.selectedFolder.open = true;
            } else {
                this.folders.push(folder);
            }
        },
        breadcrumbs(item, result) {
            if (item.parent) {
                result.unshift(item.parent.name);

                return this.breadcrumbs(item.parent, result);
            }

            return result;
        },
        async search() {
            if (this.pendingFiles) return;

            if (this.searchValue.length < 4) return;

            this.pendingFiles = true;
            this.searchRun = true;
            this.selectedFolder = {path: null};

            try {
                const response = await this.$axios.get(`/projects/${this.simpleId}/files/search`, {
                    params: {
                        search: this.searchValue
                    }
                });

                this.files = response.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }

            this.pendingFiles = false;
        }
    }
}
</script>

<style lang="scss" scoped>
.card-header {
    font-size: 1.2rem;
    font-weight: bold;
}

.search-input {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjY2IiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PGNpcmNsZSBjeD0iMTEiIGN5PSIxMSIgcj0iOCIvPjxwYXRoIGQ9Ik0yMSAyMWwtNC00Ii8+PC9zdmc+);
    background-repeat: no-repeat;
    background-position: 12px;
    padding-left: 48px;
    padding-top: 12px;
    width: auto;
}

.title {
    font-size: 24px;
    font-weight: bold;
}

.icon-user_file-attachment-selected {
    font-size: 48px;
}

.fileicon {
    width: 32px;
}
</style>
