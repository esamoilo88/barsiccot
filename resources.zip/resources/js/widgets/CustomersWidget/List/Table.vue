<template>
    <div>
        <table-simple
            ref="table"
            table-id="admin-users-list"
            :fields="tableConf.fields"
            :filters="tableConf.filters"
            :total-rows-prop="tableConf.totalRows"
            :per-page-prop="tableConf.perPage"
            :sort-by-prop="tableConf.sortBy"
            :sort-desc-prop="tableConf.sortDesc"
            :items-provider="itemsProvider"
            :container-class="'simple-box'"
        >
            <template #beforefilters>
                <div class="col">
                    <button @click="$emit('create')" class="btn btn-primary">
                        <span class="icon-action-add-default"></span>
                        Neuer Kunde
                    </button>
                </div>
            </template>

            <template #cell(kunde)="data">
                <div>
                    {{ data.item.name }}
                </div>
                <div class="text-muted text-nowrap">
                    <span>{{ data.item.city }}</span>

                    <span v-if="data.item.akpGpNr">&#8226;</span>
                    <span>{{ data.item.akpGpNr }}</span>

                    <span v-if="data.item.akpDTAGkdnr">&#8226;</span>
                    <span>{{ data.item.akpDTAGkdnr }}</span>
                </div>
            </template>

            <template #cell(kundentyp)="data">
                <span class="badge badge-secondary">{{ data.item.internal ? 'Konzernkunden' : 'Externe Kunden' }}</span>
            </template>

            <template #cell(options)="data">
                <div class="text-nowrap">
                    <ButtonIcon
                        icon-class="icon-user_file-contacts-default"
                        variant="primary"
                        title="Kundeninfo"
                        @click="goInfoCustomer(data.item)"
                        hint-position="top"
                    />
                </div>
            </template>
        </table-simple>
    </div>
</template>

<script>
import TableSimple from "@comp/TableSimple/TableSimple";
import ButtonIcon from "@comp/ButtonIcon/ButtonIcon";

export default {
    components: {TableSimple, ButtonIcon},
    data() {
        return {
            tableConf: {
                currentPage: 1,
                totalRows: 0,
                perPage: 20,
                sortBy: 'kunde',
                sortDesc: false,
                fields: [
                    {key: 'kunde', label: 'Kunde', sortable: true, sortKey: 'kunde'},
                    {key: 'akpSegment', label: 'Segment', sortable: true, sortKey: 'akpSegment'},
                    {key: 'akpWzBezeichnung', label: 'Wirtschaftszweig'},
                    {key: 'akpZgBezeichnung', label: 'Zielgruppe'},
                    {key: 'kundentyp', label: 'Kundentyp'},
                    {key: 'options', label: 'Optionen'},
                ],
                filters: [
                    {
                        field: 'kundentyp',
                        type: 'select',
                        settings: {
                            preselected: 'alle',
                            label: 'Kundentyp',
                            options: [{id: 'alle', text: 'Alle'}, {id: '1', text: 'Konzernkunden'}, {id: '0', text: 'Externe Kunden'}]
                        }
                    },
                    {
                        field: 'search',
                        type: 'text',
                        settings: {label: 'Suchen...'}
                    }
                ],
            }
        }
    },
    methods: {
        async itemsProvider(ctx) {
            try {
                const response = await this.$axios.post('/customers/list', ctx);
                this.tableConf.totalRows = response.data.total;
                this.tableConf.perPage = response.data.perPage;
                return response.data.data;
            } catch (e) {
                window.flash.showMessagesFromAjax(e.response.data);
            }
        },
        async updateTable() {
            await this.$refs.table.itemsProviderProxy(this.$refs.table.getContext());
        },
        goInfoCustomer(item){
            window.location.href = `/customers/${item.id}`;
        }
    }
}
</script>
