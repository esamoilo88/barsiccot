<template>
    <div>
        <Table @create="isVisible = true" />

        <ModalDialog
            :is-visible="isVisible"
            @hideModal="isVisible = false"
            button-title="Kunde"
            title-dialog="Neuer Kunde"
            close-button="Schließen"
            button-class="btn-secondary"
            size="xl"
            modal-class="kunde-auswahlen"
            :scrollable="true"
        >
            <search-form selection-btn-text="Kunde anlegen" disable-bestandskunde />
        </ModalDialog>
    </div>
</template>

<script>
import Table from "res/js/widgets/CustomersWidget/List/Table";
import SearchForm from "@comp/Common/CustomerSearch/SearchForm";
import ModalDialog from "@comp/ModalDialog/ModalDialog";

export default {
    components: {
        Table, SearchForm, ModalDialog
    },
    data() {
        return {
            isVisible: false
        }
    },
    created() {
        this.$eventBus.$on('select-customer', this.createCustomer);
    },
    beforeDestroy() {
        this.$eventBus.$off('select-customer', this.createCustomer);
    },
    methods: {
        async createCustomer(customer) {
            window.preloader.show();
            try {
                const res = await this.$axios.post('/customers/store', {...customer});
                window.location.href = `/customers/${res.data}`;
            } catch (err) {
                console.error("Couldn't create a customer! Err:", err);
                window.flash.showMessagesFromAjax(err.response.data);
            }
            window.preloader.hide();
        }
    }
}
</script>
