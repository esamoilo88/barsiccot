import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import Index from "./Index";

Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;

export default new Vue({
    el: '#customers-list-widget',
    components: {
        Index
    }
});
