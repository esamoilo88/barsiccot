<template>
    <div id="my_project_widget" class="d-flex flex-column">
        <div class="widget-header d-flex flex-column">
            <h2 id="my_project_title" class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>
        <div class="widget-content simple-box box-shadow">
            <b-overlay :show="loading">
                <div class="row" v-if="!loading">
                    <div class="project_sum col-lg-12">
                        <div class="row no-gutters align-items-center border-bottom pr-3 pb-3 pt-3">
                            <div id="auftragseingang_box" class="col-auto pr-2 m-2">
                                <div class="d-flex">
                                    <div class="w-20 mr-3">
                                        <div class="yellow icon_background">
                                            <span class="icon-content-tarrifs-default icon_size"></span>
                                        </div>
                                    </div>
                                    <div class="mr-3">
                                        <span class="text-uppercase titles" id="auftragseingang_title"> Auftragseingang {{ currentYear }}</span>
                                        <div class="cost_value">
                                            {{ $f.numberToString(items.kosten.betrag, true, false, '0,00') }}
                                        </div>
                                        <div id="auftragseingang_procent" class="text-muted">{{ items.prozent.betrag }}% von Gesamt</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pr-3 pt-3 m-2">
                            <div id="ilv_box" class="d-flex">
                                <div class="w-20 mr-3">
                                    <div class="bg-info icon_background">
                                        <span class="icon-user_file-billing-default icon_size"></span>
                                    </div>
                                </div>
                                <div class="mr-5">
                                    <span class="text-uppercase titles" id="ilv_title"> ILV {{ currentYear }}</span>
                                    <div class="cost_value">
                                        {{ $f.numberToString(items.kosten.sumIlv, true, false, '0,00') }}
                                    </div>
                                    <div class="text-muted" id="ilv_procent">{{ items.prozent.sumIlv }}% von Gesamt</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="pr-1 pt-1">
                            <div id="umsatz_box" class="d-flex">
                                <div class="w-20 mr-3">
                                    <div class="bg-success icon_background">
                                        <span class="icon-user_file-billing-default icon_size"></span>
                                    </div>
                                </div>
                                <div class="mr-3">
                                    <span class="text-uppercase titles" id="umsatz_title"> Umsatz {{ currentYear }}</span>
                                    <div class="cost_value">
                                        {{ $f.numberToString(items.kosten.umsatz, true, false, '0,00') }}
                                    </div>
                                    <div class="text-muted" id="umsatz_procent">{{ items.prozent.umsatz }} % von Gesamt</div>
                                </div>
                            </div>
                        </div>
                        <div class="pr-1 pt-4">
                            <div id="realisierter_umsatz_box" class="d-flex ml-2">
                                <div class="w-20 mr-2">
                                    <div>
                                        <span class="icon-user_file-billing-default icon_size_non_back mr-3"></span>
                                    </div>
                                </div>
                                <div class="mr-2">
                                    <div class="titles text-uppercase" id="realisierter_umsatz_title"> Realisierter Umsatz {{ currentYear }}</div>
                                    <div class="cost_value">
                                        {{ $f.numberToString(items.kosten.realis, true, false, '0,00') }}
                                    </div>
                                    <div class="text-muted">Januar - {{ currentMonth }}</div>
                                </div>
                            </div>
                        </div>
                        <div class="pr-1 pt-4">
                            <div id="geplanter_umsatz_box" class="d-flex ml-2">
                                <div class="w-20 mr-2">
                                    <div>
                                        <span class="icon-user_file-analytics-default icon_size_non_back mr-3"></span>
                                    </div>
                                </div>
                                <div class="mr-2">
                                    <div class="text-uppercase titles"  id="geplanter_umsatz_title"> Geplanter Umsatz {{ currentYear }}</div>
                                    <div class="cost_value">
                                        {{ $f.numberToString(items.kosten.planned, true, false, '0,00') }}
                                    </div>
                                    <div class="text-muted">{{ futureMonth }} - Dezember</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </b-overlay>
        </div>
    </div>
</template>

<script>
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import ComputeFieldsMxn from "./ComputeFieldsMxn";
import {BOverlay} from "bootstrap-vue";

export default {
    name: "MyProjectsSum",
    components: {BOverlay},
    mixins: [ObjectsProcessing, ComputeFieldsMxn],
    props: {
        widget: {
            type: Object,
            required: true
        }
    },
    async created() {
        await this.getSumDate();
    },
    mounted() {
        this.$emit('loaded');
    },
    data() {
        return {
            items: [],
            loading: true
        }
    },
    methods: {
        async getSumDate() {
            this.loading = true;
            let res = await this.$axios.get(`widgets/sum-projects`);
            this.items = res.data;
            this.loading = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/features/widgets';

.cost_value {
    font-weight: bold;
    font-size: 22px;
    padding: 2px 0 2px;
}

.marge-box {
    border-right: 2px solid #dee2e6;
    margin-right: 55px;
    padding-right: 55px;
}

.text-muted {
    font-size: 1.125rem;
}

.project_sum {
    padding: 0;
    border-right: 1px solid #dee2e6 !important;
}

.gesamt_preis {
    padding-right: 0;
}

.icon_background {
    border-radius: 50px;
    position: relative;
    width: 40px;
    height: 40px;
}

.icon_size {
    position: absolute;
    top: 27%;
    left: 24%;
    width: 70%;
    font-size: 1.3rem;
    vertical-align: middle;
}

.icon_size_non_back {
    font-size: 1.3rem;
}

.titles {
    color: grey;
    font-size: 16px;
    font-weight: bold;
}
</style>
