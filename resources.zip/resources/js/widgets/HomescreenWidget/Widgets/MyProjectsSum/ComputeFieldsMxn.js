import dayjs from 'res/js/utils/day';

export default {
    computed: {
        currentYear() {
            return dayjs().format('YYYY');
        },
        currentMonth() {
            return dayjs().format('MMMM');
        },
        futureMonth() {
            return dayjs().add(1, 'month').format('MMMM');
        }
    }
}
