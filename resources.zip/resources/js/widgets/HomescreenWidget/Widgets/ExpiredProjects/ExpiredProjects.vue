<template>
    <div>
        <div class="widget-header d-flex flex-column">
            <h2 class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>

        <div class="widget-content simple-box box-shadow scrollable">
            <BoxSpinner :busy="loading"/>

            <ul class="list-group">
                <li class="list-group-item open-offers-item" v-for="item in items">
                    <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                            <CircleChart
                                :content="item.shortName"
                                :value="item.progress"
                                :color="item.color"
                                size="small"
                                sr-text="Status"
                            />
                        </div>

                        <div class="col px-3">
                            <div class="text-muted mb-3">
                                <span>SIN/{{ item.simpleId }}</span>
                                <span>&#8226;</span>
                                <span>{{ item.thema }}</span>
                                <span>&#8226;</span>
                                <span :class="{'text-danger': isPastDate(item.vertragsende)}">Vertragsende {{ formatDate(item.vertragsende, 'DD.MM.YYYY') }}</span>
                            </div>

                            <div>
                                {{ item.kundenname }}11
                            </div>
                        </div>

                        <div class="col-auto">
                            <div class="options-container btn-group" role="group">
                                <a
                                    :href="`/projects/${item.simpleId}`"
                                    class="btn btn-outline-secondary dashboard-link"
                                    :id="`sales-dashboard-btn-${item.simpleId}`"
                                    title="Sales Dashboard"
                                    v-b-tooltip.hover.lefttop
                                >
                                    <span class="icon-content-news-default"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </li>

                <li v-if="items.length === 0" class="text-center text-muted">Keine Vorhaben</li>
            </ul>

            <div class="text-center text-muted py-3">{{ items.length }}/{{ total }}</div>

            <Observer
                ref="observer"
                @intersect="intersected"
                :is-loading="isLoading"
            />
        </div>
    </div>
</template>

<script>
import CircleChart from "@comp/CircleChart/CircleChart";
import Observer from "@comp/Observer/Observer";
import BoxSpinner from "@comp/BoxSpinner/BoxSpinner";
import {VBTooltip} from 'bootstrap-vue';
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: 'ExpiredProjects',
    components: {CircleChart, Observer, BoxSpinner},
    mixins: [DatesProcessing],
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        widget: {
            type: Object
        }
    },
    data() {
        return {
            items: [],
            total: 0,
            currentPage: 1,
            perPage: 5,
            loading: false,
            isLoading: false
        }
    },
    async mounted() {
        this.$emit('loaded');
    },
    methods: {
        async intersected() {
            if (this.total && this.items.length === this.total) return;

            this.loading = true;
            this.isLoading = true;

            const response  = await this.$axios.get(`widgets/projects/expired`, {
                params: {
                    currentPage: this.currentPage,
                    perPage: this.perPage
                }
            })

            this.currentPage++;

            this.total = response.data.total;
            this.items = [...this.items, ...response.data.data];

            this.loading = false;
            this.isLoading = false;

            await this.$nextTick();
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";
@import 'resources/sass/features/widgets';

.dashboard-link {
    span {
        font-size: 1.5rem;
        color: $iconscolor;
        vertical-align: middle;
    }
}

.scrollable{
    min-height: auto;
    max-height: 300px;
    overflow: auto;
    padding-bottom: 2px;
}
</style>
