<template>
    <div class="d-flex flex-column">
        <div class="widget-header d-flex flex-column">
            <h2 class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>
        <div class="widget-content simple-box box-shadow">
            <div class="row">
                <div class="col-lg-12 d-flex flex-column">
                    <div class="mb-3">
                        <span class="text-uppercase">Benutzername</span>
                        {{ widget.data.username }}
                    </div>
                    <div class="mb-3">
                        <span class="text-uppercase">Bereich</span>
                        {{ getValue(widget.data, 'bereich.teamKurz') }} - {{ getValue(widget.data, 'bereich.teamLang') }}
                    </div>
                    <div class="mb-3"><span class="text-uppercase">E-mail</span>{{ widget.data.email }}</div>
                    <div class="mb-3"><span class="text-uppercase">Telefonnummer</span>{{ widget.data.telNr }}</div>
                </div>
                <div class="col-lg-12">
                    <div>
                        <span class="text-uppercase">Berechtigungen</span>
                        <ul class="permissions-list pl-0">
                            <li v-for="permission of widget.data.backendRechtes" :key="permission.bezeichnung">
                                {{ permission.bezeichnung }}
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";

export default {
    name: "UserInfo",
    mixins: [ObjectsProcessing],
    props: {
        widget: {
            type: Object,
            required: true
        }
    },
    mounted() {
        this.$emit('loaded');
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/features/widgets';

.widget-content .text-uppercase {
    font-weight: bold;
    display: block;
    margin-bottom: 0.5rem;
}

.permissions-list {
    list-style: none;
}
</style>
