<template>
    <div class="d-flex flex-column">
        <div class="widget-header d-flex flex-column">
            <h2 class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>
        <b-overlay :show="initialLoading">
            <div class="widget-content simple-box box-shadow">
                <div v-for="item in items">
                    <div class="row no-gutters align-items-center">
                        <div class="col-xl-3">
                            <CircleChart
                                v-if="item.financeStatusProgress"
                                :icon-class="item.financeStatusIcon"
                                :value="item.financeStatusProgress"
                                :color="item.financeStatusColor"
                                size="xsmall"
                                sr-text="Finance Status"
                            />
                            <CircleChart
                                v-else
                                content=""
                                size="xsmall"
                                sr-text="Finance Status"
                            />
                        </div>

                        <div class="col-xl-19 d-flex flex-column">
                            <div class="d-flex">
                                <span class="text-muted text-1r">SIN/{{ item.simpleId }}</span>
                                <span class="mx-2 bullet-divider">•</span>
                                <span class="text-muted text-1r">{{ item.kundenname }}</span>
                                <span class="mx-2 bullet-divider">•</span>
                                <Badge :color="item.statusColor">{{ item.statusShortName }}</Badge>
                            </div>
                            <span>{{ item.thema }}</span>
                        </div>

                        <div class="col-xl-2">
                            <a
                                :href="'/orders/' + item.simpleId"
                                class="btn btn-secondary btn-icon dashboard-link"
                                :id="'finance-dashboard-btn-' + item.simpleId"
                                title="Finance Dashboard"
                                v-b-tooltip.hover.lefttop
                            >
                                <span class="icon-user_file-billing-default"></span>
                            </a>
                        </div>
                    </div>
                    <hr>
                </div>

                <div v-if="showMessage" class="more-data">
                    Bitte warten
                </div>

                <Observer @intersect="intersected" :is-loading="isLoading"/>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import Observer from "@comp/Observer/Observer";
import CircleChart from "@comp/CircleChart/CircleChart";
import {VBTooltip, BOverlay} from 'bootstrap-vue';
import Badge from "@comp/Badge/Badge";

export default {
    name: "OpenBilling",
    components: {
        Observer, CircleChart, Badge, BOverlay
    },
    directives: {
        'b-tooltip': VBTooltip
    },
    props: {
        widget: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            perPage: 5,
            showMessage: false,
            items: [],
            page: 1,
            total: null,
            isLoading: false,
            initialLoading: true
        }
    },
    mounted() {
        this.$emit('loaded');
    },
    methods: {
        async intersected() {
            if (this.total && this.items.length === this.total) return;

            const isFirstPage = this.page === 1;

            if (!isFirstPage) {
                this.showMessage = true;
            }

            this.isLoading = true;

            const res = await this.$axios.get(`/widgets/open-billing/${this.perPage}/${this.page}`);
            this.page++;

            this.total = res.data.total;
            this.items = [...this.items, ...res.data.data];

            this.showMessage = false;
            this.isLoading = false;
            this.initialLoading = false;
        },
        async refresh() {
            this.items = [];
            this.page = 1;
            this.total = null;
            await this.intersected();
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/variables';
@import 'resources/sass/features/widgets';

.dashboard-link {
    span {
        font-size: 1.5rem;
        color: $iconscolor;
        vertical-align: middle;
    }
}

.widget-content {
    min-height: 300px;
    max-height: 350px;
    overflow-y: auto;
}

.more-data {
    font-size: 20px;
    font-weight: bold;
    padding: 10px;
}
</style>
