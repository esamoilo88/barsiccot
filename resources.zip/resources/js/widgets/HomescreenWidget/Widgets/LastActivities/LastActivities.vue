<template>
    <div class="d-flex flex-column">
        <div class="widget-header d-flex flex-column">
            <h2 class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>
        <b-overlay :show="isLoading">
            <div class="widget-content simple-box box-shadow scrollable">
                <div v-for="item in items">
                    <div class="d-flex">
                        <div class="w-20 mr-4">
                            <div :class="['icon_background',item.cssClass]">
                                <span :class="['icon_size',item.icon]" ></span>
                            </div>
                        </div>
                        <div>
                            <div class="mr-5">
                                <div class="text-muted mb-1">{{ formatDate(item.timestamp, 'DD.MM.YYYY HH:mm:ss') }}
                                    <span class="mx-1 bullet-divider">•</span>
                                    SIN/{{ item.simpleId }}
                                    <span class="mx-1 bullet-divider">•</span>
                                    {{ item.userName }} {{ item.userSecondName }}
                                    <span class="mx-1 bullet-divider">•</span>
                                    {{ item.objectName }}
                                </div>
                                <div v-html="item.logText.replace(/(?:\r\n|\r|\n)/g, '<br />')"></div>
                            </div>
                        </div>
                    </div>
                    <hr>
                </div>

                <div v-if="showMessage" class="placeholder-preloader-wrapper">
                    <div class="ph-item ph-image">
                        <div class="ph-col-12">
                            <div class="ph-row">
                                <div class="circle-placeholder"></div>
                            </div>
                        </div>
                    </div>
                    <div class="ph-item">
                        <div class="ph-col-12">
                            <div class="ph-row">
                                <div class="ph-col-2"></div>
                                <div class="ph-col-2 empty"></div>
                                <div class="ph-col-2"></div>
                                <div class="ph-col-2 empty"></div>
                                <div class="ph-col-2"></div>
                                <div class="ph-col-12"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <Observer @intersect="intersected" :is-loading="showMessage"/>
            </div>
        </b-overlay>
    </div>
</template>

<script>
import ObjectsProcessing from "@mixins/ValuesProcessing/ObjectsProcessing";
import Observer from "@comp/Observer/Observer";
import {BOverlay} from "bootstrap-vue";
import DatesProcessing from "@mixins/ValuesProcessing/DatesProcessing";

export default {
    name: "LstActivities",
    components: {Observer, BOverlay},
    mixins: [ObjectsProcessing, DatesProcessing],
    props: {
        widget: {
            type: Object
        }
    },
    data() {
        return {
            items: [],
            total: 0,
            currentPage: 1,
            perPage: 5,
            loading: false,
            isLoading: false,
            showMessage: false
        }
    },
    async mounted() {
        this.$emit('loaded');
    },
    methods: {
        async intersected() {
            if (this.total && this.items.length === this.total) return;

            const isFirstPage = this.page === 1;

            if (isFirstPage) {
                this.isLoading = true;
            } else {
                this.showMessage = true;
            }

            const response = await this.$axios.get(`widgets/last-activities`, {
                params: {
                    currentPage: this.currentPage,
                    perPage: this.perPage
                }
            })

            this.currentPage++;

            this.total = response.data.total;
            this.items = [...this.items, ...response.data.data];
            this.showMessage = false;
            this.isLoading = false;
        }
    }
}
</script>

<style lang="scss" scoped>
@import 'resources/sass/features/widgets';

h3 {
    font-size: initial;
}

::v-deep .placeholder-preloader-wrapper {
    display: flex;

    .card-body {
        padding: 0;
    }

    .ph-item {
        display: block;
        border: none;
        border-radius: 0;
        box-shadow: none;
        margin: 0;

        .ph-col-24 {
            padding: 0;
        }
    }

    .ph-row div {
        width: 350px;
    }
}
.icon_background{
    border-radius: 50px;
    position: relative;
    width: 60px;
    height: 60px;
}
.icon_size{
    position: absolute;
    top: 28%;
    left: 28%;
    width: 80%;
    font-size: 1.7rem;
    vertical-align: middle;
}
.scrollable{
    min-height: auto;
    max-height: 300px;
    overflow: auto;
    padding-bottom: 2px;
}
.placeholder-preloader-wrapper .ph-row div.circle-placeholder{
    width: 350px;
    height: 48px;
    border-radius: 120px;
}
.ph-col-12,.ph-col-2{
    border-radius: 20px;
}
</style>
