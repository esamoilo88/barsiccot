<template>
    <div class="d-flex flex-column">
        <div class="widget-header d-flex flex-column">
            <h2 class="mr-3 widget-name">{{ widget.name }}</h2>
            <span class="text-muted widget-description">{{ widget.description }}</span>
        </div>
        <div class="widget-content simple-box box-shadow">
            <div class="row">
                <div class="calendar-wrapper col-xxl-6 col-xl-8 col-lg-8 col-md-12 d-flex flex-column">
                    <b-overlay :show="pending">
                        <b-calendar
                            @input="showEvents"
                            @context="fetchEvents"
                            :date-info-fn="getClassForDate"
                            locale="de"
                            label-help=""
                            nav-button-variant="primary"
                            :start-weekday="1"
                            label-current-month="Aktueller Monat"
                            label-prev-month="Vorheriger Monat"
                            label-next-month="Nächster Monat"
                            label-prev-year="Vorheriges Jahr"
                            label-next-year="Nächstes Jahr"
                            hide-header
                        ></b-calendar>
                    </b-overlay>
                </div>
                <div class="col-xxl-17 col-xl-15 col-lg-15 d-flex flex-column">
                    <div class="row">
                        <div class="selected-date col-xxl-4 col-lg-12 col-md-13">
                            <div class="selected-day">{{ selectedDate.day }}</div>
                            <div class="d-flex flex-column">
                                <div class="selected-weekday">{{ selectedDate.weekday }}</div>
                                <div class="selected-month-year">{{ selectedDate.month }} {{ selectedDate.year }}</div>
                            </div>
                            <div v-if="widgetData.data.ultimo_at[selectedDate.ymd]" class="d-flex flex-column mt-3">
                                <b-badge class="mb-2">{{ 'AT' + widgetData.data.ultimo_at[selectedDate.ymd]['at'] }}</b-badge>
                                <b-badge>{{ 'U-' + widgetData.data.ultimo_at[selectedDate.ymd]['ultimo'] }}</b-badge>
                            </div>
                        </div>

                        <div class="events-list col-xxl-20 col-lg-12 col-md-12 mt-xxl-0 mt-md-3 d-flex flex-column">
                            <span class="font-weight-bold mb-3">Termine</span>
                            <template v-if="selectedDate.events">
                                <div class="d-flex align-items-start mb-2" v-for="event of selectedDate.events" :key="'evt-' + event.id">
                                    <b-badge :class="'bg-' + event.color + ' mr-2'">{{ event.group }}</b-badge>
                                    <div>
                                        <span class="font-weight-bold mr-2">{{ event.process }}</span>
                                        <span>{{ event.description }} ({{ event.timeValue }})</span>
                                    </div>
                                </div>
                            </template>
                            <div v-else>
                                Keine Daten vorhanden
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import dayjs from 'res/js/utils/day';
import {BCalendar, BBadge, BOverlay} from 'bootstrap-vue';

export default {
    name: "FinanceCalendar",
    components: {
        BCalendar, BBadge, BOverlay
    },
    props: {
        widget: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            widgetData: this.widget,
            selectedDate: {
                ymd: '',
                day: 0,
                weekday: '',
                month: '',
                year: 0,
                events: []
            },
            context: {},
            pending: false
        }
    },
    created() {
        this.showEvents(dayjs().format('YYYY-MM-DD'));
    },
    mounted() {
        this.$emit('loaded');
    },
    methods: {
        getClassForDate(ymd, date) {
            let classes = ['date-btn'];
            if (this.widgetData.data.dates[ymd]) {
                let color = 'badge-' + this.widgetData.data.dates[ymd][0].color;
                classes = [...classes, 'has-event', color];
            }
            return classes;
        },
        showEvents(ymd) {
            let date = dayjs(ymd, 'YYYY-MM-DD');
            this.selectedDate.year = date.format('YYYY');
            this.selectedDate.month = date.format('MMMM');
            this.selectedDate.day = date.format('DD');
            this.selectedDate.weekday = date.format('dddd');
            this.selectedDate.ymd = ymd;
            this.selectedDate.events = this.widgetData.data.dates ? this.widgetData.data.dates[ymd] : [];
        },
        async fetchEvents(context) {
            let date = dayjs(context.activeYMD, 'YYYY-MM-DD');
            let month = date.format('M');
            let year = date.format('YYYY');
            let lastSelectedDate = dayjs(this.context.activeYMD, 'YYYY-MM-DD');

            if (month !== lastSelectedDate.format('M') || year !== lastSelectedDate.format('YYYY')) {
                try {
                    this.pending = true;
                    const res = await this.$axios.get(`/widgets/finance-calendar/${year}/${month}`);
                    this.widgetData.data = res.data;
                    this.showEvents(date.format('YYYY-MM-DD'));
                } catch (err) {
                    console.error('Couldn\'t fetch month events! Err:', err);
                    window.flash.showMessagesFromAjax(err.response.data);
                }
                this.pending = false;
            }

            this.context = context;
        }
    }
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";
@import 'resources/sass/features/widgets';

::v-deep .date-btn {
    position: relative;
    border-radius: 5px !important;

    span, span:hover, span.active, .btn-outline-primary:not(:disabled):not(.disabled):active {
        border-radius: 5px !important;
        background-color: inherit !important;
        color: inherit !important;
        transition: none !important;
    }

    .btn-outline-primary {
        color: $primary !important;
    }

    &:hover:not([class*="badge-"]) {
        background-color: #ececec;
    }

    &[aria-selected="true"] {
        color: #fff !important;
        background-color: $primary !important;
    }
}

::v-deep div.has-event::after {
    content: '◢';
    position: absolute;
    bottom: -2px;
    right: 2px;
    font-size: 13px;
}

.selected-date {
    max-width: 250px;
}

.selected-day {
    font-weight: bold;
    font-size: 2rem;
}

.selected-weekday {
    border-bottom: 4px solid grey;
    padding-bottom: 10px;
}

.selected-month-year {
    padding-top: 10px;
}

.events-list {
    padding-left: 5rem;
}

.calendar-wrapper {
    max-width: 320px;
}

::v-deep [class*="badge-"] {
    color: #000 !important;
}
</style>
