<template>
    <div class="no-widgets d-flex flex-column justify-content-center align-items-center">
        <span class="icon-action-tiles-add-selected add-widget-icon"></span>
        <h2 class="font-weight-bold mt-2">Homescreen</h2>
        <span>Nutze Widgets um deinen</span>
        <span>Homescreen zu personalisieren.</span>
        <a class="btn btn-primary mt-5" href="/profile/#widgets-selection">Jetzt Widgets auswählen</a>
    </div>
</template>

<script>

export default {
    name: "NoWidgets"
}
</script>

<style scoped>
.no-widgets {
    border: 2px dashed grey;
    border-radius: 5px;
    background-color: #fff;
    padding: 100px 0;
}

.add-widget-icon {
    font-size: 5.5rem;
}
</style>
