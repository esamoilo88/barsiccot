<template>
    <div>
        <NoWidgets v-if="widgetsProp.length === 0"/>

        <div :class="{'fixed-height': mountedWidgets != 0, 'position-relative': true}" v-else>

            <div v-if="mountedWidgets != 0" class="widgets-preloader mb-4 box-shadow">
                <div class="ph-item">
                    <div class="ph-col-12">
                        <div class="ph-row">
                            <div class="ph-col-2 big"></div>
                            <div class="ph-col-10 empty"></div>
                            <div class="ph-col-12 empty"></div>
                            <div class="ph-col-4"></div>
                            <div class="ph-col-8 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                            <div class="ph-col-12 empty"></div>
                            <div class="ph-col-6"></div>
                            <div class="ph-col-6 empty"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row widgets-wrapper">
                <template v-for="widget of widgetsProp">
                    <div :class="getWidgetWrapperClass(widget.size) + ' mb-4'" :key="widget.id">
                        <component @loaded="--mountedWidgets" :is="widget.sysName" :widget="widget"></component>
                    </div>
                </template>
            </div>
        </div>
    </div>
</template>

<script>

import NoWidgets from "res/js/widgets/HomescreenWidget/NoWidgets";

export default {
    name: "homescreen",
    components: {NoWidgets},
    props: {
        widgetsProp: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            mountedWidgets: this.widgetsProp.length
        }
    },
    created() {
        this.widgetsProp.map(w => {
            this.$options.components[w.sysName] = () => import(`./Widgets/${w.sysName}/${w.sysName}.vue`);
        });
    },
    methods: {
        getWidgetWrapperClass(size) {
            switch (size) {
                case 'small':
                    return 'col-lg-6';
                case 'medium':
                    return 'col-lg-12';
                case 'full':
                    return 'col-lg-24';
                default:
                    return 'col-lg-24';
            }
        }
    }
}
</script>

<style scoped>
.fixed-height {
    max-height: 229px;
    height: 229px;
    overflow: hidden;
}

.widgets-preloader {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    z-index: 1000;
    margin-right: 15px;
    margin-left: 15px;
}

.ph-item {
    display: flex;
}
</style>
