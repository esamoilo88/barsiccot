import Vue from 'vue';
import {$axios, eventBus} from 'res/js/boot';
import homescreen from "./HomeScreen";
import Formatter from "res/js/utils/formatter";
import {ModalPlugin} from 'bootstrap-vue';
import Vuelidate from "vuelidate";
import SimpleTranslator from "res/js/utils/SimpleTranslator";

const translations = require('res/lang/lang.translations.json');
const t = new SimpleTranslator(translations);

Vue.prototype.$f = new Formatter();
Vue.prototype.$axios = $axios;
Vue.prototype.$eventBus = eventBus;
Vue.prototype.$t = t;

Vue.use(ModalPlugin);
Vue.use(Vuelidate);

export default new Vue({
    el: '#homescreen', //resources/views/App/Homescreen/index.blade.php
    components: {
        homescreen
    }
});
