<?php

namespace App\Components\Termine;

use App\Http\Requests\Offer\Einstellungen\Preisbildung\StorePreisbildungRequest;
use App\Http\Requests\Offer\NewOfferRequest;
use App\Http\Requests\Orders\CreateOrdersRequest;
use App\Http\Requests\Project\UpdateLaufzeitRequest;
use Illuminate\Support\Carbon;

class Termine
{
    /**
     * check  Termine according the function checkTermine and check on the past date and return error messages
     *
     * @param CreateOrdersRequest|NewOfferRequest|UpdateLaufzeitRequest|StorePreisbildungRequest $arrData [Sales_Anfrage array mit Terminfeldern]
     * @return array
     **/
    public function checkTermine($arrData): array
    {
        $errors = array();

        if (!empty($arrData->vertragsbeginn) && !empty($arrData->vertragsende)) {
            $intVertragsbeginn = Carbon::createFromFormat('d.m.Y', $arrData->vertragsbeginn);
            $intVertragsende = Carbon::createFromFormat('d.m.Y', $arrData->vertragsende);

            if ($intVertragsbeginn > $intVertragsende) {
                $errors['vertragsbeginn'][] = 'Der Vertragsbeginn darf nicht nach dem Vertragsende liegen.';
                $errors['vertragsende'][] = 'Das Vertragsende darf nicht vor dem Vertragsbeginn liegen.';
            }

            if (!empty($arrData->rolloutbeginn)) {
                $intRolloutbeginn = Carbon::createFromFormat('d.m.Y', $arrData->rolloutbeginn);

                if ($intRolloutbeginn->lessThan($intVertragsbeginn)) {
                    $errors['rolloutbeginn'][] =
                        'Der Realisierungsbeginn darf nicht vor dem Vertragsbeginn liegen.';
                }
                if ($intRolloutbeginn->greaterThan($intVertragsende)) {
                    $errors['rolloutbeginn'][] =
                        'Der Realisierungsende darf nicht nach dem Vertragsende liegen.';
                }
            }
            if (!empty($arrData->rolloutende)) {
                $intRolloutende = Carbon::createFromFormat('d.m.Y', $arrData->rolloutende);

                if ($intRolloutende->lessThan($intVertragsbeginn)) {
                    $errors['rolloutende'][] = 'Das Realisierungsende darf nicht vor dem Vertragsbeginn liegen.';
                }
                if ($intRolloutende->greaterThan($intVertragsende)) {
                    $errors['rolloutende'][] = 'Das Realisierungsende darf nicht nach dem Vertragsende liegen.';
                }
            }


            if (!empty($arrData->betriebsbeginn)) {
                $intBetriebsbeginn = Carbon::createFromFormat('d.m.Y', $arrData->betriebsbeginn);

                if ($intBetriebsbeginn->lessThan($intVertragsbeginn)) {
                    $errors['betriebsbeginn'][] = 'Der Betriebsbeginn darf nicht vor dem Vertragsbeginn liegen.';
                }
                if ($intBetriebsbeginn->greaterThan($intVertragsende)) {
                    $errors['betriebsbeginn'][] = 'Der Betriebsbeginn darf nicht nach dem Vertragsende liegen.';
                }
            }
            if (!empty($arrData->betriebsende)) {
                $intBetriebsende = Carbon::createFromFormat('d.m.Y', $arrData->betriebsende);

                if ($intBetriebsende->lessThan($intVertragsbeginn)) {
                    $errors['betriebsende'][] = 'Das Betriebsende darf nicht vor dem Vertragsbeginn liegen.';
                }
                if ($intBetriebsende->greaterThan($intVertragsende)) {
                    $errors['betriebsende'][] = 'Das Betriebsende darf nicht nach dem Vertragsende liegen.';
                }
            }
            if (!empty($arrData->beauftragungsende)) {
                $intBeauftragungsende = Carbon::createFromFormat('d.m.Y', $arrData->beauftragungsende);

                if ($intBeauftragungsende->lessThan($intVertragsbeginn)) {
                    $errors['beauftragungsende'][] = 'Das Beauftragungsende darf nicht vor dem Vertragsbeginn liegen.';
                }
                if ($intBeauftragungsende->greaterThan($intVertragsende)) {
                    $errors['beauftragungsende'][] = 'Das Beauftragungsende darf nicht nach dem Vertragsende liegen.';
                }

            }
        }


        if (!empty($arrData->rolloutbeginn) && !empty($arrData->rolloutende)) {
            $intRolloutbeginn = Carbon::createFromFormat('d.m.Y', $arrData->rolloutbeginn);
            $intRolloutende = Carbon::createFromFormat('d.m.Y', $arrData->rolloutende);

            if ($intRolloutbeginn->greaterThan($intRolloutende)) {
                $errors['rolloutbeginn'][] = 'Der Realisierungsbeginn darf nicht nach dem Realisierungsende liegen.';
                $errors['rolloutende'][] = 'Das Realisierungsende darf nicht vor dem Realisierungsbeginn liegen.';
            }
        }

        if (!empty($arrData->betriebsbeginn) && !empty($arrData->betriebsende)) {
            $intBetriebsbeginn = Carbon::createFromFormat('d.m.Y', $arrData->betriebsbeginn);
            $intBetriebsende = Carbon::createFromFormat('d.m.Y', $arrData->betriebsende);

            if ($intBetriebsbeginn->greaterThan($intBetriebsende)) {
                $errors['betriebsbeginn'][] = 'Der Betriebsbeginn darf nicht nach dem Betriebsende liegen.';
                $errors['betriebsende'][] = 'Das Betriebsende darf nicht vor dem Betriebsbeginn liegen.';
            }
        }


        if (!empty($arrData->rolloutende) && empty($arrData->rolloutbeginn)) {
            $errors['rolloutbeginn'][] =
                'Wenn ein Realisierungsende angegeben wird, so ist auch ein Realisierungsbeginn erforderlich.';
        }
        if (!empty($arrData->rolloutbeginn) && empty($arrData->rolloutende)) {
            $errors['rolloutende'][] =
                'Wenn ein Realisierungsbeginn angegeben wird, so ist auch ein Realisierungsende erforderlich.';
        }

        if (!empty($arrData->betriebsende) && empty($arrData->betriebsbeginn)) {
            $errors['betriebsbeginn'][] =
                'Wenn ein Betriebsende angegeben wird, so ist auch ein Betriebsbeginn erforderlich.';
        }
        if (!empty($arrData->betriebsbeginn) && empty($arrData->betriebsende)) {
            $errors['betriebsende'][] =
                'Wenn ein Betriebsbeginn angegeben wird, so ist auch ein Betriebsende erforderlich.';
        }

        $DateNow = Carbon::today();

        if (!empty($arrData->vertragsende)) {
            $intVertragsende = Carbon::createFromFormat('d.m.Y', $arrData->vertragsende);
            if ($intVertragsende->lessThan($DateNow)) {
                $errors['vertragsende'][] = 'Das Vertragsende darf nicht in der Vergangenheit liegen.';
            }
        }

        if (!empty($arrData->rolloutende)) {
            $intRolloutende = Carbon::createFromFormat('d.m.Y', $arrData->rolloutende);
            if ($intRolloutende->lessThan($DateNow)) {
                $errors['rolloutende'][] = 'Das Realisierungsende darf nicht in der Vergangenheit liegen.';
            }
        }

        if (!empty($arrData->betriebsende)) {
            $intBetriebsende = Carbon::createFromFormat('d.m.Y', $arrData->betriebsende);
            if ($intBetriebsende->lessThan($DateNow)) {
                $errors['betriebsende'][] = 'Das Betriebsende darf nicht in der Vergangenheit liegen.';
            }
        }
        if (!empty($arrData->lieferterminAngebot)) {
            $intLiefertermin = Carbon::createFromFormat('d.m.Y', $arrData->lieferterminAngebot);
            if ($intLiefertermin->lessThan($DateNow)) {
                $errors['lieferterminAngebot'][] = 'Der Liefertermin darf nicht in der Vergangenheit liegen.';
            }
        }


        if (!empty($arrData->vertragsbeginn) && !empty($arrData->lieferterminAngebot)) {
            $intLiefertermin = Carbon::createFromFormat('d.m.Y', $arrData->lieferterminAngebot);
            $intVertragsbeginn = Carbon::createFromFormat('d.m.Y', $arrData->vertragsbeginn);

            if ($intVertragsbeginn->lessThan($intLiefertermin)) {
                $errors['lieferterminAngebot'][] = 'Der Liefertermin Angebot liegt nach dem Vertragsbeginn.';
            }
        }
        return $errors;
    }

}
