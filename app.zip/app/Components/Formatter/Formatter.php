<?php

namespace App\Components\Formatter;

use App\Domain\Signatures\DateFormat\DateFormatSignature;
use DateTime;

class Formatter
{
    /**
     * @param float|null $number
     * @param int $decimals
     * @param false $useCurrency
     * @param string|null $defaultVal
     * @return string
     */
    public static function numberToString(?float $number, int $decimals = 2, $useCurrency = false, ?string $defaultVal = '0,00'): string
    {
        $number = ($number) ? number_format($number, $decimals, ',', '.') : $defaultVal;

        return $useCurrency ? $number . ' €' : $number;
    }

    /**
     * @param string|null $number
     * @param bool $isBig
     * @return float|string|null
     */
    public static function stringToNumber(?string $number, bool $isBig = false)
    {
        if (is_null($number)) {
            return null;
        }
        $number = str_replace('€', '', $number);
        $number = str_replace('%', '', $number);
        $number = str_replace('.', '', $number);
        $number = str_replace(',', '.', $number);
        $number = trim($number);

        return $isBig ? (string)$number : (float)$number;
    }

    /**
     * @param DateTime $dateTime
     * @param DateFormatSignature $formatSignature
     * @return string
     */
    public static function dateToString(DateTime $dateTime, DateFormatSignature $formatSignature): string
    {
        return $dateTime->format($formatSignature->value());
    }

    /**
     * @param $value
     * @param int $decimals
     * @param string $decPoint
     * @param string $thousandsSeparator
     * @return float
     */
    public static function formatFloat($value, int $decimals = 2, string $decPoint = '.', string $thousandsSeparator = ''): float
    {
        if (is_string($value)) {
            $value = self::stringToNumber($value);
        }
        return number_format((float)$value, $decimals, $decPoint, $thousandsSeparator);
    }

    /**
     * Get the value with leading zeros (e.g. 9 => 09)
     * @param $value
     * @param int $length - the required amount of numbers in result
     * @return string
     */
    public static function leadingZeros($value, int $length = 2): string
    {
        $strValue = (string)$value;
        if (mb_strlen($strValue) < $length) {
            $diff = $length - mb_strlen($strValue);
            $strValue = str_repeat('0', $diff) . $strValue;
        }

        return $strValue;
    }
}
