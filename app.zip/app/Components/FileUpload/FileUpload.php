<?php

namespace App\Components\FileUpload;

use App\Domain\ValueObjects\UploadedFile;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\UploadedFile as HttpUploadedFile;

class FileUpload
{
    // List of allowed Uploads
    private static array $permitted = [
        'gif', 'jpeg', 'jpg', 'pjpeg', 'png', 'csv', 'csv', 'xls', 'xlt', 'xla', 'xlsx', 'msg', 'pdf', 'doc', 'docx',
        'dot'
    ];

    //temporary path for files if rootfolder was be not mentioned
    private static string $path = "files/tmp";

    /**
     * Function store: save File in the server path
     *
     * @param object $request
     * @return array
     *
     */
    public function getTempPath(object $request): array
    {
        $i = 0;
        $path = [];
        /** @var HttpUploadedFile $file */
        while (!empty($file = $request->file('file_' . $i))) {

            $path[] = [
                'tempPath' => $file->store('/fileStorages'),
                'size' => $file->getSize()
            ];

            $i++;
        }
        return $path;
    }

    /***
     * Function store: save File in the server path
     * @param UploadedFile $file
     * @param string|null $targetFolder
     * @param array|null $validExts
     * @param bool $removeExistingFile
     * @throws \Exception
     */
    public function storeFile(UploadedFile $file, ?string $targetFolder, ?array $validExts, bool $removeExistingFile = false)
    {
        $target = $targetFolder ?? self::$path;

        $contents = Storage::get($file->getSavePath());
        $filename = $file->getFileName();

        Storage::disk('local')->put($filename, $contents);

        $allowedExtentions = $validExts ? $validExts : self::$permitted;
//        if we keep validation here
        $typeOK = in_array($file->getExtension(), $allowedExtentions);

        if ($removeExistingFile) {
            $this->deleteFile($file, $target, $allowedExtentions);
        }

        if ($typeOK) {
            $this->storeToRootPath($file, $targetFolder);
        } else {
            throw new \Exception(__('errors.file_upload.invalid_exts'));
        };
    }

    /**
     * @param UploadedFile $file
     * @param string $target
     * @throws \Exception
     */
    protected function storeToRootPath(UploadedFile $file, string $target): void
    {
        $filename = iconv("UTF-8", "ISO-8859-1", $file->getFileName());

        $fullPath = $target . $filename;

        if (Storage::disk('root_path')->exists($fullPath)) {
            throw new \Exception(__('errors.file_upload.file_exist'));
        }

        $success = Storage::disk('root_path')->put($target . $file->getFileName(), Storage::get($file->getSavePath()));
        if (!$success) {
            throw new \Exception(__('errors.file_upload.error_upload'));
        }
    }


    /**
     * Function store: save File in the server path
     * @param array $files
     * @param string|null $targetFolder
     * @param array $validExts
     * @param bool $removeExistingFile
     * @throws \Exception
     */
    public function upload(array $files, string $targetFolder = null, array $validExts = [], bool $removeExistingFile = false): void
    {
        foreach ($files as $file) {
            if (Storage::disk('local')->exists($file->getSavePath())) {
                $this->storeFile($file, $targetFolder, $validExts, $removeExistingFile);
            }
        }

    }

    /**
     * @param string $fileName
     * @param string|null $targetFolder
     * @param bool $withPattern
     * @return bool
     */
    public function isFileExist(string $fileName, string $targetFolder = '', bool $withPattern = false): bool
    {
        $fileName = str_replace(' ', '_', $fileName);
        if ($targetFolder !== '') {
            $target = mb_strpos($targetFolder, ':') === false
                ? config('dbconfig.storage.BASE_PATH_FILES') . $targetFolder
                : $targetFolder;
        } else {
            $target = self::$path;
        }
        $target = $target . $fileName;

        if ($withPattern) {
            $matchingFiles = File::glob($target);
            return count($matchingFiles) > 0;
        }

        return Storage::disk('root_path')->exists($target);
    }

    /**
     * @param string $fileName
     * @param string $targetFolder
     * @return array
     */
    public function getLoadedFiles(string $fileName, string $targetFolder, $withPattern = false): array
    {
        $result = [];
        if ($this->isFileExist($fileName, $targetFolder, $withPattern)) {
            $files = Storage::disk('root_path')->files($targetFolder);
            foreach ($files as $key=>$file) {
                $result[$key]['size'] = Storage::disk('root_path')->size($file);
                $lastmodified = Storage::disk('root_path')->lastModified($file);
                $result[$key]['date'] = \DateTime::createFromFormat("U", $lastmodified);
                $result[$key]['name'] = $file;
                $result[$key]['shortName'] = basename($file);
            }
        }
        return $result;

    }

    /**
     * Delete old Angebotsfile before upload new one
     * @param UploadedFile $file
     * @param string $target
     * @param array $allowedExtentions
     */
    private function deleteFile(UploadedFile $file, string $target, array $allowedExtentions): void
    {
        if (in_array($file->getExtension(), $allowedExtentions)) {
            if (file_exists(config('dbconfig.storage.BASE_PATH_FILES') . $target . $file->getFileName())) {
                unlink(config('dbconfig.storage.BASE_PATH_FILES') . $target . $file->getFileName());
            }
        }
    }

    /**
     * @param array $attachments
     */
    public function deleteFiles(array $attachments): void
    {
        foreach ($attachments as $targetPath) {
            if (file_exists($targetPath)) {
                unlink($targetPath);
            }
        }
    }

}


