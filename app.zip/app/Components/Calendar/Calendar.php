<?php

namespace App\Components\Calendar;

use App\Domain\Repositories\Interfaces\IOfferAuftragRepository;
use App\Domain\ValueObjects\SIN;
use DateInterval;
use DateTime;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Spatie\Regex\Regex;

class Calendar
{
    public static array $months = [1 => 'Januar', 2 => 'Februar', 3 => 'März', 4 => 'April', 5 => 'Mai', 6 => 'Juni',
        7 => 'Juli', 8 => 'August', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Dezember'];

    public static array $weekdays = [
    	'kurz' => [1 => 'Mo', 2 => 'Di', 3 => 'Mi', 4 => 'Do', 5 => 'Fr', 6 => 'Sa', 7 => 'So'],
    	'lang' => [1 => 'Montag', 2 => 'Dienstag', 3 => 'Mittwoch', 4 => 'Donnerstag', 5 => 'Freitag', 6 => 'Samstag', 7 => 'Sonntag'],
    ];

    private static Carbon $currentFakturaDate;

    private static Carbon $previousFakturaDate;

    /**
     * @var int - the sequence number of working day for the current month
     */
    private static int $currentWorkingDayIndex;

    public function __construct()
    {
        $previousDate = Carbon::now()->subMonth()->startOfMonth();
        $workingDayConfig = (int) config('dbconfig.faktura.OFFER_FAKTURATAG', 3);

        self::$previousFakturaDate     = self::getFakturaDate($workingDayConfig, $previousDate);
        self::$currentFakturaDate      = self::getFakturaDate();
        self::$currentWorkingDayIndex  = self::getCurrentWorkingDay();
    }

    /**
     * @return Carbon $currentFakturaDate
     */
    public static function getCurrentFakturaDate() : Carbon
    {
        return self::$currentFakturaDate;
    }

    /**
     * @return Carbon $previousFakturaDate
     */
    public static function getPreviousFakturaDate() : Carbon
    {
        return self::$previousFakturaDate;
    }

    /**
     * @return int $currentWorkingDayNumber
     */
    public static function getCurrentWorkingDayIndex() : int
    {
        return self::$currentWorkingDayIndex;
    }

    /**
     * Get the sequence number (index) of the current working day in the current month
     * @param Carbon|null $date
     * @return int
     * @throws \Exception
     */
    public static function getCurrentWorkingDay(?Carbon $date = null) : int
    {
        if ($date) {
            $currentDate = $date;
        } else {
            $currentDate = Carbon::now();
        }
        $startOfMonth = $date ? $date->copy()->startOfMonth() : Carbon::now()->startOfMonth();
        $holidays = self::getHolidays($currentDate->year);

        $count = 0;
        while (!$startOfMonth->gt($currentDate)) {
            if (!$startOfMonth->isWeekend() && !in_array($startOfMonth->format('d.m.Y'), $holidays)) {
                $count++;
            }
            $startOfMonth->addDay();
        }

        return $count;
    }

    /**
     * Get the Faktura date relative to the current date
     * @param int $workingDayIndex
     * @param Carbon|null $relativeDate - the starting point date for faktura date calculation
     * @return Carbon - faktura date with OFFER_FAKTURAZEIT time
     * @throws \Exception
     */
    public static function getFakturaDate(int $workingDayIndex = 0, Carbon $relativeDate = null) : Carbon
    {
        $workingDayIndex = $workingDayIndex === 0 ? (int) config('dbconfig.faktura.OFFER_FAKTURATAG') : $workingDayIndex;
        $fakturaTime = config('dbconfig.faktura.OFFER_FAKTURAZEIT', '23:15');
        $relativeDate = is_null($relativeDate) ? Carbon::now() : $relativeDate;

        $fakturaDate = self::getWorkingDayDate($workingDayIndex, $relativeDate->month, $relativeDate->year)
            ->setTimeFromTimeString($fakturaTime);
        // if today date is more than {$workingDayIndex} working day of {$month} than we calculate fakturaDate for {$month+1}
        if ($relativeDate->gt($fakturaDate) || $relativeDate->eq($fakturaDate)) {
            $relativeDate = $relativeDate->addMonthNoOverflow()->startOfMonth();
            $fakturaDate = self::getFakturaDate($workingDayIndex, $relativeDate);
        }

        return $fakturaDate;
    }

    /**
     * Get the current faktura month
     * @return int
     */
    public static function getCurrentFakturaMonth(): int
    {
        $fakturaCopy = self::$currentFakturaDate->copy();
        // we decrement month because faktura date for current billing month
        // settled in the 3rd working day of the next month. So if we have faktura date
        // 3.09.21 we are basically in august faktura month, not september
        return $fakturaCopy->subMonthNoOverflow()->month;
    }

    /**
     * Get the current faktura year
     * @return int
     */
    public static function getCurrentFakturaYear(): int
    {
        $fakturaCopy = self::$currentFakturaDate->copy();
        // we decrement month because faktura date for current billing month
        // settled in the 3rd working day of the next month. So if we have faktura date
        // 3.09.21 we are basically in august faktura month, not september
        return $fakturaCopy->subMonthNoOverflow()->year;
    }

    /**
     * Get the date of {$index}-th working day of the specific $month and $year
     * @param int $index - the sequence number of working day
     * @param int $month
     * @param int $year
     * @return Carbon
     * @throws \Exception
     */
    public static function getWorkingDayDate(int $index, int $month, int $year) : Carbon
    {
        $date = Carbon::create($year, $month, 1);
        $holidays = self::getHolidays($year);

        $count = 0;
        while ($index !== $count) {
            // if date is not weekend or holiday -> increment count
            if (!$date->isWeekend() && !in_array($date->format('d.m.Y'), $holidays)) {
                $count++;
                if ($index === $count) {
                    break;
                }
            }
            $date->addDay();
        }

        return $date;
    }

    /**
     * Get number of working days between two dates
     * @param Carbon $start
     * @param Carbon $end
     * @return int
     * @throws \Exception
     */
    public static function getWorkingDaysBetween(Carbon $start, Carbon $end) : int
    {
        $start->setTime(0, 0, 0);
        $end->setTime(0, 0, 0);

        if ($start->gt($end)) {
            throw new \Exception('Start is greater then end');
        }

        $holidays = [];
        if ($start->year < $end->year) {
            for ($year = $start->year; $year <= $end->year; $year++) {
                $holidays = array_merge($holidays, self::getHolidays($year));
            }
        } else {
            $holidays = self::getHolidays($start->year);
        }

        $count = 0;
        $startBackup = clone $start;
        while (!$start->gt($end)) {
            if (!$start->isWeekend() &&
                !in_array($start->format('d.m.Y'), $holidays) &&
                !$start->eq($startBackup) &&
                !$start->eq($end)
            ) {
                $count++;
            }
            $start->addDay();
        }

        return $count;
    }

    /**
     * Calculate the working date with sum or subtraction
     * @param Carbon $date - initial date
     * @param string $operator - '+' or '-'
     * @param int $days - the number of days to sum or subtract
     * @return Carbon
     * @throws \Exception - throws when operator argument is invalid
     */
    public static function getCalculatedWorkingDay(Carbon $date, string $operator, int $days) : Carbon
    {
        $holidays = self::getHolidays($date->year);

        while ($days > 0) {
            if ($operator === '+') {
                $date->addDay();
            } elseif ($operator === '-') {
                $date->subDay();
            } else {
                throw new \Exception('The invalid $operator argument');
            }

            // if year is changed than we get holidays for that year
            if (($date->month === 1 && $date->day === 1) || ($date->month === 12 && $date->day === 31)) {
                $holidays = array_merge($holidays, self::getHolidays($date->year));
            }

            if (!$date->isWeekend() && !in_array($date->format('d.m.Y'), $holidays)) {
                $days--;
            }
        }

        return $date;
    }

    /**
     * Get the ultimo date (last working day of a month)
     * of certain year and month or get the ultimo-{$subtract}
     * @param int $year
     * @param int $month
     * @param int $subtract
     * @return Carbon
     * @throws \Exception
     */
    public static function getUltimo(int $year = 0, int $month = 0, int $subtract = 0) : Carbon
    {
        $year = $year === 0 ? Carbon::now()->year : $year;
        $month = $month === 0 ? Carbon::now()->month : $month;
        $lastDayOfMonth = Carbon::create($year, $month, 1)->endOfMonth()->setTime(0,0,0);

        $holidays = self::getHolidays($year);

        $lastWorkingDayOfMonth = null;
        while (is_null($lastWorkingDayOfMonth)) {
            if (!$lastDayOfMonth->isWeekend() && !in_array($lastDayOfMonth->format('d.m.Y'), $holidays)) {
                $lastWorkingDayOfMonth = $lastDayOfMonth->copy();
                break;
            }
            $lastDayOfMonth->subDay();
        }

        while ($subtract > 0) {
            $lastWorkingDayOfMonth->subDay();
            if (!$lastWorkingDayOfMonth->isWeekend() && !in_array($lastWorkingDayOfMonth->format('d.m.Y'), $holidays)) {
                $subtract--;
            }
        }

        return $lastWorkingDayOfMonth;
    }

    /**
     * Returns the value of X in the "U-{X}" expression
     * @param int $year
     * @param int $month
     * @param int $day
     * @return int
     * @throws \Exception
     */
    public static function getCurrentUltimoIndex(int $year = 0, int $month = 0, int $day = 0): int
    {
        $year = $year === 0 ? Carbon::now()->year : $year;
        $month = $month === 0 ? Carbon::now()->month : $month;
        $lastDayOfMonth = Carbon::create($year, $month, 1)->endOfMonth()->setTime(0,0,0);

        $holidays = self::getHolidays($year);

        $lastWorkingDayOfMonth = null;
        while (is_null($lastWorkingDayOfMonth)) {
            if (!$lastDayOfMonth->isWeekend() && !in_array($lastDayOfMonth->format('d.m.Y'), $holidays)) {
                $lastWorkingDayOfMonth = $lastDayOfMonth->copy();
                break;
            }
            $lastDayOfMonth->subDay();
        }

        $index = 0;
        $comparingDate = $day ? Carbon::create($year, $month, $day) : Carbon::now();
        $comparingDate->setTime(0, 0, 0);

        while (!$lastWorkingDayOfMonth->eq($comparingDate) && $comparingDate->lt($lastWorkingDayOfMonth)) {
            $lastWorkingDayOfMonth->subDay();
            if (!$lastWorkingDayOfMonth->isWeekend() && !in_array($lastWorkingDayOfMonth->format('d.m.Y'), $holidays)) {
                $index++;
            }
        }

        return $index;
    }

    /**
     * Get the date when the next billing process will be fired
     * @param string $frequencyPattern - e.g. 'monthly_U-7', 'monthly_3AT', 'hourly'
     * @return Carbon|null - date if matched any pattern, null otherwise
     */
    public static function getNextBillingDate(string $frequencyPattern) : ?Carbon
    {
        $currentDate = Carbon::now();
        $monthlyU  = Regex::match('/_U-(\d+)$/', $frequencyPattern);
        $monthlyAT = Regex::match('/_(\d+)AT$/', $frequencyPattern);

        try {
            if ($frequencyPattern === 'hourly') {
                $currentMinutes = Carbon::now()->format('i');
                if ($currentMinutes <= 55) {
                    return Carbon::now()->setMinutes(55);
                } else {
                    return Carbon::now()->addHour()->setMinutes(55);
                }
            } elseif ($monthlyAT->hasMatch()) { // match 'monthly_{x}AT pattern
                $days = $monthlyAT->group(1);
                return self::getFakturaDate($days);
            } elseif ($monthlyU->hasMatch()) { // match 'monthly_U-{x} pattern
                $days = $monthlyU->group(1);
                $ultimoDate = self::getUltimo($currentDate->year, $currentDate->month, $days)
                    ->setTimeFromTimeString(config('dbconfig.billing.ULTIMO_BOOKING_TIME'));
                if ($currentDate->gt($ultimoDate)) {
                    $nextMonthDate = $currentDate->copy()->addMonthNoOverflow()->startOfMonth();
                    return self::getUltimo($nextMonthDate->year, $nextMonthDate->month, $days)
                        ->setTimeFromTimeString(config('dbconfig.billing.ULTIMO_BOOKING_TIME'));
                } else {
                    return $ultimoDate;
                }
            }
        } catch (\Exception $e) {
            Log::error("Error occurred when calculating next billing date! " . $e->getMessage());
        }

        return null;
    }

    /**
     * The list of holidays for a specific year
     * @param int $year
     * @return array
     * @throws \Exception
     */
    public static function getHolidays(int $year) : array
    {
        $easterDate = self::easter_datetime($year)->getTimestamp();
        return [
            "Karfreitag $year"                 => Carbon::parse($easterDate)->subDays(2)->format('d.m.Y'),
            "Ostermontag $year"                => Carbon::parse($easterDate)->addDay()->format('d.m.Y'),
            "Christi Himmelfahrt $year"        => Carbon::parse($easterDate)->addDays(39)->format('d.m.Y'),
            "Pfingstmontag $year"              => Carbon::parse($easterDate)->addDays(50)->format('d.m.Y'),
            "Fronleichnam $year"               => Carbon::parse($easterDate)->addDays(60)->format('d.m.Y'),
            "Neujahr $year"                    => "01.01.$year",
            "Maifeiertag $year"                => "01.05.$year",
            "Tag der Deutschen Einheit $year"  => "03.10.$year",
            "Allerheiligen $year"              => "01.11.$year",
            "Erster Weihnachtsfeiertag $year"  => "25.12.$year",
            "Zweiter Weihnachtsfeiertag $year" => "26.12.$year",
        ];
    }

    /**
     * Get correct easter date
     * @param $year
     * @return DateTime
     * @throws \Exception
     */
    public static function easter_datetime($year) {
        $base = new DateTime("$year-03-21", new \DateTimeZone('UTC'));
        $days = easter_days($year);
        return $base->add(new DateInterval("P{$days}D"));
    }

    /**
     * @param bool $isHardBilling
     * @return bool
     * @throws \Exception
     */
    public static function checkMarchRuleForBilling(bool $isHardBilling): bool
    {
        $currentFakturaJahr = self::getCurrentFakturaYear();
        $now = Carbon::now();
        $month = config('dbconfig.calendar.MARCH_RULE_MONTH');

        if ($isHardBilling) {
            $ultimo = explode('-', config('dbconfig.calendar.MARCH_RULE_DATE_HB'))[1];
            $time = config('dbconfig.calendar.MARCH_RULE_TIME_HB');
            $date = self::getUltimo($currentFakturaJahr, $month, $ultimo);
        } else {
            $workingDay = substr(config('dbconfig.calendar.MARCH_RULE_DATE_CB'), 2);
            $time = config('dbconfig.calendar.MARCH_RULE_TIME_CB');
            $date = self::getWorkingDayDate($workingDay, $month, $currentFakturaJahr);
        }

        $time = explode(':', $time);

        $mrz = $date->setTime($time[0], $time[1], $time[2]);

        return $now->getTimestamp() <= $mrz->getTimestamp();
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public static function checkMarchRuleForCosts(): bool
    {
        $ultimo = explode('-', config('dbconfig.calendar.MARCH_RULE_DATE_COSTS'))[1];
        $time = explode(':', config('dbconfig.calendar.MARCH_RULE_TIME_COSTS'));
        $month = config('dbconfig.calendar.MARCH_RULE_MONTH');

        $now = Carbon::now()->getTimestamp();
        $currentFakturaJahr = self::getCurrentFakturaYear();

        $mrz = self::getUltimo($currentFakturaJahr, $month, $ultimo)
            ->setTime($time[0], $time[1], $time[2])
            ->getTimestamp();

        return $now <= $mrz;
    }

    /**
     * Get months dates between specific dates
     * @param Carbon|null $to
     * @param Carbon|null $from
     * @param string $format
     * @param bool $withMarchRule
     * @param bool $isHardBilling
     * @return array
     * @throws \Exception
     */
    public static function getMonthsDates(
        Carbon $to = null,
        Carbon $from = null,
        string $format = 'd-m-Y',
        bool $withMarchRule = false,
        bool $isHardBilling = false
    ): array
    {
        $from = !$from ? Carbon::now() : $from;
        $to   = !$to ? Carbon::now()->setMonth(12)->setDay(1) : $to;

        if ($withMarchRule) {
            $from = Carbon::now();
            if (self::checkMarchRuleForBilling($isHardBilling)) {
                $from = $from->subYear()->setMonth(1)->setDay(1);
            } else {
                $from = $from->setMonth(1)->setDay(1);
            }
            $to = Carbon::now()->setMonth(12)->setDay(1);
        }

        $result = [];
        while (!$from->gt($to)) {
            $result[] = $from->format($format);
            $from->addMonthNoOverflow();
        }
        $from->startOfYear();

        return $result;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public static function isTodayNotWorkDay(): bool
    {
        $today = Carbon::today();

        return $today->isSaturday() || $today->isSunday() || self::isHoliday($today);
    }

    /**
     * @param Carbon $date
     * @return bool
     * @throws \Exception
     */
    public static function isHoliday(Carbon $date): bool
    {
        return in_array($date->format('d.m.Y'), self::getHolidays($date->year));
    }
}
