<?php

namespace App\Domain\Dictionaries;

class LogChannelsDictionary
{
    public const FAKTURAPLAN_JOB_CHANNEL = 'fakturaplan_job';
    public const SAP_BILLING_REGULAR_JOB_CHANNEL = 'sap_billing';
    public const AUTO_BILL_JOB_CHANNEL = 'auto_bill';
    public const COMPETENCE_DEMANDS_JOB_CHANNEL = 'competence_demands';
    public const AUTO_ILV_JOB_CHANNEL = 'auto_ilv';
    public const PLAN_ILV_JOB_CHANNEL = 'plan_ilv';
    public const PRESUMABLY_ACCOUNTED_LBU_CHANNEL = 'presumably_accounted_lbu';
    public const EBI_MASS_IMPORT_CHANNEL = 'ebi_mass_import';
    public const AKP_IMPORT_CHANNEL = 'akp_import';
    public const AUTOMAIL_CHANNEL = 'automail';
    public const UPDATE_CRM_DATA = 'update_crm_data';
    public const CALC_CONFIGURATION_ITEMS = 'calc_configuration_items';
}
