<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaRabattierung
 *
 * @ORM\Table(name="Offer_Faktura_Rabattierung")
 * @ORM\Entity
 */
class OfferFakturaRabattierung
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\OneToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private OfferAuftrag $simple;

    /** @ORM\Column(name="gmkz_alt", type="decimal", precision=7, scale=4, nullable=true) */
    private ?string $gmkzAlt;

    /** @ORM\Column(name="gmkz_neu", type="decimal", precision=7, scale=4, nullable=true) */
    private ?string $gmkzNeu;

    /** @ORM\Column(name="preisnachlass", type="decimal", precision=18, scale=7, nullable=true) */
    private ?string $preisnachlass;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private \DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaRabattierungRabattoption")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="rabattoption_id", referencedColumnName="rabattoption_id")
     * })
     */
    private OfferFakturaRabattierungRabattoption $rabattoption;

    /** @ORM\Column(name="discount_totals", type="boolean", nullable=true) */
    private ?bool $discountTotals = null;

    /**
     * @return string|null
     */
    public function getGmkzAlt(): ?string
    {
        return $this->gmkzAlt;
    }

    /**
     * @param string|null $gmkzAlt
     */
    public function setGmkzAlt(?string $gmkzAlt): void
    {
        $this->gmkzAlt = $gmkzAlt;
    }

    /**
     * @return string|null
     */
    public function getGmkzNeu(): ?string
    {
        return $this->gmkzNeu;
    }

    /**
     * @param string|null $gmkzNeu
     */
    public function setGmkzNeu(?string $gmkzNeu): void
    {
        $this->gmkzNeu = $gmkzNeu;
    }

    /**
     * @return string|null
     */
    public function getPreisnachlass(): ?string
    {
        return $this->preisnachlass;
    }

    /**
     * @param string|null $preisnachlass
     */
    public function setPreisnachlass(?string $preisnachlass): void
    {
        $this->preisnachlass = $preisnachlass;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @return OfferAuftrag
     */
    public function getSimple(): OfferAuftrag
    {
        return $this->simple;
    }

    /**
     * @param OfferAuftrag|object $simple
     */
    public function setSimple(OfferAuftrag $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferFakturaRabattierungRabattoption
     */
    public function getRabattoption(): OfferFakturaRabattierungRabattoption
    {
        return $this->rabattoption;
    }

    /**
     * @param OfferFakturaRabattierungRabattoption|object $rabattoption
     */
    public function setRabattoption(OfferFakturaRabattierungRabattoption $rabattoption): void
    {
        $this->rabattoption = $rabattoption;
    }

    /**
     * @return bool|null
     */
    public function getDiscountTotals(): ?bool
    {
        return $this->discountTotals;
    }

    /**
     * @param bool|null $discountTotals
     */
    public function setDiscountTotals(?bool $discountTotals): void
    {
        $this->discountTotals = $discountTotals;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }
}
