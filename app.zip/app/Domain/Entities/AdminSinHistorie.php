<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * AdminSinHistorie
 *
 * @ORM\Table(name="Admin_SIN_Historie")
 * @ORM\Entity
 */
class AdminSinHistorie
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="aktion", type="string", length=50, nullable=true)
     */
    private $aktion;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkung", type="string", length=250, nullable=true)
     */
    private $bemerkung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="added", type="datetime", nullable=false)
     */
    private $added;

    /**
     * @var string|null
     *
     * @ORM\Column(name="debug_info", type="text", length=16, nullable=true)
     */
    private $debugInfo;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \GlobalGate
     *
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;


}
