<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesVerkaufsstufen
 *
 * @ORM\Table(name="Sales_Verkaufsstufen")
 * @ORM\Entity
 */
class SalesVerkaufsstufen
{
    /**
     * @var int
     *
     * @ORM\Column(name="verkaufsstufen_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $verkaufsstufenId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=80, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abkuerzung", type="string", length=20, nullable=true)
     */
    private $abkuerzung;

    /**
     * @var int|null
     *
     * @ORM\Column(name="auftrw_empfehlung", type="smallint", nullable=true)
     */
    private $auftrwEmpfehlung;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="smallint", nullable=false)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
