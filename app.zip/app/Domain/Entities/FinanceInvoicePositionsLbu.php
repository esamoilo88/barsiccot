<?php

namespace App\Domain\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="Finance_Invoice_Positions_LBU")
 */
class FinanceInvoicePositionsLbu
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\OneToOne(targetEntity="FinanceInvoicePositions")
     * @ORM\JoinColumn(name="position_id", referencedColumnName="id")
     */
    private FinanceInvoicePositions $position;

    /**
     * @var int
     * @ORM\Column(type="integer")
     */
    private int $lbuId;

    /**
     * @ORM\OneToOne(targetEntity="OfferFakturaLbu")
     * @ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id")
     */
    private OfferFakturaLbu $lbu;

    /**
     * FinanceInvoicePositionsLbu constructor.
     * @param FinanceInvoicePositions $position
     * @param OfferFakturaLbu|object $lbu
     */
    public function __construct(FinanceInvoicePositions $position, OfferFakturaLbu $lbu)
    {
        $this->position = $position;
        $this->lbu = $lbu;
    }

    /**
     * @return FinanceInvoicePositions
     */
    public function getPosition(): FinanceInvoicePositions
    {
        return $this->position;
    }

    /**
     * @param FinanceInvoicePositions $position
     */
    public function setPosition(FinanceInvoicePositions $position): void
    {
        $this->position = $position;
    }

    /**
     * @return OfferFakturaLbu
     */
    public function getLbu(): OfferFakturaLbu
    {
        return $this->lbu;
    }

    /**
     * @param OfferFakturaLbu $lbu
     */
    public function setLbu(OfferFakturaLbu $lbu): void
    {
        $this->lbu = $lbu;
    }

}
