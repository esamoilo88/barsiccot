<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendDatum
 *
 * @ORM\Table(name="Backend_Datum")
 * @ORM\Entity
 */
class BackendDatum
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="datum", type="date", nullable=false)
     */
    private $datum;

    /**
     * @var int|null
     *
     * @ORM\Column(name="arbeitstag_im_monat", type="integer", nullable=true)
     */
    private $arbeitstagImMonat;


}
