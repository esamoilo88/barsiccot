<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * CostsKosten
 *
 * @ORM\Table(name="Costs_Kosten")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsKosten
{
    /**
     * @ORM\Column(name="kosten_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $kostenId;

    /**
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="kostenplan_id", type="integer", nullable=true)
     */
    private ?int $kostenplanId;

    /**
     * @ORM\Column(name="kostenart_id", type="integer", nullable=false)
     */
    private int $kostenartId;

    /**
     * @ORM\Column(name="kosten_jahr", type="smallint", nullable=false)
     */
    private int $kostenJahr;

    /**
     * @ORM\Column(name="kosten_monat", type="smallint", nullable=false)
     */
    private int $kostenMonat;

    /**
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $stundensatz;

    /**
     * @ORM\Column(name="wert", type="decimal", precision=26, scale=16, nullable=false)
     */
    private float $wert;

    /**
     * @ORM\Column(name="actual_value", type="decimal", precision=26, scale=16, nullable=true)
     */
    private ?float $actualValue;

    /**
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private ?string $bemerkungen;

    /**
     * @ORM\Column(name="lbu_leistungs_monat", type="string", length=10, nullable=true)
     */
    private ?string $lbuLeistungsMonat;

    /**
     * @ORM\Column(name="lbu_faktura_monat", type="string", length=10, nullable=true)
     */
    private ?string $lbuFakturaMonat;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private ?int $ofiLa;

    /**
     * @ORM\Column(name="receiver_kostenstelle_id", type="integer", nullable=true)
     */
    private ?int $receiverKostenstelleId;

    /**
     * @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $stundensatzAlternativ;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id", nullable=true)
     */
    private ?CostsKostenstelle $kostenstelle;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="receiver_kostenstelle_id", referencedColumnName="kostenstelle_id", nullable=true)
     */
    private ?CostsKostenstelle $receiverKostenstelle = null;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenart;

    /**
     * @ORM\Column(name="ilv_valid", type="boolean", nullable=true)
     */
    private ?bool $ilvValid;

    /**
     * @ORM\Column(name="locked", type="boolean", nullable=true)
     */
    private ?bool $locked;

    /**
     * @ORM\Column(name="automated", type="boolean", nullable=true)
     */
    private ?bool $automated;

    /**
     * @ORM\Column(name="psp_element", type="string", nullable=true)
     */
    private ?string $pspElement;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $benutzer = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenQuellsystem")
     * @ORM\JoinColumn(name="quellsystem_id", referencedColumnName="quellsystem_id")
     */
    private ?OfferFakturaLbuDatenQuellsystem $quellsystem = null;

    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @param CostsKostenart $kostenart
     */
    public function setKostenart(CostsKostenart $kostenart): void
    {
        $this->kostenart = $kostenart;
    }

    /**
     * @param float $stundensatz
     */
    public function setStundensatz(float $stundensatz): void
    {
        $this->stundensatz = $stundensatz;
    }

    /**
     * @param float|null $stundensatzAlternativ
     */
    public function setStundensatzAlternativ(?float $stundensatzAlternativ): void
    {
        $this->stundensatzAlternativ = $stundensatzAlternativ;
    }

    /**
     * @param int $kostenJahr
     */
    public function setKostenJahr(int $kostenJahr): void
    {
        $this->kostenJahr = $kostenJahr;
    }

    /**
     * @param int $kostenMonat
     */
    public function setKostenMonat(int $kostenMonat): void
    {
        $this->kostenMonat = $kostenMonat;
    }

    /**
     * @param int|null $ofiLa
     */
    public function setOfiLa(?int $ofiLa): void
    {
        $this->ofiLa = $ofiLa;
    }

    /**
     * @param CostsKostenstelle|null $kostenstelle
     */
    public function setKostenstelle(?CostsKostenstelle $kostenstelle): void
    {
        $this->kostenstelle = $kostenstelle;
    }

    /**
     * @param CostsKostenstelle|null $receiverKostenstelle
     */
    public function setReceiverKostenstelle(?CostsKostenstelle $receiverKostenstelle): void
    {
        $this->receiverKostenstelle = $receiverKostenstelle;
    }

    /**
     * @param float $wert
     */
    public function setWert(float $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @param float|null $actualValue
     */
    public function setActualValue(?float $actualValue): void
    {
        $this->actualValue = $actualValue;
    }

    /**
     * @param string|null $pspElement
     */
    public function setPspElement(?string $pspElement): void
    {
        $this->pspElement = $pspElement;
    }

    /**
     * @param BackendBenutzer|null $benutzer
     */
    public function setBenutzer(?BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param bool|null $locked
     */
    public function setLocked(?bool $locked): void
    {
        $this->locked = $locked;
    }

    /**
     * @param bool|null $automated
     */
    public function setAutomated(?bool $automated): void
    {
        $this->automated = $automated;
    }

    /**
     * @param bool|null $ilvValid
     */
    public function setIlvValid(?bool $ilvValid): void
    {
        $this->ilvValid = $ilvValid;
    }

    /**
     * @param string|null $bemerkungen
     */
    public function setBemerkungen(?string $bemerkungen): void
    {
        $this->bemerkungen = $bemerkungen;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return CostsKostenstelle|null
     */
    public function getReceiverKostenstelle(): ?CostsKostenstelle
    {
        return $this->receiverKostenstelle;
    }

    /**
     * @param OfferFakturaLbuDatenQuellsystem|null $quellsystem
     */
    public function setQuellsystem(?OfferFakturaLbuDatenQuellsystem $quellsystem): void
    {
        $this->quellsystem = $quellsystem;
    }

    /**
     * @return int
     */
    public function getKostenId(): int
    {
        return $this->kostenId;
    }

    /**
     * @return CostsKostenart
     */
    public function getKostenart(): CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return int
     */
    public function getKostenMonat(): int
    {
        return $this->kostenMonat;
    }

    /**
     * @return float|null
     */
    public function getStundensatzAlternativ(): ?float
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @return CostsKostenstelle|null
     */
    public function getKostenstelle(): ?CostsKostenstelle
    {
        return $this->kostenstelle;
    }

    /**
     * @return float
     */
    public function getWert(): float
    {
        return $this->wert;
    }

    /**
     * @return DateTime
     */
    public function getJahrMonat(): DateTime
    {
        return new DateTime("{$this->kostenJahr}-{$this->kostenMonat}-01");
    }

    /**
     * @return OfferFakturaLbuDatenQuellsystem|null
     */
    public function getQuellsystem(): ?OfferFakturaLbuDatenQuellsystem
    {
        return $this->quellsystem;
    }

    /**
     * @return float|null
     */
    public function getActualValue(): ?float
    {
        return $this->actualValue;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }
}
