<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class FinanceOrderPosition
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Finance_Order_Position")
 */
class FinanceOrderPosition
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="angebotsposition_id")
     */
    private OfferKalkulationAngebotsposition $angebotsposition;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceOrder")
     * @ORM\JoinColumn(name="order_id", referencedColumnName="id")
     */
    private FinanceOrder $financeOrder;

    /** @ORM\Column(name="icp_kont_bpos", type="integer") */
    private int $icpKontBpos;

    /** @ORM\Column(name="angebotsposition_id", type="integer") */
    private int $angebotspositionId;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * FinanceOrderPosition constructor.
     * @param OfferKalkulationAngebotsposition $angebotsposition
     * @param FinanceOrder $financeOrder
     * @param int $icpKontBpos
     */
    public function __construct(OfferKalkulationAngebotsposition $angebotsposition, FinanceOrder $financeOrder, int $icpKontBpos)
    {
        $this->angebotsposition = $angebotsposition;
        $this->financeOrder = $financeOrder;
        $this->icpKontBpos = $icpKontBpos;
        $this->angebotspositionId = $angebotsposition->getAngebotspositionId();
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"mapping"})
     * @return OfferKalkulationAngebotsposition
     */
    public function getAngebotsposition(): OfferKalkulationAngebotsposition
    {
        return $this->angebotsposition;
    }

    /**
     * @Groups({"mapping"})
     * @return FinanceOrder
     */
    public function getFinanceOrder(): FinanceOrder
    {
        return $this->financeOrder;
    }

    /**
     * @Groups({"mapping"})
     * @return int
     */
    public function getIcpKontBpos(): int
    {
        return $this->icpKontBpos;
    }


    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param int $icpKontBpos
     */
    public function setIcpKontBpos(int $icpKontBpos): void
    {
        $this->icpKontBpos = $icpKontBpos;
    }
}
