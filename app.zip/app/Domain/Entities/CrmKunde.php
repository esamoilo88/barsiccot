<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * CrmKunde
 *
 * @ORM\Table(name="CRM_Kunde", uniqueConstraints={@ORM\UniqueConstraint(name="UC_CRM_Kunde", columns={"DTAG_kdnr"}), @ORM\UniqueConstraint(name="ui_crm_kunde_id", columns={"kunde_id"})})
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CrmKunde
{
    /**
     * @var int
     *
     * @ORM\Column(name="kunde_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $kundeId;

    /**
     * @var int
     *
     * @ORM\Column(name="DTAG_kdnr", type="bigint", nullable=false)
     */
    private $dtagKdnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_name_lang", type="text", length=-1, nullable=true)
     */
    private $dtagNameLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_plz", type="text", length=-1, nullable=true)
     */
    private $dtagPlz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_ort", type="text", length=-1, nullable=true)
     */
    private $dtagOrt;

    /**
     * @var bool
     *
     * @ORM\Column(name="is_active", type="boolean", nullable=false)
     */
    private $isActive;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @ORM\Column(name="gp_nr", type="bigint", nullable=false)
     */
    private $gpNr;

    /** @ORM\OneToOne(targetEntity="CrmCustomer", mappedBy="crmKunde") */
    private ?CrmCustomer $crmCustomer = null;

    /**
     * @return int
     */
    public function getDtagKdnr(): int
    {
        return $this->dtagKdnr;
    }

    /**
     * @return string|null
     */
    public function getDtagNameLang(): ?string
    {
        return $this->dtagNameLang;
    }

    /**
     * @return string|null
     */
    public function getDtagPlz(): ?string
    {
        return $this->dtagPlz;
    }

    /**
     * @return string|null
     */
    public function getDtagOrt(): ?string
    {
        return $this->dtagOrt;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->isActive;
    }
}
