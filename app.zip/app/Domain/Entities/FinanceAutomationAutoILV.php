<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class FinanceAutomationAutoILV
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Finance_Automation_Auto_ILV")
 */
class FinanceAutomationAutoILV
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $offerAuftrag;

    /** @ORM\Column(name="jahr", type="integer") */
    private int $jahr;

    /** @ORM\Column(name="monat", type="integer") */
    private int $monat;

    /** @ORM\Column(name="create_at", type="string") */
    private string $createAt;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * FinanceAutomationAutoILV constructor.
     * @param OfferAuftrag $offerAuftrag
     * @param int $jahr
     * @param int $monat
     * @param string $createAt
     */
    public function __construct(OfferAuftrag $offerAuftrag, int $jahr, int $monat, string $createAt)
    {
        $this->offerAuftrag = $offerAuftrag;
        $this->jahr = $jahr;
        $this->monat = $monat;
        $this->createAt = $createAt;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @return OfferAuftrag
     */
    public function getOfferAuftrag(): OfferAuftrag
    {
        return $this->offerAuftrag;
    }

    /**
     * @return int
     */
    public function getJahr(): int
    {
        return $this->jahr;
    }

    /**
     * @return int
     */
    public function getMonat(): int
    {
        return $this->monat;
    }

    /**
     * @return string
     */
    public function getCreateAt(): string
    {
        return $this->createAt;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
