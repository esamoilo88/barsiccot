<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity
 * @ORM\Table(name="Finance_Invoice_Positions")
 */
class FinanceInvoicePositions
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="unit_price", type="decimal") */
    private float $unitPrice;

    /** @ORM\Column(name="quantity", type="decimal") */
    private float $quantity;

    /** @ORM\Column(name="short_text", type="string", length=40, nullable=true) */
    private ?string $shortText = null;

    /** @ORM\Column(name="long_text", type="string", length=600, nullable=true) */
    private ?string $longText = null;

    /** @ORM\Column(name="icp_kont_psp_kst", type="string", length=40, nullable=true) */
    private ?string $icpKontPspKst = null;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private ?DateTime $modified = null;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceInvoice")
     * @ORM\JoinColumn(name="invoice_id", referencedColumnName="id")
     */
    private FinanceInvoice $invoice;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id", nullable=true)
     */
    private ?OfferAuftrag $auftrag;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaMaterialnummer")
     * @ORM\JoinColumn(name="mat_nr_id", referencedColumnName="mat_nr_id", nullable=true)
     */
    private ?OfferFakturaMaterialnummer $matNr;

    /**
     * @ORM\ManyToOne(targetEntity="FinancePsp")
     * @ORM\JoinColumn(name="psp_element_id", referencedColumnName="id", nullable=true)
     */
    private ?FinancePsp $psp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenSachkonto")
     * @ORM\JoinColumn(name="icp_kont_konto_id", referencedColumnName="konto_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenSachkonto $sachkonto;

    /**
     * @ORM\ManyToMany(targetEntity="OfferFakturaLbu")
     * @ORM\JoinTable(name="Finance_Invoice_Positions_LBU",
     *      joinColumns={@ORM\JoinColumn(name="position_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id")}
     * )
     */
    private Collection $lbus;

    /**
     * FinanceInvoicePositions constructor.
     * @param float $unitPrice
     * @param float $quantity
     * @param FinanceInvoice $invoice
     */
    public function __construct(float $unitPrice, float $quantity, FinanceInvoice $invoice)
    {
        $this->unitPrice = $unitPrice;
        $this->quantity = $quantity;
        $this->invoice = $invoice;

        $this->lbus = new ArrayCollection();
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return float
     */
    public function getUnitPrice(): float
    {
        return $this->unitPrice;
    }

    /**
     * @param float $unitPrice
     */
    public function setUnitPrice(float $unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return float
     */
    public function getQuantity(): float
    {
        return $this->quantity;
    }

    /**
     * @param float $quantity
     */
    public function setQuantity(float $quantity): void
    {
        $this->quantity = $quantity;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getShortText(): ?string
    {
        return $this->shortText;
    }

    /**
     * @param string|null $shortText
     */
    public function setShortText(?string $shortText): void
    {
        $this->shortText = $shortText;
    }

    /**
     * @return string|null
     */
    public function getLongText(): ?string
    {
        return $this->longText;
    }

    /**
     * @param string|null $longText
     */
    public function setLongText(?string $longText): void
    {
        $this->longText = $longText;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @param string|null $icpKontPspKst
     */
    public function setIcpKontPspKst(?string $icpKontPspKst): void
    {
        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime|null
     */
    public function getModified(): ?DateTime
    {
        return $this->modified;
    }

    /**
     * @return FinanceInvoice
     */
    public function getInvoice(): FinanceInvoice
    {
        return $this->invoice;
    }

    /**
     * @param FinanceInvoice $invoice
     */
    public function setInvoice(FinanceInvoice $invoice): void
    {
        $this->invoice = $invoice;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return OfferAuftrag|null
     */
    public function getAuftrag(): ?OfferAuftrag
    {
        return $this->auftrag;
    }

    /**
     * @param OfferAuftrag|object|null $auftrag
     */
    public function setAuftrag(?OfferAuftrag $auftrag): void
    {
        $this->auftrag = $auftrag;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return OfferFakturaMaterialnummer|null
     */
    public function getMatNr(): ?OfferFakturaMaterialnummer
    {
        return $this->matNr;
    }

    /**
     * @param OfferFakturaMaterialnummer|object|null $matNr
     */
    public function setMatNr(?OfferFakturaMaterialnummer $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return FinancePsp|null
     */
    public function getPsp(): ?FinancePsp
    {
        return $this->psp;
    }

    /**
     * @param FinancePsp|object|null $psp
     */
    public function setPsp(?FinancePsp $psp): void
    {
        $this->psp = $psp;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return OfferFakturaLbuDatenSachkonto|null
     */
    public function getSachkonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->sachkonto;
    }

    /**
     * @param OfferFakturaLbuDatenSachkonto|object|null $sachkonto
     */
    public function setSachkonto(?OfferFakturaLbuDatenSachkonto $sachkonto): void
    {
        $this->sachkonto = $sachkonto;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return ArrayCollection|Collection
     */
    public function getLbus()
    {
        return $this->lbus;
    }

    /**
     * @param ArrayCollection|Collection $lbus
     */
    public function setLbus($lbus): void
    {
        $this->lbus = $lbus;
    }
}

