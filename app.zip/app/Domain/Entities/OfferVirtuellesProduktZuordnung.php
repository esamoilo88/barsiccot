<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferVirtuellesProduktZuordnung
 *
 * @ORM\Table(name="Offer_Virtuelles_Produkt_Zuordnung")
 * @ORM\Entity
 */
class OfferVirtuellesProduktZuordnung
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="vp_id", type="bigint", nullable=false)
     */
    private $vpId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="angebotsposition_id", type="bigint", nullable=true)
     */
    private $angebotspositionId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="leistungsposition_id", type="bigint", nullable=true)
     */
    private $leistungspositionId;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
