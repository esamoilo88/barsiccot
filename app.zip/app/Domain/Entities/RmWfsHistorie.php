<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmWfsHistorie
 *
 * @ORM\Table(name="RM_WFS_Historie")
 * @ORM\Entity
 */
class RmWfsHistorie
{
    /**
     * @var int
     *
     * @ORM\Column(name="wfs_historie_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $wfsHistorieId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \RmAnfrage
     *
     * @ORM\ManyToOne(targetEntity="RmAnfrage")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @var \RmWorkflowstatus
     *
     * @ORM\ManyToOne(targetEntity="RmWorkflowstatus")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="neue_workflowstatus_id", referencedColumnName="workflowstatus_id")
     * })
     */
    private $neueWorkflowstatus;


}
