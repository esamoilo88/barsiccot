<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKatalogFakturatyp
 *
 * @ORM\Table(name="Offer_Katalog_Fakturatyp")
 * @ORM\Entity
 */
class OfferKatalogFakturatyp
{
    /**
     * @var int
     *
     * @ORM\Column(name="fakturatyp_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $fakturatypId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @return int
     */
    public function getFakturatypId(): int
    {
        return $this->fakturatypId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param  string|null  $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param  string|null  $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @param  \DateTime|null  $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }
}
