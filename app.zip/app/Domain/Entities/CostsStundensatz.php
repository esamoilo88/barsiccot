<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * CostsStundensatz
 *
 * @ORM\Table(name="Costs_Stundensatz")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsStundensatz
{
    /**
     * @var int
     *
     * @ORM\Column(name="stundensatz_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $stundensatzId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="gueltig_von", type="datetime", nullable=false)
     */
    private $gueltigVon;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="gueltig_bis", type="datetime", nullable=true)
     */
    private $gueltigBis;

    /**
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2)
     */
    private float $stundensatz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="jahreskapazitaet", type="decimal", precision=10, scale=2, nullable=true)
     */
    private $jahreskapazitaet;

    /**
     * @ORM\Column(name="gmkz", type="decimal", precision=12, scale=6, nullable=true)
     */
    private ?float $gmkz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $stundensatzAlternativ;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var int|null
     *
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private ?int $ofiLa;

    /**
     * @var CostsKostenart
     *
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     * })
     */
    private $kostenart;

    /**
     * @ORM\Column(name="is_default", type="boolean", nullable=true)
     */
    private ?bool $isDefault;

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return int
     */
    public function getStundensatzId(): int
    {
        return $this->stundensatzId;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @return float|null
     */
    public function getGmkz(): ?float
    {
        return $this->gmkz;
    }

    /**
     * @return string|null
     */
    public function getStundensatzAlternativ(): ?string
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @return bool|null
     */
    public function getIsDefault(): ?bool
    {
        return $this->isDefault;
    }
}
