<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaBillingAbgrenzung
 *
 * @ORM\Table(name="Offer_Faktura_Billing_Abgrenzung")
 * @ORM\Entity
 */
class OfferFakturaBillingAbgrenzung
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="leistungs_jahr", type="integer", nullable=false)
     */
    private $leistungsJahr;

    /**
     * @var int
     *
     * @ORM\Column(name="leistungs_monat", type="integer", nullable=false)
     */
    private $leistungsMonat;

    /**
     * @var int|null
     *
     * @ORM\Column(name="faktura_jahr", type="integer", nullable=true)
     */
    private $fakturaJahr;

    /**
     * @var int|null
     *
     * @ORM\Column(name="faktura_monat", type="integer", nullable=true)
     */
    private $fakturaMonat;

    /**
     * @var string|null
     *
     * @ORM\Column(name="psp_element", type="string", length=200, nullable=true)
     */
    private $pspElement;

    /**
     * @var int
     *
     * @ORM\Column(name="value", type="integer", nullable=false)
     */
    private $value;

    /**
     * @var string|null
     *
     * @ORM\Column(name="base", type="string", length=200, nullable=true)
     */
    private $base;

    /**
     * @var string|null
     *
     * @ORM\Column(name="lbu_ids", type="text", length=-1, nullable=true)
     */
    private $lbuIds;

    /**
     * @var int
     *
     * @ORM\Column(name="mat_nr", type="integer", nullable=false)
     */
    private $matNr;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="exported", type="datetime", nullable=true)
     */
    private $exported;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="booking_period", type="datetime", nullable=true)
     */
    private $bookingPeriod;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_meldeart", type="string", length=200, nullable=true)
     */
    private $smartMeldeart;

    /**
     * @var int
     *
     * @ORM\Column(name="smart_konto", type="integer", nullable=false)
     */
    private $smartKonto;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_minderung", type="string", length=200, nullable=true)
     */
    private $smartMinderung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_buchungstext", type="string", length=200, nullable=true)
     */
    private $smartBuchungstext;

    /**
     * @var int
     *
     * @ORM\Column(name="smart_pgnr", type="integer", nullable=false)
     */
    private $smartPgnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_pgname", type="string", length=200, nullable=true)
     */
    private $smartPgname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_land", type="string", length=200, nullable=true)
     */
    private $smartLand;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_contact", type="string", length=200, nullable=true)
     */
    private $smartContact;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smart_bestellnummer_vertrag", type="string", length=200, nullable=true)
     */
    private $smartBestellnummerVertrag;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="valid_from", type="datetime", nullable=false)
     */
    private $validFrom;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="valid_to", type="datetime", nullable=false)
     */
    private $validTo;

    /**
     * @var \OfferAuftrag
     *
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
