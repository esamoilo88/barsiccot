<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendPreferences
 * read the documentation: https://seu30.gdc-bln03.t-systems.com/confluence/display/SIMPLE/User+Preferences
 *
 * @ORM\Table(name="Backend_Preferences")
 * @ORM\Entity
 */
class BackendPreferences
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="`group`", type="string", length=32, nullable=false) */
    private string $group;

    /** @ORM\Column(name="sys_name", type="string", length=32, nullable=false) */
    private string $sysName;

    /** @ORM\Column(name="name", type="string", length=64, nullable=false) */
    private string $name;

    /** @ORM\Column(name="subtext", type="string", length=1024, nullable=false) */
    private string $subtext;

    /** @ORM\Column(name="structure", type="string", length=-1, nullable=false) */
    private string $structure;

    /** @ORM\Column(name="value", type="string", length=128, nullable=true) */
    private ?string $value;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide = false;

    /**
     * @Groups({"userProfile"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * @param string $group
     */
    public function setGroup(string $group): void
    {
        $this->group = $group;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @param string $sysName
     */
    public function setSysName(string $sysName): void
    {
        $this->sysName = $sysName;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getSubtext(): string
    {
        return $this->subtext;
    }

    /**
     * @param string $subtext
     */
    public function setSubtext(string $subtext): void
    {
        $this->subtext = $subtext;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getStructure(): string
    {
        return $this->structure;
    }

    /**
     * @param string $structure
     */
    public function setStructure(string $structure): void
    {
        $this->structure = $structure;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getValue(): ?string
    {
        return $this->value;
    }

    /**
     * @param string|null $value
     */
    public function setValue(?string $value): void
    {
        $this->value = $value;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }
}
