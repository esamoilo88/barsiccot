<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;
use App\Domain\Annotations\SystemProtocol as SP;

/**
 * OfferKalkulationBerechnung
 *
 * @ORM\Table(name="Offer_Kalkulation_Berechnung")
 * @ORM\Entity
 * @ORM\EntityListeners({"App\Domain\Listeners\SystemProtocol\SystemProtocolListener"})
 * @SP(
 *   messages={
 *     "created"="Berechnung angelegt",
 *     "updated"="Berechnung bearbeitet",
 *     "removed"="Berechnung gelöscht"
 *   },
 *   group="BER"
 * )
 */
class OfferKalkulationBerechnung implements Loggable
{
    /**
     * @var int
     *
     * @ORM\Column(name="berechnung_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $berechnungId;

    /**
     * @var string|null
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="operator", type="string", length=1, nullable=true)
     */
    private $operator;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wert", type="decimal", precision=18, scale=10, nullable=true)
     */
    private $wert;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kommentar", type="text", length=-1, nullable=true)
     */
    private $kommentar;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationElement")
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id")
     */
    private ?OfferKalkulationElement $element = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private ?OfferKalkulationLeistungsposition $leistungsposition = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationVariable")
     * @ORM\JoinColumn(name="variable_id", referencedColumnName="variable_id")
     */
    private ?OfferKalkulationVariable $variable;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationBerechnung")
     * @ORM\JoinColumn(name="quell_berechnung_id", referencedColumnName="berechnung_id")
     */
    private ?OfferKalkulationBerechnung $quellBerechnung;

    /**
     * OfferKalkulationBerechnung constructor.
     * @param string $bezeichnung
     * @param string $operator
     * @param string $wert
     * @param string|null $kommentar
     * @param OfferKalkulationVariable|null $variable
     */
    public function __construct(
        string $bezeichnung,
        string $operator,
        string $wert,
        ?string $kommentar,
        ?OfferKalkulationVariable $variable = null
    )
    {
        $this->bezeichnung = $bezeichnung;
        $this->operator = $operator;
        $this->wert = $wert;
        $this->kommentar = $kommentar;
        $this->variable = $variable;
    }


    /**
     * @param OfferKalkulationElement|null $element
     */
    public function setElement(?OfferKalkulationElement $element): void
    {
        $this->element = $element;
    }

    /**
     * @param OfferKalkulationLeistungsposition|null $leistungsposition
     */
    public function setLeistungsposition(?OfferKalkulationLeistungsposition $leistungsposition): void
    {
        $this->leistungsposition = $leistungsposition;
    }

    /**
     * @return int
     */
    public function getBerechnungId(): int
    {
        return $this->berechnungId;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getOperator(): ?string
    {
        return $this->operator;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return OfferKalkulationElement|null
     */
    public function getElement(): ?OfferKalkulationElement
    {
        return $this->element;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getWert(): ?string
    {
        return $this->wert;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return OfferKalkulationVariable|null
     */
    public function getVariable(): ?OfferKalkulationVariable
    {
        return $this->variable;
    }

    /**
     * @param  OfferKalkulationVariable|null  $variable
     */
    public function setVariable(?OfferKalkulationVariable $variable): void
    {
        $this->variable = $variable;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param string|null $operator
     */
    public function setOperator(?string $operator): void
    {
        $this->operator = $operator;
    }

    /**
     * @param string|null $wert
     */
    public function setWert(?string $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @param string|null $kommentar
     */
    public function setKommentar(?string $kommentar): void
    {
        $this->kommentar = $kommentar;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return OfferKalkulationLeistungsposition|null
     */
    public function getLeistungsposition(): ?OfferKalkulationLeistungsposition
    {
        return $this->leistungsposition;
    }

    /**
     * @return OfferKalkulationBerechnung|null
     */
    public function getQuellBerechnung(): ?OfferKalkulationBerechnung
    {
        return $this->quellBerechnung;
    }

    /**
     * @param  OfferKalkulationBerechnung|null  $quellBerechnung
     */
    public function setQuellBerechnung(?OfferKalkulationBerechnung $quellBerechnung): void
    {
        $this->quellBerechnung = $quellBerechnung;
    }

    ////
    // SystemProtocol functions START
    ////

    /**
     * @return SIN
     * @throws InvalidSinException
     * @throws \Exception
     */
    public function getSin(): SIN
    {
        if ($this->getLeistungsposition()) {
            return new SIN($this->getLeistungsposition()->getSimple()->getSimpleId());
        } elseif ($this->getElement()) {
            return new SIN($this->getElement()->getLeistungsposition()->getSimple()->getSimpleId());
        } else {
            throw new \Exception("Couldn't get simple id");
        }
    }

    /**
     * @return string
     */
    public function getSystemProtocolObjectName(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSystemProtocolParentName(): ?string
    {
        if ($this->getLeistungsposition()) {
            return $this->getLeistungsposition()->getBezeichnung();
        } elseif ($this->getElement()) {
            return $this->getElement()->getBezeichnung();
        } else {
            return "";
        }
    }

    ////
    // SystemProtocol functions END
    ////
}
