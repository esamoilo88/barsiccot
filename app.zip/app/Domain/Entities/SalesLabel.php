<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesLabel
 *
 * @ORM\Table(name="Sales_Label")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class SalesLabel
{
    /**
     * @ORM\Column(name="label_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $labelId;

    /** @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="isIKSL", type="boolean", nullable=false) */
    private bool $isiksl;

    /** @ORM\Column(name="sort", type="integer", nullable=true) */
    private ?int $sort;

    /** @ORM\Column(name="abkuerzung", type="string", length=50, nullable=true) */
    private ?string $abkuerzung;

    /** @ORM\Column(name="gruppe", type="string", length=50, nullable=true) */
    private ?string $gruppe;

    /** @ORM\Column(name="admin_hide", type="boolean", nullable=false) */
    private bool $adminHide = false;

    /** @ORM\Column(name="billing_relevant", type="boolean", nullable=false) */
    private bool $billingRelevant = false;

    /** @ORM\Column(name="additional_info", type="string", length=50, nullable=true) */
    private ?string $additionalInfo;

    /**
     * @ORM\ManyToOne(targetEntity="SalesLabelKategorie")
     * @ORM\JoinColumn(name="label_kategorie_id", referencedColumnName="label_kategorie_id")
     */
    private SalesLabelKategorie $labelKategorie;

    /**
     * SalesLabel constructor.
     * @param string|null $bezeichnung
     */
    public function __construct(?string $bezeichnung)
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return int
     */
    public function getLabelId(): int
    {
        return $this->labelId;
    }

    /**
     * @param int $labelId
     */
    public function setLabelId(int $labelId): void
    {
        $this->labelId = $labelId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool
     */
    public function isIsiksl(): bool
    {
        return $this->isiksl;
    }

    /**
     * @param bool $isiksl
     */
    public function setIsiksl(bool $isiksl): void
    {
        $this->isiksl = $isiksl;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return string|null
     */
    public function getAbkuerzung(): ?string
    {
        return $this->abkuerzung;
    }

    /**
     * @param string|null $abkuerzung
     */
    public function setAbkuerzung(?string $abkuerzung): void
    {
        $this->abkuerzung = $abkuerzung;
    }

    /**
     * @return string|null
     */
    public function getGruppe(): ?string
    {
        return $this->gruppe;
    }

    /**
     * @param string|null $gruppe
     */
    public function setGruppe(?string $gruppe): void
    {
        $this->gruppe = $gruppe;
    }

    /**
     * @return bool
     */
    public function isAdminHide(): bool
    {
        return $this->adminHide;
    }

    /**
     * @param bool $adminHide
     */
    public function setAdminHide(bool $adminHide): void
    {
        $this->adminHide = $adminHide;
    }

    /**
     * @return bool
     */
    public function isBillingRelevant(): bool
    {
        return $this->billingRelevant;
    }

    /**
     * @param bool $billingRelevant
     */
    public function setBillingRelevant(bool $billingRelevant): void
    {
        $this->billingRelevant = $billingRelevant;
    }

    /**
     * @return SalesLabelKategorie
     */
    public function getLabelKategorie(): SalesLabelKategorie
    {
        return $this->labelKategorie;
    }

    /**
     * @param SalesLabelKategorie $labelKategorie
     */
    public function setLabelKategorie(SalesLabelKategorie $labelKategorie): void
    {
        $this->labelKategorie = $labelKategorie;
    }

    /**
     * @return string|null
     */
    public function getAdditionalInfo(): ?string
    {
        return $this->additionalInfo;
    }

    /**
     * @param string|null $additionalInfo
     */
    public function setAdditionalInfo(?string $additionalInfo): void
    {
        $this->additionalInfo = $additionalInfo;
    }
}
