<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferProfitcenterSettings
 *
 * @ORM\Table(name="Offer_Profitcenter_Settings")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferProfitcenterSettings
{
    /**
     * @ORM\Column(name="profitcenter_settings_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $profitcenterSettingsId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung = null;

    /** @ORM\Column(name="frequency", type="string", length=25, nullable=true) */
    private ?string $frequency = null;

    /** @ORM\Column(name="is_default", type="boolean", nullable=true) */
    private ?bool $isDefault;

    /** @ORM\Column(name="is_iksl", type="boolean", nullable=true) */
    private ?bool $isIksl = false;

    /** @ORM\Column(name="sap_interface_usage", type="boolean", nullable=true) */
    private ?bool $sapInterfaceUsage = null;

    /** @ORM\Column(name="billing_head_reference", type="string", length=12, nullable=true) */
    private ?string $billingHeadReference;

    /** @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true) */
    private ?string $icpKontPspKst = null;

    /** @ORM\Column(name="`external`", type="boolean", nullable=true) */
    private ?bool $external = null;

    /** @ORM\Column(name="allow_empty_ap", type="boolean", nullable=false) */
    private bool $allowEmptyAp = false;

    /** @ORM\Column(name="smart_interface_usage", type="boolean", nullable=true) */
    private ?bool $smartInterfaceUsage;

    /** @ORM\Column(name="smart_contact_email", type="string", length=200, nullable=true) */
    private ?string $smartContactEmail;

    /** @ORM\Column(name="smart_pg_name", type="string", length=200, nullable=true) */
    private ?string $smartPgName;

    /** @ORM\Column(name="xm2_logic", type="boolean", nullable=true) */
    private ?bool $xm2Logic;

    /** @ORM\Column(name="country_code", type="string", length=20, nullable=true) */
    private ?string $countryCode;

    /** @ORM\Column(name="ranking", type="string", length=50, nullable=true) */
    private ?string $ranking;

    /** @ORM\Column(name="finance_reference", type="string", length=50, nullable=true) */
    private ?string $financeReference;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="ansprechpartner_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $ansprechpartner = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id")
     */
    private ?OfferDebitor $debitor = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaFakturaziel")
     * @ORM\JoinColumn(name="fakturaziel_id", referencedColumnName="fakturaziel_id")
     */
    private ?OfferFakturaFakturaziel $fakturaziel = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenSachkonto")
     * @ORM\JoinColumn(name="icp_kont_konto_id", referencedColumnName="konto_id")
     */
    private ?OfferFakturaLbuDatenSachkonto $icpKontKonto = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaMaterialnummer")
     * @ORM\JoinColumn(name="mat_nr_id", referencedColumnName="mat_nr_id")
     */
    private ?OfferFakturaMaterialnummer $matNr = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferProfitcenterSettingsBillingtype")
     * @ORM\JoinColumn(name="billing_type_id", referencedColumnName="billing_type_id", nullable=true)
     */
    private ?OfferProfitcenterSettingsBillingtype $billingType = null;

    /**
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumn(name="label_id", referencedColumnName="label_id")
     */
    private SalesLabel $label;

    /** @ORM\Column(name="cbi_use_pcs", type="boolean", nullable=true) */
    private ?bool $cbiUsePcs = null;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceStream")
     * @ORM\JoinColumn(name="stream_id", referencedColumnName="id")
     */
    private FinanceStream $stream;

    /**
     * @return int
     * @Groups({"orderBasic"})
     */
    public function getProfitcenterSettingsId(): int
    {
        return $this->profitcenterSettingsId;
    }

    /**
     * @return string|null
     * @Groups({"icp"})
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getFrequency(): ?string
    {
        return $this->frequency;
    }

    /**
     * @param string|null $frequency
     */
    public function setFrequency(?string $frequency): void
    {
        $this->frequency = $frequency;
    }

    /**
     * @return bool|null
     */
    public function getIsDefault(): ?bool
    {
        return $this->isDefault;
    }

    /**
     * @param bool|null $isDefault
     */
    public function setIsDefault(?bool $isDefault): void
    {
        $this->isDefault = $isDefault;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function isIsIksl(): ?bool
    {
        return $this->isIksl;
    }

    /**
     * @param bool|null $isIksl
     */
    public function setIsIksl(?bool $isIksl): void
    {
        $this->isIksl = $isIksl;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getSapInterfaceUsage(): ?bool
    {
        return $this->sapInterfaceUsage;
    }

    /**
     * @param bool|null $sapInterfaceUsage
     */
    public function setSapInterfaceUsage(?bool $sapInterfaceUsage): void
    {
        $this->sapInterfaceUsage = $sapInterfaceUsage;
    }

    /**
     * @return string|null
     */
    public function getBillingHeadReference(): ?string
    {
        return $this->billingHeadReference;
    }

    /**
     * @param string|null $billingHeadReference
     */
    public function setBillingHeadReference(?string $billingHeadReference): void
    {
        $this->billingHeadReference = $billingHeadReference;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @param string|null $icpKontPspKst
     */
    public function setIcpKontPspKst(?string $icpKontPspKst): void
    {
        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getExternal(): ?bool
    {
        return $this->external;
    }

    /**
     * @param bool|null $external
     */
    public function setExternal(?bool $external): void
    {
        $this->external = $external;
    }

    /**
     * @return bool
     * @Groups({"orderBasic"})
     */
    public function isAllowEmptyAp(): bool
    {
        return $this->allowEmptyAp;
    }

    /**
     * @param bool $allowEmptyAp
     */
    public function setAllowEmptyAp(bool $allowEmptyAp): void
    {
        $this->allowEmptyAp = $allowEmptyAp;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getSmartInterfaceUsage(): ?bool
    {
        return $this->smartInterfaceUsage;
    }

    /**
     * @param bool|null $smartInterfaceUsage
     */
    public function setSmartInterfaceUsage(?bool $smartInterfaceUsage): void
    {
        $this->smartInterfaceUsage = $smartInterfaceUsage;
    }

    /**
     * @return string|null
     */
    public function getSmartContactEmail(): ?string
    {
        return $this->smartContactEmail;
    }

    /**
     * @param string|null $smartContactEmail
     */
    public function setSmartContactEmail(?string $smartContactEmail): void
    {
        $this->smartContactEmail = $smartContactEmail;
    }

    /**
     * @return string|null
     */
    public function getSmartPgName(): ?string
    {
        return $this->smartPgName;
    }

    /**
     * @param string|null $smartPgName
     */
    public function setSmartPgName(?string $smartPgName): void
    {
        $this->smartPgName = $smartPgName;
    }

    /**
     * @return bool|null
     */
    public function getXm2Logic(): ?bool
    {
        return $this->xm2Logic;
    }

    /**
     * @param bool|null $xm2Logic
     */
    public function setXm2Logic(?bool $xm2Logic): void
    {
        $this->xm2Logic = $xm2Logic;
    }

    /**
     * @return string|null
     */
    public function getCountryCode(): ?string
    {
        return $this->countryCode;
    }

    /**
     * @param string|null $countryCode
     */
    public function setCountryCode(?string $countryCode): void
    {
        $this->countryCode = $countryCode;
    }

    /**
     * @return string|null
     */
    public function getRanking(): ?string
    {
        return $this->ranking;
    }

    /**
     * @param string|null $ranking
     */
    public function setRanking(?string $ranking): void
    {
        $this->ranking = $ranking;
    }

    /**
     * @return string|null
     */
    public function getFinanceReference(): ?string
    {
        return $this->financeReference;
    }

    /**
     * @param string|null $financeReference
     */
    public function setFinanceReference(?string $financeReference): void
    {
        $this->financeReference = $financeReference;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getAnsprechpartner(): ?BackendBenutzer
    {
        return $this->ansprechpartner;
    }

    /**
     * @param BackendBenutzer|null $ansprechpartner
     */
    public function setAnsprechpartner(?BackendBenutzer $ansprechpartner): void
    {
        $this->ansprechpartner = $ansprechpartner;
    }

    /**
     * @return OfferDebitor|null
     * @Groups({"orderBasic"})
     */
    public function getDebitor(): ?OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @param OfferDebitor|null $debitor
     */
    public function setDebitor(?OfferDebitor $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @return OfferFakturaFakturaziel|null
     * @Groups({"orderBasic"})
     */
    public function getFakturaziel(): ?OfferFakturaFakturaziel
    {
        return $this->fakturaziel;
    }

    /**
     * @param OfferFakturaFakturaziel|null $fakturaziel
     */
    public function setFakturaziel(?OfferFakturaFakturaziel $fakturaziel): void
    {
        $this->fakturaziel = $fakturaziel;
    }

    /**
     * @return OfferFakturaLbuDatenSachkonto|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getIcpKontKonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->icpKontKonto;
    }

    /**
     * @param OfferFakturaLbuDatenSachkonto|null $icpKontKonto
     */
    public function setIcpKontKonto(?OfferFakturaLbuDatenSachkonto $icpKontKonto): void
    {
        $this->icpKontKonto = $icpKontKonto;
    }

    /**
     * @return OfferFakturaMaterialnummer|null
     * @Groups({"orderBasic"})
     */
    public function getMatNr(): ?OfferFakturaMaterialnummer
    {
        return $this->matNr;
    }

    /**
     * @param OfferFakturaMaterialnummer|null $matNr
     */
    public function setMatNr(?OfferFakturaMaterialnummer $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @return OfferProfitcenterSettingsBillingtype|null
     * @Groups({"orderBasic"})
     */
    public function getBillingType(): ?OfferProfitcenterSettingsBillingtype
    {
        return $this->billingType;
    }

    /**
     * @param OfferProfitcenterSettingsBillingtype $billingType
     */
    public function setBillingType(OfferProfitcenterSettingsBillingtype $billingType): void
    {
        $this->billingType = $billingType;
    }

    /**
     * @return SalesLabel
     */
    public function getLabel(): SalesLabel
    {
        return $this->label;
    }

    /**
     * @param SalesLabel $label
     */
    public function setLabel(SalesLabel $label): void
    {
        $this->label = $label;
    }

    /**
     * @return bool|null
     */
    public function isCbiUsePcs(): ?bool
    {
        return $this->cbiUsePcs;
    }

    /**
     * @Groups({"icpCbiUsePcs"})
     */
    public function getIcpData(): array
    {
        return [
            'icpKontPspKst' => $this->getIcpKontPspKst(),
            'debitor' => $this->getDebitor(),
            'fakturaziel' => $this->getFakturaziel(),
            'icpKontKonto' => $this->getIcpKontKonto(),
            'matNr' => $this->getMatNr(),
        ];
    }
}
