<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;
use App\Domain\Annotations\SystemProtocol as SP;

/**
 * @ORM\Table(name="Offer_Kalkulation_Leistungsposition")
 * @ORM\Entity
 * @ORM\EntityListeners({"App\Domain\Listeners\SystemProtocol\SystemProtocolListener"})
 * @SP(
 *   messages={
 *     "created"="Leistungsposition angelegt",
 *     "updated"="Leistungsposition bearbeitet",
 *     "removed"="Leistungsposition gelöscht"
 *   },
 *   group="LP"
 * )
 */
class OfferKalkulationLeistungsposition implements Loggable
{
    /**
     * @var int
     *
     * @ORM\Column(name="leistungsposition_id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $leistungspositionId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @var int|null
     *
     * @ORM\Column(name="seceit_nr", type="integer", nullable=true)
     */
    private ?int $seceitNr;

    /**
     * @var int
     *
     * @ORM\Column(name="fakturatyp_id", type="smallint")
     */
    private int $fakturatypId;

    /**
     * @var OfferKatalogFakturatyp
     *
     * @ORM\OneToOne(targetEntity="OfferKatalogFakturatyp")
     * @ORM\JoinColumn(name="fakturatyp_id", referencedColumnName="fakturatyp_id")
     */
    private OfferKatalogFakturatyp $fakturatyp;

    /**
     * @var string|null
     * @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true)
     */
    private ?string $bezeichnung;

    /**
     * @var float
     *
     * @ORM\Column(name="menge", type="decimal", precision=26, scale=18)
     */
    private float $menge = 0;

    /**
     * @var int|null
     *
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @var float|null
     *
     * @ORM\Column(name="if_wert_ressourcen", type="decimal", precision=18, scale=4, nullable=true)
     */
    private ?float $ifWertRessourcen;

    /**
     * @ORM\Column(name="if_wert_kosten", type="decimal", precision=18, scale=4, nullable=true)
     */
    private ?float $ifWertKosten;

    /**
     * @ORM\OneToOne(targetEntity="CostsServicelevel")
     * @ORM\JoinColumn(name="servicelevel_id", referencedColumnName="servicelevel_id", nullable=true)
     */
    private ?CostsServicelevel $servicelevel = null;

    /**
     * @ORM\Column(name="servicelevel_id", type="integer", nullable=true)
     */
    private ?int $servicelevelId = null;

    /**
     * @ORM\Column(name="servicelevel_wert", type="decimal", precision=18, scale=4, nullable=true)
     */
    private ?float $servicelevelWert = null;

    /**
     * @ORM\Column(name="itil_main_id", type="integer", nullable=true)
     */
    private ?int $itilMainId = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilMain")
     * @ORM\JoinColumn(name="itil_main_id", referencedColumnName="itil_main_id", nullable=true)
     */
    private ?OfferItilMain $itilMain = null;

    /**
     * @ORM\Column(name="itil_sub_id", type="integer", nullable=true)
     */
    private ?int $itilSubId = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilSub")
     * @ORM\JoinColumn(name="itil_sub_id", referencedColumnName="itil_sub_id", nullable=true)
     */
    private ?OfferItilSub $itilSub = null;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private ?string $beschreibung;

    /**
     * @ORM\Column(name="vollkosten", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $vollkosten = null;

    /**
     * @ORM\Column(name="vollkosten_final", type="decimal", precision=18, scale=2, nullable=true, options={"comment"="Vollkosten_Gesamt + Annuitätenrechnung"})
     */
    private ?float $vollkostenFinal = null;

    /**
     * @ORM\Column(name="einzelpreis_dtts", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $einzelpreisDtts;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="nach_aufwand", type="boolean", nullable=true)
     */
    private ?bool $nachAufwand;

    /**
     * @var int|null
     *
     * @ORM\Column(name="festpreisstufe_id", type="smallint", nullable=true)
     */
    private ?int $festpreisstufeId;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="favorit", type="boolean", nullable=true)
     */
    private ?bool $favorit;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean")
     */
    private bool $hide;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="material", type="boolean", nullable=true)
     */
    private ?bool $material;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="mz", type="boolean", nullable=true)
     */
    private ?bool $mz;

    /**
     * @ORM\Column(name="an_zinssatz", type="decimal", precision=18, scale=4, nullable=true)
     */
    private ?float $anZinssatz = null;

    /**
     * @ORM\Column(name="an_laufzeit", type="integer", nullable=true)
     */
    private ?int $anLaufzeit = null;

    /**
     * @ORM\Column(name="an_kwert", type="decimal", precision=6, scale=2, nullable=true)
     */
    private ?float $anKwert = null;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="presales", type="boolean", nullable=true)
     */
    private ?bool $presales;

    /**
     * @var int|null
     *
     * @ORM\Column(name="katalog_leistungsposition_id", type="bigint", nullable=true)
     */
    private ?int $katalogLeistungspositionId;

    /**
     * @ORM\OneToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="katalog_leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKatalogLeistungsposition $katalogLp = null;

    /**
     * @var DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime")
     */
    private DateTime $created;

    /**
     * @var DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="menge_alt", type="decimal", precision=18, scale=12, nullable=true)
     */
    private ?float $mengeAlt;

    /**
     * @var int|null
     *
     * @ORM\Column(name="verteilung_id_alt", type="bigint", nullable=true)
     */
    private ?int $verteilungIdAlt;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="festpreis_only", type="boolean", nullable=true)
     */
    private ?bool $festpreisOnly;

    /**
     * @var DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="elp", type="boolean", nullable=true)
     */
    private ?bool $elp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="myshs_hash", type="string", length=32, nullable=true)
     */
    private ?string $myshsHash;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * @var OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="angebotsposition_id", nullable=true)
     */
    private ?OfferKalkulationAngebotsposition $angebotsposition = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationLeistungsposition")
     * @ORM\JoinColumn(name="quell_leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKalkulationLeistungsposition $quellLeistungsposition;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationElement", mappedBy="leistungsposition", cascade={"remove"}) */
    private Collection $elements;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationBerechnung", mappedBy="leistungsposition", cascade={"remove"}) */
    private Collection $berechnung;

    /** @ORM\Column(type="boolean") */
    private bool $origin = false;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $sharedCosts = null;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="v_OfferKalkulationBerechnungGrid", mappedBy="leistungsposition")
     */
    private Collection $berechnungGrid;

    /**
     * @ORM\ManyToOne(targetEntity="CompetenceSkillprofile")
     * @ORM\JoinColumn(name="competence_skill_id", referencedColumnName="id", nullable=true)
     */
    private ?CompetenceSkillprofile $skillprofile = null;

    /**
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumn(name="portfolio_id", referencedColumnName="label_id", nullable=true)
     */
    private ?SalesLabel $portfolio = null;

    /**
     * OfferKalkulationLeistungsposition constructor.
     * @param SalesStammdaten $simple
     * @param OfferAngebotVk $vkVersions
     * @param OfferKatalogFakturatyp $fakturatyp
     * @param float $menge
     * @param BackendBenutzer $benutzer
     * @param bool $hide
     * @param bool $mz
     * @param bool $presales
     * @param float $elp
     */
    public function __construct(
        SalesStammdaten $simple,
        OfferAngebotVk $vkVersions,
        OfferKatalogFakturatyp $fakturatyp,
        float $menge,
        BackendBenutzer $benutzer,
        bool $hide = false,
        bool $mz = false,
        bool $presales = false,
        float $elp = 0.0
    )
    {
        $this->simple = $simple;
        $this->vkVersions = $vkVersions;
        $this->fakturatyp = $fakturatyp;
        $this->menge = $menge;
        $this->benutzer = $benutzer;
        $this->hide = $hide;
        $this->mz = $mz;
        $this->presales = $presales;
        $this->elp = $elp;
        $this->elements = new ArrayCollection();
        $this->berechnung = new ArrayCollection();
        $this->berechnungGrid = new ArrayCollection();
        $this->vollkosten = 0.0;
        $this->vollkostenFinal = 0.0;
    }

    /**
     * @Groups({"leistungenPaginated", "seceitList"})
     * @return float
     */
    public function getMenge(): float
    {
        return $this->menge;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getIfWertKosten(): ?string
    {
        return $this->ifWertKosten;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return float|null
     */
    public function getIfWertRessourcen(): ?float
    {
        return $this->ifWertRessourcen;
    }

    /**
     * @param string $field
     * @param $value
     */
    public function setField(string $field, $value): void
    {
        $this->{$field} = $value;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return Collection
     */
    public function getElements(): Collection
    {
        return $this->elements;
    }

    /**
     * @return float|null
     */
    public function getServicelevelWert(): ?float
    {
        return $this->servicelevelWert;
    }

    /**
     * @return float|null
     */
    public function getAnZinssatz(): ?float
    {
        return $this->anZinssatz;
    }

    /**
     * @return int|null
     */
    public function getAnLaufzeit(): ?int
    {
        return $this->anLaufzeit;
    }

    /**
     * @return float|null
     */
    public function getAnKwert(): ?float
    {
        return $this->anKwert;
    }

    /**
     * @return float|null
     */
    public function getVollkosten(): ?float
    {
        return $this->vollkosten;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return float|null
     */
    public function getVollkostenFinal(): ?float
    {
        return $this->vollkostenFinal;
    }

    /**
     * @param float|null $vollkosten
     */
    public function setVollkosten(?float $vollkosten): void
    {
        $this->vollkosten = $vollkosten;
    }

    /**
     * @param float|null $vollkostenFinal
     */
    public function setVollkostenFinal(?float $vollkostenFinal): void
    {
        $this->vollkostenFinal = $vollkostenFinal;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return Collection
     */
    public function getBerechnung(): Collection
    {
        return $this->berechnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param float|null $ifWertRessourcen
     */
    public function setIfWertRessourcen(?float $ifWertRessourcen): void
    {
        $this->ifWertRessourcen = $ifWertRessourcen;
    }

    /**
     * @param float|null $ifWertKosten
     */
    public function setIfWertKosten(?float $ifWertKosten): void
    {
        $this->ifWertKosten = $ifWertKosten;
    }

    /**
     * @param float|null $servicelevelWert
     */
    public function setServicelevelWert(?float $servicelevelWert): void
    {
        $this->servicelevelWert = $servicelevelWert;
    }

    /**
     * @param OfferItilMain|null $itilMain
     */
    public function setItilMain(?OfferItilMain $itilMain): void
    {
        $this->itilMain = $itilMain;
    }

    /**
     * @param OfferItilSub|null $itilSub
     */
    public function setItilSub(?OfferItilSub $itilSub): void
    {
        $this->itilSub = $itilSub;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @param bool|null $nachAufwand
     */
    public function setNachAufwand(?bool $nachAufwand): void
    {
        $this->nachAufwand = $nachAufwand;
    }

    /**
     * @param bool|null $material
     */
    public function setMaterial(?bool $material): void
    {
        $this->material = $material;
    }

    /**
     * @param OfferKatalogLeistungsposition|null $katalogLp
     */
    public function setKatalogLp(?OfferKatalogLeistungsposition $katalogLp): void
    {
        $this->katalogLp = $katalogLp;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param CostsServicelevel|null $servicelevel
     */
    public function setServicelevel(?CostsServicelevel $servicelevel): void
    {
        $this->servicelevel = $servicelevel;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @return OfferKatalogFakturatyp
     */
    public function getFakturatyp(): OfferKatalogFakturatyp
    {
        return $this->fakturatyp;
    }

    /**
     * @Groups({"leistungenPaginated", "seceitList"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return CostsServicelevel|null
     */
    public function getServicelevel(): ?CostsServicelevel
    {
        return $this->servicelevel;
    }

    /**
     * @return OfferItilMain|null
     */
    public function getItilMain(): ?OfferItilMain
    {
        return $this->itilMain;
    }

    /**
     * @return OfferItilSub|null
     */
    public function getItilSub(): ?OfferItilSub
    {
        return $this->itilSub;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @Groups({"seceitList"})
     * @return bool|null
     */
    public function getNachAufwand(): ?bool
    {
        return $this->nachAufwand;
    }

    /**
     * @return bool|null
     */
    public function getMaterial(): ?bool
    {
        return $this->material;
    }

    /**
     * @return OfferKalkulationAngebotsposition|null
     */
    public function getAngebotsposition(): ?OfferKalkulationAngebotsposition
    {
        return $this->angebotsposition;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return OfferKatalogLeistungsposition|null
     */
    public function getKatalogLp(): ?OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @param OfferAngebotVk $vkVersions
     */
    public function setVkVersions(OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @param OfferKalkulationAngebotsposition|null $angebotsposition
     */
    public function setAngebotsposition(?OfferKalkulationAngebotsposition $angebotsposition): void
    {
        $this->angebotsposition = $angebotsposition;
    }

    /**
     * @param OfferKatalogFakturatyp $fakturatyp
     */
    public function setFakturatyp(OfferKatalogFakturatyp $fakturatyp): void
    {
        $this->fakturatyp = $fakturatyp;
    }

    /**
     * @param float $menge
     */
    public function setMenge(float $menge): void
    {
        $this->menge = $menge;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @param OfferKalkulationBerechnung $ber
     */
    public function addBer(OfferKalkulationBerechnung $ber)
    {
        $this->berechnung->add($ber);
    }

    /**
     * @param OfferKalkulationElement $el
     */
    public function addEl(OfferKalkulationElement $el)
    {
        $this->elements->add($el);
    }

    /**
     * @param bool $origin
     */
    public function setOrigin(bool $origin): void
    {
        $this->origin = $origin;
    }

    /**
     * @return OfferKalkulationLeistungsposition|null
     */
    public function getQuellLeistungsposition(): ?OfferKalkulationLeistungsposition
    {
        return $this->quellLeistungsposition;
    }

    /**
     * @param OfferKalkulationLeistungsposition|null $quellLeistungsposition
     */
    public function setQuellLeistungsposition(?OfferKalkulationLeistungsposition $quellLeistungsposition): void
    {
        $this->quellLeistungsposition = $quellLeistungsposition;
    }

    /**
     * @Groups({"seceitList"})
     * @return int
     */
    public function getLeistungspositionId(): int
    {
        return $this->leistungspositionId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @Groups({"seceitList"})
     * @return int|null
     */
    public function getSeceitNr(): ?int
    {
        return $this->seceitNr;
    }

    /**
     * @param int|null $seceitNr
     */
    public function setSeceitNr(?int $seceitNr): void
    {
        $this->seceitNr = $seceitNr;
    }

    /**
     * @return int
     */
    public function getFakturatypId(): int
    {
        return $this->fakturatypId;
    }

    /**
     * @param int $fakturatypId
     */
    public function setFakturatypId(int $fakturatypId): void
    {
        $this->fakturatypId = $fakturatypId;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtts(): ?float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @param float|null $einzelpreisDtts
     */
    public function setEinzelpreisDtts(?float $einzelpreisDtts): void
    {
        $this->einzelpreisDtts = $einzelpreisDtts;
    }

    /**
     * @return int|null
     */
    public function getFestpreisstufeId(): ?int
    {
        return $this->festpreisstufeId;
    }

    /**
     * @param int|null $festpreisstufeId
     */
    public function setFestpreisstufeId(?int $festpreisstufeId): void
    {
        $this->festpreisstufeId = $festpreisstufeId;
    }

    /**
     * @return bool|null
     */
    public function getFavorit(): ?bool
    {
        return $this->favorit;
    }

    /**
     * @param bool|null $favorit
     */
    public function setFavorit(?bool $favorit): void
    {
        $this->favorit = $favorit;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @Groups({"seceitList"})
     * @return bool|null
     */
    public function getMz(): ?bool
    {
        return $this->mz;
    }

    /**
     * @param bool|null $mz
     */
    public function setMz(?bool $mz): void
    {
        $this->mz = $mz;
    }

    /**
     * @return bool|null
     */
    public function getPresales(): ?bool
    {
        return $this->presales;
    }

    /**
     * @param bool|null $presales
     */
    public function setPresales(?bool $presales): void
    {
        $this->presales = $presales;
    }

    /**
     * @return int|null
     */
    public function getKatalogLeistungspositionId(): ?int
    {
        return $this->katalogLeistungspositionId;
    }

    /**
     * @param int|null $katalogLeistungspositionId
     */
    public function setKatalogLeistungspositionId(?int $katalogLeistungspositionId): void
    {
        $this->katalogLeistungspositionId = $katalogLeistungspositionId;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return float|null
     */
    public function getMengeAlt(): ?float
    {
        return $this->mengeAlt;
    }

    /**
     * @param float|null $mengeAlt
     */
    public function setMengeAlt(?float $mengeAlt): void
    {
        $this->mengeAlt = $mengeAlt;
    }

    /**
     * @return int|null
     */
    public function getVerteilungIdAlt(): ?int
    {
        return $this->verteilungIdAlt;
    }

    /**
     * @param int|null $verteilungIdAlt
     */
    public function setVerteilungIdAlt(?int $verteilungIdAlt): void
    {
        $this->verteilungIdAlt = $verteilungIdAlt;
    }

    /**
     * @return bool|null
     */
    public function getFestpreisOnly(): ?bool
    {
        return $this->festpreisOnly;
    }

    /**
     * @param bool|null $festpreisOnly
     */
    public function setFestpreisOnly(?bool $festpreisOnly): void
    {
        $this->festpreisOnly = $festpreisOnly;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @param DateTime|null $bits
     */
    public function setBits(?DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return bool|null
     */
    public function getElp(): ?bool
    {
        return $this->elp;
    }

    /**
     * @param bool|null $elp
     */
    public function setElp(?bool $elp): void
    {
        $this->elp = $elp;
    }

    /**
     * @return string|null
     */
    public function getMyshsHash(): ?string
    {
        return $this->myshsHash;
    }

    /**
     * @param string|null $myshsHash
     */
    public function setMyshsHash(?string $myshsHash): void
    {
        $this->myshsHash = $myshsHash;
    }

    /**
     * @return bool
     */
    public function isOrigin(): bool
    {
        return $this->origin;
    }

    /**
     * @return bool|null
     */
    public function getSharedCosts(): ?bool
    {
        return $this->sharedCosts;
    }

    /**
     * @param bool|null $sharedCosts
     */
    public function setSharedCosts(?bool $sharedCosts): void
    {
        $this->sharedCosts = $sharedCosts;
    }

    /**
     * @param float|null $anZinssatz
     */
    public function setAnZinssatz(?float $anZinssatz): void
    {
        $this->anZinssatz = $anZinssatz;
    }

    /**
     * @param int|null $anLaufzeit
     */
    public function setAnLaufzeit(?int $anLaufzeit): void
    {
        $this->anLaufzeit = $anLaufzeit;
    }

    /**
     * @param float|null $anKwert
     */
    public function setAnKwert(?float $anKwert): void
    {
        $this->anKwert = $anKwert;
    }

    /**
     * @return int|null
     */
    public function getServicelevelId(): ?int
    {
        return $this->servicelevelId;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return CompetenceSkillprofile|null
     */
    public function getSkillprofile(): ?CompetenceSkillprofile
    {
        return $this->skillprofile;
    }

    /**
     * @param CompetenceSkillprofile|null $skillprofile
     */
    public function setSkillprofile(?CompetenceSkillprofile $skillprofile): void
    {
        $this->skillprofile = $skillprofile;
    }

    /**
     * @param SalesLabel|null $portfolio
     */
    public function setPortfolio(?SalesLabel $portfolio): void
    {
        $this->portfolio = $portfolio;
    }

    /**
     * @return SalesLabel|null
     */
    public function getPortfolio(): ?SalesLabel
    {
        return $this->portfolio;
    }

    /**
     * @param Collection $berechnung
     */
    public function setBerechnung(Collection $berechnung): void
    {
        $this->berechnung = $berechnung;
    }

    /**
     * @param Collection $elements
     */
    public function setElements(Collection $elements): void
    {
        $this->elements = $elements;
    }

    ////
    // SystemProtocol functions START
    ////

    /**
     * @return SIN
     * @throws InvalidSinException
     * @throws \Exception
     */
    public function getSin(): SIN
    {
        return new SIN($this->simple->getSimpleId());
    }

    /**
     * @return string
     */
    public function getSystemProtocolObjectName(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSystemProtocolParentName(): ?string
    {
        return ($this->getAngebotsposition()) ? $this->getAngebotsposition()->getBezeichnung() : null;
    }

    ////
    // SystemProtocol functions END
    ////
}
