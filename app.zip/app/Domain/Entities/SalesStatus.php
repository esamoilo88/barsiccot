<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * SalesStatus
 *
 * @ORM\Table(name="Sales_Status")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class SalesStatus
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", nullable=false) */
    private string $name;

    /** @ORM\Column(name="short_name", type="string", nullable=false) */
    private string $shortName;

    /** @ORM\Column(name="sys_name", type="string") */
    private string $sysName;

    /** @ORM\Column(name="rank ", type="integer", nullable=false) */
    private int $rank;

    /** @ORM\Column(name="active ", type="boolean", nullable=false) */
    private bool $active;

    /** @ORM\Column(name="presales", type="boolean", nullable=false) */
    private bool $presales;

    /** @ORM\Column(name="loss", type="boolean", nullable=false) */
    private bool $loss;

    /** @ORM\Column(name="onka_writable", type="boolean", nullable=false) */
    private bool $onkaWritable;

    /** @ORM\Column(name="billing_writable", type="boolean", nullable=false) */
    private bool $billingWritable;

    /** @ORM\Column(name="offer_complete", type="boolean", nullable=false) */
    private bool $offerComplete;

    /** @ORM\Column(name="progress", type="smallint", nullable=false, options={"default"=0}) */
    private int $progress = 0;

    /** @ORM\Column(name="color", type="string", length=10, nullable=true) */
    private ?string $color;

    /** @ORM\Column(name="preorder", type="boolean") */
    private bool $preorder = false;

    /** @ORM\Column(name="billing_locked", type="boolean", nullable=false) */
    private bool $billingLocked;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=false)
     */
    private DateTime $bits;

    /**
     * SalesStatus constructor.
     * @param string $name
     * @param string $shortName
     * @param string $sysName
     * @param int $rank
     * @param bool $active
     * @param bool $presales
     * @param bool $loss
     * @param bool $onkaWritable
     * @param bool $billingWritable
     * @param bool $offerComplete
     * @param int $progress
     * @param string|null $color
     */
    public function __construct(
        string $name,
        string $shortName,
        string $sysName,
        int $rank,
        bool $active,
        bool $presales,
        bool $loss,
        bool $onkaWritable,
        bool $billingWritable,
        bool $offerComplete,
        int $progress,
        ?string $color
    )
    {
        $this->name = $name;
        $this->shortName = $shortName;
        $this->sysName = $sysName;
        $this->rank = $rank;
        $this->active = $active;
        $this->presales = $presales;
        $this->loss = $loss;
        $this->onkaWritable = $onkaWritable;
        $this->billingWritable = $billingWritable;
        $this->offerComplete = $offerComplete;
        $this->progress = $progress;
        $this->color = $color;
    }

    /**
     * @return string
     * @Groups({"projectBasic"})
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     * @Groups({"projectBasic"})
     */
    public function getShortName(): string
    {
        return $this->shortName;
    }

    /**
     * @return int
     */
    public function getRank(): int
    {
        return $this->rank;
    }

    /**
     * @Groups({"projectBasic"})
     * @return int
     */
    public function getProgress(): int
    {
        return $this->progress;
    }

    /**
     * @param int $progress
     * @return void
     */
    public function setProgress(int $progress): void
    {
        $this->progress = $progress;
    }

    /**
     * @Groups({"projectBasic"})
     * @return string|null
     */
    public function getColor(): ?string
    {
        return $this->color;
    }

    /**
     * @param string|null $color
     */
    public function setColor(?string $color): void
    {
        $this->color = $color;
    }

    /**
     * @Groups({"projectBasic"})
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * @Groups({"projectBasic"})
     * @return bool
     */
    public function isPresales(): bool
    {
        return $this->presales;
    }

    /**
     * @return bool
     */
    public function isLoss(): bool
    {
        return $this->loss;
    }

    /**
     * @Groups({"projectBasic"})
     * @return bool
     */
    public function isOnkaWritable(): bool
    {
        return $this->onkaWritable;
    }

    /**
     * @return bool
     * @Groups({"orderBasic"})
     */
    public function isBillingWritable(): bool
    {
        return $this->billingWritable;
    }

    /**
     * @return bool
     * @Groups({"projectBasic"})
     */
    public function isOfferComplete(): bool
    {
        return $this->offerComplete;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string $shortName
     */
    public function setShortName(string $shortName): void
    {
        $this->shortName = $shortName;
    }

    /**
     * @param int $rank
     */
    public function setRank(int $rank): void
    {
        $this->rank = $rank;
    }

    /**
     * @param bool $active
     */
    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    /**
     * @param bool $presales
     */
    public function setPresales(bool $presales): void
    {
        $this->presales = $presales;
    }

    /**
     * @param bool $loss
     */
    public function setLoss(bool $loss): void
    {
        $this->loss = $loss;
    }

    /**
     * @param bool $onkaWritable
     */
    public function setOnkaWritable(bool $onkaWritable): void
    {
        $this->onkaWritable = $onkaWritable;
    }

    /**
     * @param bool $billingWritable
     */
    public function setBillingWritable(bool $billingWritable): void
    {
        $this->billingWritable = $billingWritable;
    }

    /**
     * @param bool $offerComplete
     */
    public function setOfferComplete(bool $offerComplete): void
    {
        $this->offerComplete = $offerComplete;
    }

    /**
     * @param string $sysName
     */
    public function setSysName(string $sysName): void
    {
        $this->sysName = $sysName;
    }

    /**
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }
    /**
     * @return bool
     */
    public function isPreorder(): bool
    {
        return $this->preorder;
    }

}
