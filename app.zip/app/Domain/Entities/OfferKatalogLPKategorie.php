<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OfferKatalogLPKategorie
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_LP_Kategorie")
 */
class OfferKatalogLPKategorie
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")
     */
    private OfferKatalogKategorie $katalogKategorie;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private OfferKatalogLeistungsposition $katalogLp;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * OfferKatalogLPKategorie constructor.
     * @param OfferKatalogKategorie $katalogKategorie
     * @param OfferKatalogLeistungsposition $katalogLp
     * @param int|null $sort
     */
    public function __construct(OfferKatalogKategorie $katalogKategorie, OfferKatalogLeistungsposition $katalogLp, ?int $sort)
    {
        $this->katalogKategorie = $katalogKategorie;
        $this->katalogLp = $katalogLp;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return OfferKatalogKategorie
     */
    public function getKatalogKategorie(): OfferKatalogKategorie
    {
        return $this->katalogKategorie;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getKatalogLp(): OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
