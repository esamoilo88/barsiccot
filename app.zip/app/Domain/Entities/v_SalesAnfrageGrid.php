<?php


namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="v_Sales_Anfrage_Grid")
 */
class v_SalesAnfrageGrid
{
    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     */
    private int $simpleId;

    /** @ORM\Column(name="thema", type="string") */
    private string $vorhabenname;

    /** @ORM\Column(name="kundenname", type="string", nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="cm_wert", type="smallint", nullable=true) */
    private ?int $cmWert;

    /** @ORM\Column(name="region", type="string", nullable=true) */
    private ?string $region;

    /** @ORM\Column(name="liefertermin_angebot", type="datetime", nullable=true) */
    private ?DateTime $lieferterminAngebot;

    /** @ORM\Column(name="liegezeit_soll", type="integer", nullable=true) */
    private ?int $liegezeitSoll;

    /** @ORM\Column(name="benutzername", type="string", nullable=true) */
    private ?string $benutzername;

    /** @ORM\Column(name="angebot_angefordert_am", type="datetime", nullable=true) */
    private ?DateTime $angebotAngefordertAm;

    /** @ORM\Column(name="liegezeit_ist", type="integer", nullable=true) */
    private ?int $liegezeitIst;

    /** @ORM\Column(name="Reihungswert", type="integer", nullable=true) */
    private ?int $reihungswert;

    /** @ORM\Column(name="Ablehnung_simple_id", type="integer", nullable=true) */
    private ?int $ablehnungSimpleId;

    /** @ORM\Column(name="angebotsersteller_zugewiesen_am", type="datetime", nullable=true) */
    private ?DateTime $angebotserstellerZugewiesenAm;

    /** @ORM\Column(name="af_versions_id", type="integer", nullable=true) */
    private ?int $afVersionsId;

    /** @ORM\Column(name="FVbenutzer_id", type="integer", nullable=true) */
    private ?int $fvbenutzerId;

    /** @ORM\Column(name="SCbenutzer_id", type="integer", nullable=true) */
    private ?int $scbenutzerId;

    /** @ORM\Column(name="TKBbenutzer_id", type="integer", nullable=true) */
    private ?int $tkbbenutzerId;

    /** @ORM\Column(name="auftragswahrscheinlichkeit", type="integer", nullable=true) */
    private ?int $auftragswahrscheinlichkeit;

    /** @ORM\Column(name="volumen_dtts", type="decimal", precision=18, scale=2, nullable=false) */
    private string $volumenDtts;

    /** @ORM\Column(name="prioritaet_bezeichnung", type="string", nullable=true) */
    private ?string $prioritaetBezeichnung;

    /** @ORM\Column(name="weitergeleitet_am", type="datetime", nullable=true) */
    private ?DateTime $weitergeleitetAm;

    /** @ORM\Column(name="prioritaet_id", type="integer", nullable=true) */
    private ?int $prioritaetId;

    /** @ORM\Column(name="AEbenutzer_id", type="integer", nullable=true) */
    private ?int $aebenutzerId;

    /** @ORM\Column(name="auftrag_simple_id", type="integer", nullable=true) */
    private ?int $auftragSimpleId;

    /** @ORM\Column(name="abgeschlossenGrund_id", type="integer", nullable=true) */
    private ?int $abgeschlossengrundId;

    /**
     * @ORM\OneToOne(targetEntity="SalesStatus", fetch="EAGER")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private SalesStatus $status;

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getVorhabenname(): string
    {
        return $this->vorhabenname;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return int|null
     */
    public function getCmWert(): ?int
    {
        return $this->cmWert;
    }

    /**
     * @return string|null
     */
    public function getRegion(): ?string
    {
        return $this->region;
    }

    /**
     * @return DateTime|null
     */
    public function getLieferterminAngebot(): ?DateTime
    {
        return $this->lieferterminAngebot;
    }

    /**
     * @return int|null
     */
    public function getLiegezeitSoll(): ?int
    {
        return $this->liegezeitSoll;
    }

    /**
     * @return string|null
     */
    public function getBenutzername(): ?string
    {
        return $this->benutzername;
    }

    /**
     * @return DateTime|null
     */
    public function getAngebotAngefordertAm(): ?DateTime
    {
        return $this->angebotAngefordertAm;
    }

    /**
     * @return int|null
     */
    public function getLiegezeitIst(): ?int
    {
        return $this->liegezeitIst;
    }

    /**
     * @return int|null
     */
    public function getReihungswert(): ?int
    {
        return $this->reihungswert;
    }

    /**
     * @return int|null
     */
    public function getAblehnungSimpleId(): ?int
    {
        return $this->ablehnungSimpleId;
    }

    /**
     * @return DateTime|null
     */
    public function getAngebotserstellerZugewiesenAm(): ?DateTime
    {
        return $this->angebotserstellerZugewiesenAm;
    }

    /**
     * @return int|null
     */
    public function getAfVersionsId(): ?int
    {
        return $this->afVersionsId;
    }

    /**
     * @return int|null
     */
    public function getFvbenutzerId(): ?int
    {
        return $this->fvbenutzerId;
    }

    /**
     * @return int|null
     */
    public function getScbenutzerId(): ?int
    {
        return $this->scbenutzerId;
    }

    /**
     * @return int|null
     */
    public function getTkbbenutzerId(): ?int
    {
        return $this->tkbbenutzerId;
    }

    /**
     * @return int|null
     */
    public function getAuftragswahrscheinlichkeit(): ?int
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @return string
     */
    public function getVolumenDtts(): string
    {
        return $this->volumenDtts;
    }

    /**
     * @return string|null
     */
    public function getPrioritaetBezeichnung(): ?string
    {
        return $this->prioritaetBezeichnung;
    }

    /**
     * @return DateTime|null
     */
    public function getWeitergeleitetAm(): ?DateTime
    {
        return $this->weitergeleitetAm;
    }

    /**
     * @return int|null
     */
    public function getPrioritaetId(): ?int
    {
        return $this->prioritaetId;
    }

    /**
     * @return int|null
     */
    public function getAebenutzerId(): ?int
    {
        return $this->aebenutzerId;
    }

    /**
     * @return int|null
     */
    public function getAuftragSimpleId(): ?int
    {
        return $this->auftragSimpleId;
    }

    /**
     * @return int|null
     */
    public function getAbgeschlossengrundId(): ?int
    {
        return $this->abgeschlossengrundId;
    }

    /**
     * @return SalesStatus
     */
    public function getStatus(): SalesStatus
    {
        return $this->status;
    }
}
