<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * HISTORY_SalesSinStatus
 *
 * @ORM\Table(name="Sales_SIN_Status_HISTORY")
 * @ORM\Entity
 */
class HISTORY_SalesSinStatus
{
    /**
     * @ORM\Column(name="id ", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="simple_id ", type="integer", nullable=false) */
    private int $simpleId;

    /** @ORM\Column(name="status_id ", type="integer", nullable=false) */
    private int $status;

    /** @ORM\Column(name="valid_from", type="datetime", nullable=false) */
    private $validFrom;

    /** @ORM\Column(name="valid_to", type="datetime", nullable=false) */
    private $validTo;

    /**
     * HISTORY_SalesSinStatus constructor.
     */
    private function __construct()
    {
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return int
     */
    public function getStatus(): int
    {
        return $this->status;
    }
}
