<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKalkulationHistorie
 *
 * @ORM\Table(name="Offer_Kalkulation_Historie")
 * @ORM\Entity
 */
class OfferKalkulationHistorie
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="object_id", type="bigint", nullable=false)
     */
    private $objectId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="object_type", type="string", length=3, nullable=true)
     */
    private $objectType;

    /**
     * @var string|null
     *
     * @ORM\Column(name="object_name", type="text", length=-1, nullable=true)
     */
    private $objectName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="parent", type="text", length=-1, nullable=true)
     */
    private $parent;

    /**
     * @var string|null
     *
     * @ORM\Column(name="action", type="string", length=6, nullable=true)
     */
    private $action;

    /**
     * @var string|null
     *
     * @ORM\Column(name="field", type="string", length=32, nullable=true)
     */
    private $field;

    /**
     * @var string|null
     *
     * @ORM\Column(name="old_value", type="text", length=-1, nullable=true)
     */
    private $oldValue;

    /**
     * @var string|null
     *
     * @ORM\Column(name="new_value", type="text", length=-1, nullable=true)
     */
    private $newValue;

    /**
     * @var string|null
     *
     * @ORM\Column(name="old_value_formatted", type="text", length=-1, nullable=true)
     */
    private $oldValueFormatted;

    /**
     * @var string|null
     *
     * @ORM\Column(name="new_value_formatted", type="text", length=-1, nullable=true)
     */
    private $newValueFormatted;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="timestamp", type="datetime", nullable=false)
     */
    private $timestamp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="transaction", type="string", length=40, nullable=true, options={"fixed"=true})
     */
    private $transaction;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;

    /**
     * @var \OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private $vkVersions;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
