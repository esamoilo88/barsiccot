<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferKatalogLeistungsposition
 *
 * @ORM\Table(name="Offer_Katalog_Leistungsposition")
 * @ORM\Entity
 */
class OfferKatalogLeistungsposition
{
    /**
     * @var int
     *
     * @ORM\Column(type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $leistungspositionId;

    /**
     * @var string|null
     *
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    private ?string $katalognummer;

    /**
     * @ORM\Column(type="string", length=150, nullable=true)
     */
    private ?string $bezeichnung = null;

    /**
     * @var string|null
     *
     * @ORM\Column(type="text", length=-1, nullable=true)
     */
    private ?string $beschreibung;

    /**
     * @var int|null
     *
     * @ORM\Column(type="smallint", nullable=true)
     */
    private ?int $servicelevelId;

    /**
     * @ORM\OneToOne(targetEntity="CostsServicelevel", fetch="EAGER")
     * @ORM\JoinColumn(name="servicelevel_id", referencedColumnName="servicelevel_id", nullable=true)
     */
    private ?CostsServicelevel $servicelevel;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $einzelpreisDtts;

    /** @ORM\Column(name="modulkatalog_id", type="string", length=20, nullable=true) */
    private ?string $modulkatalogId;

    /** @ORM\Column(type="text", length=-1, nullable=true) */
    private ?string $kommentar;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $nachAufwand;

    /** @ORM\Column(type="string", length=7, nullable=true) */
    private ?string $farbe;

    /** @ORM\Column(name="material", type="boolean", nullable=true) */
    private ?bool $material;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $bits;

    /** @ORM\Column(type="text", length=-1, nullable=true) */
    private ?string $productIdMyshs;

    /** @ORM\Column(type="decimal", precision=18, scale=4, nullable=true) */
    private ?string $inflationsfaktorKosten;

    /** @ORM\Column(type="decimal", precision=18, scale=4, nullable=true) */
    private ?string $inflationsfaktorRessourcen;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilMain")
     * @ORM\JoinColumn(name="itil_main_id", referencedColumnName="itil_main_id", nullable=true)
     */
    private ?OfferItilMain $itilMain = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilSub")
     * @ORM\JoinColumn(name="itil_sub_id", referencedColumnName="itil_sub_id", nullable=true)
     */
    private ?OfferItilSub $itilSub = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogFakturatyp")
     * @ORM\JoinColumn(name="fakturatyp_id", referencedColumnName="fakturatyp_id")
     */
    private OfferKatalogFakturatyp $fakturatyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogFestpreisstufe")
     * @ORM\JoinColumn(name="festpreisstufe_id", referencedColumnName="festpreisstufe_id", nullable=true)
     */
    private ?OfferKatalogFestpreisstufe $festpreisstufe;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id", nullable=true)
     */
    private ?OfferKatalogKategorie $kategorie;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="SalesEsinPcag", inversedBy="leistungsposition")
     * @ORM\JoinTable(name="offer_katalog_leistungsposition_profitcenter",
     *   joinColumns={
     *     @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="pcag_id", referencedColumnName="pcag_id")
     *   }
     * )
     */
    private Collection $pcag;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogElement", mappedBy="leistungsposition", cascade={"remove"})
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private Collection $katalogEl;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogBerechnung", mappedBy="leistungsposition", cascade={"remove"})
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private Collection $katalogBer;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogElLp", mappedBy="katalogLp")
     * @ORM\OrderBy({"sort" = "ASC"})
     */
    private Collection $els;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogBerElLp", mappedBy="katalogLp")
     * @ORM\OrderBy({"sort" = "ASC"})
     */
    private Collection $bers;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinTable(name="Offer_Katalog_LP_AP",
     *      joinColumns={@ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")}
     * )
     */
    private Collection $aps;

    /**
     * @ORM\ManyToOne(targetEntity="CompetenceSkillprofile")
     * @ORM\JoinColumn(name="competence_skill_id", referencedColumnName="id", nullable=true)
     */
    private ?CompetenceSkillprofile $skillprofile = null;

    /** @ORM\OneToOne(targetEntity="OfferKatalogLPKategorie", mappedBy="katalogLp") */
    private OfferKatalogLPKategorie $katalogLPKategorie;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinTable(name="Offer_Katalog_LP_Kategorie",
     *      joinColumns={@ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")}
     * )
     */
    private Collection $categories;

    /**
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumn(name="portfolio_id", referencedColumnName="label_id", nullable=true)
     */
    private ?SalesLabel $portfolio = null;

    /** Variable for Katalog list */
    private array $breadcrumb = [];

    /** Variable for Katalog list*/
    private bool $isOutdated = false;

    /** Variable for Katalog list */
    private float $unitCosts = 0.0;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenMengentyp")
     * @ORM\JoinColumn(name="mengentyp_id", referencedColumnName="mengentyp_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenMengentyp $mengentyp = null;

    /**
     * OfferKatalogLeistungsposition constructor.
     */
    public function __construct()
    {
        $this->pcag = new ArrayCollection();

        $this->inflationsfaktorRessourcen = null;
        $this->inflationsfaktorKosten = null;
        $this->beschreibung = null;
        $this->nachAufwand = null;
        $this->material = null;
        $this->katalogEl = new ArrayCollection();
        $this->katalogBer = new ArrayCollection();
        $this->bers = new ArrayCollection();
        $this->els = new ArrayCollection();
        $this->aps = new ArrayCollection();
        $this->categories = new ArrayCollection();
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->leistungspositionId;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return int
     */
    public function getLeistungspositionId(): int
    {
        return $this->leistungspositionId;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getInflationsfaktorRessourcen(): ?string
    {
        return $this->inflationsfaktorRessourcen;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getInflationsfaktorKosten(): ?string
    {
        return $this->inflationsfaktorKosten;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return int|null
     */
    public function getServicelevelId(): ?int
    {
        return $this->servicelevelId;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return OfferItilMain|null
     */
    public function getItilMain(): ?OfferItilMain
    {
        return $this->itilMain;
    }

    /**
     * @param OfferItilMain|null $itilMain
     */
    public function setItilMain(?OfferItilMain $itilMain): void
    {
        $this->itilMain = $itilMain;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return OfferItilSub|null
     */
    public function getItilSub(): ?OfferItilSub
    {
        return $this->itilSub;
    }

    /**
     * @param OfferItilSub|null $itilSub
     */
    public function setItilSub(?OfferItilSub $itilSub): void
    {
        $this->itilSub = $itilSub;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return bool|null
     */
    public function getNachAufwand(): ?bool
    {
        return $this->nachAufwand;
    }

    /**
     * @return bool|null
     */
    public function getMaterial(): ?bool
    {
        return $this->material;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return CostsServicelevel|null
     */
    public function getServicelevel(): ?CostsServicelevel
    {
        return $this->servicelevel;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getKatalogEl()
    {
        return $this->katalogEl;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param CostsServicelevel|null $servicelevel
     */
    public function setServicelevel(?CostsServicelevel $servicelevel): void
    {
        $this->servicelevel = $servicelevel;
    }

    /**
     * @param float|null $inflationsfaktorRessourcen
     */
    public function setInflationsfaktorRessourcen(?float $inflationsfaktorRessourcen): void
    {
        $this->inflationsfaktorRessourcen = $inflationsfaktorRessourcen;
    }

    /**
     * @param float|null $inflationsfaktorKosten
     */
    public function setInflationsfaktorKosten(?float $inflationsfaktorKosten): void
    {
        $this->inflationsfaktorKosten = $inflationsfaktorKosten;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @param bool|null $nachAufwand
     */
    public function setNachAufwand(?bool $nachAufwand): void
    {
        $this->nachAufwand = $nachAufwand;
    }

    /**
     * @param ArrayCollection|Collection $katalogEl
     */
    public function setKatalogEl($katalogEl): void
    {
        $this->katalogEl = $katalogEl;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getKatalogBer()
    {
        return $this->katalogBer;
    }

    /**
     * @return OfferKatalogFestpreisstufe|null
     */
    public function getFesstpreisstyfe(): ?OfferKatalogFestpreisstufe
    {
        return $this->festpreisstufe;
    }

    /**
     * @return OfferKatalogFakturatyp
     */
    public function getFakturatyp(): OfferKatalogFakturatyp
    {
        return $this->fakturatyp;
    }

    /**
     * @return string|null
     */
    public function getEinzelpreisDtts(): ?string
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return CompetenceSkillprofile|null
     */
    public function getSkillprofile(): ?CompetenceSkillprofile
    {
        return $this->skillprofile;
    }

    /**
     * @param CompetenceSkillprofile|null $skillprofile
     */
    public function setSkillprofile(?CompetenceSkillprofile $skillprofile): void
    {
        $this->skillprofile = $skillprofile;
    }

    /**
     * @return SalesLabel|null
     */
    public function getPortfolio(): ?SalesLabel
    {
        return $this->portfolio;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return ArrayCollection|Collection
     */
    public function getEls()
    {
        return $this->els->map(function (OfferKatalogElLp $elLp) {
            return $elLp->getKatalogEl();
        });
    }

    /**
     * @param ArrayCollection|Collection $els
     */
    public function setEls($els): void
    {
        $this->els = $els;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return ArrayCollection|Collection
     */
    public function getBers()
    {
        return $this->bers->map(function (OfferKatalogBerElLp $berLp) {
            return $berLp->getKatalogBer();
        });
    }

    /**
     * @param ArrayCollection|Collection $bers
     */
    public function setBers($bers): void
    {
        $this->bers = $bers;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return OfferKatalogLPKategorie
     */
    public function getKatalogLPKategorie(): OfferKatalogLPKategorie
    {
        return $this->katalogLPKategorie;
    }

    /**
     * @param OfferKatalogLPKategorie $katalogLPKategorie
     */
    public function setKatalogLPKategorie(OfferKatalogLPKategorie $katalogLPKategorie): void
    {
        $this->katalogLPKategorie = $katalogLPKategorie;
    }

    /**
     * @return array
     */
    public function getBreadcrumb(): array
    {
        return $this->breadcrumb;
    }

    /**
     * @param array $breadcrumb
     */
    public function setBreadcrumb(array $breadcrumb): void
    {
        $this->breadcrumb = $breadcrumb;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return bool
     */
    public function isOutdated(): bool
    {
        return $this->isOutdated;
    }

    /**
     * @param bool $isOutdated
     */
    public function setIsOutdated(bool $isOutdated): void
    {
        $this->isOutdated = $isOutdated;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return float
     */
    public function getUnitCosts(): float
    {
        return $this->unitCosts;
    }

    /**
     * @param float $unitCosts
     */
    public function setUnitCosts(float $unitCosts): void
    {
        $this->unitCosts = $unitCosts;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getKatalognummer(): ?string
    {
        return $this->katalognummer;
    }

    /**
     * @param string|null $katalognummer
     */
    public function setKatalognummer(?string $katalognummer): void
    {
        $this->katalognummer = $katalognummer;
    }

    /**
     * @return Collection
     */
    public function getCategories(): Collection
    {
        return $this->categories;
    }

    /**
     * @param Collection $categories
     */
    public function setCategories(Collection $categories): void
    {
        $this->categories = $categories;
    }

    /**
     * @return Collection
     */
    public function getAps(): Collection
    {
        return $this->aps;
    }

    /**
     * @param Collection $aps
     */
    public function setAps(Collection $aps): void
    {
        $this->aps = $aps;
    }

    /**
     * @param OfferKatalogFakturatyp $fakturatyp
     */
    public function setFakturatyp(OfferKatalogFakturatyp $fakturatyp): void
    {
        $this->fakturatyp = $fakturatyp;
    }

    /**
     * @return OfferFakturaLbuDatenMengentyp|null
     */
    public function getMengentyp(): ?OfferFakturaLbuDatenMengentyp
    {
        return $this->mengentyp;
    }
}
