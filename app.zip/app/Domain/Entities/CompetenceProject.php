<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * CompetenceProject
 *
 * @ORM\Table(name="Competence_Project")
 * @ORM\Entity
 */
class CompetenceProject
{
    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     * @ORM\Id
     */
    private $simpleId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="project_id", type="integer", nullable=true)
     */
    private $projectId;

    /**
     * @var int
     *
     * @ORM\Column(name="customer_id", type="integer", nullable=false)
     */
    private $customerId;

    /**
     * @var DateTime|null
     *
     * @ORM\Column(name="timestamp", type="datetime", nullable=true)
     */
    private $timestamp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_hash", type="string", length=32, nullable=true)
     */
    private $customerHash;

    /**
     * @ORM\OneToOne(targetEntity="SalesStammdaten", inversedBy="competenceProject")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /**
     * CompetenceProject constructor.
     * @param SalesStammdaten $stammdaten
     * @param int $projectId
     * @param int $customerId
     * @param string|null $customerHash
     * @param DateTime $timestamp
     */
    public function __construct(
        SalesStammdaten $stammdaten,
        int $projectId,
        int $customerId,
        ?string $customerHash,
        DateTime $timestamp
    )
    {
        $this->simpleId = $stammdaten->getSimpleId();
        $this->salesStammdaten = $stammdaten;
        $this->projectId = $projectId;
        $this->customerId = $customerId;
        $this->customerHash = $customerHash;
        $this->timestamp = $timestamp;
    }

    /**
     * @return int|null
     */
    public function getProjectId(): ?int
    {
        return $this->projectId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getCustomerHash(): ?string
    {
        return $this->customerHash;
    }

    /**
     * @return int
     */
    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @param int|null $projectId
     */
    public function setProjectId(?int $projectId): void
    {
        $this->projectId = $projectId;
    }

    /**
     * @param int $customerId
     */
    public function setCustomerId(int $customerId): void
    {
        $this->customerId = $customerId;
    }

    /**
     * @param string|null $customerHash
     */
    public function setCustomerHash(?string $customerHash): void
    {
        $this->customerHash = $customerHash;
    }

    /**
     * @param DateTime|null $timestamp
     */
    public function setTimestamp(?DateTime $timestamp): void
    {
        $this->timestamp = $timestamp;
    }
}
