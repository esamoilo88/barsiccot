<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\Finance\MonthYear;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * FinanceSINBalance
 *
 * @ORM\Table(name="Finance_SIN_Balance")
 * @ORM\Entity
 */
class FinanceSINBalance
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\OneToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\Column(name="total_costs", type="decimal", nullable=true)
     */
    private ?float $totalCosts;

    /**
     * @ORM\Column(name="total_ilv", type="decimal", nullable=true)
     */
    private ?float $totalIlv;

    /**
     * @ORM\Column(name="total_revenue", type="decimal", nullable=true)
     */
    private ?float $totalRevenue;

    /**
     * @ORM\Column(name="newest_costs", type="decimal", nullable=true)
     */
    private ?float $newestCosts;

    /**
     * @ORM\Column(name="newest_ilv", type="decimal", nullable=true)
     */
    private ?float $newestIlv;

    /**
     * @ORM\Column(name="newest_revenue", type="decimal", nullable=true)
     */
    private ?float $newestRevenue;

    /**
     * @ORM\Column(name="newest_costs_period", type="datetime", nullable=true)
     */
    private ?DateTime $newestCostsPeriod;

    /**
     * @ORM\Column(name="newest_ilv_period", type="datetime", nullable=true)
     */
    private ?DateTime $newestIlvPeriod;

    /**
     * @ORM\Column(name="newest_revenue_period", type="datetime", nullable=true)
     */
    private ?DateTime $newestRevenuePeriod;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * FinanceSINBalance constructor.
     * @param SalesStammdaten $simple
     */
    public function __construct(SalesStammdaten $simple)
    {
        $this->simple = $simple;
        $this->simpleId = $simple->getSimpleId();
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSIN(): SIN
    {
        return new SIN($this->simpleId);
    }

    /**
     * @param float|null $totalCosts
     */
    public function setTotalCosts(?float $totalCosts): void
    {
        $this->totalCosts = $totalCosts;
    }

    /**
     * @param ?float $totalIlv
     */
    public function setTotalIlv(?float $totalIlv): void
    {
        $this->totalIlv = $totalIlv;
    }

    /**
     * @param ?float $totalRevenue
     */
    public function setTotalRevenue(?float $totalRevenue): void
    {
        $this->totalRevenue = $totalRevenue;
    }

    /**
     * @param ?float $newestCosts
     */
    public function setNewestCosts(?float $newestCosts): void
    {
        $this->newestCosts = $newestCosts;
    }

    /**
     * @param ?float $newestIlv
     */
    public function setNewestIlv(?float $newestIlv): void
    {
        $this->newestIlv = $newestIlv;
    }

    /**
     * @param ?float $newestRevenue
     */
    public function setNewestRevenue(?float $newestRevenue): void
    {
        $this->newestRevenue = $newestRevenue;
    }

    /**
     * @param MonthYear|null $monthYear
     */
    public function setNewestCostsPeriod(?MonthYear $monthYear): void
    {
        $this->newestCostsPeriod = $monthYear ? $this->makeDate($monthYear): null;
    }

    /**
     * @param MonthYear|null $monthYear
     */
    public function setNewestIlvPeriod(?MonthYear $monthYear): void
    {
        $this->newestIlvPeriod = $monthYear ? $this->makeDate($monthYear): null;
    }

    /**
     * @param MonthYear|null $monthYear
     */
    public function setNewestRevenuePeriod(?MonthYear $monthYear): void
    {
        $this->newestRevenuePeriod = $monthYear ? $this->makeDate($monthYear): null;
    }

    /**
     * @param MonthYear $monthYear
     * @return DateTime
     */
    private function makeDate(MonthYear $monthYear): DateTime
    {
        $date = new DateTime();
        $date->setDate($monthYear->getYear(), $monthYear->getMonth(),1);

        return $date;
    }

    /**
     * @return float|null
     */
    public function getNewestCosts(): ?float
    {
        return $this->newestCosts;
    }

    /**
     * @return float|null
     */
    public function getNewestRevenue(): ?float
    {
        return $this->newestRevenue;
    }

    /**
     * @return DateTime|null
     */
    public function getNewestRevenuePeriod(): ?DateTime
    {
        return $this->newestRevenuePeriod;
    }

    /**
     * @return DateTime|null
     */
    public function getNewestCostsPeriod(): ?DateTime
    {
        return $this->newestCostsPeriod;
    }

    /**
     * @return float|null
     */
    public function getTotalRevenue(): ?float
    {
        return $this->totalRevenue;
    }

    /**
     * @return float|null
     */
    public function getTotalCosts(): ?float
    {
        return $this->totalCosts;
    }

    /**
     * @return float|null
     */
    public function getTotalIlv(): ?float
    {
        return $this->totalIlv;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }
}
