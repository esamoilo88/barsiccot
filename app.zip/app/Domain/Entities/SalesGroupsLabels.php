<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Sales_Groups_Labels")
 * @ORM\Entity
 */
class SalesGroupsLabels
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="label", type="string", length=50, unique=true) */
    private string $label;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide = false;

    /** @ORM\Column(name="locked", type="boolean", nullable=true) */
    private ?bool $locked;

    /**
     * SalesGroupsLabels constructor.
     * @param string $label
     * @param bool $locked
     */
    public function __construct(string $label, bool $locked = false)
    {
        $this->label = $label;
        $this->locked = $locked;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getLabel(): string
    {
        return $this->label;
    }

    /**
     * @param string $label
     */
    public function setLabel(string $label): void
    {
        $this->label = $label;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool|null
     */
    public function getLocked(): ?bool
    {
        return $this->locked;
    }

    /**
     * @param bool|null $locked
     */
    public function setLocked(?bool $locked): void
    {
        $this->locked = $locked;
    }
}
