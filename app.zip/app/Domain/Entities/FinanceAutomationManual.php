<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * FinanceAutomationManual
 *
 * @ORM\Table(name="Finance_Automation_Manual")
 * @ORM\Entity
 */
class FinanceAutomationManual
{

    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="auto_send", type="boolean")
     */
    private bool $autoSend;

    /**
     * @ORM\Column(name="send_at", type="string")
     */
    private string $sendAt;

    /**
     * @ORM\Column(name="bill_after_deadline", type="boolean")
     */
    private bool $billAfterDeadline;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;
}
