<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmFmb
 *
 * @ORM\Table(name="RM_FMB")
 * @ORM\Entity
 */
class RmFmb
{
    /**
     * @var int
     *
     * @ORM\Column(name="fmb_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $fmbId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=100, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="email", type="string", length=150, nullable=true)
     */
    private $email;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
