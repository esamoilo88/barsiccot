<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * MyshsCommunication
 *
 * @ORM\Table(name="MySHS_Communication")
 * @ORM\Entity
 */
class MyshsCommunication
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int|null
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=true)
     */
    private $simpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="type", type="string", length=28, nullable=true, options={"fixed"=true})
     */
    private $type;

    /**
     * @var string|null
     *
     * @ORM\Column(name="response", type="string", length=0, nullable=true)
     */
    private $response;

    /**
     * @var string|null
     *
     * @ORM\Column(name="controller_name", type="string", length=50, nullable=true)
     */
    private $controllerName;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="timestamp", type="datetime", nullable=false)
     */
    private $timestamp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="action", type="string", length=32, nullable=true)
     */
    private $action;


}
