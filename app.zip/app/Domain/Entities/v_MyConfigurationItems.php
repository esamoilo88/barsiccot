<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_MyConfiguration_Items")
 */
class v_MyConfigurationItems
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="item_id", type="integer")
     */
    private int $itemId;

    /**
     * @ORM\Column(name="configuration_id", type="integer")
     */
    private int $configurationId;

    /**
     * @ORM\Column(name="product_type", type="string")
     * @Groups({"projectBasic"})
     */
    private string $productType;

    /** @ORM\Column(name="group_name", type="string") */
    private string $groupName;

    /** @ORM\Column(name="group_sort", type="string", nullable=true) */
    private ?string $groupSort;

    /** @ORM\Column(name="ap_name", type="string") */
    private string $apName;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private $price;

    /** @ORM\Column(name="unit_costs", type="decimal", precision=18, scale=2, nullable=true) */
    private $unitCosts;

    /** @ORM\Column(name="fixed_price",type="boolean") */
    private bool $fixedPrice;

    /** @ORM\Column(name="preisfaktor", type="decimal", precision=9, scale=2, nullable=true) */
    private ?float $preisfaktor = null;

    /** @ORM\Column(name="marge", type="decimal", precision=9, scale=2, nullable=true) */
    private ?float $marge = null;

    /** @ORM\Column(type="boolean") */
    private bool $required;

    /** @ORM\Column(type="boolean") */
    private bool $fixed;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /** @ORM\Column(type="boolean") */
    private bool $selected;

    /** @ORM\Column(type="string") */
    private string $mengentype;

    /** @ORM\Column(type="boolean") */
    private bool $isRecurrent;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguration")
     * @ORM\JoinColumn(name="configuration_id", referencedColumnName="id")
     */
    private OnkaConfiguration $configuration;

    /**
     * @ORM\OneToOne (targetEntity="OnkaConfigurationItem")
     * @ORM\JoinColumn(name="item_id", referencedColumnName="id")
     */
    private OnkaConfigurationItem $item;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfigurator")
     * @ORM\JoinColumn(name="group_configurator_id", referencedColumnName="id")
     */
    private OnkaConfigurator $configurator;

    /** @ORM\Column(name="param_sourcing_name", type="string", nullable=true) */
    private ?string $paramSourcingName;

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getItemId(): int
    {
        return $this->itemId;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getConfigurationId(): int
    {
        return $this->configurationId;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string
     */
    public function getProductType(): string
    {
        return $this->productType;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string
     */
    public function getGroupName(): string
    {
        return $this->groupName;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string
     */
    public function getApName(): string
    {
        return $this->apName;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string
     */
    public function getGroupSort(): ?string
    {
        return $this->groupSort;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return mixed
     */
    public function getUnitCosts()
    {
        return $this->unitCosts;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return mixed
     */
    public function getPreisfaktor()
    {
        return $this->preisfaktor;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return mixed
     */
    public function getMarge()
    {
        return $this->marge;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return mixed
     */
    public function getFixedPrice()
    {
        return $this->fixedPrice;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function isFixed(): bool
    {
        return $this->fixed;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function isSelected(): bool
    {
        return $this->selected;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string
     */
    public function getMengentype(): string
    {
        return $this->mengentype;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function isRecurrent(): bool
    {
        return $this->isRecurrent;
    }

    /**
     * @return OnkaConfiguration
     */
    public function getConfiguration(): OnkaConfiguration
    {
        return $this->configuration;
    }

    /**
     * @param OnkaConfiguration $configuration
     */
    public function setConfiguration(OnkaConfiguration $configuration): void
    {
        $this->configuration = $configuration;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OnkaConfigurationItem
     */
    public function getItem(): OnkaConfigurationItem
    {
        return $this->item;
    }

    /**
     * @param OnkaConfigurationItem $item
     */
    public function setItem(OnkaConfigurationItem $item): void
    {
        $this->item = $item;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string|null
     */
    public function getParamSourcingName(): ?string
    {
        return $this->paramSourcingName;
    }
}
