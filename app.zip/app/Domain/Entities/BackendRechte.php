<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendRechte
 *
 * @ORM\Table(name="Backend_Rechte")
 * @ORM\Entity
 */
class BackendRechte
{
    /**
     * @ORM\Column(name="rechte_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $rechteId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="berechtigung", type="string", length=50, nullable=true) */
    private ?string $berechtigung;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="has_role", type="boolean", nullable=false) */
    private bool $hasRole;

    /** @ORM\Column(type="boolean") */
    private bool $hide;

    /** @ORM\Column(name="`group`", type="string", nullable=true) */
    private ?string $group;

    /**
     * @ORM\ManyToOne(targetEntity="BackendAnwendung")
     * @ORM\JoinColumn(name="anwendungs_id", referencedColumnName="anwendungs_id")
     */
    private ?BackendAnwendung $backendAnwendung = null;

    /**
     * @ORM\ManyToMany(targetEntity="BackendRoles")
     * @ORM\JoinTable(name="Backend_RoleRechte",
     *     joinColumns={@ORM\JoinColumn(name="rechte_id", referencedColumnName="rechte_id")},
     *     inverseJoinColumns={@ORM\JoinColumn(name="role_id", referencedColumnName="role_id")}
     * )
     */
    private Collection $accessibleRoles;

    /** @ORM\Column(type="boolean") */
    private bool $seeUserNames;

    /**
     * @return int
     */
    public function getRechteId():int
    {
        return $this->rechteId;
    }

    /**
     * @param int $rechteId
     */
    public function setRechteId(int $rechteId): void
    {
        $this->rechteId = $rechteId;
    }

    /**
     * @return bool
     */
    public function hasRole(): bool
    {
        return $this->hasRole;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBerechtigung(): ?string
    {
        return $this->berechtigung;
    }

    /**
     * @param string|null $berechtigung
     */
    public function setBerechtigung(?string $berechtigung): void
    {
        $this->berechtigung = $berechtigung;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return bool
     */
    public function isHasRole(): bool
    {
        return $this->hasRole;
    }

    /**
     * @param bool $hasRole
     */
    public function setHasRole(bool $hasRole): void
    {
        $this->hasRole = $hasRole;
    }

    /**
     * @return BackendAnwendung
     */
    public function getBackendAnwendung(): ?BackendAnwendung
    {
        return $this->backendAnwendung;
    }

    /**
     * @param BackendAnwendung $backendAnwendung
     */
    public function setBackendAnwendung(BackendAnwendung $backendAnwendung): void
    {
        $this->backendAnwendung = $backendAnwendung;
    }

    /**
     * @return Collection
     */
    public function getAccessibleRoles(): Collection
    {
        return $this->accessibleRoles;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getGroup(): ?string
    {
        return $this->group;
    }

    /**
     * @return bool
     */
    public function isSeeUserNames(): bool
    {
        return $this->seeUserNames;
    }
}
