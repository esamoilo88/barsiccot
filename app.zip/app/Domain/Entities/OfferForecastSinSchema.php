<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferForecastSinSchema
 *
 * @ORM\Table(name="Offer_Forecast_SIN_Schema", indexes={@ORM\Index(name="IDX_22B6EEDBEA1BEF35", columns={"schema_id"})})
 * @ORM\Entity
 */
class OfferForecastSinSchema
{
    /**
     * @ORM\Column(name="sin_schema_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $sinSchemaId;

    /** @ORM\Column(name="simple_id", type="bigint", nullable=false) */
    private int $simpleId;

    /**
     * @ORM\ManyToOne(targetEntity="OfferForecastSchema")
     * @ORM\JoinColumn(name="schema_id", referencedColumnName="schema_id")
     */
    private OfferForecastSchema $schema;

    /**
     * OfferForecastSinSchema constructor.
     * @param int $simpleId
     * @param OfferForecastSchema|object $schema
     */
    public function __construct(int $simpleId, OfferForecastSchema $schema)
    {
        $this->simpleId = $simpleId;
        $this->schema = $schema;
    }

    /**
     * @return int
     */
    public function getSinSchemaId(): int
    {
        return $this->sinSchemaId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @return OfferForecastSchema
     */
    public function getSchema(): OfferForecastSchema
    {
        return $this->schema;
    }

    /**
     * @param OfferForecastSchema|object $schema
     */
    public function setSchema(OfferForecastSchema $schema): void
    {
        $this->schema = $schema;
    }
}
