<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferFakturaLbuDatenSachkonto
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Daten_Sachkonto")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferFakturaLbuDatenSachkonto
{
    /**
     * @ORM\Column(name="konto_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $kontoId;

    /** @ORM\Column(name="sachkonto", type="integer", nullable=false) */
    private int $sachkonto = 0;

    /** @ORM\Column(name="partnergesellschaft", type="integer", nullable=false) */
    private int $partnergesellschaft = 0;

    /** @ORM\Column(name="sort", type="smallint", nullable=false) */
    private int $sort;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * @return int
     * @Groups({"orderBasic", "icp"})
     */
    public function getKontoId(): int
    {
        return $this->kontoId;
    }

    /**
     * @return int
     * @Groups({"orderBasic", "cbiOverview", "icp"})
     */
    public function getSachkonto(): int
    {
        return $this->sachkonto;
    }

    /**
     * @param int $sachkonto
     */
    public function setSachkonto(int $sachkonto): void
    {
        $this->sachkonto = $sachkonto;
    }

    /**
     * @return int
     * @Groups({"orderBasic", "cbiOverview", "icp"})
     */
    public function getPartnergesellschaft(): int
    {
        return $this->partnergesellschaft;
    }

    /**
     * @param int $partnergesellschaft
     */
    public function setPartnergesellschaft(int $partnergesellschaft): void
    {
        $this->partnergesellschaft = $partnergesellschaft;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return string|null
     */
    public function getDropdownItem(): ?string
    {
       return $this->sachkonto. '_' .$this->partnergesellschaft;
    }
}
