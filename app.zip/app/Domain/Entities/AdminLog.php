<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * AdminLog
 *
 * @ORM\Table(name="Admin_Log")
 * @ORM\Entity
 */
class AdminLog
{
    /**
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="aktion", type="text", length=-1, nullable=true)
     */
    private ?string $aktion;

    /**
     * @ORM\Column(name="bemerkung", type="string", length=250, nullable=true)
     */
    private ?string $bemerkung;

    /**
     * @ORM\Column(name="dateline", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $dateline;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $simple;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * AdminLog constructor.
     * @param GlobalGate $simple
     * @param BackendBenutzer $benutzer
     * @param string|null $aktion
     * @param string|null $bemerkung
     */
    public function __construct(GlobalGate $simple, BackendBenutzer $benutzer, ?string $aktion = null, ?string $bemerkung = null)
    {
        $this->simple = $simple;
        $this->benutzer = $benutzer;
        $this->aktion = $aktion;
        $this->bemerkung = $bemerkung;
    }


}
