<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OnkaMultieditFields
 * @ORM\Entity
 * @ORM\Table(name="Onka_Multiedit_Fields")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaMultieditFields
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(type="string", length=3, nullable=false) */
    private string $object;

    /** @ORM\Column(type="string", length=128, nullable=false) */
    private string $uiField;

    /** @ORM\Column(type="string", length=64, nullable=false) */
    private string $sysField;

    /** @ORM\Column(type="string", length=16, nullable=false) */
    private string $inputType;

    /** @ORM\Column(type="smallint", nullable=false) */
    private int $sort;

    /** @ORM\Column(type="boolean", nullable=false) */
    private bool $required;

    /** @ORM\Column(type="string", length=512, nullable=true) */
    private ?string $info;

    /** @ORM\Column(type="string", length=64, nullable=true) */
    private ?string $prefix;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getObject(): string
    {
        return $this->object;
    }

    /**
     * @param  string  $object
     */
    public function setObject(string $object): void
    {
        $this->object = $object;
    }

    /**
     * @return string
     */
    public function getUiField(): string
    {
        return $this->uiField;
    }

    /**
     * @param  string  $uiField
     */
    public function setUiField(string $uiField): void
    {
        $this->uiField = $uiField;
    }

    /**
     * @return string
     */
    public function getSysField(): string
    {
        return $this->sysField;
    }

    /**
     * @param  string  $sysField
     */
    public function setSysField(string $sysField): void
    {
        $this->sysField = $sysField;
    }

    /**
     * @return string
     */
    public function getInputType(): string
    {
        return $this->inputType;
    }

    /**
     * @param  string  $inputType
     */
    public function setInputType(string $inputType): void
    {
        $this->inputType = $inputType;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param  int  $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * @param  bool  $required
     */
    public function setRequired(bool $required): void
    {
        $this->required = $required;
    }

    /**
     * @return string|null
     */
    public function getInfo(): ?string
    {
        return $this->info;
    }

    /**
     * @param  string|null  $info
     */
    public function setInfo(?string $info): void
    {
        $this->info = $info;
    }

    /**
     * @return string|null
     */
    public function getPrefix(): ?string
    {
        return $this->prefix;
    }

    /**
     * @param  string|null  $prefix
     */
    public function setPrefix(?string $prefix): void
    {
        $this->prefix = $prefix;
    }
}
