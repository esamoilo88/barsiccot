<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Absender;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Carbon\Carbon;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Illuminate\Contracts\Auth\Authenticatable;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendBenutzer
 *
 * @ORM\Table(name="Backend_Benutzer")
 * @ORM\Entity
 */
class BackendBenutzer extends Absender implements Authenticatable
{
    /**
     * @ORM\Column(name="benutzer_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $benutzerId;

    /** @ORM\Column(name="username", type="string", length=50, nullable=true) */
    private ?string $username;

    /** @ORM\Column(name="passwort", type="string", length=100, nullable=true) */
    private ?string $passwort;

    /** @ORM\Column(name="anrede", type="string", length=20, nullable=true) */
    private ?string $anrede;

    /** @ORM\Column(name="vorname", type="string", length=100, nullable=true) */
    private ?string $vorname = null;

    /** @ORM\Column(name="nachname", type="string", length=100, nullable=true) */
    private ?string $nachname = null;

    /** @ORM\Column(name="firma", type="text", length=-1, nullable=true) */
    private ?string $firma;

    /** @ORM\Column(name="ressort", type="text", length=-1, nullable=true) */
    private ?string $ressort;

    /** @ORM\Column(name="org_einheit", type="text", length=-1, nullable=true) */
    private ?string $orgEinheit;

    /** @ORM\Column(name="email", type="string", length=255, nullable=true) */
    private ?string $email;

    /** @ORM\Column(name="pw_letzte_aenderung", type="datetime", nullable=true) */
    private ?\DateTime $pwLetzteAenderung;

    /** @ORM\Column(name="pw_gesendet_am", type="datetime", nullable=true) */
    private ?\DateTime $pwGesendetAm;

    /** @ORM\Column(name="change_pass", type="boolean", nullable=true) */
    private ?bool $changePass;

    /** @ORM\Column(name="blocked", type="boolean", nullable=true) */
    private ?bool $blocked;

    /** @ORM\Column(name="user_informiert", type="boolean", nullable=true) */
    private ?bool $userInformiert;

    /** @ORM\Column(name="is_admin", type="boolean", nullable=true) */
    private ?bool $isAdmin;

    /** @ORM\Column(name="login_count", type="integer", nullable=true) */
    private ?int $loginCount;

    /** @ORM\Column(name="internal_notes", type="string", nullable=true) */
    private ?string $internalNotes = null;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?\DateTime $created;

    /**
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="update")
     */
    private ?\DateTime $modified;

    /** @ORM\Column(name="tel_nr", type="string", length=50, nullable=true) */
    private ?string $telNr = null;

    /** @ORM\Column(name="ccf_terms", type="boolean", nullable=false) */
    private bool $ccfTerms = false;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBereich")
     * @ORM\JoinColumn(name="bereich_id", referencedColumnName="bereich_id")
     */
    private ?BackendBereich $bereich = null;

    /**
     * @ORM\ManyToMany(targetEntity="BackendRechte", fetch="EAGER")
     * @ORM\JoinTable(name="Backend_BenutzerPermissions",
     *     joinColumns={@ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")},
     *     inverseJoinColumns={@ORM\JoinColumn(name="rechte_id", referencedColumnName="rechte_id")}
     * )
     */
    private Collection $backendRechtes;

    /**
     * @ORM\OneToMany(targetEntity="BackendProjectRoles", mappedBy="backendBenutzer")
     */
    private Collection $backendProjectRoles;

    /**
     * @ORM\OneToMany(targetEntity="BackendBenutzerGroup", mappedBy="benutzer")
     */
    private Collection $backendBenutzerGroup;

    /**
     * @ORM\ManyToMany(targetEntity="BackendGroup", fetch="EAGER")
     * @ORM\JoinTable(name="Backend_Benutzer_Group",
     *     joinColumns={@ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")},
     *     inverseJoinColumns={@ORM\JoinColumn(name="group_id", referencedColumnName="id")}
     * )
     */
    private Collection $backendGroup;

    /** @ORM\OneToOne(targetEntity="BackendBenutzerLogin", mappedBy="user") */
    private ?BackendBenutzerLogin $lastLogin;

    private const TEMPORAL_PASSWORD_EXPIRED_IN_HOURS = 24;
    private const BASE_PASSWORD_EXPIRED_IN_DAYS = 90;

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return Collection
     */
    public function getBackendRechtes(): Collection
    {
        return $this->backendRechtes;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return Collection
     */
    public function getBackendGroup(): Collection
    {
        return $this->backendGroup;
    }

    /**
     * @return int
     */
    public function benutzerId(): int
    {
        return $this->benutzerId;
    }


    /**
     * @return string|null
     */
    public function username(): ?string
    {
        return $this->username;
    }

    /**
     * @param string|null $username
     */
    public function setUsername(?string $username): void
    {
        $this->username = $username;
    }

    /**
     * @return string
     */
    public function password(): string
    {
        return $this->passwort;
    }

    /**
     * @param string $password
     */
    public function setPassword(string $password): void
    {
        $this->passwort = $password;
    }

    /**
     * @return string|null
     */
    public function anrede(): ?string
    {
        return $this->anrede;
    }

    /**
     * @param string|null $anrede
     */
    public function setAnrede(?string $anrede): void
    {
        $this->anrede = $anrede;
    }

    /**
     * @return string|null
     */
    public function vorname(): ?string
    {
        return $this->vorname;
    }

    /**
     * @param string|null $vorname
     */
    public function setVorname(?string $vorname): void
    {
        $this->vorname = $vorname;
    }

    /**
     * @return string|null
     */
    public function nachname(): ?string
    {
        return $this->nachname;
    }

    /**
     * @param string|null $nachname
     */
    public function setNachname(?string $nachname): void
    {
        $this->nachname = $nachname;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getFullName(): string
    {
        return $this->vorname . ' ' . $this->nachname;
    }

    /**
     * @return string
     * @Groups({"pspDetails"})
     */
    public function getLastNameFirstName(): string
    {
        return $this->nachname . ', ' . $this->vorname;
    }

    /**
     * @return string|null
     */
    public function getFirma(): ?string
    {
        return $this->firma;
    }

    /**
     * @param string|null $firma
     */
    public function setFirma(?string $firma): void
    {
        $this->firma = $firma;
    }

    /**
     * @return string|null
     */
    public function ressort(): ?string
    {
        return $this->ressort;
    }

    /**
     * @param string|null $ressort
     */
    public function setRessort(?string $ressort): void
    {
        $this->ressort = $ressort;
    }

    /**
     * @return string|null
     */
    public function orgEinheit(): ?string
    {
        return $this->orgEinheit;
    }

    /**
     * @param string|null $orgEinheit
     */
    public function setOrgEinheit(?string $orgEinheit): void
    {
        $this->orgEinheit = $orgEinheit;
    }

    /**
     * @return string|null
     * @Groups({"onkaApprovalItems", "orderBasic", "UserInfoWidget", "userProfile"})
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @param string|null $email
     */
    public function setEmail(?string $email): void
    {
        $this->email = $email;
    }

    /**
     * @Groups({"userProfile"})
     * @return DateTime|null
     */
    public function getPwLetzteAenderung(): ?DateTime
    {
        return $this->pwLetzteAenderung;
    }

    public function setPwLetzteAenderung(): void
    {
        $this->pwLetzteAenderung = new DateTime();
    }

    /**
     * @Groups({"userProfile"})
     * @return DateTime|null
     */
    public function getPwGesendetAm(): ?DateTime
    {
        return $this->pwGesendetAm;
    }

    public function setPwGesendetAm(): void
    {
        $this->pwGesendetAm = new DateTime();
    }

    public function dropPwGesendetAm(): void
    {
        $this->pwGesendetAm = null;
    }

    /**
     * @return bool
     */
    public function isTemporalPasswordExpired(): bool
    {
        return Carbon::now()->diffInHours($this->pwGesendetAm) > self::TEMPORAL_PASSWORD_EXPIRED_IN_HOURS;
    }

    /**
     * @return bool
     */
    public function isBasePasswordExpired(): bool
    {
        if (Carbon::instance($this->pwLetzteAenderung)->isFuture() || $this->pwLetzteAenderung === null) {
            return  false;
        }
        return Carbon::now()->diffInDays($this->pwLetzteAenderung) > self::BASE_PASSWORD_EXPIRED_IN_DAYS;
    }

    /**
     * @return bool|null
     */
    public function isChangePass(): ?bool
    {
        return $this->changePass;
    }

    public function setChangePass(bool $value): void
    {
        $this->changePass = $value;
    }

    /**
     * @return bool|null
     */
    public function blocked(): ?bool
    {
        return $this->blocked;
    }

    /**
     * @param bool|null $blocked
     */
    public function setBlocked(?bool $blocked): void
    {
        $this->blocked = $blocked;
    }

    /**
     * @return bool|null
     */
    public function userInformiert(): ?bool
    {
        return $this->userInformiert;
    }

    /**
     * @param bool|null $userInformiert
     */
    public function setUserInformiert(?bool $userInformiert): void
    {
        $this->userInformiert = $userInformiert;
    }

    /**
     * @return bool|null
     */
    public function isAdmin(): ?bool
    {
        return $this->isAdmin;
    }

    /**
     * @param bool|null $isAdmin
     */
    public function setIsAdmin(?bool $isAdmin): void
    {
        $this->isAdmin = $isAdmin;
    }

    /**
     * @return int|null
     */
    public function loginCount(): ?int
    {
        return $this->loginCount;
    }

    /**
     * @param int|null $loginCount
     */
    public function setLoginCount(?int $loginCount): void
    {
        $this->loginCount = $loginCount;
    }

    /**
     * @Groups({"userProfile"})
     * @return \DateTime|null
     */
    public function getCreated(): ?\DateTime
    {
        return $this->created;
    }

    /**
     * @param \DateTime|null $created
     */
    public function setCreated(?\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @Groups({"userProfile"})
     * @return \DateTime|null
     */
    public function getModified(): ?\DateTime
    {
        return $this->modified;
    }

    public function setModified(): void
    {
        $this->modified = new DateTime();
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return string|null
     */
    public function getTelNr(): ?string
    {
        return $this->telNr;
    }

    /**
     * @param string|null $telNr
     */
    public function setTelNr(?string $telNr): void
    {
        $this->telNr = $telNr;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return BackendBereich|null
     */
    public function getBereich(): ?BackendBereich
    {
        return $this->bereich;
    }

    /**
     * @param BackendBereich|null $bereich
     */
    public function setBereich(?BackendBereich $bereich): void
    {
        $this->bereich = $bereich;
    }

    /**
     * @return string
     */
    public function getAuthIdentifierName(): string
    {
        return $this->username;
    }

    /**
     * @return int
     */
    public function getAuthIdentifier(): int
    {
        return $this->benutzerId;
    }

    /**
     * @return string|null
     */
    public function getAuthPassword(): ?string
    {
        return $this->passwort;
    }

    /**
     * @return string|void
     */
    public function getRememberToken()
    {
        // TODO: Implement getRememberToken() method.
    }

    /**
     * @param string $value
     */
    public function setRememberToken($value)
    {
        // TODO: Implement setRememberToken() method.
    }

    /**
     * @return string|void
     */
    public function getRememberTokenName()
    {
        // TODO: Implement getRememberTokenName() method.
    }

    /**
     * @return bool
     */
    public function isBlocked(): bool
    {
        return (bool)$this->blocked;
    }

    /**
     * @param int $countNumber
     * @return bool
     */
    public function isAttemptCountMoreThen(int $countNumber): bool
    {
        return $this->loginCount === $countNumber;
    }

    /**
     * @return $this
     */
    public function increaseAttemptCount(): BackendBenutzer
    {
        $this->loginCount++;

        return $this;
    }

    /**
     * If attempt number is exceeded - we block a user
     * @param int $maxAttemptNumber
     * @return $this
     */
    public function blockIfAttemptsExceeded(int $maxAttemptNumber): BackendBenutzer
    {
        if ($this->loginCount >= $maxAttemptNumber) {
            $this->blocked = true;
        }

        return $this;
    }

    /**
     * Reset auth attempts number
     */
    public function dropAttemptCount()
    {
        $this->loginCount = null;
    }

    /**
     * @return string
     */
    public function getEmailSalutation(): string
    {
        switch(strtolower($this->anrede)) {
            case 'herr': return 'Sehr geehrter Herr ' . $this->nachname;
            case 'frau': return 'Sehr geehrte Frau ' . $this->nachname;
            default: return 'Sehr geehrter Herr/Frau ' . $this->vorname . ' ' . $this->nachname;
        }
    }

    /**
     * @return string
     */
    public function getSalutation(): string
    {
        return sprintf('%s %s', $this->vorname, $this->nachname);
    }

    /**
     * @return string
     * @Groups({"onkaApprovalItems"})
     */
    public function getSurnameNameDividedByComma(): string
    {
        return sprintf('%s, %s', $this->nachname, $this->vorname);
    }

    /**
     * @return bool
     */
    public function isAdminOrHasRolePermission(): bool
    {
        return $this->isAdmin() || $this->hasRolePermission();
    }

    /**
     * @return bool
     */
    public function hasRolePermission(): bool
    {
        $permissions = $this->getBackendRechtes();

        $result = $permissions->filter(function($item) {
            return $item->hasRole();
        });

        return !$result->isEmpty();
    }

    /**
     * @return bool
     */
    public function hasAePermission(): bool
    {
        return !$this->getBackendRechtes()->filter(function (BackendRechte $rechte) {
            return $rechte->getBezeichnung() === config('dbconfig.roles.ANGEBOTSERSTELLER_LONG_NAME');
        })->isEmpty();
    }

    /**
     * @return Collection
     */
    public function getBackendProjectRoles(): Collection
    {
        return $this->backendProjectRoles;
    }

    /**
     * @param  Collection  $backendProjectRoles
     */
    public function setBackendProjectRoles(Collection $backendProjectRoles): void
    {
        $this->backendProjectRoles = $backendProjectRoles;
    }

    /**
     * @return int
     * @Groups({"orderBasic", "userProfile", "icp"})
     */
    public function getBenutzerId(): int
    {
        return $this->benutzerId;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile"})
     * @return string|null
     */
    public function getUsername(): ?string
    {
        return $this->username;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getVorname(): ?string
    {
        return $this->vorname;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getNachname(): ?string
    {
        return $this->nachname;
    }

    /**
     * Check if user has a specific permission
     * @param int $permissionId
     * @return bool
     */
    public function hasPermission(int $permissionId): bool
    {
        $permissions = $this->getBackendRechtes();
        /** @var BackendRechte $p */
        foreach ($permissions as $p) {
            if ($p->getRechteId() === $permissionId) {
                return true;
            }
        }
        return false;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getAnrede(): ?string
    {
        return $this->anrede;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getOrgEinheit(): ?string
    {
        return $this->orgEinheit;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getRessort(): ?string
    {
        return $this->ressort;
    }

    /**
     * @Groups({"userProfile"})
     * @return bool
     */
    public function isCcfTerms(): bool
    {
        return $this->ccfTerms;
    }

    /**
     * @param bool $ccfTerms
     */
    public function setCcfTerms(bool $ccfTerms): void
    {
        $this->ccfTerms = $ccfTerms;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string
     */
    public function getNachnameVornameTel(): string
    {
        return "{$this->nachname}, {$this->vorname}#{$this->telNr}";
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string
     */
    public function getNachnameVorname(): string
    {
        return "{$this->nachname}, {$this->vorname}";
    }

    /**
     * @return string|null
     */
    public function getInternalNotes(): ?string
    {
        return $this->internalNotes;
    }

    /**
     * @param string|null $internalNotes
     */
    public function setInternalNotes(?string $internalNotes): void
    {
        $this->internalNotes = $internalNotes;
    }

    /**
     * @return int|null
     */
    public function getLoginCount(): ?int
    {
        return $this->loginCount;
    }

    /**
     * @return bool|null
     */
    public function getUserInformiert(): ?bool
    {
        return $this->userInformiert;
    }

    /**
     * @Groups({"userProfile"})
     * @return BackendBenutzerLogin|null
     */
    public function getLastLogin(): ?BackendBenutzerLogin
    {
        return $this->lastLogin;
    }

    /**
     * @param BackendBenutzerLogin|null $lastLogin
     */
    public function setLastLogin(?BackendBenutzerLogin $lastLogin): void
    {
        $this->lastLogin = $lastLogin;
    }

    /**
     * @return bool
     */
    public function isBackendBenutzer(): bool
    {
        return true;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->getBenutzerId();
    }
}
