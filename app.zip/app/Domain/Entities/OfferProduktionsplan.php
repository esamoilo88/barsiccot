<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferProduktionsplan
 *
 * @ORM\Table(name="Offer_Produktionsplan")
 * @ORM\Entity
 */
class OfferProduktionsplan
{
    /**
     * @var int|null
     *
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private $ofiLa;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=255, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="planzeit", type="decimal", precision=10, scale=2, nullable=true)
     */
    private $planzeit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ilv_faktor", type="decimal", precision=18, scale=0, nullable=true)
     */
    private $ilvFaktor;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="smallint", nullable=false)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="disabled", type="boolean", nullable=false)
     */
    private $disabled;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kurzbeschreibung", type="text", length=-1, nullable=true)
     */
    private $kurzbeschreibung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="langbeschreibung", type="text", length=-1, nullable=true)
     */
    private $langbeschreibung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="ma", type="boolean", nullable=true)
     */
    private $ma;

    /**
     * @var string|null
     *
     * @ORM\Column(name="myshs_hash", type="string", length=32, nullable=true)
     */
    private $myshsHash;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="myshs_hash_check", type="boolean", nullable=true)
     */
    private $myshsHashCheck;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kosten_ilv", type="decimal", precision=38, scale=2, nullable=true)
     */
    private $kostenIlv;

    /**
     * @var \CostsKostenart
     *
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     * })
     */
    private $kostenart;

    /**
     * @var \OfferKalkulationAngebotsposition
     *
     * @ORM\ManyToOne(targetEntity="OfferKalkulationAngebotsposition")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="angebotsposition_id")
     * })
     */
    private $angebotsposition;

    /**
     * @var \OfferKalkulationLeistungsposition
     *
     * @ORM\ManyToOne(targetEntity="OfferKalkulationLeistungsposition")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     * })
     */
    private $leistungsposition;

    /**
     * @var \OfferProduktionsplan
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="OfferProduktionsplan")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="produktionsplan_id", referencedColumnName="produktionsplan_id")
     * })
     */
    private $produktionsplan;

    /**
     * @var \OfferVerrechnungsart
     *
     * @ORM\ManyToOne(targetEntity="OfferVerrechnungsart")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="verrechnungsart_id", referencedColumnName="verrechnungsart_id")
     * })
     */
    private $verrechnungsart;

    /**
     * @var \OfferVirtuellesProdukt
     *
     * @ORM\ManyToOne(targetEntity="OfferVirtuellesProdukt")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vp_id", referencedColumnName="vp_id")
     * })
     */
    private $vp;


}
