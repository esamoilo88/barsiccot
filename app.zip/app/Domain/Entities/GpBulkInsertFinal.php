<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * GpBulkInsertFinal
 *
 * @ORM\Table(name="gp_bulk_insert_final", uniqueConstraints={@ORM\UniqueConstraint(name="UC_CRM_GP_BULK", columns={"gp_nr"})})
 * @ORM\Entity
 */
class GpBulkInsertFinal
{
    /**
     * @var int
     *
     * @ORM\Column(name="gp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $gpId;

    /**
     * @var int
     *
     * @ORM\Column(name="gp_nr", type="bigint", nullable=false)
     */
    private $gpNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_name_lang", type="string", length=200, nullable=true)
     */
    private $gpNameLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_plz", type="string", length=10, nullable=true)
     */
    private $gpPlz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_ort", type="string", length=200, nullable=true)
     */
    private $gpOrt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ust_id", type="string", length=32, nullable=true)
     */
    private $ustId;

    /**
     * @var bool
     *
     * @ORM\Column(name="is_active", type="boolean", nullable=false)
     */
    private $isActive;

    /**
     * @var string|null
     *
     * @ORM\Column(name="segment", type="string", length=20, nullable=true)
     */
    private $segment;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_id", type="string", length=10, nullable=true)
     */
    private $wzId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_bezeichnung", type="text", length=-1, nullable=true)
     */
    private $wzBezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_id", type="string", length=50, nullable=true)
     */
    private $zgId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_bezeichnung", type="text", length=-1, nullable=true)
     */
    private $zgBezeichnung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;


}
