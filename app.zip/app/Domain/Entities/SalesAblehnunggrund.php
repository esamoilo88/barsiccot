<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesAblehnunggrund
 *
 * @ORM\Table(name="Sales_AblehnungGrund")
 * @ORM\Entity
 */
class SalesAblehnunggrund
{
    /**
     * @ORM\Column(name="ablehnungGrund_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $ablehnunggrundId;

    /**
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private ?string $bezeichnung;

    /**
     * @ORM\Column(name="hide", type="boolean")
     */
    private bool $hide;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @ORM\Column(name="parent_id", type="integer", nullable=true)
     */
    private ?int $parentId;

    /**
     * SalesAblehnunggrund constructor.
     * @param string|null $bezeichnung
     * @param int|null $parentId
     * @param bool $hide
     */
    public function __construct(
        ?string $bezeichnung = null,
        ?int $parentId = null,
        bool $hide = false
    )
    {
        $this->bezeichnung = $bezeichnung;
        $this->parentId = $parentId;
        $this->hide = $hide;
    }


    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->ablehnunggrundId;
    }

    /**
     * @return string|null
     */
    public function getTitle(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int|null
     */
    public function getParentId(): ?int
    {
        return $this->parentId;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }
}
