<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Backend_Widgets_Users")
 * @ORM\Entity
 */
class BackendWidgetsUsers
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $user;

    /**
     * @ORM\ManyToOne(targetEntity="BackendWidgets")
     * @ORM\JoinColumn(name="widget_id", referencedColumnName="id")
     */
    private BackendWidgets $widget;

    /** @ORM\Column(name="sort", type="integer", nullable=true) */
    private ?int $sort;

    /**
     * BackendWidgetsUsers constructor.
     * @param BackendBenutzer $user
     * @param BackendWidgets|object $widget
     * @param int $sort
     */
    public function __construct(BackendBenutzer $user, BackendWidgets $widget, int $sort = 1)
    {
        $this->user = $user;
        $this->widget = $widget;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @param BackendBenutzer $user
     */
    public function setUser(BackendBenutzer $user): void
    {
        $this->user = $user;
    }

    /**
     * @return BackendWidgets
     */
    public function getWidget(): BackendWidgets
    {
        return $this->widget;
    }

    /**
     * @param BackendWidgets $widget
     */
    public function setWidget(BackendWidgets $widget): void
    {
        $this->widget = $widget;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }
}
