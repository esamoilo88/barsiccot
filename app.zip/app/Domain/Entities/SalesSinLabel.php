<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * SalesSinLabel
 *
 * @ORM\Table(name="Sales_SIN_Label")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class SalesSinLabel
{
    /**
     * @var int
     *
     * @ORM\Column(name="sin_label_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $sinLabelId;

    /**
     * @ORM\ManyToOne (targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="bigint", nullable=false)
     */
    private int $simpleId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="prozent", type="smallint", nullable=true)
     */
    private ?int $prozent;

    /**
     * @var SalesLabel
     *
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="label_id", referencedColumnName="label_id")
     * })
     */
    private SalesLabel $label;

    /**
     * SalesSinLabel constructor.
     * @param SalesStammdaten $stammdaten
     * @param SalesLabel $label
     * @param int|null $prozent
     */
    public function __construct(SalesStammdaten $stammdaten, SalesLabel $label, ?int $prozent = null)
    {
        $this->label    = $label;
        $this->prozent  = $prozent;
        $this->salesStammdaten = $stammdaten;
    }

    /**
     * @return int
     */
    public function getSinLabelId(): int
    {
        return $this->sinLabelId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @return int|null
     */
    public function getProzent(): ?int
    {
        return $this->prozent;
    }

    /**
     * @param int|null $prozent
     */
    public function setProzent(?int $prozent): void
    {
        $this->prozent = $prozent;
    }

    /**
     * @return SalesLabel
     */
    public function getLabel(): SalesLabel
    {
        return $this->label;
    }

    /**
     * @return int
     */
    public function getLabelId(): int
    {
        return $this->label->getLabelId();
    }

    /**
     * @return bool
     */
    public function isIsIksl(): bool
    {
        return $this->label->isIsiksl();
    }

    /**
     * @param SalesLabel $label
     */
    public function setLabel(SalesLabel $label): void
    {
        $this->label = $label;
    }
}
