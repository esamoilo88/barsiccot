<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use App\Domain\Annotations\SystemProtocol as SP;

/**
 * @ORM\Table(name="Offer_Kalkulation_Variable")
 * @ORM\Entity
 * @ORM\EntityListeners({"App\Domain\Listeners\SystemProtocol\SystemProtocolListener"})
 * @SP(
 *   messages={
 *     "created"="Variable angelegt",
 *     "updated"="Variable bearbeitet",
 *     "removed"="Variable gelöscht"
 *   },
 *   group="VAR"
 * )
 */
class OfferKalkulationVariable implements Loggable
{
    /**
     * @ORM\Column(name="variable_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $variableId;

    /** @ORM\Column(name="angebotsposition_id", type="bigint", nullable=true) */
    private ?int $angebotspositionId;

    /** @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="summenbezeichnung", type="text", length=-1, nullable=true) */
    private ?string $summenbezeichnung;

    /** @ORM\Column(name="wert", type="decimal", precision=18, scale=10, nullable=false) */
    private string $wert;

    /** @ORM\Column(name="sum", type="boolean", nullable=false) */
    private bool $sum;

    /** @ORM\Column(name="kommentar", type="text", length=-1, nullable=true) */
    private ?string $kommentar;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private ?OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private SalesStammdaten $simple;

    /**
     * OfferKalkulationVariable constructor.
     * @param SalesStammdaten $simple
     * @param OfferAngebotVk|null $vkVersions
     * @param string|null $bezeichnung
     * @param string $wert
     * @param bool $sum
     * @param BackendBenutzer $benutzer
     */
    public function __construct(
        SalesStammdaten $simple,
        ?OfferAngebotVk $vkVersions,
        ?string $bezeichnung,
        string $wert,
        bool $sum,
        BackendBenutzer $benutzer
    )
    {
        $this->simple = $simple;
        $this->vkVersions = $vkVersions;
        $this->bezeichnung = $bezeichnung;
        $this->wert = $wert;
        $this->sum = $sum;
        $this->benutzer = $benutzer;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return int
     */
    public function getVariableId(): int
    {
        return $this->variableId;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @param  int|null  $angebotspositionId
     */
    public function setAngebotspositionId(?int $angebotspositionId): void
    {
        $this->angebotspositionId = $angebotspositionId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param  string|null  $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSummenbezeichnung(): ?string
    {
        return $this->summenbezeichnung;
    }

    /**
     * @param  string|null  $summenbezeichnung
     */
    public function setSummenbezeichnung(?string $summenbezeichnung): void
    {
        $this->summenbezeichnung = $summenbezeichnung;
    }

    /**
     * @return string
     */
    public function getWert(): string
    {
        return $this->wert;
    }

    /**
     * @param string $wert
     */
    public function setWert(string $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @return bool
     */
    public function isSum(): bool
    {
        return $this->sum;
    }

    /**
     * @param  bool  $sum
     */
    public function setSum(bool $sum): void
    {
        $this->sum = $sum;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @param  string|null  $kommentar
     */
    public function setKommentar(?string $kommentar): void
    {
        $this->kommentar = $kommentar;
    }

    /**
     * @return \DateTime
     */
    public function getCreated(): \DateTime
    {
        return $this->created;
    }

    /**
     * @param  \DateTime  $created
     */
    public function setCreated(\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getModified(): \DateTime
    {
        return $this->modified;
    }

    /**
     * @param  \DateTime  $modified
     */
    public function setModified(\DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param  \DateTime|null  $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @param  BackendBenutzer  $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @param  OfferAngebotVk  $vkVersions
     */
    public function setVkVersions(OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @param  SalesStammdaten  $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    ////
    // SystemProtocol functions START
    ////

    /**
     * @return SIN
     * @throws InvalidSinException
     * @throws \Exception
     */
    public function getSin(): SIN
    {
        return new SIN($this->simple->getSimpleId());
    }

    /**
     * @return string
     */
    public function getSystemProtocolObjectName(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSystemProtocolParentName(): ?string
    {
        return null;
    }

    ////
    // SystemProtocol functions END
    ////
}
