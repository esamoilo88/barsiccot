<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmKunden
 *
 * @ORM\Table(name="RM_Kunden")
 * @ORM\Entity
 */
class RmKunden
{
    /**
     * @var int
     *
     * @ORM\Column(name="kunden_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $kundenId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kundenname", type="string", length=150, nullable=true)
     */
    private $kundenname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kundennummer", type="string", length=150, nullable=true)
     */
    private $kundennummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tdn_tlan_nr", type="string", length=50, nullable=true)
     */
    private $tdnTlanNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertragspartner_nr", type="string", length=150, nullable=true)
     */
    private $vertragspartnerNr;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
