<?php

namespace App\Domain\Entities\Interfaces;

abstract class Absender
{
    public abstract function getEmail(): ?string;
    public abstract function getSalutation(): string;
    public abstract function isBackendBenutzer(): bool;
    public abstract function getId(): int;

}
