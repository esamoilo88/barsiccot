<?php

namespace App\Domain\Entities\Interfaces;

use App\Domain\ValueObjects\SIN;

/**
 * Interface Loggable - represents an entity which can be used
 * in the "System Protocol" feature
 * @package App\Domain\Entities\Interfaces
 */
interface Loggable
{
    public function getSin(): SIN;
    public function getSystemProtocolObjectName(): string;
    public function getSystemProtocolParentName(): ?string;
}
