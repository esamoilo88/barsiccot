<?php

namespace App\Domain\Entities\Interfaces;

interface Automailable
{
    /**
     * @return array
     */
    public function toArray(): array;
}