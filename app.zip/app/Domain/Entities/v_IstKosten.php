<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Istkosten")
 */
class v_IstKosten
{
    /**
     * @ORM\Column(name="kosten_id", type="integer")
     * @ORM\Id
     */
    private int $kostenId;

    /** @ORM\Column(name="quellsystem_bezeichnung", type="string", nullable=true) */
    private ?string $quellsystemBezeichnung;

    /** @ORM\Column(name="bemerkungen", type="string") */
    private string $bemerkungen;

    /** @ORM\Column(name="ofi_la", type="integer", nullable=true) */
    private ?string $ofiLa;

    /** @ORM\Column(name="created", type="datetime", nullable=true) */
    private ?DateTime $created;
}
