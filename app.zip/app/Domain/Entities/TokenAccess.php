<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Illuminate\Support\Carbon;

/**
 * @ORM\Table(name="Token_Access")
 * @ORM\Entity
 */
class TokenAccess
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="token", type="string", length=64) */
    private string $token;

    /** @ORM\Column(name="route", type="string", length=128, nullable=true) */
    private ?string $route;

    /** @ORM\Column(name="payload", type="string") */
    private string $payload = '';

    /** @ORM\Column(name="expiration", type="datetime", nullable=true) */
    private ?DateTime $expiration;

    /**
     * @ORM\Column(name="issued_at", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $issuedAt;

    /**
     * TokenAccess constructor.
     * @param string $token
     * @param string|null $route
     * @param string $payload
     * @param Carbon|null $expirationTime
     */
    public function __construct(string $token, ?string $route, string $payload, ?Carbon $expirationTime)
    {
        $this->token = $token;
        $this->route = $route;
        $this->payload = $payload;
        $this->expiration = $expirationTime;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getToken(): string
    {
        return $this->token;
    }

    /**
     * @return string|null
     */
    public function getRoute(): ?string
    {
        return $this->route;
    }

    /**
     * @return string
     */
    public function getPayload(): string
    {
        return $this->payload;
    }

    /**
     * @return DateTime|null
     */
    public function getExpiration(): ?DateTime
    {
        return $this->expiration;
    }

    /**
     * @return DateTime
     */
    public function getIssuedAt(): DateTime
    {
        return $this->issuedAt;
    }

    /**
     * @return bool
     */
    public function isExpired(): bool
    {
        if (!$this->expiration) {
            return false;
        }
        $now = Carbon::now();
        return $now->gte($this->expiration);
    }
}
