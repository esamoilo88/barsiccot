<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaAutofaktura
 *
 * @ORM\Table(name="Offer_Faktura_Autofaktura")
 * @ORM\Entity
 */
class OfferFakturaAutofaktura
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="event", type="string", length=36, nullable=true)
     */
    private $event;

    /**
     * @var bool
     *
     * @ORM\Column(name="result", type="boolean", nullable=false)
     */
    private $result;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="timestamp", type="datetime", nullable=false)
     */
    private $timestamp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="message", type="text", length=-1, nullable=true)
     */
    private $message;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
