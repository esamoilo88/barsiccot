<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtLbuDaten
 *
 * @ORM\Table(name="ext_LBU_Daten")
 * @ORM\Entity
 */
class ExtLbuDaten
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="angebotsposition_id", type="bigint", nullable=true)
     */
    private $angebotspositionId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorgangs_ticket_nr", type="string", length=255, nullable=true)
     */
    private $vorgangsTicketNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="angebotsposition", type="string", length=255, nullable=true)
     */
    private $angebotsposition;

    /**
     * @var string|null
     *
     * @ORM\Column(name="leistungsort", type="string", length=255, nullable=true)
     */
    private $leistungsort;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="leistungstermin", type="date", nullable=false)
     */
    private $leistungstermin;

    /**
     * @var string|null
     *
     * @ORM\Column(name="menge", type="decimal", precision=24, scale=12, nullable=true)
     */
    private $menge;

    /**
     * @var string
     *
     * @ORM\Column(name="einzelpreis_dtts", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $einzelpreisDtts;

    /**
     * @var string
     *
     * @ORM\Column(name="transferpreis_dtts", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $transferpreisDtts;

    /**
     * @var string
     *
     * @ORM\Column(name="einzelpreis_dtag", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $einzelpreisDtag;

    /**
     * @var string
     *
     * @ORM\Column(name="transferpreis_dtag", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $transferpreisDtag;

    /**
     * @var string|null
     *
     * @ORM\Column(name="installationsbemerkung", type="text", length=-1, nullable=true)
     */
    private $installationsbemerkung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ozt", type="string", length=50, nullable=true)
     */
    private $ozt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sap_bestellnummer", type="string", length=150, nullable=true)
     */
    private $sapBestellnummer;

    /**
     * @var string
     *
     * @ORM\Column(name="einzelpreis_dtts_original", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $einzelpreisDttsOriginal;

    /**
     * @var string
     *
     * @ORM\Column(name="einzelpreis_dtag_original", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $einzelpreisDtagOriginal;

    /**
     * @var string
     *
     * @ORM\Column(name="transferpreis_dtts_original", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $transferpreisDttsOriginal;

    /**
     * @var string
     *
     * @ORM\Column(name="transferpreis_dtag_original", type="decimal", precision=12, scale=2, nullable=false)
     */
    private $transferpreisDtagOriginal;

    /**
     * @var string|null
     *
     * @ORM\Column(name="preisnachlass", type="decimal", precision=18, scale=7, nullable=true)
     */
    private $preisnachlass;

    /**
     * @var string|null
     *
     * @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true)
     */
    private $icpKontPspKst;

    /**
     * @var int|null
     *
     * @ORM\Column(name="icp_kont_bpos", type="integer", nullable=true)
     */
    private $icpKontBpos;

    /**
     * @var string|null
     *
     * @ORM\Column(name="psp_element", type="string", length=50, nullable=true)
     */
    private $pspElement;

    /**
     * @var int|null
     *
     * @ORM\Column(name="mat_nr", type="integer", nullable=true)
     */
    private $matNr;

    /**
     * @var \OfferFakturaLbuDatenSachkonto
     *
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenSachkonto")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="icp_kont_konto_id", referencedColumnName="konto_id")
     * })
     */
    private $icpKontKonto;


}
