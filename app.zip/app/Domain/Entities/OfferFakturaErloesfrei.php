<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaErloesfrei
 *
 * @ORM\Table(name="Offer_Faktura_Erloesfrei")
 * @ORM\Entity
 */
class OfferFakturaErloesfrei
{
    /**
     * @var int
     *
     * @ORM\Column(name="erloesfrei_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $erloesfreiId;

    /**
     * @var int
     *
     * @ORM\Column(name="faktura_jahr", type="smallint", nullable=false)
     */
    private $fakturaJahr;

    /**
     * @var int
     *
     * @ORM\Column(name="faktura_monat", type="smallint", nullable=false)
     */
    private $fakturaMonat;

    /**
     * @var string|null
     *
     * @ORM\Column(name="grund", type="text", length=-1, nullable=true)
     */
    private $grund;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferAuftrag
     *
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
