<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendRoles
 *
 * @ORM\Table(name="Backend_Benutzer_Group")
 * @ORM\Entity
 */
class BackendBenutzerGroup
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="BackendGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private BackendGroup $group;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * BackendBenutzerGroup constructor.
     * @param BackendBenutzer $benutzer
     * @param BackendGroup $group
     */
    public function __construct(BackendBenutzer $benutzer, BackendGroup $group)
    {
        $this->benutzer = $benutzer;
        $this->group = $group;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return BackendGroup
     */
    public function getGroup(): BackendGroup {
        return $this->group;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param BackendGroup $group
     */
    public function setGroup(BackendGroup $group): void
    {
        $this->group = $group;
    }
}
