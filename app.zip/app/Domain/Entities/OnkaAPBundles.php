<?php


namespace App\Domain\Entities;


use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaAPBundles
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_AP_Bundles")
 */
class OnkaAPBundles
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="kat_angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $katAngebotsposition;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="bundle_angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $bundleAngebotsposition;

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferKatalogAngebotsposition
     */
    public function getKatAngebotsposition(): OfferKatalogAngebotsposition
    {
        return $this->katAngebotsposition;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferKatalogAngebotsposition
     */
    public function getBundleAngebotsposition(): OfferKatalogAngebotsposition
    {
        return $this->bundleAngebotsposition;
    }


}
