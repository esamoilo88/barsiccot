<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesAngebotTp
 *
 * @ORM\Table(name="Sales_Angebot_TP")
 * @ORM\Entity
 */
class SalesAngebotTp
{
    /**
     * @var int
     *
     * @ORM\Column(name="tp_versions_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $tpVersionsId;

    /**
     * @var int
     *
     * @ORM\Column(name="versionsnr", type="smallint", nullable=false)
     */
    private $versionsnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="versionsgrund", type="text", length=-1, nullable=true)
     */
    private $versionsgrund;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp_dtts_standard", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $tpDttsStandard;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp_dtts_individual", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $tpDttsIndividual;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp_dtts_gesamt", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $tpDttsGesamt;

    /**
     * @var string
     *
     * @ORM\Column(name="gmkz_tdg", type="decimal", precision=7, scale=4, nullable=false)
     */
    private $gmkzTdg;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="angebot_gesendet_am", type="datetime", nullable=true)
     */
    private $angebotGesendetAm;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="produktionsreife_start", type="datetime", nullable=true)
     */
    private $produktionsreifeStart;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="produktionsreife_ende", type="datetime", nullable=true)
     */
    private $produktionsreifeEnde;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private $vkVersions;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @param string|null $tpDttsStandard
     */
    public function setTpDttsStandard(?string $tpDttsStandard): void
    {
        $this->tpDttsStandard = $tpDttsStandard;
    }

    /**
     * @param string|null $tpDttsIndividual
     */
    public function setTpDttsIndividual(?string $tpDttsIndividual): void
    {
        $this->tpDttsIndividual = $tpDttsIndividual;
    }

    /**
     * @param string|null $tpDttsGesamt
     */
    public function setTpDttsGesamt(?string $tpDttsGesamt): void
    {
        $this->tpDttsGesamt = $tpDttsGesamt;
    }

    /**
     * @return string
     */
    public function getGmkzTdg(): string
    {
        return $this->gmkzTdg;
    }

    /**
     * @return int
     */
    public function getTpVersionsId(): int
    {
        return $this->tpVersionsId;
    }

    /**
     * @return int
     */
    public function getVersionsnr(): int
    {
        return $this->versionsnr;
    }

}
