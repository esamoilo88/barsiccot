<?php

namespace App\Domain\Entities;

use App\Domain\Signatures\SinStatus\StatusSignature;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * GlobalGate
 *
 * @ORM\Table(name="Global_Gate")
 * @ORM\Entity
 */
class GlobalGate
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $simpleId;

    /** @ORM\Column(name="thema", type="string", length=150, nullable=true) */
    private ?string $thema;

    /** @ORM\Column(name="nr", type="string", length=50, nullable=true) */
    private ?string $nr;

    /** @ORM\Column(name="eingangs_nr", type="string", length=50, nullable=true) */
    private ?string $eingangsNr;

    /** @ORM\Column(name="epm_simple_id", type="bigint", nullable=true) */
    private ?int $epmSimpleId;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /** @ORM\Column(name="sicherheitsstufe", type="string", length=256, nullable=true, options={"default"="Default"}) */
    private ?string $sicherheitsstufe = 'Default';

    /**
     * @ORM\ManyToOne(targetEntity="GlobalProzess")
     * @ORM\JoinColumn(name="prozess_id", referencedColumnName="prozess_id")
     */
    private GlobalProzess $prozess;

    /** @ORM\OneToOne(targetEntity="SalesSinStatus", mappedBy="globalGate", fetch="EAGER") */
    private SalesSinStatus $sinStatus;

    /** @ORM\OneToOne(targetEntity="SalesStammdaten", mappedBy="globalGate") */
    private SalesStammdaten $salesStammdaten;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    public function __construct(
        ?string $thema,
        ?string $sicherheitsstufe,
        GlobalProzess $prozess
    )
    {
        $this->thema = $thema;
        $this->sicherheitsstufe = $sicherheitsstufe;
        $this->prozess = $prozess;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return new SIN($this->simpleId);
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return int
     * @Groups({"projectBasic"})
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return SalesSinStatus
     * @Groups({"projectBasic"})
     */
    public function getSinStatus(): SalesSinStatus
    {
        return $this->sinStatus;
    }

    /**
     * @return GlobalProzess
     * @Groups({"orderBasic"})
     */
    public function getProzess(): GlobalProzess
    {
        return $this->prozess;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getThema(): ?string
    {
        return $this->thema;
    }

    /**
     * @param string|null $thema
     */
    public function setThema(?string $thema): void
    {
        $this->thema = $thema;
    }

    /**
     * @param string|null $sicherheitsstufe
     */
    public function setSicherheitsstufe(?string $sicherheitsstufe): void
    {
        $this->sicherheitsstufe = $sicherheitsstufe;
    }

    /**
     * @param GlobalProzess $prozess
     */
    public function setProzess(GlobalProzess $prozess): void
    {
        $this->prozess = $prozess;
    }

    /**
     * @param StatusSignature $signature
     * @return bool
     */
    public function isInStatus(StatusSignature $signature): bool
    {
        return $this->sinStatus->getStatus()->getSysName() === $signature->value();
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->getSinStatus()->getStatus()->isActive();
    }

    /**
     * @return bool
     */
    public function isPresales(): bool
    {
        return $this->getSinStatus()->getStatus()->isPresales();
    }

    /**
     * @return bool
     */
    public function isPreorder(): bool
    {
        return $this->getSinStatus()->getStatus()->isPreorder();
    }

    /**
     * @return bool
     */
    public function isOnkaWriteable(): bool
    {
        return $this->getSinStatus()->getStatus()->isOnkaWritable();
    }

    /**
     * @return bool
     */
    public function isBillingWritable(): bool
    {
        return $this->getSinStatus()->getStatus()->isBillingWritable();
    }

    /**
     * @return SalesStammdaten
     */
    public function getSalesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return bool
     */
    public function isOfferComplete(): bool
    {
        return $this->getSinStatus()->getStatus()->isOfferComplete();
    }

    /**
     * @return bool
     */
    public function canCompleteOffer(): bool
    {
        return $this->isPresales() && $this->isActive() && !$this->isOfferComplete();
    }

    /**
     * @return string|null
     */
    public function getSicherheitsstufe(): ?string
    {
        return $this->sicherheitsstufe;
    }
}
