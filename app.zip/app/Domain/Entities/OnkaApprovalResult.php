<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaApprovalResult
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Approval_Result")
 */
class OnkaApprovalResult
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="SalesVersionierung")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesVersionierung $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_version_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $angebotVk;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaApproval")
     * @ORM\JoinColumn(name="approval_id", referencedColumnName="id")
     */
    private OnkaApproval $onkaApproval;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="req_by_benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $requestByUser;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="req_from_benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $requestFromUser;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="chk_by_benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $checkedByUser;

    /** @ORM\Column(name="req_from_mail", type="string", nullable=true) */
    private ?string $reqFromMail;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $requestedAt;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $checkedAt;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $result;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $comment;

    /**
     * OnkaApprovalResult constructor.
     * @param SalesVersionierung|object $simple
     * @param OfferAngebotVk|object $angebotVk
     * @param OnkaApproval|object $onkaApproval
     */
    public function __construct(
        SalesVersionierung $simple,
        OfferAngebotVk $angebotVk,
        OnkaApproval $onkaApproval
    )
    {
        $this->simple = $simple;
        $this->angebotVk = $angebotVk;
        $this->onkaApproval = $onkaApproval;
    }

    /**
     * @return int
     * @Groups({"onkaApprovalItems"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return SalesVersionierung
     */
    public function getSimple(): SalesVersionierung
    {
        return $this->simple;
    }

    /**
     * @param SalesVersionierung $simple
     */
    public function setSimple(SalesVersionierung $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getAngebotVk(): OfferAngebotVk
    {
        return $this->angebotVk;
    }

    /**
     * @param OfferAngebotVk $angebotVk
     */
    public function setAngebotVk(OfferAngebotVk $angebotVk): void
    {
        $this->angebotVk = $angebotVk;
    }

    /**
     * @return OnkaApproval
     */
    public function getOnkaApproval(): OnkaApproval
    {
        return $this->onkaApproval;
    }

    /**
     * @param OnkaApproval $onkaApproval
     */
    public function setOnkaApproval(OnkaApproval $onkaApproval): void
    {
        $this->onkaApproval = $onkaApproval;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getRequestByUser(): ?BackendBenutzer
    {
        return $this->requestByUser;
    }

    /**
     * @param BackendBenutzer|null $requestByUser
     */
    public function setRequestByUser(?BackendBenutzer $requestByUser): void
    {
        $this->requestByUser = $requestByUser;
    }

    /**
     * @return string|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getReqFromMail(): ?string
    {
        return $this->reqFromMail;
    }

    /**
     * @param string|null $reqFromMail
     */
    public function setReqFromMail(?string $reqFromMail): void
    {
        $this->reqFromMail = $reqFromMail;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getRequestFromUser(): ?BackendBenutzer
    {
        return $this->requestFromUser;
    }

    /**
     * @param BackendBenutzer|null $requestFromUser
     */
    public function setRequestFromUser(?BackendBenutzer $requestFromUser): void
    {
        $this->requestFromUser = $requestFromUser;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getCheckedByUser(): ?BackendBenutzer
    {
        return $this->checkedByUser;
    }

    /**
     * @param BackendBenutzer|null $checkedByUser
     */
    public function setCheckedByUser(?BackendBenutzer $checkedByUser): void
    {
        $this->checkedByUser = $checkedByUser;
    }

    /**
     * @return DateTime|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getRequestedAt(): ?DateTime
    {
        return $this->requestedAt;
    }

    /**
     * @param DateTime|null $requestedAt
     */
    public function setRequestedAt(?DateTime $requestedAt): void
    {
        $this->requestedAt = $requestedAt;
    }

    /**
     * @return DateTime|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getCheckedAt(): ?DateTime
    {
        return $this->checkedAt;
    }

    /**
     * @param DateTime|null $checkedAt
     */
    public function setCheckedAt(?DateTime $checkedAt): void
    {
        $this->checkedAt = $checkedAt;
    }

    /**
     * @return bool|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getResult(): ?bool
    {
        return $this->result;
    }

    /**
     * @param bool|null $result
     */
    public function setResult(?bool $result): void
    {
        $this->result = $result;
    }

    /**
     * @return string|null
     * @Groups({"onkaApprovalItems"})
     */
    public function getComment(): ?string
    {
        return $this->comment;
    }

    /**
     * @param string|null $comment
     */
    public function setComment(?string $comment): void
    {
        $this->comment = $comment;
    }
}
