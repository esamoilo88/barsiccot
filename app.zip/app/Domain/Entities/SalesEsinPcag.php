<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesEsinPcag
 *
 * @ORM\Table(name="Sales_eSIN_PCAG")
 * @ORM\Entity
 */
class SalesEsinPcag
{
    /**
     * @var int
     *
     * @ORM\Column(name="pcag_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $pcagId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abkuerzung", type="string", length=50, nullable=true)
     */
    private $abkuerzung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="iksl_prozess", type="boolean", nullable=true)
     */
    private $ikslProzess;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="OfferKatalogLeistungsposition", mappedBy="pcag")
     */
    private $leistungsposition;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->leistungsposition = new \Doctrine\Common\Collections\ArrayCollection();
    }

}
