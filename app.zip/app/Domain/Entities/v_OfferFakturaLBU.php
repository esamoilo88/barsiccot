<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Serializer\Annotation\SerializedName;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Faktura_LBU")
 */
class v_OfferFakturaLBU
{
    /**
     * @ORM\Id
     * @ORM\Column(name="lbu_id", type="integer")
     */
    private int $lbuId;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /** @ORM\Column(name="Preis_TP1", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $preisTP1 = null;

    /** @ORM\Column(name="Preis_TP2", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $preisTP2 = null;

    /** @ORM\Column(name="leistungs_jahr", type="integer") */
    private int $leistungsJahr;

    /** @ORM\Column(name="leistungs_monat", type="integer") */
    private int $leistungsMonat;

    /** @ORM\Column(name="faktura_jahr", type="integer") */
    private int $fakturaJahr;

    /** @ORM\Column(name="faktura_monat", type="integer") */
    private int $fakturaMonat;

    /** @ORM\Column(name="Leistungszeitraum", type="string", length=62, nullable=true) */
    private ?string $Leistungszeitraum;

    /** @ORM\Column(name="Fakturazeitraum", type="string", length=62, nullable=true) */
    private ?string $Fakturazeitraum;

    /** @ORM\Column(name="debitor_nummer", type="string", length=50, nullable=true) */
    private ?string $debitorNummer;

    /** @ORM\Column(name="debitor_gesellschaftsnummer", type="string", nullable=true) */
    private ?string $debitorGesellschaftsnummer;

    /** @ORM\Column(name="Typ", type="string", length=10) */
    private ?string $type;

    /** @ORM\Column(name="vorgangstyp_name", type="string", nullable=true) */
    private ?string $vorgangstypName;

    /** @ORM\Column(name="vorgangstyp_id", type="integer", nullable=true) */
    private ?int $vorgangstypId;

    /** @ORM\Column(name="vorgangstyp", type="string", nullable=true) */
    private ?string $vorgangstyp;

    /** @ORM\Column(name="debitor_id", type="integer", nullable=true) */
    private ?int $debitorId;

    /** @ORM\Column(name="credit_reason_name", type="string", nullable=true) */
    private ?string $creditReasonName;

    /** @ORM\Column(name="created_by_vorname", type="string", nullable=true) */
    private ?string $createdByVorname;

    /** @ORM\Column(name="created_by_nachname", type="string", nullable=true) */
    private ?string $createdByNachname;

    /** @ORM\Column(name="abgrenzung", type="boolean") */
    private bool $abgrenzung;

    /** @ORM\Column(name="redesign", type="boolean") */
    private bool $redesign;

    /** @ORM\Column(name="lieferversion", type="string", length=2, nullable=true) */
    private ?string $lieferversion;

    /** @ORM\Column(name="rechnungsnummer", type="string", length=50, nullable=true) */
    private ?string $rechnungsnummer;

    /** @ORM\Column(name="credit_reason_id", type="integer", nullable=true) */
    private ?int $creditReasonId;

    /** @ORM\Column(name="vorname", type="string", nullable=true) */
    private ?string $vorname;

    /** @ORM\Column(name="nachname", type="string", nullable=true) */
    private ?string $nachname;

    /** @ORM\Column(name="ansprechpartner_id", type="integer", nullable=true) */
    private ?int $ansprechpartnerId;

    /** @ORM\Column(name="billing_subject_extension", type="string", nullable=true) */
    private ?string $billingSubjectExtension;

    /** @ORM\Column(name="sap_bestellnummer", type="string", nullable=true) */
    private ?string $sapBestellnummer;

    /** @ORM\Column(name="fakturaziel_id", type="integer", nullable=true) */
    private ?int $fakturazielId;

    /** @ORM\Column(name="fakturaziel_name", type="string", nullable=true) */
    private ?string $fakturazielName;

    /** @ORM\Column(name="sap_transaction_code", type="string", nullable=true) */
    private ?string $sapTransactionCode = null;

    /** @ORM\Column(name="sap_invoice_code", type="string", nullable=true) */
    private ?string $sapInvoiceCode = null;

    /** @ORM\Column(name="sap_status", type="string", nullable=true) */
    private ?string $sapStatus;

    /** @ORM\Column(name="fakturiert_am", type="datetime") */
    private ?DateTime $fakturiertAm;

    /** @ORM\Column(name="gesendet_am", type="datetime") */
    private ?DateTime $gesendetAm;

    /** @ORM\Column(name="fakturabereit", type="datetime") */
    private ?DateTime $fakturabereit;

    /** @ORM\Column(name="kommentar", type="string", nullable=true) */
    private ?string $kommentar;

    /** @ORM\Column(name="created", type="datetime") */
    private ?DateTime $created;

    /**
     * @ORM\OneToOne(targetEntity="OfferFakturaLbuStatus")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private OfferFakturaLbuStatus $status;

    /** @ORM\Column(name="negative", type="boolean", nullable=true) */
    private ?bool $negative = null;

    /**
     * @ORM\OneToOne(targetEntity="OfferFakturaFreigabegrund")
     * @ORM\JoinColumn(name="freigabegrund_id", referencedColumnName="freigabegrund_id", nullable=true)
     */
    private ?OfferFakturaFreigabegrund $freigabegrund = null;

    /** @ORM\Column(name="abgelehnt", type="boolean", nullable=true) */
    private ?bool $abgelehnt = null;

    /** @ORM\Column(name="dauerfreigabe", type="boolean") */
    private bool $dauerfreigabe = false;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $pending = null;

    /**
     * @return bool|null
     */
    public function getNegative(): ?bool
    {
        return $this->negative;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @Groups({"lbuDetails"})
     * @SerializedName("id")
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return float|null
     */
    public function getPreisTP1(): ?float
    {
        return $this->preisTP1;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return float|null
     */
    public function getPreisTP2(): ?float
    {
        return $this->preisTP2;
    }

    /**
     * @return string|null
     */
    public function getLeistungszeitraum(): ?string
    {
        return $this->Leistungszeitraum;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return int
     */
    public function getLeistungsJahr(): int
    {
        return $this->leistungsJahr;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return int
     */
    public function getLeistungsMonat(): int
    {
        return $this->leistungsMonat;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return int
     */
    public function getFakturaJahr(): int
    {
        return $this->fakturaJahr;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return int
     */
    public function getFakturaMonat(): int
    {
        return $this->fakturaMonat;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getDebitorNummer(): ?string
    {
        return $this->debitorNummer;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getDebitorGesellschaftsnummer(): ?string
    {
        return $this->debitorGesellschaftsnummer;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getVorgangstypName(): ?string
    {
        return $this->vorgangstypName;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getVorname(): ?string
    {
        return $this->vorname;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getNachname(): ?string
    {
        return $this->nachname;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getAnsprechpartner(): ?string
    {
        if (!$this->nachname && !$this->vorname) {
            return null;
        }
        return $this->nachname . ', ' . $this->vorname;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getFakturazielName(): ?string
    {
        return $this->fakturazielName;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getSapTransactionCode(): ?string
    {
        return $this->sapTransactionCode;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getSapInvoiceCode(): ?string
    {
        return $this->sapInvoiceCode;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getSapStatus(): ?string
    {
        return $this->sapStatus;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return bool
     */
    public function isAbgrenzung(): bool
    {
        return $this->abgrenzung;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return DateTime|null
     */
    public function getCreated(): ?DateTime
    {
        return $this->created;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return DateTime|null
     */
    public function getFakturiertAm(): ?DateTime
    {
        return $this->fakturiertAm;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return DateTime|null
     */
    public function getGesendetAm(): ?DateTime
    {
        return $this->gesendetAm;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return DateTime|null
     */
    public function getFakturabereit(): ?DateTime
    {
        return $this->fakturabereit;
    }

    /**
     *
     * @return OfferFakturaLbuStatus
     */
    public function getStatus(): OfferFakturaLbuStatus
    {
        return $this->status;
    }

    /**
     * @param OfferFakturaLbuStatus $status
     */
    public function setStatus(OfferFakturaLbuStatus $status): void
    {
        $this->status = $status;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getCreditReasonName(): ?string
    {
        return $this->creditReasonName;
    }

    /**
     * @return string|null
     */
    public function getCreatedByVorname(): ?string
    {
        return $this->createdByVorname;
    }

    /**
     * @return string|null
     */
    public function getCreatedByNachname(): ?string
    {
        return $this->createdByNachname;
    }

    /**
     * @Groups({"lbuDetails"})
     * @return string|null
     */
    public function getCreatedBy(): ?string
    {
        if (!$this->createdByNachname && !$this->createdByVorname) {
            return null;
        }
        return $this->createdByNachname . ', ' . $this->createdByVorname;
    }

    /**
     * @return OfferFakturaFreigabegrund|null
     */
    public function getFreigabegrund(): ?OfferFakturaFreigabegrund
    {
        return $this->freigabegrund;
    }

    /**
     * @return bool|null
     */
    public function getAbgelehnt(): ?bool
    {
        return $this->abgelehnt;
    }

    /**
     * @return bool
     */
    public function getRedesign(): bool
    {
        return $this->redesign;
    }

    /**
     * @return string|null
     */
    public function getLieferversion(): ?string
    {
        return $this->lieferversion;
    }

    /**
     * @return string|null
     */
    public function getNewLv(): ?string
    {
        return ++$this->lieferversion;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return int|null
     */
    public function getAnsprechpartnerId(): ?int
    {
        return $this->ansprechpartnerId;
    }

    /**
     * @return int|null
     */
    public function getFakturazielId(): ?int
    {
        return $this->fakturazielId;
    }

    /**
     * @return int|null
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }
    /**
     * @return DateTime
     */
    public function getJahrMonat(): DateTime
    {
        return new DateTime("{$this->fakturaJahr}-{$this->fakturaMonat}-01");
    }

    /**
     * @return bool|null
     */
    public function getPending(): ?bool
    {
        return $this->pending;
    }

    /**
     * @return DateTime
     */
    public function getLeistungsJahrMonat(): DateTime
    {
        return new DateTime("{$this->leistungsJahr}-{$this->leistungsMonat}-01");
    }
}
