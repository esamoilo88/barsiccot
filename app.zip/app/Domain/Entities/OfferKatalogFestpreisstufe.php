<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKatalogFestpreisstufe
 *
 * @ORM\Table(name="Offer_Katalog_Festpreisstufe")
 * @ORM\Entity
 */
class OfferKatalogFestpreisstufe
{
    /**
     * @var int
     *
     * @ORM\Column(name="festpreisstufe_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $festpreisstufeId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=255, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="farbe", type="string", length=7, nullable=true)
     */
    private $farbe;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @return int
     */
    public function getFesstpreisstyfeId(): int
    {
        return $this->festpreisstufeId;
    }

}
