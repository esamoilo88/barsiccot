<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OnkaConfiguratorParam
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configurator_Param")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaConfiguratorParam
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(type="string") */
    private string $name;

    /** @ORM\Column(type="text") */
    private string $subtext;

    /** @ORM\Column(type="integer") */
    private int $sort;
    /**
     * @ORM\Column(type="decimal", precision=26, scale=16)
     */
    private $defaultValue;

    /** @ORM\Column(type="integer", nullable=true) */
    private ?int $stepsize = null;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfigurator")
     * @ORM\JoinColumn(name="configurator_id", referencedColumnName="id")
     */
    private OnkaConfigurator $configurator;

    /** @ORM\Column(type="string", length=1024, nullable=true) */
    private ?string $options;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\OneToMany(targetEntity="OnkaParamSourcing", mappedBy="configuratorParam") */
    private Collection $sourcing;

    /** @ORM\Column(name="sys_name", type="text", length=1024, nullable=true) */
    private ?string $sysName;

    /** @ORM\Column(name="computed", type="boolean", nullable=true) */
    private ?string $computed;

    /** @ORM\Column(name="locked", type="boolean", nullable=true) */
    private ?string $locked;

    /** @ORM\Column(name="hide", type="boolean", nullable=true) */
    private ?string $hide;

    /** @ORM\Column(name="formula", type="text", length=1024, nullable=true) */
    private ?string $formula;

    /**
     * @var float|null
     * @ORM\Column(type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $minValue = null;

    /**
     * @var float|null
     * @ORM\Column(type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $maxValue = null;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorParamGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private OnkaConfiguratorParamGroup $paramGroup;

    /** @ORM\Column(name="ui_type", type="text", length=8, nullable=false) */
    private string $uiType = 'input';

    /**
     * OnkaConfiguratorParam constructor.
     * @param string $name
     * @param string $subtext
     * @param $default
     * @param int|null $stepsize
     * @param OnkaConfigurator $configurator
     */
    public function __construct(
        string $name,
        string $subtext,
        $default,
        ?int $stepsize,
        OnkaConfigurator $configurator
    )
    {
        $this->name = $name;
        $this->subtext = $subtext;
        $this->defaultValue = $default;
        $this->stepsize = $stepsize;
        $this->configurator = $configurator;
        $this->sourcing = new ArrayCollection();
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getSubtext(): string
    {
        return $this->subtext;
    }

    /**
     * @return mixed
     */
    public function getDefaultValue()
    {
        return $this->defaultValue;
    }

    /**
     * @return int|null
     */
    public function getStepsize(): ?int
    {
        return $this->stepsize;
    }

    /**
     * @return OnkaConfigurator
     */
    public function getConfigurator(): OnkaConfigurator
    {
        return $this->configurator;
    }

    /**
     * @return bool
     */
    public function isDropdown(): bool
    {
        return $this->uiType === 'dropdown';
    }

    /**
     * @return bool
     */
    public function isInput(): bool
    {
        return $this->uiType === 'input';
    }

    /**
     * @return bool
     */
    public function isCheckbox(): bool
    {
        return $this->uiType === 'checkbox';
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return bool
     */
    public function isComputed(): bool
    {
        return $this->computed;
    }

    /**
     * @return string|null
     */
    public function getFormula(): ?string
    {
        return $this->formula;
    }

    /**
     * @return string|null
     */
    public function getSysName(): ?string
    {
        return $this->sysName;
    }

    /**
     * @return array|null
     */
    public function getOptions(): ?array
    {
        return json_decode($this->options,true);
    }

    /**
     * @return string|null
     */
    public function getDefaultItemsId(): ?string
    {
        $defaultArray = array_filter($this->getOptions(), function ($l)  {
            return $l['default'];
        });
        return array_values(array_map(fn ($node) => $node['items'], $defaultArray))[0] ?? '';
    }

    /**
     * @return string|null
     */
    public function getDefaultDropdownValue(): ?string
    {
        $defaultArray = array_filter($this->getOptions(), function ($l)  {
            return $l['default'];
        });
        return array_values(array_map(fn ($node) => $node['key'], $defaultArray))[0] ?? '';
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return Collection
     */
    public function getSourcing(): Collection
    {
        return $this->sourcing;
    }

    /**
     * @return float|null
     */
    public function getMinValue(): ?float
    {
        return $this->minValue;
    }

    /**
     * @return float|null
     */
    public function getMaxValue(): ?float
    {
        return $this->maxValue;
    }

    /**
     * @return string
     */
    public function getUiType(): string
    {
        return $this->uiType;
    }

    /**
     * @param string $uiType
     */
    public function setUiType(string $uiType): void
    {
        $this->uiType = $uiType;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return string|null
     */
    public function getComputed(): ?string
    {
        return $this->computed;
    }

    /**
     * @param string|null $computed
     */
    public function setComputed(?string $computed): void
    {
        $this->computed = $computed;
    }

    /**
     * @return string|null
     */
    public function getLocked(): ?string
    {
        return $this->locked;
    }

    /**
     * @param string|null $locked
     */
    public function setLocked(?string $locked): void
    {
        $this->locked = $locked;
    }

    /**
     * @return string|null
     */
    public function getHide(): ?string
    {
        return $this->hide;
    }

    /**
     * @param string|null $hide
     */
    public function setHide(?string $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return OnkaConfiguratorParamGroup
     */
    public function getParamGroup(): OnkaConfiguratorParamGroup
    {
        return $this->paramGroup;
    }

    /**
     * @param OnkaConfiguratorParamGroup $paramGroup
     */
    public function setParamGroup(OnkaConfiguratorParamGroup $paramGroup): void
    {
        $this->paramGroup = $paramGroup;
    }
}
