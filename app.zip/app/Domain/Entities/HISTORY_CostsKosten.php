<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * CostsKosten
 *
 * @ORM\Table(name="Costs_Kosten_HISTORY")
 * @ORM\Entity(readOnly=true)
 */
class HISTORY_CostsKosten
{
    /**
     * @var int
     *
     * @ORM\Column(name="kosten_id", type="bigint", nullable=false)
     * @ORM\Id
     */
    private $kostenId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="kostenplan_id", type="integer", nullable=true)
     */
    private $kostenplanId;

    /**
     * @var int
     *
     * @ORM\Column(name="kostenart_id", type="integer", nullable=false)
     */
    private $kostenartId;

    /**
     * @var int
     *
     * @ORM\Column(name="kosten_jahr", type="smallint", nullable=false)
     */
    private $kostenJahr;

    /**
     * @var int
     *
     * @ORM\Column(name="kosten_monat", type="smallint", nullable=false)
     */
    private $kostenMonat;

    /**
     * @var string
     *
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=false)
     */
    private $stundensatz;

    /**
     * @var string
     *
     * @ORM\Column(name="wert", type="decimal", precision=26, scale=16, nullable=false)
     */
    private $wert;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private $bemerkungen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="lbu_leistungs_monat", type="string", length=10, nullable=true)
     */
    private $lbuLeistungsMonat;

    /**
     * @var string|null
     *
     * @ORM\Column(name="lbu_faktura_monat", type="string", length=10, nullable=true)
     */
    private $lbuFakturaMonat;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var int|null
     *
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private $ofiLa;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="valid_from", type="datetime", nullable=false, options={"default"="sysutcdatetime()"})
     */
    private $validFrom = 'sysutcdatetime()';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="valid_to", type="datetime", nullable=false, options={"default"="CONVERT([datetime2](0),'9999-12-31 23:59:59')"})
     */
    private $validTo = 'CONVERT([datetime2](0),\'9999-12-31 23:59:59\')';

    /**
     * @var int|null
     *
     * @ORM\Column(name="receiver_kostenstelle_id", type="integer", nullable=true)
     */
    private $receiverKostenstelleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $stundensatzAlternativ;

    /**
     * @var \CostsKostenstelle
     *
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id")
     * })
     */
    private $kostenstelle;

}
