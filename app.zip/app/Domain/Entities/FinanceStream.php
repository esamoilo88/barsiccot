<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;

use Symfony\Component\Serializer\Annotation\Groups;

/**
 * FinanceStream
 *
 * @ORM\Table(name="Finance_Stream")
 * @ORM\Entity
 */
class FinanceStream
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", length=30) */
    private string $name;

    /** @ORM\Column(name="description", type="string", length=-1, nullable=true) */
    private ?string $description;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide = false;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /**
     * @ORM\OneToMany(targetEntity="FinanceInvoice", mappedBy="stream")
     * @ORM\JoinColumn(name="id", referencedColumnName="stram_id")
     */
    private Collection $invoices;

    /**
     * FinanceStream constructor.
     * @param string $name
     */
    public function __construct(string $name)
    {
        $this->name = $name;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @param string|null $description
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return Collection
     */
    public function getInvoices(): Collection
    {
        return $this->invoices;
    }
}
