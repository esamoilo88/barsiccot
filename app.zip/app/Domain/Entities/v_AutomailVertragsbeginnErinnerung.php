<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Automailable;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Automail_VertragsbeginnErinnerung")
 */
class v_AutomailVertragsbeginnErinnerung implements Automailable
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="string")
     */
    private int $simple_id;

    /**
     * @ORM\Column(name="thema", type="string", nullable=true)
     */
    private ?string $thema;

    /**
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private ?string $kundenname;

    /**
     * @ORM\Column(name="role_short", type="string", nullable=true)
     */
    private ?string $role_short;

    /**
     * @ORM\Column(name="email", type="string", nullable=true)
     */
    private ?string $email;

    /**
     * @ORM\Column(name="vertragsbeginn", type="string", nullable=true)
     */
    private ?string $vertragsbeginn;

    /**
     * @ORM\Column(name="nachname", type="string", nullable=true)
     */
    private ?string $nachname;

    /**
     * @ORM\Column(name="vorname", type="string", nullable=true)
     */
    private ?string $vorname;

    /**
     * @ORM\Column(name="fertig_am", type="string", nullable=true)
     */
    private ?string $fertig_am;

    /**
     * @ORM\Column(name="anrede", type="string", nullable=true)
     */
    private ?string $anrede;

    /**
     * @ORM\Column(name="benutzer_id", type="string", nullable=true)
     */
    private ?string $benutzerId;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simple_id' => $this->simple_id,
            'thema' => $this->thema,
            'kundenname' => $this->kundenname,
            'email' => $this->email,
            'vertragsbeginn' => $this->vertragsbeginn,
            'nachname' => $this->nachname,
            'vorname' => $this->vorname,
            'fertig_am' => $this->fertig_am,
            'anrede' => $this->anrede,
            'role_short' => $this->role_short
        ];
    }
}
