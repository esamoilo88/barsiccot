<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Finance_PlanILV")
 */
class v_FinancePlanILV
{
    /**
     * @ORM\Id
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $offerAuftrag;

    /**
     * @ORM\Column(name="kostenwert", type="decimal", precision=26, scale=16, nullable=false)
     */
    private float $kostenwert;

    /** @ORM\Column(name="kosten_jahr", type="integer") */
    private int $kostenJahr;

    /** @ORM\Column(name="kosten_monat", type="integer") */
    private int $kostenMonat;

    /**
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private ?string $bemerkungen;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id", nullable=true)
     */
    private ?CostsKostenstelle $kostenstelle;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenart;

    /**
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $stundensatz;

    /**
     * @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $stundensatzAlternativ;

    /**
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private ?int $ofiLa;

    /**
     * @ORM\Column(name="psp_element", type="string", nullable=true)
     */
    private ?string $pspElement;

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return OfferAuftrag
     */
    public function getOfferAuftrag(): OfferAuftrag
    {
        return $this->offerAuftrag;
    }

    /**
     * @return float
     */
    public function getKostenwert(): float
    {
        return $this->kostenwert;
    }

    /**
     * @return int
     */
    public function getKostenJahr(): int
    {
        return $this->kostenJahr;
    }

    /**
     * @return int
     */
    public function getKostenMonat(): int
    {
        return $this->kostenMonat;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @return CostsKostenstelle|null
     */
    public function getKostenstelle(): ?CostsKostenstelle
    {
        return $this->kostenstelle;
    }

    /**
     * @return CostsKostenart
     */
    public function getKostenart(): CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return float|null
     */
    public function getStundensatzAlternativ(): ?float
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }
}
