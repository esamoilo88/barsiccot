<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Table(name="Backend_Benutzer_Login", uniqueConstraints={@ORM\UniqueConstraint(name="UC_BBL_benutzer_id", columns={"benutzer_id"})})
 * @ORM\Entity
 */
class BackendBenutzerLogin
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\OneToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $user;

    /** @ORM\Column(name="last_login", type="datetime") */
    private DateTime $lastLogin;

    /**
     * BackendBenutzerLogin constructor.
     * @param BackendBenutzer $user
     * @param DateTime $lastLogin
     */
    public function __construct(BackendBenutzer $user, DateTime $lastLogin)
    {
        $this->user = $user;
        $this->lastLogin = $lastLogin;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @param BackendBenutzer $user
     */
    public function setUser(BackendBenutzer $user): void
    {
        $this->user = $user;
    }

    /**
     * @Groups({"userProfile"})
     * @return DateTime
     */
    public function getLastLogin(): DateTime
    {
        return $this->lastLogin;
    }

    /**
     * @param DateTime $lastLogin
     */
    public function setLastLogin(DateTime $lastLogin): void
    {
        $this->lastLogin = $lastLogin;
    }
}
