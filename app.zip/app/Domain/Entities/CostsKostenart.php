<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CostsKostenart
 *
 * @ORM\Table(name="Costs_Kostenart")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsKostenart
{
    /**
     * @ORM\Column(name="kostenart_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $kostenartId;

    /**
     * @ORM\Column(name="zuordnung", type="string", length=20, nullable=true)
     */
    private ?string $zuordnung;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @ORM\Column(name="bezeichnung", type="string", length=100, nullable=true)
     */
    private ?string $bezeichnung;

    /**
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private ?string $beschreibung;

    /**
     * @ORM\Column(name="abkürzung", type="string", length=20, nullable=true)
     */
    private ?string $abkuerzung;

    /**
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private bool $hide;

    /**
     * @ORM\Column(name="hauptgruppe", type="string", length=50, nullable=true)
     */
    private ?string $hauptgruppe;

    /**
     * @ORM\Column(name="gruppe", type="string", length=50, nullable=true)
     */
    private ?string $gruppe;

    /**
     * @ORM\Column(name="onka_relevant", type="boolean", nullable=true)
     */
    private ?bool $onkaRelevant;

    /**
     * @ORM\Column(name="kosten_relevant", type="boolean", nullable=true)
     */
    private ?bool $kostenRelevant;

    /**
     * @ORM\Column(name="kein_produktionsplan", type="boolean", nullable=true)
     */
    private ?bool $keinProduktionsplan;

    /**
     * @ORM\Column(name="default_produktionsplan_sort", type="integer", nullable=true)
     */
    private ?int $defaultProduktionsplanSort;

    /**
     * @ORM\Column(name="default_produktionsplan_name", type="text", length=-1, nullable=true)
     */
    private ?string $defaultProduktionsplanName;

    /**
     * @ORM\Column(name="delivery", type="text", length=-1, nullable=true)
     */
    private ?string $delivery;

    /**
     * @ORM\Column(name="force_produktionsplan", type="boolean", nullable=true)
     */
    private ?bool $forceProduktionsplan;

    /**
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private ?int $ofiLa;

    /**
     * @ORM\Column(name="myshs_relevant", type="boolean", nullable=true)
     */
    private ?bool $myshsRelevant;

    /**
     * @ORM\Column(name="competence_send", type="boolean", nullable=true)
     */
    private ?bool $competenceSend;

    /** @ORM\Column(name="approval_group", type="text", length=50, nullable=true) */
    private ?string $approvalGroup;


    /** @ORM\OneToMany(targetEntity="CostsStundensatz", mappedBy="kostenart") */
    private Collection $costStundensatz;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostentyp")
     * @ORM\JoinColumn(name="kostentyp_id", referencedColumnName="kostentyp_id")
     */
    private ?CostsKostentyp $kostentyp = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferVerrechnungsart")
     * @ORM\JoinColumn(name="default_verrechnungsart_id", referencedColumnName="verrechnungsart_id")
     */
    private ?OfferVerrechnungsart $defaultVerrechnungsart;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilMain")
     * @ORM\JoinColumn(name="itil_main_id", referencedColumnName="itil_main_id")
     */
    private ?OfferItilMain $itilMain;

    /**
     * @ORM\Column(name="ilv_relevant", type="boolean", nullable=true)
     */
    private ?bool $ilvRelevant = false;

    /**
     * @ORM\Column(name="vlv_relevant", type="boolean", nullable=true)
     */
    private ?bool $vlvRelevant;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->kostenartId;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return CostsKostentyp|null
     */
    public function getKostentyp(): ?CostsKostentyp
    {
        return $this->kostentyp;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getZuordnung(): ?string
    {
        return $this->zuordnung;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return int
     */
    public function getKostenartId(): int
    {
        return $this->kostenartId;
    }

    /**
     * @param string|null $zuordnung
     */
    public function setZuordnung(?string $zuordnung): void
    {
        $this->zuordnung = $zuordnung;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return string|null
     */
    public function getAbkuerzung(): ?string
    {
        return $this->abkuerzung;
    }

    /**
     * @param string|null $abkuerzung
     */
    public function setAbkuerzung(?string $abkuerzung): void
    {
        $this->abkuerzung = $abkuerzung;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return string|null
     */
    public function getHauptgruppe(): ?string
    {
        return $this->hauptgruppe;
    }

    /**
     * @param string|null $hauptgruppe
     */
    public function setHauptgruppe(?string $hauptgruppe): void
    {
        $this->hauptgruppe = $hauptgruppe;
    }

    /**
     * @return string|null
     */
    public function getGruppe(): ?string
    {
        return $this->gruppe;
    }

    /**
     * @param string|null $gruppe
     */
    public function setGruppe(?string $gruppe): void
    {
        $this->gruppe = $gruppe;
    }

    /**
     * @return bool|null
     */
    public function getOnkaRelevant(): ?bool
    {
        return $this->onkaRelevant;
    }

    /**
     * @param bool|null $onkaRelevant
     */
    public function setOnkaRelevant(?bool $onkaRelevant): void
    {
        $this->onkaRelevant = $onkaRelevant;
    }

    /**
     * @return bool|null
     */
    public function getKostenRelevant(): ?bool
    {
        return $this->kostenRelevant;
    }

    /**
     * @param bool|null $kostenRelevant
     */
    public function setKostenRelevant(?bool $kostenRelevant): void
    {
        $this->kostenRelevant = $kostenRelevant;
    }

    /**
     * @return bool|null
     */
    public function getKeinProduktionsplan(): ?bool
    {
        return $this->keinProduktionsplan;
    }

    /**
     * @param bool|null $keinProduktionsplan
     */
    public function setKeinProduktionsplan(?bool $keinProduktionsplan): void
    {
        $this->keinProduktionsplan = $keinProduktionsplan;
    }

    /**
     * @return int|null
     */
    public function getDefaultProduktionsplanSort(): ?int
    {
        return $this->defaultProduktionsplanSort;
    }

    /**
     * @param int|null $defaultProduktionsplanSort
     */
    public function setDefaultProduktionsplanSort(?int $defaultProduktionsplanSort): void
    {
        $this->defaultProduktionsplanSort = $defaultProduktionsplanSort;
    }

    /**
     * @return string|null
     */
    public function getDefaultProduktionsplanName(): ?string
    {
        return $this->defaultProduktionsplanName;
    }

    /**
     * @param string|null $defaultProduktionsplanName
     */
    public function setDefaultProduktionsplanName(?string $defaultProduktionsplanName): void
    {
        $this->defaultProduktionsplanName = $defaultProduktionsplanName;
    }

    /**
     * @return string|null
     */
    public function getDelivery(): ?string
    {
        return $this->delivery;
    }

    /**
     * @param string|null $delivery
     */
    public function setDelivery(?string $delivery): void
    {
        $this->delivery = $delivery;
    }

    /**
     * @return bool|null
     */
    public function getForceProduktionsplan(): ?bool
    {
        return $this->forceProduktionsplan;
    }

    /**
     * @param bool|null $forceProduktionsplan
     */
    public function setForceProduktionsplan(?bool $forceProduktionsplan): void
    {
        $this->forceProduktionsplan = $forceProduktionsplan;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @param int|null $ofiLa
     */
    public function setOfiLa(?int $ofiLa): void
    {
        $this->ofiLa = $ofiLa;
    }

    /**
     * @return bool|null
     */
    public function getMyshsRelevant(): ?bool
    {
        return $this->myshsRelevant;
    }

    /**
     * @param bool|null $myshsRelevant
     */
    public function setMyshsRelevant(?bool $myshsRelevant): void
    {
        $this->myshsRelevant = $myshsRelevant;
    }

    /**
     * @return bool|null
     */
    public function getCompetenceSend(): ?bool
    {
        return $this->competenceSend;
    }

    /**
     * @param bool|null $competenceSend
     */
    public function setCompetenceSend(?bool $competenceSend): void
    {
        $this->competenceSend = $competenceSend;
    }

    /**
     * @return OfferVerrechnungsart|null
     */
    public function getDefaultVerrechnungsart(): ?OfferVerrechnungsart
    {
        return $this->defaultVerrechnungsart;
    }

    /**
     * @param OfferVerrechnungsart|null $defaultVerrechnungsart
     */
    public function setDefaultVerrechnungsart(?OfferVerrechnungsart $defaultVerrechnungsart): void
    {
        $this->defaultVerrechnungsart = $defaultVerrechnungsart;
    }

    /**
     * @return OfferItilMain|null
     */
    public function getItilMain(): ?OfferItilMain
    {
        return $this->itilMain;
    }

    /**
     * @param OfferItilMain|null $itilMain
     */
    public function setItilMain(?OfferItilMain $itilMain): void
    {
        $this->itilMain = $itilMain;
    }

    /**
     * @return string|null
     */
    public function getApprovalGroup(): ?string
    {
        return $this->approvalGroup;
    }

    /**
     * @param  string|null  $approvalGroup
     */
    public function setApprovalGroup(?string $approvalGroup): void
    {
        $this->approvalGroup = $approvalGroup;
    }

    /**
     * Get SystemProtocol value for kostenart
     * field in parent entities
     * @return string
     */
    public function getSPValue(): string
    {
        // use getters here because otherwise lazy load is not triggered and fatal error is happened
        return $this->getZuordnung() . " - " . $this->getBezeichnung();
    }

    /**
     * @return bool|null
     */
    public function getIlvRelevant(): ?bool
    {
        return $this->ilvRelevant;
    }
}
