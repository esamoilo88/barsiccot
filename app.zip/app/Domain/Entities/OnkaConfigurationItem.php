<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaConfigurationItem
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configuration_Item")
 */
class OnkaConfigurationItem
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /** @ORM\Column(type="boolean") */
    private bool $required;

    /** @ORM\Column(type="boolean") */
    private bool $fixed;

    /** @ORM\Column(type="boolean") */
    private bool $selected;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguration")
     * @ORM\JoinColumn(name="configuration_id", referencedColumnName="id")
     */
    private OnkaConfiguration $configuration;

    /** @ORM\OneToMany(targetEntity="OnkaConfigurationItemContent", mappedBy="item", cascade={"remove"}) */
    private Collection $service;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private OnkaConfiguratorGroup $configuratorGroup;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorItem")
     * @ORM\JoinColumn(name="configurator_item_id", referencedColumnName="id")
     */
    private ?OnkaConfiguratorItem $onkaConfiguratorItem;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $katalogAp;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /** @ORM\Column(type="integer", nullable=true) */
    private ?int $parentItemId = null;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2)
     */
    private float $unitCosts = 0;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2)
     */
    private float $unitPrice = 0;

    /**
     * OnkaConfigurationItem constructor.
     * @param int $sort
     * @param int $quantity
     * @param bool $required
     * @param bool $fixed
     * @param bool $selected
     * @param OnkaConfiguration $configuration
     * @param OnkaConfiguratorGroup $configuratorGroup
     * @param OfferKatalogAngebotsposition $katalogAp
     * @param int|null $parentItemId
     * @param OnkaConfiguratorItem|null $onkaConfiguratorItem
     */
    public function __construct(
        int $sort,
        int $quantity,
        bool $required,
        bool $fixed,
        bool $selected,
        OnkaConfiguration $configuration,
        OnkaConfiguratorGroup $configuratorGroup,
        OfferKatalogAngebotsposition $katalogAp,
        ?OnkaConfiguratorItem $onkaConfiguratorItem,
        int $parentItemId = null
    )
    {
        $this->sort = $sort;
        $this->quantity = $quantity;
        $this->required = $required;
        $this->fixed = $fixed;
        $this->selected = $selected;
        $this->configuration = $configuration;
        $this->configuratorGroup = $configuratorGroup;
        $this->katalogAp = $katalogAp;
        $this->service = new ArrayCollection();
        $this->onkaConfiguratorItem = $onkaConfiguratorItem;
        $this->parentItemId = $parentItemId;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * @return bool
     */
    public function isFixed(): bool
    {
        return $this->fixed;
    }

    /**
     * @return bool
     */
    public function isSelected(): bool
    {
        return $this->selected;
    }

    /**
     * @return OnkaConfiguration
     */
    public function getConfiguration(): OnkaConfiguration
    {
        return $this->configuration;
    }

    /**
     * @return OnkaConfiguratorGroup
     */
    public function getConfiguratorGroup(): OnkaConfiguratorGroup
    {
        return $this->configuratorGroup;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferKatalogAngebotsposition
     */
    public function getKatalogAp(): OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return Collection
     */
    public function getService(): Collection
    {
        return $this->service;
    }

    /**
     * @return OnkaConfiguratorItem|null
     */
    public function getOnkaConfiguratorItem(): ?OnkaConfiguratorItem
    {
        return $this->onkaConfiguratorItem;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @param int $quantity
     */
    public function setQuantity(int $quantity): void
    {
        $this->quantity = $quantity;
    }

    /**
     * @param bool $required
     */
    public function setRequired(bool $required): void
    {
        $this->required = $required;
    }

    /**
     * @param bool $fixed
     */
    public function setFixed(bool $fixed): void
    {
        $this->fixed = $fixed;
    }

    /**
     * @param bool $selected
     */
    public function setSelected(bool $selected): void
    {
        $this->selected = $selected;
    }

    /**
     * @param OnkaConfiguration $configuration
     */
    public function setConfiguration(OnkaConfiguration $configuration): void
    {
        $this->configuration = $configuration;
    }

    /**
     * @param OnkaConfiguratorGroup $configuratorGroup
     */
    public function setConfiguratorGroup(OnkaConfiguratorGroup $configuratorGroup): void
    {
        $this->configuratorGroup = $configuratorGroup;
    }

    /**
     * @param OfferKatalogAngebotsposition $katalogAp
     */
    public function setKatalogAp(OfferKatalogAngebotsposition $katalogAp): void
    {
        $this->katalogAp = $katalogAp;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @param DateTime $bits
     */
    public function setBits(DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @param Collection $service
     */
    public function setService(Collection $service): void
    {
        $this->service = $service;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int|null
     */
    public function getParentItemId(): ?int
    {
        return $this->parentItemId;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @param float $unitCosts
     */
    public function setUnitCosts(float $unitCosts): void
    {
        $this->unitCosts = $unitCosts;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @param float|int $unitPrice
     */
    public function setUnitPrice($unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    /**
     * @return float|int
     */
    public function getUnitCosts()
    {
        return $this->unitCosts;
    }

    /**
     * @return float|int
     */
    public function getUnitPrice()
    {
        return $this->unitPrice;
    }
}
