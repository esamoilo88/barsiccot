<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class V_MultiSendConfirmLbu
 * @package App\Domain\Entities
 *
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Multi_Send_Confirm_LBU")
 */
class v_MultiSendConfirmLbu
{
    /**
     * @ORM\Id
     * @ORM\Column(name="lbu_id", type="integer")
     */
    private int $lbuId;

    /** @ORM\Column(name="simple_id", type="integer") */
    private int $simpleId;

    /** @ORM\Column(name="benutzer_id", type="integer") */
    private int $benutzerId;

    /** @ORM\Column(name="group_benutzer_id", type="integer") */
    private int $groupBenutzerId;

    /** @ORM\Column(name="role_short", type="string", length=50, nullable=false) */
    private string $roleShort;

    /** @ORM\Column(name="kundenname", type="string", length=255, nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="kundennummer", type="string", length=50, nullable=true) */
    private ?string $kundennummer;

    /** @ORM\Column(name="Leistungszeitraum", type="string", length=62, nullable=true) */
    private ?string $Leistungszeitraum;

    /** @ORM\Column(name="Fakturazeitraum", type="string", length=62, nullable=true) */
    private ?string $Fakturazeitraum;

    /** @ORM\Column(name="Preis_TP1", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $preisTP1 = null;

    /** @ORM\Column(name="Preis_TP2", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $preisTP2 = null;

    /** @ORM\Column(name="leistungs_jahr", type="integer") */
    private int $leistungsJahr;

    /** @ORM\Column(name="leistungs_monat", type="integer") */
    private int $leistungsMonat;

    /** @ORM\Column(name="automated", type="boolean") */
    private bool $automated = false;

    /** @ORM\Column(name="faktura_jahr", type="integer") */
    private int $fakturaJahr;

    /** @ORM\Column(name="faktura_monat", type="integer") */
    private int $fakturaMonat;

    /** @ORM\Column(name="gesendet_am", type="datetime", nullable=true) */
    private ?DateTime $gesendetAm;

    /** @ORM\Column(name="thema", type="string") */
    private string $vorhabenname;

    /** @ORM\Column(name="auto_approve", type="boolean") */
    private bool $autoApprove = false;

    /** @ORM\Column(name="freigabegrund_id", type="smallint", nullable=false) */
    private $freigabegrundId;

    /** @ORM\Column(name="send_at", type="string") */
    private string $sendAt;

    /** @ORM\Column(name="`external`", type="boolean", nullable=true) */
    private ?bool $external;

    /** @ORM\Column(name="representative", type="boolean", nullable=false) */
    private bool $representative;

    /** @ORM\Column(name="vorgangstyp", type="text", length=-1, nullable=true) */
    private $vorgangstyp;

    /** @ORM\Column(name="debitor_nummer", type="string", length=50, nullable=true) */
    private $debitorNummer;

    /** @ORM\Column(name="status_name", type="string") */
    private string $statusName;

    /** @ORM\Column(name="sys_name", type="string") */
    private string $sysName;

    /** @ORM\Column(name="is_status_writable", type="boolean") */
    private bool $isStatusWritable;

    /** @ORM\Column(name="status_progress", type="integer") */
    private int $statusProgress;

    /** @ORM\Column(name="status_icon", type="string", nullable=true) */
    private ?string $statusIcon = null;

    /** @ORM\Column(name="status_desc", type="string") */
    private string $statusDesc;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaFreigabegrund")
     * @ORM\JoinColumn(name="freigabegrund_id", referencedColumnName="freigabegrund_id")
     */
    private OfferFakturaFreigabegrund $freigabegrund;

    /** @ORM\Column(name="status_color", type="string", nullable=true) */
    private ?string $statusColor = null;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return string|null
     */
    public function getLeistungszeitraum(): ?string
    {
        return $this->Leistungszeitraum;
    }

    /**
     * @return float|null
     */
    public function getPreisTP2(): ?float
    {
        return $this->preisTP2;
    }

    /**
     * @return string|null
     */
    public function getVorhabenname(): ?string
    {
        return $this->vorhabenname;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string|null
     */
    public function getKundennummer(): ?string
    {
        return $this->kundennummer;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
