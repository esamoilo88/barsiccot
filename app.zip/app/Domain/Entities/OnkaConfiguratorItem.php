<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OnkaConfiguratorItem
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configurator_Item")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaConfiguratorItem
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfigurator")
     * @ORM\JoinColumn(name="configurator_id", referencedColumnName="id")
     */
    private OnkaConfigurator $configurator;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private OnkaConfiguratorGroup $configuratorGroup;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $katalogAp;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /** @ORM\Column(type="boolean") */
    private bool $required;

    /** @ORM\Column(type="boolean") */
    private bool $fixed;

    /** @ORM\Column(type="boolean") */
    private bool $selected;

    /** @ORM\Column(name="add_on_start", type="boolean") */
    private bool $addOnStart = false;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * OnkaConfiguratorItem constructor.
     * @param OnkaConfigurator $configurator
     * @param OnkaConfiguratorGroup $configuratorGroup
     * @param OfferKatalogAngebotsposition $katalogAp
     * @param int $sort
     * @param int $quantity
     * @param bool $required
     * @param bool $fixed
     * @param bool $selected
     */
    public function __construct(
        OnkaConfigurator $configurator,
        OnkaConfiguratorGroup $configuratorGroup,
        OfferKatalogAngebotsposition $katalogAp,
        int $sort,
        int $quantity,
        bool $required,
        bool $fixed,
        bool $selected
    )
    {
        $this->configurator = $configurator;
        $this->configuratorGroup = $configuratorGroup;
        $this->katalogAp = $katalogAp;
        $this->sort = $sort;
        $this->quantity = $quantity;
        $this->required = $required;
        $this->fixed = $fixed;
        $this->selected = $selected;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OnkaConfigurator
     */
    public function getConfigurator(): OnkaConfigurator
    {
        return $this->configurator;
    }

    /**
     * @return OnkaConfiguratorGroup
     */
    public function getConfiguratorGroup(): OnkaConfiguratorGroup
    {
        return $this->configuratorGroup;
    }

    /**
     * @return OfferKatalogAngebotsposition
     */
    public function getKatalogAp(): OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * @return bool
     */
    public function isAddOnStart(): bool
    {
        return $this->addOnStart;
    }

    /**
     * @return bool
     */
    public function isFixed(): bool
    {
        return $this->fixed;
    }

    /**
     * @return bool
     */
    public function isSelected(): bool
    {
        return $this->selected;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }
}
