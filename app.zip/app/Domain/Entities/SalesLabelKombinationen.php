<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesLabelKombinationen
 *
 * @ORM\Table(name="Sales_Label_Kombinationen")
 * @ORM\Entity
 */
class SalesLabelKombinationen
{
    /**
     * @var int
     *
     * @ORM\Column(name="label_kombinationen_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $labelKombinationenId;

    /**
     * @var SalesLabel
     *
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="quell_label_id", referencedColumnName="label_id")
     * })
     */
    private SalesLabel $quellLabel;

    /**
     * @var SalesLabel
     *
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="ziel_label_id", referencedColumnName="label_id")
     * })
     */
    private SalesLabel $zielLabel;

    /**
     * @return int
     */
    public function getLabelKombinationenId(): int
    {
        return $this->labelKombinationenId;
    }

    /**
     * @return SalesLabel
     */
    public function getQuellLabel(): SalesLabel
    {
        return $this->quellLabel;
    }

    /**
     * @param SalesLabel $quellLabel
     */
    public function setQuellLabel(SalesLabel $quellLabel): void
    {
        $this->quellLabel = $quellLabel;
    }

    /**
     * @return SalesLabel
     */
    public function getZielLabel(): SalesLabel
    {
        return $this->zielLabel;
    }

    /**
     * @param SalesLabel $zielLabel
     */
    public function setZielLabel(SalesLabel $zielLabel): void
    {
        $this->zielLabel = $zielLabel;
    }
}
