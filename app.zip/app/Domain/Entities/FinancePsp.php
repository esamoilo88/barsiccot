<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * FinancePsp
 *
 * @ORM\Table(name="Finance_PSP")
 * @ORM\Entity
 */
class FinancePsp
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="psp_element", type="string", length=50, nullable=false) */
    private string $pspElement;

    /** @ORM\Column(name="psp_element_sap", type="string", length=50, nullable=true) */
    private ?string $pspElementSap;

    /** @ORM\Column(name="name", type="string", length=150, nullable=false) */
    private string $name;

    /** @ORM\Column(name="parent_name", type="string", length=150, nullable=false) */
    private string $parentName;

    /** @ORM\Column(name="lob_name", type="string", length=50, nullable=true) */
    private ?string $lobName;

    /** @ORM\Column(name="lob_key", type="string", length=50, nullable=true) */
    private ?string $lobKey;

    /** @ORM\Column(name="collector", type="boolean", nullable=false) */
    private bool $collector = false;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide = false;

    /** @ORM\Column(name="locked", type="boolean", nullable=false) */
    private bool $locked = false;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="contact_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $contact;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="representative_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $representative;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private ?\DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private ?\DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\OneToMany(targetEntity="SalesStammdaten", mappedBy="pspElement") */
    private Collection $salesProject;

    /**
     * FinancePsp constructor.
     * @param string $pspElement
     * @param string|null $pspElementSap
     * @param string $name
     * @param string $parentName
     * @param BackendBenutzer|null $contact
     * @param BackendBenutzer|null $representative
     * @param bool $collector
     * @param bool $hide
     * @param bool $locked
     */
    public function __construct(
        string $pspElement,
        ?string $pspElementSap,
        string $name,
        string $parentName,
        ?BackendBenutzer $contact,
        ?BackendBenutzer $representative,
        bool $collector = false,
        bool $hide = false,
        bool $locked = false
    )
    {
        $this->pspElement = $pspElement;
        $this->pspElementSap = $pspElementSap;
        $this->parentName = $parentName;
        $this->name = $name;
        $this->contact = $contact;
        $this->representative = $representative;
        $this->hide = $hide;
        $this->locked = $locked;
        $this->collector = $collector;
    }

    /**
     * @return int
     * @Groups({"orderBasic"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Groups({"orderBasic", "pspDetails", "cbiOverview", "icp"})
     */
    public function getPspElement(): string
    {
        return $this->pspElement;
    }

    /**
     * @param string $pspElement
     */
    public function setPspElement(string $pspElement): void
    {
        $this->pspElement = $pspElement;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getPspElementSap(): ?string
    {
        return $this->pspElementSap;
    }

    /**
     * @param string|null $pspElementSap
     */
    public function setPspElementSap(?string $pspElementSap): void
    {
        $this->pspElementSap = $pspElementSap;
    }

    /**
     * @return string
     * @Groups({"orderBasic", "pspDetails", "icp"})
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     * @Groups({"orderBasic", "pspDetails", "icp"})
     */
    public function getParentName(): string
    {
        return $this->parentName;
    }

    /**
     * @param string $parentName
     */
    public function setParentName(string $parentName): void
    {
        $this->parentName = $parentName;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getLobName(): ?string
    {
        return $this->lobName;
    }

    /**
     * @param string|null $lobName
     */
    public function setLobName(?string $lobName): void
    {
        $this->lobName = $lobName;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getLobKey(): ?string
    {
        return $this->lobKey;
    }

    /**
     * @param string|null $lobKey
     */
    public function setLobKey(?string $lobKey): void
    {
        $this->lobKey = $lobKey;
    }

    /**
     * @return bool
     * @Groups({"pspDetails"})
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return bool
     * @Groups({"orderBasic", "pspDetails"})
     */
    public function isCollector(): bool
    {
        return $this->collector;
    }

    /**
     * @param bool $collector
     */
    public function setCollector(bool $collector): void
    {
        $this->collector = $collector;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool
     * @Groups({"orderBasic", "pspDetails", "icp"})
     */
    public function isLocked(): bool
    {
        return $this->locked;
    }

    /**
     * @param bool $locked
     */
    public function setLocked(bool $locked): void
    {
        $this->locked = $locked;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"orderBasic", "pspDetails"})
     */
    public function getContact(): ?BackendBenutzer
    {
        return $this->contact;
    }

    /**
     * @param BackendBenutzer|null $contact
     */
    public function setContact(?BackendBenutzer $contact): void
    {
        $this->contact = $contact;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"orderBasic", "pspDetails"})
     */
    public function getRepresentative(): ?BackendBenutzer
    {
        return $this->representative;
    }

    /**
     * @param BackendBenutzer|null $representative
     */
    public function setRepresentative(?BackendBenutzer $representative): void
    {
        $this->representative = $representative;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated(): ?\DateTime
    {
        return $this->created;
    }

    /**
     * @param \DateTime|null $created
     */
    public function setCreated(?\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime|null
     */
    public function getModified(): ?\DateTime
    {
        return $this->modified;
    }

    /**
     * @param \DateTime|null $modified
     */
    public function setModified(?\DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return Collection
     */
    public function getSalesProject(): Collection
    {
        return $this->salesProject;
    }
}
