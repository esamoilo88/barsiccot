<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OfferKatalogAngebotsposition
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_Angebotsposition")
 */
class OfferKatalogAngebotsposition
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @Groups({"onkaApprovalItems"})
     * @ORM\Column(type="boolean")
     */
    private bool $approved = false;

    /** @ORM\Column(type="string") */
    private string $code;

    /** @ORM\Column(type="boolean") */
    private bool $fixedPrice = false;

    /** @ORM\Column(type="string") */
    private string $name;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaProducttype", fetch="EAGER")
     * @ORM\JoinColumn(name="producttype_id", referencedColumnName="id")
     */
    private OnkaProducttype $producttype;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $flamingoProductCode;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id", nullable=true)
     */
    private ?OfferKatalogKategorie $catalogCategory;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $myshsProductCode;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $unitCosts;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $unitPrice;

    /** @ORM\OneToOne(targetEntity="OfferKatalogZuordnung", mappedBy="katalogAp") */
    private OfferKatalogZuordnung $zuordnung;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime", nullable=true)
     */
    private ?DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime", nullable=true)
     */
    private ?DateTime $modified;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $bits;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $description = null;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $eos;

    /** @ORM\OneToOne(targetEntity="OfferKatalogAPKategorie", mappedBy="katalogAp") */
    private OfferKatalogAPKategorie $katalogApKategorie;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinTable(name="Offer_Katalog_AP_Kategorie",
     *      joinColumns={@ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")}
     * )
     */
    private Collection $categories;

    /** @ORM\OneToMany(targetEntity="OnkaAPBundles", mappedBy="katAngebotsposition", cascade={"remove"}) */
    private Collection $bundles;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinTable(name="Offer_Katalog_LP_AP",
     *      joinColumns={@ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")}
     * )
     */
    private Collection $lps;

    /**
     * Variable for Katalog list
     * @var array
     */
    private array $breadcrumb = [];

    /**
     * Variable for Katalog list
     * @var bool
     */
    private bool $isOutdated = false;

    /**
     * OfferKatalogAngebotsposition constructor.
     * @param bool $fixedPrice
     * @param string $name
     * @param OnkaProducttype|object $producttype
     * @param int $quantity
     * @param string $code
     * @param string|null $unitPrice
     * @param string|null $description
     */
    public function __construct(
        bool $fixedPrice,
        string $name,
        OnkaProducttype $producttype,
        int $quantity,
        string $code,
        ?string $unitPrice,
        ?string $description
    )
    {
        $this->fixedPrice = $fixedPrice;
        $this->name = $name;
        $this->producttype = $producttype;
        $this->quantity = $quantity;
        $this->code = $code;
        $this->unitPrice = $unitPrice;
        $this->description = $description;

        $this->categories = new ArrayCollection();
        $this->lps = new ArrayCollection();
        $this->bundles = new ArrayCollection();
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return bool
     */
    public function isApproved(): bool
    {
        return $this->approved;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return bool
     */
    public function isFixedPrice(): bool
    {
        return $this->fixedPrice;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @Groups({"adminKatalog","confItemsPaginated"})
     * @return OnkaProducttype
     */
    public function getProducttype(): OnkaProducttype
    {
        return $this->producttype;
    }

    /**
     * @Groups({"adminKatalog","confItemsPaginated"})
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return boolean
     */
    public function getFixedPrice(): bool
    {
        return $this->fixedPrice;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @return string|null
     */
    public function getFlamingoProductCode(): ?string
    {
        return $this->flamingoProductCode;
    }

    /**
     * @return OfferKatalogKategorie|null
     */
    public function getCatalogCategory(): ?OfferKatalogKategorie
    {
        return $this->catalogCategory;
    }

    /**
     * @return string|null
     */
    public function getMyshsProductCode(): ?string
    {
        return $this->myshsProductCode;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return float|null
     */
    public function getUnitCosts(): ?float
    {
        return $this->unitCosts;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return float|null
     */
    public function getUnitPrice(): ?float
    {
        return $this->unitPrice;
    }

    /**
     * @return OfferKatalogZuordnung
     */
    public function getZuordnung(): OfferKatalogZuordnung
    {
        return $this->zuordnung;
    }

    /**
     * @return DateTime|null
     */
    public function getCreated(): ?DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime|null
     */
    public function getModified(): ?DateTime
    {
        return $this->modified;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @param bool $approved
     */
    public function setApproved(bool $approved): void
    {
        $this->approved = $approved;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param bool $fixedPrice
     */
    public function setFixedPrice(bool $fixedPrice): void
    {
        $this->fixedPrice = $fixedPrice;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param OnkaProducttype|object $producttype
     */
    public function setProducttype(OnkaProducttype $producttype): void
    {
        $this->producttype = $producttype;
    }

    /**
     * @param int $quantity
     */
    public function setQuantity(int $quantity): void
    {
        $this->quantity = $quantity;
    }

    /**
     * @param string|null $description
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @param string|null $flamingoProductCode
     */
    public function setFlamingoProductCode(?string $flamingoProductCode): void
    {
        $this->flamingoProductCode = $flamingoProductCode;
    }

    /**
     * @param OfferKatalogKategorie|null $catalogCategory
     */
    public function setCatalogCategory(?OfferKatalogKategorie $catalogCategory): void
    {
        $this->catalogCategory = $catalogCategory;
    }

    /**
     * @param string|null $myshsProductCode
     */
    public function setMyshsProductCode(?string $myshsProductCode): void
    {
        $this->myshsProductCode = $myshsProductCode;
    }

    /**
     * @param float|null $unitCosts
     */
    public function setUnitCosts(?float $unitCosts): void
    {
        $this->unitCosts = $unitCosts;
    }

    /**
     * @param float|null $unitPrice
     */
    public function setUnitPrice(?float $unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    /**
     * @param OfferKatalogZuordnung $zuordnung
     */
    public function setZuordnung(OfferKatalogZuordnung $zuordnung): void
    {
        $this->zuordnung = $zuordnung;
    }

    /**
     * @Groups({"confItemsPaginated", "adminKatalog"})
     * @return DateTime|null
     */
    public function getEos(): ?DateTime
    {
        return $this->eos;
    }

    /**
     * @param DateTime|null $eos
     */
    public function setEos(?DateTime $eos): void
    {
        $this->eos = $eos;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return Collection
     */
    public function getBundles(): Collection
    {
        return $this->bundles;
    }

    /**
     * @return Collection
     */
    public function getLps(): Collection
    {
        return $this->lps;
    }

    /**
     * @param Collection $lps
     */
    public function setLps(Collection $lps): void
    {
        $this->lps = $lps;
    }

    /**
     * @return OfferKatalogAPKategorie
     */
    public function getKatalogApKategorie(): OfferKatalogAPKategorie
    {
        return $this->katalogApKategorie;
    }

    /**
     * @param OfferKatalogAPKategorie $katalogApKategorie
     */
    public function setKatalogApKategorie(OfferKatalogAPKategorie $katalogApKategorie): void
    {
        $this->katalogApKategorie = $katalogApKategorie;
    }

    /**
     * @return array
     */
    public function getBreadcrumb(): array
    {
        return $this->breadcrumb;
    }

    /**
     * @param array $breadcrumb
     */
    public function setBreadcrumb(array $breadcrumb): void
    {
        $this->breadcrumb = $breadcrumb;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return bool
     */
    public function isOutdated(): bool
    {
        return $this->isOutdated;
    }

    /**
     * @param bool $isOutdated
     */
    public function setIsOutdated(bool $isOutdated): void
    {
        $this->isOutdated = $isOutdated;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getCategories()
    {
        return $this->categories;
    }

    /**
     * @param ArrayCollection|Collection $categories
     */
    public function setCategories($categories): void
    {
        $this->categories = $categories;
    }
}
