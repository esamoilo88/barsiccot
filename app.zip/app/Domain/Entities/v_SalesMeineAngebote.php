<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Sales_MeineAngebote")
 */
class v_SalesMeineAngebote
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private int $simpleId;

    /** @ORM\Column(name="start_simple_id", type="integer", nullable=true) */
    private ?int $startSimpleId;

    /** @ORM\Column(name="vertragsdaten_gesendet_am", type="datetime", nullable=true) */
    private ?\DateTime $vertragsdatenGesendetAm;

    /** @ORM\Column(name="abgeschlossenGrund_id", type="integer", nullable=true) */
    private ?int $abgeschlossenGrundId;

    /** @ORM\Column(name="Version", type="string", nullable=true) */
    private ?string $version;

    /** @ORM\Column(name="thema", type="string", nullable=true) */
    private ?string $thema;

    /** @ORM\Column(name="kundenname", type="string", length=255, nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="kundennummer", type="string", length=50, nullable=true) */
    private ?string $kundennummer;

    /** @ORM\Column(name="vorhabenbeschreibung", type="string", nullable=true) */
    private ?string $vorhabenbeschreibung;

    /** @ORM\Column(name="vertragsbeginn", type="datetime", nullable=true) */
    private ?\DateTime $vertragsbeginn;

    /** @ORM\Column(name="vertragsende", type="datetime", nullable=true) */
    private ?\DateTime $vertragsende;

    /** @ORM\Column(name="bearbeitung_begonnen_am", type="datetime", nullable=true) */
    private ?\DateTime $bearbeitungBegonnenAm;

    /** @ORM\Column(name="weitergeleitet_am", type="datetime", nullable=true) */
    private ?\DateTime $weitergeleitetAm;

    /** @ORM\Column(name="angebot_angefordert_am", type="datetime", nullable=true) */
    private ?\DateTime $angebotAngefordertAm;

    /** @ORM\Column(name="angebot_gesendet_am", type="datetime", nullable=true) */
    private ?\DateTime $angebotGesendetAm;

    /** @ORM\Column(name="vk_gesamt", type="decimal", nullable=true) */
    private ?float $vkGesamt;

    /** @ORM\Column(name="tp_dtts_gesamt", type="decimal", nullable=true) */
    private ?float $tpDttsGesamt;

    /** @ORM\Column(name="kvm_eingebunden_am", type="datetime", nullable=true) */
    private ?\DateTime $kvmEingebundenAm;

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getVersion(): ?string
    {
        return $this->version;
    }

    /**
     * @return string|null
     */
    public function getThema(): ?string
    {
        return $this->thema;
    }

    /**
     * @return \DateTime|null
     */
    public function getBearbeitungBegonnenAm(): ?\DateTime
    {
        return $this->bearbeitungBegonnenAm;
    }

    /**
     * @return \DateTime|null
     */
    public function getWeitergeleitetAm(): ?\DateTime
    {
        return $this->weitergeleitetAm;
    }

    /**
     * @return \DateTime|null
     */
    public function getAngebotAngefordertAm(): ?\DateTime
    {
        return $this->angebotAngefordertAm;
    }

    /**
     * @return \DateTime|null
     */
    public function getAngebotGesendetAm(): ?\DateTime
    {
        return $this->angebotGesendetAm;
    }

    /**
     * @return float|null
     */
    public function getVkGesamt(): ?float
    {
        return $this->vkGesamt;
    }

    /**
     * @return float|null
     */
    public function getTpDttsGesamt(): ?float
    {
        return $this->tpDttsGesamt;
    }

    /**
     * @return \DateTime|null
     */
    public function getKvmEingebundenAm(): ?\DateTime
    {
        return $this->kvmEingebundenAm;
    }

    /**
     * @return int|null
     */
    public function getStartSimpleId(): ?int
    {
        return $this->startSimpleId;
    }

    /**
     * @return \DateTime|null
     */
    public function getVertragsdatenGesendetAm(): ?\DateTime
    {
        return $this->vertragsdatenGesendetAm;
    }

    /**
     * @return int|null
     */
    public function getAbgeschlossenGrundId(): ?int
    {
        return $this->abgeschlossenGrundId;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string|null
     */
    public function getKundennummer(): ?string
    {
        return $this->kundennummer;
    }

    /**
     * @return string|null
     */
    public function getVorhabenbeschreibung(): ?string
    {
        return $this->vorhabenbeschreibung;
    }

    /**
     * @return \DateTime|null
     */
    public function getVertragsbeginn(): ?\DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return \DateTime|null
     */
    public function getVertragsende(): ?\DateTime
    {
        return $this->vertragsende;
    }
}
