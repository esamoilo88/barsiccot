<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferPsaGruppen
 *
 * @ORM\Table(name="Offer_PSA_Gruppen")
 * @ORM\Entity
 */
class OfferPsaGruppen
{
    /**
     * @var int
     *
     * @ORM\Column(name="psa_gruppen_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $psaGruppenId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=200, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferPsaAntworten
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaAntworten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="antwort_id", referencedColumnName="antwort_id")
     * })
     */
    private $antwort;

    /**
     * @var \OfferPsaFragen
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaFragen")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="frage_id", referencedColumnName="frage_id")
     * })
     */
    private $frage;


}
