<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferPsaAntworten
 *
 * @ORM\Table(name="Offer_PSA_Antworten")
 * @ORM\Entity
 */
class OfferPsaAntworten
{
    /**
     * @var int
     *
     * @ORM\Column(name="antwort_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $antwortId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="punktwert", type="integer", nullable=true)
     */
    private $punktwert;

    /**
     * @var string|null
     *
     * @ORM\Column(name="antwort", type="string", length=2048, nullable=true)
     */
    private $antwort;

    /**
     * @var \OfferPsaFragen
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaFragen")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="frage_id", referencedColumnName="frage_id")
     * })
     */
    private $frage;


}
