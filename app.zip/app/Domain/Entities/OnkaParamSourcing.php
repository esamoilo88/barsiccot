<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OnkaParamSourcing
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Param_Sourcing")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaParamSourcing
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaParamField")
     * @ORM\JoinColumn(name="field_id", referencedColumnName="id")
     */
    private OnkaParamField $paramField;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorParam")
     * @ORM\JoinColumn(name="param_id", referencedColumnName="id")
     */
    private OnkaConfiguratorParam $configuratorParam;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="kat_angebotsposition_id", referencedColumnName="id", nullable=true)
     */
    private ?OfferKatalogAngebotsposition $katalogAp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="kat_leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKatalogLeistungsposition $katalogLp;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    public CONST MENGE_SYS_FIELD_NAME = 'menge';

    /**
     * OnkaParamSourcing constructor.
     * @param OnkaParamField $paramField
     * @param OnkaConfiguratorParam $configuratorParam
     * @param OfferKatalogAngebotsposition|null $katalogAp
     * @param OfferKatalogLeistungsposition|null $katalogLp
     */
    public function __construct(
        OnkaParamField $paramField,
        OnkaConfiguratorParam $configuratorParam,
        ?OfferKatalogAngebotsposition $katalogAp,
        ?OfferKatalogLeistungsposition $katalogLp
    )
    {
        $this->paramField = $paramField;
        $this->configuratorParam = $configuratorParam;
        $this->katalogAp = $katalogAp;
        $this->katalogLp = $katalogLp;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OnkaParamField
     */
    public function getParamField(): OnkaParamField
    {
        return $this->paramField;
    }

    /**
     * @return OnkaConfiguratorParam
     */
    public function getConfiguratorParam(): OnkaConfiguratorParam
    {
        return $this->configuratorParam;
    }

    /**
     * @return OfferKatalogAngebotsposition|null
     */
    public function getKatalogAp(): ?OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @return OfferKatalogLeistungsposition|null
     */
    public function getKatalogLp(): ?OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }
}
