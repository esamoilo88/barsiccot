<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferKatalogBerechnung
 *
 * @ORM\Table(name="Offer_Katalog_Berechnung")
 * @ORM\Entity
 */
class OfferKatalogBerechnung
{
    /**
     * @var int
     *
     * @ORM\Column(type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $berechnungId;

    /** @ORM\Column(type="string", length=50, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(type="string", length=1, nullable=true) */
    private ?string $operator;

    /** @ORM\Column(type="decimal", precision=18, scale=10) */
    private string $wert;

    /** @ORM\Column(type="text", length=-1, nullable=true) */
    private ?string $kommentar;

    /** @ORM\Column(type="datetime", nullable=true) */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogElement")
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id", nullable=true)
     */
    private ?OfferKatalogElement $element;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKatalogLeistungsposition $leistungsposition;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogElement")
     * @ORM\JoinTable(name="Offer_Katalog_BER_EL_LP",
     *      joinColumns={@ORM\JoinColumn(name="berechnung_id", referencedColumnName="berechnung_id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="element_id", referencedColumnName="element_id")}
     * )
     */
    private Collection $els;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinTable(name="Offer_Katalog_BER_EL_LP",
     *      joinColumns={@ORM\JoinColumn(name="berechnung_id", referencedColumnName="berechnung_id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")}
     * )
     */
    private Collection $lps;

    /**
     * OfferKatalogBerechnung constructor.
     * @param string $wert
     * @param string|null $bezeichnung
     * @param string|null $operator
     */
    public function __construct(string $wert, ?string $bezeichnung = null, ?string $operator = null)
    {
        $this->wert = $wert;
        $this->bezeichnung = $bezeichnung;
        $this->operator = $operator;
        $this->els = new ArrayCollection();
        $this->lps = new ArrayCollection();
    }

    /**
     * @Groups({"adminKatalog"})
     * @return int
     */
    public function getBerechnungId(): int
    {
        return $this->berechnungId;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getOperator(): ?string
    {
        return $this->operator;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return float
     */
    public function getWert(): float
    {
        return $this->wert;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @param float $wert
     */
    public function setWert(float $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param string|null $operator
     */
    public function setOperator(?string $operator): void
    {
        $this->operator = $operator;
    }

    /**
     * @param string|null $kommentar
     */
    public function setKommentar(?string $kommentar): void
    {
        $this->kommentar = $kommentar;
    }

    /**
     * @param OfferKatalogElement|null|object $element
     */
    public function setElement(?OfferKatalogElement $element): void
    {
        $this->element = $element;
    }

    /**
     * @param OfferKatalogLeistungsposition|null|object $leistungsposition
     */
    public function setLeistungsposition(?OfferKatalogLeistungsposition $leistungsposition): void
    {
        $this->leistungsposition = $leistungsposition;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getEls()
    {
        return $this->els;
    }

    /**
     * @param ArrayCollection|Collection $els
     */
    public function setEls($els): void
    {
        $this->els = $els;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getLps()
    {
        return $this->lps;
    }

    /**
     * @param ArrayCollection|Collection $lps
     */
    public function setLps($lps): void
    {
        $this->lps = $lps;
    }

    /**
     * @return OfferKatalogLeistungsposition|null
     */
    public function getLeistungsposition(): ?OfferKatalogLeistungsposition
    {
        return $this->leistungsposition;
    }
}
