<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class MappingLegacyKostenart
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Mapping_Legacy_Kostenart")
 */
class MappingLegacyKostenart
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id_alt", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenartIdAlt;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id_new", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenartIdNew;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id", nullable=true)
     */
    private ?CostsKostenstelle $kostenstelle;

    /**
     * @ORM\Column(name="service_region", type="boolean", nullable=false)
     */
    private bool $serviceRegion;

    /**
     * @ORM\Column(name="ress_to_cost", type="boolean", nullable=false)
     */
    private bool $ressToCost;
}
