<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity
 * @ORM\Table(name="Finance_Invoice")
 */
class FinanceInvoice
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="faktura_monat", type="integer") */
    private int $fakturaMonat;

    /** @ORM\Column(name="faktura_jahr", type="integer") */
    private int $fakturaJahr;

    /** @ORM\Column(name="invoice_nr", type="integer", nullable=true) */
    private ?int $invoiceNr = null;

    /** @ORM\Column(name="billing_subject", type="string", length=600, nullable=true) */
    private ?string $billingSubject = null;

    /** @ORM\Column(name="billing_date", type="datetime", nullable=true) */
    private ?DateTime $billingDate = null;

    /** @ORM\Column(name="billing_head_reference", type="string", length=12, nullable=true) */
    private ?string $billingHeadReference = null;

    /** @ORM\Column(name="sap_interface_filename", type="string", length=32, nullable=true) */
    private ?string $sapInterfaceFilename = null;

    /** @ORM\Column(name="sap_transaction_code", type="bigint", nullable=true) */
    private ?int $sapTransactionCode = null;

    /** @ORM\Column(name="sap_invoice_code", type="bigint", nullable=true) */
    private ?int $sapInvoiceCode = null;

    /** @ORM\Column(name="sap_status", type="string", length=50, nullable=true) */
    private ?string $sapStatus = null;

    /** @ORM\Column(name="closed", type="boolean") */
    private bool $closed = false;

    /** @ORM\Column(name="transferred", type="datetime", nullable=true) */
    private ?DateTime $transferred = null;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private ?DateTime $modified = null;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceStream")
     * @ORM\JoinColumn(name="stream_id", referencedColumnName="id")
     */
    private FinanceStream $stream;

    /**
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id", nullable=true)
     */
    private ?OfferDebitor $debitor;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="created_by", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $createdBy;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="ansprechpartner_id", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $ansprechpartner;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaVorgangstyp")
     * @ORM\JoinColumn(name="vorgangstyp_id", referencedColumnName="vorgangstyp_id")
     */
    private OfferFakturaVorgangstyp $vorgangstyp;

    /** @ORM\OneToMany(targetEntity="FinanceInvoicePositions", mappedBy="invoice") */
    private Collection $positions;

    /**
     * FinanceInvoice constructor.
     * @param int $fakturaMonat
     * @param int $fakturaJahr
     * @param FinanceStream|object $stream
     * @param BackendBenutzer $createdBy
     */
    public function __construct(int $fakturaMonat, int $fakturaJahr, FinanceStream $stream, BackendBenutzer $createdBy)
    {
        $this->fakturaMonat = $fakturaMonat;
        $this->fakturaJahr = $fakturaJahr;
        $this->stream = $stream;
        $this->createdBy = $createdBy;

        $this->positions = new ArrayCollection();
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int
     */
    public function getFakturaMonat(): int
    {
        return $this->fakturaMonat;
    }

    /**
     * @param int $fakturaMonat
     */
    public function setFakturaMonat(int $fakturaMonat): void
    {
        $this->fakturaMonat = $fakturaMonat;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int
     */
    public function getFakturaJahr(): int
    {
        return $this->fakturaJahr;
    }

    /**
     * @param int $fakturaJahr
     */
    public function setFakturaJahr(int $fakturaJahr): void
    {
        $this->fakturaJahr = $fakturaJahr;
    }

    /**
     * @return int|null
     */
    public function getInvoiceNr(): ?int
    {
        return $this->invoiceNr;
    }

    /**
     * @param int|null $invoiceNr
     */
    public function setInvoiceNr(?int $invoiceNr): void
    {
        $this->invoiceNr = $invoiceNr;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getBillingSubject(): ?string
    {
        return $this->billingSubject;
    }

    /**
     * @param string|null $billingSubject
     */
    public function setBillingSubject(?string $billingSubject): void
    {
        $this->billingSubject = $billingSubject;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return DateTime|null
     */
    public function getBillingDate(): ?DateTime
    {
        return $this->billingDate;
    }

    /**
     * @param DateTime|null $billingDate
     */
    public function setBillingDate(?DateTime $billingDate): void
    {
        $this->billingDate = $billingDate;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getBillingHeadReference(): ?string
    {
        return $this->billingHeadReference;
    }

    /**
     * @param string|null $billingHeadReference
     */
    public function setBillingHeadReference(?string $billingHeadReference): void
    {
        $this->billingHeadReference = $billingHeadReference;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getSapInterfaceFilename(): ?string
    {
        return $this->sapInterfaceFilename;
    }

    /**
     * @param string|null $sapInterfaceFilename
     */
    public function setSapInterfaceFilename(?string $sapInterfaceFilename): void
    {
        $this->sapInterfaceFilename = $sapInterfaceFilename;
    }

    /**
     * @return int|null
     */
    public function getSapTransactionCode(): ?int
    {
        return $this->sapTransactionCode;
    }

    /**
     * @Groups({"cbiOverview"})
     * @param int|null $sapTransactionCode
     */
    public function setSapTransactionCode(?int $sapTransactionCode): void
    {
        $this->sapTransactionCode = $sapTransactionCode;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int|null
     */
    public function getSapInvoiceCode(): ?int
    {
        return $this->sapInvoiceCode;
    }

    /**
     * @param int|null $sapInvoiceCode
     */
    public function setSapInvoiceCode(?int $sapInvoiceCode): void
    {
        $this->sapInvoiceCode = $sapInvoiceCode;
    }

    /**
     * @return string|null
     * @Groups({"cbiOverview"})
     */
    public function getSapStatus(): ?string
    {
        return $this->sapStatus;
    }

    /**
     * @param string|null $sapStatus
     */
    public function setSapStatus(?string $sapStatus): void
    {
        $this->sapStatus = $sapStatus;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return bool
     */
    public function isClosed(): bool
    {
        return $this->closed;
    }

    /**
     * @param bool $closed
     */
    public function setClosed(bool $closed): void
    {
        $this->closed = $closed;
    }

    /**
     * @return DateTime|null
     * @Groups({"cbiOverview"})
     */
    public function getTransferred(): ?DateTime
    {
        return $this->transferred;
    }

    /**
     * @param DateTime|null $transferred
     */
    public function setTransferred(?DateTime $transferred): void
    {
        $this->transferred = $transferred;
    }

    /**
     * @return DateTime
     * @Groups({"cbiOverview"})
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime|null
     */
    public function getModified(): ?DateTime
    {
        return $this->modified;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return FinanceStream
     */
    public function getStream(): FinanceStream
    {
        return $this->stream;
    }

    /**
     * @param FinanceStream $stream
     */
    public function setStream(FinanceStream $stream): void
    {
        $this->stream = $stream;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return OfferDebitor|null
     */
    public function getDebitor(): ?OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @param OfferDebitor|object|null $debitor
     */
    public function setDebitor(?OfferDebitor $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return BackendBenutzer
     */
    public function getCreatedBy(): BackendBenutzer
    {
        return $this->createdBy;
    }

    /**
     * @param BackendBenutzer $createdBy
     */
    public function setCreatedBy(BackendBenutzer $createdBy): void
    {
        $this->createdBy = $createdBy;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return BackendBenutzer|null
     */
    public function getAnsprechpartner(): ?BackendBenutzer
    {
        return $this->ansprechpartner;
    }

    /**
     * @param BackendBenutzer|object|null $ansprechpartner
     */
    public function setAnsprechpartner(?BackendBenutzer $ansprechpartner): void
    {
        $this->ansprechpartner = $ansprechpartner;
    }

    /**
     * @return OfferFakturaVorgangstyp
     */
    public function getVorgangstyp(): OfferFakturaVorgangstyp
    {
        return $this->vorgangstyp;
    }

    /**
     * @param OfferFakturaVorgangstyp|object $vorgangstyp
     */
    public function setVorgangstyp(OfferFakturaVorgangstyp $vorgangstyp): void
    {
        $this->vorgangstyp = $vorgangstyp;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return ArrayCollection|Collection
     */
    public function getPositions()
    {
        return $this->positions;
    }

    /**
     * @param ArrayCollection|Collection $positions
     */
    public function setPositions($positions): void
    {
        $this->positions = $positions;
    }

    /**
     * @param FinanceInvoicePositions $position
     */
    public function addPosition(FinanceInvoicePositions $position): void
    {
        $this->positions->add($position);
    }
}
