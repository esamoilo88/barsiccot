<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class VorhabenGrid
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="v_MyProjects")
 */
class v_MyProjects
{
    /**
     * @ORM\Column(name="simple_id", type="string")
     * @ORM\Id
     */
    private string $simpleId;

    /** @ORM\Column(name="thema", type="string") */
    private string $vorhabenname;

    /** @ORM\Column(name="kundenname", type="string") */
    private string $kundenname;

    /** @ORM\Column(name="volumen_dtts", type="decimal") */
    private float $volumenDtts;

    /**
     * @ORM\OneToOne(targetEntity="SalesStatus", fetch="EAGER")
     * @ORM\JoinColumn(name="status", referencedColumnName="id")
     */
    private SalesStatus $status;

    /** @ORM\OneToOne(targetEntity="SalesStammdaten", mappedBy="globalGate") */
    private SalesStammdaten $salesStammdaten;

    /** @ORM\Column(name="active", type="string", nullable=true) */
    private ?string $active;

    /** @ORM\Column(name="loss", type="boolean", nullable=false) */
    private bool $loss;

    /** @ORM\Column(name="presales", type="boolean", nullable=false) */
    private bool $presales;

    /** @ORM\Column(name="offer_complete", type="boolean", nullable=false) */
    private bool $offerComplete;

    /** @ORM\Column(name="benutzer_id", type="integer", nullable=true) */
    private ?int $benutzerId;

    /** @ORM\Column(name="role_short", type="string", nullable=true) */
    private ?string $role;

    /** @ORM\Column(name="representative", type="boolean", nullable=true) */
    private ?bool $representative;

    /** @ORM\Column(name="psp_element", type="string", nullable=true) */
    private ?string $pspElement;

    /**
     * @ORM\OneToOne(targetEntity="FinanceSINBalance")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private FinanceSINBalance $financeSINBalance;

    /**
     * @ORM\OneToOne(targetEntity="FinanceSinStatus")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private FinanceSinStatus $financeSINStatus;

    /** @ORM\Column(name="angebot_angefordert_am", type="datetime", nullable=true) */
    private ?DateTime $angebotAngefordertAm;

    /** @ORM\Column(name="versionsnr", type="smallint", nullable=false) */
    private int $versionsnr;

    /** @ORM\Column(name="vk_gesamt", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $vkGesamt;

    /** @ORM\Column(name="total_price", type="decimal", precision=18, scale=2, nullable=true) */
    private ?float $totalPrice = null;

    /** @ORM\Column(name="offer_completed", type="datetime", nullable=true) */
    private ?DateTime $offerCompleted;

    /**
     * @return string
     */
    public function getSimpleId(): string
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getVorhabenname(): string
    {
        return $this->vorhabenname;
    }

    /**
     * @return string
     */
    public function getKundenname(): string
    {
        return $this->kundenname;
    }

    /**
     * @return float
     */
    public function getVolumenDtts(): float
    {
        return $this->volumenDtts;
    }

    /**
     * @return SalesStatus
     */
    public function getStatus(): SalesStatus
    {
        return $this->status;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSalesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return string|null
     */
    public function getActive(): ?string
    {
        return $this->active;
    }

    /**
     * @return bool
     */
    public function isLoss(): bool
    {
        return $this->loss;
    }

    /**
     * @return bool
     */
    public function isPresales(): bool
    {
        return $this->presales;
    }

    /**
     * @return bool
     */
    public function isOfferComplete(): bool
    {
        return $this->offerComplete;
    }

    /**
     * @return int|null
     */
    public function getBenutzerId(): ?int
    {
        return $this->benutzerId;
    }

    /**
     * @return string|null
     */
    public function getRole(): ?string
    {
        return $this->role;
    }

    /**
     * @return bool|null
     */
    public function getRepresentative(): ?bool
    {
        return $this->representative;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }
}
