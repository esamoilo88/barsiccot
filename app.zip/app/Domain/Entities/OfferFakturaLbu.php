<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferFakturaLbu
 *
 * @ORM\Table(name="Offer_Faktura_LBU")
 * @ORM\Entity
 */
class OfferFakturaLbu
{
    /**
     * @ORM\Column(name="lbu_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $lbuId;

    /** @ORM\Column(name="redesign", type="boolean", nullable=false) */
    private bool $redesign = false;

    /** @ORM\Column(name="leistungs_jahr", type="integer", nullable=false) */
    private int $leistungsJahr;

    /** @ORM\Column(name="leistungs_monat", type="smallint", nullable=false) */
    private int $leistungsMonat;

    /** @ORM\Column(name="faktura_jahr", type="integer", nullable=false) */
    private int $fakturaJahr;

    /** @ORM\Column(name="faktura_monat", type="smallint", nullable=false) */
    private int $fakturaMonat;

    /** @ORM\Column(name="lieferversion", type="string", length=2, nullable=true) */
    private ?string $lieferversion;

    /** @ORM\Column(name="kommentar", type="text", length=-1, nullable=true) */
    private ?string $kommentar;

    /** @ORM\Column(name="dateiname", type="string", length=50, nullable=true) */
    private ?string $dateiname;

    /** @ORM\Column(name="gesendet_am", type="datetime", nullable=true) */
    private ?DateTime $gesendetAm;

    /** @ORM\Column(name="bestaetigt_am", type="datetime", nullable=true) */
    private ?DateTime $bestaetigtAm;

    /** @ORM\Column(name="abgelehnt", type="boolean", nullable=true) */
    private ?bool $abgelehnt;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private DateTime $modified;

    /** @ORM\Column(name="fakturiert_am", type="datetime", nullable=true) */
    private ?DateTime $fakturiertAm;

    /** @ORM\Column(name="abgrenzung", type="boolean", nullable=false) */
    private bool $abgrenzung = false;

    /** @ORM\Column(name="rechnungsnummer", type="string", length=50, nullable=true) */
    private ?string $rechnungsnummer;

    /** @ORM\Column(name="fakturabereit", type="datetime", nullable=true) */
    private ?DateTime $fakturabereit;

    /** @ORM\Column(name="sap_bestellnummer", type="string", length=50, nullable=true) */
    private ?string $sapBestellnummer;

    /** @ORM\Column(name="dateiname_sap", type="string", length=32, nullable=true) */
    private ?string $dateinameSap;

    /** @ORM\Column(name="billing_subject_extension", type="string", length=150, nullable=true) */
    private ?string $billingSubjectExtension;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="ansprechpartner_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $ansprechpartner;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaFreigabegrund")
     * @ORM\JoinColumn(name="freigabegrund_id", referencedColumnName="freigabegrund_id", nullable=true)
     */
    private ?OfferFakturaFreigabegrund $freigabegrund = null;

    /**
     * @ORM\ManyToOne(targetEntity="SalesAngebotTp")
     * @ORM\JoinColumn(name="tp_versions_id", referencedColumnName="tp_versions_id")
     */
    private ?SalesAngebotTp $tpVersions;

    /**
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id")
     */
    private ?OfferDebitor $debitor;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaFakturaziel")
     * @ORM\JoinColumn(name="fakturaziel_id", referencedColumnName="fakturaziel_id")
     */
    private OfferFakturaFakturaziel $fakturaziel;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaVorgangstyp")
     * @ORM\JoinColumn(name="vorgangstyp_id", referencedColumnName="vorgangstyp_id", nullable=true)
     */
    private ?OfferFakturaVorgangstyp $vorgangstyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuStatus")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id", nullable=true)
     */
    private ?OfferFakturaLbuStatus $status = null;

    /** @ORM\Column(name="sap_transaction_code", type="bigint", nullable=true) */
    private ?int $sapTransactionCode = null;

    /** @ORM\Column(name="sap_invoice_code", type="bigint", nullable=true) */
    private ?int $sapInvoiceCode = null;

    /** @ORM\Column(name="sap_status", type="string", length=50, nullable=true) */
    private ?string $sapStatus = null;

    /** @ORM\OneToMany(targetEntity="OfferFakturaLbuDaten", mappedBy="lbu", cascade={"remove"}) */
    private Collection $lbuDaten;

    /** @ORM\Column(name="automated", type="boolean") */
    private bool $automated = false;

    /**
     * @ORM\OneToOne(targetEntity="FinanceCreditReason")
     * @ORM\JoinColumn(name="credit_reason_id", referencedColumnName="id")
     */
    private ?FinanceCreditReason $creditReason = null;

    /** @ORM\OneToMany(targetEntity="FinanceAutomationFakturaplan", mappedBy="lbu") */
    private Collection $fakturaplan;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="created_by", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $createdBy;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceAutomationFakturaplan")
     * @ORM\JoinColumn(name="fakturaplan_id", referencedColumnName="id", nullable=true)
     */
    private ?FinanceAutomationFakturaplan $financeFakturaplan = null;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $pending = null;

    /**
     * OfferFakturaLbu constructor.
     * @param int $leistungsJahr
     * @param int $leistungsMonat
     * @param int $fakturaJahr
     * @param int $fakturaMonat
     * @param OfferAuftrag|object $simple
     * @param OfferFakturaVorgangstyp|object $vorgangstyp
     * @param OfferFakturaFakturaziel|object $fakturaziel
     * @param BackendBenutzer|object $ansprechpartner
     * @param BackendBenutzer|null $createdBy
     * @param OfferDebitor|object $debitor
     * @param OfferFakturaLbuStatus|object $status
     * @param bool $abgrenzung
     * @param string|null $bestellnummer
     * @param bool|null $pending
     */
    public function __construct(
        int $leistungsJahr,
        int $leistungsMonat,
        int $fakturaJahr,
        int $fakturaMonat,
        OfferAuftrag $simple,
        OfferFakturaVorgangstyp $vorgangstyp,
        OfferFakturaFakturaziel $fakturaziel,
        BackendBenutzer $ansprechpartner,
        ?BackendBenutzer $createdBy,
        OfferDebitor $debitor,
        OfferFakturaLbuStatus $status,
        bool $abgrenzung,
        ?string $bestellnummer = null,
        ?bool $pending = null
    )
    {
        $this->leistungsJahr = $leistungsJahr;
        $this->leistungsMonat = $leistungsMonat;
        $this->fakturaJahr = $fakturaJahr;
        $this->fakturaMonat = $fakturaMonat;
        $this->simple = $simple;
        $this->vorgangstyp = $vorgangstyp;
        $this->fakturaziel = $fakturaziel;
        $this->ansprechpartner = $ansprechpartner;
        $this->abgrenzung = $abgrenzung;
        $this->createdBy = $createdBy;
        $this->debitor = $debitor;
        $this->sapBestellnummer = $bestellnummer;
        $this->status = $status;
        $this->lieferversion = "A";
        $this->pending = $pending;
        $this->fakturaplan = new ArrayCollection();
    }

    /**
     * @return OfferFakturaLbuStatus|null
     */
    public function getStatus(): ?OfferFakturaLbuStatus
    {
        return $this->status;
    }

    /**
     * @param OfferFakturaLbuStatus|null $status
     */
    public function setStatus(?OfferFakturaLbuStatus $status): void
    {
        $this->status = $status;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return bool
     */
    public function isRedesign(): bool
    {
        return $this->redesign;
    }

    /**
     * @param bool $redesign
     */
    public function setRedesign(bool $redesign): void
    {
        $this->redesign = $redesign;
    }

    /**
     * @return int
     */
    public function getLeistungsJahr(): int
    {
        return $this->leistungsJahr;
    }

    /**
     * @param int $leistungsJahr
     */
    public function setLeistungsJahr(int $leistungsJahr): void
    {
        $this->leistungsJahr = $leistungsJahr;
    }

    /**
     * @return int
     */
    public function getLeistungsMonat(): int
    {
        return $this->leistungsMonat;
    }

    /**
     * @param int $leistungsMonat
     */
    public function setLeistungsMonat(int $leistungsMonat): void
    {
        $this->leistungsMonat = $leistungsMonat;
    }

    /**
     * @return int
     */
    public function getFakturaJahr(): int
    {
        return $this->fakturaJahr;
    }

    /**
     * @param int $fakturaJahr
     */
    public function setFakturaJahr(int $fakturaJahr): void
    {
        $this->fakturaJahr = $fakturaJahr;
    }

    /**
     * @return int
     */
    public function getFakturaMonat(): int
    {
        return $this->fakturaMonat;
    }

    /**
     * @param int $fakturaMonat
     */
    public function setFakturaMonat(int $fakturaMonat): void
    {
        $this->fakturaMonat = $fakturaMonat;
    }

    /**
     * @return string|null
     */
    public function getLieferversion(): ?string
    {
        return $this->lieferversion;
    }

    /**
     * @param string|null $lieferversion
     */
    public function setLieferversion(?string $lieferversion): void
    {
        $this->lieferversion = $lieferversion;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @param string|null $kommentar
     */
    public function setKommentar(?string $kommentar): void
    {
        $this->kommentar = $kommentar;
    }

    /**
     * @return string|null
     */
    public function getDateiname(): ?string
    {
        return $this->dateiname;
    }

    /**
     * @param string|null $dateiname
     */
    public function setDateiname(?string $dateiname): void
    {
        $this->dateiname = $dateiname;
    }

    /**
     * @return DateTime|null
     */
    public function getGesendetAm(): ?DateTime
    {
        return $this->gesendetAm;
    }

    /**
     * @param DateTime|null $gesendetAm
     */
    public function setGesendetAm(?DateTime $gesendetAm): void
    {
        $this->gesendetAm = $gesendetAm;
    }

    /**
     * @return DateTime|null
     */
    public function getBestaetigtAm(): ?DateTime
    {
        return $this->bestaetigtAm;
    }

    /**
     * @param DateTime|null $bestaetigtAm
     */
    public function setBestaetigtAm(?DateTime $bestaetigtAm): void
    {
        $this->bestaetigtAm = $bestaetigtAm;
    }

    /**
     * @return bool|null
     */
    public function getAbgelehnt(): ?bool
    {
        return $this->abgelehnt;
    }

    /**
     * @param bool|null $abgelehnt
     */
    public function setAbgelehnt(?bool $abgelehnt): void
    {
        $this->abgelehnt = $abgelehnt;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return DateTime|null
     */
    public function getFakturiertAm(): ?DateTime
    {
        return $this->fakturiertAm;
    }

    /**
     * @param DateTime|null $fakturiertAm
     */
    public function setFakturiertAm(?DateTime $fakturiertAm): void
    {
        $this->fakturiertAm = $fakturiertAm;
    }

    /**
     * @return bool
     */
    public function isAbgrenzung(): bool
    {
        return $this->abgrenzung;
    }

    /**
     * @param bool $abgrenzung
     */
    public function setAbgrenzung(bool $abgrenzung): void
    {
        $this->abgrenzung = $abgrenzung;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @param string|null $rechnungsnummer
     */
    public function setRechnungsnummer(?string $rechnungsnummer): void
    {
        $this->rechnungsnummer = $rechnungsnummer;
    }

    /**
     * @return DateTime|null
     */
    public function getFakturabereit(): ?DateTime
    {
        return $this->fakturabereit;
    }

    /**
     * @param DateTime|null $fakturabereit
     */
    public function setFakturabereit(?DateTime $fakturabereit): void
    {
        $this->fakturabereit = $fakturabereit;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @param string|null $sapBestellnummer
     */
    public function setSapBestellnummer(?string $sapBestellnummer): void
    {
        $this->sapBestellnummer = $sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getDateinameSap(): ?string
    {
        return $this->dateinameSap;
    }

    /**
     * @param string|null $dateinameSap
     */
    public function setDateinameSap(?string $dateinameSap): void
    {
        $this->dateinameSap = $dateinameSap;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @param string|null $billingSubjectExtension
     */
    public function setBillingSubjectExtension(?string $billingSubjectExtension): void
    {
        $this->billingSubjectExtension = $billingSubjectExtension;
    }

    /**
     * @return BackendBenutzer
     */
    public function getAnsprechpartner(): BackendBenutzer
    {
        return $this->ansprechpartner;
    }

    /**
     * @param BackendBenutzer $ansprechpartner
     */
    public function setAnsprechpartner(BackendBenutzer $ansprechpartner): void
    {
        $this->ansprechpartner = $ansprechpartner;
    }

    /**
     * @return OfferAuftrag
     */
    public function getSimple(): OfferAuftrag
    {
        return $this->simple;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return new SIN($this->simple->getSimpleId());
    }

    /**
     * @param OfferAuftrag $simple
     */
    public function setSimple(OfferAuftrag $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferFakturaFreigabegrund
     */
    public function getFreigabegrund(): OfferFakturaFreigabegrund
    {
        return $this->freigabegrund;
    }

    /**
     * @param OfferFakturaFreigabegrund|null $freigabegrund
     */
    public function setFreigabegrund(?OfferFakturaFreigabegrund $freigabegrund): void
    {
        $this->freigabegrund = $freigabegrund;
    }

    /**
     * @return SalesAngebotTp|null
     */
    public function getTpVersions(): ?SalesAngebotTp
    {
        return $this->tpVersions;
    }

    /**
     * @param SalesAngebotTp|null $tpVersions
     */
    public function setTpVersions(?SalesAngebotTp $tpVersions): void
    {
        $this->tpVersions = $tpVersions;
    }

    /**
     * @return OfferDebitor
     */
    public function getDebitor(): OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @param OfferDebitor|object|null $debitor
     */
    public function setDebitor(?OfferDebitor $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @return OfferFakturaFakturaziel
     */
    public function getFakturaziel(): OfferFakturaFakturaziel
    {
        return $this->fakturaziel;
    }

    /**
     * @param OfferFakturaFakturaziel $fakturaziel
     */
    public function setFakturaziel(OfferFakturaFakturaziel $fakturaziel): void
    {
        $this->fakturaziel = $fakturaziel;
    }

    /**
     * @return OfferFakturaVorgangstyp|null
     */
    public function getVorgangstyp(): ?OfferFakturaVorgangstyp
    {
        return $this->vorgangstyp;
    }

    /**
     * @param OfferFakturaVorgangstyp $vorgangstyp
     */
    public function setVorgangstyp(OfferFakturaVorgangstyp $vorgangstyp): void
    {
        $this->vorgangstyp = $vorgangstyp;
    }

    /**
     * @return int|null
     */
    public function getSapTransactionCode(): ?int
    {
        return $this->sapTransactionCode;
    }

    /**
     * @param int|null $sapTransactionCode
     */
    public function setSapTransactionCode(?int $sapTransactionCode): void
    {
        $this->sapTransactionCode = $sapTransactionCode;
    }

    /**
     * @return int|null
     */
    public function getSapInvoiceCode(): ?int
    {
        return $this->sapInvoiceCode;
    }

    /**
     * @param int|null $sapInvoiceCode
     */
    public function setSapInvoiceCode(?int $sapInvoiceCode): void
    {
        $this->sapInvoiceCode = $sapInvoiceCode;
    }

    /**
     * @return string|null
     */
    public function getSapStatus(): ?string
    {
        return $this->sapStatus;
    }

    /**
     * @param string|null $sapStatus
     */
    public function setSapStatus(?string $sapStatus): void
    {
        $this->sapStatus = $sapStatus;
    }

    /**
     * @return Collection
     */
    public function getLbuDaten(): Collection
    {
        return $this->lbuDaten;
    }

    /**
     * @param Collection $lbuDaten
     */
    public function setLbuDaten(Collection $lbuDaten): void
    {
        $this->lbuDaten = $lbuDaten;
    }

    /**
     * @return FinanceCreditReason|null
     */
    public function getCreditReason(): ?FinanceCreditReason
    {
        return $this->creditReason;
    }

    /**
     * @param FinanceCreditReason|null $creditReason
     */
    public function setCreditReason(?FinanceCreditReason $creditReason): void
    {
        $this->creditReason = $creditReason;
    }

    /**
     * @return Collection
     */
    public function getFakturaplan(): Collection
    {
        return $this->fakturaplan;
    }

    /**
     * @param Collection $fakturaplan
     */
    public function setFakturaplan(Collection $fakturaplan): void
    {
        $this->fakturaplan = $fakturaplan;
    }

    /**
     * @return bool
     */
    public function isAutomated(): bool
    {
        return $this->automated;
    }

    /**
     * @param bool $automated
     */
    public function setAutomated(bool $automated): void
    {
        $this->automated = $automated;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getCreatedBy(): ?BackendBenutzer
    {
        return $this->createdBy;
    }

    /**
     * @param BackendBenutzer $createdBy
     */
    public function setCreatedBy(BackendBenutzer $createdBy): void
    {
        $this->createdBy = $createdBy;
    }

    /**
     * @param FinanceAutomationFakturaplan|null $financeFakturaplan
     */
    public function setFinanceFakturaplan(?FinanceAutomationFakturaplan $financeFakturaplan): void
    {
        $this->financeFakturaplan = $financeFakturaplan;
    }

    /**
     * @return bool|null
     */
    public function getPending(): ?bool
    {
        return $this->pending;
    }

    /**
     * @param bool|null $pending
     */
    public function setPending(?bool $pending): void
    {
        $this->pending = $pending;
    }
}
