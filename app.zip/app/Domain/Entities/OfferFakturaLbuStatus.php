<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaLbuStatus
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Status")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferFakturaLbuStatus
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="short_name", type="string")
     */
    private string $shortName;

    /**
     * @ORM\Column(name="name", type="string")
     */
    private string $name;

    /**
     * @ORM\Column(name="sys_name", type="string")
     */
    private string $sysName;

    /**
     * @ORM\Column(name="`open`", type="boolean")
     */
    private bool $open;

    /**
     * @ORM\Column(name="writable", type="boolean")
     */
    private bool $writable;

    /**
     * @ORM\Column(name="transferred", type="boolean")
     */
    private bool $transferred;

    /**
     * @ORM\Column(name="locked", type="boolean")
     */
    private bool $locked;

    /**
     * @ORM\Column(name="accounted", type="boolean")
     */
    private bool $accounted;

    /**
     * @ORM\Column(name="rejected", type="boolean")
     */
    private bool $rejected;

    /**
     * @ORM\Column(name="progress", type="integer")
     */
    private int $progress;

    /**
     * @ORM\Column(name="color", type="string", nullable=true)
     */
    private ?string $color = null;

    /**
     * @ORM\Column(name="icon", type="string", nullable=true)
     */
    private ?string $icon = null;

    /**
     * @ORM\Column(name="description", type="string")
     */
    private string $description;

    /**
     * OfferFakturaLbuStatus constructor.
     * @param string $shortName
     * @param string $name
     * @param string $sysName
     * @param string $description
     * @param int $progress
     * @param bool $writable
     * @param bool $transferred
     * @param bool $locked
     * @param bool $accounted
     * @param bool $rejected
     */
    public function __construct(
        string $shortName,
        string $name,
        string $sysName,
        string $description,
        int $progress = 0,
        bool $writable = false,
        bool $transferred = false,
        bool $locked = false,
        bool $accounted = false,
        bool $rejected = false
    )
    {
        $this->shortName = $shortName;
        $this->name = $name;
        $this->sysName = $sysName;
        $this->description = $description;
        $this->progress = $progress;
        $this->writable = $writable;
        $this->transferred = $transferred;
        $this->locked = $locked;
        $this->accounted = $accounted;
        $this->rejected = $rejected;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return bool
     */
    public function isAccounted(): bool
    {
        return $this->accounted;
    }

    /**
     * @return bool
     */
    public function isLocked(): bool
    {
        return $this->locked;
    }

    /**
     * @return bool
     */
    public function isOpen(): bool
    {
        return $this->open;
    }

    /**
     * @return bool
     */
    public function isRejected(): bool
    {
        return $this->rejected;
    }

    /**
     * @return bool
     */
    public function isTransferred(): bool
    {
        return $this->transferred;
    }

    /**
     * @return bool
     */
    public function isWritable(): bool
    {
        return $this->writable;
    }

    /**
     * @return string|null
     */
    public function getColor(): ?string
    {
        return $this->color;
    }

    /**
     * @return string
     */
    public function getShortName(): string
    {
        return $this->shortName;
    }

    /**
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @return int
     */
    public function getProgress(): int
    {
        return $this->progress;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string|null
     */
    public function getIcon(): ?string
    {
        return $this->icon;
    }
}
