<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CostsServicelevel
 *
 * @ORM\Table(name="Costs_Servicelevel")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsServicelevel
{
    /**
     * @ORM\Column(name="servicelevel_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $servicelevelId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private string $bezeichnung;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private string $beschreibung;

    /** @ORM\Column(name="beschreibung_angebot", type="text", length=-1, nullable=true) */
    private string $beschreibungAngebot;

    /** @ORM\Column(name="abkuerzung", type="string", length=30, nullable=true) */
    private string $abkuerzung;

    /** @ORM\Column(name="wert", type="decimal", precision=10, scale=2) */
    private float $wert;

    /** @ORM\Column(name="sort", type="smallint", nullable=true) */
    private int $sort;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private DateTime $bits;

    /** @ORM\Column(name="ilv_faktor", type="decimal", precision=18, scale=2, nullable=true) */
    private ?float $ilvFaktor = null;

    /**
     * @ORM\ManyToOne(targetEntity="CostsServicelevelKategorie")
     * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")
     */
    private CostsServicelevelKategorie $kategorie;

    /**
     * @return float
     */
    public function getWert(): float
    {
        return $this->wert;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return int
     */
    public function getServicelevelId(): int
    {
        return $this->servicelevelId;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return float|null
     */
    public function getIlvFaktor(): ?float
    {
        return $this->ilvFaktor;
    }

    /**
     * @return CostsServicelevelKategorie
     */
    public function getKategorie(): CostsServicelevelKategorie
    {
        return $this->kategorie;
    }
}
