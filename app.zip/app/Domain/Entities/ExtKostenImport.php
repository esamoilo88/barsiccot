<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtKostenImport
 *
 * @ORM\Table(name="ext_Kosten_import")
 * @ORM\Entity
 */
class ExtKostenImport
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="simple_id", type="text", length=-1, nullable=true)
     */
    private $simpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kostenplan_id", type="text", length=-1, nullable=true)
     */
    private $kostenplanId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kostenart_id", type="text", length=-1, nullable=true)
     */
    private $kostenartId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kosten_jahr", type="text", length=-1, nullable=true)
     */
    private $kostenJahr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kosten_monat", type="text", length=-1, nullable=true)
     */
    private $kostenMonat;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stundensatz", type="text", length=-1, nullable=true)
     */
    private $stundensatz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wert", type="text", length=-1, nullable=true)
     */
    private $wert;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private $bemerkungen;


}
