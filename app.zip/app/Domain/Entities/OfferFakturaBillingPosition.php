<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Offer_Faktura_Billing_Position")
 * @ORM\Entity
 */
class OfferFakturaBillingPosition
{
    /**
     * @ORM\Column(name="pos_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $posId;

    /** @ORM\Column(name="angebotsposition_id", type="integer", nullable=true) */
    private ?float $angebotspositionId;

    /** @ORM\Column(name="unit_price", type="decimal", nullable=true) */
    private ?float $unitPrice;

    /** @ORM\Column(name="amount", type="decimal", precision=24, scale=12, nullable=true) */
    private ?float $amount;

    /** @ORM\Column(name="short_text", type="string", length=150, nullable=true) */
    private ?string $shortText;

    /** @ORM\Column(name="long_text", type="string", length=150, nullable=true) */
    private ?string $longText;

    /** @ORM\Column(name="psp_element", type="string", length=50, nullable=true) */
    private ?string $pspElement;

    /** @ORM\Column(name="mat_nr", type="integer", nullable=true) */
    private ?int $matNr;

    /** @ORM\Column(name="icp_kont_bpos", type="integer", nullable=true) */
    private ?int $icpKontBpos;

    /** @ORM\Column(name="icp_kont_sachkonto", type="integer", nullable=true) */
    private ?int $icpKontSachkonto;

    /** @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true) */
    private ?string $icpKontPspKst;

    /** @ORM\Column(name="related_lbu_ids", type="text", length=-1, nullable=true) */
    private ?string $relatedLbuIds;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaBillingHead")
     * @ORM\JoinColumn(name="head_id", referencedColumnName="head_id")
     */
    private OfferFakturaBillingHead $head;

    /**
     * OfferFakturaBillingPosition constructor.
     * @param SalesStammdaten $simple
     * @param OfferFakturaBillingHead $head
     */
    public function __construct(SalesStammdaten $simple, OfferFakturaBillingHead $head)
    {
        $this->simple = $simple;
        $this->head = $head;
    }

    /**
     * @return int
     */
    public function getPosId(): int
    {
        return $this->posId;
    }

    /**
     * @return float|null
     */
    public function getAngebotspositionId(): ?float
    {
        return $this->angebotspositionId;
    }

    /**
     * @param float|null $angebotspositionId
     */
    public function setAngebotspositionId(?float $angebotspositionId): void
    {
        $this->angebotspositionId = $angebotspositionId;
    }

    /**
     * @return float|null
     */
    public function getUnitPrice(): ?float
    {
        return $this->unitPrice;
    }

    /**
     * @param float|null $unitPrice
     */
    public function setUnitPrice(?float $unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    /**
     * @return float|null
     */
    public function getAmount(): ?float
    {
        return $this->amount;
    }

    /**
     * @param float|null $amount
     */
    public function setAmount(?float $amount): void
    {
        $this->amount = $amount;
    }

    /**
     * @return string|null
     */
    public function getShortText(): ?string
    {
        return $this->shortText;
    }

    /**
     * @param string|null $shortText
     */
    public function setShortText(?string $shortText): void
    {
        $this->shortText = $shortText;
    }

    /**
     * @return string|null
     */
    public function getLongText(): ?string
    {
        return $this->longText;
    }

    /**
     * @param string|null $longText
     */
    public function setLongText(?string $longText): void
    {
        $this->longText = $longText;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @param string|null $pspElement
     */
    public function setPspElement(?string $pspElement): void
    {
        $this->pspElement = $pspElement;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNr;
    }

    /**
     * @param int|null $matNr
     */
    public function setMatNr(?int $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @param int|null $icpKontBpos
     */
    public function setIcpKontBpos(?int $icpKontBpos): void
    {
        $this->icpKontBpos = $icpKontBpos;
    }

    /**
     * @return int|null
     */
    public function getIcpKontSachkonto(): ?int
    {
        return $this->icpKontSachkonto;
    }

    /**
     * @param int|null $icpKontSachkonto
     */
    public function setIcpKontSachkonto(?int $icpKontSachkonto): void
    {
        $this->icpKontSachkonto = $icpKontSachkonto;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @param string|null $icpKontPspKst
     */
    public function setIcpKontPspKst(?string $icpKontPspKst): void
    {
        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return string|null
     */
    public function getRelatedLbuIds(): ?string
    {
        return $this->relatedLbuIds;
    }

    /**
     * @param string|null $relatedLbuIds
     */
    public function setRelatedLbuIds(?string $relatedLbuIds): void
    {
        $this->relatedLbuIds = $relatedLbuIds;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferFakturaBillingHead
     */
    public function getHead(): OfferFakturaBillingHead
    {
        return $this->head;
    }

    /**
     * @param OfferFakturaBillingHead $head
     */
    public function setHead(OfferFakturaBillingHead $head): void
    {
        $this->head = $head;
    }
}
