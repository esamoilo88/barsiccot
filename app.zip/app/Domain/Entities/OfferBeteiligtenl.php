<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferBeteiligtenl
 *
 * @ORM\Table(name="Offer_BeteiligteNL")
 * @ORM\Entity
 */
class OfferBeteiligtenl
{
    /**
     * @var int
     *
     * @ORM\Column(name="beteiligteNL_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $beteiligtenlId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="prozent", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $prozent;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var OfferNiederlassung
     *
     * @ORM\ManyToOne(targetEntity="OfferNiederlassung")
     * @ORM\JoinColumn(name="nl_id", referencedColumnName="nl_id")
     */
    private $nl;

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @param string|null $prozent
     */
    public function setProzent(?string $prozent): void
    {
        $this->prozent = $prozent;
    }

    /**
     * @param OfferNiederlassung $nl
     */
    public function setNl(OfferNiederlassung $nl): void
    {
        $this->nl = $nl;
    }

    /**
     * @return OfferNiederlassung
     */
    public function getNl(): OfferNiederlassung
    {
        return $this->nl;
    }

    /**
     * @return string|null
     */
    public function getProzent(): ?string
    {
        return $this->prozent;
    }
}
