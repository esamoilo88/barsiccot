<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OfferKatalogElLp
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_EL_LP")
 */
class OfferKatalogElLp
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogElement")
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id")
     */
    private OfferKatalogElement $katalogEl;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private OfferKatalogLeistungsposition $katalogLp;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * OfferKatalogElLp constructor.
     * @param OfferKatalogElement $elementLp
     * @param OfferKatalogLeistungsposition $katalogLp
     * @param int|null $sort
     */
    public function __construct(OfferKatalogElement $elementLp, OfferKatalogLeistungsposition $katalogLp, ?int $sort)
    {
        $this->katalogEl = $elementLp;
        $this->katalogLp = $katalogLp;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @return OfferKatalogElement
     */
    public function getKatalogEl(): OfferKatalogElement
    {
        return $this->katalogEl;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getKatalogLp(): OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
