<?php

namespace App\Domain\Entities;

use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;

/**
 * CrmNote
 *
 * @ORM\Table(name="CRM_Notes")
 * @ORM\Entity
 */
class CrmNote
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="note", type="text")
     */
    private string $note;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $backendBenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="CrmCustomer")
     * @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
     */
    private CrmCustomer $crmCustomer;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * CrmNote constructor.
     * @param string $note
     * @param BackendBenutzer $backendBenutzer
     * @param CrmCustomer $crmCustomer
     */
    public function __construct(string $note, BackendBenutzer $backendBenutzer, CrmCustomer $crmCustomer)
    {
        $this->note = $note;
        $this->backendBenutzer = $backendBenutzer;
        $this->crmCustomer = $crmCustomer;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getNote(): string
    {
        return $this->note;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBackendBenutzer(): BackendBenutzer
    {
        return $this->backendBenutzer;
    }

    /**
     * @return CrmCustomer
     */
    public function getCrmCustomer(): CrmCustomer
    {
        return $this->crmCustomer;
    }

    /**
     * @param string $note
     */
    public function setNote(string $note): void
    {
        $this->note = $note;
    }
}
