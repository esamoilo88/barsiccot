<?php


namespace App\Domain\Entities;


use App\Domain\ValueObjects\SIN;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * FinanceAutomationSystemQuellsystem
 *
 * @ORM\Table(name="Finance_Automation_System_Quellsystem")
 * @ORM\Entity
 */
class FinanceAutomationSystemQuellsystem
{

    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="quellsystem_id", type="integer")
     */
    private int $quellsystemId;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * FinanceAutomationSystemQuellsystem constructor.
     * @param SIN $sin
     * @param int $quellsystemId
     */
    public function __construct(SIN $sin, int $quellsystemId)
    {
        $this->simpleId = $sin->value();
        $this->quellsystemId = $quellsystemId;
    }

    /**
     * @return int
     */
    public function getQuellsystemId(): int
    {
        return $this->quellsystemId;
    }

    /**
     * @param int $quellsystemId
     */
    public function setQuellsystemId(int $quellsystemId): void
    {
        $this->quellsystemId = $quellsystemId;
    }

    /**
     * @param SIN $sin
     */
    public function setSIN(SIN $sin): void
    {
        $this->simpleId = $sin->value();
    }
}
