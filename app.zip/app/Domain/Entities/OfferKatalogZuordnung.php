<?php


namespace App\Domain\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKatalogZuordnung
 *
 * @ORM\Table(name="Offer_Katalog_Zuordnung")
 * @ORM\Entity
 */
class OfferKatalogZuordnung
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="kat_angebotsposition_id", referencedColumnName="id", nullable=false)
     */
    private OfferKatalogAngebotsposition $katalogAp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="kat_leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=false)
     */
    private OfferKatalogLeistungsposition $katalogLp;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /**
     * @ORM\Column(name="optional", type="boolean", nullable=false)
     */
    private bool $optional;

    /**
     * @ORM\Column(name="ui_element", type="string", nullable=true)
     */
    private ?string $uiElement;

    /**
     * @ORM\Column(name="radio_group", type="string", nullable=true)
     */

    private ?string $radioGroup;
    /**
     * @ORM\Column(name="radio_group", type="string", nullable=true)
     */

    /**
     * OfferKatalogZuordnung constructor.
     * @param OfferKatalogAngebotsposition $katalogAp
     * @param OfferKatalogLeistungsposition $katalogLp
     * @param int $quantity
     * @param bool $optional
     * @param string|null $uiElement
     * @param string|null $radioGroup
     */
    public function __construct(
        OfferKatalogAngebotsposition $katalogAp,
        OfferKatalogLeistungsposition $katalogLp,
        int $quantity,
        bool $optional,
        ?string $uiElement,
        ?string $radioGroup
    )
    {
        $this->katalogAp = $katalogAp;
        $this->katalogLp = $katalogLp;
        $this->quantity = $quantity;
        $this->optional = $optional;
        $this->uiElement = $uiElement;
        $this->radioGroup = $radioGroup;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OfferKatalogAngebotsposition
     */
    public function getKatalogAp(): OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getKatalogLp(): OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return bool
     */
    public function getOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @return string|null
     */
    public function getUiElement(): ?string
    {
        return $this->uiElement;
    }

    /**
     * @return string|null
     */
    public function getRadioGroup(): ?string
    {
        return $this->radioGroup;
    }
}
