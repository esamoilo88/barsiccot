<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaIcpBestellpositionen
 *
 * @ORM\Table(name="Offer_Faktura_ICP_Bestellpositionen")
 * @ORM\Entity
 */
class OfferFakturaIcpBestellpositionen
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bestellnummer", type="string", length=50, nullable=true)
     */
    private $bestellnummer;

    /**
     * @var int
     *
     * @ORM\Column(name="icp_kont_bpos", type="integer", nullable=false)
     */
    private $icpKontBpos;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \OfferAuftrag
     *
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @var \OfferKalkulationAngebotsposition
     *
     * @ORM\ManyToOne(targetEntity="OfferKalkulationAngebotsposition")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="angebotsposition_id")
     * })
     */
    private $angebotsposition;


}
