<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\SIN;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * FinanceAutomationFakturaplan
 * @ORM\Table(name="Finance_Automation_Fakturaplan")
 * @ORM\Entity
 */
class FinanceAutomationFakturaplan
{

    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /** @ORM\Column(name="lbu_id", type="integer") */
    private int $lbuId;

    /** @ORM\Column(name="finance_order_id", type="integer", nullable=true) */
    private ?int $financeOrderId;

    /** @ORM\Column(name="auto_create", type="boolean") */
    private bool $autoCreate;

    /** @ORM\Column(name="auto_send", type="boolean") */
    private bool $autoSend;

    /** @ORM\Column(name="create_at", type="string") */
    private string $createAt;

    /** @ORM\Column(name="offset_period", type="smallint") */
    private int $offsetPeriod;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $backendBenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id", nullable=true)
     */
    private ?BackendGroup $group;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbu")
     * @ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id")
     */
    private OfferFakturaLbu $lbu;

    /**
     * @ORM\ManyToOne(targetEntity="FinanceOrder")
     * @ORM\JoinColumn(name="finance_order_id", referencedColumnName="id", nullable=true)
     */
    private ?FinanceOrder $financeOrder = null;

    /**
     * FinanceAutomationFakturaplan constructor.
     * @param SIN $sin
     * @param OfferFakturaLbu $lbu
     * @param FinanceOrder|null $order
     */
    public function __construct(SIN $sin, OfferFakturaLbu $lbu, ?FinanceOrder $order)
    {
        $this->simpleId = $sin->value();
        $this->lbu = $lbu;
        $this->lbuId = $lbu->getLbuId();
        $this->financeOrder = $order;
        $this->financeOrderId = $order ? $order->getId() : null;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbu->getLbuId();
    }

    /**
     * @param int $lbuId
     */
    public function setLbuId(int $lbuId): void
    {
        $this->lbuId = $lbuId;
    }

    /**
     * @return bool
     */
    public function isAutoCreate(): bool
    {
        return $this->autoCreate;
    }

    /**
     * @param bool $autoCreate
     */
    public function setAutoCreate(bool $autoCreate): void
    {
        $this->autoCreate = $autoCreate;
    }

    /**
     * @return bool
     */
    public function isAutoSend(): bool
    {
        return $this->autoSend;
    }

    /**
     * @param bool $autoSend
     */
    public function setAutoSend(bool $autoSend): void
    {
        $this->autoSend = $autoSend;
    }

    /**
     * @return int
     */
    public function getOffsetPeriod(): int
    {
        return $this->offsetPeriod;
    }

    /**
     * @param int $offsetPeriod
     */
    public function setOffsetPeriod(int $offsetPeriod): void
    {
        $this->offsetPeriod = $offsetPeriod;
    }

    /**
     * @return string
     */
    public function getCreateAt(): string
    {
        return $this->createAt;
    }

    /**
     * @param string $createAt
     */
    public function setCreateAt(string $createAt): void
    {
        $this->createAt = $createAt;
    }

    /**
     * @param bool $autoApprove
     */
    public function handleGlobalAutoapprove(bool $autoApprove): void
    {
        if ($autoApprove) {
            $this->globalAutoApproveGetsTrue();
        }
        //TODO
//        $autoApprove ?
//            $this->globalAutoApproveGetsTrue() :
//            $this->globalAutoApproveGetsFalse();
    }

    /**
     * controlled by FinanceAutomationSuperglobal::autoApprove
     */
    private function globalAutoApproveGetsTrue(): void
    {
        if ($this->autoSend === true) {
            $this->autoSend = false;
        }
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OfferFakturaLbu
     */
    public function getLbu(): OfferFakturaLbu
    {
        return $this->lbu;
    }

    /**
     * @param OfferFakturaLbu $lbu
     */
    public function setLbu(OfferFakturaLbu $lbu): void
    {
        $this->lbu = $lbu;
    }

    /**
     * @return FinanceOrder|null
     */
    public function getFinanceOrder(): ?FinanceOrder
    {
        return $this->financeOrder;
    }

    /**
     * @param FinanceOrder|null $financeOrder
     */
    public function setFinanceOrder(?FinanceOrder $financeOrder): void
    {
        $this->financeOrder = $financeOrder;
    }

    //TODO not a good way
    /**
     * @param string|null $billAt
     */
    public function setBillAt(?string $billAt): void {}

    /**
     * @param string|null $sendAt
     */
    public function setSendAt(?string $sendAt): void {}

    /**
     * @param bool $billAfterDeadline
     */
    public function setBillAfterDeadline(bool $billAfterDeadline): void {}

    /**
     * @param bool $autoBill
     */
    public function setAutoBill(bool $autoBill): void {}

    /**
     * @return BackendBenutzer|null
     */
    public function getBackendBenutzer(): ?BackendBenutzer
    {
        return $this->backendBenutzer;
    }

    /**
     * @param BackendBenutzer|null $backendBenutzer
     */
    public function setBackendBenutzer(?BackendBenutzer $backendBenutzer): void
    {
        $this->backendBenutzer = $backendBenutzer;
    }

    /**
     * @return BackendGroup|null
     */
    public function getGroup(): ?BackendGroup
    {
        return $this->group;
    }

    /**
     * @param ?BackendGroup $group
     */
    public function setGroup(?BackendGroup $group): void
    {
        $this->group = $group;
    }
}
