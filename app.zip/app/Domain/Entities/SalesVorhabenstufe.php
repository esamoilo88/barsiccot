<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesVorhabenstufe
 *
 * @ORM\Table(name="Sales_Vorhabenstufe")
 * @ORM\Entity
 */
class SalesVorhabenstufe
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="dateline", type="datetime")
     */
    private DateTime $dateline;

    /**
     * @ORM\Column(name="volumen_dtts", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?string $volumenDtts;

    /**
     * @ORM\Column(name="volumen_gesamt", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?string $volumenGesamt;

    /**
     * @ORM\Column(name="auftragswahrscheinlichkeit", type="integer", nullable=true)
     */
    private ?int $auftragswahrscheinlichkeit;

    /**
     * @ORM\Column(name="AE_monat", type="datetime", nullable=true)
     */
    private ?DateTime $aeMonat;

    /**
     * @ORM\Column(name="umsatz_monat", type="datetime", nullable=true)
     */
    private ?DateTime $umsatzMonat;

    /**
     * @ORM\Column(name="laufzeit_in_monaten", type="smallint", nullable=true)
     */
    private ?int $laufzeitInMonaten;

    /**
     * @ORM\Column(name="kommentar", type="text", length=-1, nullable=true)
     */
    private ?string $kommentar;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="SalesVerkaufsstufen")
     * @ORM\JoinColumn(name="verkaufsstufen_id", referencedColumnName="verkaufsstufen_id")
     */
    private SalesVerkaufsstufen $verkaufsstufen;

    /**
     * SalesVorhabenstufe constructor.
     * @param SalesStammdaten $simple
     * @param SalesVerkaufsstufen $verkaufsstufen
     * @param int|null $auftragswahrscheinlichkeit
     * @param int|null $laufzeitInMonaten
     * @param string|null $volumenGesamt
     * @param DateTime $dateline
     * @param string|null $volumenDtts
     * @param DateTime|null $aeMonat
     * @param DateTime|null $umsatzMonat
     * @param string|null $kommentar
     */
    public function __construct(
        SalesStammdaten $simple,
        SalesVerkaufsstufen $verkaufsstufen,
        ?int $auftragswahrscheinlichkeit,
        ?int $laufzeitInMonaten,
        ?string $volumenGesamt,
        DateTime $dateline,
        ?string $volumenDtts = null,
        ?DateTime $aeMonat = null,
        ?DateTime $umsatzMonat = null,
        ?string $kommentar = null
    )
    {
        $this->simple = $simple;
        $this->verkaufsstufen = $verkaufsstufen;
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
        $this->laufzeitInMonaten = $laufzeitInMonaten;
        $this->volumenGesamt = $volumenGesamt;
        $this->dateline = $dateline;
        $this->volumenDtts = $volumenDtts;
        $this->aeMonat = $aeMonat;
        $this->umsatzMonat = $umsatzMonat;
        $this->kommentar = $kommentar;
    }

    /**
     * @param SalesVerkaufsstufen $verkaufsstufen
     */
    public function setVerkaufsstufen(SalesVerkaufsstufen $verkaufsstufen): void
    {
        $this->verkaufsstufen = $verkaufsstufen;
    }

    /**
     * @param DateTime $dateline
     */
    public function setDateline(DateTime $dateline): void
    {
        $this->dateline = $dateline;
    }

    /**
     * @param int|null $auftragswahrscheinlichkeit
     */
    public function setAuftragswahrscheinlichkeit(?int $auftragswahrscheinlichkeit): void
    {
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
    }

    /**
     * @param int|null $laufzeitInMonaten
     */
    public function setLaufzeitInMonaten(?int $laufzeitInMonaten): void
    {
        $this->laufzeitInMonaten = $laufzeitInMonaten;
    }

    /**
     * @param string|null $volumenGesamt
     */
    public function setVolumenGesamt(?string $volumenGesamt): void
    {
        $this->volumenGesamt = $volumenGesamt;
    }
}
