<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferChangerequest
 *
 * @ORM\Table(name="Offer_ChangeRequest")
 * @ORM\Entity
 */
class OfferChangerequest
{
    /**
     * @ORM\Column(name="cr_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $crId;

    /**
     * @ORM\ManyToOne(targetEntity="OfferChangerequestTyp")
     * @ORM\JoinColumn(name="cr_typ", referencedColumnName="id")
     */
    private OfferChangerequestTyp $crTyp;

    /** @ORM\Column(name="versionsnr", type="smallint", nullable=false) */
    private int $versionsnr;

    /** @ORM\Column(name="versionsnr_external", type="smallint", nullable=true) */
    private ?int $versionsnrExternal;

    /** @ORM\Column(name="grund", type="text", length=-1, nullable=true) */
    private ?string $grund;

    /** @ORM\Column(name="fertig_am", type="datetime", nullable=true) */
    private ?\DateTime $fertigAm = null;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=false)
     * @Gedmo\Timestampable(on="create")
     */
    private ?\DateTime $created;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\Column(name="total_costs_before", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $totalCostsBefore;

    /** @ORM\Column(name="total_costs_after", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $totalCostsAfter;

    /** @ORM\Column(name="total_price_before", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $totalPriceBefore;

    /** @ORM\Column(name="total_price_after", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $totalPriceAfter;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $simple;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStatus")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id", nullable=true)
     */
    private ?SalesStatus $status;

    /**
     * OfferChangerequest constructor.
     * @param OfferChangerequestTyp|object $crTyp
     * @param int $versionsnr
     * @param BackendBenutzer|object $benutzer
     * @param OfferAuftrag|object $simple
     */
    public function __construct(
        OfferChangerequestTyp $crTyp,
        int $versionsnr,
        BackendBenutzer $benutzer,
        OfferAuftrag $simple
    )
    {
        $this->crTyp = $crTyp;
        $this->versionsnr = $versionsnr;
        $this->benutzer = $benutzer;
        $this->simple = $simple;
    }

    /**
     * @Groups({"crList"})
     * @return int
     */
    public function getCrId(): int
    {
        return $this->crId;
    }

    /**
     * @Groups({"crList"})
     * @return OfferChangerequestTyp
     */
    public function getCrTyp(): OfferChangerequestTyp
    {
        return $this->crTyp;
    }

    /**
     * @param OfferChangerequestTyp $crTyp
     */
    public function setCrTyp(OfferChangerequestTyp $crTyp): void
    {
        $this->crTyp = $crTyp;
    }

    /**
     * @Groups({"crList"})
     * @return int
     */
    public function getVersionsnr(): int
    {
        return $this->versionsnr;
    }

    /**
     * @param int $versionsnr
     */
    public function setVersionsnr(int $versionsnr): void
    {
        $this->versionsnr = $versionsnr;
    }

    /**
     * @Groups({"crList"})
     * @return string|null
     */
    public function getGrund(): ?string
    {
        return $this->grund;
    }

    /**
     * @param string|null $grund
     */
    public function setGrund(?string $grund): void
    {
        $this->grund = $grund;
    }

    /**
     * @Groups({"crList"})
     * @return \DateTime|null
     */
    public function getFertigAm(): ?\DateTime
    {
        return $this->fertigAm;
    }

    /**
     * @param \DateTime|null $fertigAm
     */
    public function setFertigAm(?\DateTime $fertigAm): void
    {
        $this->fertigAm = $fertigAm;
    }

    /**
     * @Groups({"crList"})
     * @return \DateTime|null
     */
    public function getCreated(): ?\DateTime
    {
        return $this->created;
    }

    /**
     * @param \DateTime|null $created
     */
    public function setCreated(?\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return string|null
     */
    public function getTotalCostsBefore(): ?string
    {
        return $this->totalCostsBefore;
    }

    /**
     * @param string|null $totalCostsBefore
     */
    public function setTotalCostsBefore(?string $totalCostsBefore): void
    {
        $this->totalCostsBefore = $totalCostsBefore;
    }

    /**
     * @return string|null
     */
    public function getTotalCostsAfter(): ?string
    {
        return $this->totalCostsAfter;
    }

    /**
     * @param string|null $totalCostsAfter
     */
    public function setTotalCostsAfter(?string $totalCostsAfter): void
    {
        $this->totalCostsAfter = $totalCostsAfter;
    }

    /**
     * @return string|null
     */
    public function getTotalPriceBefore(): ?string
    {
        return $this->totalPriceBefore;
    }

    /**
     * @param string|null $totalPriceBefore
     */
    public function setTotalPriceBefore(?string $totalPriceBefore): void
    {
        $this->totalPriceBefore = $totalPriceBefore;
    }

    /**
     * @return string|null
     */
    public function getTotalPriceAfter(): ?string
    {
        return $this->totalPriceAfter;
    }

    /**
     * @param string|null $totalPriceAfter
     */
    public function setTotalPriceAfter(?string $totalPriceAfter): void
    {
        $this->totalPriceAfter = $totalPriceAfter;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @return OfferAuftrag
     */
    public function getSimple(): OfferAuftrag
    {
        return $this->simple;
    }

    /**
     * @param OfferAuftrag $simple
     */
    public function setSimple(OfferAuftrag $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return SalesStatus|null
     */
    public function getStatus(): ?SalesStatus
    {
        return $this->status;
    }

    /**
     * @param SalesStatus|null $status
     */
    public function setStatus(?SalesStatus $status): void
    {
        $this->status = $status;
    }

    /**
     * @Groups({"crList"})
     * @return int|null
     */
    public function getVersionsnrExternal(): ?int
    {
        return $this->versionsnrExternal;
    }

    /**
     * @param int|null $versionsnrExternal
     */
    public function setVersionsnrExternal(?int $versionsnrExternal): void
    {
        $this->versionsnrExternal = $versionsnrExternal;
    }
}
