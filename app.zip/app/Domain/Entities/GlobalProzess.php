<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * GlobalProzess
 *
 * @ORM\Table(name="Global_Prozess")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class GlobalProzess
{
    const PROCESS_KZK = 'KZK';

    /**
     * @ORM\Column(name="prozess_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $prozessId;

    /** @ORM\Column(name="bezeichnung", type="string", length=5, nullable=true) */
    private ?string $bezeichnung = null;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\Column(name="produktiv", type="boolean", nullable=true) */
    private ?bool $produktiv;

    /**
     * GlobalProzess constructor.
     * @param int $prozessId
     */
    public function __construct(int $prozessId)
    {
        $this->prozessId = $prozessId;
    }

    /**
     * @return int
     */
    public function getProzessId(): int
    {
        return $this->prozessId;
    }

    /**
     * @param int $prozessId
     */
    public function setProzessId(int $prozessId): void
    {
        $this->prozessId = $prozessId;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return bool|null
     */
    public function getProduktiv(): ?bool
    {
        return $this->produktiv;
    }

    /**
     * @param bool|null $produktiv
     */
    public function setProduktiv(?bool $produktiv): void
    {
        $this->produktiv = $produktiv;
    }

    /**
     * @return bool
     */
    public function isKzk(): bool
    {
        return $this->bezeichnung == self::PROCESS_KZK;
    }
}
