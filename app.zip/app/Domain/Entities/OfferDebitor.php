<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferDebitor
 *
 * @ORM\Table(name="Offer_Debitor")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferDebitor
{
    /**
     * @var int
     *
     * @ORM\Column(name="debitor_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $debitorId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nummer", type="string", length=50, nullable=true)
     */
    private $nummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gesellschaftsnummer", type="string", length=50, nullable=true)
     */
    private $gesellschaftsnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="text", length=-1, nullable=true)
     */
    private $name;

    /**
     * @var string|null
     *
     * @ORM\Column(name="anschrift", type="text", length=-1, nullable=true)
     */
    private $anschrift;

    /**
     * @var int|null
     *
     * @ORM\Column(name="plz", type="integer", nullable=true)
     */
    private $plz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ort", type="string", length=50, nullable=true)
     */
    private $ort;

    /**
     * @var string|null
     *
     * @ORM\Column(name="strasse", type="string", length=50, nullable=true)
     */
    private $strasse;

    /**
     * @var string|null
     *
     * @ORM\Column(name="konzernkunde", type="string", length=50, nullable=true)
     */
    private $konzernkunde;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private $bemerkungen;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="allow_abgrenzung", type="boolean", nullable=true)
     */
    private $allowAbgrenzung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="`external`", type="boolean", nullable=true)
     */
    private ?bool $external;

    /**
     * @return int
     * @Groups({"orderBasic", "icp"})
     */
    public function getDebitorId(): int
    {
        return $this->debitorId;
    }

    /**
     * @Groups({"cbiOverview", "icp"})
     * @return string|null
     */
    public function getNummer(): ?string
    {
        return $this->nummer;
    }

    /**
     * @param string|null $nummer
     */
    public function setNummer(?string $nummer): void
    {
        $this->nummer = $nummer;
    }

    /**
     * @Groups({"cbiOverview"})
     * @return string|null
     */
    public function getGesellschaftsnummer(): ?string
    {
        return $this->gesellschaftsnummer;
    }

    /**
     * @param string|null $gesellschaftsnummer
     */
    public function setGesellschaftsnummer(?string $gesellschaftsnummer): void
    {
        $this->gesellschaftsnummer = $gesellschaftsnummer;
    }

    /**
     * @return string|null
     * @Groups({"icp"})
     */
    public function getName(): ?string
    {
        return $this->name;
    }

    /**
     * @param string|null $name
     */
    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string|null
     */
    public function getAnschrift(): ?string
    {
        return $this->anschrift;
    }

    /**
     * @param string|null $anschrift
     */
    public function setAnschrift(?string $anschrift): void
    {
        $this->anschrift = $anschrift;
    }

    /**
     * @return int|null
     */
    public function getPlz(): ?int
    {
        return $this->plz;
    }

    /**
     * @param int|null $plz
     */
    public function setPlz(?int $plz): void
    {
        $this->plz = $plz;
    }

    /**
     * @return string|null
     */
    public function getOrt(): ?string
    {
        return $this->ort;
    }

    /**
     * @param string|null $ort
     */
    public function setOrt(?string $ort): void
    {
        $this->ort = $ort;
    }

    /**
     * @return string|null
     */
    public function getStrasse(): ?string
    {
        return $this->strasse;
    }

    /**
     * @param string|null $strasse
     */
    public function setStrasse(?string $strasse): void
    {
        $this->strasse = $strasse;
    }

    /**
     * @return string|null
     */
    public function getKonzernkunde(): ?string
    {
        return $this->konzernkunde;
    }

    /**
     * @param string|null $konzernkunde
     */
    public function setKonzernkunde(?string $konzernkunde): void
    {
        $this->konzernkunde = $konzernkunde;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @param string|null $bemerkungen
     */
    public function setBemerkungen(?string $bemerkungen): void
    {
        $this->bemerkungen = $bemerkungen;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return bool|null
     */
    public function getAllowAbgrenzung(): ?bool
    {
        return $this->allowAbgrenzung;
    }

    /**
     * @param bool|null $allowAbgrenzung
     */
    public function setAllowAbgrenzung(?bool $allowAbgrenzung): void
    {
        $this->allowAbgrenzung = $allowAbgrenzung;
    }

    /**
     * @return bool|null
     */
    public function getExternal(): ?bool
    {
        return $this->external;
    }

    /**
     * @param bool|null $external
     */
    public function setExternal(?bool $external): void
    {
        $this->external = $external;
    }
}
