<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendRoles
 *
 * @ORM\Table(name="Backend_Roles")
 * @ORM\Entity
 */
class BackendRoles
{
    /**
     * @ORM\Column(name="role_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $roleId;

    /** @ORM\Column(name="role_short", type="string", length=50, nullable=false) */
    private string $roleShort;

    /** @ORM\Column(name="role_long", type="string", length=50, nullable=false) */
    private string $roleLong;

    /** @ORM\Column(name="max", type="integer", length=50, nullable=false) */
    private int $max;

    /** @ORM\Column(type="boolean") */
    private bool $hide;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $description;

    /**
     * @return string
     */
    public function getRoleShort(): string
    {
        return $this->roleShort;
    }

    /**
     * @return int
     */
    public function getRoleId(): int {
        return $this->roleId;
    }

    /**
     * @Groups({"groupInfo"})
     * @return string
     */
    public function getRoleLong(): string
    {
        return $this->roleLong;
    }

    /**
     * @return int
     */
    public function getMax(): int
    {
        return $this->max;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }
}
