<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaLbuDatenQuellsystem
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Daten_Quellsystem")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferFakturaLbuDatenQuellsystem
{
    /**
     * @var int
     *
     * @ORM\Column(name="quellsystem_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $quellsystemId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private ?string $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abkuerzung", type="string", length=50, nullable=true)
     */
    private $abkuerzung;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="smallint", nullable=false)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @ORM\Column(name="automation", type="boolean")
     */
    private bool $automation;

    /**
     * @return int
     */
    public function getQuellsystemId(): int
    {
        return $this->quellsystemId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
