<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Offer_AbgeschlossenGrund")
 * @ORM\Entity
 */
class OfferAbgeschlossengrund
{
    /**
     * @ORM\Column(name="abgeschlossenGrund_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $abgeschlossengrundId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="hide", type="boolean", nullable=true) */
    private ?bool $hide;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;
}
