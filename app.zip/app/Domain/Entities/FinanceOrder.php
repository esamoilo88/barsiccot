<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;
use Illuminate\Support\Facades\Date;

/**
 * Class Finance_Order
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Finance_Order")
 */
class FinanceOrder
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $simpleId;

    /** @ORM\Column(name="order_number", type="bigint",nullable=false) */
    private int $orderNumber;

    /** @ORM\Column(name="active", type="boolean",nullable=false) */
    private bool $active;

    /** @ORM\Column(name="expire", type="date", nullable=true) */
    private ?DateTime $expire;

    /** @ORM\Column(name="budget", type="decimal", nullable=true) */
    private ?float $budget;

    /** @ORM\Column(name="is_default", type="boolean") */
    private bool $isDefault;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * FinanceOrder constructor.
     * @param OfferAuftrag $simpleId
     * @param int $orderNumber
     * @param bool $active
     * @param bool $isDefault
     * @param DateTime|null $expire
     * @param string|null $budget
     */
    public function __construct(
        OfferAuftrag $simpleId,
        int $orderNumber,
        bool $active,
        bool $isDefault,
        ?DateTime $expire = null,
        ?string $budget = null
    )
    {
        $this->simpleId = $simpleId;
        $this->orderNumber = $orderNumber;
        $this->active = $active;
        $this->expire = $expire;
        $this->budget = $budget;
        $this->isDefault = $isDefault;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OfferAuftrag
     */
    public function getSimpleId(): OfferAuftrag
    {
        return $this->simpleId;
    }

    /**
     * @param OfferAuftrag $simpleId
     */
    public function setSimpleId(OfferAuftrag $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @Groups({"mapping"})
     * @return int
     */
    public function getOrderNumber(): int
    {
        return $this->orderNumber;
    }

    /**
     * @param int $orderNumber
     */
    public function setOrderNumber(int $orderNumber): void
    {
        $this->orderNumber = $orderNumber;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * @param bool $active
     */
    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    /**
     * @return DateTime|null
     */
    public function getExpire(): ?DateTime
    {
        return $this->expire;
    }

    /**
     * @param DateTime|null $expire
     */
    public function setExpire(?DateTime $expire): void
    {
        $this->expire = $expire;
    }

    /**
     * @return float|null
     */
    public function getBudget(): ?float
    {
        return $this->budget;
    }

    /**
     * @param float|null $budget
     */
    public function setBudget(?float $budget): void
    {
        $this->budget = $budget;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

}
