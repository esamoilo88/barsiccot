<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * BackendMailhistorie
 *
 * @ORM\Table(name="Backend_Mailhistorie")
 * @ORM\Entity
 */
class BackendMailhistorie
{
    /**
     * @ORM\Column(name="mail_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $mailId;

    /** @ORM\Column(name="simple_id", type="integer", nullable=false) */
    private int $simpleId;

    /** @ORM\Column(name="von", type="string", length=80, nullable=false) */
    private string $von;

    /** @ORM\Column(name="an", type="text", length=-1, nullable=false) */
    private string $an;

    /** @ORM\Column(name="betreff", type="text", length=-1, nullable=false) */
    private string $betreff;

    /** @ORM\Column(name="nachricht", type="text", length=16, nullable=false) */
    private string $nachricht;

    /** @ORM\Column(name="success", type="boolean", nullable=false) */
    private bool $success;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $dateline;

    /** @ORM\Column(name="cc", type="text", length=-1, nullable=true) */
    private ?string $cc;

    /** @ORM\Column(name="bcc", type="text", length=-1, nullable=true) */
    private ?string $bcc;

    /** @ORM\Column(name="attachments", type="text", length=-1, nullable=true) */
    private ?string $attachments;

    /** @ORM\Column(name="prio", type="smallint", nullable=true) */
    private ?int $prio;

    /** @ORM\Column(name="server_name", type="string", length=50, nullable=true) */
    private ?string $serverName;

    /** @ORM\Column(name="server_ip", type="string", length=50, nullable=true) */
    private ?string $serverIp;

    /**
     * BackendMailhistorie constructor.
     * @param int $simpleId
     * @param string $von
     * @param string $an
     * @param string $betreff
     * @param string $nachricht
     * @param bool $success
     * @param string|null $cc
     * @param string|null $bcc
     * @param string|null $attachments
     * @param int|null $prio
     * @param string|null $serverName
     * @param string|null $serverIp

     */
    public function __construct(
        string $von,
        string $an,
        int $simpleId,
        string $betreff,
        string $nachricht,
        bool $success,
        ?string $cc,
        ?string $bcc,
        ?string $attachments,
        ?int $prio,
        ?string $serverName = null,
        ?string $serverIp = null
    )
    {
        $this->von = $von;
        $this->an = $an;
        $this->betreff = $betreff;
        $this->nachricht = $nachricht;
        $this->cc = $cc;
        $this->bcc = $bcc;
        $this->attachments = $attachments;
        $this->prio = $prio;
        $this->serverName = $serverName;
        $this->serverIp = $serverIp;
        $this->success = $success;
        $this->simpleId = $simpleId;
    }

}
