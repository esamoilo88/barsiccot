<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaApproval
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Approval")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaApproval
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(type="string") */
    private string $name;

    /** @ORM\Column(type="string") */
    private string $subtext;

    /** @ORM\Column(type="string") */
    private string $icon;

    /** @ORM\Column(name="from_cost_value", type="decimal") */
    private float $fromCostValue;

    /** @ORM\Column(name="to_cost_value", type="decimal") */
    private float $toCostValue;

    /** @ORM\Column(type="boolean") */
    private bool $optional;

    /** @ORM\Column(name="optional_pre_approved", type="boolean") */
    private bool $optionalPreApproved = false;

    /** @ORM\Column(type="boolean") */
    private bool $hide;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $filterKoart;

    /** @ORM\Column(type="string") */
    private string $rechteIds;

    /** @ORM\Column(name="default_approver_email", type="string", nullable=true) */
    private ?string $defaultApproverEmail;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\OneToMany(targetEntity="OnkaApprovalResult", mappedBy="onkaApproval")*/
    private Collection $onkaApprovalResults;

    /**
     * OnkaApproval constructor.
     * @param string $name
     * @param string $subtext
     * @param string $icon
     * @param float $from
     * @param float $to
     * @param bool $optional
     * @param bool $hide
     * @param string|null $filterKoart
     * @param string $rechteIds
     */
    public function __construct(
        string $name,
        string $subtext,
        string $icon,
        float $from,
        float $to,
        bool $optional,
        bool $hide,
        string $rechteIds,
        ?string $filterKoart
    )
    {
        $this->name = $name;
        $this->subtext = $subtext;
        $this->icon = $icon;
        $this->fromCostValue = $from;
        $this->toCostValue = $to;
        $this->optional = $optional;
        $this->hide = $hide;
        $this->filterKoart = $filterKoart;
        $this->rechteIds = $rechteIds;
        $this->onkaApprovalResults = new ArrayCollection();
    }

    /**
     * @return int
     * @Groups({"onkaApprovalItems"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Groups({"onkaApprovalItems"})
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     * @Groups({"onkaApprovalItems"})
     */
    public function getSubtext(): string
    {
        return $this->subtext;
    }

    /**
     * @return string
     * @Groups({"onkaApprovalItems"})
     */
    public function getIcon(): string
    {
        return $this->icon;
    }

    /**
     * @return float
     */
    public function getFromCostValue(): float
    {
        return $this->fromCostValue;
    }

    /**
     * @return float
     */
    public function getToCostValue(): float
    {
        return $this->toCostValue;
    }

    /**
     * @return bool
     * @Groups({"onkaApprovalItems"})
     */
    public function isOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @return bool
     * @Groups({"onkaApprovalItems"})
     */
    public function isOptionalPreApproved(): bool
    {
        return $this->optionalPreApproved;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return string|null
     */
    public function getFilterKoart(): ?string
    {
        return $this->filterKoart;
    }

    /**
     * @return string
     * @Groups({"onkaApprovalItems"})
     */
    public function getRechteIds(): string
    {
        return $this->rechteIds;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return string|null
     */
    public function getDefaultApproverEmail(): ?string
    {
        return $this->defaultApproverEmail;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string $subtext
     */
    public function setSubtext(string $subtext): void
    {
        $this->subtext = $subtext;
    }

    /**
     * @param string $icon
     */
    public function setIcon(string $icon): void
    {
        $this->icon = $icon;
    }

    /**
     * @param float $fromCostValue
     */
    public function setFromCostValue(float $fromCostValue): void
    {
        $this->fromCostValue = $fromCostValue;
    }

    /**
     * @param float $toCostValue
     */
    public function setToCostValue(float $toCostValue): void
    {
        $this->toCostValue = $toCostValue;
    }

    /**
     * @param bool $optional
     */
    public function setOptional(bool $optional): void
    {
        $this->optional = $optional;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @param string|null $filterKoart
     */
    public function setFilterKoart(?string $filterKoart): void
    {
        $this->filterKoart = $filterKoart;
    }

    /**
     * @param string $rechteIds
     */
    public function setRechteIds(string $rechteIds): void
    {
        $this->rechteIds = $rechteIds;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return ArrayCollection|Collection
     * @Groups({"onkaApprovalItems"})
     */
    public function getOnkaApprovalResults()
    {
        return $this->onkaApprovalResults;
    }
}
