<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesZdfTransaktion
 *
 * @ORM\Table(name="Sales_ZDF_Transaktion")
 * @ORM\Entity
 */
class SalesZdfTransaktion
{
    /**
     * @ORM\Column(name="transaktions_id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $transaktionsId;

    /**
     * @ORM\Column(name="errorcode", type="integer", nullable=true)
     */
    private ?int $errorcode;

    /**
     * @ORM\Column(name="errortext", type="string", length=255, nullable=true)
     */
    private ?string $errortext;

    /**
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="update")
     */
    private ?DateTime $modified;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $created;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="SalesZdfStammdaten")
     * @ORM\JoinColumn(name="zdf_id", referencedColumnName="zdf_id")
     */
    private SalesZdfStammdaten $zdf;

    /**
     * SalesZdfTransaktion constructor.
     * @param SalesZdfStammdaten $zdf
     * @param int|null $errorcode
     * @param string|null $errortext
     */
    public function __construct(SalesZdfStammdaten $zdf, ?int $errorcode = null, ?string $errortext = null)
    {
        $this->zdf = $zdf;
        $this->errorcode = $errorcode;
        $this->errortext = $errortext;
    }

    /**
     * @return int
     */
    public function getTransaktionsId(): int
    {
        return $this->transaktionsId;
    }

    /**
     * @param int|null $errorcode
     */
    public function setErrorcode(?int $errorcode): void
    {
        $this->errorcode = $errorcode;
    }

    /**
     * @param string|null $errortext
     */
    public function setErrortext(?string $errortext): void
    {
        $this->errortext = $errortext;
    }

    /**
     * @return int|null
     */
    public function getErrorcode(): ?int
    {
        return $this->errorcode;
    }
}
