<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Offer_Faktura_Billing_Head")
 * @ORM\Entity
 */
class OfferFakturaBillingHead
{
    /**
     * @ORM\Column(name="head_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $headId;

    /** @ORM\Column(name="billing_type_id", type="integer", nullable=false) */
    private int $billingTypeId;

    /** @ORM\Column(name="vorgangstyp", type="string", length=2, nullable=true) */
    private ?string $vorgangstyp;

    /** @ORM\Column(name="debitor", type="string", length=50, nullable=true) */
    private ?string $debitor;

    /** @ORM\Column(name="sap_bestellnummer", type="string", length=50, nullable=true) */
    private ?string $sapBestellnummer;

    /** @ORM\Column(name="ansprechpartner", type="string", length=253, nullable=true) */
    private ?string $ansprechpartner;

    /** @ORM\Column(name="billing_subject", type="string", length=150, nullable=true) */
    private ?string $billingSubject;

    /** @ORM\Column(name="billing_date", type="datetime", nullable=false) */
    private \DateTime $billingDate;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id", nullable=true)
     */
    private ?SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbu")
     * @ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id", nullable=true)
     */
    private ?OfferFakturaLbu $lbu;

    /** @ORM\OneToMany(targetEntity="OfferFakturaBillingPosition", mappedBy="head", cascade={"persist"}) */
    private Collection $positions;

    /**
     * OfferFakturaBillingHead constructor.
     * @param int $billingTypeId
     * @param \DateTime $billingDate
     * @param SalesStammdaten|null $simple
     */
    public function __construct(int $billingTypeId, \DateTime $billingDate, ?SalesStammdaten $simple)
    {
        $this->billingTypeId = $billingTypeId;
        $this->billingDate = $billingDate;
        $this->simple = $simple;
    }

    /**
     * @return int
     */
    public function getHeadId(): int
    {
        return $this->headId;
    }

    /**
     * @return int
     */
    public function getBillingTypeId(): int
    {
        return $this->billingTypeId;
    }

    /**
     * @param int $billingTypeId
     */
    public function setBillingTypeId(int $billingTypeId): void
    {
        $this->billingTypeId = $billingTypeId;
    }

    /**
     * @return string|null
     */
    public function getVorgangstyp(): ?string
    {
        return $this->vorgangstyp;
    }

    /**
     * @param string|null $vorgangstyp
     */
    public function setVorgangstyp(?string $vorgangstyp): void
    {
        $this->vorgangstyp = $vorgangstyp;
    }

    /**
     * @return string|null
     */
    public function getDebitor(): ?string
    {
        return $this->debitor;
    }

    /**
     * @param string|null $debitor
     */
    public function setDebitor(?string $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @param string|null $sapBestellnummer
     */
    public function setSapBestellnummer(?string $sapBestellnummer): void
    {
        $this->sapBestellnummer = $sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getAnsprechpartner(): ?string
    {
        return $this->ansprechpartner;
    }

    /**
     * @param string|null $ansprechpartner
     */
    public function setAnsprechpartner(?string $ansprechpartner): void
    {
        $this->ansprechpartner = $ansprechpartner;
    }

    /**
     * @return string|null
     */
    public function getBillingSubject(): ?string
    {
        return $this->billingSubject;
    }

    /**
     * @param string|null $billingSubject
     */
    public function setBillingSubject(?string $billingSubject): void
    {
        $this->billingSubject = $billingSubject;
    }

    /**
     * @return \DateTime
     */
    public function getBillingDate(): \DateTime
    {
        return $this->billingDate;
    }

    /**
     * @param \DateTime $billingDate
     */
    public function setBillingDate(\DateTime $billingDate): void
    {
        $this->billingDate = $billingDate;
    }

    /**
     * @return SalesStammdaten|null
     */
    public function getSimple(): ?SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @param SalesStammdaten|null $simple
     */
    public function setSimple(?SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferFakturaLbu|null
     */
    public function getLbu(): ?OfferFakturaLbu
    {
        return $this->lbu;
    }

    /**
     * @param OfferFakturaLbu|null $lbu
     */
    public function setLbu(?OfferFakturaLbu $lbu): void
    {
        $this->lbu = $lbu;
    }

    /**
     * @return Collection
     */
    public function getPositions(): Collection
    {
        return $this->positions;
    }

    /**
     * @param Collection $positions
     */
    public function setPositions(Collection $positions): void
    {
        $this->positions = $positions;
    }
}
