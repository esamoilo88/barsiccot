<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendBereichkatalog
 *
 * @ORM\Table(name="Backend_BereichKatalog")
 * @ORM\Entity
 */
class BackendBereichkatalog
{
    /**
     * @var int
     *
     * @ORM\Column(name="bereichKatalog_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $bereichkatalogId;

    /**
     * @var \BackendBereich
     *
     * @ORM\ManyToOne(targetEntity="BackendBereich")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bereich_id", referencedColumnName="bereich_id")
     * })
     */
    private $bereich;

    /**
     * @var \OfferKatalogKategorie
     *
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")
     * })
     */
    private $kategorie;


}
