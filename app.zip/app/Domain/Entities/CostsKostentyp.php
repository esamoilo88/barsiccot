<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CostsKostentyp
 *
 * @ORM\Table(name="Costs_Kostentyp")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsKostentyp
{
    public const KOSTEN_TYPE_NAME = 'Kosten';
    public const RESSOURCEN_TYPE_NAME = 'Ressourcen';

    /**
     * @var int
     *
     * @ORM\Column(name="kostentyp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $kostentypId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    public function isKostentyp(int $type): bool
    {
        return $this->kostentypId == $type;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return int
     */
    public function getKostentypId(): int
    {
        return $this->kostentypId;
    }

    /**
     * @Groups({"leistungenPaginated", "adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @return bool
     */
    public function isKosten(): bool
    {
        return $this->bezeichnung === self::KOSTEN_TYPE_NAME;
    }

    /**
     * @return bool
     */
    public function isRessourcen(): bool
    {
        return $this->bezeichnung === self::RESSOURCEN_TYPE_NAME;
    }
}
