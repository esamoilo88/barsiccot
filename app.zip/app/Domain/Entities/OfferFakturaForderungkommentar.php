<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaForderungkommentar
 *
 * @ORM\Table(name="Offer_Faktura_Forderungkommentar")
 * @ORM\Entity
 */
class OfferFakturaForderungkommentar
{
    /**
     * @var int
     *
     * @ORM\Column(name="forderungkommentar_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $forderungkommentarId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kommentar", type="text", length=-1, nullable=true)
     */
    private $kommentar;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \GlobalGate
     *
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
