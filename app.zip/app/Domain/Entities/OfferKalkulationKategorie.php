<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKalkulationKategorie
 *
 * @ORM\Table(name="Offer_Kalkulation_Kategorie")
 * @ORM\Entity
 */
class OfferKalkulationKategorie
{
    /**
     * @var int
     *
     * @ORM\Column(name="ap_category_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $apCategoryId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="short_name", type="string", length=10, nullable=true)
     */
    private $shortName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="long_name", type="string", length=50, nullable=true)
     */
    private $longName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="dive_category", type="string", length=10, nullable=true)
     */
    private $diveCategory;

    /**
     * @var string|null
     *
     * @ORM\Column(name="image", type="string", length=50, nullable=true)
     */
    private $image;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="smallint", nullable=false)
     */
    private $sort = '0';

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide = '0';

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
