<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferVirtuellesProdukt
 *
 * @ORM\Table(name="Offer_Virtuelles_Produkt")
 * @ORM\Entity
 */
class OfferVirtuellesProdukt
{
    /**
     * @var int
     *
     * @ORM\Column(name="vp_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $vpId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=250, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var string|null
     *
     * @ORM\Column(name="myshs_hash", type="string", length=32, nullable=true)
     */
    private $myshsHash;


}
