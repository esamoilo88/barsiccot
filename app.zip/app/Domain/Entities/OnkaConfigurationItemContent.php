<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaConfigurationItemContent
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configuration_Item_Content")
 */
class OnkaConfigurationItemContent
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfigurationItem", inversedBy="itemContent")
     * @ORM\JoinColumn(name="item_id",referencedColumnName="id", nullable=false)
     */
    private OnkaConfigurationItem $item;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="kat_leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=false)
     */
    private OfferKatalogLeistungsposition $katalogLp;

    /** @ORM\Column(type="decimal", precision=26, scale=16) */
    private $quantity;

    /**
     * @ORM\Column(name="optional", type="boolean", nullable=false)
     */
    private bool $optional = false;

    /** @ORM\Column(type="boolean") */
    private bool $selected = false;

    /**
     * @ORM\Column(name="ui_element", type="string", nullable=true)
     */
    private ?string $uiElement;

    /**
     * @ORM\Column(name="radio_group", type="string", nullable=true)
     */
    private ?string $radioGroup;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2)
     */
    private float $unitCosts = 0;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2)
     */
    private float $unitPrice = 0;

    /**
     * OnkaConfigurationItemContent constructor.
     * @param OnkaConfigurationItem $item
     * @param OfferKatalogLeistungsposition $katalogLp
     * @param float $quantity
     * @param bool $optional
     * @param bool $selected
     * @param string|null $uiElement
     * @param string|null $radioGroup
     */
    public function __construct(
        OnkaConfigurationItem $item,
        OfferKatalogLeistungsposition $katalogLp,
        $quantity,
        bool $optional,
        bool $selected,
        ?string $uiElement,
        ?string $radioGroup
    )
    {
        $this->item = $item;
        $this->katalogLp = $katalogLp;
        $this->quantity = $quantity;
        $this->optional = $optional;
        $this->selected = $selected;
        $this->uiElement = $uiElement;
        $this->radioGroup = $radioGroup;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return OnkaConfigurationItem
     */
    public function getItem(): OnkaConfigurationItem
    {
        return $this->item;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferKatalogLeistungsposition
     */
    public function getKatalogLp(): OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @Groups({"confItemsPaginated"})
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function getOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool
     */
    public function getSelected(): bool
    {
        return $this->selected;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string|null
     */
    public function getRadioGroup(): ?string
    {
        return $this->radioGroup;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return string|null
     */
    public function getUiElement(): ?string
    {
        return $this->uiElement;
    }

    /**
     * @param bool $optioonal
     */
    public function setOptional(bool $optioonal): void
    {
        $this->optional = $optioonal;
    }

    /**
     * @param bool $selected
     */
    public function setSelected(bool $selected): void
    {
        $this->selected = $selected;
    }

    /**
     * @param float $unitCosts
     */
    public function setUnitCosts(float $unitCosts): void
    {
        $this->unitCosts = $unitCosts;
    }

    /**
     * @param float|int $unitPrice
     */
    public function setUnitPrice($unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return float
     */
    public function getUnitPrice(): float
    {
        return $this->unitPrice;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return float
     */
    public function getUnitCosts(): float
    {
        return $this->unitCosts;
    }

}
