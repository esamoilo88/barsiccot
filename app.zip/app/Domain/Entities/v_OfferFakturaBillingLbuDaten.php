<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Faktura_Billing_LBU_Daten")
 */
class v_OfferFakturaBillingLbuDaten
{
    /**
     * @ORM\Id
     * @ORM\Column(name="lbu_daten_id", type="integer")
     */
    private int $lbuDatenId;

    /**
     * @ORM\ManyToOne(targetEntity="v_OfferFakturaBillingLbu")
     * @ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id")
     */
    private v_OfferFakturaBillingLbu $lbu;

    /** @ORM\Column(name="mat_nr", type="integer", nullable=true) */
    private ?int $matNr;

    /** @ORM\Column(name="simple_id", type="integer") */
    private int $simpleId;

    /** @ORM\Column(name="angebotsposition_id", type="integer", nullable=true) */
    private ?int $angebotspositionId;

    /** @ORM\Column(name="angebotsposition", type="string", nullable=true) */
    private ?string $angebotsposition;

    /** @ORM\Column(name="auftrags_menge", type="decimal", precision=38, scale=12, nullable=true) */
    private ?float $auftragsMenge;

    /** @ORM\Column(name="einzelpreis_dtag", type="decimal", precision=18, scale=2) */
    private float $einzelpreisDtag;

    /** @ORM\Column(name="sachkonto", type="integer", nullable=true) */
    private ?int $sachkonto;

    /** @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true) */
    private ?string $icpKontPspKst;

    /** @ORM\Column(name="icp_kont_bpos", type="integer", nullable=true) */
    private ?int $icpKontBpos;

    /** @ORM\Column(name="psp_element", type="string", length=50, nullable=true) */
    private ?string $pspElement;

    /** @ORM\Column(name="producttype_name", type="string", length=40, nullable=true) */
    private ?string $producttypeName;

    /**
     * @return int
     */
    public function getLbuDatenId(): int
    {
        return $this->lbuDatenId;
    }

    /**
     * @return v_OfferFakturaBillingLbu
     */
    public function getLbu(): v_OfferFakturaBillingLbu
    {
        return $this->lbu;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNr;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return string|null
     */
    public function getAngebotsposition(): ?string
    {
        return $this->angebotsposition;
    }

    /**
     * @return float|null
     */
    public function getAuftragsMenge(): ?float
    {
        return $this->auftragsMenge;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDtag(): float
    {
        return $this->einzelpreisDtag;
    }

    /**
     * @return int|null
     */
    public function getSachkonto(): ?int
    {
        return $this->sachkonto;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return string|null
     */
    public function getProducttypeName(): ?string
    {
        return $this->producttypeName;
    }
}
