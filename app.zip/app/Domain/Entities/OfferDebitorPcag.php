<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferDebitorPcag
 *
 * @ORM\Table(name="Offer_Debitor_PCAG")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferDebitorPcag
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id")
     * })
     */
    private OfferDebitor $debitor;

    /**
     * @ORM\ManyToOne(targetEntity="SalesLabel")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="pcag_id", referencedColumnName="label_id")
     * })
     */
    private SalesLabel $pcag;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return OfferDebitor
     */
    public function getDebitor(): OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @param OfferDebitor $debitor
     */
    public function setDebitor(OfferDebitor $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @return SalesLabel
     */
    public function getPcag(): SalesLabel
    {
        return $this->pcag;
    }

    /**
     * @param SalesLabel $pcag
     */
    public function setPcag(SalesLabel $pcag): void
    {
        $this->pcag = $pcag;
    }
}
