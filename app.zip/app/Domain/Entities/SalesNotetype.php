<?php


namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Sales_Notetypes")
 * @ORM\Entity
 */

class SalesNotetype
{

    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     */
    private string $name;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"default"="0"})
     */
    private int $sort = 0;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean", options={"default"="0"})
     */
    private bool $hide = false;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     */
    private string $icon;

    /**
     * @var DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private DateTime $bits;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return DateTime
     */
    public function getBits(): DateTime
    {
        return $this->bits;
    }

    /**
     * @return string
     */
    public function getIcon(): string
    {
        return $this->icon;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string $icon
     */
    public function setIcon(string $icon): void
    {
        $this->icon = $icon;
    }
}
