<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * Backend_BenutzerPermission
 *
 * @ORM\Table(name="Backend_BenutzerPermissions")
 * @ORM\Entity
 */
class BackendBenutzerPermissions
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer", inversedBy="backendRechtes")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $backendBenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRechte")
     * @ORM\JoinColumn(name="rechte_id", referencedColumnName="rechte_id")
     */
    private BackendRechte $backendRechte;

    /**
     * BackendBenutzerPermission constructor.
     * @param BackendBenutzer $backendBenutzer
     * @param BackendRechte $rechte
     */
    public function __construct(BackendBenutzer $backendBenutzer, BackendRechte $rechte)
    {
        $this->backendBenutzer = $backendBenutzer;
        $this->backendRechte = $rechte;
    }

    /**
     * @return BackendBenutzer
     */
    public function backendBenutzer(): BackendBenutzer
    {
        return $this->backendBenutzer;
    }

    /**
     * @return BackendRechte
     */
    public function backendRechte(): BackendRechte
    {
        return $this->backendRechte;
    }
}
