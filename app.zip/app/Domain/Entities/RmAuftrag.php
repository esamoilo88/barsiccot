<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmAuftrag
 *
 * @ORM\Table(name="RM_Auftrag")
 * @ORM\Entity
 */
class RmAuftrag
{
    /**
     * @var int
     *
     * @ORM\Column(name="auftrag_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $auftragId;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="auftragsbestaetigung", type="datetime", nullable=true)
     */
    private $auftragsbestaetigung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bestellung_abgeschlossen", type="datetime", nullable=true)
     */
    private $bestellungAbgeschlossen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sap_nr", type="string", length=150, nullable=true)
     */
    private $sapNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zdf_ticket_nr", type="string", length=150, nullable=true)
     */
    private $zdfTicketNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="servicevertrags_nr", type="string", length=150, nullable=true)
     */
    private $servicevertragsNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="seceit_nr", type="string", length=150, nullable=true)
     */
    private $seceitNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkung", type="text", length=-1, nullable=true)
     */
    private $bemerkung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produktionsstoerung", type="text", length=-1, nullable=true)
     */
    private $produktionsstoerung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="produktionsstoerung_date", type="datetime", nullable=true)
     */
    private $produktionsstoerungDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="serviceabbildung_erledigt", type="datetime", nullable=true)
     */
    private $serviceabbildungErledigt;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="datum_fakturameldung", type="datetime", nullable=true)
     */
    private $datumFakturameldung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="auftragsvolumen", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $auftragsvolumen;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="abgeschlossen_date", type="datetime", nullable=true)
     */
    private $abgeschlossenDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="vertrag_gekuendigt_am", type="datetime", nullable=true)
     */
    private $vertragGekuendigtAm;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var int|null
     *
     * @ORM\Column(name="verknuepfte_simple_id", type="integer", nullable=true)
     */
    private $verknuepfteSimpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stoerung_prozess", type="text", length=-1, nullable=true)
     */
    private $stoerungProzess;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_1", type="text", length=-1, nullable=true)
     */
    private $customField1;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_2", type="text", length=-1, nullable=true)
     */
    private $customField2;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_3", type="text", length=-1, nullable=true)
     */
    private $customField3;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_4", type="text", length=-1, nullable=true)
     */
    private $customField4;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_5", type="text", length=-1, nullable=true)
     */
    private $customField5;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_6", type="text", length=-1, nullable=true)
     */
    private $customField6;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_7", type="text", length=-1, nullable=true)
     */
    private $customField7;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_8", type="text", length=-1, nullable=true)
     */
    private $customField8;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_9", type="text", length=-1, nullable=true)
     */
    private $customField9;

    /**
     * @var string|null
     *
     * @ORM\Column(name="custom_field_10", type="text", length=-1, nullable=true)
     */
    private $customField10;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="SVbenutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $svbenutzer;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;

    /**
     * @var \RmAnfrage
     *
     * @ORM\ManyToOne(targetEntity="RmAnfrage")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
