<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmBeauftragungsform
 *
 * @ORM\Table(name="RM_Beauftragungsform")
 * @ORM\Entity
 */
class RmBeauftragungsform
{
    /**
     * @var int
     *
     * @ORM\Column(name="beauftragungsform_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $beauftragungsformId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=100, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hide", type="boolean", nullable=true)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
