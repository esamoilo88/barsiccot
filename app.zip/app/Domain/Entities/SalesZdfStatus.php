<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesZdfStatus
 *
 * @ORM\Table(name="Sales_ZDF_Status")
 * @ORM\Entity
 */
class SalesZdfStatus
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\Column(name="bemerkung", type="text", length=-1, nullable=true)
     */
    private ?string $bemerkung;

    /**
     * @ORM\Column(name="status", type="string", length=15, nullable=true)
     */
    private ?string $status;

    /**
     * @ORM\Column(name="substatus", type="string", length=10, nullable=true)
     */
    private ?string $substatus;

    /**
     * @ORM\Column(name="statustext", type="string", length=50, nullable=true)
     */
    private ?string $statustext;

    /**
     * @ORM\Column(name="substatustext", type="string", length=50, nullable=true)
     */
    private ?string $substatustext;

    /**
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="update")
     */
    private ?DateTime $modified;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $created;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="SalesZdfStammdaten")
     * @ORM\JoinColumn(name="zdf_id", referencedColumnName="zdf_id")
     */
    private SalesZdfStammdaten $zdf;

    /**
     * SalesZdfStatus constructor.
     * @param SalesStammdaten $simple
     * @param string|null $bemerkung
     * @param string|null $status
     * @param string|null $substatus
     * @param string|null $statustext
     * @param string|null $substatustext
     * @param SalesZdfStammdaten $zdf
     */
    public function __construct(
        SalesStammdaten $simple,
        ?string $bemerkung,
        ?string $status,
        ?string $substatus,
        ?string $statustext,
        ?string $substatustext,
        SalesZdfStammdaten $zdf
    )
    {
        $this->simple = $simple;
        $this->bemerkung = $bemerkung;
        $this->status = $status;
        $this->substatus = $substatus;
        $this->statustext = $statustext;
        $this->substatustext = $substatustext;
        $this->zdf = $zdf;
    }

    /**
     * @param string|null $bemerkung
     */
    public function setBemerkung(?string $bemerkung): void
    {
        $this->bemerkung = $bemerkung;
    }

    /**
     * @param string|null $status
     */
    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    /**
     * @param string|null $substatus
     */
    public function setSubstatus(?string $substatus): void
    {
        $this->substatus = $substatus;
    }

    /**
     * @param string|null $substatustext
     */
    public function setSubstatustext(?string $substatustext): void
    {
        $this->substatustext = $substatustext;
    }

}
