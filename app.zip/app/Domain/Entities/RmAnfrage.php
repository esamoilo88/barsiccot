<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmAnfrage
 *
 * @ORM\Table(name="RM_Anfrage")
 * @ORM\Entity
 */
class RmAnfrage
{
    /**
     * @var string|null
     *
     * @ORM\Column(name="betreff", type="string", length=200, nullable=true)
     */
    private $betreff;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="materialbestellung", type="boolean", nullable=true)
     */
    private $materialbestellung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="servicerelevant", type="boolean", nullable=true)
     */
    private $servicerelevant;

    /**
     * @var string|null
     *
     * @ORM\Column(name="banf_nr", type="string", length=50, nullable=true)
     */
    private $banfNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tesy_nr", type="string", length=50, nullable=true)
     */
    private $tesyNr;

    /**
     * @var int|null
     *
     * @ORM\Column(name="datenbanknummer", type="integer", nullable=true)
     */
    private $datenbanknummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="seceit_nr_anfrage", type="string", length=150, nullable=true)
     */
    private $seceitNrAnfrage;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="produktionsreif_am", type="datetime", nullable=true)
     */
    private $produktionsreifAm;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="fachteam_am", type="datetime", nullable=true)
     */
    private $fachteamAm;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true)
     */
    private $bemerkungen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="eingangsmail", type="text", length=-1, nullable=true)
     */
    private $eingangsmail;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="eingangsdatum", type="datetime", nullable=false)
     */
    private $eingangsdatum;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     */
    private $created;

    /**
     * @var \GlobalGate
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;

    /**
     * @var \RmBeauftragungsform
     *
     * @ORM\ManyToOne(targetEntity="RmBeauftragungsform")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="beauftragungsform_id", referencedColumnName="beauftragungsform_id")
     * })
     */
    private $beauftragungsform;

    /**
     * @var \RmDienstleistung
     *
     * @ORM\ManyToOne(targetEntity="RmDienstleistung")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="dienstleistungs_id", referencedColumnName="dienstleistungs_id")
     * })
     */
    private $dienstleistungs;

    /**
     * @var \RmKunden
     *
     * @ORM\ManyToOne(targetEntity="RmKunden")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kunden_id", referencedColumnName="kunden_id")
     * })
     */
    private $kunden;

    /**
     * @var \RmProduktcluster
     *
     * @ORM\ManyToOne(targetEntity="RmProduktcluster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="pc_id", referencedColumnName="pc_id")
     * })
     */
    private $pc;

    /**
     * @var \RmTeam
     *
     * @ORM\ManyToOne(targetEntity="RmTeam")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fachteam_id", referencedColumnName="team_id")
     * })
     */
    private $fachteam;

    /**
     * @var \RmWorkflowstatus
     *
     * @ORM\ManyToOne(targetEntity="RmWorkflowstatus")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="workflowstatus_id", referencedColumnName="workflowstatus_id")
     * })
     */
    private $workflowstatus;

    /**
     * @var \RmAnfragevon
     *
     * @ORM\ManyToOne(targetEntity="RmAnfragevon")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="AVbenutzer_id", referencedColumnName="email")
     * })
     */
    private $avbenutzer;


}
