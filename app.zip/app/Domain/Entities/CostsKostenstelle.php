<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * CostsKostenstelle
 *
 * @ORM\Table(name="Costs_Kostenstelle")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CostsKostenstelle
{
    /**
     * @ORM\Column(name="kostenstelle_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private ?int $kostenstelleId;

    /** @ORM\Column(name="gruppe", type="text", length=-1, nullable=true) */
    private ?string $gruppe;

    /** @ORM\Column(name="kostenstelle", type="string", length=20, nullable=true) */
    private ?string $kostenstelle;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="hide", type="boolean", nullable=true) */
    private ?bool $hide;

    /** @ORM\Column(name="sort", type="smallint", nullable=true) */
    private ?int $sort;

    /** @ORM\Column(name="created", type="datetime", nullable=true) */
    private ?\DateTime $created;

    /** @ORM\Column(name="modified", type="datetime", nullable=true) */
    private ?\DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\Column(name="short_name", type="string", length=50, nullable=true) */
    private ?string $shortName;

    /**
     * @return int|null
     */
    public function getKostenstelleId(): ?int
    {
        return $this->kostenstelleId;
    }

    /**
     * @return string|null
     */
    public function getGruppe(): ?string
    {
        return $this->gruppe;
    }

    /**
     * @param string|null $gruppe
     */
    public function setGruppe(?string $gruppe): void
    {
        $this->gruppe = $gruppe;
    }

    /**
     * @return string|null
     */
    public function getKostenstelle(): ?string
    {
        return $this->kostenstelle;
    }

    /**
     * @return string|null
     */
    public function getShortName(): ?string
    {
        return $this->shortName;
    }

    /**
     * @param string|null $kostenstelle
     */
    public function setKostenstelle(?string $kostenstelle): void
    {
        $this->kostenstelle = $kostenstelle;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return bool|null
     */
    public function getHide(): ?bool
    {
        return $this->hide;
    }

    /**
     * @param bool|null $hide
     */
    public function setHide(?bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated(): ?\DateTime
    {
        return $this->created;
    }

    /**
     * @param \DateTime|null $created
     */
    public function setCreated(?\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime|null
     */
    public function getModified(): ?\DateTime
    {
        return $this->modified;
    }

    /**
     * @param \DateTime|null $modified
     */
    public function setModified(?\DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * Get SystemProtocol value for kostenstelle
     * field in parent entities
     * @return string
     */
    public function getSPValue(): string
    {
        // use getters here because otherwise lazy load is not triggered and fatal error is happened
        return $this->getGruppe() . " " . $this->getKostenstelle();
    }
}
