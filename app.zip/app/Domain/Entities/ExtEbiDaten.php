<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtEbiDaten
 *
 * @ORM\Table(name="ext_EBI_Daten")
 * @ORM\Entity
 */
class ExtEbiDaten
{
    /**
     * @var int
     *
     * @ORM\Column(name="ebi_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $ebiId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=true)
     */
    private $simpleId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="leistungsposition_id", type="integer", nullable=true)
     */
    private $leistungspositionId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="angebotsposition_id", type="bigint", nullable=true)
     */
    private $angebotspositionId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="artikelart", type="string", length=50, nullable=true)
     */
    private $artikelart;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="abrechnungszeitraum_vom", type="datetime", nullable=true)
     */
    private $abrechnungszeitraumVom;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="abrechnungszeitraum_bis", type="datetime", nullable=true)
     */
    private $abrechnungszeitraumBis;

    /**
     * @var int|null
     *
     * @ORM\Column(name="anzahl_ist", type="integer", nullable=true)
     */
    private $anzahlIst;

    /**
     * @var int|null
     *
     * @ORM\Column(name="aufwand_minuten", type="integer", nullable=true)
     */
    private $aufwandMinuten;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp1_dtts_einzelpreis", type="decimal", precision=12, scale=2, nullable=true)
     */
    private $tp1DttsEinzelpreis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produkt", type="text", length=-1, nullable=true)
     */
    private $produkt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sap_bestellnummer", type="string", length=150, nullable=true)
     */
    private $sapBestellnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="dtts_projektnummer_sin", type="text", length=-1, nullable=true)
     */
    private $dttsProjektnummerSin;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sto_ort", type="text", length=-1, nullable=true)
     */
    private $stoOrt;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="fertigstellungsdatum", type="datetime", nullable=true)
     */
    private $fertigstellungsdatum;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ozt", type="string", length=4, nullable=true)
     */
    private $ozt;

    /**
     * @var int|null
     *
     * @ORM\Column(name="vorgangsnummer", type="bigint", nullable=true)
     */
    private $vorgangsnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="link_zum_seceit_vorgang", type="text", length=16, nullable=true)
     */
    private $linkZumSeceitVorgang;

    /**
     * @var int|null
     *
     * @ORM\Column(name="nr_seceit", type="integer", nullable=true)
     */
    private $nrSeceit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="installationsbemerkung", type="text", length=-1, nullable=true)
     */
    private $installationsbemerkung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ausfuehrender", type="string", length=50, nullable=true)
     */
    private $ausfuehrender;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="blocked", type="boolean", nullable=true)
     */
    private $blocked;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="imported", type="boolean", nullable=true)
     */
    private $imported;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     */
    private $created;


}
