<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtEbiDatenImport
 *
 * @ORM\Table(name="ext_EBI_Daten_import")
 * @ORM\Entity
 */
class ExtEbiDatenImport
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abrechnungszeitraum_vom", type="text", length=-1, nullable=true)
     */
    private $abrechnungszeitraumVom;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abrechnungszeitraum_bis", type="text", length=-1, nullable=true)
     */
    private $abrechnungszeitraumBis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="fo_id", type="text", length=-1, nullable=true)
     */
    private $foId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="to_id", type="text", length=-1, nullable=true)
     */
    private $toId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="cluster_id", type="text", length=-1, nullable=true)
     */
    private $clusterId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vpo6_cluster", type="text", length=-1, nullable=true)
     */
    private $vpo6Cluster;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tvp", type="text", length=-1, nullable=true)
     */
    private $tvp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="msk_tvp", type="text", length=-1, nullable=true)
     */
    private $mskTvp;

    /**
     * @var string|null
     *
     * @ORM\Column(name="msk_text", type="text", length=-1, nullable=true)
     */
    private $mskText;

    /**
     * @var string|null
     *
     * @ORM\Column(name="msk_matnr", type="text", length=-1, nullable=true)
     */
    private $mskMatnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="msk_alnr", type="text", length=-1, nullable=true)
     */
    private $mskAlnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="anzahl_soll", type="text", length=-1, nullable=true)
     */
    private $anzahlSoll;

    /**
     * @var string|null
     *
     * @ORM\Column(name="anzahl_ist", type="text", length=-1, nullable=true)
     */
    private $anzahlIst;

    /**
     * @var string|null
     *
     * @ORM\Column(name="aufwand_minuten", type="text", length=-1, nullable=true)
     */
    private $aufwandMinuten;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp1_dtts_einzelpreis", type="text", length=-1, nullable=true)
     */
    private $tp1DttsEinzelpreis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp1_dtts_gesamtpreis_soll", type="text", length=-1, nullable=true)
     */
    private $tp1DttsGesamtpreisSoll;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp1_dtts_gesamtpreis_ist", type="text", length=-1, nullable=true)
     */
    private $tp1DttsGesamtpreisIst;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp2_zw_einzelpreis", type="text", length=-1, nullable=true)
     */
    private $tp2ZwEinzelpreis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp2_zw_gesamtpreis_soll", type="text", length=-1, nullable=true)
     */
    private $tp2ZwGesamtpreisSoll;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tp2_zw_gesamtpreis_ist", type="text", length=-1, nullable=true)
     */
    private $tp2ZwGesamtpreisIst;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vk_einzelpreis", type="text", length=-1, nullable=true)
     */
    private $vkEinzelpreis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="liste_einzelpreis", type="text", length=-1, nullable=true)
     */
    private $listeEinzelpreis;

    /**
     * @var string|null
     *
     * @ORM\Column(name="preisinfo", type="text", length=-1, nullable=true)
     */
    private $preisinfo;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zusaetzliche_leistung", type="text", length=-1, nullable=true)
     */
    private $zusaetzlicheLeistung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produkt", type="text", length=16, nullable=true)
     */
    private $produkt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produkt_nr", type="text", length=-1, nullable=true)
     */
    private $produktNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="confmain", type="text", length=-1, nullable=true)
     */
    private $confmain;

    /**
     * @var string|null
     *
     * @ORM\Column(name="matnr", type="text", length=-1, nullable=true)
     */
    private $matnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="alnr", type="text", length=-1, nullable=true)
     */
    private $alnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="typ", type="text", length=-1, nullable=true)
     */
    private $typ;

    /**
     * @var string|null
     *
     * @ORM\Column(name="quelle", type="text", length=-1, nullable=true)
     */
    private $quelle;

    /**
     * @var string|null
     *
     * @ORM\Column(name="katstufe_1", type="text", length=-1, nullable=true)
     */
    private $katstufe1;

    /**
     * @var string|null
     *
     * @ORM\Column(name="katstufe_2", type="text", length=-1, nullable=true)
     */
    private $katstufe2;

    /**
     * @var string|null
     *
     * @ORM\Column(name="katstufe_3", type="text", length=-1, nullable=true)
     */
    private $katstufe3;

    /**
     * @var string|null
     *
     * @ORM\Column(name="katstufe_4", type="text", length=-1, nullable=true)
     */
    private $katstufe4;

    /**
     * @var string|null
     *
     * @ORM\Column(name="katstufe_5", type="text", length=-1, nullable=true)
     */
    private $katstufe5;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sece_userid", type="text", length=-1, nullable=true)
     */
    private $seceUserid;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vb_name", type="text", length=-1, nullable=true)
     */
    private $vbName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertriebspunktnummer", type="text", length=-1, nullable=true)
     */
    private $vertriebspunktnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vb_struktur", type="text", length=16, nullable=true)
     */
    private $vbStruktur;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gka_kenner", type="text", length=-1, nullable=true)
     */
    private $gkaKenner;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorleistungsknr", type="text", length=-1, nullable=true)
     */
    private $vorleistungsknr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kundennummer", type="text", length=-1, nullable=true)
     */
    private $kundennummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vnr", type="text", length=-1, nullable=true)
     */
    private $vnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nnr", type="text", length=-1, nullable=true)
     */
    private $nnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="mta_nr", type="text", length=-1, nullable=true)
     */
    private $mtaNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sap_bestellnummer", type="text", length=-1, nullable=true)
     */
    private $sapBestellnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="dtts_projektnummer_sin", type="text", length=-1, nullable=true)
     */
    private $dttsProjektnummerSin;

    /**
     * @var string|null
     *
     * @ORM\Column(name="fkto", type="text", length=-1, nullable=true)
     */
    private $fkto;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tdn_nr_zgsl", type="text", length=-1, nullable=true)
     */
    private $tdnNrZgsl;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kname", type="text", length=-1, nullable=true)
     */
    private $kname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kplz", type="text", length=-1, nullable=true)
     */
    private $kplz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kort", type="text", length=-1, nullable=true)
     */
    private $kort;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kstr", type="text", length=-1, nullable=true)
     */
    private $kstr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stoname", type="text", length=-1, nullable=true)
     */
    private $stoname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stoplz", type="text", length=-1, nullable=true)
     */
    private $stoplz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stoort", type="text", length=-1, nullable=true)
     */
    private $stoort;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stostr", type="text", length=-1, nullable=true)
     */
    private $stostr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertragsfreigabe", type="text", length=-1, nullable=true)
     */
    private $vertragsfreigabe;

    /**
     * @var string|null
     *
     * @ORM\Column(name="fertigstellungstermin", type="text", length=-1, nullable=true)
     */
    private $fertigstellungstermin;

    /**
     * @var string|null
     *
     * @ORM\Column(name="versand_der_fertigstellungsmail", type="text", length=-1, nullable=true)
     */
    private $versandDerFertigstellungsmail;

    /**
     * @var string|null
     *
     * @ORM\Column(name="onkz", type="text", length=-1, nullable=true)
     */
    private $onkz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ozt", type="text", length=-1, nullable=true)
     */
    private $ozt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ausfuehrende_tknl_itk", type="text", length=-1, nullable=true)
     */
    private $ausfuehrendeTknlItk;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorgangsnummer", type="text", length=-1, nullable=true)
     */
    private $vorgangsnummer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="servicevertrag", type="text", length=-1, nullable=true)
     */
    private $servicevertrag;

    /**
     * @var string|null
     *
     * @ORM\Column(name="oss", type="text", length=-1, nullable=true)
     */
    private $oss;

    /**
     * @var string|null
     *
     * @ORM\Column(name="link_zum_seceit_vorgang", type="text", length=16, nullable=true)
     */
    private $linkZumSeceitVorgang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nr_seceit", type="text", length=-1, nullable=true)
     */
    private $nrSeceit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nr_modular_montage_seceit", type="text", length=-1, nullable=true)
     */
    private $nrModularMontageSeceit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="dtts_kategorie", type="text", length=-1, nullable=true)
     */
    private $dttsKategorie;

    /**
     * @var string|null
     *
     * @ORM\Column(name="verrechnungsobjekt", type="text", length=-1, nullable=true)
     */
    private $verrechnungsobjekt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertriebskennzeichen", type="text", length=-1, nullable=true)
     */
    private $vertriebskennzeichen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="segmentmanagement", type="text", length=-1, nullable=true)
     */
    private $segmentmanagement;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertriebssegment", type="text", length=-1, nullable=true)
     */
    private $vertriebssegment;

    /**
     * @var string|null
     *
     * @ORM\Column(name="profitcenter", type="text", length=-1, nullable=true)
     */
    private $profitcenter;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vetriebsmitarbeiter", type="text", length=-1, nullable=true)
     */
    private $vetriebsmitarbeiter;

    /**
     * @var string|null
     *
     * @ORM\Column(name="umsetzungsart", type="text", length=-1, nullable=true)
     */
    private $umsetzungsart;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produktcluster", type="text", length=-1, nullable=true)
     */
    private $produktcluster;

    /**
     * @var string|null
     *
     * @ORM\Column(name="geschaeftsbereich", type="text", length=-1, nullable=true)
     */
    private $geschaeftsbereich;

    /**
     * @var string|null
     *
     * @ORM\Column(name="geschaeftsfall", type="text", length=-1, nullable=true)
     */
    private $geschaeftsfall;

    /**
     * @var string|null
     *
     * @ORM\Column(name="itil_main", type="text", length=-1, nullable=true)
     */
    private $itilMain;

    /**
     * @var string|null
     *
     * @ORM\Column(name="itil_sub", type="text", length=-1, nullable=true)
     */
    private $itilSub;

    /**
     * @var string|null
     *
     * @ORM\Column(name="installationsbemerkung", type="text", length=-1, nullable=true)
     */
    private $installationsbemerkung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="standort_id_rot", type="text", length=-1, nullable=true)
     */
    private $standortIdRot;

    /**
     * @var string|null
     *
     * @ORM\Column(name="geschaeftsfall_2", type="text", length=-1, nullable=true)
     */
    private $geschaeftsfall2;

    /**
     * @var string|null
     *
     * @ORM\Column(name="uebergabetermin", type="text", length=-1, nullable=true)
     */
    private $uebergabetermin;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorgangsbezeichnung", type="text", length=-1, nullable=true)
     */
    private $vorgangsbezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="projektname_simple", type="text", length=-1, nullable=true)
     */
    private $projektnameSimple;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ausfuehrender", type="text", length=-1, nullable=true)
     */
    private $ausfuehrender;

    /**
     * @var string|null
     *
     * @ORM\Column(name="artikelart", type="text", length=-1, nullable=true)
     */
    private $artikelart;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vertragsklammer", type="text", length=-1, nullable=true)
     */
    private $vertragsklammer;


}
