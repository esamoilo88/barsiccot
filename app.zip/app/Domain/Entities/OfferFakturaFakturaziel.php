<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferFakturaFakturaziel
 *
 * @ORM\Table(name="Offer_Faktura_Fakturaziel")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferFakturaFakturaziel
{
    /**
     * @var int
     *
     * @ORM\Column(name="fakturaziel_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $fakturazielId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=20, nullable=true)
     */
    private ?string $name = null;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="require_icp_kont_konto_id", type="boolean", nullable=true)
     */
    private ?bool $requireIcpKontKontoId = null;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="require_icp_kont_psp_kst", type="boolean", nullable=true)
     */
    private ?bool $requireIcpKontPspKst = null;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="require_icp_kont_bpos", type="boolean", nullable=true)
     */
    private ?bool $requireIcpKontBpos = null;

    /**
     * @var int|null
     *
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort = null;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hide", type="boolean", nullable=true)
     */
    private ?bool $hide = null;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?\DateTime $bits = null;

    public const KONTIERUNGSELEMENT_NAME = 'Kontierungselement';
    public const BESTELLUNG_NAME = 'Bestellung';

    /**
     * @return int
     * @Groups({"orderBasic", "icp"})
     */
    public function getFakturazielId(): int
    {
        return $this->fakturazielId;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getName(): ?string
    {
        return $this->name;
    }

    /**
     * @param string|null $name
     */
    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getRequireIcpKontKontoId(): ?bool
    {
        return $this->requireIcpKontKontoId;
    }

    /**
     * @param bool|null $requireIcpKontKontoId
     */
    public function setRequireIcpKontKontoId(?bool $requireIcpKontKontoId): void
    {
        $this->requireIcpKontKontoId = $requireIcpKontKontoId;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getRequireIcpKontPspKst(): ?bool
    {
        return $this->requireIcpKontPspKst;
    }

    /**
     * @param bool|null $requireIcpKontPspKst
     */
    public function setRequireIcpKontPspKst(?bool $requireIcpKontPspKst): void
    {
        $this->requireIcpKontPspKst = $requireIcpKontPspKst;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getRequireIcpKontBpos(): ?bool
    {
        return $this->requireIcpKontBpos;
    }

    /**
     * @param bool|null $requireIcpKontBpos
     */
    public function setRequireIcpKontBpos(?bool $requireIcpKontBpos): void
    {
        $this->requireIcpKontBpos = $requireIcpKontBpos;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return bool|null
     */
    public function getHide(): ?bool
    {
        return $this->hide;
    }

    /**
     * @param bool|null $hide
     */
    public function setHide(?bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return bool
     */
    public function isBestellung(): bool
    {
        return $this->name === OfferFakturaFakturaziel::BESTELLUNG_NAME;
    }

    /**
     * @return bool
     */
    public function isKontierung(): bool
    {
        return $this->name === OfferFakturaFakturaziel::KONTIERUNGSELEMENT_NAME;
    }
}
