<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Kalkulation_Berechnung_Grid")
 */
class v_OfferKalkulationBerechnungGrid
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="berechnung_id", type="integer", nullable=false)
     */
    private int $berechnungId;

    /**
     * @ORM\Column(name="element_id", type="integer", nullable=true)
     */
    private int $elementId;

    /**
     * @Groups({"leistungenPaginated"})
     * @ORM\ManyToOne(targetEntity="OfferKalkulationElement")
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id", nullable=true)
     */
    private ?OfferKalkulationElement $element;


    /**
     * @Groups({"leistungenPaginated"})
     * @ORM\ManyToOne(targetEntity="OfferKalkulationLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKalkulationLeistungsposition $leistungsposition;

    /**
     * @ORM\Column(name="leistungsposition_id", type="integer", nullable=true)
     */
    private int $leistungspositionId;

    /**
     *
     * @ORM\Column(name="bezeichnung", type="string", nullable=false)
     */
    private $bezeichnung;

    /**
     * @ORM\Column(name="wert", type="decimal", precision=18, scale=10, nullable=true)
     */
    private $wert;

    /**
     * @ORM\Column(name="operator", type="string", nullable=false)
     */
    private $operator;

    /**
     * @ORM\Column(name="variable", type="string", nullable=true)
     */
    private $variable;

    /** @ORM\Column(name="variable_id", type="integer", nullable=true) */
    private ?int $variableId;

    /** @ORM\Column(name="kommentar", type="string", nullable=true) */
    private ?string $kommentar;

    /**
     * @ORM\Column(name="operation", type="string", nullable=true)
     */
    private $operation;

    /**
     * @ORM\Column(name="vollkosten", type="decimal",precision=38, scale=11, nullable=true)
     */
    private $vollkosten;

    /**
     * @return int
     */
    public function getBerechnungId(): int
    {
        return $this->berechnungId;
    }

    /**
     * @return int|null
     */
    public function getElementId(): ?int
    {
        return $this->elementId;
    }

    /**
     * @return int|null
     */
    public function getLeistungspositionId(): ?int
    {
        return $this->leistungspositionId;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return float|null
     */
    public function getWert(): ?float
    {
        return $this->wert;
    }

    /**
     * @return string
     */
    public function getOperator(): string
    {
        return $this->operator;
    }

    /**
     * @return string|null
     */
    public function getOperation(): ?string
    {
        return $this->operation;
    }

    /**
     * @return float|null
     */
    public function getVollkosten(): ?float
    {
        return $this->vollkosten;
    }

    /**
     * @return string|null
     */
    public function getVariable(): ?string
    {
        return $this->variable;
    }

    /**
     * @return int|null
     */
    public function getVariableId(): ?int
    {
        return $this->variableId;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }
}
