<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Automailable;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Automail_AbschlussOrbit")
 */
class v_AutomailAbschlussOrbit implements Automailable
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="string")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="vorhabenname", type="string", nullable=true)
     */
    private ?string $vorhabenname;

    /**
     * @ORM\Column(name="abgeschlossen_am", type="string", nullable=true)
     */
    private ?string $abgeschlossenAm;

    /**
     * @ORM\Column(name="an_email", type="string", nullable=true)
     */
    private ?string $anEmail;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simple_id' => $this->simpleId,
            'vorhabenname' => $this->vorhabenname,
            'abgeschlossen_am' => $this->abgeschlossenAm,
            'an_email' => $this->anEmail,
        ];
    }
}