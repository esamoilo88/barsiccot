<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * FinanceSinStatus
 *
 * @ORM\Table(name="Finance_SIN_Status")
 * @ORM\Entity
 */
class FinanceSinStatus
{

    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private int $id;

    /**
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuStatus", fetch="EAGER")
     * @ORM\JoinColumn(name="lbu_status_id", referencedColumnName="id")
     */
    private OfferFakturaLbuStatus $lbuStatus;

    /**
     * @ORM\Column(name="revenue_status_period", type="date")
     */
    private DateTime $revenueStatusPeriod;

    /**
     * @ORM\Column(name="revenue_status_timestamp", type="datetime")
     */
    private DateTime $revenueStatusTimestamp;

    /**
     * FinanceSinStatus constructor.
     * @param int $simpleId
     * @param OfferFakturaLbuStatus $lbuStatus
     * @param DateTime $revenueStatusPeriod
     * @param DateTime $revenueStatusTimestamp
     */
    public function __construct(
        int $simpleId,
        OfferFakturaLbuStatus $lbuStatus,
        DateTime $revenueStatusPeriod,
        DateTime $revenueStatusTimestamp
    )
    {
        $this->simpleId = $simpleId;
        $this->lbuStatus = $lbuStatus;
        $this->revenueStatusPeriod = $revenueStatusPeriod;
        $this->revenueStatusTimestamp = $revenueStatusTimestamp;
    }

    /**
     * @param OfferFakturaLbuStatus $lbuStatus
     */
    public function setLbuStatus(OfferFakturaLbuStatus $lbuStatus): void
    {
        $this->lbuStatus = $lbuStatus;
    }

    /**
     * @param DateTime $revenueStatusPeriod
     */
    public function setRevenueStatusPeriod(DateTime $revenueStatusPeriod): void
    {
        $this->revenueStatusPeriod = $revenueStatusPeriod;
    }

    /**
     * @param DateTime $revenueStatusTimestamp
     */
    public function setRevenueStatusTimestamp(DateTime $revenueStatusTimestamp): void
    {
        $this->revenueStatusTimestamp = $revenueStatusTimestamp;
    }

    /**
     * @return OfferFakturaLbuStatus
     */
    public function getLbuStatus(): OfferFakturaLbuStatus
    {
        return $this->lbuStatus;
    }

    /**
     * @return DateTime
     */
    public function getRevenueStatusTimestamp(): DateTime
    {
        return $this->revenueStatusTimestamp;
    }
}
