<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Illuminate\Support\Carbon;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_AllProjects")
 */
class v_AllProjects
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private int $simpleId;

    /** @ORM\Column(name="thema", length=150, type="string", nullable=true) */
    private ?string $thema;

    /** @ORM\Column(name="kundenname", length=255, type="string", nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="volumen_dtts", type="decimal", nullable=false) */
    private float $volumenDtts;

    /** @ORM\Column(name="offer_complete", type="boolean", nullable=false) */
    private bool $offerComplete;

    /** @ORM\Column(name="loss", type="boolean", nullable=false) */
    private bool $loss;

    /** @ORM\Column(name="presales", type="boolean", nullable=false) */
    private bool $presales;

    /**
     * @ORM\OneToOne(targetEntity="SalesStatus")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private SalesStatus $status;

    /** @ORM\Column(name="status_color", length=10, type="string", nullable=true) */
    private ?string $statusColor;

    /** @ORM\Column(name="status_short", length=50, type="string", nullable=false) */
    private string $statusShort;

    /** @ORM\Column(name="active", type="string", nullable=false) */
    private string $active;

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getThema(): ?string
    {
        return $this->thema;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return float
     */
    public function getVolumenDtts(): float
    {
        return $this->volumenDtts;
    }

    /**
     * @return bool
     */
    public function isOfferComplete(): bool
    {
        return $this->offerComplete;
    }

    /**
     * @return bool
     */
    public function isLoss(): bool
    {
        return $this->loss;
    }

    /**
     * @return bool
     */
    public function isPresales(): bool
    {
        return $this->presales;
    }

    /**
     * @return SalesStatus
     */
    public function getStatus(): SalesStatus
    {
        return $this->status;
    }

    /**
     * @return string|null
     */
    public function getStatusColor(): ?string
    {
        return $this->statusColor;
    }

    /**
     * @return string
     */
    public function getStatusShort(): string
    {
        return $this->statusShort;
    }

    /**
     * @return string
     */
    public function getActive(): string
    {
        return $this->active;
    }
}
