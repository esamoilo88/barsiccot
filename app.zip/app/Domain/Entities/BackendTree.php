<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * BackendTree
 *
 * @ORM\Table(name="Backend_Tree")
 * @ORM\Entity
 */
class BackendTree
{
    /**
     * @ORM\Column(name="tree_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $treeId;

    /** @ORM\Column(name="sort", type="integer", nullable=true) */
    private ?int $sort;

    /** @ORM\Column(name="bezeichnung", type="string", length=75, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="controller", type="string", length=75, nullable=true) */
    private ?string $controller;

    /** @ORM\Column(name="action", type="string", length=75, nullable=true) */
    private ?string $action;

    /** @ORM\Column(name="hide", type="boolean", nullable=true) */
    private ?bool $hide;

    /** @ORM\Column(name="necessary_roles", type="string", length=150, nullable=true) */
    private ?string $necessaryRoles;

    /** @ORM\Column(name="check_roles", type="boolean", nullable=true) */
    private ?bool $checkRoles;

    /** @ORM\Column(name="tree_group", type="string", length=50, nullable=true) */
    private ?string $treeGroup;

    /** @ORM\Column(name="path", type="string", length=64, nullable=true) */
    private ?string $path;

    /** @ORM\Column(name="in_nav", type="boolean", nullable=false, options={"default"="0"}) */
    private bool $inNav = false;

    /** @ORM\Column(name="icon", type="string", length=64, nullable=true) */
    private ?string $icon;

    /**
     * @ORM\ManyToOne(targetEntity="BackendAnwendung")
     * @ORM\JoinColumn(name="anwendungs_id", referencedColumnName="anwendungs_id")
     */
    private ?BackendAnwendung $backendAnwendung;

    /**
     * @ORM\ManyToMany(targetEntity="BackendRechte")
     * @ORM\JoinTable(name="Backend_RechteTree",
     *     joinColumns={@ORM\JoinColumn(name="tree_id", referencedColumnName="tree_id")},
     *     inverseJoinColumns={@ORM\JoinColumn(name="rechte_id", referencedColumnName="rechte_id")}
     * )
     */
    private Collection $backendRechtes;

    /**
     * BackendTree constructor.
     * @param BackendAnwendung|null $backendAnwendung
     */
    public function __construct(
        BackendAnwendung $backendAnwendung = null
    )
    {
        $this->backendAnwendung = $backendAnwendung;
    }

    /**
     * @return string|null
     */
    public function getNecessaryRoles(): ?string
    {
        return $this->necessaryRoles;
    }

    /**
     * @param string|null $necessaryRoles
     */
    public function setNecessaryRoles(?string $necessaryRoles): void
    {
        $this->necessaryRoles = $necessaryRoles;
    }

    /**
     * @return bool|null
     */
    public function isCheckRoles(): ?bool
    {
        return $this->checkRoles;
    }

    /**
     * @param bool|null $checkRoles
     */
    public function setCheckRoles(?bool $checkRoles): void
    {
        $this->checkRoles = $checkRoles;
    }

    /**
     * @return bool|null
     */
    public function isHide(): ?bool
    {
        return $this->hide;
    }

    /**
     * @param bool|null $hide
     */
    public function setHide(?bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return string|null
     */
    public function getController(): ?string
    {
        return $this->controller;
    }

    /**
     * @param string|null $controller
     */
    public function setController(?string $controller): void
    {
        $this->controller = $controller;
    }

    /**
     * @return string|null
     */
    public function getAction(): ?string
    {
        return $this->action;
    }

    /**
     * @param string|null $action
     */
    public function setAction(?string $action): void
    {
        $this->action = $action;
    }

    /**
     * @return int
     */
    public function getTreeId(): int
    {
        return $this->treeId;
    }

    /**
     * @param int $treeId
     */
    public function setTreeId(int $treeId): void
    {
        $this->treeId = $treeId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return BackendAnwendung|null
     */
    public function getBackendAnwendung(): ?BackendAnwendung
    {
        return $this->backendAnwendung;
    }

    /**
     * @param BackendAnwendung|null $backendAnwendung
     */
    public function setBackendAnwendung(?BackendAnwendung $backendAnwendung): void
    {
        $this->backendAnwendung = $backendAnwendung;
    }

    /**
     * @return string|null
     */
    public function getTreeGroup(): ?string
    {
        return $this->treeGroup;
    }

    /**
     * @param string|null $treeGroup
     */
    public function setTreeGroup(?string $treeGroup): void
    {
        $this->treeGroup = $treeGroup;
    }

    /**
     * @return string|null
     */
    public function getPath(): ?string
    {
        return $this->path;
    }

    /**
     * @param string|null $path
     */
    public function setPath(?string $path): void
    {
        $this->path = $path;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return Collection
     */
    public function getBackendRechtes(): Collection
    {
        return $this->backendRechtes;
    }

    /**
     * @param Collection $backendRechtes
     */
    public function setBackendRechtes(Collection $backendRechtes): void
    {
        $this->backendRechtes = $backendRechtes;
    }

    /**
     * @return bool
     */
    public function isInNav(): bool
    {
        return $this->inNav;
    }

    /**
     * @param bool $inNav
     */
    public function setInNav(bool $inNav): void
    {
        $this->inNav = $inNav;
    }

    /**
     * @return bool
     */
    public function hasBackendAnwendung(): bool
    {
        return $this->backendAnwendung !== null;
    }

    /**
     * @return bool
     */
    public function hasTreeGroup(): bool
    {
        return $this->treeGroup !== null;
    }

    /**
     * @return string|null
     */
    public function getIcon(): ?string
    {
        return $this->icon;
    }

    /**
     * @param string|null $icon
     */
    public function setIcon(?string $icon): void
    {
        $this->icon = $icon;
    }
}
