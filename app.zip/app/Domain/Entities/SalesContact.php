<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesContact
 *
 * @ORM\Table(name="Sales_Contact")
 * @ORM\Entity
 */
class SalesContact
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="SalesContactRole")
     * @ORM\JoinColumn(name="role_id", referencedColumnName="id")
     */
    private SalesContactRole $role;

    /**
     * @var string
     *
     * @ORM\Column(name="first_name", type="string")
     */
    private string $firstName;

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string")
     */
    private string $lastName;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string")
     */
    private string $email;

    /**
     * @var string
     *
     * @ORM\Column(name="department", type="string")
     */
    private string $department;

    /**
     * @var DateTime
     *
     * @ORM\Column(name="created", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $created;

    /**
     * @var DateTime
     *
     * @ORM\Column(name="modified", type="datetime")
     * @Gedmo\Timestampable(on="update")
     */
    private DateTime $modified;

    /**
     * @var DateTime
     *
     * @ORM\Column(name="bits", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $bits;

    /**
     * SalesContact constructor.
     * @param SalesStammdaten $simple
     * @param SalesContactRole $role
     * @param string $firstName
     * @param string $lastName
     * @param string $email
     * @param string $department
     */
    public function __construct(
        SalesStammdaten $simple,
        SalesContactRole $role,
        string $firstName,
        string $lastName,
        string $email,
        string $department
    )
    {
        $this->simple = $simple;
        $this->role = $role;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->department = $department;
    }

    /**
     * @param SalesContactRole $role
     */
    public function setRole(SalesContactRole $role): void
    {
        $this->role = $role;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return DateTime
     */
    public function getBits(): DateTime
    {
        return $this->bits;
    }

    /**
     * @return string
     */
    public function getDepartment(): string
    {
        return $this->department;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return string
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @return SalesContactRole
     */
    public function getRole(): SalesContactRole
    {
        return $this->role;
    }
}
