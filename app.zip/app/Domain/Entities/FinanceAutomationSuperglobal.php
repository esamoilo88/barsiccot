<?php


namespace App\Domain\Entities;


use App\Domain\ValueObjects\SIN;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;


/**
 * FinanceAutomationSuperglobal
 *
 * @ORM\Table(name="Finance_Automation_Superglobal")
 * @ORM\Entity
 */
class FinanceAutomationSuperglobal
{
    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="plan_ilv", type="boolean")
     */
    private bool $planIlv;

    /**
     * @ORM\Column(name="auto_ilv", type="boolean")
     */
    private bool $autoIlv;

    /**
     * @ORM\Column(name="auto_forecast", type="boolean")
     */
    private bool $autoForecast;

    /**
     * @ORM\Column(name="auto_abgrenzung", type="boolean")
     */
    private bool $autoAbgrenzung;

    /**
     * @ORM\Column(name="auto_approve", type="boolean")
     */
    private bool $autoApprove = false;

    /**
     * @ORM\Column(name="auto_bill", type="boolean", nullable=true)
     */
    private ?bool $autoBill = null;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * FinanceAutomationSuperglobal constructor.
     * @param SIN $sin
     * @param bool $autoIlv
     * @param bool $planIlv
     */
    public function __construct(SIN $sin, bool $autoIlv, bool $planIlv)
    {
        $this->simpleId = $sin->value();
        $this->autoIlv = $autoIlv;
        $this->planIlv = $planIlv;
        $this->autoForecast = false;
        $this->autoAbgrenzung = false;
        $this->autoApprove = false;
    }


    /**
     * @return bool
     */
    public function isAutoApprove(): bool
    {
        return $this->autoApprove;
    }

    /**
     * @param SIN $sin
     */
    public function setSIN(SIN $sin): void
    {
        $this->simpleId = $sin->value();
    }

    /**
     * @param bool $planIlv
     */
    public function setPlanIlv(bool $planIlv): void
    {
        $this->planIlv = $planIlv;
    }

    /**
     * @param bool $autoIlv
     */
    public function setAutoIlv(bool $autoIlv): void
    {
        $this->autoIlv = $autoIlv;
    }

    /**
     * @param bool $autoAbgrenzung
     */
    public function setAutoAbgrenzung(bool $autoAbgrenzung): void
    {
        $this->autoAbgrenzung = $autoAbgrenzung;
    }

    /**
     * @param bool $autoForecast
     */
    public function setAutoForecast(bool $autoForecast): void
    {
        $this->autoForecast = $autoForecast;
    }

    /**
     * @param bool $autoApprove
     */
    public function setAutoApprove(bool $autoApprove): void
    {
        $this->autoApprove = $autoApprove;
    }

    /**
     * @return bool
     */
    public function isPlanIlv(): bool
    {
        return $this->planIlv;
    }

    /**
     * @return bool
     */
    public function isAutoIlv(): bool
    {
        return $this->autoIlv;
    }

    /**
     * @return bool|null
     */
    public function isAutoBill(): ?bool
    {
        return $this->autoBill;
    }

    /**
     * @param bool|null $autoBill
     */
    public function setAutoBill(?bool $autoBill): void
    {
        $this->autoBill = $autoBill;
    }
}
