<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\Mapping as ORM;

/**
 * SalesVersionierung
 *
 * @ORM\Table(name="Sales_Versionierung")
 * @ORM\Entity
 */
class SalesVersionierung
{
    /**
     * @var int
     *
     * @ORM\Column(name="vk_versions_id", type="integer")
     */
    private int $vkVersionsId;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk", fetch="EAGER")
     * @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     */
    private ?OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="SalesAnfrage", fetch="EAGER")
     * @ORM\JoinColumn(name="af_versions_id", referencedColumnName="af_versions_id")
     */
    private ?SalesAnfrage $afVersions;

    /**
     * @ORM\ManyToOne(targetEntity="SalesAngebotTp")
     * @ORM\JoinColumn(name="tp_versions_id", referencedColumnName="tp_versions_id")
     */
    private ?SalesAngebotTp $tpVersions;

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\OneToOne(targetEntity="SalesStammdaten", fetch="EAGER")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\OneToOne(targetEntity="OfferAuftrag", mappedBy="salesVersionierung")
     */
    private ?OfferAuftrag $offerAuftrag = null;

    public function __construct(SalesStammdaten $simple, SalesAnfrage $salesAnfrage)
    {
        $this->simple = $simple;
        $this->afVersions = $salesAnfrage;
        $this->simpleId = $simple->getSimpleId();
    }

    /**
     * @param SalesAnfrage|null $afVersions
     */
    public function setAfVersions(?SalesAnfrage $afVersions): void
    {
        $this->afVersions = $afVersions;
    }

    /**
     * @param OfferAngebotVk|null $vkVersions
     */
    public function setVkVersions(?OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @param SalesAngebotTp|null $tpVersions
     */
    public function setTpVersions(?SalesAngebotTp $tpVersions): void
    {
        $this->tpVersions = $tpVersions;
    }

    /**
     * @return OfferAngebotVk|null
     */
    public function getVkVersions(): ?OfferAngebotVk
    {
        return $this->vkVersions;
    }

    public function resetVersions(): void
    {
        $this->afVersions = null;
        $this->vkVersions = null;
        $this->tpVersions = null;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return SIN
     * @throws \App\Exceptions\Business\InvalidSinException
     */
    public function getSin(): SIN
    {
        return new SIN($this->simpleId);
    }

    /**
     * @return SalesAngebotTp|null
     */
    public function getTpVersions(): ?SalesAngebotTp
    {
        return $this->tpVersions;
    }

    /**
     * @return int
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @return bool
     */
    public function hasVkVersions(): bool
    {
        return $this->vkVersions !== null;
    }

    /**
     * @return SalesAnfrage|null
     */
    public function getAfVersions(): ?SalesAnfrage
    {
        return $this->afVersions;
    }

    /**
     * @return OfferAuftrag|null
     */
    public function getOfferAuftrag(): ?OfferAuftrag
    {
        return $this->offerAuftrag;
    }
}
