<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class OnkaSequenceCostrate
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Sequence_Costrate")
 */
class OnkaSequenceCostrate
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaSequence")
     * @ORM\JoinColumn(name="sequence_id", referencedColumnName="id")
     */
    private OnkaSequence $sequence;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $costrate;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * OnkaSequenceCostrate constructor.
     * @param OnkaSequence $sequence
     * @param CostsKostenart $costrate
     */
    public function __construct(OnkaSequence $sequence, CostsKostenart $costrate)
    {
        $this->sequence = $sequence;
        $this->costrate = $costrate;
    }

    /**
     * @return OnkaSequence
     */
    public function getSequence(): OnkaSequence
    {
        return $this->sequence;
    }

    /**
     * @return CostsKostenart
     */
    public function getCostrate(): CostsKostenart
    {
        return $this->costrate;
    }
}
