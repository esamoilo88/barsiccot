<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Table(name="Backend_Widgets")
 * @ORM\Entity
 */
class BackendWidgets
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", length=50) */
    private string $name;

    /** @ORM\Column(name="description", type="string", length=150) */
    private string $description = '';

    /** @ORM\Column(name="size", type="string", length=10) */
    private string $size = 'small';

    /** @ORM\Column(name="hide", type="boolean") */
    private bool $hide = false;

    /** @ORM\Column(name="image", type="string", length=128, nullable=true) */
    private ?string $image;

    /** @ORM\Column(name="sys_name", type="string", length=64) */
    private string $sysName;

    /**
     * Data for displaying on frontend
     * @var array
     */
    private array $data = [];

    /**
     * BackendWidgets constructor.
     * @param string $name
     * @param string $description
     * @param string $size
     * @param string $sysName
     */
    public function __construct(string $name, string $description, string $size, string $sysName)
    {
        $this->name = $name;
        $this->description = $description;
        $this->size = $size;
        $this->sysName = $sysName;
    }

    /**
     * @Groups({"userProfile"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getSize(): string
    {
        return $this->size;
    }

    /**
     * @param string $size
     */
    public function setSize(string $size): void
    {
        $this->size = $size;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @Groups({"userProfile"})
     * @return string|null
     */
    public function getImage(): ?string
    {
        return $this->image;
    }

    /**
     * @param string|null $image
     */
    public function setImage(?string $image): void
    {
        $this->image = $image;
    }

    /**
     * @Groups({"userProfile"})
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @param string $sysName
     */
    public function setSysName(string $sysName): void
    {
        $this->sysName = $sysName;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * @param array $data
     */
    public function setData(array $data): void
    {
        $this->data = $data;
    }
}
