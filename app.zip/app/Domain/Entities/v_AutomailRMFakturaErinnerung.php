<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Automailable;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Automail_RMFakturaErinnerung")
 */
class v_AutomailRMFakturaErinnerung implements Automailable
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="string")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="thema", type="string", nullable=true)
     */
    private ?string $thema;

    /**
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private ?string $kundenname;

    /**
     * @ORM\Column(name="av_email", type="string", nullable=true)
     */
    private ?string $avEmail;

    /**
     * @ORM\Column(name="av_anrede", type="string", nullable=true)
     */
    private ?string $avAnrede;

    /**
     * @ORM\Column(name="av_nachname", type="string", nullable=true)
     */
    private ?string $avNachname;

    /**
     * @ORM\Column(name="bestellung_abgeschlossen", type="string", nullable=true)
     */
    private ?string $bestellungAbgeschlossen;

    /**
     * @ORM\Column(name="status", type="string", nullable=true)
     */
    private ?string $status;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simple_id' => $this->simpleId,
            'thema' => $this->thema,
            'kundenname' => $this->kundenname,
            'av_email' => $this->avEmail,
            'av_nachname' => $this->avNachname,
            'av_anrede' => $this->avAnrede,
            'status' => $this->status,
            'bestellung_abgeschlossen' => $this->bestellungAbgeschlossen
        ];
    }
}
