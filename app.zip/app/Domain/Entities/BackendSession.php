<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendSession
 *
 * @ORM\Table(name="Backend_Session")
 * @ORM\Entity
 */
class BackendSession
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=255, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="data", type="text", length=16, nullable=true)
     */
    private $data;

    /**
     * @var int|null
     *
     * @ORM\Column(name="expires", type="integer", nullable=true)
     */
    private $expires;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;


}
