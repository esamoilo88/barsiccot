<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CrmKunde
 *
 * @ORM\Table(name="CRM_Contacts")
 * @ORM\Entity
 */
class CrmContacts
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /**
     * @ORM\Column(type="string")
     */
    private string $firstName;

    /**
     * @ORM\Column(type="string")
     */
    private string $lastName;

    /**
     * @ORM\Column(type="string")
     */
    private string $company;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    private ?string $department;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    private ?string $email;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    private ?string $telNr;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $bits;

    /**
     * @ORM\OneToOne(targetEntity="CrmCustomer")
     * @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
     */
    private CrmCustomer $customer;

    /**
     * @ORM\OneToOne(targetEntity="CrmRole")
     * @ORM\JoinColumn(name="role_id", referencedColumnName="id")
     */
    private CrmRole $role;

    /**
     * @return int
     * @Groups({"basic"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Groups({"basic"})
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @return string
     * @Groups({"basic"})
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @return string
     * @Groups({"basic"})
     */
    public function getCompany(): string
    {
        return $this->company;
    }

    /**
     * @return string|null
     * @Groups({"basic"})
     */
    public function getDepartment(): ?string
    {
        return $this->department;
    }

    /**
     * @return string|null
     * @Groups({"basic"})
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @return string|null
     * @Groups({"basic"})
     */
    public function getTelNr(): ?string
    {
        return $this->telNr;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return DateTime
     */
    public function getBits(): DateTime
    {
        return $this->bits;
    }

    /**
     * @return CrmCustomer
     */
    public function getCustomer(): CrmCustomer
    {
        return $this->customer;
    }

    /**
     * @return CrmRole
     * @Groups({"basic"})
     */
    public function getRole(): CrmRole
    {
        return $this->role;
    }

    /**
     * @param string $firstName
     */
    public function setFirstName(string $firstName): void
    {
        $this->firstName = $firstName;
    }

    /**
     * @param string $lastName
     */
    public function setLastName(string $lastName): void
    {
        $this->lastName = $lastName;
    }

    /**
     * @param string $company
     */
    public function setCompany(string $company): void
    {
        $this->company = $company;
    }

    /**
     * @param string|null $department
     */
    public function setDepartment(?string $department): void
    {
        $this->department = $department;
    }

    /**
     * @param string|null $email
     */
    public function setEmail(?string $email): void
    {
        $this->email = $email;
    }

    /**
     * @param string|null $telNr
     */
    public function setTelNr(?string $telNr): void
    {
        $this->telNr = $telNr;
    }

    /**
     * @param CrmCustomer $customer
     */
    public function setCustomer(CrmCustomer $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @param CrmRole $role
     */
    public function setRole(CrmRole $role): void
    {
        $this->role = $role;
    }
}
