<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CrmKunde
 *
 * @ORM\Table(name="CRM_Role")
 * @ORM\Entity
 */
class CrmRole
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /**
     * @ORM\Column(type="string")
     */
    private string $name;

    /**
     * @ORM\Column(type="string")
     */
    private string $sysName;

    /**
     * @ORM\Column(type="integer")
     */
    private string $sort;

    /**
     * @ORM\Column(type="boolean")
     */
    private string $hide;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $bits;

    /**
     * @return int
     * @Groups({"basic"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Groups({"basic"})
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @return string
     */
    public function getSort(): string
    {
        return $this->sort;
    }

    /**
     * @return string
     */
    public function getHide(): string
    {
        return $this->hide;
    }

    /**
     * @return DateTime
     */
    public function getBits(): DateTime
    {
        return $this->bits;
    }

}
