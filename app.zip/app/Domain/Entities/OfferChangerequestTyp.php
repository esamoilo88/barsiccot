<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferChangerequestTyp
 *
 * @ORM\Table(name="Offer_ChangeRequest_Typ")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferChangerequestTyp
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="`external`", type="boolean", nullable=true) */
    private ?bool $external = null;

    /** @ORM\Column(name="hide", type="boolean") */
    private bool $hide = false;

    /** @ORM\Column(name="runtime", type="boolean", nullable=true) */
    private ?bool $runtime;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * @return int
     * @Groups({"crList"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"crList"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @Groups({"crList"})
     * @return bool|null
     */
    public function getExternal(): ?bool
    {
        return $this->external;
    }

    /**
     * @param bool|null $external
     */
    public function setExternal(?bool $external): void
    {
        $this->external = $external;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool|null
     */
    public function getRuntime(): ?bool
    {
        return $this->runtime;
    }

    /**
     * @param bool|null $runtime
     */
    public function setRuntime(?bool $runtime): void
    {
        $this->runtime = $runtime;
    }
}
