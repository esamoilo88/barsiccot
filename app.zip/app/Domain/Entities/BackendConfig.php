<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendConfig
 *
 * @ORM\Table(name="Backend_Config")
 * @ORM\Entity
 */
class BackendConfig
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", length=128, nullable=false) */
    private string $name;

    /** @ORM\Column(name="value_dev", type="text", nullable=false, options={"default"=""}) */
    private string $valueDev = "";

    /** @ORM\Column(name="value_prod", type="text", nullable=false, options={"default"=""}) */
    private string $valueProd = "";

    /** @ORM\Column(name="is_json", type="boolean", nullable=false, options={"default"="0"}) */
    private bool $isJson = false;

    /** @ORM\Column(name="conf_group", type="string", length=32, nullable=false, options={"default"=""}) */
    private string $confGroup = "";

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getValueDev(): string
    {
        return $this->valueDev;
    }

    /**
     * @param string $valueDev
     */
    public function setValueDev(string $valueDev): void
    {
        $this->valueDev = $valueDev;
    }

    /**
     * @return string
     */
    public function getValueProd(): string
    {
        return $this->valueProd;
    }

    /**
     * @param string $valueProd
     */
    public function setValueProd(string $valueProd): void
    {
        $this->valueProd = $valueProd;
    }

    /**
     * @return string|null
     */
    public function getIsJson(): ?string
    {
        return $this->isJson;
    }

    /**
     * @param bool $isJson
     */
    public function setIsJson(bool $isJson): void
    {
        $this->isJson = $isJson;
    }

    /**
     * @return string
     */
    public function getConfGroup(): string
    {
        return $this->confGroup;
    }

    /**
     * @param string $confGroup
     */
    public function setConfGroup(string $confGroup): void
    {
        $this->confGroup = $confGroup;
    }
}
