<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmAnfragenachbesserung
 *
 * @ORM\Table(name="RM_AnfrageNachbesserung")
 * @ORM\Entity
 */
class RmAnfragenachbesserung
{
    /**
     * @var int
     *
     * @ORM\Column(name="anfrageNachbesserung_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $anfragenachbesserungId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \RmAnfrage
     *
     * @ORM\ManyToOne(targetEntity="RmAnfrage")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="anfrage_simple_id", referencedColumnName="simple_id")
     * })
     */
    private $anfrageSimple;

    /**
     * @var \RmNachbesserung
     *
     * @ORM\ManyToOne(targetEntity="RmNachbesserung")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nachbesserungs_id", referencedColumnName="nachbesserungs_id")
     * })
     */
    private $nachbesserungs;


}
