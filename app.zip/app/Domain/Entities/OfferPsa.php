<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferPsa
 *
 * @ORM\Table(name="Offer_PSA")
 * @ORM\Entity
 */
class OfferPsa
{
    /**
     * @var int
     *
     * @ORM\Column(name="psa_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $psaId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferPsaAntworten
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaAntworten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="antwort_id", referencedColumnName="antwort_id")
     * })
     */
    private $antwort;

    /**
     * @var \OfferPsaFragen
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaFragen")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="frage_id", referencedColumnName="frage_id")
     * })
     */
    private $frage;


}
