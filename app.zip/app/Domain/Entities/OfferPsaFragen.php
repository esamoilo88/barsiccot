<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferPsaFragen
 *
 * @ORM\Table(name="Offer_PSA_Fragen")
 * @ORM\Entity
 */
class OfferPsaFragen
{
    /**
     * @var int
     *
     * @ORM\Column(name="frage_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $frageId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="frage", type="string", length=1000, nullable=true)
     */
    private $frage;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferPsaGruppen
     *
     * @ORM\ManyToOne(targetEntity="OfferPsaGruppen")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gruppen_id", referencedColumnName="psa_gruppen_id")
     * })
     */
    private $gruppen;


}
