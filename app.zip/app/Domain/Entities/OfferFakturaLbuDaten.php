<?php

namespace App\Domain\Entities;

use App\Exceptions\Business\ValidationException;
use App\Utils\SimpleValidator\SimpleValidator;
use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Illuminate\Contracts\Container\BindingResolutionException;


/**
 * OfferFakturaLbuDaten
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Daten")
 * @ORM\Entity
 */
class OfferFakturaLbuDaten
{
    /**
     * @ORM\Column(name="lbu_daten_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $lbuDatenId;

    /**
     * @ORM\Column(name="angebotsposition", type="string", length=255, nullable=true)
     */
    private ?string $angebotspositionName;

    /**
     * @ORM\Column(name="leistungsort", type="string", length=255, nullable=true)
     */
    private ?string $leistungsort;

    /**
     * @ORM\Column(name="leistungszeitpunkt", type="date", nullable=false)
     */
    private DateTime $leistungszeitpunkt;

    /**
     * @ORM\Column(name="leistungszeitraum_von", type="date", nullable=false)
     */
    private DateTime $leistungszeitraumVon;

    /**
     * @ORM\Column(name="leistungszeitraum_bis", type="date", nullable=false)
     */
    private DateTime $leistungszeitraumBis;

    /**
     * @ORM\Column(name="menge", type="decimal", precision=24, scale=12, nullable=true)
     */
    private ?float $menge;

    /**
     * @ORM\Column(name="einzelpreis_dtts", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $einzelpreisDtts;

    /**
     * @ORM\Column(name="einzelpreis_dtag", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $einzelpreisDtag;

    /**
     * @ORM\Column(name="transferpreis_dtts", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $transferpreisDtts;

    /**
     * @ORM\Column(name="transferpreis_dtag", type="decimal", precision=18, scale=2, nullable=false)
     */
    private float $transferpreisDtag;

    /**
     * @ORM\Column(name="einzelpreis_dtts_original", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $einzelpreisDttsOriginal;

    /**
     * @ORM\Column(name="einzelpreis_dtag_original", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $einzelpreisDtagOriginal;

    /**
     * @ORM\Column(name="transferpreis_dtts_original", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $transferpreisDttsOriginal;

    /**
     * @ORM\Column(name="transferpreis_dtag_original", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $transferpreisDtagOriginal;

    /**
     * @ORM\Column(name="preisnachlass", type="decimal", precision=18, scale=7, nullable=true)
     */
    private ?float $preisnachlass;

    /**
     * @ORM\Column(name="installationsbemerkung", type="text", length=-1, nullable=true)
     */
    private ?string $installationsbemerkung;

    /**
     * @ORM\Column(name="sap_bestellnummer", type="string", length=150, nullable=true)
     */
    private ?string $sapBestellnummer;

    /**
     * @ORM\Column(name="vorgangs_ticket_nr", type="string", length=50, nullable=true)
     */
    private ?string $vorgangsTicketNr;

    /**
     * @ORM\Column(name="kommentar", type="text", length=-1, nullable=true)
     */
    private ?string $kommentar;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="mat_nr", type="integer", nullable=true)
     */
    private ?int $matNr;

    /**
     * @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true)
     */
    private ?string $icpKontPspKst;

    /**
     * @ORM\Column(name="icp_kont_bpos", type="integer", nullable=true)
     */
    private ?int $icpKontBpos;

    /**
     * @ORM\Column(name="psp_element", type="string", length=50, nullable=true)
     */
    private ?string $pspElement;

    /**
     * @ORM\ManyToOne(targetEntity="ExtEbiDaten")
     * @ORM\JoinColumn(name="ebi_id", referencedColumnName="ebi_id")
     */
    private ?ExtEbiDaten $ebi;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbu")
     * @ORM\JoinColumn(name="lbu_id", referencedColumnName="lbu_id")
     */
    private OfferFakturaLbu $lbu;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenMengentyp")
     * @ORM\JoinColumn(name="mengentyp_id", referencedColumnName="mengentyp_id")
     */
    private ?OfferFakturaLbuDatenMengentyp $mengentyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenPreistyp")
     * @ORM\JoinColumn(name="preistyp_id", referencedColumnName="preistyp_id")
     */
    private ?OfferFakturaLbuDatenPreistyp $preistyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenQuellsystem")
     * @ORM\JoinColumn(name="quellsystem_id", referencedColumnName="quellsystem_id")
     */
    private ?OfferFakturaLbuDatenQuellsystem $quellsystem;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenSachkonto")
     * @ORM\JoinColumn(name="icp_kont_konto_id", referencedColumnName="konto_id")
     */
    private ?OfferFakturaLbuDatenSachkonto $icpKontKonto;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="angebotsposition_id")
     */
    private ?OfferKalkulationAngebotsposition $angebotsposition;

    /**
     * @ORM\ManyToOne(targetEntity="OfferNiederlassung")
     * @ORM\JoinColumn(name="nl_id", referencedColumnName="nl_id")
     */
    private ?OfferNiederlassung $nl;

    /**
     * @ORM\Column(name="position_name", type="string", length=100, nullable=true)
     */
    private ?string $positionName = null;

    /**
     * @ORM\Column(name="location_name", type="string", length=100, nullable=true)
     */
    private ?string $locationName = null;

    /**
     * @ORM\Column(name="order_purchase_key", type="string", length=100, nullable=true)
     */
    private ?string $orderPurchaseKey = null;

    /**
     * OfferFakturaLbuDaten constructor.
     * @param OfferFakturaLbu $lbu
     * @param OfferAuftrag $simple
     * @param OfferFakturaLbuDatenMengentyp $mengentyp
     * @param OfferFakturaLbuDatenPreistyp $preistyp
     * @param string $apName
     * @param OfferKalkulationAngebotsposition|null $angebotsposition
     * @param float $menge
     * @param float $einzelpreisDtts
     * @param float $transferpreisDtts
     * @param float $einzelpreisDtag
     * @param float $transferpreisDtag
     * @param float $einzelpreisDttsOriginal
     * @param float $einzelpreisDtagOriginal
     * @param float $transferpreisDttsOriginal
     * @param float $transferpreisDtagOriginal
     * @param string $leistungsort
     * @param int|null $icpKontBpos
     * @param string $pspElement
     * @param int $matNr
     * @param DateTime $leistungszeitpunkt
     * @param DateTime $leistungszeitraumVon
     * @param DateTime $leistungszeitraumBis
     * @param string|null $installationsbemerkung
     * @param string|null $positionName
     * @param string|null $locationName
     * @param string|null $orderPurchaseKey
     */
    public function __construct(
        OfferFakturaLbu $lbu,
        OfferAuftrag $simple,
        OfferFakturaLbuDatenMengentyp $mengentyp,
        OfferFakturaLbuDatenPreistyp $preistyp,
        string $apName,
        ?OfferKalkulationAngebotsposition $angebotsposition,
        float $menge,
        float $einzelpreisDtts,
        float $transferpreisDtts,
        float $einzelpreisDtag,
        float $transferpreisDtag,
        float $einzelpreisDttsOriginal,
        float $einzelpreisDtagOriginal,
        float $transferpreisDttsOriginal,
        float $transferpreisDtagOriginal,
        string $leistungsort,
        ?int $icpKontBpos,
        string $pspElement,
        ?int $matNr,
        DateTime $leistungszeitpunkt,
        DateTime $leistungszeitraumVon,
        DateTime $leistungszeitraumBis,
        ?string $installationsbemerkung,
        ?string $positionName = null,
        ?string $locationName = null,
        ?string $orderPurchaseKey = null
    )
    {
        $this->lbu = $lbu;
        $this->simple = $simple;
        $this->matNr = $matNr;
        $this->mengentyp = $mengentyp;
        $this->preistyp = $preistyp;
        $this->angebotspositionName = $apName;
        $this->angebotsposition = $angebotsposition;
        $this->menge = $menge;
        $this->einzelpreisDtts = $einzelpreisDtts;
        $this->transferpreisDtts = $transferpreisDtts;
        $this->einzelpreisDtag = $einzelpreisDtag;
        $this->transferpreisDtag = $transferpreisDtag;
        $this->einzelpreisDttsOriginal = $einzelpreisDttsOriginal;
        $this->einzelpreisDtagOriginal = $einzelpreisDtagOriginal;
        $this->transferpreisDttsOriginal = $transferpreisDttsOriginal;
        $this->transferpreisDtagOriginal = $transferpreisDtagOriginal;
        $this->leistungsort = $leistungsort;
        $this->icpKontBpos = $icpKontBpos;
        $this->pspElement = $pspElement;
        $this->leistungszeitpunkt = $leistungszeitpunkt;
        $this->leistungszeitraumVon = $leistungszeitraumVon;
        $this->leistungszeitraumBis = $leistungszeitraumBis;
        $this->installationsbemerkung = $installationsbemerkung;
        $this->positionName = $positionName;
        $this->locationName = $locationName;
        $this->orderPurchaseKey = $orderPurchaseKey;
    }

    /**
     * @return int
     */
    public function getLbuDatenId(): int
    {
        return $this->lbuDatenId;
    }

    /**
     * @return string|null
     */
    public function getAngebotspositionName(): ?string
    {
        return $this->angebotspositionName;
    }

    /**
     * @param string|null $angebotspositionName
     */
    public function setAngebotspositionName(?string $angebotspositionName): void
    {
        $this->angebotspositionName = $angebotspositionName;
    }

    /**
     * @return string|null
     */
    public function getLeistungsort(): ?string
    {
        return $this->leistungsort;
    }

    /**
     * @param string|null $leistungsort
     */
    public function setLeistungsort(?string $leistungsort): void
    {
        $this->leistungsort = $leistungsort;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitpunkt(): DateTime
    {
        return $this->leistungszeitpunkt;
    }

    /**
     * @param DateTime $leistungszeitpunkt
     */
    public function setLeistungszeitpunkt(DateTime $leistungszeitpunkt): void
    {
        $this->leistungszeitpunkt = $leistungszeitpunkt;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitraumVon(): DateTime
    {
        return $this->leistungszeitraumVon;
    }

    /**
     * @param DateTime $leistungszeitraumVon
     */
    public function setLeistungszeitraumVon(DateTime $leistungszeitraumVon): void
    {
        $this->leistungszeitraumVon = $leistungszeitraumVon;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitraumBis(): DateTime
    {
        return $this->leistungszeitraumBis;
    }

    /**
     * @param DateTime $leistungszeitraumBis
     */
    public function setLeistungszeitraumBis(DateTime $leistungszeitraumBis): void
    {
        $this->leistungszeitraumBis = $leistungszeitraumBis;
    }

    /**
     * @return float|null
     */
    public function getMenge(): ?float
    {
        return $this->menge;
    }

    /**
     * @param float|null $menge
     */
    public function setMenge(?float $menge): void
    {
        $this->menge = $menge;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDtts(): float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @param float $einzelpreisDtts
     */
    public function setEinzelpreisDtts(float $einzelpreisDtts): void
    {
        $this->einzelpreisDtts = $einzelpreisDtts;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDtag(): float
    {
        return $this->einzelpreisDtag;
    }

    /**
     * @param float $einzelpreisDtag
     */
    public function setEinzelpreisDtag(float $einzelpreisDtag): void
    {
        $this->einzelpreisDtag = $einzelpreisDtag;
    }

    /**
     * @return float
     */
    public function getTransferpreisDtts(): float
    {
        return $this->transferpreisDtts;
    }

    /**
     * @param float $transferpreisDtts
     */
    public function setTransferpreisDtts(float $transferpreisDtts): void
    {
        $this->transferpreisDtts = $transferpreisDtts;
    }

    /**
     * @return float
     */
    public function getTransferpreisDtag(): float
    {
        return $this->transferpreisDtag;
    }

    /**
     * @param float $transferpreisDtag
     */
    public function setTransferpreisDtag(float $transferpreisDtag): void
    {
        $this->transferpreisDtag = $transferpreisDtag;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDttsOriginal(): ?float
    {
        return $this->einzelpreisDttsOriginal;
    }

    /**
     * @param float|null $einzelpreisDttsOriginal
     */
    public function setEinzelpreisDttsOriginal(?float $einzelpreisDttsOriginal): void
    {
        $this->einzelpreisDttsOriginal = $einzelpreisDttsOriginal;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtagOriginal(): ?float
    {
        return $this->einzelpreisDtagOriginal;
    }

    /**
     * @param float|null $einzelpreisDtagOriginal
     */
    public function setEinzelpreisDtagOriginal(?float $einzelpreisDtagOriginal): void
    {
        $this->einzelpreisDtagOriginal = $einzelpreisDtagOriginal;
    }

    /**
     * @return float|null
     */
    public function getTransferpreisDttsOriginal(): ?float
    {
        return $this->transferpreisDttsOriginal;
    }

    /**
     * @param float|null $transferpreisDttsOriginal
     */
    public function setTransferpreisDttsOriginal(?float $transferpreisDttsOriginal): void
    {
        $this->transferpreisDttsOriginal = $transferpreisDttsOriginal;
    }

    /**
     * @return float|null
     */
    public function getTransferpreisDtagOriginal(): ?float
    {
        return $this->transferpreisDtagOriginal;
    }

    /**
     * @param float|null $transferpreisDtagOriginal
     */
    public function setTransferpreisDtagOriginal(?float $transferpreisDtagOriginal): void
    {
        $this->transferpreisDtagOriginal = $transferpreisDtagOriginal;
    }

    /**
     * @return float|null
     */
    public function getPreisnachlass(): ?float
    {
        return $this->preisnachlass;
    }

    /**
     * @param float|null $preisnachlass
     */
    public function setPreisnachlass(?float $preisnachlass): void
    {
        $this->preisnachlass = $preisnachlass;
    }

    /**
     * @return string|null
     */
    public function getInstallationsbemerkung(): ?string
    {
        return $this->installationsbemerkung;
    }

    /**
     * @param string|null $installationsbemerkung
     */
    public function setInstallationsbemerkung(?string $installationsbemerkung): void
    {
        $this->installationsbemerkung = $installationsbemerkung;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @param string|null $sapBestellnummer
     */
    public function setSapBestellnummer(?string $sapBestellnummer): void
    {
        $this->sapBestellnummer = $sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getVorgangsTicketNr(): ?string
    {
        return $this->vorgangsTicketNr;
    }

    /**
     * @param string|null $vorgangsTicketNr
     */
    public function setVorgangsTicketNr(?string $vorgangsTicketNr): void
    {
        $this->vorgangsTicketNr = $vorgangsTicketNr;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @param string|null $kommentar
     */
    public function setKommentar(?string $kommentar): void
    {
        $this->kommentar = $kommentar;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNr;
    }

    /**
     * @param int|null $matNr
     */
    public function setMatNr(?int $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @param string|null $icpKontPspKst
     * @throws ValidationException
     * @throws BindingResolutionException
     * @throws \ReflectionException
     */
    public function setIcpKontPspKst(?string $icpKontPspKst): void
    {
        $data = [
            'icpKontPspKst' => $icpKontPspKst,
            'debitorId' => $this->simple->getDebitorId()
        ];

        $validator = new SimpleValidator($data, 'Finance', [], null, true);
        $validationResult = $validator->validate();

        if (!$validationResult->isValid()) {
            throw new ValidationException(
                'Validation for icpKontPspKst and debitorId is failed',
                422,
                null,
                $validationResult
            );
        }

        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @param int|null $icpKontBpos
     */
    public function setIcpKontBpos(?int $icpKontBpos): void
    {
        $this->icpKontBpos = $icpKontBpos;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @param string|null $pspElement
     */
    public function setPspElement(?string $pspElement): void
    {
        $this->pspElement = $pspElement;
    }

    /**
     * @return ExtEbiDaten
     */
    public function getEbi(): ExtEbiDaten
    {
        return $this->ebi;
    }

    /**
     * @param ExtEbiDaten|null $ebi
     */
    public function setEbi(?ExtEbiDaten $ebi): void
    {
        $this->ebi = $ebi;
    }

    /**
     * @return OfferAuftrag
     */
    public function getSimple(): OfferAuftrag
    {
        return $this->simple;
    }

    /**
     * @param OfferAuftrag $simple
     */
    public function setSimple(OfferAuftrag $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return OfferFakturaLbu
     */
    public function getLbu(): OfferFakturaLbu
    {
        return $this->lbu;
    }

    /**
     * @param OfferFakturaLbu $lbu
     */
    public function setLbu(OfferFakturaLbu $lbu): void
    {
        $this->lbu = $lbu;
    }

    /**
     * @return OfferFakturaLbuDatenMengentyp|null
     */
    public function getMengentyp(): ?OfferFakturaLbuDatenMengentyp
    {
        return $this->mengentyp;
    }

    /**
     * @param OfferFakturaLbuDatenMengentyp|null $mengentyp
     */
    public function setMengentyp(?OfferFakturaLbuDatenMengentyp $mengentyp): void
    {
        $this->mengentyp = $mengentyp;
    }

    /**
     * @return OfferFakturaLbuDatenPreistyp|null
     */
    public function getPreistyp(): ?OfferFakturaLbuDatenPreistyp
    {
        return $this->preistyp;
    }

    /**
     * @param OfferFakturaLbuDatenPreistyp|null $preistyp
     */
    public function setPreistyp(?OfferFakturaLbuDatenPreistyp $preistyp): void
    {
        $this->preistyp = $preistyp;
    }

    /**
     * @return OfferFakturaLbuDatenQuellsystem|null
     */
    public function getQuellsystem(): ?OfferFakturaLbuDatenQuellsystem
    {
        return $this->quellsystem;
    }

    /**
     * @param OfferFakturaLbuDatenQuellsystem|null $quellsystem
     */
    public function setQuellsystem(?OfferFakturaLbuDatenQuellsystem $quellsystem): void
    {
        $this->quellsystem = $quellsystem;
    }

    /**
     * @return OfferFakturaLbuDatenSachkonto|null
     */
    public function getIcpKontKonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->icpKontKonto;
    }

    /**
     * @param OfferFakturaLbuDatenSachkonto|null $icpKontKonto
     */
    public function setIcpKontKonto(?OfferFakturaLbuDatenSachkonto $icpKontKonto): void
    {
        $this->icpKontKonto = $icpKontKonto;
    }

    /**
     * @return OfferKalkulationAngebotsposition|null
     */
    public function getAngebotsposition(): ?OfferKalkulationAngebotsposition
    {
        return $this->angebotsposition;
    }

    /**
     * @param OfferKalkulationAngebotsposition|null $angebotsposition
     */
    public function setAngebotsposition(?OfferKalkulationAngebotsposition $angebotsposition): void
    {
        $this->angebotsposition = $angebotsposition;
    }

    /**
     * @return OfferNiederlassung|null
     */
    public function getNl(): ?OfferNiederlassung
    {
        return $this->nl;
    }

    /**
     * @param OfferNiederlassung|null $nl
     */
    public function setNl(?OfferNiederlassung $nl): void
    {
        $this->nl = $nl;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @param string|null $positionName
     */
    public function setPositionName(?string $positionName): void
    {
        $this->positionName = $positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @param string|null $locationName
     */
    public function setLocationName(?string $locationName): void
    {
        $this->locationName = $locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }

    /**
     * @param string|null $orderPurchaseKey
     */
    public function setOrderPurchaseKey(?string $orderPurchaseKey): void
    {
        $this->orderPurchaseKey = $orderPurchaseKey;
    }
}
