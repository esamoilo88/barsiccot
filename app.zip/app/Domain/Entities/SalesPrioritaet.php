<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesPrioritaet
 *
 * @ORM\Table(name="Sales_Prioritaet")
 * @ORM\Entity
 */
class SalesPrioritaet
{
    /**
     * @var int
     *
     * @ORM\Column(name="prioritaet_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $prioritaetId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="string", length=50, nullable=true)
     */
    private $beschreibung;

    /**
     * @var int
     *
     * @ORM\Column(name="liegezeit_soll", type="integer", nullable=false)
     */
    private $liegezeitSoll;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @return int
     */
    public function getLiegezeitSoll()
    {
        return $this->liegezeitSoll;
    }

    /**
     * @return int
     */
    public function getPrioritaetId(): int
    {
        return $this->prioritaetId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }
}
