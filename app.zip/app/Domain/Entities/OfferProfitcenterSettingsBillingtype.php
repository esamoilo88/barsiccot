<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferProfitcenterSettingsBillingtype
 *
 * @ORM\Table(name="Offer_Profitcenter_Settings_Billingtype")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferProfitcenterSettingsBillingtype
{
    /**
     * @ORM\Column(name="billing_type_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $billingTypeId;

    /** @ORM\Column(name="bezeichnung", type="string", length=255, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="hard_billing", type="boolean", nullable=false) */
    private bool $hardBilling = false;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * @return int
     */
    public function getBillingTypeId(): int
    {
        return $this->billingTypeId;
    }

    /**
     * @param int $billingTypeId
     */
    public function setBillingTypeId(int $billingTypeId): void
    {
        $this->billingTypeId = $billingTypeId;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic"})
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return bool
     * @Groups({"orderBasic"})
     */
    public function isHardBilling(): bool
    {
        return $this->hardBilling;
    }

    /**
     * @param bool $hardBilling
     */
    public function setHardBilling(bool $hardBilling): void
    {
        $this->hardBilling = $hardBilling;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }
}
