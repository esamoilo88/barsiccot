<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class OnkaProducttypeSequence
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Producttype_Sequence")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaProducttypeSequence
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /** @ORM\Column(type="boolean") */
    private bool $required;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaSequence")
     * @ORM\JoinColumn(name="sequence_id", referencedColumnName="id")
     */
    private OnkaSequence $sequence;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaProducttype")
     * @ORM\JoinColumn(name="producttype_id", referencedColumnName="id")
     */
    private OnkaProducttype $producttype;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * OnkaProducttypeSequence constructor.
     * @param int $sort
     * @param bool $required
     * @param OnkaSequence $sequence
     * @param OnkaProducttype $producttype
     */
    public function __construct(int $sort, bool $required, OnkaSequence $sequence, OnkaProducttype $producttype)
    {
        $this->sort = $sort;
        $this->required = $required;
        $this->sequence = $sequence;
        $this->producttype = $producttype;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * @return OnkaSequence
     */
    public function getSequence(): OnkaSequence
    {
        return $this->sequence;
    }

    /**
     * @return OnkaProducttype
     */
    public function getProducttype(): OnkaProducttype
    {
        return $this->producttype;
    }
}
