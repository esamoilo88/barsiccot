<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmDienstleistung
 *
 * @ORM\Table(name="RM_Dienstleistung")
 * @ORM\Entity
 */
class RmDienstleistung
{
    /**
     * @var int
     *
     * @ORM\Column(name="dienstleistungs_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $dienstleistungsId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=100, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hide", type="boolean", nullable=true)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
