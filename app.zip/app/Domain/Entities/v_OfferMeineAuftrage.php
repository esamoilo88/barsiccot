<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_MeineAuftraege")
 */
class v_OfferMeineAuftrage
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @ORM\Column(name="SIN", type="string", nullable=false)
     */
    private $SIN;

    /**
     * @ORM\Column(name="thema", type="string", nullable=true)
     */
    private $thema;

    /**
     *
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private $kundenname;

    /**
     * @ORM\Column(name="tp_dtts_gesamt", type="float", nullable=true)
     */
    private $tppDttsGesamt;

    /**
     * @ORM\Column(name="auftragsdatum", type="datetime", nullable=true)
     */
    private $auftragsdatum;

    /**
     * @ORM\Column(name="VAVbenutzer_id", type="integer", nullable=true)
     */
    private $VAVbenutzerId;

    /**
     * @ORM\Column(name="AVbenutzer_id", type="integer", nullable=true)
     */
    private $AVbenutzerId;

    /**
     * @ORM\Column(name="EV1benutzer_id", type="integer", nullable=true)
     */
    private $EV1benutzerId;

    /**
     * @ORM\Column(name="EV2benutzer_id", type="integer", nullable=true)
     */
    private $EV2benutzerId;

    /**
     * @ORM\Column(name="vertragsdaten_gesendet_am", type="datetime", nullable=true)
     */
    private $vetragsdatenGesendetAm;

    /**
     * @ORM\Column(name="status", type="string", nullable=true)
     */
    private $status;

    /**
     * @ORM\Column(name="abgeschlossenGrund_id", type="integer", nullable=true)
     */
    private $abgeschlossenGrundId;

    /**
     * @ORM\Column(name="start_simple_id", type="integer", nullable=false)
     */
    private $startSimpleId;

    /**
     * @ORM\Column(name="display_field", type="string", nullable=true)
     */
    private $displayField;


    /**
     * @ORM\Column(name="vorhabenbeschreibung", type="string", nullable=true)
     */
    private $vorhabenbeschreibung;

    /**
     * @ORM\Column(name="kundennummer", type="string", nullable=true)
     */
    private $kundennummer;

    /**
     * @ORM\Column(name="vertragsbeginn", type="string", nullable=true)
     */
    private $vertragsbeginn;

    /**
     * @ORM\Column(name="vertragsende", type="string", nullable=true)
     */
    private $vertragsende;

    /**
     * @ORM\Column(name="abkuerzung", type="string", nullable=true)
     */
    private $abkuerzung;

    /**
     * @ORM\Column(name="email_auftragsverantwortlicher", type="string", nullable=true)
     */
    private $emailAuftragsverantwortlicher;

    /**
     * @ORM\Column(name="email_eintragungssverantwortlicher", type="string", nullable=true)
     */
    private $emailEintragungssverantwortlicher;

    /**
     * @ORM\Column(name="email_eintragungsverantwortlicher_2", type="string", nullable=true)
     */
    private $emailEintragungssverantwortlicher2;

    /**
     * @ORM\Column(name="abgeschlossen_dateline", type="datetime", nullable=true)
     */
    private $abgeschlossenDateline;

    /**
     * @ORM\Column(name="kommentar_faktura", type="string", nullable=true)
     */
    private $kommentarFaktura;

    /**
     * @ORM\Column(name="dauerfreigabe", type="boolean", nullable=true)
     */
    private $dauerfreigabe;

    /**
     * @ORM\Column(name="pcag_id", type="integer", nullable=true)
     */
    private $pcagId;

    /**
     * @ORM\Column(name="sap_auftrags_nr", type="string", nullable=true)
     */
    private $sapAuftragsNr;

    /**
     * @ORM\Column(name="tp_versions_nr", type="integer", nullable=true)
     */
    private $tpVersionsNr;

    /**
     * @ORM\Column(name="lbu_freigabe_vorname", type="string", nullable=true)
     */
    private $lbuFreigabeVorname;

    /**
     * @ORM\Column(name="lbu_freigabe_nachname", type="string", nullable=true)
     */
    private $lbuFreigabeNachname;

    /**
     * @ORM\Column(name="lbu_freigabe_ressort", type="string", nullable=true)
     */
    private $lbuFreigabeRessort;

    /**
     * @ORM\Column(name="lbu_recipients_email", type="string", nullable=true)
     */
    private $lbuRecipientsEmail;

    /**
     * @ORM\Column(name="gmkz_tdg", type="string", nullable=true)
     */
    private $gmkzTdg;

    /**
     * @ORM\Column(name="offener_cr", type="string", nullable=true)
     */
    private $offenerCr;

    /**
     * @ORM\Column(name="vb_date", type="datetime", nullable=true)
     */
    private $vbDate;

    /**
     * @ORM\Column(name="ve_date", type="datetime", nullable=true)
     */
    private $veDate;

    /**
     * @ORM\Column(name="kommentar_kosten", type="string", nullable=true)
     */
    private $kommentarKosten;

    /**
     * @ORM\Column(name="bezug_simple_id", type="integer", nullable=true)
     */
    private $bezugSimpleId;

    /**
     * @ORM\Column(name="tp_versions_id", type="integer", nullable=true)
     */
    private $tpVersionsId;

    /**
     * @ORM\Column(name="produktionsreife_start", type="datetime", nullable=true)
     */
    private $produktionsreifeStart;

    /**
     * @ORM\Column(name="produktionsreife_ende", type="datetime", nullable=true)
     */
    private $produktionsreifeEnde;

    /**
     * @ORM\Column(name="modified", type="string", nullable=true)
     */
    private $modified;

    /**
     * @ORM\Column(name="offene_pr", type="boolean", nullable=true)
     */
    private $offene_pr;

    /**
     * @ORM\Column(name="vk_versions_id", type="integer", nullable=true)
     */
    private $vkVersionsId;

    /**
     * @ORM\Column(name="prozess_id", type="integer", nullable=true)
     */
    private $prozessId;

    /**
     * @ORM\Column(name="psp_element", type="string", nullable=true)
     */
    private $pspElement;

    /**
     * @ORM\Column(name="matnr", type="string", nullable=true)
     */
    private $matnr;

    /**
     * @var OfferDebitor
     *
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id")
     * })
     */
    private $debitorId;

    /**
     * @ORM\Column(name="debitor_name", type="string", nullable=true)
     */
    private $debitorName;

    /**
     * @ORM\Column(name="email_auftragsverantwortlicher_2", type="string", nullable=true)
     */
    private $emailAuftragsverantwortlicher2;

    /**
     * @ORM\Column(name="AV2benutzer_id", type="integer", nullable=true)
     */
    private $AV2benutzerId;

    /**
     * @return mixed
     */
    public function getSimpleId()
    {
        return $this->simpleId;
    }

    /**
     * @return mixed
     */
    public function getSIN()
    {
        return $this->SIN;
    }

    /**
     * @return mixed
     */
    public function getThema()
    {
        return $this->thema;
    }

    /**
     * @return mixed
     */
    public function getKundenname()
    {
        return $this->kundenname;
    }

    /**
     * @return mixed
     */
    public function getTppDttsGesamt()
    {
        return $this->tppDttsGesamt;
    }

    /**
     * @return mixed
     */
    public function getAuftragsdatum()
    {
        return $this->auftragsdatum;
    }

    /**
     * @return mixed
     */
    public function getVAVbenutzerId()
    {
        return $this->VAVbenutzerId;
    }

    /**
     * @return mixed
     */
    public function getAVbenutzerId()
    {
        return $this->AVbenutzerId;
    }

    /**
     * @return mixed
     */
    public function getEV1benutzerId()
    {
        return $this->EV1benutzerId;
    }

    /**
     * @return mixed
     */
    public function getEV2benutzerId()
    {
        return $this->EV2benutzerId;
    }

    /**
     * @return mixed
     */
    public function getVetragsdatenGesendetAm()
    {
        return $this->vetragsdatenGesendetAm;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @return mixed
     */
    public function getAbgeschlossenGrundId()
    {
        return $this->abgeschlossenGrundId;
    }

    /**
     * @return mixed
     */
    public function getDisplayField()
    {
        return $this->displayField;
    }

    /**
     * @return mixed
     */
    public function getKundennummer()
    {
        return $this->kundennummer;
    }

    /**
     * @return mixed
     */
    public function getVertragsbeginn()
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return mixed
     */
    public function getVertragsende()
    {
        return $this->vertragsende;
    }

    /**
     * @return mixed
     */
    public function getAbkuerzung()
    {
        return $this->abkuerzung;
    }

    /**
     * @return mixed
     */
    public function getEmailAuftragsverantwortlicher()
    {
        return $this->emailAuftragsverantwortlicher;
    }

    /**
     * @return mixed
     */
    public function getEmailEintragungssverantwortlicher()
    {
        return $this->emailEintragungssverantwortlicher;
    }

    /**
     * @return mixed
     */
    public function getEmailEintragungssverantwortlicher2()
    {
        return $this->emailEintragungssverantwortlicher2;
    }

    /**
     * @return mixed
     */
    public function getAbgeschlossenDateline()
    {
        return $this->abgeschlossenDateline;
    }

    /**
     * @return mixed
     */
    public function getDauerfreigabe()
    {
        return $this->dauerfreigabe;
    }

    /**
     * @return mixed
     */
    public function getPcagId()
    {
        return $this->pcagId;
    }

    /**
     * @return mixed
     */
    public function getSapAuftragsNr()
    {
        return $this->sapAuftragsNr;
    }

    /**
     * @return mixed
     */
    public function getTpVersionsNr()
    {
        return $this->tpVersionsNr;
    }

    /**
     * @return mixed
     */
    public function getLbuFreigabeVorname()
    {
        return $this->lbuFreigabeVorname;
    }

    /**
     * @return mixed
     */
    public function getLbuFreigabeNachname()
    {
        return $this->lbuFreigabeNachname;
    }

    /**
     * @return mixed
     */
    public function getLbuRecipientsEmail()
    {
        return $this->lbuRecipientsEmail;
    }

    /**
     * @return mixed
     */
    public function getGmkzTdg()
    {
        return $this->gmkzTdg;
    }

    /**
     * @return mixed
     */
    public function getOffenerCr()
    {
        return $this->offenerCr;
    }

    /**
     * @return mixed
     */
    public function getVbDate()
    {
        return $this->vbDate;
    }

    /**
     * @return mixed
     */
    public function getVeDate()
    {
        return $this->veDate;
    }

    /**
     * @return mixed
     */
    public function getKommentarKosten()
    {
        return $this->kommentarKosten;
    }

    /**
     * @return mixed
     */
    public function getTpVersionsId()
    {
        return $this->tpVersionsId;
    }

    /**
     * @return mixed
     */
    public function getProduktionsreifeStart()
    {
        return $this->produktionsreifeStart;
    }

    /**
     * @return mixed
     */
    public function getProduktionsreifeEnde()
    {
        return $this->produktionsreifeEnde;
    }

    /**
     * @return mixed
     */
    public function getModified()
    {
        return $this->modified;
    }

    /**
     * @return mixed
     */
    public function getVkVersionsId()
    {
        return $this->vkVersionsId;
    }

    /**
     * @return mixed
     */
    public function getPspElement()
    {
        return $this->pspElement;
    }

    /**
     * @return mixed
     */
    public function getDebitorId()
    {
        return $this->debitorId;
    }

    /**
     * @return mixed
     */
    public function getDebitorName()
    {
        return $this->debitorName;
    }

    /**
     * @return mixed
     */
    public function getEmailAuftragsverantwortlicher2()
    {
        return $this->emailAuftragsverantwortlicher2;
    }

    /**
     * @return mixed
     */
    public function getAV2benutzerId()
    {
        return $this->AV2benutzerId;
    }

    private function __construct()
    {
    }
}
