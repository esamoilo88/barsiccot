<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Illuminate\Support\Facades\Date;

/**
 * SalesZdfStammdaten
 *
 * @ORM\Table(name="Sales_ZDF_Stammdaten")
 * @ORM\Entity
 */
class SalesZdfStammdaten
{
    /**
     * @ORM\Column(name="zdf_id", type="integer")
     * @ORM\Id
     */
    private int $zdfId;

    /**
     * @ORM\Column(name="ressourcenmanager_email", type="string", length=255, nullable=true)
     */
    private ?string $ressourcenmanagerEmail;

    /**
     * @ORM\Column(name="ressourcenmanager_vorname", type="string", length=150, nullable=true)
     */
    private ?string $ressourcenmanagerVorname;

    /**
     * @ORM\Column(name="ressourcenmanager_nachname", type="string", length=150, nullable=true)
     */
    private ?string $ressourcenmanagerNachname;

    /**
     * @ORM\Column(name="aufgabenstellung_zielsetzung_kunde", type="text", length=-1, nullable=true)
     */
    private ?string $aufgabenstellungZielsetzungKunde;

    /**
     * @ORM\Column(name="kundenanschrift", type="string", length=255, nullable=true)
     */
    private ?string $kundenanschrift;

    /**
     * @ORM\Column(name="auftraggeber", type="string", length=100, nullable=true)
     */
    private ?string $auftraggeber;

    /**
     * @ORM\Column(name="angebotswunschtermin_vertrieb", type="datetime", nullable=true)
     */
    private ?DateTime $angebotswunschterminVertrieb;

    /**
     * @ORM\Column(name="kundenwunschtermin", type="datetime", nullable=true)
     */
    private ?DateTime $kundenwunschtermin;

    /**
     * @ORM\Column(name="auftragserwartung", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?string $auftragserwartung;

    /**
     * @ORM\Column(name="modified", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="update")
     */
    private ?DateTime $modified;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $created;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     * @Gedmo\Timestampable(on="create")
     */
    private ?DateTime $bits;

    /**
     * @ORM\Column(name="stundenkontingent", type="integer", nullable=true)
     */
    private ?int $stundenkontingent;

    /**
     * @ORM\Column(name="buchungskreis", type="string", length=255, nullable=true)
     */
    private ?string $buchungskreis;

    /**
     * @ORM\Column(name="auftragswahrscheinlichkeit", type="smallint", nullable=true)
     */
    private ?int $auftragswahrscheinlichkeit;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * SalesZdfStammdaten constructor.
     * @param int $zdfId
     * @param SalesStammdaten $simple
     * @param string|null $kundenanschrift
     * @param string|null $auftraggeber
     * @param DateTime|null $angebotswunschterminVertrieb
     * @param DateTime|null $kundenwunschtermin
     * @param string|null $auftragserwartung
     * @param string|null $ressourcenmanagerEmail
     * @param int|null $auftragswahrscheinlichkeit
     * @param string|null $ressourcenmanagerVorname
     * @param string|null $ressourcenmanagerNachname
     * @param int|null $stundenkontingent
     * @param string|null $buchungskreis
     * @param string|null $aufgabenstellungZielsetzungKunde
     */
    public function __construct(
        int $zdfId,
        SalesStammdaten $simple,
        ?string $kundenanschrift,
        ?string $auftraggeber,
        ?DateTime $angebotswunschterminVertrieb,
        ?DateTime $kundenwunschtermin,
        ?string $auftragserwartung,
        ?string $ressourcenmanagerEmail,
        ?int $auftragswahrscheinlichkeit,
        ?string $ressourcenmanagerVorname,
        ?string $ressourcenmanagerNachname,
        ?int $stundenkontingent = null,
        ?string $buchungskreis = null,
        ?string $aufgabenstellungZielsetzungKunde = null
    )
    {
        $this->zdfId = $zdfId;
        $this->simple = $simple;
        $this->kundenanschrift = $kundenanschrift;
        $this->auftraggeber = $auftraggeber;
        $this->angebotswunschterminVertrieb = $angebotswunschterminVertrieb;
        $this->kundenwunschtermin = $kundenwunschtermin;
        $this->auftragserwartung = $auftragserwartung;
        $this->ressourcenmanagerEmail = $ressourcenmanagerEmail;
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
        $this->ressourcenmanagerVorname = $ressourcenmanagerVorname;
        $this->ressourcenmanagerNachname = $ressourcenmanagerNachname;
        $this->stundenkontingent = $stundenkontingent;
        $this->buchungskreis = $buchungskreis;
        $this->aufgabenstellungZielsetzungKunde = $aufgabenstellungZielsetzungKunde;
    }


    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return int
     */
    public function getZdfId(): int
    {
        return $this->zdfId;
    }

    /**
     * @param string|null $kundenanschrift
     */
    public function setKundenanschrift(?string $kundenanschrift): void
    {
        $this->kundenanschrift = $kundenanschrift;
    }

    /**
     * @param string|null $auftraggeber
     */
    public function setAuftraggeber(?string $auftraggeber): void
    {
        $this->auftraggeber = $auftraggeber;
    }

    /**
     * @param DateTime|null $angebotswunschterminVertrieb
     */
    public function setAngebotswunschterminVertrieb(?DateTime $angebotswunschterminVertrieb): void
    {
        $this->angebotswunschterminVertrieb = $angebotswunschterminVertrieb;
    }

    /**
     * @param DateTime|null $kundenwunschtermin
     */
    public function setKundenwunschtermin(?DateTime $kundenwunschtermin): void
    {
        $this->kundenwunschtermin = $kundenwunschtermin;
    }

    /**
     * @param string|null $auftragserwartung
     */
    public function setAuftragserwartung(?string $auftragserwartung): void
    {
        $this->auftragserwartung = $auftragserwartung;
    }

    /**
     * @param string|null $ressourcenmanagerEmail
     */
    public function setRessourcenmanagerEmail(?string $ressourcenmanagerEmail): void
    {
        $this->ressourcenmanagerEmail = $ressourcenmanagerEmail;
    }

    /**
     * @param int|null $auftragswahrscheinlichkeit
     */
    public function setAuftragswahrscheinlichkeit(?int $auftragswahrscheinlichkeit): void
    {
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
    }

    /**
     * @param string|null $ressourcenmanagerVorname
     */
    public function setRessourcenmanagerVorname(?string $ressourcenmanagerVorname): void
    {
        $this->ressourcenmanagerVorname = $ressourcenmanagerVorname;
    }

    /**
     * @param string|null $ressourcenmanagerNachname
     */
    public function setRessourcenmanagerNachname(?string $ressourcenmanagerNachname): void
    {
        $this->ressourcenmanagerNachname = $ressourcenmanagerNachname;
    }
}
