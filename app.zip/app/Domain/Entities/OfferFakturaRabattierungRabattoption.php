<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaRabattierungRabattoption
 *
 * @ORM\Table(name="Offer_Faktura_Rabattierung_Rabattoption")
 * @ORM\Entity
 */
class OfferFakturaRabattierungRabattoption
{
    /**
     * @var int
     *
     * @ORM\Column(name="rabattoption_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $rabattoptionId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=150, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
