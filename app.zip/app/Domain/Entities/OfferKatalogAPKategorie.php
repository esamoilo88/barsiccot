<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OfferKatalogAPKategorie
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_AP_Kategorie")
 */
class OfferKatalogAPKategorie
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $katalogAp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")
     */
    private OfferKatalogKategorie $katalogKategorie;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * OfferKatalogAPKategorie constructor.
     * @param OfferKatalogAngebotsposition $katalogAp
     * @param OfferKatalogKategorie $katalogKategorie
     * @param int|null $sort
     */
    public function __construct(OfferKatalogAngebotsposition $katalogAp, OfferKatalogKategorie $katalogKategorie, ?int $sort)
    {
        $this->katalogAp = $katalogAp;
        $this->katalogKategorie = $katalogKategorie;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @return OfferKatalogAngebotsposition
     */
    public function getKatalogAp(): OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @return OfferKatalogKategorie
     */
    public function getKatalogKategorie(): OfferKatalogKategorie
    {
        return $this->katalogKategorie;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
