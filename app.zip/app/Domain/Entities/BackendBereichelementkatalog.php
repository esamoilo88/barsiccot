<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendBereichelementkatalog
 *
 * @ORM\Table(name="Backend_BereichElementkatalog")
 * @ORM\Entity
 */
class BackendBereichelementkatalog
{
    /**
     * @var int
     *
     * @ORM\Column(name="bereichElementkatalog_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $bereichelementkatalogId;

    /**
     * @var int
     *
     * @ORM\Column(name="kategorie_id", type="integer", nullable=false)
     */
    private $kategorieId;

    /**
     * @var \BackendBereich
     *
     * @ORM\ManyToOne(targetEntity="BackendBereich")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bereich_id", referencedColumnName="bereich_id")
     * })
     */
    private $bereich;


}
