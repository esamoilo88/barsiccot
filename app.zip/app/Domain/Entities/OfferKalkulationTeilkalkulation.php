<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKalkulationTeilkalkulation
 *
 * @ORM\Table(name="Offer_Kalkulation_Teilkalkulation")
 * @ORM\Entity
 */
class OfferKalkulationTeilkalkulation
{
    /**
     * @var int
     *
     * @ORM\Column(name="teilkalkulation_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $teilkalkulationId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="technisch_machbar", type="boolean", nullable=true)
     */
    private $technischMachbar;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="termine_realisierbar", type="boolean", nullable=true)
     */
    private $termineRealisierbar;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="skill_vorhanden", type="boolean", nullable=true)
     */
    private $skillVorhanden;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="angefordert_am", type="datetime", nullable=true)
     */
    private $angefordertAm;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kommentar_pruefung", type="text", length=-1, nullable=true)
     */
    private $kommentarPruefung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="fertig_am", type="datetime", nullable=true)
     */
    private $fertigAm;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     * })
     */
    private $benutzer;

    /**
     * @var \OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private $vkVersions;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
