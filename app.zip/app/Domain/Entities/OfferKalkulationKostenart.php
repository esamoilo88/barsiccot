<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKalkulationKostenart
 *
 * @ORM\Table(name="Offer_Kalkulation_Kostenart")
 * @ORM\Entity
 */
class OfferKalkulationKostenart
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenart;

    /**
     * @ORM\Column(name="kostenstelle_id", type="integer")
     */
    private $kostenstelleId;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id")
     */
    private CostsKostenstelle $kostenstelle;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * OfferKalkulationKostenart constructor.
     * @param SalesStammdaten $simple
     * @param OfferAngebotVk $vkVersions
     * @param CostsKostenart $kostenart
     * @param CostsKostenstelle $kostenstelle
     */
    public function __construct(
        SalesStammdaten $simple,
        OfferAngebotVk $vkVersions,
        CostsKostenart $kostenart,
        CostsKostenstelle $kostenstelle
    )
    {
        $this->simple = $simple;
        $this->vkVersions = $vkVersions;
        $this->kostenart = $kostenart;
        $this->kostenstelle = $kostenstelle;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @return CostsKostenart
     */
    public function getKostenart(): CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @return CostsKostenstelle
     */
    public function getKostenstelle(): CostsKostenstelle
    {
        return $this->kostenstelle;
    }

    /**
     * @param CostsKostenstelle $kostenstelle
     */
    public function setKostenstelle(CostsKostenstelle $kostenstelle): void
    {
        $this->kostenstelle = $kostenstelle;
    }
}
