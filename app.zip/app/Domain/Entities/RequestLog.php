<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RequestLog
 *
 * @ORM\Table(name="Request_log")
 * @ORM\Entity
 */
class RequestLog
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="domain", type="string", length=20, nullable=true)
     */
    private $domain;

    /**
     * @var string|null
     *
     * @ORM\Column(name="controller", type="string", length=40, nullable=true)
     */
    private $controller;

    /**
     * @var string|null
     *
     * @ORM\Column(name="action", type="string", length=40, nullable=true)
     */
    private $action;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateline", type="datetime", nullable=false)
     */
    private $dateline;


}
