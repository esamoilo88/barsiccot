<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaLbuRecipients
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Recipients")
 * @ORM\Entity
 */
class OfferFakturaLbuRecipients
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorname", type="text", length=-1, nullable=true)
     */
    private $vorname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nachname", type="text", length=-1, nullable=true)
     */
    private $nachname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="email", type="text", length=-1, nullable=true)
     */
    private $email;

    /**
     * @var string|null
     *
     * @ORM\Column(name="recipient_type", type="string", length=3, nullable=true)
     */
    private $recipientType;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAuftrag")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private OfferAuftrag $simple;

    /**
     * OfferFakturaLbuRecipients constructor.
     * @param string $vorname
     * @param string $nachname
     * @param string $email
     * @param string $recipientType
     * @param OfferAuftrag $simple
     */
    public function __construct(
        string $vorname,
        string $nachname,
        string $email,
        string $recipientType,
        OfferAuftrag $simple
    )
    {
        $this->vorname = $vorname;
        $this->nachname = $nachname;
        $this->email = $email;
        $this->recipientType = $recipientType;
        $this->simple = $simple;
    }

}
