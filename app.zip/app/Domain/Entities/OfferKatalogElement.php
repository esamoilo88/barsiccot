<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferKatalogElement
 *
 * @ORM\Table(name="Offer_Katalog_Element")
 * @ORM\Entity
 */
class OfferKatalogElement
{
    /**
     * @var int
     *
     * @ORM\Column(type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $elementId;

    /** @ORM\Column(type="string", length=150, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(type="string", length=50, nullable=true) */
    private ?string $zeitstunden;

    /** @ORM\Column(type="decimal", precision=26, scale=16, nullable=true) */
    private ?string $wert;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $stundensatz;

    /** @ORM\Column(type="decimal", precision=12, scale=6, nullable=true) */
    private ?string $gmkz;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $ma;

    /** @ORM\Column(name="ts_id_kategorie_1", type="integer", nullable=true) */
    private ?int $tsIdKategorie1;

    /** @ORM\Column(name="ts_id_kategorie_2", type="integer", nullable=true) */
    private ?int $tsIdKategorie2;

    /**
     * @ORM\ManyToOne(targetEntity="ExtTransparenztoolliste")
     * @ORM\JoinColumn(name="ts_id_produkt", referencedColumnName="id_produkt", nullable=true)
     */
    private ?ExtTransparenztoolliste $tsIdProdukt;

    /** @ORM\Column(type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="kommentar_1", type="text", length=-1, nullable=true) */
    private ?string $kommentar1;

    /** @ORM\Column(name="kommentar_2", type="text", length=-1, nullable=true) */
    private ?string $kommentar2;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $festpreis;

    /** @ORM\Column(type="integer", nullable=true) */
    private ?int $ofiLa;

    /** @ORM\Column(type="boolean", nullable=true) */
    private ?bool $inflationsfaktor;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenart;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKatalogLeistungsposition $leistungsposition;

    /**
     * @ORM\ManyToOne(targetEntity="CostsStundensatz")
     * @ORM\JoinColumn(name="stundensatz_id", referencedColumnName="stundensatz_id", nullable=true)
     */
    private ?CostsStundensatz $costsStundensatz = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenQuellsystem")
     * @ORM\JoinColumn(name="quellsystem_id", referencedColumnName="quellsystem_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenQuellsystem $quellsystem = null;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogBerechnung", fetch="EAGER", mappedBy="element", cascade={"remove"})
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id")
     */
    private Collection $katalogBer;

    /**
     * @ORM\OneToMany(targetEntity="OfferKatalogBerElLp", mappedBy="katalogEl", cascade={"remove"})
     * @ORM\OrderBy({"sort" = "ASC"})
     */
    private Collection $bers;

    /**
     * @ORM\ManyToMany(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinTable(name="Offer_Katalog_EL_LP",
     *      joinColumns={@ORM\JoinColumn(name="element_id", referencedColumnName="element_id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")}
     * )
     */
    private Collection $lps;

    public function __construct()
    {
        $this->beschreibung = null;
        $this->festpreis = null;
        $this->katalogBer = new ArrayCollection();
        $this->bers = new ArrayCollection();
        $this->lps = new ArrayCollection();
        $this->inflationsfaktor = '';
    }

    /**
     * @Groups({"adminKatalog"})
     * @return ArrayCollection|Collection
     */
    public function getBers()
    {
        return $this->bers->map(function (OfferKatalogBerElLp $elBer) {
            return $elBer->getKatalogBer();
        });
    }

    /**
     * @param ArrayCollection|Collection $bers
     */
    public function setBers($bers): void
    {
        $this->bers = $bers;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getLps()
    {
        return $this->lps;
    }

    /**
     * @param ArrayCollection|Collection $lps
     */
    public function setLps($lps): void
    {
        $this->lps = $lps;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return CostsKostenart
     */
    public function getKostenart(): CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @Groups({"adminKatalog", "adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getWert(): ?string
    {
        return $this->wert;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getZeitstunden(): ?string
    {
        return $this->zeitstunden;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return bool|null
     */
    public function getMa(): ?bool
    {
        return $this->ma;
    }

    /**
     * @return int|null
     */
    public function getTsIdKategorie1(): ?int
    {
        return $this->tsIdKategorie1;
    }

    /**
     * @return int|null
     */
    public function getTsIdKategorie2(): ?int
    {
        return $this->tsIdKategorie2;
    }

    /**
     * @return ExtTransparenztoolliste|null
     */
    public function getTsIdProdukt(): ?ExtTransparenztoolliste
    {
        return $this->tsIdProdukt;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return bool|null
     */
    public function getFestpreis(): ?bool
    {
        return $this->festpreis;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return int
     */
    public function getElementId(): int
    {
        return $this->elementId;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getStundensatz(): ?string
    {
        return $this->stundensatz;
    }

    /**
     * @param string|null $stundensatz
     */
    public function setStundensatz(?string $stundensatz): void
    {
        $this->stundensatz = $stundensatz;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getGmkz(): ?string
    {
        return $this->gmkz;
    }

    /**
     * @param string|null $gmkz
     */
    public function setGmkz(?string $gmkz): void
    {
        $this->gmkz = $gmkz;
    }

    /**
     * @return Collection
     */
    public function getKatalogBer(): Collection
    {
        return $this->katalogBer;
    }

    /**
     * @param CostsKostenart|object $kostenart
     */
    public function setKostenart(CostsKostenart $kostenart): void
    {
        $this->kostenart = $kostenart;
    }

    /**
     * @param bool|null $ma
     */
    public function setMa(?bool $ma): void
    {
        $this->ma = $ma;
    }

    /**
     * @param int $elementId
     */
    public function setElementId(int $elementId): void
    {
        $this->elementId = $elementId;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param float|null $wert
     */
    public function setWert(?float $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @param string|null $zeitstunden
     */
    public function setZeitstunden(?string $zeitstunden): void
    {
        $this->zeitstunden = $zeitstunden;
    }

    /**
     * @param int|null $tsIdKategorie1
     */
    public function setTsIdKategorie1(?int $tsIdKategorie1): void
    {
        $this->tsIdKategorie1 = $tsIdKategorie1;
    }

    /**
     * @param int|null $tsIdKategorie2
     */
    public function setTsIdKategorie2(?int $tsIdKategorie2): void
    {
        $this->tsIdKategorie2 = $tsIdKategorie2;
    }

    /**
     * @param ExtTransparenztoolliste|null $tsIdProdukt
     */
    public function setTsIdProdukt(?ExtTransparenztoolliste $tsIdProdukt): void
    {
        $this->tsIdProdukt = $tsIdProdukt;
    }

    /**
     * @param ArrayCollection|Collection $katalogBer
     */
    public function setKatalogBer($katalogBer): void
    {
        $this->katalogBer = $katalogBer;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return bool|null
     */
    public function getInflationsfaktor(): ?bool
    {
        return $this->inflationsfaktor;
    }

    /**
     * @param bool|null $inflationsfaktor
     */
    public function setInflationsfaktor(?bool $inflationsfaktor): void
    {
        $this->inflationsfaktor = $inflationsfaktor;
    }

    /**
     * @return CostsStundensatz|null
     */
    public function getCostsStundensatz(): ?CostsStundensatz
    {
        return $this->costsStundensatz;
    }

    /**
     * @return OfferFakturaLbuDatenQuellsystem|null
     */
    public function getQuellsystem(): ?OfferFakturaLbuDatenQuellsystem
    {
        return $this->quellsystem;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getLeistungsposition(): OfferKatalogLeistungsposition
    {
        return $this->leistungsposition;
    }

    /**
     * @param OfferKatalogLeistungsposition|object $leistungsposition
     */
    public function setLeistungsposition(OfferKatalogLeistungsposition $leistungsposition): void
    {
        $this->leistungsposition = $leistungsposition;
    }
}
