<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaBillingPool
 *
 * @ORM\Table(name="Offer_Faktura_Billing_Pool")
 * @ORM\Entity
 */
class OfferFakturaBillingPool
{
    /**
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="billing_day", type="date", nullable=false) */
    private \DateTime $billingDay;

    /** @ORM\Column(name="pool_nr", type="integer", nullable=false) */
    private int $poolNr;

    /**
     * OfferFakturaBillingPool constructor.
     * @param \DateTime $billingDay
     * @param int $poolNr
     */
    public function __construct(\DateTime $billingDay, int $poolNr)
    {
        $this->billingDay = $billingDay;
        $this->poolNr = $poolNr;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return \DateTime
     */
    public function getBillingDay(): \DateTime
    {
        return $this->billingDay;
    }

    /**
     * @param \DateTime $billingDay
     */
    public function setBillingDay(\DateTime $billingDay): void
    {
        $this->billingDay = $billingDay;
    }

    /**
     * @return int
     */
    public function getPoolNr(): int
    {
        return $this->poolNr;
    }

    /**
     * @param int $poolNr
     */
    public function setPoolNr(int $poolNr): void
    {
        $this->poolNr = $poolNr;
    }
}
