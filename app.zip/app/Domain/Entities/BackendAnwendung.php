<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * BackendAnwendung
 *
 * @ORM\Table(name="Backend_Anwendung")
 * @ORM\Entity
 */
class BackendAnwendung
{
    /**
     * @ORM\Column(name="anwendungs_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $anwendungId;

    /** @ORM\Column(name="bezeichnung", type="string", length=30, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="hide", type="boolean", nullable=true) */
    private ?bool $hide;

    /** @ORM\Column(name="is_link", type="boolean", nullable=false, options={"default"="0"}) */
    private bool $isLink = false;

    /** @ORM\Column(name="sort", type="integer", nullable=false, options={"default"="1"}) */
    private int $sort = 1;

    /**
     * @return int
     */
    public function getAnwendungId(): int
    {
        return $this->anwendungId;
    }

    /**
     * @param int $anwendungId
     */
    public function setAnwendungId(int $anwendungId): void
    {
        $this->anwendungId = $anwendungId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return bool|null
     */
    public function getHide(): ?bool
    {
        return $this->hide;
    }

    /**
     * @param bool|null $hide
     */
    public function setHide(?bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool
     */
    public function isLink(): bool
    {
        return $this->isLink;
    }

    /**
     * @param bool $isLink
     */
    public function setIsLink(bool $isLink): void
    {
        $this->isLink = $isLink;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }
}
