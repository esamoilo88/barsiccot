<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * TmpCrmKunde
 *
 * @ORM\Table(name="tmp_CRM_Kunde")
 * @ORM\Entity
 */
class TmpCrmKunde
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_nr", type="text", length=-1, nullable=true)
     */
    private $gpNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_kdnr", type="text", length=-1, nullable=true)
     */
    private $dtagKdnr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_name_lang", type="text", length=-1, nullable=true)
     */
    private $dtagNameLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_plz", type="text", length=-1, nullable=true)
     */
    private $dtagPlz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="DTAG_ort", type="text", length=-1, nullable=true)
     */
    private $dtagOrt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="status", type="text", length=-1, nullable=true)
     */
    private $status;


}
