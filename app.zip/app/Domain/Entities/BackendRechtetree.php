<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendRechtetree
 *
 * @ORM\Table(name="Backend_RechteTree")
 * @ORM\Entity
 */
class BackendRechtetree
{
    /**
     * @ORM\Column(name="rechtetree_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $rechtetreeId;

    /**
     * @ORM\ManyToOne(targetEntity="BackendTree", inversedBy="backendRechteTree")
     * @ORM\JoinColumn(name="tree_id", referencedColumnName="tree_id")
     */
    private BackendTree $backendTree;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRechte")
     * @ORM\JoinColumn(name="rechte_id", referencedColumnName="rechte_id")
     */
    private BackendRechte $backendRechte;

    /**
     * @return BackendRechte
     */
    public function backendRechte(): BackendRechte
    {
        return $this->backendRechte;
    }

}
