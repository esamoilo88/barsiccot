<?php

namespace App\Domain\Entities;

use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * GlobalLog
 *
 * @ORM\Table(name="Global_Log_Group")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class GlobalLogGroup
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="sys_name", type="string", length=32) */
    private string $sysName;

    /** @ORM\Column(name="name", type="string", length=32) */
    private string $name;

    /** @ORM\Column(name="sales_relevant", type="boolean") */
    private bool $salesRelevant = false;

    /** @ORM\Column(name="onka_relevant", type="boolean") */
    private bool $onkaRelevant = false;

    /** @ORM\Column(name="finance_relevant", type="boolean") */
    private bool $financeRelevant = false;

    /** @ORM\Column(name="hide", type="boolean") */
    private bool $hide = false;

    /** @ORM\Column(name="icon", type="string", length=50, nullable=true) */
    private string $icon;

    /** @ORM\Column(name="css_class", type="string", length=50, nullable=true) */
    private string $cssClass;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @param string $sysName
     */
    public function setSysName(string $sysName): void
    {
        $this->sysName = $sysName;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return bool
     */
    public function isSalesRelevant(): bool
    {
        return $this->salesRelevant;
    }

    /**
     * @param bool $salesRelevant
     */
    public function setSalesRelevant(bool $salesRelevant): void
    {
        $this->salesRelevant = $salesRelevant;
    }

    /**
     * @return bool
     */
    public function isOnkaRelevant(): bool
    {
        return $this->onkaRelevant;
    }

    /**
     * @param bool $onkaRelevant
     */
    public function setOnkaRelevant(bool $onkaRelevant): void
    {
        $this->onkaRelevant = $onkaRelevant;
    }

    /**
     * @return bool
     */
    public function isFinanceRelevant(): bool
    {
        return $this->financeRelevant;
    }

    /**
     * @param bool $financeRelevant
     */
    public function setFinanceRelevant(bool $financeRelevant): void
    {
        $this->financeRelevant = $financeRelevant;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }
}
