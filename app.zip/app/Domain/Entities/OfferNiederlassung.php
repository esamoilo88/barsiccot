<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferNiederlassung
 *
 * @ORM\Table(name="Offer_Niederlassung")
 * @ORM\Entity
 */
class OfferNiederlassung
{
    /**
     * @var int
     *
     * @ORM\Column(name="nl_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $nlId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bemerkung", type="text", length=-1, nullable=true)
     */
    private $bemerkung;

    /**
     * @var int|null
     *
     * @ORM\Column(name="sortierung", type="smallint", nullable=true)
     */
    private $sortierung;

    /**
     * @var int|null
     *
     * @ORM\Column(name="sortierung2", type="smallint", nullable=true)
     */
    private $sortierung2;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var int|null
     *
     * @ORM\Column(name="tknl_id", type="integer", nullable=true)
     */
    private $tknlId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ozt", type="string", length=9, nullable=true)
     */
    private $ozt;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @return int
     */
    public function getNlId(): int
    {
        return $this->nlId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
