<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Automailable;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Automail_BeauftragungOrbit")
 */
class v_AutomailBeauftragungOrbit implements Automailable
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="string")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="vorhabenname", type="string", nullable=true)
     */
    private ?string $vorhabenname;
    /**
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private ?string $kundenname;

    /**
     * @ORM\Column(name="vka", type="string", nullable=true)
     */
    private ?string $vka;

    /**
     * @ORM\Column(name="beauftragt_am", type="string", nullable=true)
     */
    private ?string $beauftragtAm;

    /**
     * @ORM\Column(name="an_email", type="string", nullable=true)
     */
    private ?string $anEmail;

    /**
     * @ORM\Column(name="cc_email_1", type="string", nullable=true)
     */
    private ?string $ccEmail1;

    /**
     * @ORM\Column(name="cc_email_2", type="string", nullable=true)
     */
    private ?string $ccEmail2;

    /**
     * @ORM\Column(name="cc_email_3", type="string", nullable=true)
     */
    private ?string $ccEmail3;

    /**
     * @ORM\Column(name="cc_email_4", type="string", nullable=true)
     */
    private ?string $ccEmail4;


    /**
     * @ORM\Column(name="cc_email_5", type="string", nullable=true)
     */
    private ?string $ccEmail5;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simple_id' => $this->simpleId,
            'vorhabenname' => $this->vorhabenname,
            'kundenname' => $this->kundenname,
            'vka' => $this->vka,
            'beauftragt_am' => $this->beauftragtAm,
            'an_email' => $this->anEmail,
            'cc_email_1' => $this->ccEmail1,
            'cc_email_2' => $this->ccEmail2,
            'cc_email_3' => $this->ccEmail3,
            'cc_email_4' => $this->ccEmail4,
            'cc_email_5' => $this->ccEmail5
        ];
    }
}