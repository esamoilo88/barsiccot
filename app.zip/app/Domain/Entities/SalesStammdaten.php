<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * SalesStammdaten
 *
 * @ORM\Table(name="Sales_Stammdaten")
 * @ORM\Entity
 */
class SalesStammdaten
{
    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     */
    private int $simpleId;

    /**
     * @ORM\OneToOne(targetEntity="GlobalGate", fetch="EAGER")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $globalGate;

    /** @ORM\Column(name="bezug_simple_id", type="integer", nullable=true) */
    private ?int $bezugSimpleId;

    /** @ORM\Column(name="stamm_simple_id", type="integer", nullable=true) */
    private ?int $stammSimpleId;

    /** @ORM\Column(name="start_simple_id", type="integer", nullable=true) */
    private ?int $startSimpleId;

    /** @ORM\Column(name="psp_element", type="string", length=50, nullable=true) */
    private ?string $pspElementOld; // this field now is only for backward compatibility

    /** @ORM\Column(name="seceit_vorgangsnr", type="decimal", precision=18, scale=0, nullable=true) */
    private ?string $seceitVorgangsnr;

    /** @ORM\Column(name="kundenname", type="string", length=255, nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="kundennummer", type="string", length=50, nullable=true) */
    private ?string $kundennummer;

    /** @ORM\Column(name="crm_nr", type="string", length=200, nullable=true) */
    private ?string $crmNr;

    /** @ORM\Column(name="kundenstandort", type="string", length=50, nullable=true) */
    private ?string $kundenstandort;

    /** @ORM\Column(name="VAVbenutzer_id", type="integer", nullable=true) */
    private ?int $vavbenutzerId;

    /** @ORM\Column(name="vorhabenbeginn", type="datetime", nullable=false) */
    private DateTime $vorhabenbeginn;

    /** @ORM\Column(name="volumen_dtts", type="decimal", precision=18, scale=2, nullable=false) */
    private string $volumenDtts;

    /** @ORM\Column(name="volumen_gesamt", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $volumenGesamt;

    /** @ORM\Column(name="auftragswahrscheinlichkeit", type="smallint", nullable=true) */
    private ?int $auftragswahrscheinlichkeit;

    /** @ORM\Column(name="laufzeit_in_monaten", type="smallint", nullable=true) */
    private ?int $laufzeitInMonaten;

    /** @ORM\Column(name="AE_monat", type="datetime", nullable=true) */
    private ?DateTime $aeMonat;

    /** @ORM\Column(name="umsatz_monat", type="datetime", nullable=true) */
    private ?DateTime $umsatzMonat;

    /** @ORM\Column(name="must_win_dateline", type="datetime", nullable=true) */
    private ?DateTime $mustWinDateline;

    /** @ORM\Column(name="vorhabenbeschreibung", type="text", length=-1, nullable=true) */
    private ?string $vorhabenbeschreibung;

    /** @ORM\Column(name="statuskommentar", type="text", length=-1, nullable=true) */
    private ?string $statuskommentar;

    /** @ORM\Column(name="vertragsdaten_gesendet_am", type="datetime", nullable=true) */
    private ?DateTime $vertragsdatenGesendetAm;

    /** @ORM\Column(name="bemerkungen_terminreihe", type="text", length=-1, nullable=true) */
    private ?string $bemerkungenTerminreihe;

    /** @ORM\Column(name="config_field_1", type="text", length=-1, nullable=true) */
    private ?string $configField1;

    /** @ORM\Column(name="config_field_2", type="text", length=-1, nullable=true) */
    private ?string $configField2;

    /** @ORM\Column(name="config_field_3", type="text", length=-1, nullable=true) */
    private ?string $configField3;

    /** @ORM\Column(name="config_field_4", type="text", length=-1, nullable=true) */
    private ?string $configField4;

    /** @ORM\Column(name="config_field_5", type="text", length=-1, nullable=true) */
    private ?string $configField5;

    /** @ORM\Column(name="config_field_6", type="text", length=-1, nullable=true) */
    private ?string $configField6;

    /** @ORM\Column(name="config_field_7", type="text", length=-1, nullable=true) */
    private ?string $configField7;

    /** @ORM\Column(name="config_field_8", type="text", length=-1, nullable=true) */
    private ?string $configField8;

    /** @ORM\Column(name="config_field_9", type="text", length=-1, nullable=true) */
    private ?string $configField9;

    /** @ORM\Column(name="config_field_10", type="text", length=-1, nullable=true) */
    private ?string $configField10;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /** @ORM\Column(name="gp_nummer", type="bigint", nullable=true) */
    private ?int $gpNummer;

    /** @ORM\Column(name="ust_id", type="string", length=20, nullable=true) */
    private ?string $ustId;

    /** @ORM\Column(name="use_forecast_as_abgrenzung", type="boolean", nullable=false) */
    private bool $useForecastAsAbgrenzung;

    /** @ORM\Column(name="manual_competence_transfer", type="boolean", nullable=true) */
    private ?bool $manualCompetenceTransfer;

    /** @ORM\Column(name="dive_telekom_reference", type="integer", nullable=true) */
    private ?int $diveTelekomReference;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="FVbenutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $fvbenutzer = null;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="SCbenutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $scbenutzer = null;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="TKBbenutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $tkbbenutzer = null;

    /**
     * @ORM\ManyToOne(targetEntity="CrmGp")
     * @ORM\JoinColumn(name="gp_id", referencedColumnName="gp_id", nullable=true)
     */
    private ?CrmGp $gp;

    /**
     * @ORM\ManyToOne(targetEntity="CrmCustomer")
     * @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
     */
    private ?CrmCustomer $customer = null;

    /**
     * @ORM\OneToOne(targetEntity="FinancePsp")
     * @ORM\JoinColumn(name="psp_element_id", referencedColumnName="id")
     */
    private ?FinancePsp $pspElement = null;

    /**
     * @ORM\OneToOne(targetEntity="CompetenceProject", mappedBy="salesStammdaten")
     */
    private ?CompetenceProject $competenceProject = null;

    /** @ORM\OneToMany(targetEntity="CompetenceElements", mappedBy="salesStammdaten") */
    private Collection $competenceElements;

    /** @ORM\OneToMany(targetEntity="SalesSinLabel", mappedBy="salesStammdaten") */
    private Collection $sinLabels;

    /** @ORM\OneToMany(targetEntity="BackendProjectRoles", mappedBy="salesStammdaten") */
    private Collection $members;

    /** @ORM\OneToMany(targetEntity="BackendProjectGroup", mappedBy="simple") */
    private Collection $groups;

    private array $prioritaetId = [1, 2];

    private int $volume = 50000;

    /**
     * @ORM\OneToOne(targetEntity="SalesAblehnung", mappedBy="salesStammdaten")
     */
    private ?SalesAblehnung $salesAblehnung = null;

    /**
     * @ORM\OneToOne(targetEntity="SalesVersionierung", mappedBy="simple")
     */
    private ?SalesVersionierung $salesVersionierung = null;

    /**
     * SalesStammdaten constructor.
     * @param GlobalGate $globalGate
     * @param int|null $stammSimpleId
     * @param string|null $kundenname
     * @param string|null $kundennummer
     * @param string|null $kundenstandort
     * @param DateTime $vorhabenbeginn
     * @param string $volumenDtts
     * @param string|null $ustId
     * @param int|null $gpNummer
     * @param bool $useForecastAsAbgrenzung
     * @param CrmGp|null $gp
     * @param CrmCustomer|null $customer
     */
    public function __construct(
        GlobalGate $globalGate,
        ?int $stammSimpleId,
        ?string $kundenname,
        ?string $kundennummer,
        ?string $kundenstandort,
        DateTime $vorhabenbeginn,
        string $volumenDtts,
        ?string $ustId,
        ?int $gpNummer,
        bool $useForecastAsAbgrenzung,
        ?CrmGp $gp = null,
        ?CrmCustomer $customer = null
    )
    {
        $this->simpleId = $globalGate->getSimpleId();
        $this->globalGate = $globalGate;
        $this->stammSimpleId = $stammSimpleId;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->kundenstandort = $kundenstandort;
        $this->vorhabenbeginn = $vorhabenbeginn;
        $this->volumenDtts = $volumenDtts;
        $this->ustId = $ustId;
        $this->gpNummer = $gpNummer;
        $this->useForecastAsAbgrenzung = $useForecastAsAbgrenzung;
        $this->gp = $gp;
        $this->competenceElements = new ArrayCollection();
        $this->sinLabels = new ArrayCollection();
        $this->members = new ArrayCollection();
        $this->customer = $customer;
    }

    /**
     * @return GlobalGate
     * @Groups({"projectBasic"})
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }

    /**
     * @return CrmCustomer|null
     * @Groups({"projectBasic"})
     */
    public function getCustomer(): ?CrmCustomer
    {
        return $this->customer;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return $this->globalGate->getSin();
    }

    /**
     * @return bool
     * @Groups({"projectBasic"})
     */
    public function isActive(): bool
    {
        return $this->globalGate->isActive();
    }

    /**
     * @return bool
     */
    public function isPresales(): bool
    {
        return $this->globalGate->isPresales();
    }

    /**
     * @return bool
     */
    public function isPreorder(): bool
    {
        return $this->globalGate->isPreorder();
    }

    /**
     * @return bool
     */
    public function isOnkaWritable(): bool
    {
        return $this->globalGate->isOnkaWriteable();
    }

    /**
     * @return bool
     */
    public function isBillingWriteable(): bool
    {
        return $this->globalGate->isBillingWritable();
    }

    /**
     * @return SalesStatus
     */
    public function getStatus(): SalesStatus
    {
        return $this->globalGate->getSinStatus()->getStatus();
    }

    /**
     * @return string
     * @Groups({"pspDetails"})
     */
    public function getStatusColor(): string
    {
        return $this->globalGate->getSinStatus()->getStatus()->getColor();
    }

    /**
     * @return string
     * @Groups({"pspDetails"})
     */
    public function getStatusShortName(): string
    {
        return $this->globalGate->getSinStatus()->getStatus()->getShortName();
    }

    /**
     * @return string|null
     * @Groups({"pspDetails"})
     */
    public function getThema(): ?string
    {
        return $this->globalGate->getThema();
    }

    /**
     * @param GlobalGate $globalGate
     */
    public function setGlobalGate(GlobalGate $globalGate): void
    {
        $this->globalGate = $globalGate;
    }

    /**
     * @param CrmCustomer|null $customer
     */
    public function setCustomer(?CrmCustomer $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @return int|null
     */
    public function getBezugSimpleId(): ?int
    {
        return $this->bezugSimpleId;
    }

    /**
     * @param int|null $bezugSimpleId
     */
    public function setBezugSimpleId(?int $bezugSimpleId): void
    {
        $this->bezugSimpleId = $bezugSimpleId;
    }

    /**
     * @return int|null
     * @Groups({"projectBasic"})
     */
    public function getStammSimpleId(): ?int
    {
        return $this->stammSimpleId;
    }

    /**
     * @param int|null $stammSimpleId
     */
    public function setStammSimpleId(?int $stammSimpleId): void
    {
        $this->stammSimpleId = $stammSimpleId;
    }

    /**
     * @return int|null
     */
    public function getStartSimpleId(): ?int
    {
        return $this->startSimpleId;
    }

    /**
     * @param int|null $startSimpleId
     */
    public function setStartSimpleId(?int $startSimpleId): void
    {
        $this->startSimpleId = $startSimpleId;
    }

    /**
     * @return FinancePsp|null
     * @Groups({"orderBasic"})
     */
    public function getPspElement(): ?FinancePsp
    {
        return $this->pspElement;
    }

    /**
     * @param FinancePsp|null $pspElement
     */
    public function setPspElement(?FinancePsp $pspElement): void
    {
        $this->pspElement = $pspElement;
    }

    /**
     * @return string|null
     */
    public function getPspElementOld(): ?string
    {
        return $this->pspElementOld;
    }

    /**
     * @param string|null $pspElement
     */
    public function setPspElementOld(?string $pspElement): void
    {
        $this->pspElementOld = $pspElement;
    }

    /**
     * @return string|null
     */
    public function getSeceitVorgangsnr(): ?string
    {
        return $this->seceitVorgangsnr;
    }

    /**
     * @param string|null $seceitVorgangsnr
     */
    public function setSeceitVorgangsnr(?string $seceitVorgangsnr): void
    {
        $this->seceitVorgangsnr = $seceitVorgangsnr;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic", "pspDetails"})
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @param string|null $kundenname
     */
    public function setKundenname(?string $kundenname): void
    {
        $this->kundenname = $kundenname;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getKundennummer(): ?string
    {
        return $this->kundennummer;
    }

    /**
     * @param string|null $kundennummer
     */
    public function setKundennummer(?string $kundennummer): void
    {
        $this->kundennummer = $kundennummer;
    }

    /**
     * @return string|null
     */
    public function getCrmNr(): ?string
    {
        return $this->crmNr;
    }

    /**
     * @param string|null $crmNr
     */
    public function setCrmNr(?string $crmNr): void
    {
        $this->crmNr = $crmNr;
    }

    /**
     * @return string|null
     */
    public function getKundenstandort(): ?string
    {
        return $this->kundenstandort;
    }

    /**
     * @param string|null $kundenstandort
     */
    public function setKundenstandort(?string $kundenstandort): void
    {
        $this->kundenstandort = $kundenstandort;
    }

    /**
     * @return int|null
     */
    public function getVavbenutzerId(): ?int
    {
        return $this->vavbenutzerId;
    }

    /**
     * @param int|null $vavbenutzerId
     */
    public function setVavbenutzerId(?int $vavbenutzerId): void
    {
        $this->vavbenutzerId = $vavbenutzerId;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getVorhabenbeginn(): DateTime
    {
        return $this->vorhabenbeginn;
    }

    /**
     * @param DateTime $vorhabenbeginn
     */
    public function setVorhabenbeginn(DateTime $vorhabenbeginn): void
    {
        $this->vorhabenbeginn = $vorhabenbeginn;
    }

    /**
     * @return string
     * @Groups({"projectBasic", "pspDetails"})
     */
    public function getVolumenDtts(): string
    {
        return $this->volumenDtts;
    }

    /**
     * @param string $volumenDtts
     */
    public function setVolumenDtts(string $volumenDtts): void
    {
        $this->volumenDtts = $volumenDtts;
    }

    /**
     * @return string|null
     */
    public function getVolumenGesamt(): ?string
    {
        return $this->volumenGesamt;
    }

    /**
     * @param string|null $volumenGesamt
     */
    public function setVolumenGesamt(?string $volumenGesamt): void
    {
        $this->volumenGesamt = $volumenGesamt;
    }

    /**
     * @return int|null
     * @Groups({"projectBasic"})
     */
    public function getAuftragswahrscheinlichkeit(): ?int
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @param int|null $auftragswahrscheinlichkeit
     */
    public function setAuftragswahrscheinlichkeit(?int $auftragswahrscheinlichkeit): void
    {
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
    }

    /**
     * @return int|null
     */
    public function getLaufzeitInMonaten(): ?int
    {
        return $this->laufzeitInMonaten;
    }

    /**
     * @param int|null $laufzeitInMonaten
     */
    public function setLaufzeitInMonaten(?int $laufzeitInMonaten): void
    {
        $this->laufzeitInMonaten = $laufzeitInMonaten;
    }

    /**
     * @return DateTime|null
     * @Groups({"projectBasic"})
     */
    public function getAeMonat(): ?DateTime
    {
        return $this->aeMonat;
    }

    /**
     * @param DateTime|null $aeMonat
     */
    public function setAeMonat(?DateTime $aeMonat): void
    {
        $this->aeMonat = $aeMonat;
    }

    /**
     * @return DateTime|null
     * @Groups({"projectBasic"})
     */
    public function getUmsatzMonat(): ?DateTime
    {
        return $this->umsatzMonat;
    }

    /**
     * @param DateTime|null $umsatzMonat
     */
    public function setUmsatzMonat(?DateTime $umsatzMonat): void
    {
        $this->umsatzMonat = $umsatzMonat;
    }

    /**
     * @return DateTime|null
     */
    public function getMustWinDateline(): ?DateTime
    {
        return $this->mustWinDateline;
    }

    /**
     * @param DateTime|null $mustWinDateline
     */
    public function setMustWinDateline(?DateTime $mustWinDateline): void
    {
        $this->mustWinDateline = $mustWinDateline;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getVorhabenbeschreibung(): ?string
    {
        return $this->vorhabenbeschreibung;
    }


    /**
     * @param string|null $vorhabenbeschreibung
     */
    public function setVorhabenbeschreibung(?string $vorhabenbeschreibung): void
    {
        $this->vorhabenbeschreibung = $vorhabenbeschreibung;
    }

    /**
     * @return string|null
     */
    public function getStatuskommentar(): ?string
    {
        return $this->statuskommentar;
    }

    /**
     * @param string|null $statuskommentar
     */
    public function setStatuskommentar(?string $statuskommentar): void
    {
        $this->statuskommentar = $statuskommentar;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsdatenGesendetAm(): ?DateTime
    {
        return $this->vertragsdatenGesendetAm;
    }

    /**
     * @param DateTime|null $vertragsdatenGesendetAm
     */
    public function setVertragsdatenGesendetAm(?DateTime $vertragsdatenGesendetAm): void
    {
        $this->vertragsdatenGesendetAm = $vertragsdatenGesendetAm;
    }

    /**
     * @return string|null
     */
    public function getBemerkungenTerminreihe(): ?string
    {
        return $this->bemerkungenTerminreihe;
    }

    /**
     * @param string|null $bemerkungenTerminreihe
     */
    public function setBemerkungenTerminreihe(?string $bemerkungenTerminreihe): void
    {
        $this->bemerkungenTerminreihe = $bemerkungenTerminreihe;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @return int|null
     */
    public function getGpNummer(): ?int
    {
        return $this->gpNummer;
    }

    /**
     * @param int|null $gpNummer
     */
    public function setGpNummer(?int $gpNummer): void
    {
        $this->gpNummer = $gpNummer;
    }

    /**
     * @return string|null
     */
    public function getUstId(): ?string
    {
        return $this->ustId;
    }

    /**
     * @param string|null $ustId
     */
    public function setUstId(?string $ustId): void
    {
        $this->ustId = $ustId;
    }

    /**
     * @return bool
     */
    public function isUseForecastAsAbgrenzung(): bool
    {
        return $this->useForecastAsAbgrenzung;
    }

    /**
     * @param bool $useForecastAsAbgrenzung
     */
    public function setUseForecastAsAbgrenzung(bool $useForecastAsAbgrenzung): void
    {
        $this->useForecastAsAbgrenzung = $useForecastAsAbgrenzung;
    }

    /**
     * @return bool|null
     */
    public function getManualCompetenceTransfer(): ?bool
    {
        return $this->manualCompetenceTransfer;
    }

    /**
     * @param bool|null $manualCompetenceTransfer
     */
    public function setManualCompetenceTransfer(?bool $manualCompetenceTransfer): void
    {
        $this->manualCompetenceTransfer = $manualCompetenceTransfer;
    }

    /**
     * @return int|null
     */
    public function getDiveTelekomReference(): ?int
    {
        return $this->diveTelekomReference;
    }

    /**
     * @param int|null $diveTelekomReference
     */
    public function setDiveTelekomReference(?int $diveTelekomReference): void
    {
        $this->diveTelekomReference = $diveTelekomReference;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getFvbenutzer(): ?BackendBenutzer
    {
        return $this->fvbenutzer;
    }

    /**
     * @param BackendBenutzer $fvbenutzer
     */
    public function setFvbenutzer(BackendBenutzer $fvbenutzer): void
    {
        $this->fvbenutzer = $fvbenutzer;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getScbenutzer(): ?BackendBenutzer
    {
        return $this->scbenutzer;
    }

    /**
     * @param BackendBenutzer $scbenutzer
     */
    public function setScbenutzer(BackendBenutzer $scbenutzer): void
    {
        $this->scbenutzer = $scbenutzer;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getTkbbenutzer(): ?BackendBenutzer
    {
        return $this->tkbbenutzer;
    }

    /**
     * @param BackendBenutzer $tkbbenutzer
     */
    public function setTkbbenutzer(BackendBenutzer $tkbbenutzer): void
    {
        $this->tkbbenutzer = $tkbbenutzer;
    }

    /**
     * @return bool
     */
    public function hasGp(): bool
    {
        return $this->gp !== null;
    }

    /**
     * @param CrmGp $gp
     */
    public function setGp(CrmGp $gp): void
    {
        $this->gp = $gp;
    }

    /**
     * @return CrmGp
     * @Groups({"projectBasic"})
     */
    public function getGp(): ?CrmGp
    {
        return $this->gp;
    }

    /**
     * @return int
     * @Groups({"pspDetails"})
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }
    /**
     * @return int
     */
    public function getPrioritaetIdBasedOnVolume(): int
    {
        return ($this->getVolumenDtts() > $this->volume) ? $this->prioritaetId[0]: $this->prioritaetId[1];
    }

    /**
     * @param int $volume
     */
    public function setVolume(int $volume): void
    {
        $this->volume = $volume;
    }

    /**
     * @return CompetenceProject|null
     */
    public function getCompetenceProject(): ?CompetenceProject
    {
        return $this->competenceProject;
    }

    /**
     * @return Collection
     */
    public function getCompetenceElements(): Collection
    {
        return $this->competenceElements;
    }

    /**
     * @return Collection
     */
    public function getSinLabels(): Collection
    {
        return $this->sinLabels;
    }

    /**
     * @return Collection
     */
    public function getMembers(): Collection
    {
        return $this->members;
    }

    /**
     * @return SalesAblehnung|null
     */
    public function getSalesAblehnung(): ?SalesAblehnung
    {
        return $this->salesAblehnung;
    }

    /**
     * @return SalesVersionierung|null
     */
    public function getSalesVersionierung(): ?SalesVersionierung
    {
        return $this->salesVersionierung;
    }
}
