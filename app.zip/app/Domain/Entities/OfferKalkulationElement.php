<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;
use App\Domain\Annotations\SystemProtocol as SP;

/**
 * OfferKalkulationElement
 *
 * @ORM\Table(name="Offer_Kalkulation_Element")
 * @ORM\Entity
 * @ORM\EntityListeners({"App\Domain\Listeners\SystemProtocol\SystemProtocolListener"})
 * @SP(
 *   messages={
 *     "created"="Kalkulationselement angelegt",
 *     "updated"="Kalkulationselement bearbeitet",
 *     "removed"="Kalkulationselement gelöscht"
 *   },
 *   group="EL"
 * )
 */
class OfferKalkulationElement implements Loggable
{
    /**
     * @var int
     *
     * @ORM\Column(name="element_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $elementId;

    /** @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=true) */
    private ?float $stundensatz;

    /** @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=18, scale=2, nullable=true) */
    private ?float $stundensatzAlternativ;

    /** @ORM\Column(name="wert", type="decimal", precision=26, scale=16, nullable=true) */
    private ?string $wert;

    /** @ORM\Column(name="gmkz", type="decimal", precision=12, scale=6, nullable=true) */
    private ?float $gmkz = null;

    /**
     * @SP(prettyName="inflationsfaktor anwenden")
     * @ORM\Column(name="if_apply", type="boolean", nullable=true)
     */
    private ?bool $ifApply = null;

    /** @ORM\Column(name="zeitstunden", type="string", length=50, nullable=true) */
    private ?string $zeitstunden;

    /**
     * @SP(prettyName="mengenabhängig")
     * @ORM\Column(name="ma", type="boolean", nullable=false)
     */
    private bool $ma;

    /** @ORM\Column(name="ts_id_kategorie_1", type="integer", nullable=true) */
    private ?int $tsIdKategorie1;

    /** @ORM\Column(name="ts_id_kategorie_2", type="integer", nullable=true) */
    private ?int $tsIdKategorie2;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="kommentar_1", type="text", length=-1, nullable=true) */
    private ?string $kommentar1;

    /** @ORM\Column(name="kommentar_2", type="text", length=-1, nullable=true) */
    private ?string $kommentar2;

    /** @ORM\Column(name="vollkosten", type="decimal", precision=26, scale=16, nullable=true) */
    private ?float $vollkosten;

    /** @ORM\Column(name="festpreis", type="boolean", nullable=true) */
    private ?bool $festpreis;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private \DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private \DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /** @ORM\Column(name="ofi_la", type="integer", nullable=true) */
    private ?int $ofiLa;

    /** @ORM\Column(name="el_katalog_element_id", type="bigint", nullable=true) */
    private ?int $elKatalogElementId;

    /** @ORM\Column(name="lp_katalog_element_id", type="bigint", nullable=true) */
    private ?int $lpKatalogElementId;

    /** @ORM\Column(name="berechnungsart", type="boolean", nullable=true) */
    private ?int $berechnungsart = null;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id", nullable=true)
     */
    private ?CostsKostenstelle $kostenstelle;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $benutzer = null;

    /** @ORM\Column(type="integer", nullable=true) */
    private ?int $kostenartId;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id", nullable=true)
     */
    private ?CostsKostenart $kostenart = null;

    /**
     * @ORM\ManyToOne(targetEntity="ExtTransparenztoolliste")
     * @ORM\JoinColumn(name="ts_id_produkt", referencedColumnName="id_produkt", nullable=true)
     */
    private ?ExtTransparenztoolliste $tsIdProdukt = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private OfferKalkulationLeistungsposition $leistungsposition;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationElement")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="quell_element_id", referencedColumnName="element_id", nullable=true)
     * })
     */
    private ?OfferKalkulationElement $quellElement;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationBerechnung", mappedBy="element", cascade={"remove"}) */
    private Collection $berechnung;

    /** @ORM\OneToMany(targetEntity="v_OfferKalkulationBerechnungGrid", mappedBy="element") */
    private Collection $berechnungGrid;

    /**
     * OfferKalkulationElement constructor.
     * @param  OfferKalkulationLeistungsposition  $leistungsposition
     * @param  bool  $ma
     */
    public function __construct(
        OfferKalkulationLeistungsposition $leistungsposition,
        bool $ma = true
    )
    {
        $this->leistungsposition = $leistungsposition;
        $this->ma = $ma;
        $this->berechnung = new ArrayCollection();
        $this->berechnungGrid = new ArrayCollection();
        $this->stundensatz = floatval(0);
    }

    /**
     * @return OfferKalkulationLeistungsposition
     */
    public function getLeistungsposition(): OfferKalkulationLeistungsposition
    {
        return $this->leistungsposition;
    }

    /**
     * @param  OfferKalkulationLeistungsposition  $leistungsposition
     */
    public function setLeistungsposition(OfferKalkulationLeistungsposition $leistungsposition): void
    {
        $this->leistungsposition = $leistungsposition;
    }

    /**
     * @param OfferKalkulationElement|null $quellElement
     */
    public function setQuellElement(?OfferKalkulationElement $quellElement): void
    {
        $this->quellElement = $quellElement;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getWert(): ?string
    {
        return $this->wert;
    }

    /**
     * @return float|null
     * @Groups({"leistungenPaginated"})
     */
    public function getStundensatz(): ?float
    {
        return $this->stundensatz;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return bool
     */
    public function getMa(): bool
    {
        return $this->ma;
    }

    /**
     * @return float|null
     */
    public function getGmkz(): ?float
    {
        return $this->gmkz;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return bool|null
     */
    public function getIfApply(): ?bool
    {
        return $this->ifApply;
    }

    /**
     * @return OfferKalkulationElement|null
     */
    public function getQuellElement(): ?OfferKalkulationElement
    {
        return $this->quellElement;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return CostsKostenart|null
     */
    public function getKostenart(): ?CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return CostsKostenstelle|null
     */
    public function getKostenstelle(): ?CostsKostenstelle
    {
        return $this->kostenstelle;
    }

    /**
     * @return bool|null
     */
    public function getBerechnungsart(): ?bool
    {
        return $this->berechnungsart;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return float|null
     */
    public function getVollkosten(): ?float
    {
        return $this->vollkosten;
    }

    /**
     * @param string|null $vollkosten
     */
    public function setVollkosten(?string $vollkosten): void
    {
        $this->vollkosten = $vollkosten;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return Collection
     */
    public function getBerechnung(): Collection
    {
        return $this->berechnung;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return Collection
     */
    public function getBerechnungGrid(): Collection
    {
        return $this->berechnungGrid;
    }

    /**
     * @param CostsKostenart|object|null $kostenart
     */
    public function setKostenart(?CostsKostenart $kostenart): void
    {
        $this->kostenart = $kostenart;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param float|null $stundensatz
     */
    public function setStundensatz(?float $stundensatz): void
    {
        $this->stundensatz = $stundensatz;
    }

    /**
     * @return float|null
     */
    public function getStundensatzAlternativ(): ?float
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @param float|null $stundensatzAlternativ
     */
    public function setStundensatzAlternativ(?float $stundensatzAlternativ): void
    {
        $this->stundensatzAlternativ = $stundensatzAlternativ;
    }

    /**
     * @param int|null $ofiLa
     */
    public function setOfiLa(?int $ofiLa): void
    {
        $this->ofiLa = $ofiLa;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }


    /**
     * @param string|null $gmkz
     */
    public function setGmkz($gmkz): void
    {
        $this->gmkz = $gmkz;
    }

    /**
     * @param string|null $wert
     */
    public function setWert(?string $wert): void
    {
        $this->wert = $wert;
    }

    /**
     * @param bool|null $ifApply
     */
    public function setIfApply(?bool $ifApply): void
    {
        $this->ifApply = $ifApply;
    }

    /**
     * @param string|null $zeitstunden
     */
    public function setZeitstunden(?string $zeitstunden): void
    {
        $this->zeitstunden = $zeitstunden;
    }

    /**
     * @param bool $ma
     */
    public function setMa(bool $ma): void
    {
        $this->ma = $ma;
    }

    /**
     * @param int|null $tsIdKategorie1
     */
    public function setTsIdKategorie1(?int $tsIdKategorie1): void
    {
        $this->tsIdKategorie1 = $tsIdKategorie1;
    }

    /**
     * @param int|null $tsIdKategorie2
     */
    public function setTsIdKategorie2(?int $tsIdKategorie2): void
    {
        $this->tsIdKategorie2 = $tsIdKategorie2;
    }

    /**
     * @param ExtTransparenztoolliste|null $tsIdProdukt
     */
    public function setTsIdProdukt(?ExtTransparenztoolliste $tsIdProdukt): void
    {
        $this->tsIdProdukt = $tsIdProdukt;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @param BackendBenutzer|null $benutzer
     */
    public function setBenutzer(?BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param bool|null $festpreis
     */
    public function setFestpreis(?bool $festpreis): void
    {
        $this->festpreis = $festpreis;
    }

    /**
     * @param int|null $lpKatalogElementId
     */
    public function setLpKatalogElementId(?int $lpKatalogElementId): void
    {
        $this->lpKatalogElementId = $lpKatalogElementId;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string|null
     */
    public function getZeitstunden(): ?string
    {
        return $this->zeitstunden;
    }

    /**
     * @return int|null
     */
    public function getTsIdKategorie1(): ?int
    {
        return $this->tsIdKategorie1;
    }

    /**
     * @return int|null
     */
    public function getTsIdKategorie2(): ?int
    {
        return $this->tsIdKategorie2;
    }

    /**
     * @return ExtTransparenztoolliste|null
     */
    public function getTsIdProdukt(): ?ExtTransparenztoolliste
    {
        return $this->tsIdProdukt;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getBenutzer(): ?BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return bool|null
     */
    public function getFestpreis(): ?bool
    {
        return $this->festpreis;
    }

    /**
     * @return int|null
     */
    public function getLpKatalogElementId(): ?int
    {
        return $this->lpKatalogElementId;
    }

    /**
     * @param OfferKalkulationBerechnung $ber
     */
    public function addBer(OfferKalkulationBerechnung $ber)
    {
        $this->berechnung->add($ber);
    }

    /**
     * @param  int|null  $berechnungsart
     */
    public function setBerechnungsart(?int $berechnungsart): void
    {
        $this->berechnungsart = $berechnungsart;
    }

    /**
     * @param  CostsKostenstelle|object|null  $kostenstelle
     */
    public function setKostenstelle(?CostsKostenstelle $kostenstelle): void
    {
        $this->kostenstelle = $kostenstelle;
    }

    /**
     * @param  int|null  $kostenartId
     */
    public function setKostenartId(?int $kostenartId): void
    {
        $this->kostenartId = $kostenartId;
    }

    /**
     * @param Collection $berechnung
     */
    public function setBerechnung(Collection $berechnung): void
    {
        $this->berechnung = $berechnung;
    }

    /**
     * @return int
     */
    public function getElementId(): int
    {
        return $this->elementId;
    }

    ////
    // SystemProtocol functions START
    ////

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return new SIN($this->getLeistungsposition()->getSimple()->getSimpleId());
    }

    /**
     * @return string
     */
    public function getSystemProtocolObjectName(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSystemProtocolParentName(): ?string
    {
        return $this->getLeistungsposition()->getBezeichnung();
    }

    ////
    // SystemProtocol functions END
    ////
}
