<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKatalogKategorie
 *
 * @ORM\Table(name="Offer_Katalog_Kategorie")
 * @ORM\Entity
 */
class OfferKatalogKategorie
{
    /**
     * @var int
     *
     * @ORM\Column(name="kategorie_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $kategorieId;

    /**
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @ORM\Column(name="sort", type="smallint", nullable=true)
     */
    private $sort;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogKategorie")
     * @ORM\JoinColumn(name="parent_kategorie_id", referencedColumnName="kategorie_id")
     */
    private ?OfferKatalogKategorie $parentKategorie= null;

    /** @ORM\OneToMany(targetEntity="BackendBereichkatalog", mappedBy="kategorie")
      * @ORM\JoinColumn(name="kategorie_id", referencedColumnName="kategorie_id")
     */
    private Collection $backendBereichKatalog;

    /**
     * @return OfferKatalogKategorie|null
     */
    public function getParentKategorie(): ?OfferKatalogKategorie
    {
        return $this->parentKategorie;
    }

    /**
     * @return int
     */
    public function getKategorieId(): int
    {
        return $this->kategorieId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
