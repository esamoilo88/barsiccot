<?php

namespace App\Domain\Entities;

use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use phpDocumentor\Reflection\Types\Resource_;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Crm_Customer_Label
 *
 * @ORM\Table(name="Crm_Customer_Label")
 * @ORM\Entity
 */

class CrmCustomerLabel
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="CrmCustomer")
     * @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
     */
    private CrmCustomer $customer;

    /**
     * @ORM\ManyToOne(targetEntity="CrmLabel")
     * @ORM\JoinColumn(name="label_id", referencedColumnName="id")
     */
    private CrmLabel $label;

    /**
     * CrmCustomerLabel constructor.
     * @param CrmCustomer $customer
     * @param CrmLabel $label
     */
    public function __construct(
        CrmCustomer $customer,
        CrmLabel $label
    )
    {
        $this->customer = $customer;
        $this->label = $label;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return CrmCustomer
     */
    public function getCustomer(): CrmCustomer
    {
        return $this->customer;
    }

    /**
     * @return CrmLabel
     */
    public function getLabel(): CrmLabel
    {
        return $this->label;
    }

    /**
     * @return int
     */
    public function getCustomerId(): int
    {
        return $this->customer->getId();
    }

    /**
     * @return int
     */
    public function getLabelId(): int
    {
        return $this->label->getId();
    }

    /**
     * @param CrmLabel $label
     */
    public function setLabel(CrmLabel $label): void
    {
        $this->label = $label;
    }
}
