<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferFakturaMaterialnummer
 *
 * @ORM\Table(name="Offer_Faktura_Materialnummer")
 * @ORM\Entity
 */
class OfferFakturaMaterialnummer
{
    /**
     * @var int
     *
     * @ORM\Column(name="mat_nr_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $matNrId;

    /** @ORM\Column(name="mat_nr", type="integer", nullable=false) */
    private int $matNr = 0;

    /** @ORM\Column(name="bezeichnung", type="string", length=200, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="sort", type="integer", nullable=false) */
    private int $sort;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * @return int
     * @Groups({"orderBasic", "icp"})
     */
    public function getMatNrId(): int
    {
        return $this->matNrId;
    }

    /**
     * @return int
     * @Groups({"orderBasic", "cbiOverview", "icp"})
     */
    public function getMatNr(): int
    {
        return $this->matNr;
    }

    /**
     * @param int $matNr
     */
    public function setMatNr(int $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }
}
