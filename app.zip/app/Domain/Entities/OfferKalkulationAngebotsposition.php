<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;
use App\Domain\Annotations\SystemProtocol as SP;

/**
 * @ORM\Table(name="Offer_Kalkulation_Angebotsposition")
 * @ORM\Entity
 * @ORM\EntityListeners({"App\Domain\Listeners\SystemProtocol\SystemProtocolListener"})
 * @SP(
 *   messages={
 *     "created"="Angebotsposition angelegt",
 *     "updated"="Angebotsposition bearbeitet",
 *     "removed"="Angebotsposition gelöscht"
 *   },
 *   group="AP"
 * )
 */
class OfferKalkulationAngebotsposition implements Loggable
{
    /**
     * @ORM\Column(name="angebotsposition_id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $angebotspositionId;

    /**
     * @ORM\Column(name="seceit_nr", type="integer", nullable=true)
     */
    private ?int $seceitNr;

    /**
     * @ORM\Column(name="ap_nummer", type="string", length=50, nullable=true)
     */
    private ?string $apNummer;

    /**
     * @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true)
     */
    private ?string $bezeichnung;

    /**
     * @ORM\Column(name="menge", type="integer")
     */
    private int $menge;

    /**
     * @ORM\Column(name="vollkosten_individual", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $vollkostenIndividual;

    /**
     * @ORM\Column(name="vollkosten_standard", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $vollkostenStandard;

    /**
     * @ORM\Column(name="vollkosten_gesamt", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $vollkostenGesamt;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $einzelpreisDttsIndividual;

    /**
     * @ORM\Column(name="einzelpreis_dtts_standard", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $einzelpreisDttsStandard;

    /**
     * @ORM\Column(type="decimal", precision=18, scale=2)
     */
    private ?float $einzelpreisDttsGesamt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="transferpreis_dtts_individual", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $transferpreisDttsIndividual;

    /**
     * @ORM\Column(name="transferpreis_dtts_standard", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $transferpreisDttsStandard;

    /**
     * @ORM\Column(name="transferpreis_dtts_gesamt", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $transferpreisDttsGesamt;

    /**
     * @ORM\Column(name="sort", type="integer")
     */
    private int $sort;

    /**
     * @ORM\Column(name="beauftragt", type="boolean")
     */
    private bool $beauftragt;

    /**
     * @ORM\Column(name="deaktiviert", type="boolean")
     */
    private bool $deaktiviert;

    /**
     * @ORM\Column(name="optional", type="boolean")
     */
    private bool $optional;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created", type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="modified", type="datetime")
     */
    private DateTime $modified;

    /**
     * @ORM\Column(name="leistungsposition_id_alt", type="bigint", nullable=true)
     */
    private ?int $leistungspositionIdAlt;

    /**
     * @ORM\Column(name="fpoi", type="boolean", nullable=true)
     */
    private ?bool $fpoi;

    /**
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @ORM\Column(name="preisfaktor", type="decimal", precision=9, scale=2, nullable=true)
     */
    private ?float $preisfaktor;

    /**
     * @ORM\Column(name="unit_price_tp2", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $unitPriceTp2;

    /**
     * @ORM\Column(name="total_price_tp2", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?float $totalPriceTp2;
    /**
     * @ORM\Column(name="preisbildung_art", type="boolean", nullable=true)
     */
    private ?bool $preisbildungArt;

    /** @ORM\Column(name="fixed_price",type="boolean") */
    private bool $fixedPrice;

    /**
     * @ORM\Column(name="marge", type="decimal", precision=9, scale=2, nullable=true)
     */
    private ?float $marge;

    /**
     * @ORM\Column(name="marge_art", type="boolean", nullable=true)
     */
    private ?bool $margeArt;

    /**
     * @ORM\Column(name="myshs_hash", type="string", length=32, nullable=true)
     */
    private ?string $myshsHash;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenPreistyp")
     * @ORM\JoinColumn(name="preistyp_id", referencedColumnName="preistyp_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenPreistyp $preistyp;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogFakturatyp")
     * @ORM\JoinColumn(name="fakturatyp_id", referencedColumnName="fakturatyp_id", nullable=true)
     */
    private ?OfferKatalogFakturatyp $fakturatyp;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenMengentyp")
     * @ORM\JoinColumn(name="mengentyp_id", referencedColumnName="mengentyp_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenMengentyp $mengentyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKalkulationKategorie")
     * @ORM\JoinColumn(name="ap_category_id", referencedColumnName="ap_category_id", nullable=true)
     */
    private ?OfferKalkulationKategorie $apCategory;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="katalog_angebotsposition_id", referencedColumnName="id", nullable=true)
     */
    private ?OfferKatalogAngebotsposition $katalogKategorie;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private ?int $producttypeId = null;

    /** @ORM\Column(type="string", nullable=true) */
    private ?string $beschreibung = null;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaProducttype")
     * @ORM\JoinColumn(name="producttype_id", referencedColumnName="id", nullable=true)
     */
    private ?OnkaProducttype $producttype;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationLeistungsposition", mappedBy="angebotsposition", cascade={"remove"}) */
    private Collection $leistungspositionen;

    /** @ORM\OneToMany(targetEntity="FinanceOrderPosition", mappedBy="angebotsposition", cascade={"remove"}) */
    private Collection $orderpositionen;

    /**
     * OfferKalkulationAngebotsposition constructor.
     * @param SalesStammdaten $simple
     * @param OfferAngebotVk $vkVersions
     * @param BackendBenutzer $benutzer
     * @param int $sort
     * @param bool $optional
     * @param bool $fixedPrice
     * @param int $menge
     */
    public function __construct(
        SalesStammdaten $simple,
        OfferAngebotVk $vkVersions,
        BackendBenutzer $benutzer,
        int $sort,
        bool $optional,
        bool $fixedPrice,
        int $menge
    )
    {
        $this->simple = $simple;
        $this->vkVersions = $vkVersions;
        $this->benutzer = $benutzer;
        $this->sort = $sort;
        $this->optional = $optional;
        $this->fixedPrice = $fixedPrice;
        $this->menge = $menge;

        $this->vollkostenGesamt = floatval(0);
        $this->vollkostenIndividual = floatval(0);
        $this->transferpreisDttsGesamt = floatval(0);
        $this->einzelpreisDttsStandard = floatval(0);
        $this->totalPriceTp2 = floatval(0);
        $this->unitPriceTp2 = floatval(0);
        $this->einzelpreisDttsIndividual = null;
        $this->beauftragt = false;
        $this->deaktiviert = false;
        $this->leistungspositionen = new ArrayCollection();
        $this->orderpositionen = new ArrayCollection();
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @param OnkaProducttype|null $producttype
     */
    public function setProducttype(?OnkaProducttype $producttype): void
    {
        $this->producttype = $producttype;
    }

    /**
     * @param OfferFakturaLbuDatenMengentyp|null $mengentyp
     */
    public function setMengentyp(?OfferFakturaLbuDatenMengentyp $mengentyp): void
    {
        $this->mengentyp = $mengentyp;
    }

    /**
     * @param string|null $vollkostenIndividual
     */
    public function setVollkostenIndividual(?string $vollkostenIndividual): void
    {
        $this->vollkostenIndividual = $vollkostenIndividual;
    }

    /**
     * @param string|null $vollkostenStandard
     */
    public function setVollkostenStandard(?string $vollkostenStandard): void
    {
        $this->vollkostenStandard = $vollkostenStandard;
    }

    /**
     * @param string|null $vollkostenGesamt
     */
    public function setVollkostenGesamt(?string $vollkostenGesamt): void
    {
        $this->vollkostenGesamt = $vollkostenGesamt;
    }

    /**
     * @param float|null $einzelpreisDttsIndividual
     */
    public function setEinzelpreisDttsIndividual(?float $einzelpreisDttsIndividual): void
    {
        $this->einzelpreisDttsIndividual = $einzelpreisDttsIndividual;
    }

    /**
     * @param string|null $einzelpreisDttsStandard
     */
    public function setEinzelpreisDttsStandard(?string $einzelpreisDttsStandard): void
    {
        $this->einzelpreisDttsStandard = $einzelpreisDttsStandard;
    }

    /**
     * @param float|null $einzelpreisDttsGesamt
     */
    public function setEinzelpreisDttsGesamt(?float $einzelpreisDttsGesamt): void
    {
        $this->einzelpreisDttsGesamt = $einzelpreisDttsGesamt;
    }

    /**
     * @param string|null $transferpreisDttsIndividual
     */
    public function setTransferpreisDttsIndividual(?string $transferpreisDttsIndividual): void
    {
        $this->transferpreisDttsIndividual = $transferpreisDttsIndividual;
    }

    /**
     * @param string|null $transferpreisDttsStandard
     */
    public function setTransferpreisDttsStandard(?string $transferpreisDttsStandard): void
    {
        $this->transferpreisDttsStandard = $transferpreisDttsStandard;
    }

    /**
     * @param string|null $transferpreisDttsGesamt
     */
    public function setTransferpreisDttsGesamt(?string $transferpreisDttsGesamt): void
    {
        $this->transferpreisDttsGesamt = $transferpreisDttsGesamt;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @param string $field
     * @param $value
     */
    public function setField(string $field, $value): void
    {
        $this->{$field} = $value;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @Groups({"seceitList"})
     * @return int
     */
    public function getMenge(): int
    {
        return $this->menge;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getBenutzer(): ?BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return bool
     */
    public function isOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @return bool
     */
    public function isFixedPrice(): bool
    {
        return $this->fixedPrice;
    }

    /**
     * @Groups({"mapping", "seceitList"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return OnkaProducttype|null
     */
    public function getProducttype(): ?OnkaProducttype
    {
        return $this->producttype;
    }

    /**
     * @return OfferFakturaLbuDatenMengentyp|null
     */
    public function getMengentyp(): ?OfferFakturaLbuDatenMengentyp
    {
        return $this->mengentyp;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @Groups({"seceitList"})
     * @return float|null
     */
    public function getEinzelpreisDttsIndividual(): ?float
    {
        return $this->einzelpreisDttsIndividual;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDttsGesamt(): ?float
    {
        return $this->einzelpreisDttsGesamt;
    }

    /**
     * @return bool
     */
    public function isBeauftragt(): bool
    {
        return $this->beauftragt;
    }

    /**
     * @return bool
     */
    public function isDeaktiviert(): bool
    {
        return $this->deaktiviert;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDttsStandard(): float
    {
        return $this->einzelpreisDttsStandard;
    }

    /**
     * @return float|null
     */
    public function getUnitPriceTp2(): ?float
    {
        return $this->unitPriceTp2;
    }

    /**
     * @return float|null
     */
    public function getTotalPriceTp2(): ?float
    {
        return $this->totalPriceTp2;
    }


    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @param OfferAngebotVk $vkVersions
     */
    public function setVkVersions(OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param int $menge
     */
    public function setMenge(int $menge): void
    {
        $this->menge = $menge;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @param bool $optional
     */
    public function setOptional(bool $optional): void
    {
        $this->optional = $optional;
    }

    /**
     * @param bool $fixedPrice
     */
    public function setFixedPrice(bool $fixedPrice): void
    {
        $this->fixedPrice = $fixedPrice;
    }

    /**
     * @param OfferFakturaLbuDatenPreistyp|null $preistyp
     */
    public function setPreistyp(?OfferFakturaLbuDatenPreistyp $preistyp): void
    {
        $this->preistyp = $preistyp;
    }

    /**
     * @return float|null
     */
    public function getVollkostenIndividual(): ?float
    {
        return $this->vollkostenIndividual;
    }

    /**
     * @return float|null
     */
    public function getVollkostenGesamt(): ?float
    {
        return $this->vollkostenGesamt;
    }

    /**
     * @return float|null
     */
    public function getTransferpreisDttsGesamt(): ?float
    {
        return $this->transferpreisDttsGesamt;
    }


    /**
     * @param bool $deaktiviert
     */
    public function setDeaktiviert(bool $deaktiviert): void
    {
        $this->deaktiviert = $deaktiviert;
    }

    /**
     * @param float|null $marge
     */
    public function setMarge(?float $marge): void
    {
        $this->marge = $marge;
    }

    /**
     * @param float|null $preisfaktor
     */
    public function setPreisfaktor(?float $preisfaktor): void
    {
        $this->preisfaktor = $preisfaktor;
    }

    /**
     * @param float|null $totalPriceTp2
     */
    public function setTotalPriceTp2(?float $totalPriceTp2): void
    {
        $this->totalPriceTp2 = $totalPriceTp2;
    }

    /**
     * @param float|null $unitPriceTp2
     */
    public function setUnitPriceTp2(?float $unitPriceTp2): void
    {
        $this->unitPriceTp2 = $unitPriceTp2;
    }

    /**
     * @Groups({"mapping", "seceitList"})
     * @return int
     */
    public function getAngebotspositionId(): int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return bool
     */
    public function isApSentToMySHS(): bool
    {
        return $this->myshsHash !== null;
    }

    /**
     * @Groups({"seceitList"})
     * @return ArrayCollection|Collection
     */
    public function getLps()
    {
        return $this->leistungspositionen;
    }

    /**
     * @return bool
     */
    public function isHeadline(): bool
    {
        return substr($this->bezeichnung, 0, 2) == '--';
    }

    /**
     * @return float|null
     */
    public function getPreisfaktor(): ?float
    {
        return $this->preisfaktor;
    }

    /**
     * @param bool|null $preisbildungArt
     */
    public function setPreisbildungArt(?bool $preisbildungArt): void
    {
        $this->preisbildungArt = $preisbildungArt;
    }

    /**
     * @param bool|null $margeArt
     */
    public function setMargeArt(?bool $margeArt): void
    {
        $this->margeArt = $margeArt;
    }

    /**
     * @Groups({"seceitList"})
     * @return int|null
     */
    public function getSeceitNr(): ?int
    {
        return $this->seceitNr;
    }

    /**
     * @return string|null
     */
    public function getApNummer(): ?string
    {
        return $this->apNummer;
    }

    /**
     * @return float|null
     */
    public function getVollkostenStandard(): ?float
    {
        return $this->vollkostenStandard;
    }

    /**
     * @return string|null
     */
    public function getTransferpreisDttsIndividual(): ?string
    {
        return $this->transferpreisDttsIndividual;
    }

    /**
     * @return float|null
     */
    public function getTransferpreisDttsStandard(): ?float
    {
        return $this->transferpreisDttsStandard;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return int|null
     */
    public function getLeistungspositionIdAlt(): ?int
    {
        return $this->leistungspositionIdAlt;
    }

    /**
     * @return bool|null
     */
    public function getFpoi(): ?bool
    {
        return $this->fpoi;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @return bool|null
     */
    public function getPreisbildungArt(): ?bool
    {
        return $this->preisbildungArt;
    }

    /**
     * @return float|null
     */
    public function getMarge(): ?float
    {
        return $this->marge;
    }

    /**
     * @return bool|null
     */
    public function getMargeArt(): ?bool
    {
        return $this->margeArt;
    }

    /**
     * @return string|null
     */
    public function getMyshsHash(): ?string
    {
        return $this->myshsHash;
    }

    /**
     * @return OfferFakturaLbuDatenPreistyp|null
     */
    public function getPreistyp(): ?OfferFakturaLbuDatenPreistyp
    {
        return $this->preistyp;
    }

    /**
     * @return OfferKatalogFakturatyp|null
     */
    public function getFakturatyp(): ?OfferKatalogFakturatyp
    {
        return $this->fakturatyp;
    }

    /**
     * @return OfferKalkulationKategorie|null
     */
    public function getApCategory(): ?OfferKalkulationKategorie
    {
        return $this->apCategory;
    }

    /**
     * @return OfferKatalogAngebotsposition|null
     */
    public function getKatalogKategorie(): ?OfferKatalogAngebotsposition
    {
        return $this->katalogKategorie;
    }

    /**
     * @return int|null
     */
    public function getProducttypeId(): ?int
    {
        return $this->producttypeId;
    }

    /**
     * @return ArrayCollection|Collection
     */
    public function getLeistungspositionen()
    {
        return $this->leistungspositionen;
    }

    /**
     * @param  bool  $beauftragt
     */
    public function setBeauftragt(bool $beauftragt): void
    {
        $this->beauftragt = $beauftragt;
    }


    /**
     * @param  int|null  $seceitNr
     */
    public function setSeceitNr(?int $seceitNr): void
    {
        $this->seceitNr = $seceitNr;
    }

    /**
     * @param  string|null  $apNummer
     */
    public function setApNummer(?string $apNummer): void
    {
        $this->apNummer = $apNummer;
    }

    /**
     * @param  int|null  $leistungspositionIdAlt
     */
    public function setLeistungspositionIdAlt(?int $leistungspositionIdAlt): void
    {
        $this->leistungspositionIdAlt = $leistungspositionIdAlt;
    }

    /**
     * @param  bool|null  $fpoi
     */
    public function setFpoi(?bool $fpoi): void
    {
        $this->fpoi = $fpoi;
    }

    /**
     * @param  DateTime|null  $bits
     */
    public function setBits(?DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @param  string|null  $myshsHash
     */
    public function setMyshsHash(?string $myshsHash): void
    {
        $this->myshsHash = $myshsHash;
    }

    /**
     * @param  OfferKatalogFakturatyp|null  $fakturatyp
     */
    public function setFakturatyp(?OfferKatalogFakturatyp $fakturatyp): void
    {
        $this->fakturatyp = $fakturatyp;
    }

    /**
     * @param  OfferKalkulationKategorie|null  $apCategory
     */
    public function setApCategory(?OfferKalkulationKategorie $apCategory): void
    {
        $this->apCategory = $apCategory;
    }

    /**
     * @param  OfferKatalogAngebotsposition|null  $katalogKategorie
     */
    public function setKatalogKategorie(?OfferKatalogAngebotsposition $katalogKategorie): void
    {
        $this->katalogKategorie = $katalogKategorie;
    }

    /**
     * @param  int|null  $producttypeId
     */
    public function setProducttypeId(?int $producttypeId): void
    {
        $this->producttypeId = $producttypeId;
    }

    /**
     * @param  ArrayCollection|Collection  $leistungspositionen
     */
    public function setLeistungspositionen($leistungspositionen): void
    {
        $this->leistungspositionen = $leistungspositionen;
    }

    /**
     * @return Collection
     */
    public function getOrderpositionen(): Collection
    {
        return $this->orderpositionen;
    }


    ////
    // SystemProtocol functions START
    ////

    /**
     * @return SIN
     * @throws InvalidSinException
     * @throws \Exception
     */
    public function getSin(): SIN
    {
        return new SIN($this->simple->getSimpleId());
    }

    /**
     * @return string
     */
    public function getSystemProtocolObjectName(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getSystemProtocolParentName(): ?string
    {
        return null;
    }

    ////
    // SystemProtocol functions END
    ////
}
