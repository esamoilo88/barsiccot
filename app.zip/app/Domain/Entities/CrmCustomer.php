<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CRM_Customer
 *
 * @ORM\Table(name="CRM_Customer")
 * @ORM\Entity
 */
class CrmCustomer
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="name", type="text", length=200)
     */
    private string $name;

    /**
     * @ORM\Column(name="country", type="text", length=200, nullable=true)
     */
    private ?string $country;

    /**
     * @ORM\Column(name="state", type="text", length=300, nullable=true)
     */
    private ?string $state;

    /**
     * @ORM\Column(name="city", type="text", length=200)
     */
    private string $city= '';

    /**
     * @ORM\Column(name="street", type="text", length=200, nullable=true)
     */
    private ?string $street;

    /**
     * @ORM\Column(name="postal_code", type="text", length=20, nullable=true)
     */
    private ?string $postalCode;

    /**
     * @ORM\Column(name="hn", type="text", length=20, nullable=true)
     */
    private ?string $hn = null;

    /**
     * @ORM\Column(name="logo",type="binary", length=200, nullable=true)
     */
    private $logo = null;

    /**
     * @ORM\Column(name="internal", type="boolean", length=-1)
     */
    private bool $internal;

    /**
     * @ORM\Column(name="is_active", type="boolean")
     */
    private bool $isActive;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @ORM\OneToOne(targetEntity="CrmGp")
     * @ORM\JoinColumn(name="akp_gp_id", referencedColumnName="gp_id", nullable=true)
     */
    private ?CrmGp $crmGp;

    /**
     * @ORM\OneToOne(targetEntity="CrmKunde")
     * @ORM\JoinColumn(name="akp_kunde_id", referencedColumnName="kunde_id", nullable=true)
     */
    private ?CrmKunde $crmKunde;

    /**
     * @ORM\Column(name="akp_gp_nr", type="integer", nullable=true)
     */
    private ?int $akpGpNr;

    /**
     * @ORM\Column(name="akp_gp_name_lang", type="text", length=200, nullable=true)
     */
    private ?string $akpGpNameLang;

    /**
     * @ORM\Column(name="akp_DTAG_kdnr", type="integer", nullable=true)
     */
    private ?int $akpDTAGkdnr;

    /**
     * @ORM\Column(name="akp_zg_id", type="text", length=20, nullable=true)
     */
    private ?string $akpZgId;

    /**
     * @ORM\Column(name="akp_segment", type="text", length=20, nullable=true)
     */
    private ?string $akpSegment;

    /**
     * @ORM\Column(name="akp_zg_bezeichnung", type="text", nullable=true)
     */
    private ?string $akpZgBezeichnung;

    /**
     * @ORM\Column(name="akp_wz_id", type="text", length=10, nullable=true)
     */
    private ?string $akpWzId;

    /**
     * @ORM\Column(name="akp_wz_bezeichnung", type="text", nullable=true)
     */
    private ?string $akpWzBezeichnung;

    /**
     * @ORM\Column(name="akp_ust_id", type="text", length=32, nullable=true)
     */
    private ?string $akpUstId;

    /**
     * @ORM\Column(name="akp_DTAG_name_lang", type="text", nullable=true)
     */
    private ?string $akpDTAGnameLang;

    /** @ORM\OneToMany(targetEntity="CrmContacts", mappedBy="customer", cascade={"remove"}) */
    private Collection $contacts;

    /** @ORM\OneToMany(targetEntity="CrmNote", mappedBy="crmCustomer", cascade={"remove"}) */
    private Collection $notes;

    /**
     * CrmCustomer constructor.
     * @param string $name
     * @param string $city
     * @param bool $isActive
     * @param bool $internal
     * @param CrmGp|null $crmGp
     * @param CrmKunde|null $crmKunde
     * @param int|null $akpGpNr
     * @param string|null $akpGpNameLang
     * @param string|null $akpZgId
     * @param string|null $akpZgBezeichnung
     * @param string|null $akpWzId
     * @param string|null $akpWzBezeichnung
     * @param string|null $akpUstId
     * @param string|null $akpSegment
     * @param string|null $akpDTAGnameLang
     * @param string|null $akpDTAGkdnr
     * @param string|null $postalCode
     */
    public function __construct(
        string $name,
        string $city,
        bool $isActive,
        bool $internal,
        ?CrmGp $crmGp,
        ?CrmKunde $crmKunde,
        ?int $akpGpNr,
        ?string $akpGpNameLang,
        ?string $akpZgId,
        ?string $akpZgBezeichnung,
        ?string $akpWzId,
        ?string $akpWzBezeichnung,
        ?string $akpUstId,
        ?string $akpSegment,
        ?string $akpDTAGnameLang,
        ?string $akpDTAGkdnr,
        ?string $postalCode
    )
    {
        $this->name = $name;
        $this->city = $city;
        $this->isActive = $isActive;
        $this->internal = $internal;
        $this->crmGp = $crmGp;
        $this->crmKunde = $crmKunde;
        $this->akpGpNr = $akpGpNr;
        $this->akpGpNameLang = $akpGpNameLang;
        $this->akpZgId = $akpZgId;
        $this->akpZgBezeichnung = $akpZgBezeichnung;
        $this->akpWzId = $akpWzId;
        $this->akpWzBezeichnung = $akpWzBezeichnung;
        $this->akpUstId = $akpUstId;
        $this->akpSegment = $akpSegment;
        $this->akpDTAGnameLang =$akpDTAGnameLang;
        $this->akpDTAGkdnr =$akpDTAGkdnr;
        $this->postalCode = $postalCode;
        $this->contacts = new ArrayCollection();
        $this->notes = new ArrayCollection();
    }

    /**
     * @return int
     * @Groups({"customerBasis"})
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Groups({"customerBasis"})
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpDTAGnameLang(): ?string
    {
        return $this->akpDTAGnameLang;
    }

    /**
     * @return int|null
     * @Groups({"customerBasis"})
     */
    public function getAkpGpNr(): ?int
    {
        return $this->akpGpNr;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpDTAGkdnr(): ?string
    {
        return $this->akpDTAGkdnr;
    }

    /**
     * @return CrmGp|null
     * @Groups({"customerBasis"})
     */
    public function getCrmGp(): ?CrmGp
    {
        return $this->crmGp;
    }

    /**
     * @return string
     * @Groups({"customerBasis"})
     */
    public function getCity(): string
    {
        return $this->city;
    }

    /**
     * @return bool
     * @Groups({"customerBasis"})
     */
    public function isActive(): bool
    {
        return $this->isActive;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpSegment(): ?string
    {
        return $this->akpSegment;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getState(): ?string
    {
        return $this->state;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpWzBezeichnung(): ?string
    {
        return $this->akpWzBezeichnung;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpZgBezeichnung(): ?string
    {
        return $this->akpZgBezeichnung;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getAkpUstId(): ?string
    {
        return $this->akpUstId;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getHn(): ?string
    {
        return $this->hn;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getStreet(): ?string
    {
        return $this->street;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getPostalCode(): ?string
    {
        return $this->postalCode;
    }

    /**
     * @return string|null
     * @Groups({"customerBasis"})
     */
    public function getCountry(): ?string
    {
        return $this->country;
    }

    /**
     * @return bool
     * @Groups({"customerBasis"})
     */
    public function isInternal(): bool
    {
        return $this->internal;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string|null $street
     */
    public function setStreet(?string $street): void
    {
        $this->street = $street;
    }

    /**
     * @param string $city
     */
    public function setCity(string $city): void
    {
        $this->city = $city;
    }

    /**
     * @param string|null $postalCode
     */
    public function setPostalCode(?string $postalCode): void
    {
        $this->postalCode = $postalCode;
    }

    /**
     * @param string|null $state
     */
    public function setState(?string $state): void
    {
        $this->state = $state;
    }

    /**
     * @param string|null $hn
     */
    public function setHn(?string $hn): void
    {
        $this->hn = $hn;
    }

    /**
     * @param string|null $country
     */
    public function setCountry(?string $country): void
    {
        $this->country = $country;
    }

    /**
     * @param string|null $logo
     */
    public function setLogo(?string $logo): void
    {
        $this->logo = $logo;
    }

    /**
     * @return string
     * @Groups({"customerBasis"})
     */
    public function getLogoBase64(): ?string
    {
        return $this->logo ? 'data:image/png;base64,' . base64_encode(stream_get_contents($this->logo)) : null;
    }

    /**
     * @param bool $internal
     */
    public function setInternal(bool $internal): void
    {
        $this->internal = $internal;
    }

    /**
     * @param bool $isActive
     */
    public function setIsActive(bool $isActive): void
    {
        $this->isActive = $isActive;
    }

    /**
     * @param int|null $akpGpNr
     */
    public function setAkpGpNr(?int $akpGpNr): void
    {
        $this->akpGpNr = $akpGpNr;
    }

    /**
     * @param string|null $akpGpNameLang
     */
    public function setAkpGpNameLang(?string $akpGpNameLang): void
    {
        $this->akpGpNameLang = $akpGpNameLang;
    }

    /**
     * @param int|string|null $akpDTAGkdnr
     */
    public function setAkpDTAGkdnr($akpDTAGkdnr): void
    {
        $this->akpDTAGkdnr = $akpDTAGkdnr;
    }

    /**
     * @param string|null $akpZgId
     */
    public function setAkpZgId(?string $akpZgId): void
    {
        $this->akpZgId = $akpZgId;
    }

    /**
     * @param string|null $akpSegment
     */
    public function setAkpSegment(?string $akpSegment): void
    {
        $this->akpSegment = $akpSegment;
    }

    /**
     * @param string|null $akpZgBezeichnung
     */
    public function setAkpZgBezeichnung(?string $akpZgBezeichnung): void
    {
        $this->akpZgBezeichnung = $akpZgBezeichnung;
    }

    /**
     * @param string|null $akpWzId
     */
    public function setAkpWzId(?string $akpWzId): void
    {
        $this->akpWzId = $akpWzId;
    }

    /**
     * @param string|null $akpWzBezeichnung
     */
    public function setAkpWzBezeichnung(?string $akpWzBezeichnung): void
    {
        $this->akpWzBezeichnung = $akpWzBezeichnung;
    }

    /**
     * @param string|null $akpUstId
     */
    public function setAkpUstId(?string $akpUstId): void
    {
        $this->akpUstId = $akpUstId;
    }

    /**
     * @param string|null $akpDTAGnameLang
     */
    public function setAkpDTAGnameLang(?string $akpDTAGnameLang): void
    {
        $this->akpDTAGnameLang = $akpDTAGnameLang;
    }

    /**
     * @return CrmKunde|null
     */
    public function getCrmKunde(): ?CrmKunde
    {
        return $this->crmKunde;
    }

    /**
     * @return array
     */
    public static function getInternalSegments(): array
    {
        return array_map('trim', explode(',', config('dbconfig.create_project.INTERNAL_CUSTOMER_SEGMENT')));
    }

    /**
     * @return array
     */
    public static function getExternalSegments(): array
    {
        return array_map('trim', explode(',', config('dbconfig.create_project.EXTERNAL_CUSTOMER_SEGMENT')));
    }

    /**
     * @param string $segment
     * @return bool
     */
    public static function isSegmentInternal(string $segment): bool
    {
        return in_array($segment, self::getInternalSegments());
    }

    /**
     * @return int
     * @Groups({"customerBasis"})
     */
    public function getContactsCount(): int
    {
        return $this->contacts->count();
    }

    /**
     * @return int
     * @Groups({"customerBasis"})
     */
    public function getNotesCount(): int
    {
        return $this->notes->count();
    }
}
