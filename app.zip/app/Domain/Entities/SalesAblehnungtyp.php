<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesAblehnungtyp
 *
 * @ORM\Table(name="Sales_AblehnungTyp")
 * @ORM\Entity
 */
class SalesAblehnungtyp
{
    /**
     * @var int
     *
     * @ORM\Column(name="ablehnungTyp_id", type="smallint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $ablehnungtypId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @return int
     */
    public function getAblehnungtypId(): int
    {
        return $this->ablehnungtypId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
