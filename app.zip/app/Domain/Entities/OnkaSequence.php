<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class OnkaSequence
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Sequence")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaSequence
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="short_name", type="string") */
    private string $shortName;

    /** @ORM\Column(type="string") */
    private string $name;

    /** @ORM\Column(type="string") */
    private string $icon;

    /** @ORM\Column(type="boolean") */
    private bool $distribution;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * OnkaSequence constructor.
     * @param string $shortName
     * @param string $name
     * @param string $icon
     * @param bool $distribution
     */
    public function __construct(string $shortName, string $name, string $icon, bool $distribution)
    {
        $this->shortName = $shortName;
        $this->name = $name;
        $this->icon = $icon;
        $this->distribution = $distribution;
    }

    /**
     * @return string
     */
    public function getShortName(): string
    {
        return $this->shortName;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getIcon(): string
    {
        return $this->icon;
    }

    /**
     * @return bool
     */
    public function isDistribution(): bool
    {
        return $this->distribution;
    }
}
