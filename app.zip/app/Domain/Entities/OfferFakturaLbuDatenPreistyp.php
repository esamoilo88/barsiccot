<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;


/**
 * OfferFakturaLbuDatenPreistyp
 *
 * @ORM\Table(name="Offer_Faktura_LBU_Daten_Preistyp")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferFakturaLbuDatenPreistyp
{
    /**
     * @var int
     *
     * @ORM\Column(name="preistyp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $preistypId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abkürzung", type="string", length=50, nullable=true)
     */
    private $abk�rzung;

    /**
     * @var int|null
     *
     * @ORM\Column(name="sort", type="smallint", nullable=true)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="recurrent_payment", type="boolean", nullable=true)
     */
    private ?bool $recurrentPayment;

    /**
     * @return int
     */
    public function getPreistypId(): int
    {
        return $this->preistypId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return bool|null
     */
    public function getRecurrentPayment(): ?bool
    {
        return $this->recurrentPayment;
    }
}
