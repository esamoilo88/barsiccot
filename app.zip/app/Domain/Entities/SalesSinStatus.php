<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * SalesSinStatus
 *
 * @ORM\Table(name="Sales_SIN_Status")
 * @ORM\Entity
 */
class SalesSinStatus
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\OneToOne(targetEntity="GlobalGate", inversedBy="sinStatus")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $globalGate;

    /**
     * @ORM\OneToOne(targetEntity="SalesStatus", fetch="EAGER")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private SalesStatus $status;

    /**
     * SalesSinStatus constructor.
     * @param GlobalGate $globalGate
     * @param SalesStatus $status
     */
    public function __construct(GlobalGate $globalGate, SalesStatus $status)
    {
        $this->globalGate = $globalGate;
        $this->status = $status;
    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }

    /**
     * @return SalesStatus
     * @Groups({"projectBasic"})
     */
    public function getStatus(): SalesStatus
    {
        return $this->status;
    }

    /**
     * @param SalesStatus $status
     * @return void
     */
    public function setStatus(SalesStatus $status): void
    {
        $this->status = $status;
    }
}
