<?php

namespace App\Domain\Entities;

use App\Exceptions\Business\ValidationException;
use App\Utils\SimpleValidator\SimpleValidator;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Illuminate\Contracts\Container\BindingResolutionException;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferAuftrag
 *
 * @ORM\Table(name="Offer_Auftrag")
 * @ORM\Entity
 */
class OfferAuftrag
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\OneToOne(targetEntity="SalesVersionierung")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesVersionierung $salesVersionierung;

    /** @ORM\Column(name="bezug_simple_id", type="integer", nullable=true) */
    private ?int $bezugSimpleId;

    /** @ORM\Column(name="debitor_id", type="integer", nullable=true) */
    private ?int $debitorId = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferDebitor")
     * @ORM\JoinColumn(name="debitor_id", referencedColumnName="debitor_id", nullable=true)
     */
    private ?OfferDebitor $offerDebitor;

    /** @ORM\Column(name="auftragsdatum", type="datetime", nullable=true) */
    private ?DateTime $auftragsdatum;

    /** @ORM\Column(name="av_zugewiesen_am", type="datetime", nullable=true) */
    private ?DateTime $avZugewiesenAm;

    /** @ORM\Column(name="tsi_kontierung", type="string", length=150, nullable=true) */
    private ?string $tsiKontierung;

    /** @ORM\Column(name="sap_auftrags_nr", type="text", length=-1, nullable=true) */
    private ?string $sapAuftragsNr;

    /** @ORM\Column(name="buchungskreis", type="string", length=50, nullable=true) */
    private ?string $buchungskreis;

    /** @ORM\Column(name="partnergesellschaft", type="string", length=150, nullable=true) */
    private ?string $partnergesellschaft;

    /** @ORM\Column(name="doknr_efs", type="string", length=50, nullable=true) */
    private ?string $doknrEfs;

    /** @ORM\Column(name="kommentar_faktura", type="text", length=-1, nullable=true) */
    private ?string $kommentarFaktura;

    /** @ORM\Column(name="kommentar_kosten", type="text", length=-1, nullable=true) */
    private ?string $kommentarKosten;

    /** @ORM\Column(name="abgeschlossen_dateline", type="datetime", nullable=true) */
    private ?DateTime $abgeschlossenDateline;

    /** @ORM\Column(name="zdf_factory_id", type="integer", nullable=true) */
    private ?int $zdfFactoryId;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaMaterialnummer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="mat_nr_id", referencedColumnName="mat_nr_id")
     * })
     */
    private ?OfferFakturaMaterialnummer $matNr;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaFakturaziel")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="default_fakturaziel_id", referencedColumnName="fakturaziel_id")
     * })
     */
    private ?OfferFakturaFakturaziel $defaultFakturaziel;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenSachkonto")
     * @ORM\JoinColumn(name="default_icp_kont_konto_id", referencedColumnName="konto_id", nullable=true)
     */
    private ?OfferFakturaLbuDatenSachkonto $defaultIcpKontKonto;

    /** @ORM\Column(name="default_icp_kont_psp_kst", type="string", length=50, nullable=true) */
    private ?string $defaultIcpKontPspKst;

    /** @ORM\Column(name="lbu_auto_confirm", type="boolean", nullable=true) */
    private ?bool $lbuAutoConfirm;

    /** @ORM\Column(name="billing_subject_extension", type="string", length=150, nullable=true) */
    private ?string $billingSubjectExtension;

    /** @ORM\Column(name="lbu_auto_creation", type="boolean", nullable=true) */
    private ?bool $lbuAutoCreation;

    /** @ORM\Column(name="lbu_auto_send", type="boolean", nullable=true) */
    private ?bool $lbuAutoSend;

    /** @ORM\Column(name="dauerfreigabe", type="boolean", nullable=true) */
    private ?bool $dauerfreigabe;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="AV2benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $av2benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="AVbenutzer_id", referencedColumnName="benutzer_id", nullable = true)
     */
    private ?BackendBenutzer $avbenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="default_ansprechpartner_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $defaultAnsprechpartner;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="EV1benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $ev1benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="EV2benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $ev2benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAbgeschlossengrund")
     * @ORM\JoinColumn(name="abgeschlossenGrund_id", referencedColumnName="abgeschlossenGrund_id")
     */
    private ?OfferAbgeschlossengrund $abgeschlossengrund;

    /**
     * @ORM\ManyToOne(targetEntity="OfferProfitcenterSettings")
     * @ORM\JoinColumn(name="profitcenter_settings_id", referencedColumnName="profitcenter_settings_id")
     */
    private ?OfferProfitcenterSettings $profitcenterSettings = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbu")
     * @ORM\JoinColumn(name="lbu_id_auto_creation", referencedColumnName="lbu_id")
     */
    private ?OfferFakturaLbu $lbuIdAutoCreation;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="lbu_auto_send_benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $lbuAutoSendBenutzer;


    /** @ORM\OneToMany(targetEntity="FinanceOrder", mappedBy="simpleId") */
    private Collection $financeOrders;

    /** @ORM\Column(name="cbi_sin_control", type="boolean", nullable=true) */
    private ?bool $cbiSinControl;

    /**
     * OfferAuftrag constructor.
     * @param SalesVersionierung $simpleId
     * @param string|null $sapAuftragsNr
     * @param OfferDebitor $debitor
     * @param OfferProfitcenterSettings|null $profitcenterSettings
     * @param bool|null $lbuAutoConfirm
     * @param bool|null $lbuAutoCreation
     * @param bool|null $dauerfreigabe
     */
    public function __construct(
        SalesVersionierung $simpleId,
        ?string $sapAuftragsNr,
        OfferDebitor $debitor,
        ?OfferProfitcenterSettings $profitcenterSettings,
        ?bool $lbuAutoConfirm,
        ?bool $lbuAutoCreation,
        ?bool $dauerfreigabe
    )
    {
        $this->simpleId = $simpleId->getSimpleId();
        $this->sapAuftragsNr = $sapAuftragsNr;
        $this->offerDebitor = $debitor;
        $this->debitorId = $debitor->getDebitorId();
        $this->profitcenterSettings = $profitcenterSettings;
        $this->lbuAutoConfirm = $lbuAutoConfirm;
        $this->lbuAutoCreation = $lbuAutoCreation;
        $this->dauerfreigabe = $dauerfreigabe;
        $this->financeOrders = new ArrayCollection();
    }

    /**
     * @Groups({"cbiOverview", "icp"})
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return SalesVersionierung
     */
    public function getSalesVersionierung(): SalesVersionierung
    {
        return $this->salesVersionierung;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getAvbenutzer(): ?BackendBenutzer
    {
        return $this->avbenutzer;
    }

    /**
     * @return string|null
     */
    public function getSapAuftragsNr(): ?string
    {
        return $this->sapAuftragsNr;
    }

    /**
     * @return INT|null
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return OfferDebitor|null
     */
    public function getOfferDebitor(): ?OfferDebitor
    {
        return $this->offerDebitor;
    }

    /**
     * @return OfferProfitcenterSettings|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getProfitcenterSettings(): ?OfferProfitcenterSettings
    {
        return $this->profitcenterSettings;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoCreation(): ?bool
    {
        return $this->lbuAutoCreation;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoConfirm(): ?bool
    {
        return $this->lbuAutoConfirm;
    }

    /**
     * @return string|null
     * @Groups({"icp"})
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoSend(): ?bool
    {
        return $this->lbuAutoSend;
    }

    /**
     * @return bool|null
     * @Groups({"orderBasic"})
     */
    public function getDauerfreigabe(): ?bool
    {
        return $this->dauerfreigabe;
    }

    /**
     * @return \DateTime|null
     */
    public function getAuftragsdatum(): ?\DateTime
    {
        return $this->auftragsdatum;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @param SalesVersionierung $salesVersionierung
     */
    public function setSalesVersionierung(SalesVersionierung $salesVersionierung): void
    {
        $this->salesVersionierung = $salesVersionierung;
    }

    /**
     * @param BackendBenutzer|null $avbenutzer
     */
    public function setAvBenutzer(?BackendBenutzer $avbenutzer): void
    {
        $this->avbenutzer = $avbenutzer;
    }

    /**
     * @param string $sapAuftragsNr
     */
    public function setSapAuftragsNr(string $sapAuftragsNr): void
    {
        $this->sapAuftragsNr = $sapAuftragsNr;
    }

    /**
     * @param int $debitorId
     */
    public function setDebitorId(int $debitorId): void
    {
        $this->debitorId = $debitorId;
    }

    /**
     * @param OfferProfitcenterSettings $profitcenterSettings
     */
    public function setProfitcenterSettings(OfferProfitcenterSettings $profitcenterSettings):void
    {
        $this->profitcenterSettings = $profitcenterSettings;
    }

    /**
     * @param bool $lbuAutoCreation
     */
    public function setLbuAutoCreation(bool $lbuAutoCreation): void
    {
        $this->lbuAutoCreation = $lbuAutoCreation;
    }

    /**
     * @param bool $lbuAutoConfirm
     */
    public function setLbuAutoConfirm(bool $lbuAutoConfirm): void
    {
        $this->lbuAutoConfirm = $lbuAutoConfirm;
    }

    /**
     * @param string|null $billingSubjectExtension
     */
    public function setBillingSubjectExtension(?string $billingSubjectExtension): void
    {
        $this->billingSubjectExtension = $billingSubjectExtension;
    }

    /**
     * @param bool $lbuAutoSend
     */
    public function setLbuAutoSend(bool $lbuAutoSend): void
    {
        $this->lbuAutoSend = $lbuAutoSend;
    }

    /**
     * @param bool $dauerfreigabe
     */
    public function setDauerfreigabe(bool $dauerfreigabe): void
    {
        $this->dauerfreigabe = $dauerfreigabe;
    }

    /**
     * @param \DateTime $auftragsdatum
     */
    public function setAuftragsdatum(\DateTime $auftragsdatum): void
    {
        $this->auftragsdatum = $auftragsdatum;
    }

    /**
     * @return int|null
     */
    public function getBezugSimpleId(): ?int
    {
        return $this->bezugSimpleId;
    }

    /**
     * @param int|null $bezugSimpleId
     */
    public function setBezugSimpleId(?int $bezugSimpleId): void
    {
        $this->bezugSimpleId = $bezugSimpleId;
    }

    /**
     * @return DateTime|null
     */
    public function getAvZugewiesenAm(): ?DateTime
    {
        return $this->avZugewiesenAm;
    }

    /**
     * @param DateTime|null $avZugewiesenAm
     */
    public function setAvZugewiesenAm(?DateTime $avZugewiesenAm): void
    {
        $this->avZugewiesenAm = $avZugewiesenAm;
    }

    /**
     * @return string|null
     */
    public function getTsiKontierung(): ?string
    {
        return $this->tsiKontierung;
    }

    /**
     * @param string|null $tsiKontierung
     */
    public function setTsiKontierung(?string $tsiKontierung): void
    {
        $this->tsiKontierung = $tsiKontierung;
    }

    /**
     * @return string|null
     */
    public function getBuchungskreis(): ?string
    {
        return $this->buchungskreis;
    }

    /**
     * @param string|null $buchungskreis
     */
    public function setBuchungskreis(?string $buchungskreis): void
    {
        $this->buchungskreis = $buchungskreis;
    }

    /**
     * @return string|null
     */
    public function getPartnergesellschaft(): ?string
    {
        return $this->partnergesellschaft;
    }

    /**
     * @param string|null $partnergesellschaft
     */
    public function setPartnergesellschaft(?string $partnergesellschaft): void
    {
        $this->partnergesellschaft = $partnergesellschaft;
    }

    /**
     * @return string|null
     */
    public function getDoknrEfs(): ?string
    {
        return $this->doknrEfs;
    }

    /**
     * @param string|null $doknrEfs
     */
    public function setDoknrEfs(?string $doknrEfs): void
    {
        $this->doknrEfs = $doknrEfs;
    }

    /**
     * @return string|null
     */
    public function getKommentarFaktura(): ?string
    {
        return $this->kommentarFaktura;
    }

    /**
     * @param string|null $kommentarFaktura
     */
    public function setKommentarFaktura(?string $kommentarFaktura): void
    {
        $this->kommentarFaktura = $kommentarFaktura;
    }

    /**
     * @return string|null
     */
    public function getKommentarKosten(): ?string
    {
        return $this->kommentarKosten;
    }

    /**
     * @param string|null $kommentarKosten
     */
    public function setKommentarKosten(?string $kommentarKosten): void
    {
        $this->kommentarKosten = $kommentarKosten;
    }

    /**
     * @return bool
     */
    public function hasAbgeschlossenDateline(): bool
    {
        return isset($this->abgeschlossenDateline);
    }

    /**
     * @return DateTime|null
     */
    public function getAbgeschlossenDateline(): ?DateTime
    {
        return $this->abgeschlossenDateline;
    }

    /**
     * @param DateTime|null $abgeschlossenDateline
     */
    public function setAbgeschlossenDateline(?DateTime $abgeschlossenDateline): void
    {
        $this->abgeschlossenDateline = $abgeschlossenDateline;
    }

    /**
     * @return int|null
     */
    public function getZdfFactoryId(): ?int
    {
        return $this->zdfFactoryId;
    }

    /**
     * @param int|null $zdfFactoryId
     */
    public function setZdfFactoryId(?int $zdfFactoryId): void
    {
        $this->zdfFactoryId = $zdfFactoryId;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @param DateTime|null $bits
     */
    public function setBits(?DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return OfferFakturaMaterialnummer|null
     * @Groups({"orderBasic"})
     */
    public function getMatNr(): ?OfferFakturaMaterialnummer
    {
        return $this->matNr;
    }

    /**
     * @param OfferFakturaMaterialnummer|null|object $matNr
     */
    public function setMatNr(?OfferFakturaMaterialnummer $matNr): void
    {
        $this->matNr = $matNr;
    }

    /**
     * @return OfferFakturaFakturaziel|null
     * @Groups({"orderBasic"})
     */
    public function getDefaultFakturaziel(): ?OfferFakturaFakturaziel
    {
        return $this->defaultFakturaziel;
    }

    /**
     * @param OfferFakturaFakturaziel|null|object $defaultFakturaziel
     */
    public function setDefaultFakturaziel(?OfferFakturaFakturaziel $defaultFakturaziel): void
    {
        $this->defaultFakturaziel = $defaultFakturaziel;
    }

    /**
     * @return OfferFakturaLbuDatenSachkonto|null
     * @Groups({"orderBasic"})
     */
    public function getDefaultIcpKontKonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->defaultIcpKontKonto;
    }

    /**
     * @param OfferFakturaLbuDatenSachkonto|null|object $defaultIcpKontKonto
     */
    public function setDefaultIcpKontKonto(?OfferFakturaLbuDatenSachkonto $defaultIcpKontKonto): void
    {
        $this->defaultIcpKontKonto = $defaultIcpKontKonto;
    }

    /**
     * @return string|null
     * @Groups({"orderBasic", "icp"})
     */
    public function getDefaultIcpKontPspKst(): ?string
    {
        return $this->defaultIcpKontPspKst;
    }

    /**
     * @param string|null $defaultIcpKontPspKst
     * @throws ValidationException
     * @throws BindingResolutionException
     * @throws \ReflectionException
     */
    public function setDefaultIcpKontPspKst(?string $defaultIcpKontPspKst): void
    {
        $data = [
            'icpKontPspKst' => $defaultIcpKontPspKst,
            'debitorId' => $this->getDebitorId()
        ];

        $validator = new SimpleValidator($data, 'Finance', [], null, true);
        $validationResult = $validator->validate();

        if (!$validationResult->isValid()) {
            throw new ValidationException(
                'Validation for icpKontPspKst and debitorId is failed',
                422,
                null,
                $validationResult
            );
        }

        $this->defaultIcpKontPspKst = $defaultIcpKontPspKst;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getAv2benutzer(): ?BackendBenutzer
    {
        return $this->av2benutzer;
    }

    /**
     * @param BackendBenutzer $av2benutzer
     */
    public function setAv2benutzer(BackendBenutzer $av2benutzer): void
    {
        $this->av2benutzer = $av2benutzer;
    }

    /**
     * @return BackendBenutzer|null
     * @Groups({"icp"})
     */
    public function getDefaultAnsprechpartner(): ?BackendBenutzer
    {
        return $this->defaultAnsprechpartner;
    }

    /**
     * @param BackendBenutzer $defaultAnsprechpartner
     */
    public function setDefaultAnsprechpartner(BackendBenutzer $defaultAnsprechpartner): void
    {
        $this->defaultAnsprechpartner = $defaultAnsprechpartner;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getEv1benutzer(): ?BackendBenutzer
    {
        return $this->ev1benutzer;
    }

    /**
     * @param BackendBenutzer $ev1benutzer
     */
    public function setEv1benutzer(BackendBenutzer $ev1benutzer): void
    {
        $this->ev1benutzer = $ev1benutzer;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getEv2benutzer(): ?BackendBenutzer
    {
        return $this->ev2benutzer;
    }

    /**
     * @param BackendBenutzer $ev2benutzer
     */
    public function setEv2benutzer(BackendBenutzer $ev2benutzer): void
    {
        $this->ev2benutzer = $ev2benutzer;
    }

    /**
     * @return OfferAbgeschlossengrund|null
     */
    public function getAbgeschlossengrund(): ?OfferAbgeschlossengrund
    {
        return $this->abgeschlossengrund;
    }

    /**
     * @param OfferAbgeschlossengrund $abgeschlossengrund
     */
    public function setAbgeschlossengrund(OfferAbgeschlossengrund $abgeschlossengrund): void
    {
        $this->abgeschlossengrund = $abgeschlossengrund;
    }

    /**
     * @return OfferFakturaLbu|null
     */
    public function getLbuIdAutoCreation(): ?OfferFakturaLbu
    {
        return $this->lbuIdAutoCreation;
    }

    /**
     * @param OfferFakturaLbu $lbuIdAutoCreation
     */
    public function setLbuIdAutoCreation(OfferFakturaLbu $lbuIdAutoCreation): void
    {
        $this->lbuIdAutoCreation = $lbuIdAutoCreation;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getLbuAutoSendBenutzer(): ?BackendBenutzer
    {
        return $this->lbuAutoSendBenutzer;
    }

    /**
     * @param BackendBenutzer $lbuAutoSendBenutzer
     */
    public function setLbuAutoSendBenutzer(BackendBenutzer $lbuAutoSendBenutzer): void
    {
        $this->lbuAutoSendBenutzer = $lbuAutoSendBenutzer;
    }

    /**
     * @param OfferDebitor|null $offerDebitor
     */
    public function setOfferDebitor(?OfferDebitor $offerDebitor): void
    {
        $this->offerDebitor = $offerDebitor;
    }

    /**
     * @return Collection
     */
    public function getFinanceOrders(): Collection
    {
        return $this->financeOrders;
    }

    /**
     * @return bool|null
     * @Groups({"icp"})
     */
    public function isCbiSinControl(): ?bool
    {
        return $this->cbiSinControl;
    }

    /**
     * @return bool|null
     * @Groups({"icp"})
     */
    public function isCbiUsePcs(): ?bool
    {
        return $this->profitcenterSettings->isCbiUsePcs();
    }

    /**
     * @param bool|null $cbiSinControl
     */
    public function setCbiSinControl(?bool $cbiSinControl): void
    {
        $this->cbiSinControl = $cbiSinControl;
    }

    /**
     * @return bool|null
     * @Groups({"icp"})
     */
    public function getExternal(): ?bool
    {
        return $this->getProfitcenterSettings()->getExternal();
    }

    /**
     * @return bool
     * @Groups({"icp"})
     */
    public function isHardBilling(): bool
    {
        return $this->profitcenterSettings->getBillingType()->isHardBilling();
    }

    /**
     * @return array
     * @Groups({"icp"})
     */
    public function getIcpData(): array
    {
        $isHardBilling = $this->getProfitcenterSettings()->getBillingType()->isHardBilling();
        $isCbiUsePcs = $this->getProfitcenterSettings()->isCbiUsePcs();
        $isCbiSinControl = $this->isCbiSinControl();

        if ($isHardBilling) {
            return $this->getIcpDataAuftrag();
        }

        if ($isCbiUsePcs && !$isCbiSinControl) {
            return $this->getIcpDataProfitcenter();
        }

        return $this->getIcpDataAuftrag();
    }

    /**
     * @return array
     * @Groups({"icp"})
     */
    public function getIcpDataAuftrag(): array
    {
        return [
            'icpKontPspKst' => $this->getDefaultIcpKontPspKst(),
            'debitor' => $this->getOfferDebitor(),
            'fakturaziel' => $this->getDefaultFakturaziel(),
            'icpKontKonto' => $this->getDefaultIcpKontKonto(),
            'matNr' => $this->getMatNr(),
        ];
    }

    /**
     * @return array
     */
    public function getIcpDataProfitcenter(): array
    {
        return $this->getProfitcenterSettings()->getIcpData();
    }

    /**
     * @return FinancePsp|null
     * @Groups({"icp"})
     */
    public function getPspElement(): ?FinancePsp
    {
        return $this->salesVersionierung->getSimple()->getPspElement();
    }
}
