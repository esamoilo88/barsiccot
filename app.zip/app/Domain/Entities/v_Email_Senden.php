<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Illuminate\Support\Carbon;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Email_Senden")
 */
class v_Email_Senden
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="thema", type="string", nullable=true)
     */
    private ?string $thema;

    /**
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private $kundenname;

    /**
     * @ORM\Column(name="kundennummer", type="integer", nullable=true)
     */
    private ?int $kundennummer;

    /**
     *
     * @ORM\Column(name="versionsnr", type="integer", nullable=true)
     */
    private $versionsnr;

    /**
     * @ORM\Column(name="TSIEMail", type="string", nullable=true)
     */
    private $TSIEMail;

    /**
     * @ORM\Column(name="TSIVorname", type="string", nullable=true)
     */
    private $TSIVorname;

    /**
     * @ORM\Column(name="TSINachname", type="string", nullable=true)
     */
    private $TSINachname;

    /**
     * @ORM\Column(name="AnEMail", type="string", nullable=true)
     */
    private $AnEMail;

    /**
     * @ORM\Column(name="AnVorname", type="string", nullable=true)
     */
    private $AnVorname;

    /**
     * @ORM\Column(name="AnNachname", type="string", nullable=true)
     */
    private $AnNachname;

    /**
     * @ORM\Column(name="VonEMail", type="string", nullable=true)
     */
    private $VonEMail;

    /**
     * @ORM\Column(name="VonVorname", type="string", nullable=true)
     */
    private $VonVorname;

    /**
     * @ORM\Column(name="VonNachname", type="string", nullable=true)
     */
    private $VonNachname;

    /**
     * @ORM\Column(name="tp_dtts_gesamt", type="string", nullable=true)
     */
    private $tpDttsGesamt;

    /**
     * @ORM\Column(name="kundenstandort", type="string", nullable=true)
     */
    private $kundenstandort;


    /**
     * @ORM\Column(name="VSAG_Bezeichnung", type="string", nullable=true)
     */
    private $VSAGBezeichnung;

    /**
     * @ORM\Column(name="PRODC_Bezeichnung", type="string", nullable=true)
     */
    private $PRODCBezeichnung;

    /**
     * @ORM\Column(name="auftragswahrscheinlichkeit", type="integer", nullable=true)
     */
    private $auftragswahrscheinlichkeit;

    /**
     * @ORM\Column(name="vorhabenbeschreibung", type="string", nullable=true)
     */
    private $vorhabenbeschreibung;

    /**
     * @ORM\Column(name="AE_monat", type="datetime", nullable=true)
     */
    private $AEmonat;

    /**
     * @ORM\Column(name="FVbenutzer_id", type="integer", nullable=true)
     */
    private $FVbenutzerId;

    /**
     * @ORM\Column(name="SCbenutzer_id", type="integer", nullable=true)
     */
    private $SCbenutzerId;

    /**
     * @ORM\Column(name="af_versions_id", type="integer", nullable=true)
     */
    private $afVersionsId;

    /**
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @ORM\Column(name="VKRRegion", type="string", nullable=true)
     */
    private $VKRRegion;

    /**
     * @ORM\Column(name="volumen_dtts", type="string", nullable=false)
     */
    private $volumenDtts;

    /**
     * @return int|null
     */
    public function getVersionsnr(): ?int
    {
        return $this->versionsnr;
    }

    /**
     * @return mixed
     */
    public function getThema()
    {
        return $this->thema;
    }

    /**
     * @return mixed
     */
    public function getKundenname()
    {
        return $this->kundenname;
    }

    /**
     * @return int|null
     */
    public function getKundennummer(): ?int
    {
        return $this->kundennummer;
    }

    /**
     * @return mixed
     */
    public function getKundenstandort()
    {
        return $this->kundenstandort;
    }

    /**
     * @return mixed
     */
    public function getVorhabenbeschreibung()
    {
        return $this->vorhabenbeschreibung;
    }

    /**
     * @return mixed
     */
    public function getPRODCBezeichnung()
    {
        return $this->PRODCBezeichnung;
    }

    /**
     * @return mixed
     */
    public function getVSAGBezeichnung()
    {
        return $this->VSAGBezeichnung;
    }

    /**
     * @return mixed
     */
    public function getVolumenDtts()
    {
        return $this->volumenDtts;
    }

    /**
     * @return mixed
     */
    public function getAuftragswahrscheinlichkeit()
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @return \DateTime
     */
    public function getAEmonat()
    {
        return $this->AEmonat;
    }

    /**
     * @return mixed
     */
    public function getVKRRegion()
    {
        return $this->VKRRegion;
    }


}
