<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * CrmKunde
 *
 * @ORM\Table(name="CRM_Label_Category")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CrmLabelCategory
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", nullable=false) */
    private string $name;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="sort", type="integer", nullable=false, options={"default"="1"}) */
    private int $sort = 1;

    /** @ORM\OneToMany(targetEntity="CrmLabel", mappedBy="crmCategory") */
    private Collection $crmLabel;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }
}
