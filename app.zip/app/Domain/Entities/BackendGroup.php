<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Absender;
use DateTime;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendRoles
 *
 * @ORM\Table(name="Backend_Group")
 * @ORM\Entity
 */
class BackendGroup extends Absender
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string", length=50) */
    private string $name;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBereich")
     * @ORM\JoinColumn(name="bereich_id", referencedColumnName="bereich_id")
     */
    private BackendBereich $bereich;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRoles")
     * @ORM\JoinColumn(name="role_id", referencedColumnName="role_id")
     */
    private BackendRoles $role;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRoleInfo")
     * @ORM\JoinColumn(name="roleinfo_id", referencedColumnName="id", nullable=true)
     */
    private ?BackendRoleInfo $roleInfo;

    /**
     * @ORM\OneToMany(targetEntity="BackendBenutzerGroup", mappedBy="group")
     */
    private Collection $backendBenutzerGroup;

    /**
     * @ORM\OneToMany(targetEntity="BackendProjectGroup", mappedBy="group")
     */
    private Collection $backendProjectGroup;

    /** @ORM\Column(name="hide", type="integer") */
    private int $hide;

    /** @ORM\Column(name="active", type="boolean") */
    private bool $active;

    /** @ORM\Column(name="email", type="string", length=250, nullable=true) */
    private ?string $email;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $bits;

    /**
     * @Groups({"groupInfo"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"groupInfo"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return string
     */
    public function getSalutation(): string
    {
        return $this->email;
    }

    /**
     * @return bool
     */
    public function isBackendBenutzer(): bool
    {
        return false;
    }

    /**
     * @return BackendRoles|null
     */
    public function getRole(): ?BackendRoles
    {
        return $this->role;
    }

    /**
     * @return BackendRoleInfo|null
     */
    public function getRoleInfo(): ?BackendRoleInfo
    {
        return $this->roleInfo;
    }

    /**
     * @return BackendBereich|null
     */
    public function getBereich(): BackendBereich
    {
        return $this->bereich;
    }
}
