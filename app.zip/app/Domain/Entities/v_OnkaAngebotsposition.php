<?php


namespace App\Domain\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Onka_Angebotsposition")
 */
class v_OnkaAngebotsposition
{
    /**
     * @var int
     *
     * @ORM\Column(name="angebotsposition_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $angebotspositionId;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="fpoi", type="boolean", nullable=true)
     */
    private ?bool $fpoi;

    /**
     * @var int
     *
     * @ORM\Column(name="menge", type="integer", nullable=false)
     */
    private int $menge;

    /**
     * @var string|null
     *
     * @ORM\Column(name="marge", type="decimal", precision=9, scale=2, nullable=true)
     */
    private ?string $marge;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="marge_art", type="boolean", nullable=true)
     */
    private ?bool $margeArt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="einzelpreis_dtts_individual", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?string $einzelpreisDttsIndividual;

    /**
     * @var string|null
     *
     * @ORM\Column(name="preisfaktor", type="decimal", precision=9, scale=2, nullable=true)
     */
    private ?string $preisfaktor;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="preisbildung_art", type="boolean", nullable=true)
     */
    private ?bool $preisbildungArt;

    /**
     * @return bool|null
     */
    public function getFpoi(): ?bool
    {
        return $this->fpoi;
    }

    /**
     * @return int
     */
    public function getAngebotspositionId(): int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return string|null
     */
    public function getEinzelpreisDttsIndividual(): ?string
    {
        return $this->einzelpreisDttsIndividual;
    }

    /**
     * @return string|null
     */
    public function getMarge(): ?string
    {
        return $this->marge;
    }

    /**
     * @return bool|null
     */
    public function getMargeArt(): ?bool
    {
        return $this->margeArt;
    }

    /**
     * @return int
     */
    public function getMenge(): int
    {
        return $this->menge;
    }

    /**
     * @return bool|null
     */
    public function getPreisbildungArt(): ?bool
    {
        return $this->preisbildungArt;
    }

    /**
     * @return string|null
     */
    public function getPreisfaktor(): ?string
    {
        return $this->preisfaktor;
    }

    /**
     * @return bool
     */
    public function isPreisbildungArtNotNull(): bool
    {
        return $this->preisbildungArt !== null;
    }

    /**
     * @return bool
     */
    public function isMargeArtNotNull(): bool
    {
        return $this->margeArt !== null;
    }

}
