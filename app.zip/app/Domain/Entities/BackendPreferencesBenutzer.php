<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendPreferences
 *
 * @ORM\Table(name="Backend_Preferences_Benutzer")
 * @ORM\Entity
 */
class BackendPreferencesBenutzer
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendPreferences")
     * @ORM\JoinColumn(name="preference_id", referencedColumnName="id")
     */
    private BackendPreferences $preference;

    /** @ORM\Column(name="value", type="string", length=128, nullable=true) */
    private ?string $value;

    /**
     * BackendPreferencesBenutzer constructor.
     * @param BackendBenutzer $benutzer
     * @param BackendPreferences|object $preference
     * @param string|null $value
     */
    public function __construct(BackendBenutzer $benutzer, BackendPreferences $preference, ?string $value = null)
    {
        $this->benutzer = $benutzer;
        $this->preference = $preference;
        $this->value = $value;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @return BackendPreferences
     */
    public function getPreference(): BackendPreferences
    {
        return $this->preference;
    }

    /**
     * @param BackendPreferences $preference
     */
    public function setPreference(BackendPreferences $preference): void
    {
        $this->preference = $preference;
    }

    /**
     * @return string
     */
    public function getValue(): string
    {
        return $this->value;
    }

    /**
     * @param string $value
     */
    public function setValue(string $value): void
    {
        $this->value = $value;
    }
}
