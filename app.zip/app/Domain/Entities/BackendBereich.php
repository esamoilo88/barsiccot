<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * BackendBereich
 *
 * @ORM\Table(name="Backend_Bereich")
 * @ORM\Entity
 */
class BackendBereich
{
    /**
     * @var int
     *
     * @ORM\Column(name="bereich_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $bereichId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sales", type="string", length=50, nullable=true)
     */
    private $sales;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vkr_kuerzel", type="string", length=50, nullable=true)
     */
    private $vkrKuerzel;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nl_id", type="string", length=50, nullable=true)
     */
    private $nlId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="reports_rf", type="string", length=50, nullable=true)
     */
    private $reportsRf;

    /**
     * @var int|null
     *
     * @ORM\Column(name="unique_id", type="bigint", nullable=true)
     */
    private $uniqueId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="orge_id", type="smallint", nullable=true)
     */
    private $orgeId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="orge_kurz", type="string", length=50, nullable=true)
     */
    private $orgeKurz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="orge_lang", type="text", length=-1, nullable=true)
     */
    private $orgeLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort2_id", type="string", length=20, nullable=true)
     */
    private $ressort2Id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort2_kurz", type="string", length=50, nullable=true)
     */
    private $ressort2Kurz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort2_lang", type="text", length=-1, nullable=true)
     */
    private $ressort2Lang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort4_id", type="string", length=20, nullable=true)
     */
    private $ressort4Id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort4_kurz", type="string", length=50, nullable=true)
     */
    private $ressort4Kurz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort4_lang", type="text", length=-1, nullable=true)
     */
    private $ressort4Lang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="team_id", type="string", length=20, nullable=true)
     */
    private $teamId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="team_kurz", type="string", length=50, nullable=true)
     */
    private $teamKurz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="team_lang", type="text", length=-1, nullable=true)
     */
    private ?string $teamLang = null;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean")
     */
    private bool $hide = false;

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int
     */
    public function getBereichId(): int
    {
        return $this->bereichId;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile", "groupInfo"})
     * @return string|null
     */
    public function getTeamKurz(): ?string
    {
        return $this->teamKurz;
    }

    /**
     * @Groups({"UserInfoWidget", "userProfile", "groupInfo"})
     * @return string|null
     */
    public function getTeamLang(): ?string
    {
        return $this->teamLang;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }
}
