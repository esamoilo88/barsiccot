<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class V_MappingZuordnungKostenart
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="v_Mapping_Zuordnung_Kostenart")
 */
class v_MappingZuordnungKostenart
{

    /**
     * @ORM\Column(name="angebotsposition_id", type="integer", nullable=true)
     * @ORM\Id
     */
    private ?int $angebotspositionId;

    /** @ORM\Column(name="bezeichnung", type="string", length=150, nullable=true) */
    private ?string $bezeichnung;

    /**
     * @ORM\Column(name="zuordnung", type="string", length=40, nullable=true)
     */
    private ?string $zuordnung;

    /**
     * @ORM\Column(name="kostenart_id_new", type="integer", nullable=false)
     */
    private int $kostenartIdNew;

    /**
     * @ORM\Column(name="kostenart_id_alt", type="integer", nullable=false)
     */
    private int $kostenartIdAlt;

    /** @ORM\Column(name="kostenart_neu", type="string", length=150, nullable=true) */
    private ?string $kostenartNeu;

    /** @ORM\Column(name="kostenart_alt", type="string", length=150, nullable=true) */
    private ?string $kostenartAlt;

    /** @ORM\Column(name="kostenwert", type="decimal", precision=20, scale=4, nullable=true) */
    private ?float $kostenwert;

    /**
     * @ORM\Column(name="stundensatz", type="decimal", precision=20, scale=4, nullable=true)
     */
    private ?float $stundensatz;

    /**
     * @ORM\Column(name="stundensatz_alternativ", type="decimal", precision=20, scale=4, nullable=true)
     */
    private ?float $stundensatzAlternativ;

    /**
     * @ORM\Column(name="target_kostenart_id", type="integer", nullable=false)
     */
    private int $targetKostenartId;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenstelle")
     * @ORM\JoinColumn(name="kostenstelle_id", referencedColumnName="kostenstelle_id", nullable= true)
     */
    private ?CostsKostenstelle $kostenstelle;

    /**
     * @ORM\Column(name="service_region", type="boolean", nullable=false)
     */
    private bool $serviceRegion;

    /**
     * @ORM\Column(name="ofi_la", type="integer", nullable=true)
     */
    private ?int $ofiLa;

    /** @ORM\Column(name="config_field_6", type="text", length=-1, nullable=true) */
    private ?string $configField6;

    /**
     * @ORM\Column(name="ilv_relevant", type="boolean", nullable=true)
     */
    private ?bool $ilvRelevant = false;

    /**
     * @ORM\Column(name="vlv_relevant", type="boolean", nullable=true)
     */
    private ?bool $vlvRelevant;
}
