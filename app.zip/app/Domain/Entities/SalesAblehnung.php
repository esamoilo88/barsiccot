<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;


/**
 * SalesAblehnung
 *
 * @ORM\Table(name="Sales_Ablehnung")
 * @ORM\Entity
 */
class SalesAblehnung
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="dateline", type="datetime")
     */
    private DateTime $dateline;

    /**
     * @ORM\Column(name="bemerkung", type="text", length=-1, nullable=true)
     */
    private ?string $bemerkung;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="SalesAblehnunggrund")
     * @ORM\JoinColumn(name="ablehnungGrund_id", referencedColumnName="ablehnungGrund_id")
     */
    private SalesAblehnunggrund $ablehnunggrund;

    /**
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $project;

    /**
     * @param GlobalGate $project
     */
    public function setProject(GlobalGate $project): void
    {
        $this->project = $project;
    }

    /**
     * @param SalesAblehnunggrund $ablehnunggrund
     */
    public function setReason(SalesAblehnunggrund $ablehnunggrund): void
    {
        $this->ablehnunggrund = $ablehnunggrund;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setUser(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @param string|null $bemerkung
     */
    public function setDescription(?string $bemerkung): void
    {
        $this->bemerkung = $bemerkung;
    }

    /**
     * @param SalesStammdaten $salesStammdaten
     */
    public function setSalesStammdaten(SalesStammdaten $salesStammdaten): void
    {
        $this->salesStammdaten = $salesStammdaten;
    }

    /**
     * @return DateTime
     */
    public function getDateline(): DateTime
    {
        return $this->dateline;
    }

    /**
     * @param DateTime $dateline
     */
    public function setDateline(DateTime $dateline): void
    {
        $this->dateline = $dateline;
    }
}
