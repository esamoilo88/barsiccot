<?php


namespace App\Domain\Entities;


use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SalesContactRole
 *
 * @ORM\Table(name="Sales_Contact_Role")
 * @ORM\Entity
 */
class SalesContactRole
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string")
     */
    private string $name;

    /**
     * @var string
     *
     * @ORM\Column(name="sys_name", type="string")
     */
    private string $sysName;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="integer")
     */
    private int $sort;

    /**
     * @var boolean
     *
     * @ORM\Column(name="hide", type="boolean")
     */
    private bool $hide;

    /**
     * @var DateTime
     *
     * @ORM\Column(name="bits", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $bits;

    /**
     * SalesContactRole constructor.
     * @param string $name
     * @param string $sysName
     * @param int $sort
     * @param bool $hide
     */
    public function __construct(
        string $name,
        string $sysName,
        int $sort,
        bool $hide = false
    )
    {
        $this->name = $name;
        $this->sysName = $sysName;
        $this->sort = $sort;
        $this->hide = $hide;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getSysName(): string
    {
        return $this->sysName;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }
}
