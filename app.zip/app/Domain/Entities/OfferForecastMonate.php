<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * OfferForecastMonate
 *
 * @ORM\Table(name="Offer_Forecast_Monate")
 * @ORM\Entity
 */
class OfferForecastMonate
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="monat", type="date") */
    private DateTime $monat;

    /** @ORM\Column(name="umsatz", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $umsatz = null;

    /** @ORM\Column(type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $umsatzDisc = null;

    /** @ORM\Column(name="kosten", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $kosten = null;

    /**
     * @ORM\Column(name="created", type="datetime", nullable=false)
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $created;

    /**
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     * @Gedmo\Timestampable(on="update")
     */
    private DateTime $modified;

//    TODO problem: need to create new readmode enity or update fields logic and move it from db to code
//    /**
//     * @ORM\Column(name="valid_from", type="datetime", nullable=false, options={"default"="sysutcdatetime()"})
//     */
//    private $validFrom = 'sysutcdatetime()';
//
//    /**
//     * @ORM\Column(name="valid_to", type="datetime", nullable=false, options={"default"="CONVERT([datetime2](0),'9999-12-31 23:59:59',(0))"})
//     */
//    private $validTo = 'CONVERT([datetime2](0),\'9999-12-31 23:59:59\',(0))';

    /** @ORM\Column(name="kosten_gen_type", type="string", length=6, nullable=true) */
    private ?string $kostenGenType = null;

    /** @ORM\Column(name="umsatz_gen_type", type="string", length=6, nullable=true) */
    private ?string $umsatzGenType = null;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $benutzer;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * OfferForecastMonate constructor.
     * @param SalesStammdaten|object $simple
     * @param DateTime $monat
     * @param BackendBenutzer $benutzer
     */
    public function __construct(
        SalesStammdaten $simple,
        DateTime $monat,
        BackendBenutzer $benutzer
    )
    {
        $this->simple = $simple;
        $this->monat = $monat;
        $this->benutzer = $benutzer;
    }

    /**
     * @return string|null
     */
    public function getUmsatz(): ?string
    {
        return $this->umsatz;
    }

    /**
     * @return string|null
     */
    public function getKosten(): ?string
    {
        return $this->kosten;
    }

    /**
     * @return string|null
     */
    public function getKostenGenType(): ?string
    {
        return $this->kostenGenType;
    }

    /**
     * @return string|null
     */
    public function getUmsatzGenType(): ?string
    {
        return $this->umsatzGenType;
    }

    /**
     * @param string|null $umsatz
     */
    public function setUmsatz(?string $umsatz): void
    {
        $this->umsatz = $umsatz;
    }

    /**
     * @param string|null $kosten
     */
    public function setKosten(?string $kosten): void
    {
        $this->kosten = $kosten;
    }

    /**
     * @param string|null $kostenGenType
     */
    public function setKostenGenType(?string $kostenGenType): void
    {
        $this->kostenGenType = $kostenGenType;
    }

    /**
     * @param string|null $umsatzGenType
     */
    public function setUmsatzGenType(?string $umsatzGenType): void
    {
        $this->umsatzGenType = $umsatzGenType;
    }

    /**
     * @return DateTime
     */
    public function getMonat(): DateTime
    {
        return $this->monat;
    }

    /**
     * @param DateTime $monat
     */
    public function setMonat(DateTime $monat): void
    {
        $this->monat = $monat;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @param BackendBenutzer $benutzer
     */
    public function setBenutzer(BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return string|null
     */
    public function getUmsatzDisc(): ?string
    {
        return $this->umsatzDisc;
    }
}
