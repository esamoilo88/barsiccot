<?php


namespace App\Domain\Entities;


use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Workflow")
 */
class v_OfferWorkflow
{
    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $simpleId;

    /** @ORM\Column(name="Status", type="string") */
    private string $status;

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }
}
