<?php

namespace App\Domain\Entities;

use App\Utils\SimpleValidator\IRuleEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Validation_Rules")
 * @ORM\Entity
 */
class ValidationRules implements IRuleEntity
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="`group`", type="string", length=32) */
    private string $group;

    /** @ORM\Column(name="field", type="string", length=32) */
    private string $field;

    /** @ORM\Column(name="`rule`", type="string", length=512) */
    private string $rule;

    /** @ORM\Column(name="enabled", type="boolean") */
    private bool $enabled = true;

    /** @ORM\Column(name="error_message", type="string", length=1024, nullable=true) */
    private ?string $errorMessage;

    /** @ORM\Column(name="success_message", type="string", length=1024, nullable=true) */
    private ?string $successMessage;

    /**
     * ValidationRules constructor.
     * @param string $group
     * @param string $field
     * @param string $rule
     */
    public function __construct(string $group, string $field, string $rule)
    {
        $this->group = $group;
        $this->field = $field;
        $this->rule = $rule;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * @param string $group
     */
    public function setGroup(string $group): void
    {
        $this->group = $group;
    }

    /**
     * @return string
     */
    public function getField(): string
    {
        return $this->field;
    }

    /**
     * @param string $field
     */
    public function setField(string $field): void
    {
        $this->field = $field;
    }

    /**
     * @return string
     */
    public function getRule(): string
    {
        return $this->rule;
    }

    /**
     * @param string $rule
     */
    public function setRule(string $rule): void
    {
        $this->rule = $rule;
    }

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * @param bool $enabled
     */
    public function setEnabled(bool $enabled): void
    {
        $this->enabled = $enabled;
    }

    /**
     * @return string|null
     */
    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    /**
     * @param string|null $errorMessage
     */
    public function setErrorMessage(?string $errorMessage): void
    {
        $this->errorMessage = $errorMessage;
    }

    /**
     * @return string|null
     */
    public function getSuccessMessage(): ?string
    {
        return $this->successMessage;
    }

    /**
     * @param string|null $successMessage
     */
    public function setSuccessMessage(?string $successMessage): void
    {
        $this->successMessage = $successMessage;
    }
}
