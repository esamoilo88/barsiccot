<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferItilSub
 *
 * @ORM\Table(name="Offer_ITIL_Sub")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OfferItilSub
{
    /**
     * @ORM\Column(name="itil_sub_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $itilSubId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung = null;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung = null;

    /** @ORM\Column(name="abkuerzung", type="string", length=50, nullable=true) */
    private ?string $abkuerzung = null;

    /** @ORM\Column(name="sort", type="smallint", nullable=false) */
    private int $sort;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilMain")
     * @ORM\JoinColumn(name="itil_main_id", referencedColumnName="itil_main_id")
     */
    private OfferItilMain $itilMain;

    /**
     * @Groups({"adminKatalog"})
     * @return int
     */
    public function getItilSubId(): int
    {
        return $this->itilSubId;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
