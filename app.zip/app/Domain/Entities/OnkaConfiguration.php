<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaConfiguration
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configuration")
 */
class OnkaConfiguration
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     * @Groups({"configurationInfo"})
     */
    private int $id;

    /**
     * @ORM\Column(type="string")
     * @Groups({"configurationInfo"})
     */
    private string $name;

    /**
     * @ORM\ManyToOne(targetEntity="SalesVersionierung")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesVersionierung $simple;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_version_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $angebotVk;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfigurator")
     * @ORM\JoinColumn(name="configurator_id", referencedColumnName="id")
     */
    private OnkaConfigurator $configurator;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /** @ORM\OneToMany(targetEntity="OnkaConfigurationItem", mappedBy="configuration") */
    private Collection $items;

    /** @ORM\OneToMany(targetEntity="v_MyConfigurationItems", mappedBy="configuration") */
    private Collection $viewItems;

    /** @ORM\OneToMany(targetEntity="OnkaConfigurationParam", mappedBy="configuration") */
    private Collection $params;

    /**
     * OnkaConfiguration constructor.
     * @param SalesVersionierung $simple
     * @param OfferAngebotVk $angebotVk
     * @param OnkaConfigurator $configurator
     */
    public function __construct(
        SalesVersionierung $simple,
        OfferAngebotVk $angebotVk,
        OnkaConfigurator $configurator
    )
    {
        $this->makeName($configurator);
        $this->simple = $simple;
        $this->angebotVk = $angebotVk;
        $this->configurator = $configurator;
        $this->items = new ArrayCollection();
        $this->viewItems = new ArrayCollection();

        $this->params = new ArrayCollection();
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return SalesVersionierung
     */
    public function getVersionManager(): SalesVersionierung
    {
        return $this->simple;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getAngebotVk(): OfferAngebotVk
    {
        return $this->angebotVk;
    }

    /**
     * @return OnkaConfigurator
     */
    public function getConfigurator(): OnkaConfigurator
    {
        return $this->configurator;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param OnkaConfigurator $configurator
     */
    private function makeName(OnkaConfigurator $configurator): void
    {
        $date = new DateTime();

        $this->name = sprintf('%s %s, %s',
            $configurator->getName(),
            $date->format('d.m.Y'),
            $date->format('H:i')
        );
    }

    /**
     * @return Collection
     */
    public function getItems(): Collection
    {
        return $this->items;
    }

    /**
     * @return Collection
     */
    public function getParams(): Collection
    {
        return $this->params;
    }

    /**
     * @param OnkaConfigurationItem $item
     */
    public function addConfigurationItem(OnkaConfigurationItem $item): void
    {
        if ($this->items->contains($item)) {
            return;
        }

        $this->items->add($item);
    }

    /**
     * @param Collection $items
     */
    public function setItems(Collection $items): void
    {
        $this->items = $items;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param ArrayCollection|Collection $params
     */
    public function setParams($params): void
    {
        $this->params = $params;
    }
}
