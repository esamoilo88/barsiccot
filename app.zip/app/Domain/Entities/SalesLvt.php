<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * SalesLvt
 *
 * @ORM\Table(name="Sales_LVT")
 * @ORM\Entity
 */
class SalesLvt
{
    /**
     * @var string|null
     *
     * @ORM\Column(name="vorname", type="string", length=50, nullable=true)
     */
    private $vorname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nachname", type="string", length=50, nullable=true)
     */
    private $nachname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="orge", type="string", length=100, nullable=true)
     */
    private $orge;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort", type="string", length=100, nullable=true)
     */
    private $ressort;

    /**
     * @var string|null
     *
     * @ORM\Column(name="email", type="string", length=100, nullable=true)
     */
    private $email;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


}
