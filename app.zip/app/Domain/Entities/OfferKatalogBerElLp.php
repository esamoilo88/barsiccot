<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OfferKatalogBerElLp
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_BER_EL_LP")
 */
class OfferKatalogBerElLp
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogElement")
     * @ORM\JoinColumn(name="element_id", referencedColumnName="element_id", nullable=true)
     */
    private ?OfferKatalogElement $katalogEl;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id", nullable=true)
     */
    private ?OfferKatalogLeistungsposition $katalogLp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogBerechnung")
     * @ORM\JoinColumn(name="berechnung_id", referencedColumnName="berechnung_id")
     */
    private OfferKatalogBerechnung $katalogBer;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * OfferKatalogBerElLp constructor.
     * @param OfferKatalogElement|null $katalogEl
     * @param OfferKatalogLeistungsposition|null $katalogLp
     * @param OfferKatalogBerechnung $katalogBer
     * @param int|null $sort
     */
    public function __construct(
        OfferKatalogBerechnung $katalogBer,
        ?OfferKatalogElement $katalogEl = null,
        ?OfferKatalogLeistungsposition $katalogLp = null,
        ?int $sort = null
    )
    {
        $this->katalogEl = $katalogEl;
        $this->katalogLp = $katalogLp;
        $this->katalogBer = $katalogBer;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @return OfferKatalogElement|null
     */
    public function getKatalogEl(): ?OfferKatalogElement
    {
        return $this->katalogEl;
    }

    /**
     * @param OfferKatalogElement|null $katalogEl
     */
    public function setKatalogEl(?OfferKatalogElement $katalogEl): void
    {
        $this->katalogEl = $katalogEl;
    }

    /**
     * @return OfferKatalogLeistungsposition|null
     */
    public function getKatalogLp(): ?OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @param OfferKatalogLeistungsposition|null $katalogLp
     */
    public function setKatalogLp(?OfferKatalogLeistungsposition $katalogLp): void
    {
        $this->katalogLp = $katalogLp;
    }

    /**
     * @return OfferKatalogBerechnung
     */
    public function getKatalogBer(): OfferKatalogBerechnung
    {
        return $this->katalogBer;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }
}
