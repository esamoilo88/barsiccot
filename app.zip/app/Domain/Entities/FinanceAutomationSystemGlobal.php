<?php


namespace App\Domain\Entities;


use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\Mapping as ORM;

/**
 * FinanceAutomationSystemGlobal
 *
 * @ORM\Table(name="Finance_Automation_System_Global")
 * @ORM\Entity
 */
class FinanceAutomationSystemGlobal
{
    /**
     * @ORM\Column(name="simple_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="auto_create", type="boolean")
     */
    private bool $autoCreate;

    /**
     * @ORM\Column(name="auto_send", type="boolean")
     */
    private bool $autoSend;

    /**
     * @ORM\Column(name="auto_bill", type="boolean")
     */
    private bool $autoBill;

    /**
     * @ORM\Column(name="send_at", type="string", nullable=true)
     */
    private ?string $sendAt;

    /**
     * @ORM\Column(name="bill_at", type="string", nullable=true)
     */
    private ?string $billAt;

    /**
     * @ORM\Column(name="bill_after_deadline", type="boolean")
     */
    private bool $billAfterDeadline;

    /**
     * @ORM\Column(name="auto_ilv", type="boolean")
     */
    private bool $autoIlv;

    /**
     * FinanceAutomationSystemGlobal constructor.
     * @param SIN $sin
     */
    public function __construct(SIN $sin)
    {
        $this->simpleId = $sin->value();
    }


    /**
     * @param bool $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @param bool $autoCreate
     */
    public function setAutoCreate(bool $autoCreate): void
    {
        $this->autoCreate = $autoCreate;
    }

    /**
     * @param bool $autoSend
     */
    public function setAutoSend(bool $autoSend): void
    {
        $this->autoSend = $autoSend;
    }

    /**
     * @param bool $autoBill
     */
    public function setAutoBill(bool $autoBill): void
    {
        $this->autoBill = $autoBill;
    }

    /**
     * @param string|null $sendAt
     */
    public function setSendAt(?string $sendAt): void
    {
        $this->sendAt = $sendAt;
    }

    /**
     * @param string|null $billAt
     */
    public function setBillAt(?string $billAt): void
    {
        $this->billAt = $billAt;
    }

    /**
     * @param bool $billAfterDeadline
     */
    public function setBillAfterDeadline(bool $billAfterDeadline): void
    {
        $this->billAfterDeadline = $billAfterDeadline;
    }

    /**
     * @param bool $autoIlv
     */
    public function setAutoIlv(bool $autoIlv): void
    {
        $this->autoIlv = $autoIlv;
    }

    /**
     * @param bool $autoApprove
     */
    public function handleGlobalAutoapprove(bool $autoApprove): void
    {
        $autoApprove ?
            $this->globalAutoApproveGetsTrue() :
            $this->globalAutoApproveGetsFalse();
    }

    /**
     * controlled by FinanceAutomationSuperglobal::autoApprove
     */
    private function globalAutoApproveGetsTrue(): void
    {
        if ($this->autoSend === true) {
            $this->autoBill = $this->autoSend;
            $this->billAt = $this->sendAt;
            $this->sendAt = null;
            $this->autoSend = false;
            $this->billAfterDeadline = false;
        }
    }

    /**
     * controlled by FinanceAutomationSuperglobal::autoApprove
     */
    private function globalAutoApproveGetsFalse(): void
    {
        if ($this->autoBill === true) {
            $this->autoSend = $this->autoBill;
            $this->sendAt = $this->billAt;
            $this->billAt = null;
            $this->autoBill = false;
            $this->billAfterDeadline = true;
        }
    }
}
