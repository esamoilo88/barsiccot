<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * OfferItil
 *
 * @ORM\Table(name="Offer_ITIL")
 * @ORM\Entity
 */
class OfferItil
{
    /**
     * @ORM\Column(name="itil_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $itilId;

    /** @ORM\Column(name="prozent", type="decimal", precision=18, scale=2, nullable=false) */
    private float $prozent;

    /** @ORM\Column(name="manuell", type="boolean", nullable=true) */
    private bool $manuell;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     */
    private OfferAngebotVk $vkVersions;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilMain")
     * @ORM\JoinColumn(name="itil_main_id", referencedColumnName="itil_main_id")
     */
    private OfferItilMain $itilMain;

    /**
     * @ORM\ManyToOne(targetEntity="OfferItilSub")
     * @ORM\JoinColumn(name="itil_sub_id", referencedColumnName="itil_sub_id")
     */
    private ?OfferItilSub $itilSub;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @return int
     */
    public function getItilId(): int
    {
        return $this->itilId;
    }

    /**
     * @return float
     */
    public function getProzent(): float
    {
        return $this->prozent;
    }

    /**
     * @param float $prozent
     */
    public function setProzent(float $prozent): void
    {
        $this->prozent = $prozent;
    }

    /**
     * @return bool
     */
    public function isManuell(): bool
    {
        return $this->manuell;
    }

    /**
     * @param bool $manuell
     */
    public function setManuell(bool $manuell): void
    {
        $this->manuell = $manuell;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @param DateTime|null $bits
     */
    public function setBits(?DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @param OfferAngebotVk|object $vkVersions
     */
    public function setVkVersions(OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @return OfferItilMain
     */
    public function getItilMain(): OfferItilMain
    {
        return $this->itilMain;
    }

    /**
     * @param OfferItilMain|object $itilMain
     */
    public function setItilMain(OfferItilMain $itilMain): void
    {
        $this->itilMain = $itilMain;
    }

    /**
     * @return OfferItilSub
     */
    public function getItilSub(): OfferItilSub
    {
        return $this->itilSub;
    }

    /**
     * @param OfferItilSub|object|null $itilSub
     */
    public function setItilSub(?OfferItilSub $itilSub): void
    {
        $this->itilSub = $itilSub;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @param SalesStammdaten|object $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }
}
