<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Faktura_Billing_LBU")
 */
class v_OfferFakturaBillingLbu
{
    /**
     * @ORM\Column(name="lbu_id", type="integer")
     * @ORM\Id
     */
    private int $lbuId;

    /** @ORM\Column(name="simple_id", type="integer") */
    private int $simpleId;

    /** @ORM\Column(name="vorgangstyp", type="string", nullable=true) */
    private ?string $vorgangstyp;

    /** @ORM\Column(name="fakturaziel", type="string", length=20, nullable=true) */
    private ?string $fakturaziel;

    /** @ORM\Column(name="sap_bestellnummer", type="string", length=50, nullable=true) */
    private ?string $sapBestellnummer;

    /** @ORM\Column(name="nummer", type="string", length=50, nullable=true) */
    private ?string $nummer;

    /** @ORM\Column(name="debitor_id", type="integer") */
    private int $debitorId;

    /** @ORM\Column(name="master_debitor_id", type="integer", nullable=true) */
    private ?int $masterDebitorId;

    /** @ORM\Column(name="nachname", type="string", length=100, nullable=true) */
    private ?string $nachname;

    /** @ORM\Column(name="vorname", type="string", length=100, nullable=true) */
    private ?string $vorname;

    /** @ORM\Column(name="tel_nr", type="string", length=50, nullable=true) */
    private ?string $telNr;

    /** @ORM\Column(name="leistungs_monat", type="integer") */
    private int $leistungsMonat;

    /** @ORM\Column(name="leistungs_jahr", type="integer") */
    private int $leistungsJahr;

    /** @ORM\Column(name="faktura_monat", type="integer") */
    private int $fakturaMonat;

    /** @ORM\Column(name="faktura_jahr", type="integer") */
    private int $fakturaJahr;

    /** @ORM\Column(name="kundenname", type="string", length=255, nullable=true) */
    private ?string $kundenname;

    /** @ORM\Column(name="abgrenzung", type="boolean") */
    private bool $abgrenzung;

    /** @ORM\Column(name="status_sys", type="string", length=255) */
    private string $statusSys;

    /** @ORM\Column(name="fakturabereit", type="datetime") */
    private ?DateTime $fakturabereit;

    /** @ORM\Column(name="dateiname_sap", type="string", length=32, nullable=true) */
    private ?string $dateinameSap;

    /** @ORM\Column(name="rechnungsnummer", type="string", length=50, nullable=true) */
    private ?string $rechnungsnummer;

    /** @ORM\Column(name="frequency", type="string", length=25, nullable=true) */
    private ?string $frequency;

    /** @ORM\Column(name="billing_subject_extension", type="string", length=150, nullable=true) */
    private ?string $billingSubjectExtension;

    /** @ORM\Column(name="billing_date", type="datetime", nullable=true) */
    private ?DateTime $billingDate;

    /** @ORM\OneToMany(targetEntity="v_OfferFakturaBillingLbuDaten", mappedBy="lbu") */
    private Collection $lbuDaten;

    /** @ORM\Column(name="`external`", type="boolean", nullable=true) */
    private ?bool $external;

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getVorgangstyp(): ?string
    {
        return $this->vorgangstyp;
    }

    /**
     * @return string|null
     */
    public function getFakturaziel(): ?string
    {
        return $this->fakturaziel;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getNummer(): ?string
    {
        return $this->nummer;
    }

    /**
     * @return int
     */
    public function getDebitorId(): int
    {
        return $this->debitorId;
    }

    /**
     * @return int|null
     */
    public function getMasterDebitorId(): ?int
    {
        return $this->masterDebitorId;
    }

    /**
     * @return string|null
     */
    public function getNachname(): ?string
    {
        return $this->nachname;
    }

    /**
     * @return string|null
     */
    public function getVorname(): ?string
    {
        return $this->vorname;
    }

    /**
     * @return string|null
     */
    public function getTelNr(): ?string
    {
        return $this->telNr;
    }

    /**
     * @return int
     */
    public function getLeistungsMonat(): int
    {
        return $this->leistungsMonat;
    }

    /**
     * @return int
     */
    public function getLeistungsJahr(): int
    {
        return $this->leistungsJahr;
    }

    /**
     * @return int
     */
    public function getFakturaMonat(): int
    {
        return $this->fakturaMonat;
    }

    /**
     * @return int
     */
    public function getFakturaJahr(): int
    {
        return $this->fakturaJahr;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return bool
     */
    public function isAbgrenzung(): bool
    {
        return $this->abgrenzung;
    }

    /**
     * @return string
     */
    public function getStatusSys(): string
    {
        return $this->statusSys;
    }

    /**
     * @return DateTime|null
     */
    public function getFakturabereit(): ?DateTime
    {
        return $this->fakturabereit;
    }

    /**
     * @return string|null
     */
    public function getDateinameSap(): ?string
    {
        return $this->dateinameSap;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return string|null
     */
    public function getFrequency(): ?string
    {
        return $this->frequency;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return DateTime|null
     */
    public function getBillingDate(): ?DateTime
    {
        return $this->billingDate;
    }

    /**
     * @return Collection
     */
    public function getLbuDaten(): Collection
    {
        return $this->lbuDaten;
    }

    /**
     * @return bool|null
     */
    public function getExternal(): ?bool
    {
        return $this->external;
    }
}
