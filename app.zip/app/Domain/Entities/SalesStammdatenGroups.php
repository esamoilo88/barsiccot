<?php

namespace App\Domain\Entities;

use Carbon\Carbon;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="Sales_Stammdaten_Groups")
 * @ORM\Entity
 */
class SalesStammdatenGroups
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="group_label", type="string", length=50, nullable=true) */
    private string $groupLabel;

    /** @ORM\Column(name="simple_id", type="integer", nullable=false) */
    private int $simpleId;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * SalesStammdatenGroups constructor.
     * @param string $groupLabel
     * @param int $simpleId
     */
    public function __construct(string $groupLabel, int $simpleId)
    {
        $this->groupLabel = $groupLabel;
        $this->simpleId = $simpleId;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getGroupLabel(): string
    {
        return $this->groupLabel;
    }

    /**
     * @param string $groupLabel
     */
    public function setGroupLabel(string $groupLabel): void
    {
        $this->groupLabel = $groupLabel;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }
}
