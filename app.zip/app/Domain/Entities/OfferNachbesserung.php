<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferNachbesserung
 *
 * @ORM\Table(name="Offer_Nachbesserung")
 * @ORM\Entity
 */
class OfferNachbesserung
{
    /**
     * @var int
     *
     * @ORM\Column(name="nachbesserung_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $nachbesserungId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="grund", type="text", length=-1, nullable=true)
     */
    private $grund;

    /**
     * @var string|null
     *
     * @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true)
     */
    private $beschreibung;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
