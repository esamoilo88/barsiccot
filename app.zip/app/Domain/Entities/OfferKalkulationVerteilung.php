<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferKalkulationVerteilung
 *
 * @ORM\Table(name="Offer_Kalkulation_Verteilung")
 * @ORM\Entity
 */
class OfferKalkulationVerteilung
{
    /**
     * @var int
     *
     * @ORM\Column(name="verteilung_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $verteilungId;

    /**
     * @var int
     *
     * @ORM\Column(name="quell_leistungsposition_id", type="bigint", nullable=false)
     */
    private $quellLeistungspositionId;

    /**
     * @var int
     *
     * @ORM\Column(name="angebotsposition_id", type="bigint", nullable=false)
     */
    private $angebotspositionId;

    /**
     * @var string
     *
     * @ORM\Column(name="verteilwert", type="decimal", precision=18, scale=2, nullable=false)
     */
    private $verteilwert;

    /**
     * @var string
     *
     * @ORM\Column(name="ziel_menge", type="decimal", precision=26, scale=18, nullable=false)
     */
    private $zielMenge;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var \OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private $vkVersions;

    /**
     * @var \OfferKalkulationVerteilungVerteiloption
     *
     * @ORM\ManyToOne(targetEntity="OfferKalkulationVerteilungVerteiloption")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="verteiloption_id", referencedColumnName="verteiloption_id")
     * })
     */
    private $verteiloption;

    /**
     * @var \SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;


    /**
     * @param OfferAngebotVk $vkVersion
     * @return bool
     */
    public function isVkVersion(OfferAngebotVk $vkVersion): bool
    {
        return $this->vkVersions == $vkVersion;
    }
}
