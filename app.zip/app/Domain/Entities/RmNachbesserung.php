<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * RmNachbesserung
 *
 * @ORM\Table(name="RM_Nachbesserung")
 * @ORM\Entity
 */
class RmNachbesserung
{
    /**
     * @var int
     *
     * @ORM\Column(name="nachbesserungs_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $nachbesserungsId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=100, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hide", type="boolean", nullable=true)
     */
    private $hide;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
