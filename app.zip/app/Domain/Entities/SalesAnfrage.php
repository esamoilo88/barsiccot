<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * SalesAnfrage
 *
 * @ORM\Table(name="Sales_Anfrage")
 * @ORM\Entity
 */
class SalesAnfrage
{
    /**
     * @var int
     *
     * @ORM\Column(name="af_versions_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $afVersionsId;

    /** @ORM\Column(name="versionsnr", type="smallint", nullable=false) */
    private int $versionsnr;

    /** @ORM\Column(name="AEV1benutzer_id", type="integer", nullable=true) */
    private $aev1benutzerId;

    /** @ORM\Column(name="AEV2benutzer_id", type="integer", nullable=true) */
    private $aev2benutzerId;

    /** @ORM\Column(name="angebot_angefordert_am", type="datetime", nullable=true) */
    private ?DateTime $angebotAngefordertAm;

    /** @ORM\Column(name="angebotsersteller_zugewiesen_am", type="datetime", nullable=true) */
    private ?DateTime $angebotserstellerZugewiesenAm;

    /** @ORM\Column(name="liefertermin_angebot", type="datetime", nullable=true) */
    private ?DateTime $lieferterminAngebot;

    /** @ORM\Column(name="liefertermin_angebot_check", type="datetime", nullable=true) */
    private ?DateTime $lieferterminAngebotCheck;

    /** @ORM\Column(name="ausschreibung", type="boolean", nullable=false) */
    private $ausschreibung;

    /** @ORM\Column(name="budgetangebot", type="boolean", nullable=false) */
    private $budgetangebot;

    /** @ORM\Column(name="tvp_angebot", type="boolean", nullable=true) */
    private $tvpAngebot;

    /** @ORM\Column(name="cm_wert", type="smallint", nullable=true) */
    private $cmWert;

    /** @ORM\Column(name="liegezeit_soll", type="smallint", nullable=true) */
    private $liegezeitSoll;

    /** @ORM\Column(name="vcm_kenner", type="string", length=50, nullable=true) */
    private $vcmKenner;

    /** @ORM\Column(name="vertragsbeginn", type="datetime", nullable=true) */
    private ?DateTime $vertragsbeginn;

    /** @ORM\Column(name="vertragsende", type="datetime", nullable=true) */
    private ?DateTime $vertragsende;

    /** @ORM\Column(name="rolloutbeginn", type="datetime", nullable=true) */
    private ?DateTime $rolloutbeginn;

    /** @ORM\Column(name="rolloutende", type="datetime", nullable=true) */
    private ?DateTime $rolloutende;

    /** @ORM\Column(name="betriebsbeginn", type="datetime", nullable=true) */
    private ?DateTime $betriebsbeginn;

    /** @ORM\Column(name="betriebsende", type="datetime", nullable=true) */
    private ?DateTime $betriebsende;

    /** @ORM\Column(name="bemerkungen", type="text", length=-1, nullable=true) */
    private $bemerkungen;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private $bits;

    /** @ORM\Column(name="beauftragungsende", type="datetime", nullable=true) */
    private ?DateTime $beauftragungsende;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="ZETbenutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $zetbenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="AEbenutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $aebenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="SalesPrioritaet")
     * @ORM\JoinColumn(name="prioritaet_id", referencedColumnName="prioritaet_id")
     */
    private SalesPrioritaet $prioritaet;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /** @ORM\Column(name="fasttrack", type="boolean", nullable=true) */
    private bool $fasttrack;

    /**
     * SalesAnfrage constructor.
     * @param SalesStammdaten $simple
     * @param int $versionsnr
     * @param bool $ausschreibung
     * @param bool $budgetangebot
     * @param SalesPrioritaet $prioritaet
     * @param int|null $liegezeitSoll
     * @param DateTime|null $angebotAngefordertAm
     * @param DateTime|null $lieferterminAngebot
     * @param DateTime|null $lieferterminAngebotCheck
     * @param DateTime|null $vertragsbeginn
     * @param DateTime|null $vertragsende
     * @param DateTime|null $rolloutbeginn
     * @param DateTime|null $rolloutende
     * @param DateTime|null $betriebsbeginn
     * @param DateTime|null $betriebsende
     */
    public function __construct(
        SalesStammdaten $simple,
        int $versionsnr,
        bool $ausschreibung,
        bool $budgetangebot,
        SalesPrioritaet $prioritaet,
        ?int $liegezeitSoll,
        ?DateTime $angebotAngefordertAm,
        ?DateTime $lieferterminAngebot,
        ?DateTime $lieferterminAngebotCheck,
        ?DateTime $vertragsbeginn,
        ?DateTime $vertragsende,
        ?DateTime $rolloutbeginn,
        ?DateTime $rolloutende,
        ?DateTime $betriebsbeginn,
        ?DateTime $betriebsende

    )
    {
        $this->salesStammdaten = $simple;
        $this->versionsnr = $versionsnr;
        $this->ausschreibung = $ausschreibung;
        $this->budgetangebot = $budgetangebot;
        $this->prioritaet = $prioritaet;
        $this->liegezeitSoll = $liegezeitSoll;
        $this->angebotAngefordertAm = $angebotAngefordertAm;
        $this->lieferterminAngebot = $lieferterminAngebot;
        $this->lieferterminAngebotCheck = $lieferterminAngebotCheck;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSalesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return int
     */
    public function getAfVersionsId(): int
    {
        return $this->afVersionsId;
    }

    /**
     * @return int
     */
    public function getVersionsnr(): int
    {
        return $this->versionsnr;
    }

    /**
     * @return ?DateTime
     */
    public function getAngebotAngefordertAm(): ?DateTime
    {
        return $this->angebotAngefordertAm;
    }

    /**
     * @return DateTime
     */
    public function getLieferterminAngebot(): ?DateTime
    {
        return $this->lieferterminAngebot;
    }

    /**
     * @return bool
     */
    public function getAusschreibung(): bool
    {
        return $this->ausschreibung;
    }

    /**
     * @return bool
     */
    public function getBudgetangebot(): ?bool
    {
        return $this->budgetangebot;
    }

    /**
     * @return int
     */
    public function getCmWert(): ?int
    {
        return $this->cmWert;
    }

    /**
     * @return int
     */
    public function getLiegezeitSoll(): ?int
    {
        return $this->liegezeitSoll;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getVertragsbeginn(): ?DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getVertragsende(): ?DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getRolloutbeginn(): ?DateTime
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getRolloutende(): ?DateTime
    {
        return $this->rolloutende;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getBetriebsbeginn(): ?DateTime
    {
        return $this->betriebsbeginn;
    }

    /**
     * @return DateTime
     * @Groups({"projectBasic"})
     */
    public function getBetriebsende(): ?DateTime
    {
        return $this->betriebsende;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param bool $fasttrack
     */
    public function setFasttrack(bool $fasttrack): void
    {
        $this->fasttrack = $fasttrack;
    }

    /**
     * @param DateTime|null $angebotserstellerZugewiesenAm
     */
    public function setAngebotserstellerZugewiesenAm(?DateTime $angebotserstellerZugewiesenAm): void
    {
        $this->angebotserstellerZugewiesenAm = $angebotserstellerZugewiesenAm;
    }

    /**
     * @return DateTime|null
     */
    public function getBeauftragungsende(): ?DateTime
    {
        return $this->beauftragungsende;
    }

    /**
     * @param mixed $beauftragungsende
     */
    public function setBeauftragungsende($beauftragungsende): void
    {
        $this->beauftragungsende = $beauftragungsende;
    }

    /**
     * @param DateTime|null $vertragsbeginn
     */
    public function setVertragsbeginn(?DateTime $vertragsbeginn): void
    {
        $this->vertragsbeginn = $vertragsbeginn;
    }

    /**
     * @param DateTime|NULL $vertragsende
     */
    public function setVertragsende(?DateTime $vertragsende): void
    {
        $this->vertragsende = $vertragsende;
    }

    /**
     * @param DateTime|null $rolloutbeginn
     */
    public function setRolloutbeginn(?DateTime $rolloutbeginn): void
    {
        $this->rolloutbeginn = $rolloutbeginn;
    }

    /**
     * @param DateTime|null $rolloutende
     */
    public function setRolloutende(?DateTime $rolloutende): void
    {
        $this->rolloutende = $rolloutende;
    }

    /**
     * @param DateTime|null $betriebsbeginn
     */
    public function setBetriebsbeginn(?DateTime $betriebsbeginn): void
    {
        $this->betriebsbeginn = $betriebsbeginn;
    }

    /**
     * @param DateTime|null $betriebsende
     */
    public function setBetriebsende(?DateTime $betriebsende): void
    {
        $this->betriebsende = $betriebsende;
    }

    /**
     * @param bool $ausschreibung
     */
    public function setAusschreibung(bool $ausschreibung): void
    {
        $this->ausschreibung = $ausschreibung;
    }

    /**
     * @param bool $budgetangebot
     */
    public function setBudgetangebot(bool $budgetangebot): void
    {
        $this->budgetangebot = $budgetangebot;
    }


    /**
     * @return int
     */
    public function getProjectDurationInDays(): int
    {
        $diff = $this->vertragsende->diff($this->vertragsbeginn);
        return (int) $diff->format('%a') + 1;
    }
}
