<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendProjectRoles
 *
 * @ORM\Table(name="Backend_ProjectRoles")
 * @ORM\Entity
 */
class BackendProjectRoles
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten", fetch="EAGER")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRoles")
     * @ORM\JoinColumn(name="role_id", referencedColumnName="role_id")
     */
    private BackendRoles $backendRoles;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $backendBenutzer;

    /**
     * @ORM\ManyToOne(targetEntity="BackendRoleInfo")
     * @ORM\JoinColumn(name="roleinfo_id", referencedColumnName="id", nullable=true)
     */
    private ?BackendRoleInfo $backendRoleInfo = null;

    /** @ORM\Column(name="representative", type="boolean", nullable=false) */
    private bool $representative;

    /**
     * CreateBackendProjectRolesDTO constructor.
     * @param SalesStammdaten $salesStammdaten
     * @param BackendRoles $backendRoles
     * @param BackendBenutzer $backendBenutzer
     * @param BackendRoleInfo|null $backendRoleInfo
     * @param bool $representative
     */
    public function __construct(
        SalesStammdaten $salesStammdaten,
        BackendRoles  $backendRoles,
        BackendBenutzer $backendBenutzer,
        ?BackendRoleInfo $backendRoleInfo,
        bool $representative = false
    )
    {
        $this->salesStammdaten = $salesStammdaten;
        $this->backendRoles = $backendRoles;
        $this->backendBenutzer = $backendBenutzer;
        $this->representative = $representative;
        $this->backendRoleInfo = $backendRoleInfo;
    }

    /**
     * @return BackendRoles
     */
    public function getRole(): BackendRoles
    {
        return $this->backendRoles;
    }

    /**
     * @return SalesStammdaten
     */
    public function salesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->backendBenutzer;
    }

    /**
     * @return bool
     */
    public function isRepresentative(): bool
    {
        return $this->representative;
    }

    /**
     * @param BackendBenutzer $backendBenutzer
     */
    public function setUser(BackendBenutzer $backendBenutzer): void
    {
        $this->backendBenutzer = $backendBenutzer;
    }

    /**
     * @param BackendRoles $backendRoles
     */
    public function setRole(BackendRoles $backendRoles): void
    {
        $this->backendRoles = $backendRoles;
    }

    /**
     * @param bool $representative
     */
    public function setRepresentative(bool $representative): void
    {
        $this->representative = $representative;
    }

    /**
     * @param BackendBenutzer $user
     * @return bool
     */
    public function isUser(BackendBenutzer $user): bool
    {
        return $this->backendBenutzer == $user;
    }

    /**
     * @param BackendRoles $role
     * @return bool
     */
    public function isRole(BackendRoles $role): bool
    {
        return $this->backendRoles == $role;
    }

    /**
     * @param BackendRoleInfo $backendRoleInfo
     */
    public function setBackendRoleInfo(BackendRoleInfo $backendRoleInfo): void
    {
        $this->backendRoleInfo = $backendRoleInfo;
    }
}
