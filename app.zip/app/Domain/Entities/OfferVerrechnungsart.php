<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferVerrechnungsart
 *
 * @ORM\Table(name="Offer_Verrechnungsart")
 * @ORM\Entity
 */
class OfferVerrechnungsart
{
    /**
     * @var int
     *
     * @ORM\Column(name="verrechnungsart_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $verrechnungsartId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="abkuerzung", type="string", length=30, nullable=true)
     */
    private $abkuerzung;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="smallint", nullable=false)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var bool
     *
     * @ORM\Column(name="nach_aufwand", type="boolean", nullable=false)
     */
    private $nachAufwand;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;


}
