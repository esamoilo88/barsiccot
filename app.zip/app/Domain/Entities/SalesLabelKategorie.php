<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * SalesLabelKategorie
 *
 * @ORM\Table(name="Sales_Label_Kategorie")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class SalesLabelKategorie
{
    public const PORTFOLIO_ID = 35;

    /**
     * @ORM\Column(name="label_kategorie_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $labelKategorieId;

    /** @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true) */
    private $bezeichnung;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private $beschreibung;

    /** @ORM\Column(name="min_vorkommen", type="integer", nullable=true) */
    private $minVorkommen;

    /** @ORM\Column(name="max_vorkommen", type="integer", nullable=true) */
    private $maxVorkommen;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private $hide;

    /** @ORM\Column(name="readonly_status", type="string", length=50, nullable=true) */
    private $readonlyStatus;

    /** @ORM\Column(name="mandatory_status", type="string", length=50, nullable=true) */
    private $mandatoryStatus;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private $bits;

    /** @ORM\Column(name="sort", type="integer", nullable=true) */
    private $sort;

    /** @ORM\Column(name="prozentuale_eingabe", type="boolean", nullable=true) */
    private $prozentualeEingabe;

    /** @ORM\Column(name="abkuerzung", type="string", length=50, nullable=true) */
    private $abkuerzung;

    /** @ORM\OneToMany(targetEntity="SalesLabel", mappedBy="labelKategorie") */
    private Collection $labels;

    /** @ORM\Column(name="billing_relevant", type="boolean") */
    private bool $billingRelevant;

    /**
     * @return int
     */
    public function getLabelKategorieId(): int
    {
        return $this->labelKategorieId;
    }

    /**
     * @param int $labelKategorieId
     */
    public function setLabelKategorieId(int $labelKategorieId): void
    {
        $this->labelKategorieId = $labelKategorieId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return int|null
     */
    public function getMinVorkommen(): ?int
    {
        return $this->minVorkommen;
    }

    /**
     * @param int|null $minVorkommen
     */
    public function setMinVorkommen(?int $minVorkommen): void
    {
        $this->minVorkommen = $minVorkommen;
    }

    /**
     * @return int|null
     */
    public function getMaxVorkommen(): ?int
    {
        return $this->maxVorkommen;
    }

    /**
     * @param int|null $maxVorkommen
     */
    public function setMaxVorkommen(?int $maxVorkommen): void
    {
        $this->maxVorkommen = $maxVorkommen;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return string|null
     */
    public function getReadonlyStatus(): ?string
    {
        return $this->readonlyStatus;
    }

    /**
     * @param string|null $readonlyStatus
     */
    public function setReadonlyStatus(?string $readonlyStatus): void
    {
        $this->readonlyStatus = $readonlyStatus;
    }

    /**
     * @return string|null
     */
    public function getMandatoryStatus(): ?string
    {
        return $this->mandatoryStatus;
    }

    /**
     * @param string|null $mandatoryStatus
     */
    public function setMandatoryStatus(?string $mandatoryStatus): void
    {
        $this->mandatoryStatus = $mandatoryStatus;
    }

    /**
     * @return \DateTime|null
     */
    public function getBits(): ?\DateTime
    {
        return $this->bits;
    }

    /**
     * @param \DateTime|null $bits
     */
    public function setBits(?\DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @param int|null $sort
     */
    public function setSort(?int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return bool|null
     */
    public function getProzentualeEingabe(): ?bool
    {
        return $this->prozentualeEingabe;
    }

    /**
     * @param bool|null $prozentualeEingabe
     */
    public function setProzentualeEingabe(?bool $prozentualeEingabe): void
    {
        $this->prozentualeEingabe = $prozentualeEingabe;
    }

    /**
     * @return string|null
     */
    public function getAbkuerzung(): ?string
    {
        return $this->abkuerzung;
    }

    /**
     * @param string|null $abkuerzung
     */
    public function setAbkuerzung(?string $abkuerzung): void
    {
        $this->abkuerzung = $abkuerzung;
    }
}
