<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OnkaConfigurationParam
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configuration_Param")
 */
class OnkaConfigurationParam
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="value", type="decimal", precision=26, scale=16)
     */
    private $value;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguration")
     * @ORM\JoinColumn(name="configuration_id", referencedColumnName="id")
     */
    private OnkaConfiguration $configuration;

    /**
     * @ORM\ManyToOne(targetEntity="OnkaConfiguratorParam", fetch="EAGER")
     * @ORM\JoinColumn(name="param_id", referencedColumnName="id")
     */
    private OnkaConfiguratorParam $configuratorParam;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * OnkaConfigurationParam constructor.
     * @param $value
     * @param OnkaConfiguration $configuration
     * @param OnkaConfiguratorParam $configuratorParam
     */
    public function __construct($value, OnkaConfiguration $configuration, OnkaConfiguratorParam $configuratorParam)
    {
        $this->value = $value;
        $this->configuration = $configuration;
        $this->configuratorParam = $configuratorParam;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return OnkaConfiguration
     */
    public function getConfiguration(): OnkaConfiguration
    {
        return $this->configuration;
    }

    /**
     * @return OnkaConfiguratorParam
     */
    public function getConfiguratorParam(): OnkaConfiguratorParam
    {
        return $this->configuratorParam;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return Collection
     */
    public function getApMengeSource(): Collection
    {
        return $this->configuratorParam->getSourcing()->filter(function (OnkaParamSourcing $sourcing) {
            return $sourcing->getParamField()->getSysField() === OnkaParamSourcing::MENGE_SYS_FIELD_NAME &&
                $sourcing->getKatalogLp() === null;
        });
    }

    /**
     * @return Collection
     */
    public function getLpMengeSource(): Collection
    {
        return $this->configuratorParam->getSourcing()->filter(function (OnkaParamSourcing $sourcing) {
            return $sourcing->getParamField()->getSysField() === OnkaParamSourcing::MENGE_SYS_FIELD_NAME &&
                $sourcing->getKatalogAp() === null;
        });
    }

    /**
     * @param mixed $value
     */
    public function setValue($value): void
    {
        $this->value = $value;
    }
}
