<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class CompetenceSkillprofile
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Competence_Skillprofile")
 */
class CompetenceSkillprofile
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="name", type="string") */
    private string $name;

    /** @ORM\Column(name="description", type="string") */
    private string $description;

    /** @ORM\Column(name="external_id", type="string") */
    private string $externalId;

    /** @ORM\Column(name="hide", type="boolean") */
    private bool $hide;

    /** @ORM\Column(name="sort", type="integer") */
    private int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * CompetenceSkillprofile constructor.
     * @param string $name
     * @param string $description
     * @param string $externalId
     * @param bool $hide
     * @param int $sort
     */
    public function __construct(
        string $name,
        string $description,
        string $externalId,
        bool $hide,
        int $sort
    )
    {
        $this->name = $name;
        $this->description = $description;
        $this->externalId = $externalId;
        $this->hide = $hide;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @Groups({"leistungenPaginated"})
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return string
     */
    public function getExternalId(): string
    {
        return $this->externalId;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }
}
