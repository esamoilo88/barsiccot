<?php

namespace App\Domain\Entities;

use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;
use Carbon\Traits\Date;
use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * CompetenceElements
 *
 * @ORM\Table(name="Competence_Elements")
 * @ORM\Entity
 */
class CompetenceElements
{
    /**
     * @ORM\Column(name="tr_element_id", type="integer")
     * @ORM\Id
     */
    private int $trElementId;

    /**
     * @ORM\Column(name="simple_id", type="integer")
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="kostenart", type="text", length=-1, nullable=true)
     */
    private ?string $kostenart;

    /**
     * @ORM\Column(name="kostenart_id", type="integer", nullable=true)
     */
    private ?int $kostenartId;

    /**
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=true)
     */
    private ?string $stundensatz;

    /**
     * @ORM\Column(name="betrag_stunden", type="string", length=50, nullable=true)
     */
    private ?string $betragStunden;

    /**
     * @ORM\Column(name="timestamp", type="datetime", nullable=true)
     */
    private ?DateTime $timestamp;

    /**
     * @ORM\ManyToOne (targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $salesStammdaten;

    /**
     * @ORM\ManyToOne(targetEntity="CompetenceSkillprofile")
     * @ORM\JoinColumn(name="competence_skill_id", referencedColumnName="id", nullable=true)
     */
    private ?CompetenceSkillprofile $skillprofile = null;

    /**
     * CompetenceElements constructor.
     * @param int $trElementId
     * @param SalesStammdaten $stammdaten
     * @param int|null $kostenartId
     * @param string|null $kostenart
     * @param string|null $stundensatz
     * @param DateTime|null $timestamp
     * @param string|null $betragStunden
     */
    public function __construct(
        int $trElementId,
        SalesStammdaten $stammdaten,
        ?int $kostenartId,
        ?string $kostenart,
        ?string $stundensatz,
        ?DateTime $timestamp,
        ?string $betragStunden = null
    )
    {
        $this->trElementId = $trElementId;
        $this->simpleId = $stammdaten->getSimpleId();
        $this->salesStammdaten = $stammdaten;
        $this->kostenartId = $kostenartId;
        $this->kostenart = $kostenart;
        $this->stundensatz = $stundensatz;
        $this->timestamp = $timestamp;
        $this->betragStunden = $betragStunden;
    }

    /**
     * @param int $simpleId
     */
    public function setSimpleId(int $simpleId): void
    {
        $this->simpleId = $simpleId;
    }

    /**
     * @param string|null $kostenart
     */
    public function setKostenart(?string $kostenart): void
    {
        $this->kostenart = $kostenart;
    }

    /**
     * @param int|null $kostenartId
     */
    public function setKostenartId(?int $kostenartId): void
    {
        $this->kostenartId = $kostenartId;
    }

    /**
     * @param string|null $stundensatz
     */
    public function setStundensatz(?string $stundensatz): void
    {
        $this->stundensatz = $stundensatz;
    }

    /**
     * @param DateTime|null $timestamp
     */
    public function setTimestamp(?DateTime $timestamp): void
    {
        $this->timestamp = $timestamp;
    }

    /**
     * @param string|null $betragStunden
     */
    public function setBetragStunden(?string $betragStunden): void
    {
        $this->betragStunden = $betragStunden;
    }

    /**
     * @return int|null
     */
    public function getKostenartId(): ?int
    {
        return $this->kostenartId;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSIN(): SIN
    {
        return new SIN($this->simpleId);
    }
}
