<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaConfigurator
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Configurator")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaConfigurator
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(type="string")
     */
    private string $name;

    /**
     * @ORM\Column(type="string")
     * @Groups({"configurationInfo"})
     */
    private string $subtext;

    /** @ORM\Column(type="string") */
    private string $imagePath;

    /** @ORM\Column(type="boolean") */
    private bool $hide;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /** @ORM\OneToMany(targetEntity="OnkaConfiguratorItem", mappedBy="configurator") */
    private Collection $items;

    /** @ORM\OneToMany(targetEntity="OnkaConfiguratorParam", mappedBy="configurator") */
    private Collection $params;

    /**
     * OnkaConfigurator constructor.
     * @param string $name
     * @param string $subtext
     * @param string $imagePath
     * @param bool $hide
     * @param int $sort
     */
    public function __construct(
        string $name,
        string $subtext,
        string $imagePath,
        bool $hide,
        int $sort
    )
    {
        $this->name = $name;
        $this->subtext = $subtext;
        $this->imagePath = $imagePath;
        $this->hide = $hide;
        $this->sort = $sort;
        $this->items = new ArrayCollection();
        $this->params = new ArrayCollection();
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getSubtext(): string
    {
        return $this->subtext;
    }

    /**
     * @return string
     */
    public function getImagePath(): string
    {
        return $this->imagePath;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return Collection
     */
    public function getItems(): Collection
    {
        return $this->items;
    }

    /**
     * @return array|null
     */
    public function getItemsOnStart(): ?array
    {
        return array_filter($this->getItems()->toArray(), function ($l)  {
            return $l->isAddOnStart();
        });
    }

    /**
     * @return Collection
     */
    public function getParams(): Collection
    {
        return $this->params;
    }
}
