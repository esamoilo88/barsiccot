<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class MappingLegacyZuordnung
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Mapping_Legacy_Zuordnung")
 */
class MappingLegacyZuordnung
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="zuordnung", type="string", length=40, nullable=true)
     */
    private ?string $zuordnung;

    /**
     * @ORM\Column(name="qs_koeffizient", type="decimal", nullable=true)
     */
    private ?float $qsKoeffizient;

    /**
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="target_kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $targetKostenartId;
}
