<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferFakturaVorgangstyp
 *
 * @ORM\Table(name="Offer_Faktura_Vorgangstyp", uniqueConstraints={@ORM\UniqueConstraint(name="UC_Offer_Faktura_Vorgangstyp", columns={"vorgangstyp_id"})})
 * @ORM\Entity
 */
class OfferFakturaVorgangstyp
{
    /**
     * @var int
     *
     * @ORM\Column(name="vorgangstyp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $vorgangstypId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="type", type="text", length=-1, nullable=true)
     */
    private $type;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="text", length=-1, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var int
     *
     * @ORM\Column(name="sort", type="integer", nullable=false)
     */
    private $sort;

    /**
     * @var bool
     *
     * @ORM\Column(name="hide", type="boolean", nullable=false)
     */
    private $hide;

    /**
     * @var bool
     *
     * @ORM\Column(name="credit", type="boolean", nullable=false)
     */
    private $credit;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var bool
     *
     * @ORM\Column(name="negative", type="boolean", nullable=false)
     */
    private bool $negative = false;

    /**
     * @return int
     */
    public function getVorgangstypId(): int
    {
        return $this->vorgangstypId;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return bool
     */
    public function isNegative(): bool
    {
        return $this->negative;
    }

    /**
     * @param bool $negative
     */
    public function setNegative(bool $negative): void
    {
        $this->negative = $negative;
    }

    /**
     * @return string|null
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @return bool
     */
    public function isCredit(): bool
    {
        return $this->credit;
    }
}
