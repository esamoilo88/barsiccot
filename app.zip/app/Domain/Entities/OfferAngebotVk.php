<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * OfferAngebotVk
 *
 * @ORM\Table(name="Offer_Angebot_VK")
 * @ORM\Entity
 */
class OfferAngebotVk
{
    /**
     * @ORM\Column(name="vk_versions_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $vkVersionsId;

    /** @ORM\Column(name="versionsnr", type="smallint", nullable=false) */
    private int $versionsnr;

    /** @ORM\Column(name="versionsgrund", type="text", length=-1, nullable=true) */
    private ?string $versionsgrund;

    /** @ORM\Column(name="bearbeitung_begonnen_am", type="datetime", nullable=true) */
    private ?DateTime $bearbeitungBegonnenAm;

    /** @ORM\Column(name="kvm_eingebunden_am", type="datetime", nullable=true) */
    private ?DateTime $kvmEingebundenAm;

    /** @ORM\Column(name="anforderung_kvm", type="text", length=-1, nullable=true) */
    private ?string $anforderungKvm;

    /** @ORM\Column(name="kvm_zugewiesen_am", type="datetime", nullable=true) */
    private ?DateTime $kvmZugewiesenAm;

    /** @ORM\Column(name="kvm_abgeschlossen_am", type="datetime", nullable=true) */
    private ?DateTime $kvmAbgeschlossenAm;

    /** @ORM\Column(name="controlling_informiert_am", type="datetime", nullable=true) */
    private ?DateTime $controllingInformiertAm;

    /** @ORM\Column(name="weitergeleitet_am", type="datetime", nullable=true) */
    private ?DateTime $weitergeleitetAm;

    /** @ORM\Column(name="offer_completed", type="datetime", nullable=true) */
    private ?DateTime $offerCompleted;

    /** @ORM\Column(name="vk_standard", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $vkStandard;

    /** @ORM\Column(name="vk_individual", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $vkIndividual;

    /** @ORM\Column(name="vk_gesamt", type="decimal", precision=18, scale=2, nullable=true) */
    private ?string $vkGesamt;

    /** @ORM\Column(name="favorit_ae", type="boolean", nullable=true) */
    private ?bool $favoritAe;

    /** @ORM\Column(name="favorit_hk", type="boolean", nullable=true) */
    private ?bool $favoritHk;

    /** @ORM\Column(name="freigabe_gl", type="boolean", nullable=true) */
    private ?bool $freigabeGl;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?DateTime $bits;

    /** @ORM\Column(name="preisfaktor", type="decimal", precision=9, scale=2, nullable=true) */
    private ?float $preisfaktor = null;

    /** @ORM\Column(name="marge", type="decimal", precision=9, scale=2, nullable=true) */
    private ?float $marge = null;

    /** @ORM\Column(name="angebot_gueltig_bis", type="datetime", nullable=true) */
    private ?DateTime $angebotGueltigBis;

    /** @ORM\Column(name="skill_anforderungen", type="text", length=-1, nullable=true) */
    private ?string $skillAnforderungen;

    /** @ORM\Column(name="total_price", type="decimal", precision=18, scale=2, nullable=true) */
    private ?float $totalPrice = null;

    /** @ORM\Column(name="gmkz", type="decimal", precision=7, scale=4, nullable=true) */
    private ?float $gmkz = null;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="KVMbenutzer_id", referencedColumnName="benutzer_id", nullable=true)
     */
    private ?BackendBenutzer $kvmbenutzer = null;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKvmEinbindungsgrund")
     * @ORM\JoinColumn(name="einbindungsgrund_id", referencedColumnName="einbindungsgrund_id")
     */
    private OfferKvmEinbindungsgrund $einbindungsgrund;

    /**
     * @ORM\ManyToOne(targetEntity="SalesAnfrage")
     * @ORM\JoinColumn(name="af_versions_id", referencedColumnName="af_versions_id")
     */
    private SalesAnfrage $afVersions;

    /**
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $globalGate;

    /** @ORM\OneToOne(targetEntity="SalesVersionierung", mappedBy="vkVersions") */
    private ?SalesVersionierung $salesVersionierung;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationAngebotsposition", mappedBy="vkVersions") */
    private Collection $angebotspositionen;

    /** @ORM\OneToMany(targetEntity="OfferKalkulationVariable", mappedBy="vkVersions") */
    private Collection $variables;

    /**
     * OfferAngebotVk constructor.
     * @param int $versionsnr
     * @param string $versionsgrund
     * @param DateTime $bearbeitungBegonnenAm
     * @param string $vkStandard
     * @param string $vkIndividual
     * @param string $vkGesamt
     * @param SalesAnfrage $afVersions
     * @param GlobalGate $globalGate
     */
    public function __construct(
        int $versionsnr,
        string $versionsgrund,
        DateTime $bearbeitungBegonnenAm,
        string $vkStandard,
        string $vkIndividual,
        string $vkGesamt,
        SalesAnfrage $afVersions,
        GlobalGate $globalGate
    )
    {
        $this->versionsnr = $versionsnr;
        $this->versionsgrund = $versionsgrund;
        $this->bearbeitungBegonnenAm = $bearbeitungBegonnenAm;
        $this->vkStandard = $vkStandard;
        $this->vkIndividual = $vkIndividual;
        $this->vkGesamt = $vkGesamt;
        $this->afVersions = $afVersions;
        $this->globalGate = $globalGate;
        $this->angebotspositionen = new ArrayCollection();
        $this->variables = new ArrayCollection();
    }

    /**
     * @return int
     * @Groups({"offerBasic"})
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @param int $vkVersionsId
     */
    public function setVkVersionsId(int $vkVersionsId): void
    {
        $this->vkVersionsId = $vkVersionsId;
    }

    /**
     * @return string
     */
    public function getVersionsnr(): string
    {
        return $this->versionsnr;
    }

    /**
     * @return SalesVersionierung|null
     */
    public function getSalesVersionierung(): ?SalesVersionierung
    {
        return $this->salesVersionierung;
    }

    /**
     * @return string
     */
    public function getVersionsnrWithPrefix(): string
    {
        return 'V' . $this->versionsnr;
    }

    /**
     * @param int $versionsnr
     */
    public function setVersionsnr(int $versionsnr): void
    {
        $this->versionsnr = $versionsnr;
    }

    /**
     * @return string|null
     */
    public function getVersionsgrund(): ?string
    {
        return $this->versionsgrund;
    }

    /**
     * @param string|null $versionsgrund
     */
    public function setVersionsgrund(?string $versionsgrund): void
    {
        $this->versionsgrund = $versionsgrund;
    }

    /**
     * @return DateTime|null
     */
    public function getBearbeitungBegonnenAm(): ?DateTime
    {
        return $this->bearbeitungBegonnenAm;
    }

    /**
     * @param DateTime|null $bearbeitungBegonnenAm
     */
    public function setBearbeitungBegonnenAm(?DateTime $bearbeitungBegonnenAm): void
    {
        $this->bearbeitungBegonnenAm = $bearbeitungBegonnenAm;
    }

    /**
     * @return DateTime|null
     */
    public function getKvmEingebundenAm(): ?DateTime
    {
        return $this->kvmEingebundenAm;
    }

    /**
     * @param DateTime|null $kvmEingebundenAm
     */
    public function setKvmEingebundenAm(?DateTime $kvmEingebundenAm): void
    {
        $this->kvmEingebundenAm = $kvmEingebundenAm;
    }

    /**
     * @return string|null
     */
    public function getAnforderungKvm(): ?string
    {
        return $this->anforderungKvm;
    }

    /**
     * @param string|null $anforderungKvm
     */
    public function setAnforderungKvm(?string $anforderungKvm): void
    {
        $this->anforderungKvm = $anforderungKvm;
    }

    /**
     * @return DateTime|null
     */
    public function getKvmZugewiesenAm(): ?DateTime
    {
        return $this->kvmZugewiesenAm;
    }

    /**
     * @param DateTime|null $kvmZugewiesenAm
     */
    public function setKvmZugewiesenAm(?DateTime $kvmZugewiesenAm): void
    {
        $this->kvmZugewiesenAm = $kvmZugewiesenAm;
    }

    /**
     * @return DateTime|null
     */
    public function getKvmAbgeschlossenAm(): ?DateTime
    {
        return $this->kvmAbgeschlossenAm;
    }

    /**
     * @param DateTime|null $kvmAbgeschlossenAm
     */
    public function setKvmAbgeschlossenAm(?DateTime $kvmAbgeschlossenAm): void
    {
        $this->kvmAbgeschlossenAm = $kvmAbgeschlossenAm;
    }

    /**
     * @return DateTime|null
     */
    public function getControllingInformiertAm(): ?DateTime
    {
        return $this->controllingInformiertAm;
    }

    /**
     * @param DateTime|null $controllingInformiertAm
     */
    public function setControllingInformiertAm(?DateTime $controllingInformiertAm): void
    {
        $this->controllingInformiertAm = $controllingInformiertAm;
    }

    /**
     * @return DateTime|null
     */
    public function getWeitergeleitetAm(): ?DateTime
    {
        return $this->weitergeleitetAm;
    }

    /**
     * @param DateTime|null $weitergeleitetAm
     */
    public function setWeitergeleitetAm(?DateTime $weitergeleitetAm): void
    {
        $this->weitergeleitetAm = $weitergeleitetAm;
    }

    /**
     * @return string|null
     */
    public function getVkStandard(): ?string
    {
        return $this->vkStandard;
    }

    /**
     * @param string|null $vkStandard
     */
    public function setVkStandard(?string $vkStandard): void
    {
        $this->vkStandard = $vkStandard;
    }

    /**
     * @return string|null
     */
    public function getVkIndividual(): ?string
    {
        return $this->vkIndividual;
    }

    /**
     * @param string|null $vkIndividual
     */
    public function setVkIndividual(?string $vkIndividual): void
    {
        $this->vkIndividual = $vkIndividual;
    }

    /**
     * @return string|null
     */
    public function getVkGesamt(): ?string
    {
        return $this->vkGesamt;
    }

    /**
     * @param string|null $vkGesamt
     */
    public function setVkGesamt(?string $vkGesamt): void
    {
        $this->vkGesamt = $vkGesamt;
    }

    /**
     * @return bool|null
     */
    public function getFavoritAe(): ?bool
    {
        return $this->favoritAe;
    }

    /**
     * @param bool|null $favoritAe
     */
    public function setFavoritAe(?bool $favoritAe): void
    {
        $this->favoritAe = $favoritAe;
    }

    /**
     * @return bool|null
     */
    public function getFavoritHk(): ?bool
    {
        return $this->favoritHk;
    }

    /**
     * @param bool|null $favoritHk
     */
    public function setFavoritHk(?bool $favoritHk): void
    {
        $this->favoritHk = $favoritHk;
    }

    /**
     * @return bool|null
     */
    public function getFreigabeGl(): ?bool
    {
        return $this->freigabeGl;
    }

    /**
     * @param bool|null $freigabeGl
     */
    public function setFreigabeGl(?bool $freigabeGl): void
    {
        $this->freigabeGl = $freigabeGl;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @return DateTime|null
     */
    public function getBits(): ?DateTime
    {
        return $this->bits;
    }

    /**
     * @param DateTime|null $bits
     */
    public function setBits(?DateTime $bits): void
    {
        $this->bits = $bits;
    }

    /**
     * @return float|null
     * @Groups({"offerBasic"})
     */
    public function getPreisfaktor(): ?float
    {
        return $this->preisfaktor ?? 0.00;
    }

    /**
     * @param float|null $preisfaktor
     */
    public function setPreisfaktor(?float $preisfaktor): void
    {
        $this->preisfaktor = $preisfaktor;
    }

    /**
     * @return float|null
     * @Groups({"offerBasic"})
     */
    public function getMarge(): ?float
    {
        return $this->marge ?? 0.00;
    }

    /**
     * @param float|null $marge
     */
    public function setMarge(?float $marge): void
    {
        $this->marge = $marge;
    }

    /**
     * @return float|null
     */
    public function getGmkz(): ?float
    {
        return $this->gmkz ?? 0.00;
    }

    /**
     * @param float|null $gmkz
     */
    public function setGmkz(?float $gmkz): void
    {
        $this->gmkz = $gmkz;
    }

    /**
     * @return DateTime|null
     */
    public function getAngebotGueltigBis(): ?DateTime
    {
        return $this->angebotGueltigBis;
    }

    /**
     * @param DateTime|null $angebotGueltigBis
     */
    public function setAngebotGueltigBis(?DateTime $angebotGueltigBis): void
    {
        $this->angebotGueltigBis = $angebotGueltigBis;
    }

    /**
     * @return string|null
     */
    public function getSkillAnforderungen(): ?string
    {
        return $this->skillAnforderungen;
    }

    /**
     * @param string|null $skillAnforderungen
     */
    public function setSkillAnforderungen(?string $skillAnforderungen): void
    {
        $this->skillAnforderungen = $skillAnforderungen;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getKvmbenutzer(): ?BackendBenutzer
    {
        return $this->kvmbenutzer;
    }

    /**
     * @param BackendBenutzer $kvmbenutzer
     */
    public function setKvmbenutzer(BackendBenutzer $kvmbenutzer): void
    {
        $this->kvmbenutzer = $kvmbenutzer;
    }

    /**
     * @return OfferKvmEinbindungsgrund
     */
    public function getEinbindungsgrund(): OfferKvmEinbindungsgrund
    {
        return $this->einbindungsgrund;
    }

    /**
     * @param OfferKvmEinbindungsgrund $einbindungsgrund
     */
    public function setEinbindungsgrund(OfferKvmEinbindungsgrund $einbindungsgrund): void
    {
        $this->einbindungsgrund = $einbindungsgrund;
    }

    /**
     * @return SalesAnfrage
     */
    public function getAfVersions(): SalesAnfrage
    {
        return $this->afVersions;
    }

    /**
     * @param SalesAnfrage $afVersions
     */
    public function setAfVersions(SalesAnfrage $afVersions): void
    {
        $this->afVersions = $afVersions;
    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }

    /**
     * @param GlobalGate $globalGate
     */
    public function setGlobalGate(GlobalGate $globalGate): void
    {
        $this->globalGate = $globalGate;
    }

    /**
     * @param float|null $totalPrice
     */
    public function setTotalPrice(?float $totalPrice): void
    {
        $this->totalPrice = $totalPrice;
    }

    /**
     * @return float|null
     */
    public function getTotalPrice(): ?float
    {
        return $this->totalPrice;
    }

    /**
     * @return bool
     */
    public function isBeauftragt(): bool
    {
        return ! $this->getGlobalGate()->isPresales();
    }

    /**
     * @return DateTime|null
     */
    public function getOfferCompleted(): ?DateTime
    {
        return $this->offerCompleted;
    }

    /**
     * @param DateTime|null $offerCompleted
     */
    public function setOfferCompleted(?DateTime $offerCompleted): void
    {
        $this->offerCompleted = $offerCompleted;
    }

    /**
     * @return float
     */
    public function getMargeEff(): float
    {
        if ($this->getVkGesamt() > 0 && $this->getTotalPrice() > 0) {
            return ($this->getTotalPrice() / $this->getVkGesamt() * 100) - 100;
        }

        return 0.00;
    }

    /**
     * @return Collection
     */
    public function getAngebotspositionen(): Collection
    {
        return $this->angebotspositionen;
    }

    /**
     * @return Collection
     */
    public function getVariables(): Collection
    {
        return $this->variables;
    }
}
