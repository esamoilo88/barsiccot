<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity
 * @ORM\Table(name="Finance_Calendar")
 */
class FinanceCalendar
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="`group`", type="string", length=50) */
    private string $group;

    /** @ORM\Column(name="process", type="string", length=50) */
    private string $process;

    /** @ORM\Column(name="description", type="string", length=-1, nullable=true) */
    private ?string $description;

    /** @ORM\Column(name="date_value", type="string", length=10) */
    private string $dateValue;

    /** @ORM\Column(name="time_value", type="string", length=20) */
    private string $timeValue;

    /** @ORM\Column(name="sys_name_info", type="string", length=50, nullable=true) */
    private ?string $sysNameInfo = null;

    /** @ORM\Column(name="hide", type="boolean") */
    private bool $hide = false;

    /** @ORM\Column(name="sort", type="integer") */
    private int $sort = 0;

    /** @ORM\Column(name="color", type="string", length=16, nullable=true) */
    private ?string $color;

    /**
     * FinanceCalendar constructor.
     * @param string $group
     * @param string $process
     * @param string $dateValue
     * @param string $timeValue
     */
    public function __construct(string $group, string $process, string $dateValue, string $timeValue)
    {
        $this->group = $group;
        $this->process = $process;
        $this->dateValue = $dateValue;
        $this->timeValue = $timeValue;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * @param string $group
     */
    public function setGroup(string $group): void
    {
        $this->group = $group;
    }

    /**
     * @return string
     */
    public function getProcess(): string
    {
        return $this->process;
    }

    /**
     * @param string $process
     */
    public function setProcess(string $process): void
    {
        $this->process = $process;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @param string|null $description
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @return string
     */
    public function getDateValue(): string
    {
        return $this->dateValue;
    }

    /**
     * @param string $dateValue
     */
    public function setDateValue(string $dateValue): void
    {
        $this->dateValue = $dateValue;
    }

    /**
     * @return string
     */
    public function getTimeValue(): string
    {
        return $this->timeValue;
    }

    /**
     * @param string $timeValue
     */
    public function setTimeValue(string $timeValue): void
    {
        $this->timeValue = $timeValue;
    }

    /**
     * @return string|null
     */
    public function getSysNameInfo(): ?string
    {
        return $this->sysNameInfo;
    }

    /**
     * @param string|null $sysNameInfo
     */
    public function setSysNameInfo(?string $sysNameInfo): void
    {
        $this->sysNameInfo = $sysNameInfo;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @param bool $hide
     */
    public function setHide(bool $hide): void
    {
        $this->hide = $hide;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return string|null
     */
    public function getColor(): ?string
    {
        return $this->color;
    }

    /**
     * @param string|null $color
     */
    public function setColor(?string $color): void
    {
        $this->color = $color;
    }
}
