<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * TmpCrmGp
 *
 * @ORM\Table(name="tmp_CRM_GP")
 * @ORM\Entity
 */
class TmpCrmGp
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_nr", type="text", length=-1, nullable=true)
     */
    private $gpNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_name_lang", type="text", length=-1, nullable=true)
     */
    private $gpNameLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_plz", type="text", length=-1, nullable=true)
     */
    private $gpPlz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_ort", type="text", length=-1, nullable=true)
     */
    private $gpOrt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ust_id", type="text", length=-1, nullable=true)
     */
    private $ustId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="status", type="text", length=-1, nullable=true)
     */
    private $status;

    /**
     * @var string|null
     *
     * @ORM\Column(name="segment", type="text", length=-1, nullable=true)
     */
    private $segment;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_id", type="text", length=-1, nullable=true)
     */
    private $wzId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_name", type="text", length=-1, nullable=true)
     */
    private $wzName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_id", type="text", length=-1, nullable=true)
     */
    private $zgId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_name", type="text", length=-1, nullable=true)
     */
    private $zgName;


}
