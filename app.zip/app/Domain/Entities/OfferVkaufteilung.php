<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferVkaufteilung
 *
 * @ORM\Table(name="Offer_VKAufteilung")
 * @ORM\Entity
 */
class OfferVkaufteilung
{
    /**
     * @var int
     *
     * @ORM\Column(name="vka_id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $vkaId;

    /**
     * @var string
     *
     * @ORM\Column(name="stundensatz", type="decimal", precision=18, scale=2, nullable=false)
     */
    private $stundensatz;

    /**
     * @var string
     *
     * @ORM\Column(name="betrag_euro", type="decimal", precision=18, scale=2, nullable=false)
     */
    private $betragEuro;

    /**
     * @var string|null
     *
     * @ORM\Column(name="betrag_prozent", type="decimal", precision=18, scale=2, nullable=true)
     */
    private $betragProzent;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="manuell", type="boolean", nullable=true)
     */
    private $manuell;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private $bits;

    /**
     * @var int|null
     *
     * @ORM\Column(name="kostenstelle_id", type="integer", nullable=true)
     */
    private $kostenstelleId;

    /**
     * @ORM\Column(type="integer")
     */
    private int $kostenartId;

    /**
     * @var CostsKostenart
     *
     * @ORM\ManyToOne(targetEntity="CostsKostenart")
     * @ORM\JoinColumn(name="kostenart_id", referencedColumnName="kostenart_id")
     */
    private CostsKostenart $kostenart;

    /**
     * @var OfferAngebotVk
     *
     * @ORM\ManyToOne(targetEntity="OfferAngebotVk")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="vk_versions_id", referencedColumnName="vk_versions_id")
     * })
     */
    private $vkVersions;

    /**
     * @var SalesStammdaten
     *
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     * })
     */
    private $simple;

    /**
     * @param SalesStammdaten $simple
     */
    public function setSimple(SalesStammdaten $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @param OfferAngebotVk $vkVersions
     */
    public function setVkVersions(OfferAngebotVk $vkVersions): void
    {
        $this->vkVersions = $vkVersions;
    }

    /**
     * @param CostsKostenart|object $kostenart
     */
    public function setKostenart(CostsKostenart $kostenart): void
    {
        $this->kostenart = $kostenart;
    }

    /**
     * @param string $stundensatz
     */
    public function setStundensatz(string $stundensatz): void
    {
        $this->stundensatz = $stundensatz;
    }

    /**
     * @param string $betragEuro
     */
    public function setBetragEuro(string $betragEuro): void
    {
        $this->betragEuro = $betragEuro;
    }

    /**
     * @param string|null $betragProzent
     */
    public function setBetragProzent(?string $betragProzent): void
    {
        $this->betragProzent = $betragProzent;
    }

    /**
     * @param bool|null $manuell
     */
    public function setManuell(?bool $manuell): void
    {
        $this->manuell = $manuell;
    }
}
