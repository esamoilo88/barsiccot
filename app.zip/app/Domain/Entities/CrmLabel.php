<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\Common\Collections\Collection;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CrmKunde
 *
 * @ORM\Table(name="CRM_Label")
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CrmLabel
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="CrmLabelCategory")
     * @ORM\JoinColumn(name="crm_category_id", referencedColumnName="id")
     */
    private CrmLabelCategory $crmCategory;

    /** @ORM\OneToMany(targetEntity="CrmCustomerLabel", mappedBy="label") */
    private Collection $crmCustomerLabel;

    /** @ORM\Column(name="name", type="string", nullable=false) */
    private string $name;

    /** @ORM\Column(name="description", type="string", nullable=true) */
    private ?string $description;

    /** @ORM\Column(name="hide", type="boolean", nullable=false) */
    private bool $hide;

    /** @ORM\Column(name="sort", type="integer", nullable=false, options={"default"="1"}) */
    private int $sort = 1;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="bits", type="datetime", nullable=true)
     */
    private ?DateTime $bits;

    /**
     * @return int
     * @Groups({"customerBasis"})
     */
    public function getId(): int
    {
        return $this->id;
    }
}
