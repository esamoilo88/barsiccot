<?php

namespace App\Domain\Entities;

use App\Domain\Entities\Interfaces\Automailable;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Automail_VertragsendeErinnerung")
 */
class v_AutomailVertragsendeErinnerung implements Automailable
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="simple_id", type="string")
     */
    private int $simple_id;

    /**
     * @ORM\Column(name="thema", type="string", nullable=true)
     */
    private ?string $thema;

    /**
     * @ORM\Column(name="kundenname", type="string", nullable=true)
     */
    private ?string $kundenname;

    /**
     * @ORM\Column(name="role_short", type="string", nullable=true)
     */
    private ?string $role_short;

    /**
     * @ORM\Column(name="email", type="string", nullable=true)
     */
    private ?string $email;

    /**
     * @ORM\Column(name="vertragsende", type="string", nullable=true)
     */
    private ?string $vertragsende;

    /**
     * @ORM\Column(name="betriebsende", type="string", nullable=true)
     */
    private ?string $betriebsende;

    /**
     * @ORM\Column(name="nachname", type="string", nullable=true)
     */
    private ?string $nachname;

    /**
     * @ORM\Column(name="vorname", type="string", nullable=true)
     */
    private ?string $vorname;

    /**
     * @ORM\Column(name="anrede", type="string", nullable=true)
     */
    private ?string $anrede;

    /**
     * @ORM\Column(name="benutzer_id", type="string", nullable=true)
     */
    private ?string $benutzerId;

    /**
     * @ORM\Column(name="rlfz_ve", type="string", nullable=true)
     */
    private ?string $rlfz_ve;

    /**
     * @ORM\Column(name="rlfz_be", type="string", nullable=true)
     */
    private ?string $rlfz_be;

    /**
     * @ORM\Column(name="x90_date", type="string", nullable=true)
     */
    private ?string $x90_date;

    /**
     * @ORM\Column(name="x60_date", type="string", nullable=true)
     */
    private ?string $x60_date;

    /**
     * @ORM\Column(name="x15_date", type="string", nullable=true)
     */
    private ?string $x15_date;

    /**
     * @ORM\Column(name="xp60_date", type="string", nullable=true)
     */
    private ?string $xp60_date;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simple_id' => $this->simple_id,
            'thema' => $this->thema,
            'kundenname' => $this->kundenname,
            'email' => $this->email,
            'vertragsbeginn' => $this->vertragsende,
            'nachname' => $this->nachname,
            'vorname' => $this->vorname,
            'anrede' => $this->anrede,
            'role_short' => $this->role_short
        ];
    }
}
