<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtTransparenztoollisteImport
 *
 * @ORM\Table(name="ext_Transparenztoolliste_import")
 * @ORM\Entity
 */
class ExtTransparenztoollisteImport
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="id_kategorie_1", type="string", length=50, nullable=true)
     */
    private $idKategorie1;

    /**
     * @var string|null
     *
     * @ORM\Column(name="id_kategorie_2", type="string", length=50, nullable=true)
     */
    private $idKategorie2;

    /**
     * @var string|null
     *
     * @ORM\Column(name="id_produkt", type="string", length=50, nullable=true)
     */
    private $idProdukt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kategorie_1", type="text", length=-1, nullable=true)
     */
    private $kategorie1;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kategorie_2", type="text", length=-1, nullable=true)
     */
    private $kategorie2;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produktbezeichnung", type="text", length=-1, nullable=true)
     */
    private $produktbezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="produktbezeichnung_tt", type="text", length=-1, nullable=true)
     */
    private $produktbezeichnungTt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="smile_taetigkeit", type="string", length=50, nullable=true)
     */
    private $smileTaetigkeit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bereitstellen", type="string", length=50, nullable=true)
     */
    private $bereitstellen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="instandsetzen", type="string", length=50, nullable=true)
     */
    private $instandsetzen;

    /**
     * @var string|null
     *
     * @ORM\Column(name="auskundung", type="string", length=50, nullable=true)
     */
    private $auskundung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="schulung", type="string", length=50, nullable=true)
     */
    private $schulung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="temporaer", type="string", length=50, nullable=true)
     */
    private $temporaer;

    /**
     * @var string|null
     *
     * @ORM\Column(name="locked", type="string", length=50, nullable=true)
     */
    private $locked;

    /**
     * @var string|null
     *
     * @ORM\Column(name="lkz", type="string", length=50, nullable=true)
     */
    private $lkz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="stand", type="string", length=50, nullable=true)
     */
    private $stand;

    /**
     * @var string|null
     *
     * @ORM\Column(name="neu_ab", type="string", length=50, nullable=true)
     */
    private $neuAb;


}
