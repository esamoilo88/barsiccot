<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendRoles
 *
 * @ORM\Table(name="Backend_Project_Group")
 * @ORM\Entity
 */
class BackendProjectGroup
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="BackendGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private BackendGroup $group;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /** @ORM\Column(name="bits", type="datetime", nullable=true) */
    private ?\DateTime $bits;

    /**
     * BackendProjectGroup constructor.
     * @param SalesStammdaten $simple
     * @param BackendGroup $group
     */
    public function __construct(
        SalesStammdaten $simple,
        BackendGroup $group
    )
    {
        $this->simple = $simple;
        $this->group = $group;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return BackendGroup
     */
    public function getGroup(): BackendGroup
    {
        return $this->group;
    }
}
