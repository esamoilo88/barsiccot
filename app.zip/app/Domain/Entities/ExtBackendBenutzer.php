<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * ExtBackendBenutzer
 *
 * @ORM\Table(name="ext_Backend_Benutzer")
 * @ORM\Entity
 */
class ExtBackendBenutzer
{
    /**
     * @var int
     *
     * @ORM\Column(name="temp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $tempId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="vorname", type="string", length=50, nullable=true)
     */
    private $vorname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nachname", type="string", length=50, nullable=true)
     */
    private $nachname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="firma", type="text", length=-1, nullable=true)
     */
    private $firma;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ressort", type="string", length=50, nullable=true)
     */
    private $ressort;

    /**
     * @var string|null
     *
     * @ORM\Column(name="org_einheit", type="string", length=50, nullable=true)
     */
    private $orgEinheit;

    /**
     * @var string|null
     *
     * @ORM\Column(name="mail", type="text", length=-1, nullable=true)
     */
    private $mail;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tel_nr", type="string", length=50, nullable=true)
     */
    private $telNr;


}
