<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferMeilenstein
 *
 * @ORM\Table(name="Offer_Meilenstein")
 * @ORM\Entity
 */
class OfferMeilenstein
{
    /**
     * @var int
     *
     * @ORM\Column(name="meilenstein_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $meilensteinId;

    /**
     * @var int
     *
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private $simpleId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="bezeichnung", type="string", length=200, nullable=true)
     */
    private $bezeichnung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="termin_basis", type="date", nullable=false)
     */
    private $terminBasis;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="termin_aktualisiert", type="date", nullable=true)
     */
    private $terminAktualisiert;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="termin_ist", type="date", nullable=true)
     */
    private $terminIst;

    /**
     * @var int
     *
     * @ORM\Column(name="fortschritt", type="smallint", nullable=false)
     */
    private $fortschritt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

}
