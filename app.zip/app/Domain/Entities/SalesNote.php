<?php


namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Table(name="Sales_Notes")
 * @ORM\Entity
 */
class SalesNote
{
    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     */
    private string $note;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean")
     */
    private bool $isPrivate;

    /**
     * @var DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @var DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /**
     * @var GlobalGate
     *
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private GlobalGate $project;

    /**
     * @var BackendBenutzer
     *
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $user;

    /**
     * @var SalesNotetype
     *
     * @ORM\ManyToOne(targetEntity="SalesNotetype")
     * @ORM\JoinColumn(name="notetype_id", referencedColumnName="id")
     */
    private SalesNotetype $type;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getNote(): string
    {
        return $this->note;
    }

    /**
     * @return bool
     */
    public function isPrivate(): bool
    {
        return $this->isPrivate;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function getModified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return GlobalGate
     */
    public function getProject(): GlobalGate
    {
        return $this->project;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return SalesNotetype
     */
    public function getType(): SalesNotetype
    {
        return $this->type;
    }

    /**
     * @param string $note
     */
    public function setNote(string $note): void
    {
        $this->note = $note;
    }

    /**
     * @param GlobalGate $project
     */
    public function setProject(GlobalGate $project): void
    {
        $this->project = $project;
    }

    /**
     * @param BackendBenutzer $user
     */
    public function setUser(BackendBenutzer $user): void
    {
        $this->user = $user;
    }

    /**
     * @param bool $isPrivate
     */
    public function setIsPrivate(bool $isPrivate): void
    {
        $this->isPrivate = $isPrivate;
    }

    /**
     * @param DateTime $modified
     */
    public function setModified(DateTime $modified): void
    {
        $this->modified = $modified;
    }

    /**
     * @param DateTime $created
     */
    public function setCreated(DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @param SalesNotetype $type
     */
    public function setType(SalesNotetype $type): void
    {
        $this->type = $type;
    }

    /**
     * @param BackendBenutzer $user
     * @return bool
     */
    public function isUser(BackendBenutzer $user): bool
    {
        return $this->user == $user;
    }
}
