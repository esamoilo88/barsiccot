<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * BackendBenutzerPasswort
 *
 * @ORM\Table(name="Backend_Benutzer_Passwort")
 * @ORM\Entity
 */
class BackendBenutzerPassword
{
    /**
     * @ORM\Column(name="passwort_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $passwordId;

    /**
     * @ORM\Column(name="passwort", type="string", length=100, nullable=true)
     */
    private string $password;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private BackendBenutzer $backendBenutzer;

    /**
     * BackendBenutzerPasswort constructor.
     * @param string $password
     * @param BackendBenutzer $backendBenutzer
     */
    public function __construct(string $password, BackendBenutzer $backendBenutzer)
    {
        $this->password = $password;
        $this->backendBenutzer = $backendBenutzer;
    }

    /**
     * @param string $password
     * @return bool
     */
    public function isEqualsTo(string $password): bool
    {
        return $this->password === $password;
    }
}
