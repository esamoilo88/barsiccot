<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * CompetenceCommunication
 *
 * @ORM\Table(name="Competence_Communication")
 * @ORM\Entity
 */
class CompetenceCommunication
{
    /**
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\Column(name="simple_id", type="integer", nullable=false)
     */
    private int $simpleId;

    /**
     * @ORM\Column(name="type", type="string", length=28, nullable=true, options={"fixed"=true})
     */
    private ?string  $type;

    /**
     * @ORM\Column(name="response", type="string", length=0, nullable=true)
     */
    private ?string $response;

    /**
     * @ORM\Column(name="controller_name", type="string", length=50, nullable=true)
     */
    private ?string $controllerName;

    /**
     * @ORM\Column(name="timestamp", type="datetime", nullable=true)
     */
    private ?DateTime $timestamp;

    /**
     * @ORM\Column(name="action", type="string", length=50, nullable=true)
     */
    private ?string $action;

    /**
     * CompetenceCommunication constructor.
     * @param int $simpleId
     * @param string|null $type
     * @param string|null $controllerName
     * @param string|null $action
     * @param DateTime|null $timestamp
     * @param string|null $response
     */
    public function __construct(
        int $simpleId,
        ?string $type = null,
        ?string $controllerName = null,
        ?string $action = null,
        ?DateTime $timestamp = null,
        ?string $response = null
    )
    {
        $this->simpleId = $simpleId;
        $this->type = $type;
        $this->controllerName = $controllerName;
        $this->action = $action;
        $this->timestamp = $timestamp;
        $this->response = $response;
    }

}
