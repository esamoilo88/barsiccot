<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * OfferForecastSchema
 *
 * @ORM\Table(name="Offer_Forecast_Schema")
 * @ORM\Entity
 */
class OfferForecastSchema
{
    /**
     * @ORM\Column(name="schema_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $schemaId;

    /** @ORM\Column(name="bezeichnung", type="string", length=50, nullable=true) */
    private ?string $bezeichnung;

    /** @ORM\Column(name="beschreibung", type="text", length=-1, nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="sort", type="integer", nullable=false) */
    private int $sort;

//    /** @ORM\Column(name="valid_from", type="datetime", nullable=false, options={"default"="sysutcdatetime()"}) */
//    private $validFrom = 'sysutcdatetime()';
//
//    /**
//     * @var \DateTime
//     *
//     * @ORM\Column(name="valid_to", type="datetime", nullable=false, options={"default"="CONVERT([datetime2](0),'9999-12-31 23:59:59')"})
//     */
//    private $validTo = 'CONVERT([datetime2](0),\'9999-12-31 23:59:59\')';

    /** @ORM\Column(name="umsatz_decile_1", type="integer", nullable=false) */
    private int $umsatzDecile1 = 0;

    /** @ORM\Column(name="umsatz_decile_2", type="integer", nullable=false) */
    private int $umsatzDecile2 = 0;

    /** @ORM\Column(name="umsatz_decile_3", type="integer", nullable=false) */
    private int $umsatzDecile3 = 0;

    /** @ORM\Column(name="umsatz_decile_4", type="integer", nullable=false) */
    private int $umsatzDecile4 = 0;

    /** @ORM\Column(name="umsatz_decile_5", type="integer", nullable=false) */
    private int $umsatzDecile5 = 0;

    /** @ORM\Column(name="umsatz_decile_6", type="integer", nullable=false) */
    private int $umsatzDecile6 = 0;

    /** @ORM\Column(name="umsatz_decile_7", type="integer", nullable=false) */
    private int $umsatzDecile7 = 0;

    /** @ORM\Column(name="umsatz_decile_8", type="integer", nullable=false) */
    private int $umsatzDecile8 = 0;

    /** @ORM\Column(name="umsatz_decile_9", type="integer", nullable=false) */
    private int $umsatzDecile9 = 0;

    /** @ORM\Column(name="umsatz_decile_10", type="integer", nullable=false) */
    private int $umsatzDecile10 = 0;

    /** @ORM\Column(name="kosten_decile_1", type="integer", nullable=false) */
    private int $kostenDecile1 = 0;

    /** @ORM\Column(name="kosten_decile_2", type="integer", nullable=false) */
    private int $kostenDecile2 = 0;

    /** @ORM\Column(name="kosten_decile_3", type="integer", nullable=false) */
    private int $kostenDecile3 = 0;

    /** @ORM\Column(name="kosten_decile_4", type="integer", nullable=false) */
    private int $kostenDecile4 = 0;

    /** @ORM\Column(name="kosten_decile_5", type="integer", nullable=false) */
    private int $kostenDecile5 = 0;

    /** @ORM\Column(name="kosten_decile_6", type="integer", nullable=false) */
    private int $kostenDecile6 = 0;

    /** @ORM\Column(name="kosten_decile_7", type="integer", nullable=false) */
    private int $kostenDecile7 = 0;

    /** @ORM\Column(name="kosten_decile_8", type="integer", nullable=false) */
    private int $kostenDecile8 = 0;

    /** @ORM\Column(name="kosten_decile_9", type="integer", nullable=false) */
    private int $kostenDecile9 = 0;

    /** @ORM\Column(name="kosten_decile_10", type="integer", nullable=false) */
    private int $kostenDecile10 = 0;

    /**
     * @return int
     */
    public function getSchemaId(): int
    {
        return $this->schemaId;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @param string|null $bezeichnung
     */
    public function setBezeichnung(?string $bezeichnung): void
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @param string|null $beschreibung
     */
    public function setBeschreibung(?string $beschreibung): void
    {
        $this->beschreibung = $beschreibung;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @param int $sort
     */
    public function setSort(int $sort): void
    {
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile1(): int
    {
        return $this->umsatzDecile1;
    }

    /**
     * @param int $umsatzDecile1
     */
    public function setUmsatzDecile1(int $umsatzDecile1): void
    {
        $this->umsatzDecile1 = $umsatzDecile1;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile2(): int
    {
        return $this->umsatzDecile2;
    }

    /**
     * @param int $umsatzDecile2
     */
    public function setUmsatzDecile2(int $umsatzDecile2): void
    {
        $this->umsatzDecile2 = $umsatzDecile2;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile3(): int
    {
        return $this->umsatzDecile3;
    }

    /**
     * @param int $umsatzDecile3
     */
    public function setUmsatzDecile3(int $umsatzDecile3): void
    {
        $this->umsatzDecile3 = $umsatzDecile3;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile4(): int
    {
        return $this->umsatzDecile4;
    }

    /**
     * @param int $umsatzDecile4
     */
    public function setUmsatzDecile4(int $umsatzDecile4): void
    {
        $this->umsatzDecile4 = $umsatzDecile4;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile5(): int
    {
        return $this->umsatzDecile5;
    }

    /**
     * @param int $umsatzDecile5
     */
    public function setUmsatzDecile5(int $umsatzDecile5): void
    {
        $this->umsatzDecile5 = $umsatzDecile5;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile6(): int
    {
        return $this->umsatzDecile6;
    }

    /**
     * @param int $umsatzDecile6
     */
    public function setUmsatzDecile6(int $umsatzDecile6): void
    {
        $this->umsatzDecile6 = $umsatzDecile6;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile7(): int
    {
        return $this->umsatzDecile7;
    }

    /**
     * @param int $umsatzDecile7
     */
    public function setUmsatzDecile7(int $umsatzDecile7): void
    {
        $this->umsatzDecile7 = $umsatzDecile7;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile8(): int
    {
        return $this->umsatzDecile8;
    }

    /**
     * @param int $umsatzDecile8
     */
    public function setUmsatzDecile8(int $umsatzDecile8): void
    {
        $this->umsatzDecile8 = $umsatzDecile8;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile9(): int
    {
        return $this->umsatzDecile9;
    }

    /**
     * @param int $umsatzDecile9
     */
    public function setUmsatzDecile9(int $umsatzDecile9): void
    {
        $this->umsatzDecile9 = $umsatzDecile9;
    }

    /**
     * @return int
     */
    public function getUmsatzDecile10(): int
    {
        return $this->umsatzDecile10;
    }

    /**
     * @param int $umsatzDecile10
     */
    public function setUmsatzDecile10(int $umsatzDecile10): void
    {
        $this->umsatzDecile10 = $umsatzDecile10;
    }

    /**
     * @return int
     */
    public function getKostenDecile1(): int
    {
        return $this->kostenDecile1;
    }

    /**
     * @param int $kostenDecile1
     */
    public function setKostenDecile1(int $kostenDecile1): void
    {
        $this->kostenDecile1 = $kostenDecile1;
    }

    /**
     * @return int
     */
    public function getKostenDecile2(): int
    {
        return $this->kostenDecile2;
    }

    /**
     * @param int $kostenDecile2
     */
    public function setKostenDecile2(int $kostenDecile2): void
    {
        $this->kostenDecile2 = $kostenDecile2;
    }

    /**
     * @return int
     */
    public function getKostenDecile3(): int
    {
        return $this->kostenDecile3;
    }

    /**
     * @param int $kostenDecile3
     */
    public function setKostenDecile3(int $kostenDecile3): void
    {
        $this->kostenDecile3 = $kostenDecile3;
    }

    /**
     * @return int
     */
    public function getKostenDecile4(): int
    {
        return $this->kostenDecile4;
    }

    /**
     * @param int $kostenDecile4
     */
    public function setKostenDecile4(int $kostenDecile4): void
    {
        $this->kostenDecile4 = $kostenDecile4;
    }

    /**
     * @return int
     */
    public function getKostenDecile5(): int
    {
        return $this->kostenDecile5;
    }

    /**
     * @param int $kostenDecile5
     */
    public function setKostenDecile5(int $kostenDecile5): void
    {
        $this->kostenDecile5 = $kostenDecile5;
    }

    /**
     * @return int
     */
    public function getKostenDecile6(): int
    {
        return $this->kostenDecile6;
    }

    /**
     * @param int $kostenDecile6
     */
    public function setKostenDecile6(int $kostenDecile6): void
    {
        $this->kostenDecile6 = $kostenDecile6;
    }

    /**
     * @return int
     */
    public function getKostenDecile7(): int
    {
        return $this->kostenDecile7;
    }

    /**
     * @param int $kostenDecile7
     */
    public function setKostenDecile7(int $kostenDecile7): void
    {
        $this->kostenDecile7 = $kostenDecile7;
    }

    /**
     * @return int
     */
    public function getKostenDecile8(): int
    {
        return $this->kostenDecile8;
    }

    /**
     * @param int $kostenDecile8
     */
    public function setKostenDecile8(int $kostenDecile8): void
    {
        $this->kostenDecile8 = $kostenDecile8;
    }

    /**
     * @return int
     */
    public function getKostenDecile9(): int
    {
        return $this->kostenDecile9;
    }

    /**
     * @param int $kostenDecile9
     */
    public function setKostenDecile9(int $kostenDecile9): void
    {
        $this->kostenDecile9 = $kostenDecile9;
    }

    /**
     * @return int
     */
    public function getKostenDecile10(): int
    {
        return $this->kostenDecile10;
    }

    /**
     * @param int $kostenDecile10
     */
    public function setKostenDecile10(int $kostenDecile10): void
    {
        $this->kostenDecile10 = $kostenDecile10;
    }

    /**
     * @return array
     */
    public function getKostenDeciles(): array
    {
        $deciles = [];
        for ($i = 1; $i <= 10; $i++) {
            $deciles[] = $this->{"kostenDecile$i"};
        }
        return $deciles;
    }

    /**
     * @return array
     */
    public function getUmsatzDeciles(): array
    {
        $deciles = [];
        for ($i = 1; $i <= 10; $i++) {
            $deciles[] = $this->{"umsatzDecile$i"};
        }
        return $deciles;
    }
}
