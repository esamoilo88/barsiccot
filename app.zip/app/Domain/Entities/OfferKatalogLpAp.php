<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class OfferKatalogElLp
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Offer_Katalog_LP_AP")
 */
class OfferKatalogLpAp
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogAngebotsposition")
     * @ORM\JoinColumn(name="angebotsposition_id", referencedColumnName="id")
     */
    private OfferKatalogAngebotsposition $katalogAp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferKatalogLeistungsposition")
     * @ORM\JoinColumn(name="leistungsposition_id", referencedColumnName="leistungsposition_id")
     */
    private OfferKatalogLeistungsposition $katalogLp;

    /**
     * @ORM\Column(name="sort", type="integer", nullable=true)
     */
    private ?int $sort;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private DateTime $created;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private DateTime $modified;

    /** @ORM\Column(type="integer") */
    private int $quantity;

    /**
     * @ORM\Column(name="optional", type="boolean", nullable=false)
     */
    private bool $optional;

    /**
     * @ORM\Column(name="ui_element", type="string", nullable=true)
     */
    private ?string $uiElement;

    /**
     * @ORM\Column(name="radio_group", type="string", nullable=true)
     */
    private ?string $radioGroup;

    /**
     * OfferKatalogElLp constructor.
     * @param OfferKatalogAngebotsposition $katalogAp
     * @param OfferKatalogLeistungsposition $katalogLp
     * @param int|null $sort
     */
    public function __construct(OfferKatalogAngebotsposition $katalogAp, OfferKatalogLeistungsposition $katalogLp, ?int $sort)
    {
        $this->katalogAp = $katalogAp;
        $this->katalogLp = $katalogLp;
        $this->sort = $sort;
    }

    /**
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * @return OfferKatalogAngebotsposition
     */
    public function getKatalogAp(): OfferKatalogAngebotsposition
    {
        return $this->katalogAp;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getKatalogLp(): OfferKatalogLeistungsposition
    {
        return $this->katalogLp;
    }

    /**
     * @return int|null
     */
    public function getSort(): ?int
    {
        return $this->sort;
    }

    /**
     * @return DateTime
     */
    public function created(): DateTime
    {
        return $this->created;
    }

    /**
     * @return DateTime
     */
    public function modified(): DateTime
    {
        return $this->modified;
    }

    /**
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return bool
     */
    public function isOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @return string|null
     */
    public function getRadioGroup(): ?string
    {
        return $this->radioGroup;
    }

    /**
     * @return string|null
     */
    public function getUiElement(): ?string
    {
        return $this->uiElement;
    }
}
