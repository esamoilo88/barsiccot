<?php

namespace App\Domain\Entities;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * CrmGp
 *
 * @ORM\Table(name="CRM_GP", uniqueConstraints={@ORM\UniqueConstraint(name="UC_CRM_GP", columns={"gp_nr"}), @ORM\UniqueConstraint(name="ui_gp_id", columns={"gp_id"})})
 * @ORM\Entity
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class CrmGp
{
    /**
     * @var int
     *
     * @ORM\Column(name="gp_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $gpId;

    /**
     * @var int
     *
     * @ORM\Column(name="gp_nr", type="bigint", nullable=false)
     */
    private $gpNr;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_name_lang", type="string", length=200, nullable=true)
     */
    private $gpNameLang;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_plz", type="string", length=20, nullable=true)
     */
    private $gpPlz;

    /**
     * @var string|null
     *
     * @ORM\Column(name="gp_ort", type="string", length=200, nullable=true)
     */
    private $gpOrt;

    /**
     * @var string|null
     *
     * @ORM\Column(name="ust_id", type="string", length=32, nullable=true)
     */
    private $ustId;

    /**
     * @var bool
     *
     * @ORM\Column(name="is_active", type="boolean", nullable=false)
     */
    private $isActive;

    /**
     * @var string|null
     *
     * @ORM\Column(name="segment", type="string", length=20, nullable=true)
     */
    private $segment;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_id", type="string", length=10, nullable=true)
     */
    private $wzId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wz_bezeichnung", type="text", length=-1, nullable=true)
     */
    private $wzBezeichnung;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_id", type="string", length=20, nullable=true)
     */
    private $zgId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="zg_bezeichnung", type="string", length=200, nullable=true)
     */
    private $zgBezeichnung;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=false)
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=false)
     */
    private $modified;

    /**
     * @return int
     */
    public function getGpId(): int
    {
        return $this->gpId;
    }

    /**
     * @param int $gpId
     */
    public function setGpId(int $gpId): void
    {
        $this->gpId = $gpId;
    }

    /**
     * @return int
     * @Groups({"projectBasic"})
     */
    public function getGpNr(): int
    {
        return $this->gpNr;
    }

    /**
     * @param int $gpNr
     */
    public function setGpNr(int $gpNr): void
    {
        $this->gpNr = $gpNr;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getGpNameLang(): ?string
    {
        return $this->gpNameLang;
    }

    /**
     * @param string|null $gpNameLang
     */
    public function setGpNameLang(?string $gpNameLang): void
    {
        $this->gpNameLang = $gpNameLang;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getGpPlz(): ?string
    {
        return $this->gpPlz;
    }

    /**
     * @param string|null $gpPlz
     */
    public function setGpPlz(?string $gpPlz): void
    {
        $this->gpPlz = $gpPlz;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getGpOrt(): ?string
    {
        return $this->gpOrt;
    }

    /**
     * @param string|null $gpOrt
     */
    public function setGpOrt(?string $gpOrt): void
    {
        $this->gpOrt = $gpOrt;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getUstId(): ?string
    {
        return $this->ustId;
    }

    /**
     * @param string|null $ustId
     */
    public function setUstId(?string $ustId): void
    {
        $this->ustId = $ustId;
    }

    /**
     * @return bool
     * @Groups({"projectBasic"})
     */
    public function isActive(): bool
    {
        return $this->isActive;
    }

    /**
     * @param bool $isActive
     */
    public function setIsActive(bool $isActive): void
    {
        $this->isActive = $isActive;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getSegment(): ?string
    {
        return $this->segment;
    }

    /**
     * @param string|null $segment
     */
    public function setSegment(?string $segment): void
    {
        $this->segment = $segment;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getWzId(): ?string
    {
        return $this->wzId;
    }

    /**
     * @param string|null $wzId
     */
    public function setWzId(?string $wzId): void
    {
        $this->wzId = $wzId;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getWzBezeichnung(): ?string
    {
        return $this->wzBezeichnung;
    }

    /**
     * @param string|null $wzBezeichnung
     */
    public function setWzBezeichnung(?string $wzBezeichnung): void
    {
        $this->wzBezeichnung = $wzBezeichnung;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getZgId(): ?string
    {
        return $this->zgId;
    }

    /**
     * @param string|null $zgId
     */
    public function setZgId(?string $zgId): void
    {
        $this->zgId = $zgId;
    }

    /**
     * @return string|null
     * @Groups({"projectBasic"})
     */
    public function getZgBezeichnung(): ?string
    {
        return $this->zgBezeichnung;
    }

    /**
     * @param string|null $zgBezeichnung
     */
    public function setZgBezeichnung(?string $zgBezeichnung): void
    {
        $this->zgBezeichnung = $zgBezeichnung;
    }

    /**
     * @return \DateTime
     */
    public function getCreated(): \DateTime
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated(\DateTime $created): void
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getModified(): \DateTime
    {
        return $this->modified;
    }

    /**
     * @param \DateTime $modified
     */
    public function setModified(\DateTime $modified): void
    {
        $this->modified = $modified;
    }
}
