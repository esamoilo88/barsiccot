<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_Offer_Faktura_LBU_Daten")
 */
class v_OfferFakturaLBUDaten
{
    /**
     * @ORM\Id
     * @ORM\Column(name="lbu_daten_id", type="integer")
     */
    private int $lbuDatenId;

    /**
     * @ORM\Column(name="lbu_id", type="integer")
     */
    private int $lbuId;

    /**
     * @ORM\ManyToOne(targetEntity="SalesStammdaten")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id")
     */
    private SalesStammdaten $simple;

    /**
     * @ORM\Column(name="angebotsposition_id", type="integer", nullable=true)
     */
    private ?int $angebotspositionId;

    /**
     * @ORM\Column(name="angebotsposition", type="string")
     */
    private string $angebotsposition;

    /**
     * @ORM\Column(name="preisnachlass", type="decimal", precision=18, scale=7, nullable=true)
     */
    private ?float $preisnachlass;

    /**
     * @ORM\Column(name="leistungsort", type="string", nullable=true)
     */
    private ?string $leistungsort;

    /** @ORM\Column(name="einzelpreis_dtag", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $einzelpreisDtag = null;

    /** @ORM\Column(name="einzelpreis_dtts", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $einzelpreisDtts = null;

    /** @ORM\Column(name="transferpreis_dtag", type="decimal", precision=38, scale=2, nullable=true) */
    private ?float $transferpreisDtag = null;

    /** @ORM\Column(name="Quellsystem", type="string", nullable=true) */
    private ?string $quellsystem;

    /** @ORM\Column(name="Preistyp", type="string", nullable=false) */
    private ?string $preistyp;

    /** @ORM\Column(name="Mengentyp", type="string", nullable=false) */
    private ?string $mengentyp;

    /** @ORM\Column(name="quellsystem_id", type="integer", nullable=true) */
    private ?string $quellsystemId;

    /** @ORM\Column(name="mat_nr_id", type="integer", nullable=true)    */
    private ?int $matNr;

    /** @ORM\Column(name="vorgangs_ticket_nr", type="string", length=50, nullable=true) */
    private ?int $vorgangsTicketNr;

    /** @ORM\Column(name="icp_kont_psp_kst", type="string", length=50, nullable=true) */
    private ?string $icpKontPspKst;

    /** @ORM\Column(name="sap_bestellnummer", type="string", length=150, nullable=true) */
    private ?string $sapBestellnummer;

    /** @ORM\Column(name="icp_kont_konto_id", type="integer", nullable=true) */
    private ?int $icpKontKontoId;

    /** @ORM\Column(name="kommentar", type="string", nullable=true) */
    private ?string $kommentar;

    /** @ORM\Column(name="installationsbemerkung", type="string", nullable=true) */
    private ?string $installationsbemerkung;

    /** @ORM\Column(name="icp_kont_bpos", type="integer", nullable=true) */
    private ?int $icpKontBpos;


    /** @ORM\Column(name="menge", type="decimal", nullable=true) */
    private ?float $menge;

    /**
     * @ORM\Column(name="position_name", type="string", length=100, nullable=true)
     */
    private ?string $positionName = null;

    /**
     * @ORM\Column(name="location_name", type="string", length=100, nullable=true)
     */
    private ?string $locationName = null;

    /**
     * @ORM\Column(name="order_purchase_key", type="string", length=100, nullable=true)
     */
    private ?string $orderPurchaseKey = null;

    /** @ORM\Column(name="created", type="datetime") */
    private DateTime $created;

    /** @ORM\Column(name="leistungszeitpunkt", type="datetime") */
    private DateTime $leistungszeitpunkt;

    /**
     * @ORM\Column(name="leistungszeitraum_von", type="date", nullable=false)
     */
    private DateTime $leistungszeitraumVon;

    /**
     * @ORM\Column(name="leistungszeitraum_bis", type="date", nullable=false)
     */
    private DateTime $leistungszeitraumBis;

    /** @ORM\Column(name="psp_element", type="string", length=50, nullable=true) */
    private ?string $pspElement = null;

    /** @ORM\Column(name="ebi_sap_bestellnummer", type="string", length=150, nullable=true) */
    private ?string $ebiSapBestellnummer = null;

    /**
     * @return string|null
     */
    public function getLeistungsort(): ?string
    {
        return $this->leistungsort;
    }

    /**
     * @return string
     */
    public function getMengentyp(): string
    {
        return $this->mengentyp;
    }

    /**
     * @return string
     */
    public function getAngebotsposition(): string
    {
        return $this->angebotsposition;
    }

    /**
     * @return string|null
     */
    public function getPreistyp(): ?string
    {
        return $this->preistyp;
    }

    /**
     * @return string|null
     */
    public function getQuellsystem(): ?string
    {
        return $this->quellsystem;
    }

    /**
     * @return string|null
     */
    public function getVorgangsTicketNr(): ?string
    {
        return $this->vorgangsTicketNr;
    }

    /**
     * @return float|null
     */
    public function getMenge(): ?float
    {
        return $this->menge;
    }

    /**
     * @return float|null
     */
    public function getTransferpreisDtag(): ?float
    {
        return $this->transferpreisDtag;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtag(): ?float
    {
        return $this->einzelpreisDtag;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNr;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @return int|null
     */
    public function getIcpKontKontoId(): ?int
    {
        return $this->icpKontKontoId;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getInstallationsbemerkung(): ?string
    {
        return $this->installationsbemerkung;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitpunkt(): DateTime
    {
        return $this->leistungszeitpunkt;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitraumVon(): DateTime
    {
        return $this->leistungszeitraumVon;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitraumBis(): DateTime
    {
        return $this->leistungszeitraumBis;
    }

    /**
     * @return float|null
     */
    public function getPreisnachlass(): ?float
    {
        return $this->preisnachlass;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }

    /**
     * @return int
     */
    public function getLbuDatenId(): int
    {
        return $this->lbuDatenId;
    }

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtts(): ?float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return string|null
     */
    public function getQuellsystemId(): ?string
    {
        return $this->quellsystemId;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return DateTime
     */
    public function getCreated(): DateTime
    {
        return $this->created;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return string|null
     */
    public function getEbiSapBestellnummer(): ?string
    {
        return $this->ebiSapBestellnummer;
    }
}
