<?php

namespace App\Domain\Entities;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class OnkaProducttype
 * @package App\Domain\Entities
 *
 * @ORM\Entity
 * @ORM\Table(name="Onka_Producttype")
 * @ORM\ChangeTrackingPolicy("DEFERRED_EXPLICIT")
 */
class OnkaProducttype
{
    /**
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /** @ORM\Column(name="`group`", type="string") */
    private string $group;

    /** @ORM\Column(type="string") */
    private string $name;

    /** @ORM\Column(name="dive_kat", type="string") */
    private string $diveKat;

    /** @ORM\Column(type="string") */
    private string $icon;

    /** @ORM\Column(type="boolean") */
    private bool $hide;

    /** @ORM\Column(type="integer") */
    private int $sort;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenMengentyp")
     * @ORM\JoinColumn(name="mengentyp_id", referencedColumnName="mengentyp_id")
     */
    private OfferFakturaLbuDatenMengentyp $mengentyp;

    /**
     * @ORM\ManyToOne(targetEntity="OfferFakturaLbuDatenPreistyp")
     * @ORM\JoinColumn(name="preistyp_id", referencedColumnName="preistyp_id")
     */
    private OfferFakturaLbuDatenPreistyp $preistyp;

    /** @ORM\Column(type="datetime", nullable=true) */
    private DateTime $bits;

    /**
     * OnkaProducttype constructor.
     * @param string $group
     * @param string $name
     * @param string $diveKat
     * @param string $icon
     * @param bool $hide
     * @param int $sort
     */
    public function __construct(
        string $group,
        string $name,
        string $diveKat,
        string $icon,
        bool $hide,
        int $sort
    )
    {
        $this->group = $group;
        $this->name = $name;
        $this->diveKat = $diveKat;
        $this->icon = $icon;
        $this->hide = $hide;
        $this->sort = $sort;
    }

    /**
     * @Groups({"adminKatalog"})
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getDiveKat(): string
    {
        return $this->diveKat;
    }

    /**
     * @return string
     */
    public function getIcon(): string
    {
        return $this->icon;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }

    /**
     * @return int
     */
    public function getSort(): int
    {
        return $this->sort;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferFakturaLbuDatenMengentyp
     */
    public function getMengentyp(): OfferFakturaLbuDatenMengentyp
    {
        return $this->mengentyp;
    }

    /**
     * @Groups({"confItemsPaginated"})
     * @return OfferFakturaLbuDatenPreistyp
     */
    public function getPreistyp(): OfferFakturaLbuDatenPreistyp
    {
        return $this->preistyp;
    }
}
