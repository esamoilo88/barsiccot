<?php

namespace App\Domain\Entities;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(readOnly=true)
 * @ORM\Table(name="v_SeCeITSSt_Taetigkeit")
 */
class v_SeceitElement
{
    /**
     * @ORM\Id()
     * @ORM\Column(name="element_id", type="integer", nullable=false)
     */
    private int $elementId;

    /** @ORM\Column(name="leistungsposition_id", type="integer", nullable=false) */
    private int $leistungspositionId;

    /** @ORM\Column(name="bezeichnung", type="string", nullable=false) */
    private string $bezeichnung;

    /** @ORM\Column(name="beschreibung", type="string", nullable=true) */
    private ?string $beschreibung;

    /** @ORM\Column(name="kommentar_2", type="string", nullable=true) */
    private ?string $kommentar2;

    /** @ORM\Column(name="skill_id", type="integer", nullable=true) */
    private ?int $skillId;

    /** @ORM\Column(name="minuten", type="decimal", precision=12, scale=0, nullable=true) */
    private ?float $minuten;

    /** @ORM\Column(name="kostenart_bezeichnung", type="string", length=100, nullable=false) */
    private string $kostenartBezeichnung;

    /** @ORM\Column(name="kostenart_id", type="integer", nullable=true) */
    private ?int $kostenartId;

    /**
     * @return int
     */
    public function getElementId(): int
    {
        return $this->elementId;
    }

    /**
     * @return int
     */
    public function getLeistungspositionId(): int
    {
        return $this->leistungspositionId;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return string|null
     */
    public function getKommentar2(): ?string
    {
        return $this->kommentar2;
    }

    /**
     * @return int|null
     */
    public function getSkillId(): ?int
    {
        return $this->skillId;
    }

    /**
     * @return float|null
     */
    public function getMinuten(): ?float
    {
        return $this->minuten;
    }

    /**
     * @return string
     */
    public function getKostenartBezeichnung(): string
    {
        return $this->kostenartBezeichnung;
    }

    /**
     * @return int|null
     */
    public function getKostenartId(): ?int
    {
        return $this->kostenartId;
    }
}
