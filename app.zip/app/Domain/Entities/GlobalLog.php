<?php

namespace App\Domain\Entities;

use DateTime;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * GlobalLog
 *
 * @ORM\Table(name="Global_Log")
 * @ORM\Entity
 */
class GlobalLog
{
    /**
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="GlobalLogGroup")
     * @ORM\JoinColumn(name="group_id", referencedColumnName="id")
     */
    private GlobalLogGroup $group;

    /**
     * @ORM\ManyToOne(targetEntity="GlobalGate")
     * @ORM\JoinColumn(name="simple_id", referencedColumnName="simple_id", nullable=true)
     */
    private ?GlobalGate $simple;

    /**
     * @ORM\ManyToOne(targetEntity="BackendBenutzer")
     * @ORM\JoinColumn(name="benutzer_id", referencedColumnName="benutzer_id")
     */
    private ?BackendBenutzer $benutzer;

    /** @ORM\Column(name="action", type="string", length=32) */
    private string $action = "";

    /** @ORM\Column(name="log_text", type="string", length=512) */
    private string $logText = "";

    /** @ORM\Column(name="object_name", type="string", length=128, nullable=true) */
    private ?string $objectName;

    /** @ORM\Column(name="parent_name", type="string", length=128, nullable=true) */
    private ?string $parentName;

    /** @ORM\Column(name="changes", type="string", nullable=true) */
    private ?string $changes;

    /** @ORM\Column(name="result", type="boolean") */
    private bool $result;

    /** @ORM\Column(name="message", type="string", length=255, nullable=true) */
    private ?string $message;

    /**
     * @ORM\Column(name="`timestamp`", type="datetime")
     * @Gedmo\Timestampable(on="create")
     */
    private DateTime $timestamp;

    /**
     * GlobalLog constructor.
     * @param GlobalLogGroup|object $group
     * @param GlobalGate|object|null $simple
     * @param BackendBenutzer|null $benutzer
     * @param string|null $objectName
     * @param string|null $parentName
     * @param string|null $changes
     * @param string $logText
     * @param string $action
     * @param string|null $message
     * @param bool $result
     */
    public function __construct(
        GlobalLogGroup $group,
        ?GlobalGate $simple,
        ?BackendBenutzer $benutzer,
        ?string $objectName,
        ?string $parentName,
        ?string $changes,
        string $logText = "",
        string $action = "",
        ?string $message = "",
        bool $result = true
    )
    {
        $this->group = $group;
        $this->simple = $simple;
        $this->benutzer = $benutzer;
        $this->objectName = $objectName;
        $this->parentName = $parentName;
        $this->changes = $changes;
        $this->logText = $logText;
        $this->action = $action;
        $this->message = $message;
        $this->result = $result;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return GlobalLogGroup
     */
    public function getGroup(): GlobalLogGroup
    {
        return $this->group;
    }

    /**
     * @return string
     * @Groups({"ccf"})
     */
    public function getGroupName(): string
    {
        return $this->group->getName();
    }

    /**
     * @param GlobalLogGroup $group
     */
    public function setGroup(GlobalLogGroup $group): void
    {
        $this->group = $group;
    }

    /**
     * @return GlobalGate|null
     */
    public function getSimple(): ?GlobalGate
    {
        return $this->simple;
    }

    /**
     * @return int|null
     * @Groups({"ccf"})
     */
    public function getSimpleId(): ?int
    {
        return $this->simple ? $this->simple->getId() : null;
    }

    /**
     * @param GlobalGate|null $simple
     */
    public function setSimple(?GlobalGate $simple): void
    {
        $this->simple = $simple;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getBenutzer(): ?BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return string|null
     * @Groups({"ccf"})
     */
    public function getBenutzerName(): ?string
    {
        return $this->benutzer ? $this->benutzer->getLastNameFirstName() : null;
    }

    /**
     * @param BackendBenutzer|null $benutzer
     */
    public function setBenutzer(?BackendBenutzer $benutzer): void
    {
        $this->benutzer = $benutzer;
    }

    /**
     * @return string
     */
    public function getAction(): string
    {
        return $this->action;
    }

    /**
     * @param string $action
     */
    public function setAction(string $action): void
    {
        $this->action = $action;
    }

    /**
     * @return string
     * @Groups({"ccf"})
     */
    public function getLogText(): string
    {
        return $this->logText;
    }

    /**
     * @param string $logText
     */
    public function setLogText(string $logText): void
    {
        $this->logText = $logText;
    }

    /**
     * @return string|null
     */
    public function getObjectName(): ?string
    {
        return $this->objectName;
    }

    /**
     * @param string|null $objectName
     */
    public function setObjectName(?string $objectName): void
    {
        $this->objectName = $objectName;
    }

    /**
     * @return string|null
     */
    public function getParentName(): ?string
    {
        return $this->parentName;
    }

    /**
     * @param string|null $parentName
     */
    public function setParentName(?string $parentName): void
    {
        $this->parentName = $parentName;
    }

    /**
     * @return string|null
     */
    public function getChanges(): ?string
    {
        return $this->changes;
    }

    /**
     * @param string|null $changes
     */
    public function setChanges(?string $changes): void
    {
        $this->changes = $changes;
    }

    /**
     * @return DateTime
     * @Groups({"ccf"})
     */
    public function getTimestamp(): DateTime
    {
        return $this->timestamp;
    }

    /**
     * @return bool
     */
    public function getResult(): bool
    {
        return $this->result;
    }

    /**
     * @param bool $result
     */
    public function setResult(bool $result): void
    {
        $this->result = $result;
    }

    /**
     * @return string|null
     */
    public function getMessage(): ?string
    {
        return $this->message;
    }

    /**
     * @param string|null $message
     */
    public function setMessage(?string $message): void
    {
        $this->message = $message;
    }
}
