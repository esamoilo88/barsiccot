<?php

namespace App\Domain\DTO\Katalog\EL;

class ManageKatalogElDTO
{
    private string $bezeichnung;
    private int $kostenart;
    private float $stundensatz;
    private float $gmkz;
    private ?float $wert;
    private ?bool $ma;
    private ?bool $inflationsfaktor;
    private ?string $beschreibung;
    private ?string $zeitstunden;
    private array $lps;

    /**
     * ManageKatalogElDTO constructor.
     * @param string $bezeichnung
     * @param int $kostenart
     * @param float $stundensatz
     * @param float $gmkz
     * @param float|null $wert
     * @param bool|null $ma
     * @param bool|null $inflationsfaktor
     * @param string|null $beschreibung
     * @param string|null $zeitstunden
     * @param array $lps
     */
    public function __construct(
        string $bezeichnung,
        int $kostenart,
        float $stundensatz,
        float $gmkz,
        ?float $wert,
        ?bool $ma,
        ?bool $inflationsfaktor,
        ?string $beschreibung,
        ?string $zeitstunden,
        array $lps
    )
    {
        $this->bezeichnung = $bezeichnung;
        $this->kostenart = $kostenart;
        $this->stundensatz = $stundensatz;
        $this->gmkz = $gmkz;
        $this->wert = $wert;
        $this->ma = $ma;
        $this->inflationsfaktor = $inflationsfaktor;
        $this->beschreibung = $beschreibung;
        $this->zeitstunden = $zeitstunden;
        $this->lps = $lps;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int
     */
    public function getKostenart(): int
    {
        return $this->kostenart;
    }

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return float
     */
    public function getGmkz(): float
    {
        return $this->gmkz;
    }

    /**
     * @return float|null
     */
    public function getWert(): ?float
    {
        return $this->wert;
    }

    /**
     * @return bool|null
     */
    public function getMa(): ?bool
    {
        return $this->ma;
    }

    /**
     * @return bool|null
     */
    public function getInflationsfaktor(): ?bool
    {
        return $this->inflationsfaktor;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return string|null
     */
    public function getZeitstunden(): ?string
    {
        return $this->zeitstunden;
    }

    /**
     * @return array
     */
    public function getLps(): array
    {
        return $this->lps;
    }
}
