<?php

namespace App\Domain\DTO\Katalog\BER;

class ManageKatalogBerDTO
{
    private string $bezeichnung;
    private string $operator;
    private float $wert;
    private ?string $kommentar;
    private string $objectsType;
    private array $objects;

    /**
     * ManageKatalogBerDTO constructor.
     * @param string $bezeichnung
     * @param string $operator
     * @param float $wert
     * @param string|null $kommentar
     * @param string $objectsType
     * @param array $objects
     */
    public function __construct(
        string $bezeichnung,
        string $operator,
        float $wert,
        ?string $kommentar,
        string $objectsType,
        array $objects
    )
    {
        $this->bezeichnung = $bezeichnung;
        $this->operator = $operator;
        $this->wert = $wert;
        $this->kommentar = $kommentar;
        $this->objectsType = $objectsType;
        $this->objects = $objects;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string
     */
    public function getOperator(): string
    {
        return $this->operator;
    }

    /**
     * @return float
     */
    public function getWert(): float
    {
        return $this->wert;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return string
     */
    public function getObjectsType(): string
    {
        return $this->objectsType;
    }

    /**
     * @return array
     */
    public function getObjects(): array
    {
        return $this->objects;
    }
}
