<?php

namespace App\Domain\DTO\Katalog\LP;

class ManageKatalogLpDTO
{
    private array $categories;
    private string $name;
    private string $leistungstyp;
    private ?string $inRessourcen;
    private ?string $inKosten;
    private ?bool $nachAufwand;
    private ?string $beschreibung;
    private ?array $aps;

    /**
     * ManageKatalogLpDTO constructor.
     * @param array $categories
     * @param string $name
     * @param string $leistungstyp
     * @param string|null $inRessourcen
     * @param string|null $inKosten
     * @param bool|null $nachAufwand
     * @param string|null $beschreibung
     * @param array|null $aps
     */
    public function __construct(
        array $categories,
        string $name,
        string $leistungstyp,
        ?string $inRessourcen,
        ?string $inKosten,
        ?bool $nachAufwand,
        ?string $beschreibung,
        ?array $aps
    )
    {
        $this->categories = $categories;
        $this->name = $name;
        $this->leistungstyp = $leistungstyp;
        $this->inRessourcen = $inRessourcen;
        $this->inKosten = $inKosten;
        $this->nachAufwand = $nachAufwand;
        $this->beschreibung = $beschreibung;
        $this->aps = $aps;
    }

    /**
     * @return array
     */
    public function getCategories(): array
    {
        return $this->categories;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getLeistungstyp(): string
    {
        return $this->leistungstyp;
    }

    /**
     * @return string|null
     */
    public function getInRessourcen(): ?string
    {
        return $this->inRessourcen;
    }

    /**
     * @return string|null
     */
    public function getInKosten(): ?string
    {
        return $this->inKosten;
    }

    /**
     * @return bool|null
     */
    public function getNachAufwand(): ?bool
    {
        return $this->nachAufwand;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return array|null
     */
    public function getAps(): ?array
    {
        return $this->aps;
    }
}
