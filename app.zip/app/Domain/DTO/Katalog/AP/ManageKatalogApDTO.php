<?php

namespace App\Domain\DTO\Katalog\AP;


class ManageKatalogApDTO
{
    private array $categories;
    private int $producttypeId;
    private string $name;
    private int $quantity;
    private ?float $unitPrice;
    private ?string $beschreibung;
    private bool $fixedPrice;
    private string $code;

    /**
     * ManageKatalogApDTO constructor.
     * @param array $categories
     * @param int $producttypeId
     * @param string $name
     * @param int $quantity
     * @param float|null $unitPrice
     * @param string|null $beschreibung
     * @param bool $fixedPrice
     * @param string $code
     */
    public function __construct(
        array $categories,
        int $producttypeId,
        string $name,
        int $quantity,
        ?float $unitPrice,
        ?string $beschreibung,
        bool $fixedPrice,
        string $code
    )
    {
        $this->categories = $categories;
        $this->producttypeId = $producttypeId;
        $this->name = $name;
        $this->quantity = $quantity;
        $this->unitPrice = $unitPrice;
        $this->beschreibung = $beschreibung;
        $this->fixedPrice = $fixedPrice;
        $this->code = $code;
    }

    /**
     * @return array
     */
    public function getCategories(): array
    {
        return $this->categories;
    }

    /**
     * @return int
     */
    public function getProducttypeId(): int
    {
        return $this->producttypeId;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return float|null
     */
    public function getUnitPrice(): ?float
    {
        return $this->unitPrice;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return bool
     */
    public function isFixedPrice(): bool
    {
        return $this->fixedPrice;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }
}
