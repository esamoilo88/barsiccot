<?php

namespace App\Domain\DTO\Password;

use App\Exceptions\Application\ObjectPropertyIsNotSetException;

class PasswordForgetDTO
{
    private ?string $email;
    private ?string $name;

    /**
     * PasswordForgetDTO constructor.
     * @param string|null $email
     * @param string|null $name
     * @throws \Exception
     */
    public function __construct(string $email = null, string $name = null)
    {
        if ($email === null && $name === null) {
            throw new \Exception();
        }
        $this->email = $email;
        $this->name = $name;
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getEmail(): string
    {
        if ($this->email === null) {
            throw new ObjectPropertyIsNotSetException('email', self::class);
        }
        return $this->email;
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getName(): string
    {
        if ($this->name === null) {
            throw new ObjectPropertyIsNotSetException('name', self::class);
        }
        return $this->name;
    }

    /**
     * @return bool
     */
    public function hasEmail(): bool
    {
        return $this->email !== null;
    }

}
