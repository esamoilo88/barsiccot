<?php

namespace App\Domain\DTO\Password;

class PasswordResetDTO
{
    private string $oldPassword;
    private string $newPassword;

    /**
     * PasswordResetDTO constructor.
     * @param string $oldPassword
     * @param string $newPassword
     */
    public function __construct(string $oldPassword, string $newPassword)
    {
        $this->oldPassword = $oldPassword;
        $this->newPassword = $newPassword;
    }

    /**
     * @return string
     */
    public function getOldPassword(): string
    {
        return $this->oldPassword;
    }

    /**
     * @return string
     */
    public function getNewPassword(): string
    {
        return $this->newPassword;
    }
}