<?php

namespace App\Domain\DTO\CCF;

use App\Domain\Entities\BackendBenutzer;

class HandledDataDTO
{
    private string $pspElement;
    private string $pspElementSAP;
    private string $name;
    private string $parentName;
    private bool $collector;
    private bool $hide;
    private bool $locked;
    private ?BackendBenutzer $contact;
    private ?BackendBenutzer $representative;

    /**
     * HandledDataDTO constructor.
     * @param string $pspElement
     * @param string $pspElementSAP
     * @param string $name
     * @param string $parentName
     * @param BackendBenutzer|null $contact
     * @param BackendBenutzer|null $representative
     * @param bool $collector
     * @param bool $hide
     * @param bool $locked
     */
    public function __construct(
        string $pspElement,
        string $pspElementSAP,
        string $name,
        string $parentName,
        ?BackendBenutzer $contact,
        ?BackendBenutzer $representative,
        bool $collector = false,
        bool $hide = false,
        bool $locked = false
    )
    {
        $this->pspElement = $pspElement;
        $this->pspElementSAP = $pspElementSAP;
        $this->parentName = $parentName;
        $this->name = $name;
        $this->contact = $contact;
        $this->representative = $representative;
        $this->hide = $hide;
        $this->locked = $locked;
        $this->collector = $collector;
    }

    /**
     * @return string
     */
    public function getPspElement(): string
    {
        return $this->pspElement;
    }

    /**
     * @return string
     */
    public function getPspElementSAP(): string
    {
        return $this->pspElementSAP;
    }

    /**
     * @return string
     */
    public function getParentName(): string
    {
        return $this->parentName;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getContact(): ?BackendBenutzer
    {
        return $this->contact;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getRepresentative(): ?BackendBenutzer
    {
        return $this->representative;
    }

    /**
     * @return bool
     */
    public function isCollector(): bool
    {
        return $this->collector;
    }

    /**
     * @return bool
     */
    public function isLocked(): bool
    {
        return $this->locked;
    }

    /**
     * @return bool
     */
    public function isHide(): bool
    {
        return $this->hide;
    }
}
