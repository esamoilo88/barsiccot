<?php

namespace App\Domain\DTO\CCF;

class ProcessDiscountDTO
{
    private bool $useDiscount;
    private string $preisnachlass;
    private string $gmkzAlt;
    private string $gmkzNeu;
    private ?bool $discountTotals;
    private string $projectName;
    private string $comment;

    /**
     * ProcessDiscountDTO constructor.
     * @param bool $useDiscount
     * @param string $preisnachlass
     * @param string $gmkzAlt
     * @param string $gmkzNeu
     * @param bool|null $discountTotals
     * @param string $projectName
     * @param string $comment
     */
    public function __construct(
        bool $useDiscount,
        string $preisnachlass,
        string $gmkzAlt,
        string $gmkzNeu,
        ?bool $discountTotals,
        string $projectName,
        string $comment
    )
    {
        $this->useDiscount = $useDiscount;
        $this->preisnachlass = $preisnachlass;
        $this->gmkzAlt = $gmkzAlt;
        $this->gmkzNeu = $gmkzNeu;
        $this->discountTotals = $discountTotals;
        $this->projectName = $projectName;
        $this->comment = $comment;
    }

    /**
     * @return bool
     */
    public function isUseDiscount(): bool
    {
        return $this->useDiscount;
    }

    /**
     * @return string
     */
    public function getPreisnachlass(): string
    {
        return $this->preisnachlass;
    }

    /**
     * @return string
     */
    public function getGmkzAlt(): string
    {
        return $this->gmkzAlt;
    }

    /**
     * @return string
     */
    public function getGmkzNeu(): string
    {
        return $this->gmkzNeu;
    }

    /**
     * @return bool|null
     */
    public function isDiscountTotals(): ?bool
    {
        return $this->discountTotals;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }
}
