<?php

namespace App\Domain\DTO\CCF;

use App\Domain\Signatures\LbuStatus\LbuStatusSignature;

class ExportLBUsDTO
{
    protected int $billingType;
    protected int $modus;
    protected bool $created;
    protected bool $send;
    protected bool $ready;
    protected bool $transferred;
    protected bool $accounted;
    protected bool $rejected;
    protected bool $locked;
    protected bool $canceled;
    protected bool $marchRuleIgnore;
    protected ?string $date;
    protected ?string $time;

    /**
     * ExportLBUsDTO constructor.
     * @param int $billingType
     * @param int $modus
     * @param bool $created
     * @param bool $send
     * @param bool $ready
     * @param bool $transferred
     * @param bool $accounted
     * @param bool $rejected
     * @param bool $locked
     * @param bool $canceled
     * @param bool $marchRuleIgnore
     * @param string|null $date
     * @param string|null $time
     */
    public function __construct(
        int $billingType,
        int $modus,
        bool $created = false,
        bool $send = false,
        bool $ready = false,
        bool $transferred = false,
        bool $accounted = false,
        bool $rejected = false,
        bool $locked = false,
        bool $canceled = false,
        bool $marchRuleIgnore = false,
        string $date = null,
        string $time = null
    )
    {
        $this->billingType = $billingType;
        $this->modus = $modus;
        $this->created = $created;
        $this->send = $send;
        $this->ready = $ready;
        $this->transferred = $transferred;
        $this->accounted = $accounted;
        $this->rejected = $rejected;
        $this->locked = $locked;
        $this->canceled = $canceled;
        $this->date = $date;
        $this->time = $time;
        $this->marchRuleIgnore = $marchRuleIgnore;
    }

    /**
     * @return int
     */
    public function getBillingType(): int
    {
        return $this->billingType;
    }

    /**
     * @return int
     */
    public function getModus(): int
    {
        return $this->modus;
    }

    /**
     * @return bool
     */
    public function isCreated(): bool
    {
        return $this->created;
    }

    /**
     * @return bool
     */
    public function isSend(): bool
    {
        return $this->send;
    }

    /**
     * @return bool
     */
    public function isReady(): bool
    {
        return $this->ready;
    }

    /**
     * @return array
     */
    public function getLbuStatuses(): array
    {
        $result = [];

        if ($this->created) $result[] = LbuStatusSignature::SYS_NAMES['Created'];
        if ($this->send) $result[] = LbuStatusSignature::SYS_NAMES['Send'];
        if ($this->ready) $result[] = LbuStatusSignature::SYS_NAMES['Ready'];
        if ($this->transferred) $result[] = LbuStatusSignature::SYS_NAMES['Transferred'];
        if ($this->accounted) $result[] = LbuStatusSignature::SYS_NAMES['Accounted'];
        if ($this->rejected) $result[] = LbuStatusSignature::SYS_NAMES['Rejected'];
        if ($this->locked) $result[] = LbuStatusSignature::SYS_NAMES['Locked'];
        if ($this->canceled) $result[] = LbuStatusSignature::SYS_NAMES['Canceled'];

        return $result;
    }

    /**
     * @return bool
     */
    public function isAccounted(): bool
    {
        return $this->accounted;
    }

    /**
     * @return bool
     */
    public function isCanceled(): bool
    {
        return $this->canceled;
    }

    /**
     * @return bool
     */
    public function isLocked(): bool
    {
        return $this->locked;
    }

    /**
     * @return bool
     */
    public function isRejected(): bool
    {
        return $this->rejected;
    }

    /**
     * @return bool
     */
    public function isTransferred(): bool
    {
        return $this->transferred;
    }

    /**
     * @return string|null
     */
    public function getDate(): ?string
    {
        return $this->date;
    }

    /**
     * @return string|null
     */
    public function getTime(): ?string
    {
        return $this->time;
    }

    /**
     * @return bool
     */
    public function isMarchRuleIgnore(): bool
    {
        return $this->marchRuleIgnore;
    }
}
