<?php

namespace App\Domain\DTO\CCF;

use App\Domain\ValueObjects\SIN;

class StoreGrundeinstellungDTO
{
    private SIN $sin;
    private array $chosenLabels;
    private ?int $profitcenterSettingsId;
    private ?int $debitorId;
    private string $comment;
    private ?bool $cbiSinControl;

    /**
     * StoreGrundeinstellungDTO constructor.
     * @param SIN $sin
     * @param array $chosenLabels
     * @param int|null $profitcenterSettingsId
     * @param int|null $debitorId
     * @param string $comment
     * @param bool|null $cbiSinControl
     */
    public function __construct(
        SIN $sin,
        array $chosenLabels,
        ?int $profitcenterSettingsId,
        ?int $debitorId,
        string $comment,
        ?bool $cbiSinControl
    )
    {
        $this->sin = $sin;
        $this->chosenLabels = $chosenLabels;
        $this->profitcenterSettingsId = $profitcenterSettingsId;
        $this->debitorId = $debitorId;
        $this->comment = $comment;
        $this->cbiSinControl = $cbiSinControl;
    }

    /**
     * @return array
     */
    public function getChosenLabels(): array
    {
        return $this->chosenLabels;
    }

    /**
     * @return int
     */
    public function getProfitcenterSettingsId(): ?int
    {
        return $this->profitcenterSettingsId;
    }

    /**
     * @return int
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return bool|null
     */
    public function getCbiSinControl(): ?bool
    {
        return $this->cbiSinControl;
    }
}