<?php

namespace App\Domain\DTO\LBU\Excel\Export;

use App\Domain\DTO\Order\LBU\LBUCreateDTO;
use App\Domain\DTO\Order\LBUPosition\LBUPositionCreateDTO;

class HandledDataDTO
{
    /** @var ValidLbuDTO[] */
    private array $lbu;
    /** @var ValidLBUPositionDTO[] */
    private array $positions;

    /**
     * HandledDataDTO constructor.
     * @param array $lbu
     * @param array $positions
     */
    public function __construct(array $lbu, array $positions)
    {
        $this->lbu = $lbu;
        $this->positions = $positions;
    }

    /**
     * @return array
     */
    public function getLbu(): array
    {
        return $this->lbu;
    }

    /**
     * @param string $hashKey
     * @return array
     */
    public function getPositions(string $hashKey): array
    {
        return $this->positions[$hashKey];
    }

    /**
     * @param string $hashKey
     * @return bool
     */
    public function hasPositions(string $hashKey): bool
    {
        return array_key_exists($hashKey, $this->positions);
    }

}