<?php

namespace App\Domain\DTO\LBU\Excel\Export;

use App\Domain\Entities\OfferFakturaLbuDatenQuellsystem;
use App\Domain\Entities\OfferFakturaLbuDatenSachkonto;
use App\Domain\ValueObjects\SIN;
use App\Services\Orders\LBUExcel\Export\GetDataToExportService;
use DateTime;

class ValidLBUPositionDTO
{
    private SIN $sin;
    private string $angebotsposition;
    private float $menge;
    private float $einzelpreisDtts;
    private DateTime $leistungszeitpunkt;
    private string $leistungsort;
    private string $pspElement;
    private ?int $angebotspositionId;
    private ?OfferFakturaLbuDatenQuellsystem $quellsystem;
    private int $matNr;
    private ?string $ticketNr;
    private ?OfferFakturaLbuDatenSachkonto $sachkonto;
    private ?string $icpKontPspKst;
    private ?int $icpKontBpos;
    private ?string $kommentar;
    private ?string $positionName;
    private ?string $locationName;
    private ?string $orderPurchaseKey;

    private float $totalPrice = 0;

    /**
     * ValidLBUPositionDTO constructor.
     * @param SIN $sin
     * @param string $angebotsposition
     * @param float $menge
     * @param float $einzelpreisDtts
     * @param DateTime $leistungszeitpunkt
     * @param string $leistungsort
     * @param string $pspElement
     * @param int $matNr
     * @param int|null $angebotspositionId
     * @param OfferFakturaLbuDatenQuellsystem|null $quellsystem
     * @param string|null $ticketNr
     * @param OfferFakturaLbuDatenSachkonto|null $sachkonto
     * @param string|null $icpKontPspKst
     * @param int|null $icpKontBpos
     * @param string|null $kommentar
     * @param string|null $positionName
     * @param string|null $locationName
     * @param string|null $orderPurchaseKey
     */
    public function __construct(
        SIN $sin,
        string $angebotsposition,
        float $menge,
        float $einzelpreisDtts,
        DateTime $leistungszeitpunkt,
        string $leistungsort,
        string $pspElement,
        int $matNr,
        ?int $angebotspositionId = null,
        ?OfferFakturaLbuDatenQuellsystem $quellsystem = null,
        ?string $ticketNr = null,
        ?OfferFakturaLbuDatenSachkonto $sachkonto = null,
        ?string $icpKontPspKst = null,
        ?int $icpKontBpos = null,
        ?string $kommentar = null,
        ?string $positionName = null,
        ?string $locationName = null,
        ?string $orderPurchaseKey = null
    )
    {
        $this->sin = $sin;
        $this->angebotsposition = $angebotsposition;
        $this->menge = $menge;
        $this->einzelpreisDtts = $einzelpreisDtts;
        $this->leistungszeitpunkt = $leistungszeitpunkt;
        $this->leistungsort = $leistungsort;
        $this->pspElement = $pspElement;
        $this->angebotspositionId = $angebotspositionId;
        $this->quellsystem = $quellsystem;
        $this->matNr = $matNr;
        $this->ticketNr = $ticketNr;
        $this->sachkonto = $sachkonto;
        $this->icpKontPspKst = $icpKontPspKst;
        $this->icpKontBpos = $icpKontBpos;
        $this->kommentar = $kommentar;
        $this->positionName = $positionName;
        $this->locationName = $locationName;
        $this->orderPurchaseKey = $orderPurchaseKey;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getAngebotsposition(): string
    {
        return $this->angebotsposition;
    }

    /**
     * @return float
     */
    public function getMenge(): float
    {
        return $this->menge;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDtts(): float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitpunkt(): DateTime
    {
        return $this->leistungszeitpunkt;
    }

    /**
     * @return string
     */
    public function getLeistungsort(): string
    {
        return $this->leistungsort;
    }

    /**
     * @return string
     */
    public function getPspElement(): string
    {
        return $this->pspElement;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return OfferFakturaLbuDatenQuellsystem|null
     */
    public function getQuellsystem(): ?OfferFakturaLbuDatenQuellsystem
    {
        return $this->quellsystem;
    }

    /**
     * @return int
     */
    public function getMatNr(): int
    {
        return $this->matNr;
    }

    /**
     * @return string|null
     */
    public function getTicketNr(): ?string
    {
        return $this->ticketNr;
    }

    /**
     * @return OfferFakturaLbuDatenSachkonto|null
     */
    public function getSachkonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->sachkonto;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @param float $totalPrice
     */
    public function setTotalPrice(float $totalPrice): void
    {
        $this->totalPrice = $totalPrice;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'apName' => $this->angebotsposition,
            'leistungsort' => $this->leistungsort,
            'leistungszeitpunkt' => $this->leistungszeitpunkt->format('d.m.Y'),
            'vorgangsnummer' => $this->ticketNr,
            'menge' => $this->menge,
            'stuckpreis' => $this->einzelpreisDtts,
            'total' => $this->totalPrice,
            'ispBsp' => $this->icpKontBpos,
            'materialnummer' => $this->matNr,
            'sachkonto' => $this->sachkonto ? GetDataToExportService::makeSachkontoKey($this->sachkonto) : null,
            'ispPSP' => $this->icpKontPspKst,
            'positionName' => $this->positionName,
            'locationName' => $this->locationName,
            'orderPurchaseKey' => $this->orderPurchaseKey
        ];
    }
}
