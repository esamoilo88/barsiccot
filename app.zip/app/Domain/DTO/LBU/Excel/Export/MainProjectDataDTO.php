<?php

namespace App\Domain\DTO\LBU\Excel\Export;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\FinanceOrder;
use App\Domain\Entities\FinancePsp;
use App\Domain\Entities\OfferDebitor;
use App\Domain\Entities\OfferFakturaFakturaziel;
use App\Domain\Entities\OfferFakturaLbuDatenSachkonto;
use App\Domain\Entities\OfferFakturaMaterialnummer;
use App\Domain\ValueObjects\SIN;

class MainProjectDataDTO
{
    private SIN $sin;
    private bool $isHardBilling;
    private bool $isSapInterfaceUsage;
    private bool $isExternal;
    private bool $isAllowEmptyAp;
    private bool $dauerfreigabe;
    private ?int $projectSettingsId;
    private ?string $rechnungsart;
    private ?string $billingSubjectExtension;
    private ?FinancePsp $financePsp;
    private ?FinanceOrder $financeOrder;
    private ?BackendBenutzer $ansprechpartner;
    private ?OfferFakturaLbuDatenSachkonto $sachkonto;
    private ?OfferFakturaFakturaziel $fakturaziel;
    private ?OfferDebitor $debitor;
    private ?OfferFakturaMaterialnummer $materialnummer;
    private ?string $icpKontPspKst;
    private ?string $positionName;
    private ?string $locationName;
    private ?string $orderPurchaseKey;

    /**
     * MainProjectDataDTO constructor.
     * @param SIN $sin
     * @param bool $isHardBilling
     * @param bool $isSapInterfaceUsage
     * @param bool $isExternal
     * @param bool $isAllowEmptyAp
     * @param bool $dauerfreigabe
     * @param int|null $projectSettingsId
     * @param string|null $rechnungsart
     * @param string|null $billingSubjectExtension
     * @param FinancePsp|null $financePsp
     * @param FinanceOrder|null $financeOrder
     * @param BackendBenutzer|null $ansprechpartner
     * @param string|null $positionName
     * @param string|null $locationName
     * @param string|null $orderPurchaseKey
     */
    public function __construct(
        SIN $sin,
        bool $isHardBilling,
        bool $isSapInterfaceUsage,
        bool $isExternal,
        bool $isAllowEmptyAp,
        bool $dauerfreigabe,
        ?int $projectSettingsId,
        ?string $rechnungsart,
        ?string $billingSubjectExtension,
        ?FinancePsp $financePsp,
        ?FinanceOrder $financeOrder,
        ?BackendBenutzer $ansprechpartner,
        ?string $positionName = null,
        ?string $locationName = null,
        ?string $orderPurchaseKey = null
    )
    {
        $this->sin = $sin;
        $this->isHardBilling = $isHardBilling;
        $this->isSapInterfaceUsage = $isSapInterfaceUsage;
        $this->isExternal = $isExternal;
        $this->isAllowEmptyAp = $isAllowEmptyAp;
        $this->dauerfreigabe = $dauerfreigabe;
        $this->projectSettingsId = $projectSettingsId;
        $this->rechnungsart = $rechnungsart;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->financePsp = $financePsp;
        $this->financeOrder = $financeOrder;
        $this->ansprechpartner = $ansprechpartner;
        $this->positionName =$positionName;
        $this->locationName =$locationName;
        $this->orderPurchaseKey =$orderPurchaseKey;
    }

    /**
     * @param OfferFakturaLbuDatenSachkonto|null $sachkonto
     */
    public function setSachkonto(?OfferFakturaLbuDatenSachkonto $sachkonto): void
    {
        $this->sachkonto = $sachkonto;
    }

    /**
     * @param OfferFakturaFakturaziel|null $fakturaziel
     */
    public function setFakturaziel(?OfferFakturaFakturaziel $fakturaziel): void
    {
        $this->fakturaziel = $fakturaziel;
    }

    /**
     * @param OfferDebitor|null $debitor
     */
    public function setDebitor(?OfferDebitor $debitor): void
    {
        $this->debitor = $debitor;
    }

    /**
     * @param OfferFakturaMaterialnummer|null $materialnummer
     */
    public function setMaterialnummer(?OfferFakturaMaterialnummer $materialnummer): void
    {
        $this->materialnummer = $materialnummer;
    }

    /**
     * @param string|null $icpKontPspKst
     */
    public function setIcpKontPspKst(?string $icpKontPspKst): void
    {
        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return bool
     */
    public function isHardBilling(): bool
    {
        return $this->isHardBilling;
    }

    /**
     * @return bool
     */
    public function isSapInterfaceUsage(): bool
    {
        return $this->isSapInterfaceUsage;
    }

    /**
     * @return bool
     */
    public function isExternal(): bool
    {
        return $this->isExternal;
    }

    /**
     * @return bool
     */
    public function isAllowEmptyAp(): bool
    {
        return $this->isAllowEmptyAp;
    }

    /**
     * @return bool
     */
    public function isDauerfreigabe(): bool
    {
        return $this->dauerfreigabe;
    }

    /**
     * @return int|null
     */
    public function getProjectSettingsId(): ?int
    {
        return $this->projectSettingsId;
    }

    /**
     * @return string|null
     */
    public function getRechnungsart(): ?string
    {
        return $this->rechnungsart;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return FinancePsp|null
     */
    public function getFinancePsp(): ?FinancePsp
    {
        return $this->financePsp;
    }

    /**
     * @return FinanceOrder|null
     */
    public function getFinanceOrder(): ?FinanceOrder
    {
        return $this->financeOrder;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getAnsprechpartner(): ?BackendBenutzer
    {
        return $this->ansprechpartner;
    }

    /**
     * @return OfferFakturaLbuDatenSachkonto|null
     */
    public function getSachkonto(): ?OfferFakturaLbuDatenSachkonto
    {
        return $this->sachkonto;
    }

    /**
     * @return OfferFakturaFakturaziel|null
     */
    public function getFakturaziel(): ?OfferFakturaFakturaziel
    {
        return $this->fakturaziel;
    }

    /**
     * @return OfferDebitor|null
     */
    public function getDebitor(): ?OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @return OfferFakturaMaterialnummer|null
     */
    public function getMaterialnummer(): ?OfferFakturaMaterialnummer
    {
        return $this->materialnummer;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }

    /**
     * @return array
     */
    public function toExportArray(): array
    {
        return [
            'SIN' => $this->sin->value(),
            'Rechnungsart' => $this->rechnungsart,
            'Nutzung SAP Schnittstelle' => $this->isSapInterfaceUsage ? 'Ja' : 'Nein',
            'Faktura ohne AP' => $this->isAllowEmptyAp ? 'Erlaubt' : 'Verboten',
            'Vertragsbeziehung' => $this->isExternal ? 'Extern' : 'Intern',
            'Debitor' => $this->debitor ? $this->debitor->getNummer() : null,
            'PSP-Element' => $this->financePsp ? $this->financePsp->getPspElement() : null,
            'Materialnummer' => $this->materialnummer ? $this->materialnummer->getMatNr() : null,
            'Rechnungsbetreff Zusatz' => $this->billingSubjectExtension,
            'Fakturaziel' => $this->fakturaziel ? $this->fakturaziel->getName() : null,
            'SAP Bestellnummer' => $this->financeOrder ? $this->financeOrder->getOrderNumber() : null,
            'ICP Kontierung Sachkonto' => $this->sachkonto ? $this->sachkonto->getSachkonto() . '_' . $this->sachkonto->getPartnergesellschaft() : null,
            'ICP Kontierung PSP/KSt' => $this->icpKontPspKst,
            'Ansprechpartner' => $this->ansprechpartner ? $this->ansprechpartner->getSurnameNameDividedByComma(): null,
            'Vorgangsbezeichnung' => $this->positionName,
            'Standortbezeichnung' => $this->locationName,
            'Externe Bestellnummer' => $this->orderPurchaseKey
        ];
    }
}
