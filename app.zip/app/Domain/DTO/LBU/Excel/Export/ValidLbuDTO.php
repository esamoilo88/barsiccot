<?php

namespace App\Domain\DTO\LBU\Excel\Export;

use App\Domain\Entities\FinanceCreditReason;
use App\Domain\Entities\Interfaces\Absender;
use App\Domain\Entities\OfferDebitor;
use App\Domain\Entities\OfferFakturaFakturaziel;
use App\Domain\Entities\OfferFakturaVorgangstyp;
use App\Domain\ValueObjects\SIN;

class ValidLbuDTO
{
    private SIN $sin;
    private int $leistungsMonth;
    private int $leistungsYear;
    private int $fakturaMonth;
    private int $fakturaYear;
    private OfferFakturaVorgangstyp $vorgangstyp;
    private OfferFakturaFakturaziel $fakturaziel;
    private ?Absender $ansprechpartner;
    private ?bool $abgrenzung;
    private int $createdById;
    private OfferDebitor $debitor;
    private ?string $bestellnummer;
    private ?FinanceCreditReason $creditReason;
    private ?string $rechnungsnummer;
    private ?string $billingSubjectExtension;
    private ?string $kommentar;
    private float $totalSum = 0;

    /**
     * ValidLbuDTO constructor.
     * @param SIN $sin
     * @param int $leistungsMonth
     * @param int $leistungsYear
     * @param int $fakturaMonth
     * @param int $fakturaYear
     * @param OfferFakturaVorgangstyp $vorgangstyp
     * @param OfferFakturaFakturaziel $fakturaziel
     * @param Absender|null $ansprechpartner
     * @param bool $abgrenzung
     * @param int $createdById
     * @param OfferDebitor $debitor
     * @param string|null $bestellnummer
     * @param FinanceCreditReason|null $creditReason
     * @param string|null $rechnungsnummer
     * @param string|null $billingSubjectExtension
     * @param string|null $kommentar
     */
    public function __construct(
        SIN $sin,
        int $leistungsMonth,
        int $leistungsYear,
        int $fakturaMonth,
        int $fakturaYear,
        OfferFakturaVorgangstyp $vorgangstyp,
        OfferFakturaFakturaziel $fakturaziel,
        ?Absender $ansprechpartner,
        bool $abgrenzung,
        int $createdById,
        OfferDebitor $debitor,
        ?string $bestellnummer,
        ?FinanceCreditReason $creditReason = null,
        ?string $rechnungsnummer = null,
        ?string $billingSubjectExtension = null,
        ?string $kommentar = null
    )
    {
        $this->sin = $sin;
        $this->leistungsMonth = $leistungsMonth;
        $this->leistungsYear = $leistungsYear;
        $this->fakturaMonth = $fakturaMonth;
        $this->fakturaYear = $fakturaYear;
        $this->vorgangstyp = $vorgangstyp;
        $this->fakturaziel = $fakturaziel;
        $this->ansprechpartner = $ansprechpartner;
        $this->abgrenzung = $abgrenzung;
        $this->createdById = $createdById;
        $this->debitor = $debitor;
        $this->bestellnummer = $bestellnummer;
        $this->creditReason = $creditReason;
        $this->rechnungsnummer = $rechnungsnummer;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->kommentar = $kommentar;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getLeistungsMonth(): int
    {
        return $this->leistungsMonth;
    }

    /**
     * @return int
     */
    public function getLeistungsYear(): int
    {
        return $this->leistungsYear;
    }

    /**
     * @return int
     */
    public function getFakturaMonth(): int
    {
        return $this->fakturaMonth;
    }

    /**
     * @return int
     */
    public function getFakturaYear(): int
    {
        return $this->fakturaYear;
    }

    /**
     * @return OfferFakturaVorgangstyp
     */
    public function getVorgangstyp(): OfferFakturaVorgangstyp
    {
        return $this->vorgangstyp;
    }

    /**
     * @return OfferFakturaFakturaziel
     */
    public function getFakturaziel(): OfferFakturaFakturaziel
    {
        return $this->fakturaziel;
    }

    /**
     * @return Absender|null
     */
    public function getAnsprechpartner(): ?Absender
    {
        return $this->ansprechpartner;
    }

    /**
     * @return bool|null
     */
    public function getAbgrenzung(): ?bool
    {
        return $this->abgrenzung;
    }

    /**
     * @return int
     */
    public function getCreatedById(): int
    {
        return $this->createdById;
    }

    /**
     * @return OfferDebitor
     */
    public function getDebitor(): OfferDebitor
    {
        return $this->debitor;
    }

    /**
     * @return string|null
     */
    public function getBestellnummer(): ?string
    {
        return $this->bestellnummer;
    }

    /**
     * @return FinanceCreditReason|null
     */
    public function getCreditReason(): ?FinanceCreditReason
    {
        return $this->creditReason;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }


    /**
     * @param float $totalSum
     */
    public function addTotalSum(float $totalSum): void
    {
        $this->totalSum += $totalSum;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'sin' => $this->sin->withPrefix(),
            'leistungsMonth' => $this->leistungsMonth,
            'leistungsYear' => $this->leistungsYear,
            'fakturaMonth' => $this->fakturaMonth,
            'fakturaYear' => $this->fakturaYear,
            'totalSum' => $this->totalSum,
            'abgrenzung' => $this->abgrenzung ? 'Ja': 'Nein',
            'vorgangstyp' => $this->vorgangstyp->getType()
        ];
    }
}
