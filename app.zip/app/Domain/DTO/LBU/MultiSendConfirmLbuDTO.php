<?php

namespace App\Domain\DTO\LBU;

use App\Domain\Entities\Interfaces\Absender;

class MultiSendConfirmLbuDTO
{
    private array $lbuList;
    private array $attachedfiles;
    private ?Absender $absender;

    /**
     * MultiSendConfirmLbuDTO constructor.
     * @param array $lbuList
     * @param array $attachedfiles
     * @param Absender|null $absender
     */
    public function __construct(array $lbuList, array $attachedfiles, ?Absender $absender)
    {
        $this->lbuList = $lbuList;
        $this->attachedfiles = $attachedfiles;
        $this->absender = $absender;
    }

    /**
     * @return array
     */
    public function getLbuList(): array
    {
        return $this->lbuList;
    }

    /**
     * @return array
     */
    public function getAttachedfiles(): array
    {
        return $this->attachedfiles;
    }

    /**
     * @return Absender|null
     */
    public function getAbsender(): ?Absender
    {
        return $this->absender;
    }

    /**
     * @return bool
     */
    public function isByJob(): bool
    {
        return $this->absender === null;
    }

}
