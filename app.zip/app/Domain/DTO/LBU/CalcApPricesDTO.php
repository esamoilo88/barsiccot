<?php


namespace App\Domain\DTO\LBU;


use App\Domain\ValueObjects\SIN;

class CalcApPricesDTO
{
    protected SIN $sin;
    protected ?int $apId;
    protected ?float $einzelpreisDtts;
    protected ?float $gmkzTdg;
    protected ?float $menge;
    protected bool $negative;
    protected ?string $apBezeichnung;

    /**
     * CalcApPricesDTO constructor.
     * @param SIN $sin
     * @param int|null $apId
     * @param float|null $einzelpreisDtts
     * @param float|null $gmkzTdg
     * @param float|null $menge
     * @param bool $negative
     * @param string|null $apBezeichnung
     */
    public function __construct(
        SIN $sin,
        ?int $apId,
        ?float $einzelpreisDtts = null,
        ?float $gmkzTdg = null,
        ?float $menge = null,
        bool $negative = false,
        ?string $apBezeichnung = null
    )
    {
        $this->sin = $sin;
        $this->apId = $apId;
        $this->einzelpreisDtts = $einzelpreisDtts;
        $this->gmkzTdg = $gmkzTdg;
        $this->menge = $menge;
        $this->negative = $negative;
        $this->apBezeichnung = $apBezeichnung;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @param float|null $einzelpreisDtts
     */
    public function setEinzelpreisDtts(?float $einzelpreisDtts): void
    {
        $this->einzelpreisDtts = $einzelpreisDtts;
    }

    /**
     * @param float|null $menge
     */
    public function setMenge(?float $menge): void
    {
        $this->menge = $menge;
    }

    /**
     * @param bool $negative
     */
    public function setNegative(bool $negative): void
    {
        $this->negative = $negative;
    }

    /**
     * @return int|null
     */
    public function getApId(): ?int
    {
        return $this->apId;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtts(): ?float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return float|null
     */
    public function getGmkzTdg(): ?float
    {
        return $this->gmkzTdg;
    }

    /**
     * @return float|null
     */
    public function getMenge(): ?float
    {
        return $this->menge;
    }

    /**
     * @return bool
     */
    public function isNegative(): bool
    {
        return $this->negative;
    }

    /**
     * @return bool
     */
    public function isEmptyMenge(): bool
    {
        return is_null($this->menge);
    }

    /**
     * @return string|null
     */
    public function getApBezeichnung(): ?string
    {
        return $this->apBezeichnung;
    }
}
