<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\BackendRoles;
use App\Domain\Entities\BackendBenutzer;

class CreateBackendProjectRolesDTO
{
    private BackendRoles  $backendRoles;
    private BackendBenutzer $backendBenutzer;

    /**
     * CreateBackendProjectRolesDTO constructor.
     * @param BackendRoles $backendRoles
     * @param BackendBenutzer $backendBenutzer
     */

    public function __construct(
        BackendRoles $backendRoles,
        BackendBenutzer $backendBenutzer
    )
    {
        $this->backendRoles = $backendRoles;
        $this->backendBenutzer = $backendBenutzer;
    }

    /**
     * @return BackendRoles
     */
    public function backendRoles(): BackendRoles
    {
        return $this->backendRoles;
    }

    /**
     * @return BackendBenutzer
     */
    public function backendBenutzer(): BackendBenutzer
    {
        return $this->backendBenutzer;
    }
}
