<?php

namespace App\Domain\DTO\Project;


use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\SalesNotetype;
use App\Domain\Entities\SalesNote;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class UpdateSalesNotesDTO
{
    private SalesNote $saleNote;
    private string $note;
    private bool $isPrivate;
    private SalesNotetype $type;

    /**
     * UpdateSalesNotesDTO constructor.
     * @param SalesNote $saleNote
     * @param string $note
     * @param SalesNotetype $type
     * @param bool $isPrivate
     */
    public function __construct(
        SalesNote $saleNote,
        string $note,
        SalesNotetype $type,
        bool $isPrivate
    )
    {
        $this->saleNote = $saleNote;
        $this->note = $note;
        $this->type = $type;
        $this->isPrivate = $isPrivate;
    }

    /**
     * @return SalesNote
     */
    public function getSaleNote(): SalesNote
    {
        return $this->saleNote;
    }

    /**
     * @return string
     */
    public function getNote(): string
    {
        return $this->note;
    }

    /**
     * @return bool
     */
    public function isPrivate(): bool
    {
        return $this->isPrivate;
    }

    /**
     * @return SalesNotetype
     */
    public function getType(): SalesNotetype
    {
        return $this->type;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return $this->saleNote->getProject()->getSin();
    }
}
