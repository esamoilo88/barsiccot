<?php

namespace App\Domain\DTO\Project;


use App\Domain\Entities\CrmGp;
use App\Domain\Entities\GlobalGate;
use DateTime;

class UpdateProjectDTO
{
    private GlobalGate $globalGate;
    private ?int $auftragswahrscheinlichkeit;
    private ?DateTime $aeMonat;
    private ?int $stammSimpleId;
    private ?string $vorhabenbeschreibung;
    private DateTime $vorhabenbeginn;
    private string $volumenDtts;
    private ?DateTime $umsatzMonat;

    /**
     * UpdateProjectDTO constructor.
     * @param GlobalGate $globalGate
     * @param int|null $auftragswahrscheinlichkeit
     * @param DateTime|null $aeMonat
     * @param int|null $stammSimpleId
     * @param string|null $vorhabenbeschreibung
     * @param DateTime $vorhabenbeginn
     * @param string $volumenDtts
     * @param DateTime|null $umsatzMonat
     */
    public function __construct(
        GlobalGate $globalGate,
        ?int $auftragswahrscheinlichkeit,
        ?DateTime $aeMonat,
        ?int $stammSimpleId,
        ?string $vorhabenbeschreibung,
        DateTime $vorhabenbeginn,
        string $volumenDtts,
        ?DateTime $umsatzMonat
    )
    {
        $this->globalGate = $globalGate;
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
        $this->aeMonat = $aeMonat;
        $this->stammSimpleId = $stammSimpleId;
        $this->vorhabenbeschreibung = $vorhabenbeschreibung;
        $this->vorhabenbeginn = $vorhabenbeginn;
        $this->volumenDtts = $volumenDtts;
        $this->umsatzMonat = $umsatzMonat;
    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }


    /**
     * @return int
     */
    public function getStammSimpleId(): ?int
    {
        return $this->stammSimpleId;
    }

    /**
     * @return string
     */
    public function getVolumenDtts(): string
    {
        return $this->volumenDtts;
    }

    /**
     * @return int|null
     */
    public function getAuftragswahrscheinlichkeit(): ?int
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @return DateTime|null
     */
    public function getAeMonat(): ?DateTime
    {
        return $this->aeMonat;
    }

    /**
     * @return DateTime|null
     */
    public function getUmsatzMonat(): ?DateTime
    {
        return $this->umsatzMonat;
    }

    /**
     * @return string|null
     */
    public function getVorhabenbeschreibung(): ?string
    {
        return $this->vorhabenbeschreibung;
    }

    /**
     * @return DateTime
     */
    public function getVorhabenbeginn(): DateTime
    {
        return $this->vorhabenbeginn;
    }

    /**
     * @return bool
     */
    public function hasAeMonat(): bool
    {
        return (bool)$this->aeMonat;
    }

    /**
     * @return bool
     */
    public function hasUmsatzMonat(): bool
    {
        return (bool)$this->umsatzMonat;
    }

    /**
     * @return bool
     */
    public function hasVorhabenbeschreibung(): bool
    {
        return (bool)$this->vorhabenbeschreibung;
    }

    /**
     * @return bool
     */
    public function hasStammSimpleId(): bool
    {
        return (bool)$this->stammSimpleId;
    }

    /**
     * @return bool
     */
    public function hasAuftragswahrscheinlichkeit(): bool
    {
        return (bool)$this->auftragswahrscheinlichkeit;
    }

}
