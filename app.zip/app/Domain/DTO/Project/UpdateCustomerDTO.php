<?php

namespace App\Domain\DTO\Project;


use App\Domain\Entities\CrmGp;
use App\Domain\Entities\GlobalGate;
use DateTime;

class UpdateCustomerDTO
{
    private GlobalGate $globalGate;
    private ?string $kundenname;
    private ?string $kundennummer;
    private ?string $kundenstandort;
    private ?string $ustId;
    private ?int $gpNummer;
    private ?CrmGp $gp;

    /**
     * UpdateCustomerDTO constructor.
     * @param GlobalGate $globalGate
     * @param string|null $kundenname
     * @param string|null $kundennummer
     * @param string|null $kundenstandort
     * @param string|null $ustId
     * @param int|null $gpNummer
     * @param CrmGp|null $gp
     */
    public function __construct(
        GlobalGate $globalGate,
        ?string $kundenname,
        ?string $kundennummer,
        ?string $kundenstandort,
        ?string $ustId,
        ?int $gpNummer,
        ?CrmGp $gp
    )
    {
        $this->globalGate = $globalGate;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->kundenstandort = $kundenstandort;
        $this->ustId = $ustId;
        $this->gpNummer = $gpNummer;
        $this->gp = $gp;
    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }

    /**
     * @return string
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return int
     */
    public function getKundennummer(): ?int
    {
        return $this->kundennummer;
    }

    /**
     * @return string|null
     */
    public function getKundenstandort(): ?string
    {
        return $this->kundenstandort;
    }


    /**
     * @return string|null
     */
    public function getUstId(): ?string
    {
        return $this->ustId;
    }

    /**
     * @return int|null
     */
    public function getGpNummer(): ?int
    {
        return $this->gpNummer;
    }

    /**
     * @return CrmGp|null
     */
    public function getGp(): ?CrmGp
    {
        return $this->gp;
    }


    /**
     * @return bool
     */
    public function hasGpNummer(): bool
    {
        return $this->gpNummer !== null;
    }

    /**
     * @return bool
     */
    public function hasGp(): bool
    {
        return $this->gp !== null;
    }

    /**
     * @return bool
     */
    public function hasUstId(): bool
    {
        return $this->ustId !== null;
    }

    /**
     * @return bool
     */
    public function hasKundenname(): bool
    {
        return $this->kundenname !== null;
    }

    /**
     * @return bool
     */
    public function hasKundennummer(): bool
    {
        return $this->kundennummer !== null;
    }

    /**
     * @return bool
     */
    public function hasKundenstandort(): bool
    {
        return $this->kundenstandort !== null;
    }


}
