<?php


namespace App\Domain\DTO\Project;


use App\Domain\Entities\SalesStammdaten;
use App\Domain\Entities\SalesStatus;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class ResetStatusToS0DTO
{

    /**
     * @var SalesStammdaten
     */
    private SalesStammdaten $project;

    /**
     * @var SalesStatus
     */
    private SalesStatus $status;

    /**
     * ResetStatusToS0DTO constructor.
     * @param SalesStammdaten $project
     * @param SalesStatus $status
     */
    public function __construct(
        SalesStammdaten $project,
        SalesStatus $status
    )
    {
        $this->project = $project;
        $this->status = $status;
    }

    /**
     * @return SalesStammdaten
     */
    public function getProject(): SalesStammdaten
    {
        return $this->project;
    }

    /**
     * @return SalesStatus
     */
    public function getStatus(): SalesStatus
    {
        return $this->status;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return $this->project->getSin();
    }

    /**
     * @return SalesStatus
     */
    public function getCurrentStatus(): SalesStatus
    {
        return $this->project->getStatus();
    }
}
