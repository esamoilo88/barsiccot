<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\SalesNotetype;
use App\Domain\ValueObjects\SIN;

class CreateSalesNotesDTO
{
    private string $note;
    private bool $isPrivate;
    private BackendBenutzer $user;
    private SIN $sin;
    private SalesNotetype $type;

    /**
     * CreateSalesNotesDTO constructor.
     * @param string $note
     * @param BackendBenutzer $user
     * @param SIN $sin
     * @param SalesNotetype $type
     * @param bool $isPrivate
     */
    public function __construct(
        string $note,
        BackendBenutzer $user,
        SIN $sin,
        SalesNotetype $type,
        bool $isPrivate = false
    )
    {
        $this->note = $note;
        $this->user = $user;
        $this->sin = $sin;
        $this->type = $type;
        $this->isPrivate = $isPrivate;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return bool
     */
    public function isPrivate(): bool
    {
        return $this->isPrivate;
    }

    /**
     * @return string
     */
    public function getNote(): string
    {
        return $this->note;
    }

    /**
     * @return SalesNotetype
     */
    public function getType(): SalesNotetype
    {
        return $this->type;
    }
}
