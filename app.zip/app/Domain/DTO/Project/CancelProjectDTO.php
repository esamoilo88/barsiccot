<?php


namespace App\Domain\DTO\Project;


use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\GlobalGate;
use App\Domain\Entities\SalesAblehnunggrund;
use App\Domain\Entities\SalesStammdaten;

class CancelProjectDTO
{
    private SalesAblehnunggrund $reason;
    private BackendBenutzer $user;
    private SalesStammdaten $sale;
    private string $description;

    /**
     * CancelProjectDTO constructor.
     * @param SalesAblehnunggrund $reason
     * @param BackendBenutzer $user
     * @param SalesStammdaten $sale
     * @param string $description
     */
    public function __construct(
        SalesAblehnunggrund $reason,
        BackendBenutzer $user,
        SalesStammdaten $sale,
        string $description
    ){
        $this->reason = $reason;
        $this->user = $user;
        $this->sale = $sale;
        $this->description = $description;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return GlobalGate
     */
    public function getProject(): GlobalGate
    {
        return $this->sale->getGlobalGate();
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return SalesAblehnunggrund
     */
    public function getReason(): SalesAblehnunggrund
    {
        return $this->reason;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSale(): SalesStammdaten
    {
        return $this->sale;
    }
}
