<?php

namespace App\Domain\DTO\Project;


use App\Domain\Entities\GlobalGate;

class UpdateGlobalGateDTO
{
    private GlobalGate $globalGate;
    private ?string $thema;

    /**
     * UpdateGlobalGateDTO constructor.
     * @param GlobalGate $globalGate
     * @param string|null $thema
     */
    public function __construct(
        GlobalGate $globalGate,
        ?string $thema
    )
    {
        $this->globalGate = $globalGate;
        $this->thema = $thema;

    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }


    /**
     * @return string|null
     */
    public function getThema(): ?string
    {
        return $this->thema;
    }

    /**
     * @return bool
     */
    public function hasThema(): bool
    {
        return (bool)$this->thema;
    }

}
