<?php

namespace App\Domain\DTO\Project;

use App\Domain\ValueObjects\SIN;

class StoreRemoveProjectTagDTO
{
    private SIN $sin;
    private string $tag;

    /**
     * StoreProjectTagDTO constructor.
     * @param SIN $sin
     * @param string $tag
     */
    public function __construct(SIN $sin, string $tag)
    {
        $this->sin = $sin;
        $this->tag = $tag;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getTag(): string
    {
        return $this->tag;
    }
}
