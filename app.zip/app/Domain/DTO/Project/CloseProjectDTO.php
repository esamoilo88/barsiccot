<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\OfferAbgeschlossengrund;
use App\Domain\ValueObjects\SIN;

class CloseProjectDTO
{
    private SIN $sin;
    private OfferAbgeschlossengrund $reason;

    /**
     * CloseProjectDTO constructor.
     * @param SIN $sin
     * @param OfferAbgeschlossengrund|object $reason
     */
    public function __construct(SIN $sin, OfferAbgeschlossengrund $reason)
    {
        $this->sin = $sin;
        $this->reason = $reason;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return OfferAbgeschlossengrund
     */
    public function getReason(): OfferAbgeschlossengrund
    {
        return $this->reason;
    }
}
