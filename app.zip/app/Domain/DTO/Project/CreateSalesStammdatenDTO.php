<?php

namespace App\Domain\DTO\Project;


use App\Domain\Entities\CrmCustomer;
use App\Domain\Entities\CrmGp;
use App\Domain\Entities\GlobalGate;
use DateTime;

class CreateSalesStammdatenDTO
{
    private ?int $stammSimpleId;
    private ?string $kundenname;
    private ?string $kundennummer;
    private ?string $kundenstandort;
    private DateTime $vorhabenbeginn;
    private string $volumenDtts;
    private ?string $ustId;
    private ?int $gpNummer;
    private bool $useForecastAsAbgrenzung;
    private ?CrmGp $gp;
    private ?CrmCustomer $customer;


    /**
     * CreateSalesStammdatenDTO constructor.
     * @param int|null $stammSimpleId
     * @param string|null $kundenname
     * @param string|null $kundennummer
     * @param string|null $kundenstandort
     * @param DateTime $vorhabenbeginn
     * @param string $volumenDtts
     * @param string|null $ustId
     * @param int|null $gpNummer
     * @param bool $useForecastAsAbgrenzung
     * @param CrmGp|null $gp
     * @param CrmCustomer|null $customer
     */
    public function __construct(
        ?int $stammSimpleId,
        ?string $kundenname,
        ?string $kundennummer,
        ?string $kundenstandort,
        DateTime $vorhabenbeginn,
        string $volumenDtts,
        ?string $ustId,
        ?int $gpNummer,
        bool $useForecastAsAbgrenzung,
        ?CrmGp $gp,
        ?CrmCustomer $customer = null
    )
    {
        $this->stammSimpleId = $stammSimpleId;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->kundenstandort = $kundenstandort;
        $this->vorhabenbeginn = $vorhabenbeginn;
        $this->volumenDtts = $volumenDtts;
        $this->ustId = $ustId;
        $this->gpNummer = $gpNummer;
        $this->useForecastAsAbgrenzung = $useForecastAsAbgrenzung;
        $this->gp = $gp;
        $this->customer = $customer;
    }

    /**
     * @return int
     */
    public function getStammSimpleId(): ?int
    {
        return $this->stammSimpleId;
    }

    /**
     * @return DateTime
     */
    public function getVorhabenbeginn(): DateTime
    {
        return $this->vorhabenbeginn;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string|null
     */
    public function getKundennummer(): ?string
    {
        return $this->kundennummer;
    }

    /**
     * @return string|null
     */
    public function getKundenstandort(): ?string
    {
        return $this->kundenstandort;
    }


    /**
     * @return string
     */
    public function getVolumenDtts(): string
    {
        return $this->volumenDtts;
    }

    /**
     * @return string|null
     */
    public function getUstId(): ?string
    {
        return $this->ustId;
    }

    /**
     * @return int|null
     */
    public function getGpNummer(): ?int
    {
        return $this->gpNummer;
    }

    /**
     * @return CrmGp|null
     */
    public function getGp(): ?CrmGp
    {
        return $this->gp;
    }

    /**
     * @return bool
     */
    public function getUseForecastAsAbgrenzung(): bool
    {
        return $this->useForecastAsAbgrenzung;
    }

    /**
     * @return CrmCustomer|null
     */
    public function getCustomer(): ?CrmCustomer
    {
        return $this->customer;
    }

    /**
     * @return bool
     */
    public function hasStammSimpleId(): bool
    {
        return (bool)$this->stammSimpleId;
    }

    /**
     * @return bool
     */
    public function hasGpNummer(): bool
    {
        return $this->gpNummer !== null;
    }

    /**
     * @return bool
     */
    public function hasGp(): bool
    {
        return $this->gp !== null;
    }

    /**
     * @return bool
     */
    public function hasUstId(): bool
    {
        return $this->ustId !== null;
    }

    /**
     * @return bool
     */
    public function hasKundenname(): bool
    {
        return $this->kundenname !== null;
    }

    /**
     * @return bool
     */
    public function hasKundennummer(): bool
    {
        return $this->kundennummer !== null;
    }

    /**
     * @return bool
     */
    public function hasKundenstandort(): bool
    {
        return $this->kundenstandort !== null;
    }

    /**
     * @return bool
     */
    public function hasUseForecastAsAbgrenzung(): bool
    {
        return $this->useForecastAsAbgrenzung !== null;
    }
}
