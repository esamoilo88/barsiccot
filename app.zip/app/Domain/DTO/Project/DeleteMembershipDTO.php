<?php


namespace App\Domain\DTO\Project;


use App\Domain\Entities\BackendProjectRoles;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class DeleteMembershipDTO
{
    private BackendProjectRoles $projectRole;

    public function __construct(BackendProjectRoles $projectRole)
    {
        $this->projectRole = $projectRole;
    }

    /**
     * @return BackendProjectRoles
     */
    public function getProjectRole(): BackendProjectRoles
    {
        return $this->projectRole;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->projectRole->salesStammdaten()->getSimpleId();
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSin(): SIN
    {
        return $this->projectRole->salesStammdaten()->getSin();
    }
}
