<?php


namespace App\Domain\DTO\Project;


use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendRoleInfo;
use App\Domain\Entities\BackendRoles;
use App\Domain\Entities\SalesStammdaten;

class CreateMembershipDTO
{

    private SalesStammdaten $project;
    private BackendBenutzer $user;
    private BackendRoles $role;
    private ?BackendRoleInfo $roleInfo;
    private bool $representative;
    private bool $emailNotification;

    /**
     * CreateMembershipDTO constructor.
     * @param SalesStammdaten $project
     * @param BackendBenutzer $user
     * @param BackendRoles $role
     * @param BackendRoleInfo|null $roleInfo
     * @param bool $representative
     * @param bool $emailNotification
     */
    public function __construct(
        SalesStammdaten $project,
        BackendBenutzer $user,
        BackendRoles $role,
        ?BackendRoleInfo $roleInfo = null,
        bool $representative = false,
        bool $emailNotification = false
    )
    {
        $this->project = $project;
        $this->user = $user;
        $this->role = $role;
        $this->representative = $representative;
        $this->emailNotification = $emailNotification;
        $this->roleInfo = $roleInfo;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return BackendRoles
     */
    public function getRole(): BackendRoles
    {
        return $this->role;
    }

    /**
     * @return SalesStammdaten
     */
    public function getProject(): SalesStammdaten
    {
        return $this->project;
    }

    /**
     * @return bool
     */
    public function isRepresentative(): bool
    {
        return $this->representative;
    }

    /**
     * @return bool
     */
    public function isEmailNotification(): bool
    {
        return $this->emailNotification;
    }

    /**
     * @return BackendRoleInfo|null
     */
    public function getRoleInfo(): ?BackendRoleInfo
    {
        return $this->roleInfo;
    }
}
