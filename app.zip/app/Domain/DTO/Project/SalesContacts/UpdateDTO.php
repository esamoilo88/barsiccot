<?php


namespace App\Domain\DTO\Project\SalesContacts;


use App\Domain\ValueObjects\SIN;

class UpdateDTO
{
    private SIN $sin;
    private int $contactId;
    private int $roleId;

    /**
     * UpdateDTO constructor.
     * @param SIN $sin
     * @param int $contactId
     * @param int $roleId
     */
    public function __construct(
        SIN $sin,
        int $contactId,
        int $roleId
    )
    {
        $this->sin = $sin;
        $this->contactId = $contactId;
        $this->roleId = $roleId;
    }

    /**
     * @return int
     */
    public function getRoleId(): int
    {
        return $this->roleId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getContactId(): int
    {
        return $this->contactId;
    }
}
