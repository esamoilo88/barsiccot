<?php


namespace App\Domain\DTO\Project\SalesContacts;


use App\Domain\ValueObjects\SIN;

class CreateDTO
{
    protected SIN $sin;
    protected string $userId;
    protected int $roleId;

    /**
     * CreateUpdateDTO constructor.
     * @param SIN $sin
     * @param string $userId
     * @param int $roleId
     */
    public function __construct(
        SIN $sin,
        string $userId,
        int $roleId
    )
    {
        $this->sin = $sin;
        $this->userId = $userId;
        $this->roleId = $roleId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getRoleId(): int
    {
        return $this->roleId;
    }

    /**
     * @return string
     */
    public function getUserId(): string
    {
        return $this->userId;
    }
}
