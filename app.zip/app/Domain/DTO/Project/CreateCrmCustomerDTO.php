<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\CrmGp;
use App\Domain\Entities\CrmKunde;

class CreateCrmCustomerDTO
{
    private ?int $id;
    private string $name;
    private bool $internal;
    private bool $isActive;
    private string $city;
    private ?CrmGp $crmGp;
    private ?CrmKunde $crmKunde;
    private ?int $akpGpNr;
    private ?string $akpGpNameLang;
    private ?string $akpZgId;
    private ?string $akpSegment;
    private ?string $akpZgBezeichnung;
    private ?string $akpWzId;
    private ?string $akpWzBezeichnung;
    private ?string $akpUstId;
    private ?string $akpDTAGnameLang;
    private ?string $akpDTAGkdnr;
    private ?string $plz;

    /**
     * CreateCrmCustomerDTO constructor.
     * @param int|null $id
     * @param string $name
     * @param string $city
     * @param bool $isActive
     * @param bool $internal
     * @param CrmGp|null $crmGp
     * @param CrmKunde|null $crmKunde
     * @param int|null $akpGpNr
     * @param string|null $akpGpNameLang
     * @param string|null $akpZgId
     * @param string|null $akpZgBezeichnung
     * @param string|null $akpWzId
     * @param string|null $akpWzBezeichnung
     * @param string|null $akpUstId
     * @param string|null $akpSegment
     * @param string|null $akpDTAGnameLang
     * @param string|null $akpDTAGkdnr
     * @param string|null $plz
     */
    public function __construct(
        ?int $id,
        string $name,
        string $city,
        bool $isActive,
        bool $internal,
        ?CrmGp $crmGp,
        ?CrmKunde $crmKunde,
        ?int $akpGpNr,
        ?string $akpGpNameLang,
        ?string $akpZgId,
        ?string $akpZgBezeichnung,
        ?string $akpWzId,
        ?string $akpWzBezeichnung,
        ?string $akpUstId,
        ?string $akpSegment,
        ?string $akpDTAGnameLang,
        ?string $akpDTAGkdnr,
        ?string $plz
    )
    {
        $this->id = $id;
        $this->name = $name;
        $this->city = $city;
        $this->isActive = $isActive;
        $this->internal = $internal;
        $this->crmGp = $crmGp;
        $this->crmKunde = $crmKunde;
        $this->akpGpNr = $akpGpNr;
        $this->akpGpNameLang = $akpGpNameLang;
        $this->akpZgId = $akpZgId;
        $this->akpZgBezeichnung = $akpZgBezeichnung;
        $this->akpWzId = $akpWzId;
        $this->akpWzBezeichnung = $akpWzBezeichnung;
        $this->akpUstId = $akpUstId;
        $this->akpSegment = $akpSegment;
        $this->akpDTAGnameLang = $akpDTAGnameLang;
        $this->akpDTAGkdnr = $akpDTAGkdnr;
        $this->plz = $plz;
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getCity(): string
    {
        return $this->city;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->isActive;
    }

    /**
     * @return bool
     */
    public function getInternal(): bool
    {
        return $this->internal;
    }

    /**
     * @return CrmGp|null
     */
    public function getCrmGp(): ?CrmGp
    {
        return $this->crmGp;
    }

    /**
     * @return CrmKunde|null
     */
    public function getCrmKunde(): ?CrmKunde
    {
        return $this->crmKunde;
    }

    /**
     * @return int|null
     */
    public function getAkpGpNr(): ?int
    {
        return $this->akpGpNr;
    }

    /**
     * @return string|null
     */
    public function getAkpZgId(): ?string
    {
        return $this->akpZgId;
    }

    /**
     * @return string|null
     */
    public function getAkpZgBezeichnung(): ?string
    {
        return $this->akpZgBezeichnung;
    }

    /**
     * @return string|null
     */
    public function getAkpWzBezeichnung(): ?string
    {
        return $this->akpWzBezeichnung;
    }

    /**
     * @return string|null
     */
    public function getAkpWzId(): ?string
    {
        return $this->akpWzId;
    }

    /**
     * @return string|null
     */
    public function getAkpGpNameLang(): ?string
    {
        return $this->akpGpNameLang;
    }

    /**
     * @return string|null
     */
    public function getAkpUstId(): ?string
    {
        return $this->akpUstId;
    }

    /**
     * @return string|null
     */
    public function getAkpSegment(): ?string
    {
        return $this->akpSegment;
    }

    /**
     * @return string|null
     */
    public function getAkpDTAGnameLang(): ?string
    {
        return $this->akpDTAGnameLang;
    }

    /**
     * @return string|null
     */
    public function getPlz(): ?string
    {
        return $this->plz;
    }

    /**
     * @return string|null
     */
    public function getAkpDTAGkdnr(): ?string
    {
        return $this->akpDTAGkdnr;
    }
}
