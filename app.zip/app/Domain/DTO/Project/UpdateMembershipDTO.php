<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Entities\BackendRoleInfo;
use App\Domain\Entities\BackendRoles;

class UpdateMembershipDTO
{
    private BackendProjectRoles $projectRoles;
    private BackendBenutzer $user;
    private BackendRoles $role;
    private ?BackendRoleInfo $roleInfo;
    private bool $representative;

    public function __construct(
        BackendProjectRoles $projectRoles,
        BackendBenutzer $user,
        BackendRoles $role,
        ?BackendRoleInfo $roleInfo,
        bool $representative = false
    )
    {
        $this->projectRoles = $projectRoles;
        $this->user = $user;
        $this->role = $role;
        $this->representative = $representative;
        $this->roleInfo = $roleInfo;
    }

    /**
     * @return BackendRoles
     */
    public function getRole(): BackendRoles
    {
        return $this->role;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return BackendProjectRoles
     */
    public function getProjectRoles(): BackendProjectRoles
    {
        return $this->projectRoles;
    }

    /**
     * @return BackendRoleInfo
     */
    public function getRoleInfo(): BackendRoleInfo
    {
        return $this->roleInfo;
    }

    /**
     * @return bool
     */
    public function isRepresentative(): bool
    {
        return $this->representative;
    }

    /**
     * @return bool
     */
    public function hasRoleInfo(): bool
    {
        return $this->roleInfo !== null;
    }
}
