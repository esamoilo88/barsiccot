<?php

namespace App\Domain\DTO\Project;

use App\Domain\Entities\GlobalProzess;

class CreateGlobalGateDTO
{
    private ?string $thema;
    private ?string $sicherheitsstufe;
    private GlobalProzess $prozess;

    /**
     * CreateGlobalGateDTO constructor.
     * @param string|null $thema
     * @param string|null $sicherheitsstufe
     * @param GlobalProzess $prozess
     */

    public function __construct(
        ?string $thema,
        ?string $sicherheitsstufe,
        GlobalProzess $prozess
    )
    {
        $this->thema = $thema;
        $this->sicherheitsstufe = $sicherheitsstufe;
        $this->prozess = $prozess;
    }

    /**
     * @return string
     */
    public function thema(): ?string
    {
        return $this->thema;
    }

    /**
     * @return string
     */
    public function sicherheitsstufe(): ?string
    {
        return $this->sicherheitsstufe;
    }


    /**
     * @return GlobalProzess
     */
    public function prozess(): GlobalProzess
    {
        return $this->prozess;
    }

    /**
     * @return bool
     */
    public function hasSicherheitsstufe(): bool
    {
        return (bool)$this->sicherheitsstufe;
    }

    /**
     * @return bool
     */
    public function hasThema(): bool
    {
        return (bool)$this->thema;
    }

    /**
     * @return bool
     */
    public function hasProzess(): bool
    {
        return $this->prozess !== null;
    }

}
