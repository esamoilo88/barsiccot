<?php


namespace App\Domain\DTO\Admin\Members;


class ManageMembersDTO
{
    /** @var MemberDTO[]  */
    protected array $toUpdateOrCreate;
    protected array $toDelete;
    protected array $simpleIds;

    /**
     * ManageMembersDTO constructor.
     * @param MemberDTO[] $toUpdateOrCreate
     * @param array $toDelete
     * @param array $simpleIds
     */
    public function __construct(array $toUpdateOrCreate, array $toDelete, array $simpleIds)
    {
        $this->toUpdateOrCreate = $toUpdateOrCreate;
        $this->toDelete = $toDelete;
        $this->simpleIds = $simpleIds;
    }

    /**
     * @return MemberDTO[]
     */
    public function getToUpdateOrCreate(): array
    {
        return $this->toUpdateOrCreate;
    }

    /**
     * @return array
     */
    public function getToUpdateOrCreateIds(): array
    {
        return array_map(function ($user) {
            return $user->getUserId();
        }, $this->toUpdateOrCreate);
    }

    /**
     * @return array
     */
    public function getToDelete(): array
    {
        return $this->toDelete;
    }

    /**
     * @return array
     */
    public function getSimpleIds(): array
    {
        return $this->simpleIds;
    }




}
