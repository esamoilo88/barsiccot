<?php


namespace App\Domain\DTO\Admin\Members;


class MemberDTO
{
    protected int $userId;
    protected int $roleId;
    protected ?int $roleInfoId;
    protected bool $representative;

    /**
     * MemberDTO constructor.
     * @param int $userId
     * @param int $roleId
     * @param int|null $roleInfoId
     * @param bool $representative
     */
    public function __construct(int $userId, int $roleId, ?int $roleInfoId, bool $representative)
    {
        $this->userId = $userId;
        $this->roleId = $roleId;
        $this->roleInfoId = $roleInfoId;
        $this->representative = $representative;
    }

    /**
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }

    /**
     * @return int
     */
    public function getRoleId(): int
    {
        return $this->roleId;
    }

    /**
     * @return int|null
     */
    public function getRoleInfoId(): ?int
    {
        return $this->roleInfoId;
    }

    /**
     * @return bool
     */
    public function isRepresentative(): bool
    {
        return $this->representative;
    }
}
