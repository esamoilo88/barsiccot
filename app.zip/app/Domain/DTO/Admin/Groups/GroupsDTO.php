<?php


namespace App\Domain\DTO\Admin\Groups;


class GroupsDTO
{
    protected int $groupId;

    /**
     * GroupsDTO constructor.
     * @param int $groupId
     */
    public function __construct(int $groupId)
    {
        $this->groupId = $groupId;
    }

    /**
     * @return int
     */
    public function getGroupId(): int
    {
        return $this->groupId;
    }
}
