<?php


namespace App\Domain\DTO\Admin\Groups;


class ManageGroupsDTO
{
    /** @var GroupsDTO[]  */
    protected array $toCreate;
    protected array $toDelete;
    protected array $simpleIds;

    /**
     * ManageGroupsDTO constructor.
     * @param GroupsDTO[] $toCreate
     * @param array $toDelete
     * @param array $simpleIds
     */
    public function __construct(array $toCreate, array $toDelete, array $simpleIds)
    {
        $this->toCreate = $toCreate;
        $this->toDelete = $toDelete;
        $this->simpleIds = $simpleIds;
    }

    /**
     * @return GroupsDTO[]
     */
    public function getToCreate(): array
    {
        return $this->toCreate;
    }

    /**
     * @return array
     */
    public function getToCreateIds(): array
    {
        return array_map(function ($group) {
            return $group->getGroupId();
        }, $this->toCreate);
    }

    /**
     * @return array
     */
    public function getToDelete(): array
    {
        return $this->toDelete;
    }

    /**
     * @return array
     */
    public function getSimpleIds(): array
    {
        return $this->simpleIds;
    }




}
