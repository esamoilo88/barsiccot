<?php


namespace App\Domain\DTO\Admin\Users;


class NewUserEmailDTO
{
    protected string $firstName;
    protected string $lastName;
    protected string $username;
    protected string $password;
    protected string $link;
    protected array $emails;
    protected string $subject;

    /**
     * NewUserEmailDTO constructor.
     * @param string $firstName
     * @param string $lastName
     * @param string $username
     * @param string $password
     * @param string $link
     * @param array $emails
     * @param string $subject
     */
    public function __construct(
        string $firstName,
        string $lastName,
        string $username,
        string $password,
        string $link,
        array $emails,
        string $subject = 'Willkommen bei SIMPLE'
    )
    {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->username = $username;
        $this->password = $password;
        $this->link = $link;
        $this->emails= $emails;
        $this->subject = $subject;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }

    /**
     * @return string
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @return string
     */
    public function getUsername(): string
    {
        return $this->username;
    }

    /**
     * @return string
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    /**
     * @return string
     */
    public function getLink(): string
    {
        return $this->link;
    }

    /**
     * @return array
     */
    public function getEmails(): array
    {
        return $this->emails;
    }

}
