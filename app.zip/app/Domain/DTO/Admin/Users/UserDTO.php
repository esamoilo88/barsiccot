<?php


namespace App\Domain\DTO\Admin\Users;


class UserDTO
{
    protected string $email;
    protected string $vorname;
    protected string $nachname;
    protected string $username;
    protected ?string $anrede;
    protected ?string $firma;
    protected ?string $orge;
    protected ?string $ressort;
    protected ?string $telNr;
    protected ?string $bereichId;
    protected array $rechte;
    protected ?array $userGroup;
    protected bool $isAdmin;
    protected bool $blocked;
    protected bool $notification;
    protected bool $changePassword;
    protected ?int $userId;
    protected ?int $loginCount;
    protected ?string $internalNotes;

    /**
     * UserDTO constructor.
     * @param string $email
     * @param string $vorname
     * @param string $nachname
     * @param string $username
     * @param string|null $anrede
     * @param string|null $firma
     * @param string|null $orge
     * @param string|null $ressort
     * @param string|null $telNr
     * @param string|null $bereichId
     * @param array $rechte
     * @param array|null $userGroup
     * @param bool $isAdmin
     * @param bool $blocked
     * @param bool $notification
     * @param bool $changePassword
     * @param int|null $userId
     * @param int|null $loginCount
     * @param string|null $internalNotes
     */
    public function __construct(
        string $email,
        string $vorname,
        string $nachname,
        string $username,
        ?string $anrede = null,
        ?string $firma = null,
        ?string $orge = null,
        ?string $ressort = null,
        ?string $telNr = null,
        ?string $bereichId = null,
        array $rechte = [],
        ?array $userGroup = [],
        bool $isAdmin = false,
        bool $blocked = false,
        bool $notification = false,
        bool $changePassword = false,
        ?int $userId = null,
        ?int $loginCount = null,
        ?string $internalNotes = null
    )
    {
        $this->email = $email;
        $this->vorname = $vorname;
        $this->nachname = $nachname;
        $this->username = $username;
        $this->anrede = $anrede;
        $this->firma = $firma;
        $this->orge = $orge;
        $this->ressort = $ressort;
        $this->telNr = $telNr;
        $this->bereichId = $bereichId;
        $this->rechte = $rechte;
        $this->userGroup = $userGroup;
        $this->isAdmin = $isAdmin;
        $this->blocked = $blocked;
        $this->notification = $notification;
        $this->changePassword = $changePassword;
        $this->userId = $userId;
        $this->loginCount = $loginCount;
        $this->internalNotes = $internalNotes;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return string
     */
    public function getVorname(): string
    {
        return $this->vorname;
    }

    /**
     * @return string
     */
    public function getNachname(): string
    {
        return $this->nachname;
    }

    /**
     * @return string|null
     */
    public function getAnrede(): ?string
    {
        return $this->anrede;
    }

    /**
     * @return string|null
     */
    public function getFirma(): ?string
    {
        return $this->firma;
    }

    /**
     * @return string|null
     */
    public function getOrge(): ?string
    {
        return $this->orge;
    }

    /**
     * @return string|null
     */
    public function getRessort(): ?string
    {
        return $this->ressort;
    }

    /**
     * @return string|null
     */
    public function getTelNr(): ?string
    {
        return $this->telNr;
    }

    /**
     * @return string|null
     */
    public function getBereichId(): ?string
    {
        return $this->bereichId;
    }

    /**
     * @return array
     */
    public function getRechte(): array
    {
        return $this->rechte;
    }

    /**
     * @return array|null
     */
    public function getUserGroup(): ?array
    {
        return $this->userGroup;
    }

    /**
     * @return bool
     */
    public function isAdmin(): bool
    {
        return $this->isAdmin;
    }

    /**
     * @return bool
     */
    public function isBlocked(): bool
    {
        return $this->blocked;
    }

    /**
     * @return bool
     */
    public function isNotification(): bool
    {
        return $this->notification;
    }

    /**
     * @return int|null
     */
    public function getUserId(): ?int
    {
        return $this->userId;
    }

    /**
     * @return bool
     */
    public function isChangePassword(): bool
    {
        return $this->changePassword;
    }

    /**
     * @return int|null
     */
    public function getLoginCount(): ?int
    {
        return $this->loginCount;
    }

    /**
     * @return string|null
     */
    public function getInternalNotes(): ?string
    {
        return $this->internalNotes;
    }

    /**
     * @return string
     */
    public function getUsername(): string
    {
        return $this->username;
    }
}
