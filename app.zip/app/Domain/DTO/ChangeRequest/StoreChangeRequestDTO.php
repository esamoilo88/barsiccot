<?php

namespace App\Domain\DTO\ChangeRequest;

use App\Domain\Entities\OfferChangerequestTyp;
use App\Domain\ValueObjects\SIN;

class StoreChangeRequestDTO
{
    private SIN $sin;
    private OfferChangerequestTyp $crType;
    private string $bemerkungen;

    /**
     * StoreChangeRequestDTO constructor.
     * @param SIN $sin
     * @param OfferChangerequestTyp|object $crType
     * @param string $bemerkungen
     */
    public function __construct(SIN $sin, OfferChangerequestTyp $crType, string $bemerkungen)
    {
        $this->sin = $sin;
        $this->crType = $crType;
        $this->bemerkungen = $bemerkungen;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return OfferChangerequestTyp
     */
    public function getCrType(): OfferChangerequestTyp
    {
        return $this->crType;
    }

    /**
     * @return string
     */
    public function getBemerkungen(): string
    {
        return $this->bemerkungen;
    }
}
