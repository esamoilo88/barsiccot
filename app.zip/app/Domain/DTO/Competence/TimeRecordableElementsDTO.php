<?php


namespace App\Domain\DTO\Competence;


use DateTime;
use Symfony\Component\Serializer\Annotation\SerializedName;

class TimeRecordableElementsDTO
{

    protected int $projectCode;
    protected string $name;
    protected int $allocationCode;
    protected int $positionCode;
    protected bool $isFixedPrice;
    protected ?float $pricePerHour;
    protected ?int $laborMinutes;
    //                TODO 'Y-m-d\TH:i:s\Z'
    protected ?DateTime $endDate;

    /**
     * TimeRecordableElementsDTO constructor.
     * @param int $projectCode
     * @param string $name
     * @param int $allocationCode
     * @param int $positionCode
     * @param bool $isFixedPrice
     * @param float|null $pricePerHour
     * @param int|null $laborMinutes
     * @param DateTime|null $endDate
     */
    public function __construct(
        int $projectCode,
        string $name,
        int $allocationCode,
        int $positionCode,
        bool $isFixedPrice,
        ?float $pricePerHour,
        ?int $laborMinutes,
        ?DateTime $endDate
    )
    {
        $this->projectCode = $projectCode;
        $this->name = $name;
        $this->allocationCode = $allocationCode;
        $this->positionCode = $positionCode;
        $this->isFixedPrice = $isFixedPrice;
        $this->pricePerHour = $pricePerHour;
        $this->laborMinutes = $laborMinutes;
        $this->endDate = $endDate;
    }

    /**
     * @param int|null $laborMinutes
     */
    public function setLaborMinutes(?int $laborMinutes): void
    {
        $this->laborMinutes = $laborMinutes;
    }

    /**
     * @return int
     *
     * @SerializedName("PositionCode")
     */
    public function getPositionCode(): int
    {
        return $this->positionCode;
    }

    /**
     * @return DateTime|null
     *
     * @SerializedName("EndDate")
     */
    public function getEndDate(): ?DateTime
    {
        return $this->endDate;
    }

    /**
     * @return int
     *
     * @SerializedName("ProjectCode")
     */
    public function getProjectCode(): int
    {
        return $this->projectCode;
    }

    /**
     * @return string
     *
     * @SerializedName("Name")
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return int
     *
     * @SerializedName("AllocationCode")
     */
    public function getAllocationCode(): int
    {
        return $this->allocationCode;
    }

    /**
     * @return int|null
     *
     * @SerializedName("LaborMinutes")
     */
    public function getLaborMinutes(): ?int
    {
        return $this->laborMinutes;
    }

    /**
     * @return float|null
     *
     * @SerializedName("PricePerHour")
     */
    public function getPricePerHour(): ?float
    {
        return $this->pricePerHour;
    }

    /**
     * @return bool
     *
     * @SerializedName("IsFixedPrice")
     */
    public function isFixedPrice(): bool
    {
        return $this->isFixedPrice;
    }
}
