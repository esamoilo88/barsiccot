<?php


namespace App\Domain\DTO\Competence;


use Symfony\Component\Serializer\Annotation\SerializedName;

class CreateUpdateProjectDTO
{
    protected string $projectCode;
    protected string $planningType;
    protected string $projectName;
    protected string $statusId;
    protected ?string $location;
    protected float $budget;
    protected string $opportunityStageName;
    protected string $startDate;
    protected ?string $endDate;
    protected array $customProperties;
    protected ?string $description;
    protected ?CreateUpdateProjectCustomerDTO $customer;
    protected string $projectId;
    protected ?int $customerId;

    /**
     * CreateUpdateProjectDTO constructor.
     * @param string $planningType
     * @param string $projectCode
     * @param string $projectName
     * @param string $statusId
     * @param string|null $location
     * @param float $budget
     * @param string $opportunityStageName
     * @param string $startDate
     * @param string $endDate
     * @param array $customProperties
     * @param string|null $description
     * @param CreateUpdateProjectCustomerDTO|null $customer
     * @param string $projectId
     * @param int|null $customerId
     */
    public function __construct(
        string $planningType,
        string $projectCode,
        string $projectName,
        string $statusId,
        ?string $location,
        float $budget,
        string $opportunityStageName,
        string $startDate,
        ?string $endDate,
        array $customProperties = [],
        ?string $description = null,
        ?CreateUpdateProjectCustomerDTO $customer = null,
        string $projectId = '0',
        ?int $customerId = null
    )
    {
        $this->planningType = $planningType;
        $this->projectCode = $projectCode;
        $this->projectName = $projectName;
        $this->statusId = $statusId;
        $this->location = $location;
        $this->budget = $budget;
        $this->opportunityStageName = $opportunityStageName;
        $this->startDate = $startDate;
        $this->endDate = $endDate;
        $this->customProperties = $customProperties;
        $this->description = $description;
        $this->customer = $customer;
        $this->projectId = $projectId;
        $this->customerId = $customerId;
    }

    /**
     * @return string
     *
     * @SerializedName("ProjectName")
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return float
     *
     * @SerializedName("Budget")
     */
    public function getBudget(): float
    {
        return $this->budget;
    }

    /**
     * @return string
     *
     * @SerializedName("Description")
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @return CreateUpdateProjectCustomerDTO|null
     *
     * @SerializedName("Customer")
     */
    public function getCustomer(): ?CreateUpdateProjectCustomerDTO
    {
        return $this->customer;
    }

    /**
     * @return string
     *
     * @SerializedName("EndDate")
     */
    public function getEndDate(): ?string
    {
        return $this->endDate;
    }

    /**
     * @return string
     *
     * @SerializedName("Location")
     */
    public function getLocation(): ?string
    {
        return $this->location;
    }

    /**
     * @return string
     *
     * @SerializedName("OpportunityStageName")
     */
    public function getOpportunityStageName(): string
    {
        return $this->opportunityStageName;
    }

    /**
     * @return string
     *
     * @SerializedName("ProjectCode")
     */
    public function getProjectCode(): string
    {
        return $this->projectCode;
    }

    /**
     * @return string
     *
     * @SerializedName("StartDate")
     */
    public function getStartDate(): string
    {
        return $this->startDate;
    }

    /**
     * @return string
     *
     * @SerializedName("StatusID")
     */
    public function getStatusId(): string
    {
        return $this->statusId;
    }

    /**
     * @return string
     *
     * @SerializedName("ProjectID")
     */
    public function getProjectId(): string
    {
        return $this->projectId;
    }

    /**
     * @param CreateUpdateProjectCustomerDTO|null $customer
     */
    public function setCustomer(?CreateUpdateProjectCustomerDTO $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @param string $projectId
     */
    public function setProjectId(string $projectId): void
    {
        $this->projectId = $projectId;
    }

    /**
     * @return string
     *
     * @SerializedName("PlanningType")
     */
    public function getPlanningType(): string
    {
        return $this->planningType;
    }

    /**
     * @return int|null
     *
     * @SerializedName("CustomerID")
     */
    public function getCustomerId(): ?int
    {
        return $this->customerId;
    }

    /**
     * @param int|null $customerId
     */
    public function setCustomerId(?int $customerId): void
    {
        $this->customerId = $customerId;
    }

    /**
     * @return array
     *
     * @SerializedName("CustomProperties")
     */
    public function getCustomProperties(): array
    {
        return $this->customProperties;
    }
}
