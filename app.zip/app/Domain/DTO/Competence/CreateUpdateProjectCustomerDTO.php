<?php


namespace App\Domain\DTO\Competence;


use Symfony\Component\Serializer\Annotation\SerializedName;

class CreateUpdateProjectCustomerDTO
{
    protected string $customerName;
    protected int $referenceCode;
    protected int $crmCustomerCode;

    /**
     * CreateUpdateProjectCustomerDTO constructor.
     * @param string $customerName
     * @param int $referenceCode
     * @param int $crmCustomerCode
     */
    public function __construct(
        string $customerName,
        int $referenceCode,
        int $crmCustomerCode
    )
    {
        $this->customerName = $customerName;
        $this->referenceCode = $referenceCode;
        $this->crmCustomerCode = $crmCustomerCode;
    }

    /**
     * @return string
     *
     * @SerializedName("CustomerName")
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @return int
     *
     * @SerializedName("CrmCustomerCode")
     */
    public function getCrmCustomerCode(): int
    {
        return $this->crmCustomerCode;
    }

    /**
     * @return int
     *
     * @SerializedName("ReferenceCode")
     */
    public function getReferenceCode(): int
    {
        return $this->referenceCode;
    }
}
