<?php


namespace App\Domain\DTO\ZDF;


use App\Domain\Entities\BackendBenutzer;
use App\Domain\ValueObjects\SIN;

class ZdfSimpleStatusDTO
{
    protected SIN $sin;
    protected BackendBenutzer $user;
    protected ?string $reason;
    protected ?string $email;
    protected array $attachments;

    /**
     * ZdfSimpleStatusDTO constructor.
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @param string|null $reason
     * @param string|null $email
     * @param array $attachments
     */
    public function __construct(SIN $sin, BackendBenutzer $user, ?string $reason = null, ?string $email = null, array $attachments = [])
    {
        $this->sin = $sin;
        $this->user = $user;
        $this->reason = $reason;
        $this->email = $email;
        $this->attachments = $attachments;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return string|null
     */
    public function getReason(): ?string
    {
        return $this->reason;
    }

    /**
     * @return string|null
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @return array
     */
    public function getAttachments(): array
    {
        return $this->attachments;
    }
}
