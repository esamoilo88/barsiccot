<?php


namespace App\Domain\DTO\ZDF;


use Exception;

class ZdfExceptionMailDTO
{
    protected int $zdfId;
    protected string $message;
    protected int $code;
    protected string $trace;

    /**
     * ZdfExceptionMailDTO constructor.
     * @param int $zdfId
     * @param string $message
     * @param int $code
     * @param string $trace
     */
    public function __construct(int $zdfId, string $message, int $code, string $trace)
    {
        $this->zdfId = $zdfId;
        $this->message = $message;
        $this->code = $code;
        $this->trace = $trace;
    }

    /**
     * @return int
     */
    public function getZdfId(): int
    {
        return $this->zdfId;
    }

    /**
     * @return string
     */
    public function getMessage(): string
    {
        return $this->message;
    }

    /**
     * @return int
     */
    public function getCode(): int
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getTrace(): string
    {
        return $this->trace;
    }


}
