<?php


namespace App\Domain\DTO\ZDF;


use App\Domain\ValueObjects\SIN;

class ZdfNewSimpleMailDTO
{
    protected SIN $sin;
    protected int $zdfId;

    /**
     * ZdfNewSimpleMailDTO constructor.
     * @param SIN $sin
     * @param int $zdfId
     */
    public function __construct(SIN $sin, int $zdfId)
    {
        $this->sin = $sin;
        $this->zdfId = $zdfId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getZdfId(): int
    {
        return $this->zdfId;
    }


}
