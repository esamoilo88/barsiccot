<?php


namespace App\Domain\DTO\ZDF;


use App\Domain\ValueObjects\SIN;

class ZdfStatusUpdateMailDTO
{
    protected SIN $sin;
    protected int $zdfId;
    protected string $simplestatus;
    protected string $versionsnr;
    protected string $auftragsbezeichnung;
    protected ?string $kundenname;
    protected string $serviceConsultant;

    /**
     * ZdfStatusUpdateMailDTO constructor.
     * @param SIN $sin
     * @param int $zdfId
     * @param string $simplestatus
     * @param string $versionsnr
     * @param string $auftragsbezeichnung
     * @param string|null $kundenname
     * @param string $serviceConsultant
     */
    public function __construct(SIN $sin, int $zdfId, string $simplestatus, string $versionsnr, string $auftragsbezeichnung, ?string $kundenname, string $serviceConsultant)
    {
        $this->sin = $sin;
        $this->zdfId = $zdfId;
        $this->simplestatus = $simplestatus;
        $this->versionsnr = $versionsnr;
        $this->auftragsbezeichnung = $auftragsbezeichnung;
        $this->kundenname = $kundenname;
        $this->serviceConsultant = $serviceConsultant;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return "in ZDF | SIN/{$this->sin->value()} V.{$this->versionsnr}; {$this->auftragsbezeichnung}; {$this->kundenname}";
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getZdfId(): int
    {
        return $this->zdfId;
    }

    /**
     * @return string
     */
    public function getSimplestatus(): string
    {
        return $this->simplestatus;
    }

    /**
     * @return string
     */
    public function getVersionsnr(): string
    {
        return $this->versionsnr;
    }

    /**
     * @return string
     */
    public function getAuftragsbezeichnung(): string
    {
        return $this->auftragsbezeichnung;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string
     */
    public function getServiceConsultant(): string
    {
        return $this->serviceConsultant;
    }

}
