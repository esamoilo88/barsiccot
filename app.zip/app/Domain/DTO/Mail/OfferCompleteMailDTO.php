<?php

namespace App\Domain\DTO\Mail;

use App\Components\Formatter\Formatter;
use App\Domain\Signatures\DateFormat\DateFormatSignature;
use DateTime;

class OfferCompleteMailDTO
{
    private string $subject;
    private string $simpleId;
    private string $projectName;
    private string $customerName;
    private float $totalPrice;
    private float $totalCost;
    private float $margeEff;
    private DateTime $validTo;

    /**
     * OfferCompleteMailDTO constructor.
     * @param string $subject
     * @param string $simpleId
     * @param string $projectName
     * @param string $customerName
     * @param float $totalPrice
     * @param float $totalCost
     * @param float $margeEff
     * @param DateTime $validTo
     */
    public function __construct(
        string $subject,
        string $simpleId,
        string $projectName,
        string $customerName,
        float $totalPrice,
        float $totalCost,
        float $margeEff,
        DateTime $validTo
    )
    {
        $this->subject = $subject;
        $this->simpleId = $simpleId;
        $this->projectName = $projectName;
        $this->customerName = $customerName;
        $this->totalPrice = $totalPrice;
        $this->totalCost = $totalCost;
        $this->margeEff = $margeEff;
        $this->validTo = $validTo;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }

    /**
     * @return string
     */
    public function getSimpleId(): string
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return string
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @return string
     */
    public function getTotalPrice(): string
    {
        return Formatter::numberToString($this->totalPrice, 2, true);
    }

    /**
     * @return string
     */
    public function getTotalCost(): string
    {
        return Formatter::numberToString($this->totalCost, 2, true);
    }

    /**
     * @return string
     */
    public function getMargeEff(): string
    {
        return Formatter::numberToString($this->margeEff);
    }

    /**
     * @return string
     */
    public function getValidTo(): string
    {
        return Formatter::dateToString(
            $this->validTo,
            DateFormatSignature::dateDMYWithHoursAndMinutes()
        );
    }
}