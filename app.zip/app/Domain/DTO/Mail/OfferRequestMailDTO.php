<?php

namespace App\Domain\DTO\Mail;

use App\Domain\ValueObjects\SIN;

class OfferRequestMailDTO
{
    private string $thema;
    private SIN $sin;
    private string $lieferterminAngebot;
    private ?string $kundenname;
    private ?int $kundennummer;
    private ?string $kundenstandort;
    private ?string $vorhabenbeschreibung;
    private ?string $PRODCBezeichnung;
    private ?string $VSAGBezeichnung;
    private ?string $volumenDtts;
    private ?string $auftragswahrscheinlichkeit;
    private string $aemonat;
    private ?string $VKRRegion;
    private ?string $phone;
    private string $absender;
    private string $nachricht;
    private string $status;


    /**
     * OfferRequestMailDTO constructor.
     * @param string $thema
     * @param SIN $sin
     * @param string $lieferterminAngebot
     * @param string|null $kundenname
     * @param int|null $kundennummer
     * @param string|null $kundenstandort
     * @param string|null $vorhabenbeschreibung
     * @param string|null $PRODCBezeichnung
     * @param string|null $VSAGBezeichnung
     * @param string|null $volumenDtts
     * @param string|null $auftragswahrscheinlichkeit
     * @param string $aemonat
     * @param string|null $VKRRegion
     * @param string|null $phone
     * @param string $absender
     * @param string $nachricht
     * @param string $status
     */
    public function __construct(
        string $thema,
        SIN $sin,
        string $lieferterminAngebot,
        ?string $kundenname,
        ?int $kundennummer,
        ?string $kundenstandort,
        ?string $vorhabenbeschreibung,
        ?string $PRODCBezeichnung,
        ?string $VSAGBezeichnung,
        ?string $volumenDtts,
        ?string $auftragswahrscheinlichkeit,
        string $aemonat,
        ?string $VKRRegion,
        ?string $phone,
        string $absender,
        string $nachricht,
        string $status
    )
    {
        $this->thema = $thema;
        $this->sin = $sin;
        $this->lieferterminAngebot = $lieferterminAngebot;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->kundenstandort = $kundenstandort;
        $this->vorhabenbeschreibung = $vorhabenbeschreibung;
        $this->PRODCBezeichnung = $PRODCBezeichnung;
        $this->VSAGBezeichnung = $VSAGBezeichnung;
        $this->volumenDtts = $volumenDtts;
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
        $this->aemonat = $aemonat;
        $this->VKRRegion = $VKRRegion;
        $this->phone = $phone;
        $this->absender = $absender;
        $this->nachricht = $nachricht;
        $this->status = $status;

    }

    /**
     * @return string
     */
    public function getThema(): string
    {
        return $this->thema;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getLieferterminAngebot(): string
    {
        return $this->lieferterminAngebot;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return int|null
     */
    public function getKundennummer(): ?int
    {
        return $this->kundennummer;
    }

    /**
     * @return string|null
     */
    public function getKundenstandort(): ?string
    {
        return $this->kundenstandort;
    }

    /**
     * @return string|null
     */
    public function getVorhabenbeschreibung(): ?string
    {
        return $this->vorhabenbeschreibung;
    }

    /**
     * @return string|null
     */
    public function getPRODCBezeichnung(): ?string
    {
        return $this->PRODCBezeichnung;
    }

    /**
     * @return string|null
     */
    public function getVSAGBezeichnung(): ?string
    {
        return $this->VSAGBezeichnung;
    }

    /**
     * @return string|null
     */
    public function getVolumenDtts(): ?string
    {
        return $this->volumenDtts;
    }

    /**
     * @return string|null
     */
    public function getAuftragswahrscheinlichkeit(): ?string
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @return string
     */
    public function getAemonat(): string
    {
        return $this->aemonat;
    }

    /**
     * @return string|null
     */
    public function getVKRRegion(): ?string
    {
        return $this->VKRRegion;
    }

    /**
     * @return string|null
     */
    public function getPhone(): ?string
    {
        return $this->phone;
    }

    /**
     * @return string
     */
    public function getAbsender(): string
    {
        return $this->absender;
    }

    /**
     * @return string
     */
    public function getNachricht(): string
    {
        return $this->nachricht;
    }

    /**
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * @return bool
     */
    public function hasPhone(): bool
    {
        return $this->phone !== null;
    }
}
