<?php

namespace App\Domain\DTO\Mail;

use App\Domain\ValueObjects\SIN;

class AutomailTransferDTO
{
    private array $to;
    private string $subject;
    private bool $isStore;
    private string $message;
    private array $cc;
    private int $priority;
    private ?SIN $sin;

    /**
     * AutomailTransferDTO constructor.
     * @param array $to
     * @param string $subject
     * @param bool $isStore
     * @param string $message
     * @param array $cc
     * @param int $priority
     * @param SIN|null $sin
     */
    public function __construct(
        array $to,
        string $subject,
        bool $isStore,
        string $message,
        array $cc,
        int $priority,
        ?SIN $sin
    )
    {
        $this->to = $to;
        $this->isStore = $isStore;
        $this->subject = $subject;
        $this->sin = $sin;
        $this->cc = $cc;
        $this->message = $message;
        $this->priority = $priority;
    }

    /**
     * @return array
     */
    public function to(): array
    {
        return $this->to;
    }

    /**
     * @return SIN|null
     */
    public function sin(): ?SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function subject(): string
    {
        return $this->subject;
    }

    /**
     * @return array
     */
    public function cc(): array
    {
        return $this->cc;
    }

    /**
     * @return int
     */
    public function priority(): int
    {
        return $this->priority;
    }

    /**
     * @return bool
     */
    public function hasCc(): bool
    {
        return $this->cc !== [];
    }

    /**
     * @return bool
     */
    public function hasPriority(): bool
    {
        return $this->priority !== null;
    }

    /**
     * @return bool
     */
    public function isStore(): bool
    {
        return $this->isStore;
    }

    /**
     * @return string
     */
    public function message(): string
    {
        return $this->message;
    }
}
