<?php

namespace App\Domain\DTO\Mail;

use App\Domain\ValueObjects\SIN;

class OfferAssignMailDTO
{
    private string $projectName;
    private SIN $sin;
    private string $customerName;
    private string $salutation;
    private string $emailSalutation;
    private string $fromEmail;
    private string $subject;

    /**
     * OfferAssignMail constructor.
     * @param string $projectName
     * @param SIN $sin
     * @param string $customerName
     * @param string $salutation
     * @param string $emailSalutation
     * @param string $fromEmail
     * @param string $subject
     */
    public function __construct(
        string $projectName,
        SIN $sin,
        string $customerName,
        string $salutation,
        string $emailSalutation,
        string $fromEmail,
        string $subject
    )
    {
        $this->projectName = $projectName;
        $this->sin = $sin;
        $this->customerName = $customerName;
        $this->salutation = $salutation;
        $this->emailSalutation = $emailSalutation;
        $this->fromEmail = $fromEmail;
        $this->subject = $subject;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @return string
     */
    public function getSalutation(): string
    {
        return $this->salutation;
    }

    /**
     * @return string
     */
    public function getEmailSalutation(): string
    {
        return $this->emailSalutation;
    }

    /**
     * @return string
     */
    public function getFromEmail(): string
    {
        return $this->fromEmail;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }

}