<?php


namespace App\Domain\DTO\Mail;

use App\Components\Formatter\Formatter;
use App\Domain\Entities\SalesStammdaten;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class InfoDepartmentDTO
{
    private string $subject;
    private string $simpleId;
    private int $betrag;
    private string $vorhabenname;
    private ?string $kundenname;
    private ?string $kundennummer;
    private string $leistungszeitraum;


    /**
     * InfoDepartmentDTO constructor.
     * @param string $subject
     * @param int $simpleId
     * @param int $betrag
     * @param string $vorhabenname
     * @param string|null $kundenname
     * @param string|null $kundennummer
     * @param string $leistungszeitraum
     */
    public function __construct(
        string $subject,
        int $simpleId,
        int $betrag,
        string $vorhabenname,
        ?string $kundenname,
        ?string $kundennummer,
        string $leistungszeitraum
    )
    {
        $this->subject = $subject;
        $this->simpleId = $simpleId;
        $this->betrag = $betrag;
        $this->vorhabenname = $vorhabenname;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->leistungszeitraum = $leistungszeitraum;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }

    /**
     * @return string
     */
    public function getSimpleId(): string
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getVorhabenname(): string
    {
        return $this->vorhabenname;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string|null
     */
    public function getKundennummer(): ?string
    {
        return $this->kundennummer;
    }

    /**
     * @return string
     */
    public function getTotalPrice(): string
    {
        return Formatter::numberToString($this->betrag, 2, true);
    }

    public function getLeistungszeitraum():string
    {
        return $this->leistungszeitraum;
    }
}
