<?php

namespace App\Domain\DTO\Mail;

use App\Domain\Signatures\MailPriority\MailPrioritySignature;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\ObjectPropertyIsNotSetException;
use Illuminate\Mail\Mailable;

class MailDTO
{
    protected Mailable $mailable;
    protected array $to;
    protected string $subject;
    protected ?array $cc;
    protected ?array $bcc;
    protected ?array $attachments;
    protected ?MailPrioritySignature $priority;

    /**
     * MailTransferDTO constructor.
     * @param Mailable $mailable
     * @param array $to
     * @param string $subject
     * @param array|null $cc
     * @param array|null $bcc
     * @param array|null $attachments
     * @param MailPrioritySignature|null $priority
     */
    public function __construct(
        Mailable $mailable,
        array $to,
        string $subject,
        ?array $cc = null,
        ?array $bcc = null,
        ?array $attachments = null,
        ?MailPrioritySignature $priority = null
    )
    {
        $this->mailable = $mailable;
        $this->to = $to;
        $this->subject = $subject;
        $this->cc = $cc;
        $this->bcc = $bcc;
        $this->attachments = $attachments;
        $this->priority = $priority;
    }

    /**
     * @return Mailable
     */
    public function mailable(): Mailable
    {
        return $this->mailable;
    }

    /**
     * @return array
     */
    public function to(): array
    {
        return $this->to;
    }

    /**
     * @return string
     */
    public function subject(): string
    {
        return $this->subject;
    }

    /**
     * @return array
     * @throws ObjectPropertyIsNotSetException
     */
    public function cc(): array
    {
        if (! $this->cc) {
            throw new ObjectPropertyIsNotSetException('cc', self::class);
        }
        return $this->cc;
    }

    /**
     * @return array
     * @throws ObjectPropertyIsNotSetException
     */
    public function bcc(): array
    {
        if (! $this->bcc) {
            throw new ObjectPropertyIsNotSetException('bcc', self::class);
        }
        return $this->bcc;
    }

    /**
     * @return array|null
     * @throws ObjectPropertyIsNotSetException
     */
    public function attachments(): array
    {
        if (! $this->attachments) {
            throw new ObjectPropertyIsNotSetException('attachments', self::class);
        }
        return $this->attachments;
    }

    /**
     * @return MailPrioritySignature
     * @throws ObjectPropertyIsNotSetException
     */
    public function priority(): MailPrioritySignature
    {
        if (! $this->priority) {
            throw new ObjectPropertyIsNotSetException('priority', self::class);
        }
        return $this->priority;
    }

    /**
     * @return bool
     */
    public function hasCc(): bool
    {
        return $this->cc !== null;
    }

    /**
     * @return bool
     */
    public function hasBcc(): bool
    {
        return $this->bcc !== null;
    }

    /**
     * @return bool
     */
    public function hasAttachments(): bool
    {
        return $this->attachments !== null;
    }

    /**
     * @return bool
     */
    public function hasPriority(): bool
    {
        return $this->priority !== null;
    }
}
