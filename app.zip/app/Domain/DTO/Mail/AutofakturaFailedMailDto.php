<?php

namespace App\Domain\DTO\Mail;

class AutofakturaFailedMailDto
{
    private int $simpleId;
    private string $kundenname;
    private string $kundennummer;
    private string $vorhabenname;
    private string $error;
    private string $event;
    private array $errorsByLbu;
    private string $subject;

    /**
     * AutofakturaFailedMailDto constructor.
     * @param int $simpleId
     * @param string $kundenname
     * @param string $kundennummer
     * @param string $vorhabenname
     * @param string $event
     * @param array $errorsByLbu
     * @param string $subject
     */
    public function __construct(
        int $simpleId,
        string $kundenname,
        string $kundennummer,
        string $vorhabenname,
        string $event,
        array $errorsByLbu,
        string $subject
    )
    {
        $this->simpleId = $simpleId;
        $this->kundenname = $kundenname;
        $this->kundennummer = $kundennummer;
        $this->vorhabenname = $vorhabenname;
        $this->event = $event;
        $this->errorsByLbu = $errorsByLbu;
        $this->subject = $subject;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getKundenname(): string
    {
        return $this->kundenname;
    }

    /**
     * @return string
     */
    public function getKundennummer(): string
    {
        return $this->kundennummer;
    }

    /**
     * @return string
     */
    public function getVorhabenname(): string
    {
        return $this->vorhabenname;
    }

    /**
     * @return string
     */
    public function getError(): string
    {
        return $this->error;
    }

    /**
     * @return string
     */
    public function getEvent(): string
    {
        return $this->event;
    }

    /**
     * @return array
     */
    public function getErrorsByLbu(): array
    {
        return $this->errorsByLbu;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }
}