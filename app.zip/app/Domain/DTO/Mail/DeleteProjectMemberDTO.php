<?php

namespace App\Domain\DTO\Mail;

class DeleteProjectMemberDTO
{
    protected string $fullName;
    protected int $simpleId;
    protected string $thema;
    protected string $kundenname;
    protected string $status;
    protected string $role;
    protected bool $representative;
    protected string $deleter;

    /**
     * DeleteProjectMemberDTO constructor.
     * @param string $fullName
     * @param int $simpleId
     * @param string $thema
     * @param string $kundenname
     * @param string $status
     * @param string $role
     * @param bool $representative
     * @param string $deleter
     */
    public function __construct(string $fullName, int $simpleId, string $thema, string $kundenname, string $status, string $role, bool $representative, string $deleter)
    {
        $this->fullName = $fullName;
        $this->simpleId = $simpleId;
        $this->thema = $thema;
        $this->kundenname = $kundenname;
        $this->status = $status;
        $this->role = $role;
        $this->representative = $representative;
        $this->deleter = $deleter;
    }

    /**
     * @return string
     */
    public function getFullName(): string
    {
        return $this->fullName;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getThema(): string
    {
        return $this->thema;
    }

    /**
     * @return string
     */
    public function getKundenname(): string
    {
        return $this->kundenname;
    }

    /**
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * @return string
     */
    public function getRole(): string
    {
        return $this->role;
    }

    /**
     * @return bool
     */
    public function isRepresentative(): bool
    {
        return $this->representative;
    }

    /**
     * @return string
     */
    public function getDeleter(): string
    {
        return $this->deleter;
    }
}
