<?php


namespace App\Domain\DTO\Mail;


class CancelProjectDTO
{
    private int $simpleId;
    private string $projectName;
    private string $clientName;
    private string $statusName;
    private string $reason;
    private string $description;
    private ?string $seceitProcessNumber;
    private string $userName;

    public function __construct(
        int $simpleId,
        string $projectName,
        string $clientName,
        string $statusName,
        string $reason,
        string $description,
        ?string $seceitProcessNumber,
        string $userName
    )
    {
        $this->simpleId = $simpleId;
        $this->projectName = $projectName;
        $this->clientName = $clientName;
        $this->statusName = $statusName;
        $this->reason = $reason;
        $this->description = $description;
        $this->seceitProcessNumber = $seceitProcessNumber;
        $this->userName = $userName;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return string
     */
    public function getClientName(): string
    {
        return $this->clientName;
    }

    /**
     * @return string
     */
    public function getStatusName(): string
    {
        return $this->statusName;
    }

    /**
     * @return string
     */
    public function getReason(): string
    {
        return $this->reason;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return string|null
     */
    public function getSeceitProcessNumber(): ?string
    {
        return $this->seceitProcessNumber;
    }

    /**
     * @return string
     */
    public function getUserName(): string
    {
        return $this->userName;
    }
}
