<?php

namespace App\Domain\DTO\Mail;

use App\Domain\Signatures\MailPriority\MailPrioritySignature;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\ObjectPropertyIsNotSetException;
use Illuminate\Mail\Mailable;

class MailTransferDTO extends MailDTO
{
    private SIN $sin;

    /**
     * MailTransferDTO constructor.
     * @param Mailable $mailable
     * @param array $to
     * @param SIN $sin
     * @param string $subject
     * @param array|null $cc
     * @param array|null $bcc
     * @param array|null $attachments
     * @param MailPrioritySignature|null $priority
     */
    public function __construct(
        Mailable $mailable,
        array $to,
        SIN $sin,
        string $subject,
        ?array $cc = null,
        ?array $bcc = null,
        ?array $attachments = null,
        ?MailPrioritySignature $priority = null
    )
    {
        $this->mailable = $mailable;
        $this->to = $to;
        $this->subject = $subject;
        $this->sin = $sin;
        $this->cc = $cc;
        $this->bcc = $bcc;
        $this->attachments = $attachments;
        $this->priority = $priority;
    }

    /**
     * @return SIN
     */
    public function sin(): SIN
    {
        return $this->sin;
    }
}
