<?php

namespace App\Domain\DTO\Mail;

class OrderCreateMailDTO
{
    private int $sin;
    private string $anrede;
    private int $versionsNr;
    private ?string $kundenname;
    private ?string $angebotsersteller;
    private ?string $auftragsbezeichnung;
    private bool $isPreorder;
    private string $subject;
    private string $templateMail;

    /**
     * OrderCreateMailDTO constructor.
     * @param int $sin
     * @param string $anrede
     * @param int $versionsNr
     * @param string|null $kundenname
     * @param string|null $angebotsersteller
     * @param string|null $auftragsbezeichnung
     * @param string $templateMail
     * @param bool $isPreorder
     * @param string $subject
     */
    public function __construct(
        int $sin,
        string $anrede,
        int $versionsNr,
        ?string $kundenname,
        ?string $angebotsersteller,
        ?string $auftragsbezeichnung,
        string $templateMail,
        bool $isPreorder,
        string $subject
    )
    {
        $this->sin = $sin;
        $this->anrede = $anrede;
        $this->versionsNr = $versionsNr;
        $this->kundenname = $kundenname;
        $this->angebotsersteller = $angebotsersteller;
        $this->auftragsbezeichnung = $auftragsbezeichnung;
        $this->templateMail = $templateMail;
        $this->isPreorder = $isPreorder;
        $this->subject = $subject;
    }

    /**
     * @return int
     */
    public function getSin(): int
    {
        return $this->sin;
    }

    /**
     * @return bool
     */
    public function isPreorder(): bool
    {
        return $this->isPreorder;

    }

    /**
     * @return string
     */
    public function getAnrede(): string
    {
        return $this->anrede;
    }

    /**
     * @return int
     */
    public function getVersionsNr(): int
    {
        return $this->versionsNr;
    }

    /**
     * @return string
     */
    public function templateMail(): string
    {
        return $this->templateMail;
    }

    /**
     * @return string|null
     */
    public function getAuftragsbezeichnung(): ?string
    {
        return $this->auftragsbezeichnung;
    }

    /**
     * @return string|null
     */
    public function getKundenname(): ?string
    {
        return $this->kundenname;
    }

    /**
     * @return string|null
     */
    public function getAngebotsersteller(): ?string
    {
        return $this->angebotsersteller;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }


}
