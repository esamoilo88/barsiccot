<?php

namespace App\Domain\DTO\User;

use App\Exceptions\Application\ObjectPropertyIsNotSetException;

class UserSearchDTO
{
    private array $roles;
    private string $surname;
    private ?string $name;

    /**
     * UserSearchDTO constructor.
     * @param array $roles
     * @param string $query
     */
    public function __construct(array $roles, string $query)
    {
        $this->roles = $roles;
        $this->setProperties($query);
    }

    /**
     * @return array
     */
    public function getRoles(): array
    {
        return $this->roles;
    }

    /**
     * @return string
     */
    public function getSurname(): string
    {
        return $this->surname;
    }

    /**
     * @return bool
     */
    public function hasName(): bool
    {
        return $this->name !== null;
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getName(): string
    {
        if ($this->name === null) {
            throw new ObjectPropertyIsNotSetException('name', self::class);
        }
        return $this->name;
    }

    /**
     * @return bool
     */
    public function hasRoles(): bool
    {
        return $this->roles !== [];
    }

    /**
     * @param string $query
     */
    private function setProperties(string $query)
    {
        if(str_contains($query, ',')) {
            $search = explode(',', $query);

            $this->surname = trim($search[0]);

            if(strlen(trim($search[1])) !== 0) {
                $this->name = trim($search[1]);
            } else {
                $this->name = null;
            }
        } else {
            $this->surname = $query;
            $this->name = null;
        }
    }
}