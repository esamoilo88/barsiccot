<?php

namespace App\Domain\DTO\Offer;


use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\SalesAnfrage;
use App\Domain\Entities\SalesAngebotTp;
use App\Domain\Entities\SalesStammdaten;

class CreateSalesVersionierungDTO
{
    private SalesStammdaten $simple;
    private ?SalesAnfrage $afVersions;
    private ?SalesAngebotTp $tpVersions;
    private ?OfferAngebotVk $vkVersions;


    /**
     * CreateSalesVersionierungDTO constructor.
     * @param SalesStammdaten $simple
     * @param SalesAnfrage|null $afVersions
     * @param SalesAngebotTp|null $tpVersions
     * @param OfferAngebotVk|null $vkVersions
     */
    public function __construct(
        SalesStammdaten $simple,
        ?SalesAnfrage $afVersions = null,
        ?SalesAngebotTp $tpVersions = null,
        ?OfferAngebotVk $vkVersions = null
    )
    {
        $this->simple = $simple;
        $this->afVersions = $afVersions;
        $this->tpVersions = $tpVersions;
        $this->vkVersions = $vkVersions;
    }

    /**
     * @return SalesStammdaten
     */
    public function simple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return SalesAnfrage
     */
    public function afVersions(): SalesAnfrage
    {
        return $this->afVersions;
    }

    /**
     * @return SalesAngebotTp
     */
    public function tpVersions(): SalesAngebotTp
    {
        return $this->tpVersions;
    }

    /**
     * @return OfferAngebotVk
     */
    public function vkVersions(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @return bool
     */
    public function hasVkVersions(): bool
    {
        return $this->vkVersions !== null;
    }

    /**
     * @return bool
     */
    public function hasTpVersions(): bool
    {
        return $this->tpVersions !== null;
    }

    /**
     * @return bool
     */
    public function hasAfVersions(): bool
    {
        return $this->afVersions !== null;
    }


}
