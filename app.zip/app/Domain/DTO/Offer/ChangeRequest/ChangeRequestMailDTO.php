<?php


namespace App\Domain\DTO\Offer\ChangeRequest;


use App\Domain\ValueObjects\SIN;

class ChangeRequestMailDTO
{
    private SIN $sin;
    private string $projectName;
    private string $customerName;
    private ?string $crGrund;
    private string $vertragsbeginn;
    private string $vertragsende;
    private ?string $rolloutbeginn;
    private ?string $rolloutende;
    private ?string $betriebsbeginn;
    private ?string $betriebsende;
    private ?string $totalCostsAfter;
    private ?string $totalCostsBefore;
    private ?string $totalPriceAfter;
    private ?string $totalPriceBefore;
    private string $isUpdatedForecast;
    private string $thema;
    private string $kundenname;

    /**
     * ChangeRequestMailDTO constructor.
     * @param SIN $sin
     * @param string $projectName
     * @param string $customerName
     * @param ?string $crGrund
     * @param string $vertragsbeginn
     * @param string $vertragsende
     * @param ?string $rolloutbeginn
     * @param ?string $rolloutende
     * @param ?string $betriebsbeginn
     * @param ?string $betriebsende
     * @param string|null $totalCostsAfter
     * @param string|null $totalCostsBefore
     * @param string|null $totalPriceAfter
     * @param string|null $totalPriceBefore
     * @param string $isUpdatedForecast
     * @param string $thema
     * @param string $kundenname
     */
    public function __construct(
        SIN $sin,
        string $projectName,
        string $customerName,
        ?string $crGrund,
        string $vertragsbeginn,
        string $vertragsende,
        ?string $rolloutbeginn,
        ?string $rolloutende,
        ?string $betriebsbeginn,
        ?string $betriebsende,
        ?string $totalCostsAfter,
        ?string $totalCostsBefore,
        ?string $totalPriceAfter,
        ?string $totalPriceBefore,
        string $isUpdatedForecast,
        string $thema,
        string $kundenname
    )
    {
        $this->sin = $sin;
        $this->projectName = $projectName;
        $this->customerName = $customerName;
        $this->crGrund = $crGrund;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
        $this->totalCostsAfter = $totalCostsAfter;
        $this->totalCostsBefore = $totalCostsBefore;
        $this->totalPriceAfter = $totalPriceAfter;
        $this->totalPriceBefore = $totalPriceBefore;
        $this->isUpdatedForecast = $isUpdatedForecast;
        $this->thema = $thema;
        $this->kundenname = $kundenname;
    }

    /**
     * @return string|null
     */
    public function getTotalCostsBefore(): ?string
    {
        return $this->totalCostsBefore;
    }

    /**
     * @return string|null
     */
    public function getTotalCostsAfter(): ?string
    {
        return $this->totalCostsAfter;
    }

    /**
     * @return string|null
     */
    public function getTotalPriceBefore(): ?string
    {
        return $this->totalPriceBefore;
    }

    /**
     * @return string|null
     */
    public function getTotalPriceAfter(): ?string
    {
        return $this->totalPriceAfter;
    }

    /**
     * @return string
     */
    public function getVertragsende(): string
    {
        return $this->vertragsende;
    }

    /**
     * @return string
     */
    public function getVertragsbeginn(): string
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return string|null
     */
    public function getRolloutende(): ?string
    {
        return $this->rolloutende;
    }

    /**
     * @return string|null
     */
    public function getRolloutbeginn(): ?string
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return string|null
     */
    public function getBetriebsende(): ?string
    {
        return $this->betriebsende;
    }

    /**
     * @return string|null
     */
    public function getBetriebsbeginn(): ?string
    {
        return $this->betriebsbeginn;
    }
    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string|null
     */
    public function getCrGrund(): ?string
    {
        return $this->crGrund;
    }

    /**
     * @return string
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @return string
     */
    public function getIsUpdatedForecast(): string
    {
        return $this->isUpdatedForecast;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return string
     */
    public function getThema(): string
    {
        return $this->thema;
    }

    /**
     * @return string
     */
    public function getKundenname(): string
    {
        return $this->kundenname;
    }
}
