<?php


namespace App\Domain\DTO\Offer\ChangeRequest;


use App\Domain\ValueObjects\SIN;
use DateTime;

class ChangeRequestDTO
{
    protected SIN $sin;

    protected int $crId;
    protected int $crTyp;
    protected ?string $grund;

//    SalesAnfrage
    protected DateTime $vertragsbeginn;
    protected DateTime $vertragsende;
    protected ?DateTime $rolloutbeginn;
    protected ?DateTime $rolloutende;
    protected ?DateTime $betriebsbeginn;
    protected ?DateTime $betriebsende;

    protected array $apIds;

    protected ChangeRequestFilesDTO $files;

    protected bool $forecastUpdate;

    /**
     * ChangeRequestDTO constructor.
     * @param SIN $sin
     * @param int $crId
     * @param int $crTyp
     * @param string|null $grund
     * @param DateTime $vertragsbeginn
     * @param DateTime $vertragsende
     * @param ?DateTime $rolloutbeginn
     * @param ?DateTime $rolloutende
     * @param ?DateTime $betriebsbeginn
     * @param ?DateTime $betriebsende
     * @param array $apIds
     * @param ChangeRequestFilesDTO $files
     * @param bool $forecastUpdate
     */
    public function __construct(
        SIN $sin,
        int $crId,
        int $crTyp,
        ?string $grund,
        DateTime $vertragsbeginn,
        DateTime $vertragsende,
        ?DateTime $rolloutbeginn,
        ?DateTime $rolloutende,
        ?DateTime $betriebsbeginn,
        ?DateTime $betriebsende,
        array $apIds,
        ChangeRequestFilesDTO $files,
        bool $forecastUpdate
    )
    {
        $this->sin = $sin;
        $this->crId = $crId;
        $this->crTyp = $crTyp;
        $this->grund = $grund;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
        $this->apIds = $apIds;
        $this->files = $files;
        $this->forecastUpdate = $forecastUpdate;
    }

    /**
     * @return int
     */
    public function getCrTyp(): int
    {
        return $this->crTyp;
    }

    /**
     * @return array
     */
    public function getApIds(): array
    {
        return $this->apIds;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsbeginn(): ?DateTime
    {
        return $this->betriebsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsende(): ?DateTime
    {
        return $this->betriebsende;
    }

    /**
     * @return ChangeRequestFilesDTO
     */
    public function getFiles(): ChangeRequestFilesDTO
    {
        return $this->files;
    }

    /**
     * @return string|null
     */
    public function getGrund(): ?string
    {
        return $this->grund;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutbeginn(): ?DateTime
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutende(): ?DateTime
    {
        return $this->rolloutende;
    }

    /**
     * @return DateTime
     */
    public function getVertragsbeginn(): DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime
     */
    public function getVertragsende(): DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return bool
     */
    public function isForecastUpdate(): bool
    {
        return $this->forecastUpdate;
    }

    /**
     * @return int
     */
    public function getCrId(): int
    {
        return $this->crId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }
}
