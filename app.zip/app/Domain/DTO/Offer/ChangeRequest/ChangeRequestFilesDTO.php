<?php


namespace App\Domain\DTO\Offer\ChangeRequest;


use App\Domain\ValueObjects\UploadedFile;

class ChangeRequestFilesDTO
{
    protected ?UploadedFile $changeRequest = null;
    protected ?UploadedFile $angebot = null;
    protected ?UploadedFile $kalkulation = null;
    protected ?UploadedFile $beauftragung = null;

    /**
     * ChangeRequestFilesDTO constructor.
     * @param UploadedFile|null $changeRequest
     * @param UploadedFile|null $angebot
     * @param UploadedFile|null $kalkulation
     * @param UploadedFile|null $beauftragung
     */
    public function __construct(
        ?UploadedFile $changeRequest = null,
        ?UploadedFile $angebot = null,
        ?UploadedFile $kalkulation = null,
        ?UploadedFile $beauftragung = null
    )
    {
        $this->changeRequest = $changeRequest;
        $this->angebot = $angebot;
        $this->kalkulation = $kalkulation;
        $this->beauftragung = $beauftragung;
    }

    /**
     * @return UploadedFile|null
     */
    public function getKalkulation(): ?UploadedFile
    {
        return $this->kalkulation;
    }

    /**
     * @return UploadedFile|null
     */
    public function getChangeRequest(): ?UploadedFile
    {
        return $this->changeRequest;
    }

    /**
     * @return UploadedFile|null
     */
    public function getBeauftragung(): ?UploadedFile
    {
        return $this->beauftragung;
    }

    /**
     * @return UploadedFile|null
     */
    public function getAngebot(): ?UploadedFile
    {
        return $this->angebot;
    }
}
