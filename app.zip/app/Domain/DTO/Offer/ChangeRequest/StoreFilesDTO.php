<?php


namespace App\Domain\DTO\Offer\ChangeRequest;


use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\SalesAngebotTp;
use App\Domain\ValueObjects\SIN;

class StoreFilesDTO
{
    private SIN $sin;
    private int $crVersionsNr;
    private string $status;
    private OfferAngebotVk $offerAngebotVK;
    private ChangeRequestFilesDTO $files;

    /**
     * StoreFilesDTO constructor.
     * @param SIN $sin
     * @param int $crVersionsNr
     * @param string $status
     * @param OfferAngebotVk $offerAngebotVK
     * @param ChangeRequestFilesDTO $files
     */
    public function __construct(
        SIN $sin,
        int $crVersionsNr,
        string $status,
        OfferAngebotVk $offerAngebotVK,
        ChangeRequestFilesDTO $files
    )
    {
        $this->sin = $sin;
        $this->crVersionsNr = $crVersionsNr;
        $this->status = $status;
        $this->offerAngebotVK = $offerAngebotVK;
        $this->files = $files;
    }

    /**
     * @return ChangeRequestFilesDTO
     */
    public function getFiles(): ChangeRequestFilesDTO
    {
        return $this->files;
    }

    /**
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getCrVersionsNr(): int
    {
        return $this->crVersionsNr;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getOfferAngebotVK(): OfferAngebotVk
    {
        return $this->offerAngebotVK;
    }

}
