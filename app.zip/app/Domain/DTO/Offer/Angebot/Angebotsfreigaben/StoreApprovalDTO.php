<?php

namespace App\Domain\DTO\Offer\Angebot\Angebotsfreigaben;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\OnkaApproval;
use App\Domain\Entities\SalesVersionierung;

class StoreApprovalDTO
{
    private SalesVersionierung $simple;
    private OfferAngebotVk $vkVersion;
    private OnkaApproval $approvalId;
    private ?BackendBenutzer $requestByUser;
    private ?BackendBenutzer $requestFromUser;
    private ?\DateTime $requestedAt;
    private ?bool $setTKRole;
    private ?bool $sendEmail;
    private ?string $reqFromMail;

    /**
     * StoreApprovalDTO constructor.
     * @param SalesVersionierung $simple
     * @param OfferAngebotVk $vkVersion
     * @param OnkaApproval $approvalId
     * @param BackendBenutzer|null $requestByUser
     * @param BackendBenutzer|null $requestFromUser
     * @param \DateTime|null $requestedAt
     * @param bool|null $setTKRole
     * @param bool|null $sendEmail
     */
    public function __construct(
        SalesVersionierung $simple,
        OfferAngebotVk $vkVersion,
        OnkaApproval $approvalId,
        ?BackendBenutzer $requestFromUser,
        ?BackendBenutzer $requestByUser,
        ?\DateTime $requestedAt,
        ?bool $setTKRole = false,
        ?bool $sendEmail = true,
        ?string $reqFromMail = null
    )
    {
        $this->simple = $simple;
        $this->vkVersion = $vkVersion;
        $this->approvalId = $approvalId;
        $this->requestFromUser = $requestFromUser;
        $this->requestByUser = $requestByUser;
        $this->requestedAt = $requestedAt;
        $this->setTKRole = $setTKRole;
        $this->sendEmail = $sendEmail;
        $this->reqFromMail = $reqFromMail;
    }

    /**
     * @return SalesVersionierung
     */
    public function getSimple(): SalesVersionierung
    {
        return $this->simple;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersion(): OfferAngebotVk
    {
        return $this->vkVersion;
    }

    /**
     * @return OnkaApproval
     */
    public function getApprovalId(): OnkaApproval
    {
        return $this->approvalId;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getRequestByUser(): ?BackendBenutzer
    {
        return $this->requestByUser;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getRequestFromUser(): ?BackendBenutzer
    {
        return $this->requestFromUser;
    }

    /**
     * @return string|null
     */
    public function getName(): ?string
    {
        return ($this->getRequestFromUser()) ? $this->getRequestFromUser()->getNachname() : null;
    }

    /**
     * @return string|null
     */
    public function getVorname(): ?string
    {
        return ($this->getRequestFromUser()) ? $this->getRequestFromUser()->getVorname() : null;
    }

    /**
     * @return string|null
     */
    public function getEmailSalutation(): ?string
    {
        return ($this->getRequestFromUser()) ? $this->getRequestFromUser()->getEmailSalutation() : 'Hallo';
    }

    /**
     * @return string|null
     */
    public function getEmail(): ?string
    {
        return ($this->getRequestFromUser()) ? $this->getRequestFromUser()->getEmail() : $this->getReqFromMail();
    }

    /**
     * @return bool|null
     */
    public function getSetTKRole(): ?bool
    {
        return $this->setTKRole;
    }

    /**
     * @return bool|null
     */
    public function getSendEmail(): ?bool
    {
        return $this->sendEmail;
    }

    /**
     * @return \DateTime|null
     */
    public function getRequestedAt(): ?\DateTime
    {
        return $this->requestedAt;
    }

    /**
     * @return string|null
     */
    public function getReqFromMail(): ?string
    {
        return $this->reqFromMail;
    }
}
