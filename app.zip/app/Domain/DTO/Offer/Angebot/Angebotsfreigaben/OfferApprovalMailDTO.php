<?php

namespace App\Domain\DTO\Offer\Angebot\Angebotsfreigaben;

use App\Domain\ValueObjects\SIN;

class OfferApprovalMailDTO
{
    private SIN $sin;
    private string $projectName;
    private string $customerName;
    private string $name;
    private ?string $vorname;
    private ?string $nachname;
    private string $salutation;
    private ?string $fromEmail;
    private string $subject;

    /**
     * OfferApprovalMailDTO constructor.
     * @param SIN $sin
     * @param string $projectName
     * @param string $customerName
     * @param string $name
     * @param string|null $vorname
     * @param string|null $nachname
     * @param string $salutation
     * @param string|null $fromEmail
     * @param string $subject
     */
    public function __construct(
        SIN $sin,
        string $projectName,
        string $customerName,
        string $name,
        ?string $vorname,
        ?string $nachname,
        string $salutation,
        ?string $fromEmail,
        string $subject
)
    {
        $this->sin = $sin;
        $this->projectName = $projectName;
        $this->customerName = $customerName;
        $this->name = $name;
        $this->vorname = $vorname;
        $this->nachname = $nachname;
        $this->salutation = $salutation;
        $this->fromEmail = $fromEmail;
        $this->subject =$subject;
    }

    /**
     * @return string
     */
    public function getProjectName(): string
    {
        return $this->projectName;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string|null
     */
    public function getVorname(): ?string
    {
        return $this->vorname;
    }

    /**
     * @return string|null
     */
    public function getNachname(): ?string
    {
        return $this->nachname;
    }

    /**
     * @return string
     */
    public function getSalutation(): string
    {
        return $this->salutation;
    }

    /**
     * @return string|null
     */
    public function getFromEmail(): ?string
    {
        return $this->fromEmail;
    }

    /**
     * @return string
     */
    public function getSubject(): string
    {
        return $this->subject;
    }
}
