<?php

namespace App\Domain\DTO\Offer\Approvals;

use App\Domain\ValueObjects\SIN;

class ConfirmDeclineApprovalDTO
{
    private SIN $sin;
    private int $vkVersionId;
    private int $approvalId;
    private bool $result;
    private ?string $comment;
    private bool $withEmail;

    /**
     * ConfirmDeclineApprovalDTO constructor.
     * @param  SIN  $sin
     * @param  int  $vkVersionId
     * @param  int  $approvalId
     * @param  bool  $result
     * @param  string|null  $comment
     * @param  bool  $withEmail
     */
    public function __construct(
        SIN $sin,
        int $vkVersionId,
        int $approvalId,
        bool $result,
        ?string $comment,
        bool $withEmail
    ) {
        $this->sin = $sin;
        $this->vkVersionId = $vkVersionId;
        $this->approvalId = $approvalId;
        $this->result = $result;
        $this->comment = $comment;
        $this->withEmail = $withEmail;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersionId(): int
    {
        return $this->vkVersionId;
    }

    /**
     * @return int
     */
    public function getApprovalId(): int
    {
        return $this->approvalId;
    }

    /**
     * @return string|null
     */
    public function getComment(): ?string
    {
        return $this->comment;
    }

    /**
     * @return bool
     */
    public function isWithEmail(): bool
    {
        return $this->withEmail;
    }

    /**
     * @return bool
     */
    public function getResult(): bool
    {
        return $this->result;
    }
}
