<?php

namespace App\Domain\DTO\Offer\Calculations\BER;

use App\Domain\ValueObjects\SIN;

class UpdateBERDTO
{
    private SIN $sin;
    private int $berId;
    private array $fields;

    /**
     * UpdateBERDTO constructor.
     * @param  SIN  $sin
     * @param  int  $berId
     * @param  array  $fields
     */
    public function __construct(SIN $sin, int $berId, array $fields) {
        $this->sin = $sin;
        $this->berId = $berId;
        $this->fields = $fields;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getBerId(): int
    {
        return $this->berId;
    }

    /**
     * @return array
     */
    public function getFields(): array
    {
        return $this->fields;
    }
}
