<?php

namespace App\Domain\DTO\Offer\Calculations\BER;

use App\Domain\Entities\OfferKalkulationVariable;
use App\Domain\ValueObjects\SIN;

class StoreBERDTO
{
    private SIN $sin;
    private string $bezeichnung;
    private string $operator;
    private ?OfferKalkulationVariable $variable;
    private float $wert;
    private ?string $kommentar;
    private string $objectsType;
    private array $objects;

    /**
     * StoreBERDTO constructor.
     * @param  SIN  $sin
     * @param  string  $bezeichnung
     * @param  string  $operator
     * @param  OfferKalkulationVariable|object|null  $variable
     * @param  float  $wert
     * @param  string|null  $kommentar
     * @param  string  $objectsType
     * @param  array  $objects
     */
    public function __construct(
        SIN $sin,
        string $bezeichnung,
        string $operator,
        ?OfferKalkulationVariable $variable,
        float $wert,
        ?string $kommentar,
        string $objectsType,
        array $objects
    )
    {
        $this->sin = $sin;
        $this->bezeichnung = $bezeichnung;
        $this->operator = $operator;
        $this->variable = $variable;
        $this->wert = $wert;
        $this->kommentar = $kommentar;
        $this->objectsType = $objectsType;
        $this->objects = $objects;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string
     */
    public function getOperator(): string
    {
        return $this->operator;
    }

    /**
     * @return OfferKalkulationVariable|null
     */
    public function getVariable(): ?OfferKalkulationVariable
    {
        return $this->variable;
    }

    /**
     * @return float
     */
    public function getWert(): float
    {
        return $this->wert;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return string
     */
    public function getObjectsType(): string
    {
        return $this->objectsType;
    }

    /**
     * @return array
     */
    public function getIds(): array
    {
        return $this->objects;
    }
}
