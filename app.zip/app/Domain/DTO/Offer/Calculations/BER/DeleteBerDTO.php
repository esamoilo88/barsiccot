<?php


namespace App\Domain\DTO\Offer\Calculations\BER;


use App\Domain\ValueObjects\SIN;

class DeleteBerDTO
{
    private SIN $sin;
    private int $vkVersionsId;
    private int $berId;

    /**
     * DeleteBerDTO constructor.
     * @param SIN $sin
     * @param int $vkVersionsId
     * @param int $berId
     */
    public function __construct(
        SIN $sin,
        int $vkVersionsId,
        int $berId
    )
    {
        $this->sin = $sin;
        $this->vkVersionsId = $vkVersionsId;
        $this->berId = $berId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @return int
     */
    public function getBerId(): int
    {
        return $this->berId;
    }
}
