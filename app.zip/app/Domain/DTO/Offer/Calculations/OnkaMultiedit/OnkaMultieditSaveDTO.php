<?php

namespace App\Domain\DTO\Offer\Calculations\OnkaMultiedit;

use App\Domain\Entities\OfferAngebotVk;

class OnkaMultieditSaveDTO
{
    private OfferAngebotVk $vkVersion;
    private string $object;
    private array $fields;
    private array $objectsList;

    /**
     * OnkaMultieditSaveDTO constructor.
     * @param  OfferAngebotVk|object  $vkVersion
     * @param  string  $object
     * @param  array  $fields
     * @param  array  $objectsList
     */
    public function __construct(OfferAngebotVk $vkVersion, string $object, array $fields, array $objectsList)
    {
        $this->vkVersion = $vkVersion;
        $this->object = $object;
        $this->fields = $fields;
        $this->objectsList = $objectsList;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersion(): OfferAngebotVk
    {
        return $this->vkVersion;
    }

    /**
     * @return string
     */
    public function getObject(): string
    {
        return $this->object;
    }

    /**
     * @return array
     */
    public function getFields(): array
    {
        return $this->fields;
    }

    /**
     * @return array
     */
    public function getIds(): array
    {
        return $this->objectsList;
    }
}
