<?php

namespace App\Domain\DTO\Offer\Calculations\EL;

use App\Domain\ValueObjects\SIN;

class UpdateElementDTO
{
    private SIN $sin;
    private int $elementId;
    private array $fields;

    /**
     * UpdateElementDTO constructor.
     * @param  SIN  $sin
     * @param  int  $elementId
     * @param  array  $fields
     */
    public function __construct(SIN $sin, int $elementId, array $fields) {
        $this->sin = $sin;
        $this->elementId = $elementId;
        $this->fields = $fields;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getElementId(): int
    {
        return $this->elementId;
    }

    /**
     * @return array
     */
    public function getFields(): array
    {
        return $this->fields;
    }

}
