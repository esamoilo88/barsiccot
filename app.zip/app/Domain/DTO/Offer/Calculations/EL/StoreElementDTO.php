<?php

namespace App\Domain\DTO\Offer\Calculations\EL;

use App\Domain\ValueObjects\SIN;

class StoreElementDTO
{
    private SIN $sin;
    private string $bezeichnung;
    private int $kostenart;
    private ?bool $berechnungsart;
    private float $stundensatz;
    private float $gmkz;
    private ?float $wert;
    private bool $ma;
    private ?bool $ifApply;
    private ?int $kostenstelle;
    private ?string $beschreibung;
    private array $lps;
    private ?string $zeitstunden;

    /**
     * OfferAssignDTO constructor.
     * @param SIN $sin
     * @param string $bezeichnung
     * @param int $kostenart
     * @param bool|null $berechnungsart
     * @param float $stundensatz
     * @param float $gmkz
     * @param float|null $wert
     * @param bool $ma
     * @param bool|null $ifApply
     * @param int|null $kostenstelle
     * @param string|null $beschreibung
     * @param array $lps
     * @param string|null $zeistungen
     */
    public function __construct(
        SIN $sin,
        string $bezeichnung,
        int $kostenart,
        ?bool $berechnungsart,
        float $stundensatz,
        float $gmkz,
        ?float $wert,
        bool $ma,
        ?bool $ifApply,
        ?int $kostenstelle,
        ?string $beschreibung,
        array $lps,
        ?string $zeistungen
    ) {
        $this->sin = $sin;
        $this->bezeichnung = $bezeichnung;
        $this->kostenart = $kostenart;
        $this->berechnungsart = $berechnungsart;
        $this->stundensatz = $stundensatz;
        $this->gmkz = $gmkz;
        $this->wert = $wert;
        $this->ma = $ma;
        $this->ifApply = $ifApply;
        $this->kostenstelle = $kostenstelle;
        $this->beschreibung = $beschreibung;
        $this->lps = $lps;
        $this->zeitstunden = $zeistungen;;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getBezeichnung(): string
    {
        return $this->bezeichnung;
    }

    /**
     * @return int
     */
    public function getKostenart(): int
    {
        return $this->kostenart;
    }

    /**
     * @return bool|null
     */
    public function getBerechnungsart(): ?bool
    {
        return $this->berechnungsart;
    }

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return float
     */
    public function getGmkz(): float
    {
        return $this->gmkz;
    }

    /**
     * @return float|null
     */
    public function getWert(): ?float
    {
        return $this->wert;
    }

    /**
     * @return bool
     */
    public function getMa(): bool
    {
        return $this->ma;
    }

    /**
     * @return bool|null
     */
    public function getIfApply(): ?bool
    {
        return $this->ifApply;
    }

    /**
     * @return int|null
     */
    public function getKostenstelle(): ?int
    {
        return $this->kostenstelle;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return array
     */
    public function getLps(): array
    {
        return $this->lps;
    }

    /**
     * @return string|null
     */
    public function getZeitstunden(): ?string
    {
        return $this->zeitstunden;
    }
}
