<?php


namespace App\Domain\DTO\Offer\Calculations\LP;


use App\Domain\ValueObjects\SIN;

class DeleteLpDTO
{
    private SIN $sin;
    private int $vkVersionsId;
    private int $lpId;

    /**
     * DeleteLpDTO constructor.
     * @param SIN $sin
     * @param int $vkVersionsId
     * @param int $lpId
     */
    public function __construct(
        SIN $sin,
        int $vkVersionsId,
        int $lpId
    )
    {
        $this->sin = $sin;
        $this->vkVersionsId = $vkVersionsId;
        $this->lpId = $lpId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @return int
     */
    public function getLpId(): int
    {
        return $this->lpId;
    }
}
