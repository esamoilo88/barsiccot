<?php

namespace App\Domain\DTO\Offer\Calculations\LP;

use App\Components\Formatter\Formatter;
use App\Domain\ValueObjects\SIN;

class StoreLpDTO
{
    private SIN $sin;
    private string $name;
    private string $leistungstyp;
    private bool $nachAufwand;
    private bool $indirekteKosten;
    private array $aps;
    private ?string $description;
    private ?int $serviceLevelId;
    private ?float $inflationsfaktorRessourcen;
    private ?float $inflationsfaktorKosten;
    private ?float $annuitatZinssatz;
    private ?int $annuitatLaufzeit;
    private ?float $annuitatKWert;
    private ?float $menge;

    /**
     * StoreLpDTO constructor.
     * @param SIN $sin
     * @param string $name
     * @param string $leistungstyp
     * @param bool $nachAufwand
     * @param bool $indirekteKosten
     * @param array $aps
     * @param string|null $description
     * @param int|null $serviceLevelId
     * @param string|null $inflationsfaktorRessourcen
     * @param string|null $inflationsfaktorKosten
     * @param string|null $annuitatZinssatz
     * @param int|null $annuitatLaufzeit
     * @param string|null $annuitatKWert
     * @param float|null $menge
     */
    public function __construct(
        SIN $sin,
        string $name,
        string $leistungstyp,
        bool $nachAufwand,
        bool $indirekteKosten,
        array $aps,
        ?string $description,
        ?int $serviceLevelId,
        ?string $inflationsfaktorRessourcen,
        ?string $inflationsfaktorKosten,
        ?string $annuitatZinssatz,
        ?int $annuitatLaufzeit,
        ?string $annuitatKWert,
        ?float $menge = null
    )
    {
        $this->sin = $sin;
        $this->name = $name;
        $this->leistungstyp = $leistungstyp;
        $this->description = $description;
        $this->nachAufwand = $nachAufwand;
        $this->indirekteKosten = $indirekteKosten;
        $this->aps = $aps;
        $this->serviceLevelId = $serviceLevelId;
        $this->inflationsfaktorRessourcen = $inflationsfaktorRessourcen ? $this->formatString($inflationsfaktorRessourcen): null;
        $this->inflationsfaktorKosten = $inflationsfaktorKosten ? $this->formatString($inflationsfaktorKosten): null;
        $this->annuitatZinssatz = $annuitatZinssatz ? $this->formatString($annuitatZinssatz): null;
        $this->annuitatLaufzeit = $annuitatLaufzeit ? $this->formatString($annuitatLaufzeit): null;
        $this->annuitatKWert = $annuitatKWert ? $this->formatString($annuitatKWert): null;
        $this->menge = $menge;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getLeistungstyp(): string
    {
        return $this->leistungstyp;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @return bool
     */
    public function isNachAufwand(): bool
    {
        return $this->nachAufwand;
    }

    /**
     * @return bool
     */
    public function isIndirekteKosten(): bool
    {
        return $this->indirekteKosten;
    }

    /**
     * @return array
     */
    public function getAps(): array
    {
        return $this->aps;
    }

    /**
     * @return int|null
     */
    public function getServiceLevelId(): ?int
    {
        return $this->serviceLevelId;
    }

    /**
     * @return float|null
     */
    public function getInflationsfaktorRessourcen(): ?float
    {
        return $this->inflationsfaktorRessourcen;
    }

    /**
     * @return float|null
     */
    public function getInflationsfaktorKosten(): ?float
    {
        return $this->inflationsfaktorKosten;
    }

    /**
     * @return float|null
     */
    public function getAnnuitatZinssatz(): ?float
    {
        return $this->annuitatZinssatz;
    }

    /**
     * @return int|null
     */
    public function getAnnuitatLaufzeit(): ?int
    {
        return $this->annuitatLaufzeit;
    }

    /**
     * @return float|null
     */
    public function getAnnuitatKWert(): ?float
    {
        return $this->annuitatKWert;
    }

    /**
     * @return bool
     */
    public function hasServiceLevel(): bool
    {
        return $this->serviceLevelId !== null;
    }

    /**
     * @param string $toFormat
     * @return float
     */
    private function formatString(string $toFormat): float
    {
        return Formatter::stringToNumber($toFormat);
    }

    /**
     * @return array
     */
    public function getApsIds(): array
    {
        return array_column($this->getAps(), 'id');
    }

    /**
     * @return float|null
     */
    public function getMenge(): ?float
    {
        return $this->menge;
    }
}
