<?php

namespace App\Domain\DTO\Offer\Calculations\LP;

class CopyLpDTO
{
    private array $aps;

    /**
     * CopyLpDTO constructor.
     * @param array $aps
     */
    public function __construct(array $aps)
    {
        $this->aps = $aps;
    }

    /**
     * @return array
     */
    public function getAps(): array
    {
        return $this->aps;
    }

    /**
     * @return array
     */
    public function getApsIds(): array
    {
        return array_column($this->getAps(), 'id');
    }
}
