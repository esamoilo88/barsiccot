<?php

namespace App\Domain\DTO\Offer\Calculations;

use App\Domain\ValueObjects\SIN;
use App\Services\ONKA\RecalcService;

class RecalcDTO
{
    private SIN $sin;
    private int $vkVersionsId;
    private array $ids;
    private string $objectType;

    /**
     * MultiDeleteDTO constructor.
     * @param SIN $sin
     * @param int $vkVersionsId
     * @param array $ids
     * @param string $objectType
     */
    public function __construct(SIN $sin, int $vkVersionsId, array $ids, string $objectType)
    {
        $this->sin = $sin;
        $this->vkVersionsId = $vkVersionsId;
        $this->ids = $ids;
        $this->objectType = $objectType;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @return array
     */
    public function getIds(): array
    {
        return array_unique($this->ids);
    }

    /**
     * @return string
     */
    public function getObjectType(): string
    {
        return $this->objectType;
    }
}
