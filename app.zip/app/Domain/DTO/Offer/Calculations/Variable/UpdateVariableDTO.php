<?php

namespace App\Domain\DTO\Offer\Calculations\Variable;

use App\Domain\Entities\SalesStammdaten;

class UpdateVariableDTO
{
    private int $variableId;
    private SalesStammdaten $simple;
    private ?string $bezeichnung;
    private string $wert;


    /**
     * UpdateVariableDTO constructor.
     * @param int $variableId
     * @param SalesStammdaten $simple
     * @param string|null $bezeichnung
     * @param string $wert
     */
    public function __construct(
        int $variableId,
        SalesStammdaten $simple,
        ?string $bezeichnung,
        string $wert
    )
    {
        $this->variableId = $variableId;
        $this->simple = $simple;
        $this->bezeichnung = $bezeichnung;
        $this->wert = $wert;
    }

    /**
     * @return int
     */
    public function getVariableId(): int
    {
        return $this->variableId;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return string
     */
    public function getWert(): string
    {
        return $this->wert;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }
}
