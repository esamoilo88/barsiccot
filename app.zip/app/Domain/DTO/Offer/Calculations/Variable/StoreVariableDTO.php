<?php

namespace App\Domain\DTO\Offer\Calculations\Variable;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\SalesStammdaten;

class StoreVariableDTO
{
    private SalesStammdaten $simple;
    private ?OfferAngebotVk $versionId;
    private ?string $bezeichnung;
    private string $wert;
    private bool $sum;
    private BackendBenutzer $benutzerId;

    /**
     * StoreVariableDTO constructor.
     * @param SalesStammdaten $simple
     * @param OfferAngebotVk|null $versionId
     * @param string|null $bezeichnung
     * @param string $wert
     * @param bool $sum
     * @param BackendBenutzer $benutzerId
     */
    public function __construct(
        SalesStammdaten $simple,
        ?OfferAngebotVk $versionId,
        ?string $bezeichnung,
        string $wert,
        bool $sum,
        BackendBenutzer $benutzerId
    )
    {
        $this->simple = $simple;
        $this->versionId = $versionId;
        $this->bezeichnung = $bezeichnung;
        $this->wert = $wert;
        $this->sum = $sum;
        $this->benutzerId = $benutzerId;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSimple(): SalesStammdaten
    {
        return $this->simple;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string
     */
    public function getWert(): string
    {
        return $this->wert;
    }

    /**
     * @return OfferAngebotVk|null
     */
    public function getVersionId(): ?OfferAngebotVk
    {
        return $this->versionId;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzerId(): BackendBenutzer
    {
        return $this->benutzerId;
    }

    /**
     * @return bool
     */
    public function getSum(): bool
    {
        return $this->sum;
    }

    /**
     * @return bool
     */
    public function hasVersionId(): bool
    {
        return $this->versionId !== null;
    }

}
