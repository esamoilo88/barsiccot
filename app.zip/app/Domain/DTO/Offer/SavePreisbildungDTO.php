<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;
use DateTime;

class SavePreisbildungDTO
{
    private SIN $sin;
    private ?float $marge;
    private ?float $gmkz;
    private ?DateTime $vertragsbeginn;
    private ?DateTime $vertragsende;
    private bool $budgetangebot;
    private bool $ausschreibung;

    /**
     * SavePreisbildungDTO constructor.
     * @param float|null $marge
     * @param float|null $gmkz
     * @param DateTime|null $vertragsbeginn
     * @param DateTime|null $vertragsende
     * @param bool $budgetangebot
     * @param bool $ausschreibung
     */
    public function __construct(
        SIN $sin,
        bool $budgetangebot,
        bool $ausschreibung,
        ?float $marge,
        ?float $gmkz,
        ?DateTime $vertragsbeginn,
        ?DateTime $vertragsende
    )
    {
        $this->sin = $sin;
        $this->marge = $marge;
        $this->gmkz = $gmkz;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->budgetangebot = $budgetangebot;
        $this->ausschreibung = $ausschreibung;
    }

    /**
     * @return float|null
     */
    public function getMarge(): ?float
    {
        return $this->marge;
    }

    /**
     * @return float|null
     */
    public function getGmkz(): ?float
    {
        return $this->gmkz;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsbeginn(): ?DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsende(): ?DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return bool
     */
    public function isBudgetangebot(): bool
    {
        return $this->budgetangebot;
    }

    /**
     * @return bool
     */
    public function isAusschreibung(): bool
    {
        return $this->ausschreibung;
    }

    /**
     * @return SIN
     */
    public function sin(): SIN
    {
        return $this->sin;
    }
}