<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;
use DateTime;

/**
 * Class CreateRequestDTO
 * @package App\Domain\DTO\Offer
 */
class CreateRequestDTO
{
    private SIN $simple;
    private ?DateTime $lieferterminAngebot;
    private ?DateTime $vertragsbeginn;
    private ?DateTime $vertragsende;
    private ?DateTime $rolloutbeginn;
    private ?DateTime $rolloutende;
    private ?DateTime $betriebsbeginn;
    private ?DateTime $betriebsende;
    private ?string $nachricht;
    private array $attachments;
    private ?array $emailCC;

    /**
     * CreateSalesAnfrageDTO constructor.
     * @param SIN $simple
     * @param DateTime|null $lieferterminAngebot
     * @param DateTime|null $vertragsbeginn
     * @param DateTime|null $vertragsende
     * @param DateTime|null $rolloutbeginn
     * @param DateTime|null $rolloutende
     * @param DateTime|null $betriebsbeginn
     * @param DateTime|null $betriebsende
     * @param string|null $nachricht
     * @param array $attachments
     * @param array|null $emailCC
     */
    public function __construct(
        SIN $simple,
        array $attachments,
        ?DateTime $lieferterminAngebot = null,
        ?DateTime $vertragsbeginn = null,
        ?DateTime $vertragsende = null,
        ?DateTime $rolloutbeginn = null,
        ?DateTime $rolloutende = null,
        ?DateTime $betriebsbeginn = null,
        ?DateTime $betriebsende = null,
        ?string $nachricht = null,
        ?array $emailCC = null
    )
    {
        $this->simple = $simple;
        $this->lieferterminAngebot = $lieferterminAngebot;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
        $this->nachricht = $nachricht;
        $this->attachments = $attachments;
        $this->emailCC = $emailCC;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->simple;
    }

    /**
     * @return DateTime
     */
    public function getLieferterminAngebot(): DateTime
    {
        return $this->lieferterminAngebot;
    }

    /**
     * @return DateTime
     */
    public function getVertragsbeginn(): ?DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime
     */
    public function getVertragsende(): ?DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return DateTime
     */
    public function getRolloutbeginn(): ?DateTime
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return DateTime
     */
    public function getRolloutende(): ?DateTime
    {
        return $this->rolloutende;
    }

    /**
     * @return DateTime
     */
    public function getBetriebsbeginn(): ?DateTime
    {
        return $this->betriebsbeginn;
    }

    /**
     * @return DateTime
     */
    public function getBetriebsende(): ?DateTime
    {
        return $this->betriebsende;
    }

    /**
     * @return string|null
     */
    public function getNachricht(): ?string
    {
        return $this->nachricht;
    }

    /**
     * @return array
     */
    public function getAttachments(): array
    {
        return $this->attachments;
    }

    /**
     * @return array
     */
    public function getEmailCC(): array
    {
        return $this->emailCC;
    }

    /**
     * @return bool
     */
    public function hasVertragsbeginn(): bool
    {
        return $this->vertragsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasVertragsende(): bool
    {
        return $this->vertragsende !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutbeginn(): bool
    {
        return $this->rolloutbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutende(): bool
    {
        return $this->rolloutende !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsende(): bool
    {
        return $this->betriebsende !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsbeginn(): bool
    {
        return $this->betriebsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasNachricht(): bool
    {
        return $this->nachricht !== null;
    }

    /**
     * @return bool
     */
    public function hasAttachments(): bool
    {
        return $this->attachments !== [];
    }

    /**
     * @return bool
     */
    public function hasEmailCC(): bool
    {
        return $this->emailCC !== null;
    }

    /**
     * @return bool
     */
    public function hasLieferterminAngebot(): bool
    {
        return $this->lieferterminAngebot !== null;
    }
}
