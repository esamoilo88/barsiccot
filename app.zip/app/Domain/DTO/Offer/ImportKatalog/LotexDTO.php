<?php


namespace App\Domain\DTO\Offer\ImportKatalog;

use App\Components\Formatter\Formatter;
use App\Domain\Entities\OfferKatalogLeistungsposition;

class LotexDTO
{
    private ?string $kostenartId;
    private ?array $result;
    private ?array $arrOnkaKostenarten;
    private ?int $leistungspositionId;
    private ?OfferKatalogLeistungsposition $arrDataKatalogLP;
    private ?string $artikelNr;
    private ?string $leistungerbringen;
    private bool $createEl;
    private ?int $menge;
    private ?string $bezeichnung;
    private ?string $config;

    /**
     * LotexDTO constructor.
     * @param array|null $result
     * @param array|null $arrOnkaKostenarten
     * @param int|null $leistungspositionId
     * @param OfferKatalogLeistungsposition|null $arrDataKatalogLP
     * @param string|null $artikelNr
     * @param string|null $leistungerbringen
     * @param bool $createEl
     * @param int|null $menge
     * @param string|null $bezeichnung
     * @param string|null $config
     */
    public function __construct(
        ?string $kostenartId,
        ?array $result,
        ?array $arrOnkaKostenarten,
        ?int $leistungspositionId,
        ?OfferKatalogLeistungsposition $arrDataKatalogLP,
        ?string $artikelNr,
        ?string $leistungerbringen = '',
        bool $createEl = false,
        ?int $menge = null,
        ?string $bezeichnung = '',
        ?string $config = ''
    )
    {
        $this->kostenartId = $kostenartId;
        $this->result = $result;
        $this->arrOnkaKostenarten = $arrOnkaKostenarten;
        $this->leistungspositionId = $leistungspositionId;
        $this->arrDataKatalogLP = $arrDataKatalogLP;
        $this->artikelNr = $artikelNr;
        $this->leistungerbringen = $leistungerbringen;
        $this->createEl = $createEl;
        $this->menge = $menge;
        $this->bezeichnung = $bezeichnung;
        $this->config = $config;
    }

    /**
     * @return string|null
     */
    public function getKostenartId(): ?string
    {
        return $this->kostenartId;
    }

    /**
     * @return array|null
     */
    public function getResult(): ?array
    {
        return $this->result;
    }

    /**
     * @return array|null
     */
    public function getArrOnkaKostenarten(): ?array
    {
        return $this->arrOnkaKostenarten;
    }

    /**
     * @return array|null
     */
    public function getKostenart(): ?array
    {
        return isset($this->getArrOnkaKostenarten()[$this->getConfig()]) ? $this->getArrOnkaKostenarten()[$this->getConfig()] : null;
    }

    /**
     * @return int|null
     */
    public function getLeistungspositionId(): ?int
    {
        return $this->leistungspositionId;
    }

    /**
     * @return OfferKatalogLeistungsposition|null
     */
    public function getArrDataKatalogLP(): ?OfferKatalogLeistungsposition
    {
        return $this->arrDataKatalogLP;
    }

    /**
     * @return string|null
     */
    public function getArtikelNr(): ?string
    {
        return $this->artikelNr;
    }

    /**
     * @return float|null
     */
    public function getLeistungerbringen(): ?float
    {
        return Formatter::stringToNumber($this->leistungerbringen);
    }

    /**
     * @return bool
     */
    public function isCreateEl(): bool
    {
        return $this->createEl;
    }

    /**
     * @return float|null
     */
    public function getVollkosten(): ?float
    {
        return round($this->getLeistungerbringen() * config('dbconfig.LOTEX.GMKZ'), 2) * $this->getMenge();
    }

    /**
     * @return int|null
     */
    public function getMenge(): ?int
    {
        return $this->menge;
    }

    /**
     * @return string|null
     */
    public function getBezeichnung(): ?string
    {
        return $this->bezeichnung;
    }

    /**
     * @return string|null
     */
    public function getConfig(): ?string
    {
        return $this->config;
    }
}
