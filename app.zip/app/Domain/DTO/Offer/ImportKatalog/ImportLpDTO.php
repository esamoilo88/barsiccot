<?php


namespace App\Domain\DTO\Offer\ImportKatalog;


use App\Domain\Entities\OfferKatalogLeistungsposition;
use App\Domain\ValueObjects\SIN;

class ImportLpDTO
{
    protected OfferKatalogLeistungsposition $lp;
    protected SIN $sin;
    protected int $vkVersionId;
    protected array $aps;

    /**
     * ImportLpDTO constructor.
     * @param OfferKatalogLeistungsposition $lp
     * @param SIN $sin
     * @param int $vkVersionId
     * @param array $aps
     */
    public function __construct(OfferKatalogLeistungsposition $lp, SIN $sin, int $vkVersionId, array $aps)
    {
        $this->lp = $lp;
        $this->sin = $sin;
        $this->vkVersionId = $vkVersionId;
        $this->aps = $aps;
    }

    /**
     * @return OfferKatalogLeistungsposition
     */
    public function getLp(): OfferKatalogLeistungsposition
    {
        return $this->lp;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersionId(): int
    {
        return $this->vkVersionId;
    }

    /**
     * @return array
     */
    public function getAps(): array
    {
        return $this->aps;
    }
}
