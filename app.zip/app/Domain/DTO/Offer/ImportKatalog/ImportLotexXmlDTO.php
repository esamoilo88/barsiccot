<?php


namespace App\Domain\DTO\Offer\ImportKatalog;

use Illuminate\Http\UploadedFile;

class ImportLotexXmlDTO
{
    private int $simpleId;
    private int $versionId;
    private ?UploadedFile $file;
    private ?array $options;
    private ?array $dataForDisplay;

    /**
     * ImportLotexXmlDTO constructor.
     * @param int $simpleId
     * @param int $versionId
     * @param UploadedFile|null $file
     * @param array|null $options
     * @param array|null $dataForDisplay
     */
    public function __construct(
        int $simpleId,
        int $versionId,
        ?UploadedFile $file,
        ?array $options = null,
        ?array $dataForDisplay = null
    )
    {
        $this->simpleId = $simpleId;
        $this->versionId = $versionId;
        $this->file = $file;
        $this->options = $options;
        $this->dataForDisplay =$dataForDisplay;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return int
     */
    public function getVersionId(): int
    {
        return $this->versionId;
    }

    /**
     * @return UploadedFile|null
     */
    public function getFile(): ?UploadedFile
    {
        return $this->file;
    }

    /**
     * @return array|null
     */
    public function getOptions(): ?array
    {
        return $this->options;
    }

    /**
     * @return array|null
     */
    public function getDataForDisplay(): ?array
    {
        return $this->dataForDisplay;
    }
}
