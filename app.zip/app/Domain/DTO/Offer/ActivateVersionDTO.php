<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;

class ActivateVersionDTO
{
    private SIN $sin;
    private int $versionId;

    /**
     * ActivateVersionDTO constructor.
     * @param SIN $sin
     * @param int $versionId
     */
    public function __construct(
        SIN $sin,
        int $versionId
    )
    {
        $this->sin = $sin;
        $this->versionId = $versionId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVersionId(): int
    {
        return $this->versionId;
    }
}
