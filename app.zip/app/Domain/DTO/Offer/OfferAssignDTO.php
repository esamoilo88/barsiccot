<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;

class OfferAssignDTO
{
    private SIN $sin;
    private int $userId;

    /**
     * OfferAssignDTO constructor.
     * @param SIN $sin
     * @param int $userId
     */
    public function __construct(SIN $sin, int $userId)
    {
        $this->sin = $sin;
        $this->userId = $userId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }
}