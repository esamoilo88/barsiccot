<?php


namespace App\Domain\DTO\Offer;


use App\Domain\ValueObjects\SIN;

class ManageApDTO
{
    private SIN $sin;
    private int $vkVersionsId;
    private int $producttypeId;
    private string $name;
    private int $quantity;
    private ?float $unitPrice;
    private ?float $marge;
    private ?float $preisfaktor;
    private ?string $beschreibung;
    private bool $fixedPrice;
    private bool $optional;
    private bool $deaktiviert;
    private bool $customPreisfaktor;
    private bool $customMarge;
    private ?int $sortBefore;
    private ?int $sortAfter;
    private bool $isChangeLpMenge;

    /**
     * ManageApDTO constructor.
     * @param SIN $sin
     * @param int $vkVersionsId
     * @param string $name
     * @param int $producttypeId
     * @param int $quantity
     * @param float|null $marge
     * @param float|null $preisfaktor
     * @param string|null $beschreibung
     * @param bool $fixedPrice
     * @param bool $optional
     * @param bool $deaktiviert
     * @param bool $customPreisfaktor
     * @param bool $customMarge
     * @param float|null $unitPrice
     * @param int|null $sortBefore
     * @param int|null $sortAfter
     * @param bool $isChangeLpMenge
     */
    public function __construct(
        SIN $sin,
        int $vkVersionsId,
        string $name,
        int $producttypeId,
        int $quantity,
        ?float $marge,
        ?float $preisfaktor,
        ?string $beschreibung,
        bool $fixedPrice,
        bool $optional,
        bool $deaktiviert,
        bool $customPreisfaktor,
        bool $customMarge,
        ?float $unitPrice,
        ?int $sortBefore,
        ?int $sortAfter,
        bool $isChangeLpMenge
    )
    {
        $this->sin = $sin;
        $this->vkVersionsId = $vkVersionsId;
        $this->name = $name;
        $this->producttypeId = $producttypeId;
        $this->quantity = $quantity;
        $this->marge = $marge;
        $this->preisfaktor = $preisfaktor;
        $this->beschreibung = $beschreibung;
        $this->fixedPrice = $fixedPrice;
        $this->optional = $optional;
        $this->deaktiviert = $deaktiviert;
        $this->customPreisfaktor = $customPreisfaktor;
        $this->customMarge = $customMarge;
        $this->unitPrice = $unitPrice;
        $this->sortBefore = $sortBefore;
        $this->sortAfter = $sortAfter;
        $this->isChangeLpMenge = $isChangeLpMenge;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return int
     */
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * @return float|null
     */
    public function getUnitPrice(): ?float
    {
        return $this->unitPrice;
    }

    /**
     * @return float|null
     */
    public function getMarge(): ?float
    {
        return $this->marge;
    }

    /**
     * @return float|null
     */
    public function getPreisfaktor(): ?float
    {
        return $this->preisfaktor;
    }

    /**
     * @return string|null
     */
    public function getBeschreibung(): ?string
    {
        return $this->beschreibung;
    }

    /**
     * @return bool
     */
    public function isFixedPrice(): bool
    {
        return $this->fixedPrice;
    }

    /**
     * @return bool
     */
    public function isDeaktiviert(): bool
    {
        return $this->deaktiviert;
    }

    /**
     * @return bool
     */
    public function isOptional(): bool
    {
        return $this->optional;
    }

    /**
     * @return SIN
     */
    public function getSIN(): SIN
    {
        return $this->sin;
    }

    /**
     * @return bool
     */
    public function isCustomMarge(): bool
    {
        return $this->customMarge;
    }

    /**
     * @return bool
     */
    public function isCustomPreisfaktor(): bool
    {
        return $this->customPreisfaktor;
    }

    /**
     * @return int
     */
    public function getVkVersionsId(): int
    {
        return $this->vkVersionsId;
    }

    /**
     * @return int
     */
    public function getProducttypeId(): int
    {
        return $this->producttypeId;
    }

    /**
     * @return int|null
     */
    public function getSortBefore(): ?int
    {
        return $this->sortBefore;
    }

    /**
     * @return int|null
     */
    public function getSortAfter(): ?int
    {
        return $this->sortAfter;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param int|null $sortBefore
     */
    public function setSortBefore(?int $sortBefore): void
    {
        $this->sortBefore = $sortBefore;
    }

    /**
     * @param int|null $sortAfter
     */
    public function setSortAfter(?int $sortAfter): void
    {
        $this->sortAfter = $sortAfter;
    }

    /**
     * @param int $quantity
     */
    public function setQuantity(int $quantity): void
    {
        $this->quantity = $quantity;
    }

    /**
     * @return bool
     */
    public function isChangeLpMenge(): bool
    {
        return $this->isChangeLpMenge;
    }
}
