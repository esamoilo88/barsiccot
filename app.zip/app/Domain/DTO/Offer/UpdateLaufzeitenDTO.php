<?php

namespace App\Domain\DTO\Offer;

use App\Domain\Entities\OfferChangerequestTyp;
use App\Domain\Entities\SalesStammdaten;
use DateTime;

class UpdateLaufzeitenDTO
{
    private SalesStammdaten $salesStammdaten;
    private ?DateTime $vertragsbeginn;
    private ?DateTime $vertragsende;
    private ?DateTime $rolloutbeginn;
    private ?DateTime $rolloutende;
    private ?DateTime $betriebsbeginn;
    private ?DateTime $betriebsende;
    private ?DateTime $beauftragungsende;
    private ?OfferChangerequestTyp $crTyp;
    private ?string $bemerkungen;

    /**
     * UpdateLaufzeitenDTO constructor.
     * @param SalesStammdaten $salesStammdaten
     * @param DateTime|null $vertragsbeginn
     * @param DateTime|null $vertragsende
     * @param DateTime|null $rolloutbeginn
     * @param DateTime|null $rolloutende
     * @param DateTime|null $betriebsbeginn
     * @param DateTime|null $betriebsende
     * @param DateTime|null $beauftragungsende
     * @param OfferChangerequestTyp|object|null $crTyp
     * @param string|null $bemerkungen
     */
    public function __construct(
        SalesStammdaten $salesStammdaten,
        ?DateTime $vertragsbeginn,
        ?DateTime $vertragsende,
        ?DateTime $rolloutbeginn,
        ?DateTime $rolloutende,
        ?DateTime $betriebsbeginn,
        ?DateTime $betriebsende,
        ?DateTime $beauftragungsende,
        ?OfferChangerequestTyp $crTyp,
        ?string $bemerkungen
    )
    {
        $this->salesStammdaten = $salesStammdaten;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
        $this->beauftragungsende = $beauftragungsende;
        $this->crTyp = $crTyp;
        $this->bemerkungen = $bemerkungen;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSalesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsbeginn(): ?DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsende(): ?DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutbeginn(): ?DateTime
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutende(): ?DateTime
    {
        return $this->rolloutende;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsbeginn(): ?DateTime
    {
        return $this->betriebsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsende(): ?DateTime
    {
        return $this->betriebsende;
    }

    /**
     * @return DateTime|null
     */
    public function getBeauftragungsende(): ?DateTime
    {
        return $this->beauftragungsende;
    }

    /**
     * @return bool
     */
    public function hasVertragsbeginn(): bool
    {
        return $this->vertragsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasVertragsende(): bool
    {
        return $this->vertragsende !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsbeginn(): bool
    {
        return $this->betriebsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsende(): bool
    {
        return $this->betriebsende !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutbeginn(): bool
    {
        return $this->rolloutbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutende(): bool
    {
        return $this->rolloutende !== null;
    }

    /**
     * @return bool
     */
    public function hasBeauftragungsende(): bool
    {
        return $this->beauftragungsende !== null;
    }

    /**
     * @return OfferChangerequestTyp|null
     */
    public function getCrTyp(): ?OfferChangerequestTyp
    {
        return $this->crTyp;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }
}
