<?php


namespace App\Domain\DTO\Offer\Export;


use App\Domain\ValueObjects\SIN;
use DateTime;

class ExportDiveXmlDTO extends \App\Domain\ValueObjects\SIN
{
    private SIN $sin;
    private int $versionId;
    private DateTime $validity;
    private int $diveTelekomReference;

    /**
     * SaveValidityDTO constructor.
     * @param SIN $sin
     * @param int $versionId
     * @param DateTime $validity
     * @param int $diveTelekomReference
     */
    public function __construct(
        SIN $sin,
        int $versionId,
        DateTime $validity,
        int $diveTelekomReference
    )
    {
        $this->sin = $sin;
        $this->versionId = $versionId;
        $this->validity = $validity;
        $this->diveTelekomReference = $diveTelekomReference;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVersionId(): int
    {
        return $this->versionId;
    }

    /**
     * @return DateTime
     */
    public function getValidity(): DateTime
    {
        return $this->validity;
    }

    /**
     * @return int
     */
    public function getDiveTelekomReference(): int
    {
        return $this->diveTelekomReference;
    }
}
