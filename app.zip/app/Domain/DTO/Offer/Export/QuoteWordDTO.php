<?php


namespace App\Domain\DTO\Offer\Export;


use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\GlobalGate;
use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\SalesContact;
use App\Domain\Entities\SalesStammdaten;


class QuoteWordDTO
{
    private int $simpleId;
    private BackendBenutzer $user;
    private OfferAngebotVk $vkVersion;
    private SalesStammdaten $salesStammdaten;
    private GlobalGate $globalGate;
    private ?SalesContact $receiver;

    /**
     * QuoteWorldDTO constructor.
     * @param int $simpleId
     * @param BackendBenutzer $user
     * @param OfferAngebotVk $vkVersion
     * @param SalesStammdaten $salesStammdaten
     * @param GlobalGate $globalGate
     * @param SalesContact|null $receiver
     */
    public function __construct(
        int $simpleId,
        BackendBenutzer $user,
        OfferAngebotVk $vkVersion,
        SalesStammdaten $salesStammdaten,
        GlobalGate $globalGate,
        ?SalesContact $receiver
    )
    {
        $this->simpleId = $simpleId;
        $this->user = $user;
        $this->vkVersion = $vkVersion;
        $this->salesStammdaten = $salesStammdaten;
        $this->globalGate = $globalGate;
        $this->receiver = $receiver;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVersionId(): OfferAngebotVk
    {
        return $this->vkVersion;
    }

    /**
     * @return SalesStammdaten
     */
    public function getSalesStammdaten(): SalesStammdaten
    {
        return $this->salesStammdaten;
    }

    /**
     * @return GlobalGate
     */
    public function getGlobalGate(): GlobalGate
    {
        return $this->globalGate;
    }

    /**
     * @return SalesContact|null
     */
    public function getReceiver(): ?SalesContact
    {
        return $this->receiver;
    }
}
