<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;

class OfferCompleteDTO
{
    private SIN $sin;
    private int $vkVersion;
    private bool $isSendEmail;

    /**
     * OfferCompleteDTO constructor.
     * @param SIN $sin
     * @param int $vkVersion
     * @param bool $isSendEmail
     */
    public function __construct(SIN $sin, int $vkVersion, bool $isSendEmail)
    {
        $this->sin = $sin;
        $this->vkVersion = $vkVersion;
        $this->isSendEmail = $isSendEmail;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVkVersion(): int
    {
        return $this->vkVersion;
    }

    /**
     * @return bool
     */
    public function isSendEmail(): bool
    {
        return $this->isSendEmail;
    }
}