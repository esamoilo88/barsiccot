<?php

namespace App\Domain\DTO\Offer;

use App\Domain\ValueObjects\SIN;
use DateTime;

class SaveValidityDTO
{
    private SIN $sin;
    private int $versionId;
    private DateTime $validity;

    /**
     * SaveValidityDTO constructor.
     * @param SIN $sin
     * @param int $versionId
     * @param DateTime $validity
     */
    public function __construct(
        SIN $sin,
        int $versionId,
        DateTime $validity
    )
    {
        $this->sin = $sin;
        $this->versionId = $versionId;
        $this->validity = $validity;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getVersionId(): int
    {
        return $this->versionId;
    }

    /**
     * @return DateTime
     */
    public function getValidity(): DateTime
    {
        return $this->validity;
    }
}
