<?php


namespace App\Domain\DTO\ONKA;


use App\Domain\Entities\OfferKalkulationElement;

class SetELSumsDTO
{

    private OfferKalkulationElement $element;

    /**
     * SetELSumsDTO constructor.
     * @param OfferKalkulationElement $element
     */
    public function __construct(
        OfferKalkulationElement $element
    )
    {
        $this->element = $element;
    }

    /**
     * @return OfferKalkulationElement
     */
    public function getElement(): OfferKalkulationElement
    {
        return $this->element;
    }
}
