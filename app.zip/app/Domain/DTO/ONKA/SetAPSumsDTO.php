<?php


namespace App\Domain\DTO\ONKA;


use App\Domain\Entities\OfferKalkulationAngebotsposition;

class SetAPSumsDTO
{

    private OfferKalkulationAngebotsposition $angebotsposition;

    /**
     * SetAPSumsDTO constructor.
     * @param OfferKalkulationAngebotsposition $angebotsposition
     */
    public function __construct(
        OfferKalkulationAngebotsposition $angebotsposition
    )
    {
        $this->angebotsposition = $angebotsposition;
    }

    /**
     * @return OfferKalkulationAngebotsposition
     */
    public function getAngebotsposition(): OfferKalkulationAngebotsposition
    {
        return $this->angebotsposition;
    }
}
