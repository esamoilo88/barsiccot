<?php


namespace App\Domain\DTO\Labels;


class StoreKlassifizierungDTO
{
    private array $data;
    private array $labelIds;
    private array $categoriesIds;

    public function __construct(array $data)
    {
        $this->data = $data;
        $this->labelIds = $this->extractLabelsIds($data);
        $this->categoriesIds = $this->extractCategoriesIds($data);
    }

    /**
     * Get array of labels ids
     * @param array $data
     * @return array
     */
    private function extractLabelsIds(array $data): array
    {
        $labelIds = [];
        foreach ($data as $categoryId => $labels) {
            foreach ($labels as $label) {
                $labelIds[] = $label['labelId'];
            }
        }
        return $labelIds;
    }

    /**
     * Get array of categories ids
     * @param array $data
     * @return array
     */
    private function extractCategoriesIds(array $data): array
    {
        return array_keys($data);
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * @return array
     */
    public function getLabelIds(): array
    {
        return $this->labelIds;
    }

    /**
     * @return array
     */
    public function getCategoriesIds(): array
    {
        return $this->categoriesIds;
    }
}
