<?php


namespace App\Domain\DTO\Customer\Contacts;


class ContactDTO
{
    protected int $customerId;
    protected string $firstName;
    protected string $lastName;
    protected string $company;
    protected int $roleId;
    protected ?string $department;
    protected ?string $email;
    protected ?string $telNr;

    /**
     * ContactDTO constructor.
     * @param int $customerId
     * @param string $firstName
     * @param string $lastName
     * @param string $company
     * @param int $roleId
     * @param string|null $department
     * @param string|null $email
     * @param string|null $telNr
     */
    public function __construct(int $customerId, string $firstName, string $lastName, string $company, int $roleId, ?string $department = null, ?string $email = null, ?string $telNr = null)
    {
        $this->customerId = $customerId;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->company = $company;
        $this->roleId = $roleId;
        $this->department = $department;
        $this->email = $email;
        $this->telNr = $telNr;
    }

    /**
     * @return int
     */
    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    /**
     * @return string
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @return string
     */
    public function getCompany(): string
    {
        return $this->company;
    }

    /**
     * @return int
     */
    public function getRoleId(): int
    {
        return $this->roleId;
    }

    /**
     * @return string|null
     */
    public function getDepartment(): ?string
    {
        return $this->department;
    }

    /**
     * @return string|null
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @return string|null
     */
    public function getTelNr(): ?string
    {
        return $this->telNr;
    }


}
