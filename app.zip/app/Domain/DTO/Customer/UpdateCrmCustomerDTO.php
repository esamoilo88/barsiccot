<?php

namespace App\Domain\DTO\Customer;

class UpdateCrmCustomerDTO
{
    protected string $name;
    protected ?string $country;
    protected ?string $postalCode;
    protected ?string $state;
    protected string $city;
    protected ?string $street;
    protected ?string $hn;

    /**
     * UpdateCrmCustomerDTO constructor.
     * @param string $name
     * @param string|null $country
     * @param string|null $postalCode
     * @param string|null $state
     * @param string $city
     * @param string|null $street
     * @param string|null $hn
     */
    public function __construct(
        string $name,
        ?string $country,
        ?string $postalCode,
        ?string $state,
        string $city,
        ?string $street,
        ?string $hn
    )
    {
        $this->name = $name;
        $this->country = $country;
        $this->postalCode = $postalCode;
        $this->state = $state;
        $this->city = $city;
        $this->street = $street;
        $this->hn = $hn;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string|null
     */
    public function getCountry(): ?string
    {
        return $this->country;
    }

    /**
     * @return string|null
     */
    public function getPostalCode(): ?string
    {
        return $this->postalCode;
    }

    /**
     * @return string|null
     */
    public function getState(): ?string
    {
        return $this->state;
    }

    /**
     * @return string
     */
    public function getCity(): string
    {
        return $this->city;
    }

    /**
     * @return string|null
     */
    public function getStreet(): ?string
    {
        return $this->street;
    }

    /**
     * @return string|null
     */
    public function getHn(): ?string
    {
        return $this->hn;
    }

}
