<?php

namespace App\Domain\DTO\Customer\Notes;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\CrmCustomer;

class NoteDTO
{
    private CrmCustomer $customer;
    private string $note;
    private BackendBenutzer $benutzer;

    /**
     * NoteDTO constructor.
     * @param CrmCustomer $customer
     * @param string $note
     * @param BackendBenutzer $benutzer
     */
    public function __construct(CrmCustomer $customer, string $note, BackendBenutzer $benutzer)
    {
        $this->customer = $customer;
        $this->note = $note;
        $this->benutzer = $benutzer;
    }

    /**
     * @return CrmCustomer
     */
    public function getCustomer(): CrmCustomer
    {
        return $this->customer;
    }

    /**
     * @return string
     */
    public function getNote(): string
    {
        return $this->note;
    }

    /**
     * @return BackendBenutzer
     */
    public function getBenutzer(): BackendBenutzer
    {
        return $this->benutzer;
    }
}