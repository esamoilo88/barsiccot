<?php

namespace App\Domain\DTO\SystemProtocol;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Signatures\SystemProtocol\ActionSignature;
use App\Domain\Signatures\SystemProtocol\LogGroupSignature;
use App\Domain\ValueObjects\SIN;

class SystemProtocolDTO
{
    private LogGroupSignature $group;
    private ?SIN $sin;
    private ?BackendBenutzer $benutzer;
    private string $logText = '';
    private ActionSignature $action;
    private ?string $objectName;
    private ?string $parentName;
    private ?string $changes;
    private bool $result;
    private ?string $message;

    /**
     * SystemProtocolDTO constructor.
     * @param LogGroupSignature $group
     * @param SIN|null $sin
     * @param BackendBenutzer|null $benutzer
     * @param string $logText
     * @param ActionSignature $action
     * @param string|null $objectName
     * @param string|null $parentName
     * @param string|null $changes
     * @param bool $result
     * @param string|null $message
     */
    public function __construct(
        LogGroupSignature $group,
        ?SIN $sin,
        ?BackendBenutzer $benutzer,
        string $logText,
        ActionSignature $action,
        ?string $objectName = null,
        ?string $parentName = null,
        ?string $changes = null,
        bool $result = true,
        ?string $message = null
    )
    {
        $this->group = $group;
        $this->sin = $sin;
        $this->benutzer = $benutzer;
        $this->logText = $logText;
        $this->action = $action;
        $this->objectName = $objectName;
        $this->parentName = $parentName;
        $this->changes = $changes;
        $this->result = $result;
        $this->message =$message;
    }

    /**
     * @return LogGroupSignature
     */
    public function getGroup(): LogGroupSignature
    {
        return $this->group;
    }

    /**
     * @return SIN|null
     */
    public function getSin(): ?SIN
    {
        return $this->sin;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getBenutzer(): ?BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return ActionSignature
     */
    public function getAction(): ActionSignature
    {
        return $this->action;
    }

    /**
     * @return string
     */
    public function getLogText(): string
    {
        return $this->logText;
    }

    /**
     * @return string|null
     */
    public function getObjectName(): ?string
    {
        return $this->objectName;
    }

    /**
     * @return string|null
     */
    public function getParentName(): ?string
    {
        return $this->parentName;
    }

    /**
     * @return string|null
     */
    public function getChanges(): ?string
    {
        return $this->changes;
    }

    /**
     * @return bool
     */
    public function getResult(): bool
    {
        return $this->result;
    }

    /**
     * @return string|null
     */
    public function getMessage(): ?string
    {
        return $this->message;
    }
}
