<?php

namespace App\Domain\DTO\Pagination;

use App\Domain\Repositories\Utils\Sort\Sortable;
use App\Exceptions\Application\SortFieldIsNotSetException;

class Sort
{
    private ?bool $isDesc;
    private ?string $field;

    /**
     * Sort constructor.
     * @param bool|null $isDesc
     * @param string|null $sortBy
     */
    public function __construct(?bool $isDesc, ?string $sortBy)
    {
        $this->isDesc = $isDesc;
        $this->field = $sortBy;
    }

    /**
     * @return bool
     */
    public function hasField(): bool
    {
        return $this->field !== null;
    }

    /**
     * @return string
     */
    public function direction(): string
    {
        return $this->isDesc ? 'DESC': 'ASC';
    }

    /**
     * @param Sortable $repository
     * @return string
     * @throws SortFieldIsNotSetException
     */
    public function translatedField(Sortable $repository): string
    {
        if (! isset($repository->getSortableFields()[$this->field])) {
            throw new SortFieldIsNotSetException();
        }
        return $repository->getSortableFields()[$this->field];
    }
}
