<?php

namespace App\Domain\DTO\Pagination;

use ArrayIterator;

class PaginationResponseDTO
{
    private int $totalItems;
    private ArrayIterator $pageData;
    private int $perPage;

    /**
     * PaginationDTO constructor.
     * @param int $totalItems
     * @param ArrayIterator $pageData
     * @param int $perPage
     */
    public function __construct(int $totalItems, ArrayIterator $pageData, int $perPage)
    {
        $this->totalItems = $totalItems;
        $this->pageData = $pageData;
        $this->perPage = $perPage;
    }

    /**
     * @return int
     */
    public function totalItems(): int
    {
        return $this->totalItems;
    }

    /**
     * @return ArrayIterator
     */
    public function pageData(): ArrayIterator
    {
        return $this->pageData;
    }

    /**
     * @return int
     */
    public function perPage(): int
    {
        return $this->perPage;
    }
}