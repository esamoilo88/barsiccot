<?php

namespace App\Domain\DTO\Pagination;

class PaginationRequestDTO
{
    private ?array $filters;
    private Sort $sort;
    private int $currentPage;
    private ?string $apiUrl;
    private ?int $perPage;

    /**
     * GridParamsDTO constructor.
     * @param array $params
     */
    public function __construct(array $params)
    {
        $this->filters = $params['filter'] ?? null;
        $this->sort = new Sort($params['sortDesc'] ?? null, $params['sortBy'] ?? null);
        $this->currentPage = $params['currentPage'];
        $this->apiUrl = $params['apiUrl'] ?? null;
        $this->perPage = isset($params['perPage']) && $params['perPage'] != 0 ? $params['perPage'] : null;
    }

    /**
     * @return array|null
     */
    public function filters(): ?array
    {
        return $this->filters;
    }

    /**
     * @return bool
     */
    public function hasFilters(): bool
    {
        return $this->filters !== null;
    }

    /**
     * @return Sort
     */
    public function sort(): Sort
    {
        return $this->sort;
    }

    /**
     * @return bool
     */
    public function hasSort(): bool
    {
        return $this->sort->hasField();
    }

    /**
     * @return int
     */
    public function currentPage(): int
    {
        return $this->currentPage;
    }

    /**
     * @return int|null
     */
    public function perPage(): ?int
    {
        return $this->perPage;
    }
}
