<?php


namespace App\Domain\DTO\Order;


use App\Domain\ValueObjects\SIN;

class UpdateRechnungsdatenDTO
{

    private SIN $sin;
    private int $debitorId;
    private int $ansprechpartnerId;
    private ?string $billingSubjectExtension;

    /**
     * UpdateRechnungsdatenDTO constructor.
     * @param SIN $sin
     * @param int $debitorId
     * @param int $ansprechpartnerId
     * @param string|null $billingSubjectExtension
     */
    public function __construct(
        SIN $sin,
        int $debitorId,
        int $ansprechpartnerId,
        ?string $billingSubjectExtension
    )
    {
        $this->sin = $sin;
        $this->debitorId = $debitorId;
        $this->ansprechpartnerId = $ansprechpartnerId;
        $this->billingSubjectExtension = $billingSubjectExtension;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getAnsprechpartnerId(): int
    {
        return $this->ansprechpartnerId;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return int
     */
    public function getDebitorId(): int
    {
        return $this->debitorId;
    }
}
