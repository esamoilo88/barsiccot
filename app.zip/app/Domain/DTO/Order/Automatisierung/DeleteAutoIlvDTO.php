<?php

namespace App\Domain\DTO\Order\Automatisierung;

use App\Domain\ValueObjects\SIN;

class DeleteAutoIlvDTO
{
    private SIN $sin;
    private array $ids;

    /**
     * DeleteAutoIlvDTO constructor.
     * @param SIN $sin
     * @param array $ids
     */
    public function __construct(SIN $sin, array $ids)
    {
        $this->sin = $sin;
        $this->ids = $ids;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return array
     */
    public function getIds(): array
    {
        return $this->ids;
    }
}