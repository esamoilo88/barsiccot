<?php

namespace App\Domain\DTO\Order\Automatisierung;

use App\Domain\ValueObjects\SIN;

class CreateAutoIlvDTO
{
    private string $monthYear;
    private string $createAt;
    private SIN $sin;

    /**
     * CreateAutoIlvDTO constructor.
     * @param string $monthYear
     * @param string $createAt
     * @param SIN $sin
     */
    public function __construct(string $monthYear, string $createAt, SIN $sin)
    {
        $this->monthYear = $monthYear;
        $this->createAt = $createAt;
        $this->sin = $sin;
    }

    /**
     * @return string
     */
    public function getMonthYear(): string
    {
        return $this->monthYear;
    }

    /**
     * @return string
     */
    public function getCreateAt(): string
    {
        return $this->createAt;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }
}