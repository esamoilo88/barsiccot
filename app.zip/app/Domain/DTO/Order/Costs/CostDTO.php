<?php


namespace App\Domain\DTO\Order\Costs;


class CostDTO
{
    protected int $simpleId;
    protected int $kostenartId;
    protected ?int $stundensatzId;
    protected ?string $stundensatzAlternativ;
    protected int $kostenJahr;
    protected int $kostenMonat;
    protected ?int $ofiLa;
    protected ?int $kostenstelleId;
    protected ?int $receiverKostenstelleId;
    protected string $wert;
    protected ?string $actualValue;
    protected ?string $pspElement;
    protected ?string $bemerkungen;
    protected ?int $quellsystemId;
    private ?int $benutzerId;
    private ?float $stundentsatz;

    /**
     * CostDTO constructor.
     * @param int $simpleId
     * @param int $kostenartId
     * @param int|null $stundensatzId
     * @param string|null $stundensatzAlternativ
     * @param int $kostenJahr
     * @param int $kostenMonat
     * @param int|null $ofiLa
     * @param int|null $kostenstelleId
     * @param int|null $receiverKostenstelleId
     * @param string $wert
     * @param string|null $actualValue
     * @param int|null $pspElement
     * @param string|null $bemerkungen
     * @param int|null $quellsystemId
     * @param int|null $benutzerId
     * @param float|null $stundensatz
     */
    public function __construct(
        int $simpleId,
        int $kostenartId,
        ?int $stundensatzId,
        ?string $stundensatzAlternativ,
        int $kostenJahr,
        int $kostenMonat,
        ?int $ofiLa,
        ?int $kostenstelleId,
        ?int $receiverKostenstelleId,
        string $wert,
        ?string $actualValue,
        ?string $pspElement,
        ?string $bemerkungen,
        ?int $quellsystemId,
        ?int $benutzerId,
        ?float $stundensatz = null
    )
    {
        $this->simpleId = $simpleId;
        $this->kostenartId = $kostenartId;
        $this->stundensatzId = $stundensatzId;
        $this->stundensatzAlternativ = $stundensatzAlternativ;
        $this->kostenJahr = $kostenJahr;
        $this->kostenMonat = $kostenMonat;
        $this->ofiLa = $ofiLa;
        $this->kostenstelleId = $kostenstelleId;
        $this->receiverKostenstelleId = $receiverKostenstelleId;
        $this->wert = $wert;
        $this->actualValue = $actualValue;
        $this->pspElement = $pspElement;
        $this->bemerkungen = $bemerkungen;
        $this->quellsystemId = $quellsystemId;
        $this->benutzerId = $benutzerId;
        $this->stundentsatz = $stundensatz;
    }

    /**
     * @param $value
     * @return float|null
     */
    protected function getFloatOrNull($value): ?float
    {
        $value = str_replace(',', '.', $value);

        if ($value !== null) {
            $value = floatval($value);
        }

        return $value;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getActualValue(): ?string
    {
        return $this->actualValue;
    }

    /**
     * @return string
     */
    public function getWert(): string
    {
        return $this->wert;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @return string|null
     */
    public function getStundensatzAlternativ(): ?string
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @return int|null
     */
    public function getStundensatzId(): ?int
    {
        return $this->stundensatzId;
    }

    /**
     * @return int
     */
    public function getKostenartId(): int
    {
        return $this->kostenartId;
    }

    /**
     * @return int
     */
    public function getKostenJahr(): int
    {
        return $this->kostenJahr;
    }

    /**
     * @return int
     */
    public function getKostenMonat(): int
    {
        return $this->kostenMonat;
    }

    /**
     * @return int|null
     */
    public function getReceiverKostenstelleId(): ?int
    {
        return $this->receiverKostenstelleId;
    }

    /**
     * @return int|null
     */
    public function getKostenstelleId(): ?int
    {
        return $this->kostenstelleId;
    }

    /**
     * @return int|null
     */
    public function getQuellsystemId(): ?int
    {
        return $this->quellsystemId;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @return int|null
     */
    public function getBenutzerId(): ?int
    {
        return $this->benutzerId;
    }

    /**
     * @return float|null
     */
    public function getStundentsatz(): ?float
    {
        return $this->stundentsatz;
    }
}
