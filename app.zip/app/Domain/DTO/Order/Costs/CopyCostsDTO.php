<?php

namespace App\Domain\DTO\Order\Costs;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\ValueObjects\SIN;

class CopyCostsDTO
{
    private SIN $simpleId;
    private int $kostenmonat;
    private int $kostenjahr;
    private array $selected;
    private BackendBenutzer $user;

    /**
     * CopyCostsDTO constructor.
     * @param SIN $simpleId
     * @param int $kostenmonat
     * @param int $kostenjahr
     * @param array $selected
     * @param BackendBenutzer $user
     */
    public function __construct(
        SIN $simpleId,
        int $kostenmonat,
        int $kostenjahr,
        array $selected,
        BackendBenutzer $user
    )
    {
        $this->simpleId = $simpleId;
        $this->kostenmonat = $kostenmonat;
        $this->kostenjahr = $kostenjahr;
        $this->selected = $selected;
        $this->user = $user;
    }

    /**
     * @return SIN
     */
    public function getSimpleId(): SIN
    {
        return $this->simpleId;
    }

    /**
     * @return array
     */
    public function getSelected(): array
    {
        return $this->selected;
    }

    /**
     * @return BackendBenutzer
     */
    public function getUser(): BackendBenutzer
    {
        return $this->user;
    }

    /**
     * @return int
     */
    public function getKostenmonat(): int
    {
        return $this->kostenmonat;
    }

    /**
     * @return int
     */
    public function getKostenjahr(): int
    {
        return $this->kostenjahr;
    }
}