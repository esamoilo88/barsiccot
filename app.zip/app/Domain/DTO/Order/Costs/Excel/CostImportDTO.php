<?php


namespace App\Domain\DTO\Order\Costs\Excel;


use Carbon\Carbon;
use DateTime;

class CostImportDTO
{
    protected ?int $simpleId;
    protected ?int $kostenartId;
    protected ?int $stundensatzId;
    protected ?float $stundensatzAlternativ;
    protected ?string $kostenJahr;
    protected ?string $kostenMonat;
    protected ?string $ofiLa;
    protected ?int $kostenstelleId;
    protected ?int $receiverKostenstelleId;
    protected ?string $wert;
    protected ?string $actualValue;
    protected ?int $pspElement;
    protected ?string $bemerkungen;
    protected ?int $quellsystemId;

    /**
     * CostImportDTO constructor.
     * @param string|null $simpleId
     * @param string|null $kostenartId
     * @param int|null $stundensatzId
     * @param float|null $stundensatzAlternativ
     * @param string|null $kostenJahr
     * @param string|null $kostenMonat
     * @param string|null $ofiLa
     * @param string|null $kostenstelleId
     * @param string|null $receiverKostenstelleId
     * @param string $wert
     * @param string|null $actualValue
     * @param string|null $pspElement
     * @param string|null $bemerkungen
     * @param int|null $quellsystemId
     */
    public function __construct(
        ?string $simpleId,
        ?string $kostenartId,
        ?int $stundensatzId,
        ?float $stundensatzAlternativ,
        ?string $kostenJahr,
        ?string $kostenMonat,
        ?string $ofiLa,
        ?int $kostenstelleId,
        ?int $receiverKostenstelleId,
        ?string $wert,
        ?string $actualValue,
        ?string $pspElement,
        ?string $bemerkungen,
        ?int $quellsystemId
    )
    {
        $this->simpleId = intval($simpleId);
        $this->kostenartId = intval($kostenartId);
        $this->stundensatzId = $stundensatzId;
        $this->stundensatzAlternativ = $stundensatzAlternativ;
        $this->kostenJahr = intval($kostenJahr);
        $this->kostenMonat = intval($kostenMonat);
        $this->ofiLa = $ofiLa;
        $this->kostenstelleId = $kostenstelleId;
        $this->receiverKostenstelleId = $receiverKostenstelleId;
        $this->wert = $wert;
        $this->actualValue = $actualValue;
        $this->pspElement = $pspElement;
        $this->bemerkungen = $bemerkungen;
        $this->quellsystemId = $quellsystemId;
    }

    /**
     * @return int|null
     */
    public function getPspElement(): ?int
    {
        return $this->pspElement;
    }

    /**
     * @return int|null
     */
    public function getSimpleId(): ?int
    {
        return $this->simpleId;
    }

    /**
     * @return int|null
     */
    public function getStundensatzId(): ?int
    {
        return $this->stundensatzId;
    }

    /**
     * @return string|int
     */
    public function getWert(): ?string
    {
        return $this->wert;
    }

    /**
     * @return int|null
     */
    public function getOfiLa(): ?int
    {
        return $this->ofiLa;
    }

    /**
     * @return int|null
     */
    public function getKostenartId(): ?int
    {
        return $this->kostenartId;
    }

    /**
     * @return string|null
     */
    public function getActualValue(): ?string
    {
        return $this->actualValue;
    }

    /**
     * @return string|null
     */
    public function getKostenJahr(): ?string
    {
        return $this->kostenJahr;
    }

    /**
     * @return string|null
     */
    public function getKostenMonat(): ?string
    {
        return $this->kostenMonat;
    }

    /**
     * @return int|null
     */
    public function getKostenstelleId(): ?int
    {
        return $this->kostenstelleId;
    }

    /**
     * @return Carbon|null
     */
    public function getCostsDate(): ?Carbon
    {
        return ($this->kostenJahr && $this->kostenMonat) ? Carbon::create($this->kostenJahr, $this->kostenMonat, 1): null;
    }

    /**
     * @return int|null
     */
    public function getReceiverKostenstelleId(): ?int
    {
        return $this->receiverKostenstelleId;
    }

    /**
     * @return float|null
     */
    public function getStundensatzAlternativ(): ?float
    {
        return $this->stundensatzAlternativ;
    }

    /**
     * @return DateTime|null
     */
    public function getKostenDate(): ?DateTime
    {
        return ($this->kostenMonat && $this->kostenJahr && $this->getKostenMonat()<= 12) ?
            new DateTime("01.{$this->getKostenMonat()}.{$this->getKostenJahr()}") :
            null;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @return int|null
     */
    public function getQuellsystemId(): ?int
    {
        return $this->quellsystemId;
    }

    /**
     * @param int $stundensatzId
     */
    public function setStundensatzId(int $stundensatzId): void
    {
        $this->stundensatzId = $stundensatzId;
    }
}
