<?php

namespace App\Domain\DTO\Order\Costs\Excel;

class ValidationResponseDTO
{
    private string $type;
    private array $data;

    /**
     * ValidationResponseDTO constructor.
     * @param string $type
     * @param array $data
     */
    public function __construct(string $type, array $data)
    {
        $this->type = $type;
        $this->data = $data;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }
}
