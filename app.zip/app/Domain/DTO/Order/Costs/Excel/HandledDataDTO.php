<?php

namespace App\Domain\DTO\Order\Costs\Excel;


class HandledDataDTO
{
    /** @var ImportShowCostDTO[] */
    private array $cost;


    /**
     * HandledDataDTO constructor.
     * @param array $cost
     */
    public function __construct(array $cost)
    {
        $this->cost = $cost;
    }

    /**
     * @return array
     */
    public function getCost(): array
    {
        return $this->cost;
    }
}
