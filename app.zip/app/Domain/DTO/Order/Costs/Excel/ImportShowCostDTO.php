<?php


namespace App\Domain\DTO\Order\Costs\Excel;

class ImportShowCostDTO
{
    protected int $simpleId;
    protected string $kostenartName;
    protected float $stundensatz;
    protected int $kostenJahr;
    protected int $kostenMonat;
    protected ?string $kostenstelleName;
    protected ?string $receiverKostenstelleName;
    protected ?float $wert;
    protected ?string $bemerkungen;
    protected string $quellsystemName;

    /**
     * ImportShowCostDTO constructor.
     * @param int $simpleId
     * @param string $kostenartName
     * @param float $stundensatz
     * @param int $kostenJahr
     * @param int $kostenMonat
     * @param string|null $kostenstelleName
     * @param string|null $receiverKostenstelleName
     * @param float|null $wert
     * @param string|null $bemerkungen
     * @param string $quellsystemName
     */
    public function __construct(
        int $simpleId,
        string $kostenartName,
        float $stundensatz,
        int $kostenJahr,
        int $kostenMonat,
        ?string $kostenstelleName,
        ?string $receiverKostenstelleName,
        ?float $wert,
        ?string $bemerkungen,
        string $quellsystemName
    )
    {
        $this->simpleId = intval($simpleId);
        $this->kostenartName = $kostenartName;
        $this->stundensatz = floatval($stundensatz);
        $this->kostenJahr = intval($kostenJahr);
        $this->kostenMonat = intval($kostenMonat);
        $this->kostenstelleName = $kostenstelleName;
        $this->receiverKostenstelleName = $receiverKostenstelleName;
        $this->wert = $wert;
        $this->bemerkungen = $bemerkungen;
        $this->quellsystemName = $quellsystemName;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return float
     */
    public function getStundensatz(): float
    {
        return $this->stundensatz;
    }

    /**
     * @return float|int
     */
    public function getWert(): ?float
    {
        return $this->wert;
    }

    /**
     * @return float|int
     */
    public function getBetrag(): ?float
    {
        return floatval($this->wert * $this->stundensatz);
    }

    /**
     * @return string
     */
    public function getKostenartName(): string
    {
        return $this->kostenartName;
    }

    /**
     * @return int
     */
    public function getKostenJahr(): int
    {
        return $this->kostenJahr;
    }

    /**
     * @return int
     */
    public function getKostenMonat(): int
    {
        return $this->kostenMonat;
    }

    /**
     * @return string
     */
    public function getKostenstelleName(): string
    {
        return $this->kostenstelleName;
    }

    /**
     * @return string
     */
    public function getReceiverKostenstelleName(): string
    {
        return $this->receiverKostenstelleName;
    }

    /**
     * @return string|null
     */
    public function getBemerkungen(): ?string
    {
        return $this->bemerkungen;
    }

    /**
     * @return string
     */
    public function getQuellsystemName(): string
    {
        return $this->quellsystemName;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'simpleId' => $this->getSimpleId(),
            'kostenMonat' => $this->getKostenMonat(),
            'kostenJahr' => $this->getKostenJahr(),
            'kostenart' => $this->getKostenartName(),
            'stundensatz' => $this->getStundensatz(),
            'kostenwert' => $this->getWert(),
            'kostenBetrag' => $this->getBetrag(),
            'bemerkungen' => $this->getBemerkungen(),
            'quellsystem' => $this->getQuellsystemName(),
            'kostenstelle' => $this->getKostenstelleName(),
            'empfanger_kostenstelle' => $this->getReceiverKostenstelleName()

        ];
    }
}
