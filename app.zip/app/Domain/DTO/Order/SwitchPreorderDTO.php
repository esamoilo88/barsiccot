<?php


namespace App\Domain\DTO\Order;


use App\Domain\ValueObjects\SIN;

class SwitchPreorderDTO
{
    private SIN $sin;
    private ?string $sapAuftragsNr;
    private array $file;
    private ?int $financeOrderId;

    /**
     * SwitchPreorderDTO constructor.
     * @param SIN $sin
     * @param string|null $sapAuftragsNr
     * @param array $file
     * @param int|null $financeOrderId
     */
    public function __construct(
        SIN $sin,
        ?string $sapAuftragsNr,
        array $file,
        ?int $financeOrderId
    )
    {
        $this->sin = $sin;
        $this->sapAuftragsNr = $sapAuftragsNr;
        $this->file = $file;
        $this->financeOrderId = $financeOrderId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return array
     */
    public function getFile(): array
    {
        return $this->file;
    }

    /**
     * @return string|null
     */
    public function getSapAuftragsNr(): ?string
    {
        return $this->sapAuftragsNr;
    }

    /**
     * @return int|null
     */
    public function getFinanceOrderId(): ?int
    {
        return $this->financeOrderId;
    }
}
