<?php

namespace App\Domain\DTO\Order\LBUPosition;

use DateTime;

class LBUPositionCreateDTO
{
    private int $simpleId;
    private int $lbuId;
    private ?int $matNrId;
    private ?string $angebotsposition;
    private ?int $angebotspositionId;
    private float $menge;
    private float $einzelpreisDtts;
    private ?int $icpKontBpos;
    private DateTime $leistungszeitpunkt;
    private string $leistungsort;
    private ?string $pspElement;
    private ?int $quellsystemId;
    private ?string $ticketNr;
    private ?int $icpKontKontoId;
    private ?string $icpKontPspKst;
    private ?string $kommentar;
    private string $fakturaziel;
    private ?string $installationsbemerkung;
    private ?string $positionName;
    private ?string $locationName;
    private ?string $orderPurchaseKey;

    /**
     * LBUPositionCreateDTO constructor.
     * @param int $simpleId
     * @param int $lbuId
     * @param int|null $matNrId
     * @param float $menge
     * @param float $einzelpreisDtts
     * @param int|null $icpKontBpos
     * @param DateTime $leistungszeitpunkt
     * @param string $leistungsort
     * @param string|null $pspElement
     * @param string $fakturaziel
     * @param string|null $angebotsposition
     * @param int|null $angebotspositionId
     * @param int|null $quellsystemId
     * @param string|null $ticketNr
     * @param int|null $icpKontKontoId
     * @param string|null $icpKontPspKst
     * @param string|null $kommentar
     * @param string|null $installationsbemerkung
     * @param string|null $positionName
     * @param string|null $locationName
     * @param string|null $orderPurchaseKey
     */
    public function __construct(
        int $simpleId,
        int $lbuId,
        ?int $matNrId,
        float $menge,
        float $einzelpreisDtts,
        ?int $icpKontBpos,
        DateTime $leistungszeitpunkt,
        string $leistungsort,
        ?string $pspElement,
        string $fakturaziel,
        ?string $angebotsposition,
        ?int $angebotspositionId,
        ?int $quellsystemId = null,
        ?string $ticketNr = null,
        ?int $icpKontKontoId = null,
        ?string $icpKontPspKst = null,
        ?string $kommentar = null,
        ?string $installationsbemerkung = null,
        ?string $positionName = null,
        ?string $locationName = null,
        ?string $orderPurchaseKey = null
    )
    {
        $this->simpleId = $simpleId;
        $this->lbuId = $lbuId;
        $this->matNrId = $matNrId;
        $this->angebotsposition = $angebotsposition;
        $this->angebotspositionId = $angebotspositionId;
        $this->menge = $menge;
        $this->einzelpreisDtts = $einzelpreisDtts;
        $this->icpKontBpos = $icpKontBpos;
        $this->leistungszeitpunkt = $leistungszeitpunkt;
        $this->leistungsort = $leistungsort;
        $this->pspElement = $pspElement;
        $this->quellsystemId = $quellsystemId;
        $this->ticketNr = $ticketNr;
        $this->icpKontKontoId = $icpKontKontoId;
        $this->icpKontPspKst = $icpKontPspKst;
        $this->kommentar = $kommentar;
        $this->fakturaziel = $fakturaziel;
        $this->installationsbemerkung = $installationsbemerkung;
        $this->positionName = $positionName;
        $this->locationName = $locationName;
        $this->orderPurchaseKey = $orderPurchaseKey;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNrId;
    }

    /**
     * @return string|null
     */
    public function getAngebotspositionName(): ?string
    {
        return $this->angebotsposition;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return float
     */
    public function getMenge(): float
    {
        return $this->menge;
    }

    /**
     * @return float
     */
    public function getEinzelpreisDtts(): float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return int|null
     */
    public function getIcpKontBpos(): ?int
    {
        return $this->icpKontBpos;
    }

    /**
     * @return DateTime
     */
    public function getLeistungszeitpunkt(): DateTime
    {
        return $this->leistungszeitpunkt;
    }

    /**
     * @return string
     */
    public function getLeistungsort(): string
    {
        return $this->leistungsort;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return int|null
     */
    public function getQuellsystemId(): ?int
    {
        return $this->quellsystemId;
    }

    /**
     * @return string|null
     */
    public function getTicketNr(): ?string
    {
        return $this->ticketNr;
    }

    /**
     * @return int|null
     */
    public function getIcpKontKontoId(): ?int
    {
        return $this->icpKontKontoId;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return string
     */
    public function getFakturaziel(): string
    {
        return $this->fakturaziel;
    }

    /**
     * @return string|null
     */
    public function getInstallationsbemerkung(): ?string
    {
        return $this->installationsbemerkung;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }
}
