<?php

namespace App\Domain\DTO\Order\LBUPosition;

use App\Domain\Entities\OfferFakturaLbuDaten;

class LBUPositionCreateReturnDTO
{
    private array $errors;
    private ?OfferFakturaLbuDaten $lbuDaten;

    /**
     * LBUPositionCreateReturnDTO constructor.
     * @param array $errors
     * @param OfferFakturaLbuDaten|null $lbu
     */
    public function __construct(array $errors, ?OfferFakturaLbuDaten $lbu = null)
    {
        $this->errors = $errors;
        $this->lbuDaten = $lbu;
    }

    /**
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * @return OfferFakturaLbuDaten|null
     */
    public function getLbuDaten(): ?OfferFakturaLbuDaten
    {
        return $this->lbuDaten;
    }

    /**
     * @return bool
     */
    public function hasErrors(): bool
    {
        return $this->errors !== [];
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            $this->errors,
            $this->lbuDaten
        ];
    }
}