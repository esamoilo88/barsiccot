<?php

namespace App\Domain\DTO\Order;

use DateTime;

class LbuPositionDTO
{
    protected int $simpleId;
    protected ?int $lbuId;
    protected ?string $angebotsposition;
    protected ?float $menge;
    protected ?float $einzelpreisDtts;
    protected ?DateTime $leistungszeitpunkt;
    protected ?string $leistungsort;
    protected ?string $pspElement;
    protected ?int $angebotspositionId;
    protected ?string $quellsystemId;
    protected ?int $matNr;
    protected ?string $ticketNr;
    protected ?string $icpKontKontoId;
    protected ?string $icpKontPspKst;
    protected ?string $icpKontBpos;
    protected ?string $kommentar;
    protected string $fakturaziel;
    protected int $leistungsMonat;
    protected int $leistungsJahr;
    protected int $fakturazielId;
    protected int $debitorId;
    protected float $totalPrice;
    private ?string $positionName;
    private ?string $locationName;
    private ?string $orderPurchaseKey;

    /**
     * LbuPositionDTO constructor.
     * @param int $simpleId
     * @param string $fakturaziel
     * @param int $leistungsJahr
     * @param int $leistungsMonat
     * @param $fakturazielId
     * @param $debitorId
     * @param int|null $lbuId
     * @param string|null $angebotsposition
     * @param float|null $menge
     * @param float|null $einzelpreisDtts
     * @param DateTime|null $leistungszeitpunkt
     * @param string|null $leistungsort
     * @param string|null $pspElement
     * @param int|null $angebotspositionId
     * @param string|null $quellsystemId
     * @param int|null $matNr
     * @param string|null $ticketNr
     * @param string|null $icpKontKontoId
     * @param string|null $icpKontPspKst
     * @param string|null $icpKontBpos
     * @param string|null $kommentar
     * @param string|null $positionName
     * @param string|null $locationName
     * @param string|null $orderPurchaseKey
     */
    public function __construct(
        int $simpleId,
        string $fakturaziel,
        int $leistungsJahr,
        int $leistungsMonat,
        $fakturazielId,
        $debitorId,
        ?int $lbuId,
        ?string $angebotsposition,
        ?float $menge,
        ?float $einzelpreisDtts,
        ?DateTime $leistungszeitpunkt,
        ?string $leistungsort,
        ?string $pspElement,
        ?int $angebotspositionId = null,
        ?string $quellsystemId = null,
        ?int $matNr = null,
        ?string $ticketNr = null,
        ?string $icpKontKontoId = null,
        ?string $icpKontPspKst = null,
        ?string $icpKontBpos = null,
        ?string $kommentar = null,
        ?string $positionName = null,
        ?string $locationName = null,
        ?string $orderPurchaseKey = null
    )
    {
        $this->simpleId = $simpleId;
        $this->lbuId = $lbuId;
        $this->angebotsposition = $angebotsposition;
        $this->menge = $menge;
        $this->einzelpreisDtts = $einzelpreisDtts;
        $this->leistungszeitpunkt = $leistungszeitpunkt;
        $this->leistungsort = $leistungsort;
        $this->pspElement = $pspElement;
        $this->angebotspositionId = $angebotspositionId;
        $this->quellsystemId = $quellsystemId;
        $this->matNr = $matNr;
        $this->ticketNr = $ticketNr;
        $this->icpKontKontoId = $icpKontKontoId;
        $this->icpKontPspKst = $icpKontPspKst;
        $this->icpKontBpos = $icpKontBpos;
        $this->kommentar = $kommentar;
        $this->fakturaziel =$fakturaziel;
        $this->leistungsJahr = $leistungsJahr;
        $this->leistungsMonat = $leistungsMonat;
        $this->debitorId = $debitorId;
        $this->fakturazielId = $fakturazielId;
        $this->positionName = $positionName;
        $this->locationName = $locationName;
        $this->orderPurchaseKey = $orderPurchaseKey;
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return string|null
     */
    public function getAngebotsposition(): ?string
    {
        return $this->angebotsposition;
    }

    /**
     * @return float|null
     */
    public function getEinzelpreisDtts(): ?float
    {
        return $this->einzelpreisDtts;
    }

    /**
     * @return float|null
     */
    public function getMenge(): ?float
    {
        return $this->menge;
    }

    /**
     * @return int|null
     */
    public function getAngebotspositionId(): ?int
    {
        return $this->angebotspositionId;
    }

    /**
     * @return string|null
     */
    public function getIcpKontBpos(): ?string
    {
        return $this->icpKontBpos;
    }

    /**
     * @return string|null
     */
    public function getIcpKontKontoId(): ?string
    {
        return $this->icpKontKontoId;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return string
     */
    public function getFakturaziel(): string
    {
        return $this->fakturaziel;
    }


    /**
     * @return int|null
     */
    public function getLbuId(): ?int
    {
        return $this->lbuId;
    }

    /**
     * @return string|null
     */
    public function getLeistungsort(): ?string
    {
        return $this->leistungsort;
    }

    /**
     * @return DateTime|null
     */
    public function getLeistungszeitpunkt(): ?DateTime
    {
        return $this->leistungszeitpunkt;
    }

    /**
     * @return int|null
     */
    public function getMatNr(): ?int
    {
        return $this->matNr;
    }

    /**
     * @return string|null
     */
    public function getTicketNr(): ?string
    {
        return $this->ticketNr;
    }

    /**
     * @return string|null
     */
    public function getPspElement(): ?string
    {
        return $this->pspElement;
    }

    /**
     * @return string|null
     */
    public function getQuellsystemId(): ?string
    {
        return $this->quellsystemId;
    }

    /**
     * @return bool
     */
    public function hasAngebotsposition(): bool
    {
        return $this->angebotsposition !== null;
    }

    /**
     * @return bool
     */
    public function hasAngebotspositionId(): bool
    {
        return $this->angebotspositionId !== null;
    }

    /**
     * @return bool
     */
    public function hasEinzelpreisDtts(): bool
    {
        return $this->einzelpreisDtts !== null;
    }

    /**
     * @return bool
     */
    public function hasIcpKontBpos(): bool
    {
        return $this->icpKontBpos !== null;
    }

    /**
     * @return int
     */
    public function getLeistungsMonat(): int
    {
        return $this->leistungsMonat;
    }

    /**
     * @return int
     */
    public function getLeistungsJahr(): int
    {
        return $this->leistungsJahr;
    }

    /**
     * @return int
     */
    public function getFakturazielId(): int
    {
        return $this->fakturazielId;
    }

    /**
     * @return int
     */
    public function getDebitorId(): int
    {
        return $this->debitorId;
    }

    /**
     * @return string|null
     */
    public function getPositionName(): ?string
    {
        return $this->positionName;
    }

    /**
     * @return string|null
     */
    public function getLocationName(): ?string
    {
        return $this->locationName;
    }

    /**
     * @return string|null
     */
    public function getOrderPurchaseKey(): ?string
    {
        return $this->orderPurchaseKey;
    }
}
