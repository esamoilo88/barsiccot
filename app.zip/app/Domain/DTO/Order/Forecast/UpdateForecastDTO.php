<?php

namespace App\Domain\DTO\Order\Forecast;

use App\Domain\ValueObjects\SIN;

class UpdateForecastDTO
{
    private SIN $sin;
    private array $forecast;
    private array $monthsList;

    /**
     * UpdateForecastDTO constructor.
     * @param SIN $sin
     * @param array $forecast
     * @param array $monthsList
     */
    public function __construct(SIN $sin, array $forecast, array $monthsList)
    {
        $this->sin = $sin;
        $this->forecast = $forecast;
        $this->monthsList = $monthsList;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return array
     */
    public function getForecast(): array
    {
        return $this->forecast;
    }

    /**
     * @return array
     */
    public function getMonthsList(): array
    {
        return $this->monthsList;
    }
}
