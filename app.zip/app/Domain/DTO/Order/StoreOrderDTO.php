<?php

namespace App\Domain\DTO\Order;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Entities\OfferProfitcenterSettings;
use App\Domain\Entities\SalesAnfrage;
use App\Domain\Entities\SalesVersionierung;
use DateTime;

class StoreOrderDTO
{
    private SalesVersionierung $simple;
    private OfferAngebotVk $vkVersions;
    private SalesAnfrage $afVersions;
    private DateTime $auftragsdatum;
    private ?BackendBenutzer $avMember;
    private ?string $sapAuftragsNr;
    private ?int $debitorId;
    private ?OfferProfitcenterSettings $profitcenterSettings;
    private ?bool $lbuAutoCreation;
    private ?bool $lbuAutoSend;
    private ?bool $lbuAutoConfirm;
    private ?bool $dauerfreigabe;
    private ?int $auftragswahrscheinlichkeit;
    private ?DateTime $vertragsbeginn;
    private ?DateTime $vertragsende;
    private ?DateTime $rolloutbeginn;
    private ?DateTime $rolloutende;
    private ?DateTime $betriebsbeginn;
    private ?DateTime $betriebsende;
    private ?DateTime $beauftragungsende;
    private ?array $apIds;
    private ?array $attachedfile;
    private bool $preorder;

    /**
     * StoreOrderDTO constructor.
     * @param SalesVersionierung $simple
     * @param OfferAngebotVk $vkVersions
     * @param SalesAnfrage $afVersions
     * @param DateTime $auftragsdatum
     * @param BackendBenutzer|null $avMember
     * @param string|null $sapAuftragsNr
     * @param int|null $debitorId
     * @param OfferProfitcenterSettings|null $profitcenterSettings
     * @param bool|null $lbuAutoCreation
     * @param bool|null $lbuAutoSend
     * @param bool|null $lbuAutoConfirm
     * @param bool|null $dauerfreigabe
     * @param int|null $auftragswahrscheinlichkeit
     * @param DateTime|null $vertragsbeginn
     * @param DateTime|null $vertragsende
     * @param DateTime|null $rolloutbeginn
     * @param DateTime|null $rolloutende
     * @param DateTime|null $betriebsbeginn
     * @param DateTime|null $betriebsende
     * @param DateTime|null $beauftragungsende
     * @param array|null $apIds
     * @param array|null $attachedfile
     * @param bool $preorder
     */
    public function __construct(
        SalesVersionierung $simple,
        OfferAngebotVk $vkVersions,
        SalesAnfrage $afVersions,
        DateTime $auftragsdatum,
        ?BackendBenutzer $avMember,
        ?string $sapAuftragsNr,
        ?int $debitorId,
        ?OfferProfitcenterSettings $profitcenterSettings,
        ?bool $lbuAutoCreation,
        ?bool $lbuAutoSend,
        ?bool $lbuAutoConfirm,
        ?bool $dauerfreigabe,
        ?int $auftragswahrscheinlichkeit,
        ?DateTime $vertragsbeginn,
        ?DateTime $vertragsende,
        ?DateTime $rolloutbeginn,
        ?DateTime $rolloutende,
        ?DateTime $betriebsbeginn,
        ?DateTime $betriebsende,
        ?DateTime $beauftragungsende,
        ?array $apIds,
        ?array $attachedfile,
        bool $preorder = false
    )
    {
        $this->simple = $simple;
        $this->vkVersions = $vkVersions;
        $this->afVersions = $afVersions;
        $this->auftragsdatum = $auftragsdatum;
        $this->avMember = $avMember;
        $this->sapAuftragsNr = $sapAuftragsNr;
        $this->debitorId = $debitorId;
        $this->profitcenterSettings = $profitcenterSettings;
        $this->lbuAutoCreation = $lbuAutoCreation;
        $this->lbuAutoSend = $lbuAutoSend;
        $this->lbuAutoConfirm = $lbuAutoConfirm;
        $this->dauerfreigabe = $dauerfreigabe;
        $this->auftragswahrscheinlichkeit = $auftragswahrscheinlichkeit;
        $this->vertragsbeginn = $vertragsbeginn;
        $this->vertragsende = $vertragsende;
        $this->rolloutbeginn = $rolloutbeginn;
        $this->rolloutende = $rolloutende;
        $this->betriebsbeginn = $betriebsbeginn;
        $this->betriebsende = $betriebsende;
        $this->beauftragungsende = $beauftragungsende;
        $this->apIds = $apIds;
        $this->attachedfile = $attachedfile;
        $this->preorder = $preorder;
    }

    /**
     * @return SalesVersionierung
     */
    public function getSalesVersionierung(): SalesVersionierung
    {
        return $this->simple;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getAVmember(): ?BackendBenutzer
    {
        return $this->avMember;
    }

    /**
     * @return OfferAngebotVk
     */
    public function getVkVersion(): OfferAngebotVk
    {
        return $this->vkVersions;
    }

    /**
     * @return SalesAnfrage
     */
    public function getAfVersions(): SalesAnfrage
    {
        return $this->afVersions;
    }

    /**
     * @return string|null
     */
    public function getSapAuftragsNr(): ?string
    {
        return $this->sapAuftragsNr;
    }

    /**
     * @return DateTime
     */
    public function getAauftragsdatum(): DateTime
    {
        return $this->auftragsdatum;
    }

    /**
     * @return int|null
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return OfferProfitcenterSettings|null
     */
    public function getProfitcenterSettings(): ?OfferProfitcenterSettings
    {
        return $this->profitcenterSettings;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoCreation(): ?bool
    {
        return $this->lbuAutoCreation;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoSend(): ?bool
    {
        return $this->lbuAutoSend;
    }

    /**
     * @return bool|null
     */
    public function getLbuAutoConfirm(): ?bool
    {
        return $this->lbuAutoConfirm;

    }

    /**
     * @return bool|null
     */
    public function getDauerfreigabe(): ?bool
    {
        return $this->dauerfreigabe;
    }

    /**
     * @return int|null
     */
    public function getAuftragswahrscheinlichkeit(): ?int
    {
        return $this->auftragswahrscheinlichkeit;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsbeginn(): ?DateTime
    {
        return $this->vertragsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getVertragsende(): ?DateTime
    {
        return $this->vertragsende;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsbeginn(): ?DateTime
    {
        return $this->betriebsbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getBetriebsende(): ?DateTime
    {
        return $this->betriebsende;
    }

    /**
     * @return DateTime|null
     */
    public function getBeauftragungsende(): ?DateTime
    {
        return $this->beauftragungsende;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutbeginn(): ?DateTime
    {
        return $this->rolloutbeginn;
    }

    /**
     * @return DateTime|null
     */
    public function getRolloutende(): ?DateTime
    {
        return $this->rolloutende;
    }

    /**
     * @return array|null
     */
    public function getAPids(): ?array
    {
        return $this->apIds;
    }

    /**
     * @return array|null
     */
    public function getAttachedfile(): ?array
    {
        return $this->attachedfile;
    }

    /**
     * @return bool
     */
    public function hasVertragsbeginn(): bool
    {
        return $this->vertragsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasVertragsende(): bool
    {
        return $this->vertragsende !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutbeginn(): bool
    {
        return $this->rolloutbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasRolloutende(): bool
    {
        return $this->rolloutende !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsende(): bool
    {
        return $this->betriebsende !== null;
    }

    /**
     * @return bool
     */
    public function hasBetriebsbeginn(): bool
    {
        return $this->betriebsbeginn !== null;
    }

    /**
     * @return bool
     */
    public function hasBeauftragungsende(): bool
    {
        return $this->beauftragungsende !== null;
    }

    /**
     * @return bool
     */
    public function hasAVmember(): bool
    {
        return $this->avMember !== null;
    }

    /**
     * @return bool
     */
    public function hasAPids(): bool
    {
        return $this->apIds !== null;
    }

    /**
     * @return bool
     */
    public function hasAttachedfile(): bool
    {
        return $this->attachedfile !== null;
    }

    /**
     * @return bool
     */
    public function isPreorder(): bool
    {
        return $this->preorder;
    }
}
