<?php

namespace App\Domain\DTO\Order;

use App\Domain\Entities\OfferAuftrag;
use DateTime;

class CreateFinanceOrderDTO
{
    private OfferAuftrag $offerAuftrag;
    private int $orderNumber;
    private bool $active;
    private ?DateTime $expire;
    private ?float $budget;
    private bool $isDefault;
    private ?string $filePath;

    /**
     * CreateFinanceOrderDTO constructor.
     * @param OfferAuftrag $offerAuftrag
     * @param int $orderNumber
     * @param bool $active
     * @param bool $isDefault
     * @param DateTime|null $expire
     * @param float|null $budget
     * @param string|null $filePath
     */
    public function __construct(
        OfferAuftrag $offerAuftrag,
        int $orderNumber,
        bool $active,
        bool $isDefault,
        ?DateTime $expire,
        ?float $budget,
        ?string $filePath
    )
    {
        $this->offerAuftrag = $offerAuftrag;
        $this->orderNumber = $orderNumber;
        $this->active = $active;
        $this->expire = $expire;
        $this->budget = $budget;
        $this->isDefault = $isDefault;
        $this->filePath = $filePath;
    }

    /**
     * @return int
     */
    public function getOrderNumber(): int
    {
        return $this->orderNumber;
    }

    /**
     * @return float|null
     */
    public function getBudget(): ?float
    {
        return $this->budget;
    }

    /**
     * @return DateTime|null
     */
    public function getExpire(): ?DateTime
    {
        return $this->expire;
    }

    /**
     * @return OfferAuftrag
     */
    public function getOfferAuftrag(): OfferAuftrag
    {
        return $this->offerAuftrag;
    }

    /**
     * @param string|null $budget
     */
    public function setBudget(?string $budget): void
    {
        $this->budget = $budget;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * @return bool
     */
    public function isDefault(): bool
    {
        return $this->isDefault;
    }

    /**
     * @return string|null
     */
    public function getFilePath(): ?string
    {
        return $this->filePath;
    }
}
