<?php

namespace App\Domain\DTO\Order\Einstellungen\Automatisierung;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendGroup;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class StoreFakturaplanDTO
{
    private int $simpleId;
    private int $lbuId;
    private ?string $at;
    private ?string $ultimo;
    private ?string $createAT;
    private ?string $createUltimo;
    private bool $autoCreate;
    private bool $autoSend;
    private int $offsetPeriod;
    private ?int $financeOrderId;
    private ?BackendGroup $group;
    private ?BackendBenutzer $benutzer;

    /**
     * StoreFakturaplanDTO constructor.
     * @param int $simpleId
     * @param int $lbuId
     * @param string|null $at
     * @param string|null $ultimo
     * @param string|null $createAT
     * @param string|null $createUltimo
     * @param bool $autoCreate
     * @param bool $autoSend
     * @param int $offsetPeriod
     * @param int|null $financeOrderId
     * @param BackendGroup|null $group
     * @param BackendBenutzer|null $benutzer
     */
    public function __construct(
        int $simpleId,
        int $lbuId,
        ?string $at,
        ?string $ultimo,
        ?string $createAT,
        ?string $createUltimo,
        bool $autoCreate,
        bool $autoSend,
        int $offsetPeriod,
        ?int $financeOrderId,
        ?BackendGroup $group = null,
        ?BackendBenutzer $benutzer = null
    )
    {
        $this->simpleId = $simpleId;
        $this->lbuId = $lbuId;
        $this->at = $at;
        $this->ultimo = $ultimo;
        $this->createAT =$createAT;
        $this->createUltimo =$createUltimo;
        $this->autoCreate = $autoCreate;
        $this->autoSend = $autoSend;
        $this->offsetPeriod = $offsetPeriod;
        $this->financeOrderId = $financeOrderId;
        $this->group = $group;
        $this->benutzer = $benutzer;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSIN(): SIN
    {
        return new SIN($this->simpleId);
    }

    /**
     * @return int
     */
    public function getLbuId(): int
    {
        return $this->lbuId;
    }

    /**
     * @return string|null
     */
    public function getAt(): ?string
    {
        return $this->at;
    }

    /**
     * @return string|null
     */
    public function getUltimo(): ?string
    {
        return $this->ultimo;
    }

    /**
     * @return string|null
     */
    public function getCreateAT(): ?string
    {
        return $this->createAT;
    }

    /**
     * @return string|null
     */
    public function getCreateUltimo(): ?string
    {
        return $this->createUltimo;
    }

    /**
     * @return bool
     */
    public function getAutoCreate(): bool
    {
        return $this->autoCreate;
    }

    /**
     * @return bool
     */
    public function getAutoSendOrBill(): bool
    {
        return $this->autoSend;
    }

    /**
     * @return int
     */
    public function getOffsetPeriod(): int
    {
        return $this->offsetPeriod;
    }

    /**
     * @return BackendGroup|null
     */
    public function getGroup(): ?BackendGroup
    {
        return $this->group;
    }

    /**
     * @return BackendBenutzer|null
     */
    public function getBenutzer(): ?BackendBenutzer
    {
        return $this->benutzer;
    }

    /**
     * @return bool
     */
    public function hasAutoCreate(): bool
    {
        return $this->autoCreate !== null;
    }

    /**
     * @return bool
     */
    public function hasGroup(): bool
    {
        return $this->group !== null;
    }

    /**
     * @return bool
     */
    public function hasBenutzer(): bool
    {
        return $this->benutzer !== null;
    }
    /**
     * @return bool
     */
    public function hasAutoSendOrBill(): bool
    {
        return $this->autoSend !== null;
    }

    /**
     * @return bool
     */
    public function hasUltimo(): bool
    {
        return $this->ultimo !== null;
    }

    /**
     * @return bool
     */
    public function hasAt(): bool
    {
        return $this->at !== null;
    }

    /**
     * @return bool
     */
    public function hasCreateAT(): bool
    {
        return $this->createAT !== null;
    }

    /**
     * @return bool
     */
    public function hasCreateUltimo(): bool
    {
        return $this->createUltimo !== null;
    }

    /**
     * @return int|null
     */
    public function getFinanceOrderId(): ?int
    {
        return $this->financeOrderId;
    }
}

