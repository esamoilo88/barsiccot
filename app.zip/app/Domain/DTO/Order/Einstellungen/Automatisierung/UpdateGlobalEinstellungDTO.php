<?php

namespace App\Domain\DTO\Order\Einstellungen\Automatisierung;

use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class UpdateGlobalEinstellungDTO
{
    private int $simple;
    private ?bool $autoApprove;
    private ?bool $autoForecast;
    private ?bool $autoAbgrenzung;
    private ?bool $autoIlv;
    private ?bool $planIlv;
    private ?bool $autoBill;

    /**
     * UpdateGlobalEinstellungDTO constructor.
     * @param int $simple
     * @param bool|null $autoApprove
     * @param bool|null $autoForecast
     * @param bool|null $autoAbgrenzung
     * @param bool|null $autoIlv
     * @param bool|null $planIlv
     * @param bool|null $autoBill
     */
    public function __construct(
        int $simple,
        ?bool $autoApprove,
        ?bool $autoForecast,
        ?bool $autoAbgrenzung,
        ?bool $autoIlv,
        ?bool $planIlv,
        ?bool $autoBill = null
    )
    {
        $this->simple = $simple;
        $this->autoApprove = $autoApprove;
        $this->autoForecast = $autoForecast;
        $this->autoAbgrenzung = $autoAbgrenzung;
        $this->autoIlv = $autoIlv;
        $this->planIlv = $planIlv;
        $this->autoBill = $autoBill;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSIN(): SIN
    {
        return new SIN($this->simple);
    }

    /**
     * @return bool|null
     */
    public function getAutoForecast(): ?bool
    {
        return $this->autoForecast;
    }

    /**
     * @return bool|null
     */
    public function isAutoApprove(): ?bool
    {
        return $this->autoApprove;
    }

    /**
     * @return bool|null
     */
    public function getAutoAbgrenzung(): ?bool
    {
        return $this->autoAbgrenzung;
    }

    /**
     * @return bool
     */
    public function hasAutoForecast(): bool
    {
        return $this->autoForecast !== null;
    }

    /**
     * @return bool
     */
    public function hasAutoAbgrenzung(): bool
    {
        return $this->autoAbgrenzung !== null;
    }

    /**
     * @return bool
     */
    public function hasAutoApprove(): bool
    {
        return $this->autoApprove !== null;
    }

    /**
     * @return bool
     */
    public function hasAutoIlv(): bool
    {
        return $this->autoIlv !== null;
    }

    /**
     * @return bool
     */
    public function hasPlanIlv(): bool
    {
        return $this->planIlv !== null;
    }

    /**
     * @return bool|null
     */
    public function getAutoIlv(): ?bool
    {
        return $this->autoIlv;
    }

    /**
     * @return bool|null
     */
    public function getPlanIlv(): ?bool
    {
        return $this->planIlv;
    }

    /**
     * @return bool|null
     */
    public function isAutoBill(): ?bool
    {
        return $this->autoBill;
    }
}

