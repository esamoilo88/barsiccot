<?php

namespace App\Domain\DTO\Order\Einstellungen\Automatisierung;

use App\Domain\ValueObjects\SIN;
use App\Exceptions\Business\InvalidSinException;

class UpdateSystemAutomationDTO
{
    private int $simpleId;
    private ?string $at;
    private ?string $ultimo;
    private ?bool $autoCreate;
    private ?bool $autoSendOrBill;
    private ?bool $autoIlv;
    private ?bool $billAfterDeadline;
    private ?array $quellSystem;

    /**
     * UpdateSystemAutomationDTO constructor.
     * @param int $simpleId
     * @param string|null $at
     * @param string|null $ultimo
     * @param bool|null $autoCreate
     * @param bool|null $autoSendOrBill
     * @param bool|null $autoIlv
     * @param bool|null $billAfterDeadline
     * @param array|null $quellSystem
     */
    public function __construct(
        int $simpleId,
        ?string $at,
        ?string $ultimo,
        ?bool $autoCreate,
        ?bool $autoSendOrBill,
        ?bool $autoIlv,
        ?bool $billAfterDeadline,
        ?array $quellSystem
    )
    {
        $this->simpleId = $simpleId;
        $this->at = $at;
        $this->ultimo =$ultimo;
        $this->autoCreate = $autoCreate;
        $this->autoSendOrBill = $autoSendOrBill;
        $this->autoIlv = $autoIlv;
        $this->billAfterDeadline = $billAfterDeadline;
        $this->quellSystem =$quellSystem;
    }

    /**
     * @return SIN
     * @throws InvalidSinException
     */
    public function getSIN(): SIN
    {
        return new SIN($this->simpleId);
    }

    /**
     * @return string|null
     */
    public function getAt(): ?string
    {
        return $this->at;
    }

    /**
     * @return string|null
     */
    public function getUltimo(): ?string
    {
        return $this->ultimo;
    }

    /**
     * @return bool|null
     */
    public function getAutoCreate(): ?bool
    {
        return $this->autoCreate;
    }

    /**
     * @return bool|null
     */
    public function getAutoSendOrBill(): ?bool
    {
        return $this->autoSendOrBill;
    }

    /**
     * @return bool|null
     */
    public function getAutoIlv(): ?bool
    {
        return $this->autoIlv;
    }

    /**
     * @return bool|null
     */
    public function getBillAfterDeadline(): ?bool
    {
        return $this->billAfterDeadline;
    }

    /**
     * @return array|null
     */
    public function getQuellSystem(): ?array
    {
        return $this->quellSystem;
    }

    /**
     * @return bool
     */
    public function hasAutoCreate(): bool
    {
        return $this->autoCreate !== null;
    }

    /**
     * @return bool
     */
    public function hasAutoSendOrBill(): bool
    {
        return $this->autoSendOrBill !== null;
    }

    /**
     * @return bool
     */
    public function hasAutoIlv(): bool
    {
        return $this->autoIlv !== null;
    }

    /**
     * @return bool
     */
    public function hasBillAfterDeadline(): bool
    {
        return $this->billAfterDeadline !== null;
    }

    /**
     * @return bool
     */
    public function hasUltimo(): bool
    {
        return $this->ultimo !== null;
    }

    /**
     * @return bool
     */
    public function hasAt(): bool
    {
        return $this->at !== null;
    }

    /**
     * @return bool
     */
    public function hasQuellSystem(): bool
    {
        return $this->quellSystem !== null;
    }
}

