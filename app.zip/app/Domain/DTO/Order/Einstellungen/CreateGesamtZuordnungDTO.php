<?php

namespace App\Domain\DTO\Order\Einstellungen;

use App\Domain\Entities\CostsKostenart;
use App\Domain\Entities\CostsKostenstelle;

class CreateGesamtZuordnungDTO
{
    private CostsKostenart $kostenart;
    private ?CostsKostenstelle $kostenstelle;

    /**
     * CreateGesamtZuordnungDTO constructor.
     * @param CostsKostenart $kostenart
     * @param CostsKostenstelle|null $kostenstelle
     */
    public function __construct(CostsKostenart $kostenart, ?CostsKostenstelle $kostenstelle)
    {
        $this->kostenart = $kostenart;
        $this->kostenstelle = $kostenstelle;
    }

    /**
     * @return CostsKostenart
     */
    public function getKostenart(): CostsKostenart
    {
        return $this->kostenart;
    }

    /**
     * @return ?CostsKostenstelle
     */
    public function getKostenstelle(): ?CostsKostenstelle
    {
        return $this->kostenstelle;
    }

    /**
     * @return bool
     */
    public function hasKostenstelle(): bool
    {
        return $this->kostenstelle !== null;
    }
}