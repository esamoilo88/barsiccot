<?php

namespace App\Domain\DTO\Order\Einstellungen;

use DateTime;

class UpdateFinanceOrderDTO
{
    private int $orderNumber;
    private bool $active = true;
    private ?DateTime $expire = null;
    private ?float $budget = null;
    private ?string $filePath = null;

    /**
     * UpdateFinanceOrderDTO constructor.
     * @param int $orderNumber
     * @param bool $active
     * @param DateTime|null $expire
     * @param float|null $budget
     * @param string|null $filePath
     */
    public function __construct(
        int $orderNumber,
        bool $active,
        ?DateTime $expire,
        ?float $budget,
        ?string $filePath
    )
    {
        $this->orderNumber = $orderNumber;
        $this->active = $active;
        $this->expire = $expire;
        $this->budget = $budget;
        $this->filePath = $filePath;
    }

    /**
     * @return int
     */
    public function getOrderNumber(): int
    {
        return $this->orderNumber;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * @return DateTime|null
     */
    public function getExpire(): ?DateTime
    {
        return $this->expire;
    }

    /**
     * @return float|null
     */
    public function getBudget(): ?float
    {
        return $this->budget;
    }

    /**
     * @return string|null
     */
    public function getFilePath(): ?string
    {
        return $this->filePath;
    }
}
