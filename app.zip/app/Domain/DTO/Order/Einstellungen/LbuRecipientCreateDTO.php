<?php

namespace App\Domain\DTO\Order\Einstellungen;

class LbuRecipientCreateDTO
{
    private string $email;
    private string $vorname;
    private string $nachname;
    private int $type;

    /**
     * LbuRecipientCreateDTO constructor.
     * @param string $email
     * @param string $vorname
     * @param string $nachname
     * @param int $type
     */
    public function __construct(string $email, string $vorname, string $nachname, int $type)
    {
        $this->email = $email;
        $this->vorname = $vorname;
        $this->nachname = $nachname;
        $this->type = $type;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return string
     */
    public function getVorname(): string
    {
        return $this->vorname;
    }

    /**
     * @return string
     */
    public function getNachname(): string
    {
        return $this->nachname;
    }

    /**
     * @return int
     */
    public function getType(): int
    {
        return $this->type;
    }
}