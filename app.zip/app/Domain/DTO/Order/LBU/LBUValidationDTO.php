<?php

namespace App\Domain\DTO\Order\LBU;

use App\Domain\ValueObjects\SIN;

class LBUValidationDTO
{
    private SIN $sin;
    private ?int $leistungsJahr;
    private ?int $leistungsMonat;
    private ?int $fakturaJahr;
    private ?int $fakturaMonat;
    private ?int $fakturazielId;
    private ?int $debitorId;
    private ?string $sapBestellnummer;
    private ?string $rechnungsnummer;
    private ?int $vorgangstypId;
    private ?int $creditReasonId;
    private ?string $billingSubjectExtension;
    private ?int $ansprechpartnerId;

    /**
     * LBUValidationDTO constructor.
     * @param SIN $sin
     * @param int|null $leistungsJahr
     * @param int|null $leistungsMonat
     * @param int|null $fakturaJahr
     * @param int|null $fakturaMonat
     * @param int|null $fakturazielId
     * @param int|null $debitorId
     * @param string|null $sapBestellnummer
     * @param string|null $rechnungsnummer
     * @param int|null $vorgangstypId
     * @param int|null $creditReasonId
     * @param string|null $billingSubjectExtension
     * @param int|null $ansprechpartnerId
     */
    public function __construct(
        SIN $sin,
        ?int $leistungsJahr = null,
        ?int $leistungsMonat = null,
        ?int $fakturaJahr = null,
        ?int $fakturaMonat = null,
        ?int $fakturazielId = null,
        ?int $debitorId = null,
        ?string $sapBestellnummer = null,
        ?string $rechnungsnummer = null,
        ?int $vorgangstypId = null,
        ?int $creditReasonId = null,
        ?string $billingSubjectExtension = null,
        ?int $ansprechpartnerId = null
    )
    {
        $this->sin = $sin;
        $this->leistungsJahr = $leistungsJahr;
        $this->leistungsMonat = $leistungsMonat;
        $this->fakturaJahr = $fakturaJahr;
        $this->fakturaMonat = $fakturaMonat;
        $this->fakturazielId = $fakturazielId;
        $this->debitorId = $debitorId;
        $this->sapBestellnummer = $sapBestellnummer;
        $this->rechnungsnummer = $rechnungsnummer;
        $this->vorgangstypId = $vorgangstypId;
        $this->creditReasonId = $creditReasonId;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->ansprechpartnerId = $ansprechpartnerId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int|null
     */
    public function getLeistungsJahr(): ?int
    {
        return $this->leistungsJahr;
    }

    /**
     * @return int|null
     */
    public function getLeistungsMonat(): ?int
    {
        return $this->leistungsMonat;
    }

    /**
     * @return int|null
     */
    public function getFakturaJahr(): ?int
    {
        return $this->fakturaJahr;
    }

    /**
     * @return int|null
     */
    public function getFakturaMonat(): ?int
    {
        return $this->fakturaMonat;
    }

    /**
     * @return int|null
     */
    public function getFakturazielId(): ?int
    {
        return $this->fakturazielId;
    }

    /**
     * @return int|null
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return int|null
     */
    public function getVorgangstypId(): ?int
    {
        return $this->vorgangstypId;
    }

    /**
     * @return int|null
     */
    public function getCreditReasonId(): ?int
    {
        return $this->creditReasonId;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return int|null
     */
    public function getAnsprechpartnerId(): ?int
    {
        return $this->ansprechpartnerId;
    }
}
