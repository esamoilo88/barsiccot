<?php

namespace App\Domain\DTO\Order\LBU;

use App\Domain\Entities\OfferFakturaLbu;

class LBUCreateReturnDTO
{
    private array $errors;
    private ?OfferFakturaLbu $lbu;

    /**
     * LBUCreateReturnDTO constructor.
     * @param array $errors
     * @param OfferFakturaLbu|null $lbu
     */
    public function __construct(array $errors, ?OfferFakturaLbu $lbu)
    {
        $this->errors = $errors;
        $this->lbu = $lbu;
    }

    /**
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * @return OfferFakturaLbu|null
     */
    public function getLbu(): ?OfferFakturaLbu
    {
        return $this->lbu;
    }

    /**
     * @return bool
     */
    public function hasErrors(): bool
    {
        return $this->errors !== [];
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            $this->errors,
            $this->lbu
        ];
    }
}