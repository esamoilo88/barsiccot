<?php

namespace App\Domain\DTO\Order\LBU;

use App\Domain\Entities\Interfaces\Absender;
use App\Domain\ValueObjects\SIN;

class LBUCreateDTO
{
    private SIN $sin;
    private ?int $leistungsMonth;
    private ?int $leistungsYear;
    private ?int $fakturaMonth;
    private ?int $fakturaYear;
    private ?int $vorgangstypId;
    private ?int $fakturazielId;
    private Absender $ansprechpartner;
    private ?bool $abgrenzung;
    private ?int $createdById;
    private ?int $debitorId;
    private ?string $bestellnummer;
    private ?int $creditReasonId;
    private ?string $rechnungsnummer;
    private ?string $billingSubjectExtension;
    private ?string $kommentar;

    /**
     * LBUCreateDTO constructor.
     * @param SIN $sin
     * @param int|null $leistungsMonth
     * @param int|null $leistungsYear
     * @param int|null $fakturaMonth
     * @param int|null $fakturaYear
     * @param int|null $vorgangstypId
     * @param int|null $fakturazielId
     * @param Absender $ansprechpartner
     * @param bool $abgrenzung
     * @param int|null $createdById
     * @param int|null $debitorId
     * @param string|null $bestellnummer
     * @param int|null $creditReasonId
     * @param string|null $rechnungsnummer
     * @param string|null $billingSubjectExtension
     * @param string|null $kommentar
     */
    public function __construct(
        SIN $sin,
        ?int $leistungsMonth,
        ?int $leistungsYear,
        ?int $fakturaMonth,
        ?int $fakturaYear,
        ?int $vorgangstypId,
        ?int $fakturazielId,
        Absender $ansprechpartner,
        ?bool $abgrenzung,
        ?int $createdById,
        ?int $debitorId,
        ?string $bestellnummer,
        ?int $creditReasonId = null,
        ?string $rechnungsnummer = null,
        ?string $billingSubjectExtension = null,
        ?string $kommentar = null
    )
    {
        $this->sin = $sin;
        $this->leistungsMonth = $leistungsMonth;
        $this->leistungsYear = $leistungsYear;
        $this->fakturaMonth = $fakturaMonth;
        $this->fakturaYear = $fakturaYear;
        $this->vorgangstypId = $vorgangstypId;
        $this->fakturazielId = $fakturazielId;
        $this->ansprechpartner = $ansprechpartner;
        $this->abgrenzung = $abgrenzung;
        $this->createdById = $createdById;
        $this->debitorId = $debitorId;
        $this->bestellnummer = $bestellnummer;
        $this->creditReasonId = $creditReasonId;
        $this->rechnungsnummer = $rechnungsnummer;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->kommentar = $kommentar;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getLeistungsMonth(): ?int
    {
        return $this->leistungsMonth;
    }

    /**
     * @return int
     */
    public function getLeistungsYear(): ?int
    {
        return $this->leistungsYear;
    }

    /**
     * @return int
     */
    public function getFakturaMonth(): ?int
    {
        return $this->fakturaMonth;
    }

    /**
     * @return int
     */
    public function getFakturaYear(): ?int
    {
        return $this->fakturaYear;
    }

    /**
     * @return int
     */
    public function getVorgangstypId(): ?int
    {
        return $this->vorgangstypId;
    }

    /**
     * @return int
     */
    public function getFakturazielId(): ?int
    {
        return $this->fakturazielId;
    }

    /**
     * @return Absender
     */
    public function getAnsprechpartner(): Absender
    {
        return $this->ansprechpartner;
    }

    /**
     * @return bool
     */
    public function isAbgrenzung(): ?bool
    {
        return $this->abgrenzung;
    }

    /**
     * @return int|null
     */
    public function getCreditReasonId(): ?int
    {
        return $this->creditReasonId;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return int|null
     */
    public function getCreatedById(): ?int
    {
        return $this->createdById;
    }

    /**
     * @return int
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return string
     */
    public function getBestellnummer(): ?string
    {
        return $this->bestellnummer;
    }
}
