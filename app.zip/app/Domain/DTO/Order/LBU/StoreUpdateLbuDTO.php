<?php

namespace App\Domain\DTO\Order\LBU;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\FinanceCreditReason;
use App\Domain\Entities\Interfaces\Absender;
use App\Domain\Entities\OfferFakturaFakturaziel;
use App\Domain\Entities\OfferFakturaVorgangstyp;
use App\Domain\ValueObjects\SIN;

class StoreUpdateLbuDTO
{
    private SIN $sin;
    private int $leistungsMonth;
    private int $leistungsYear;
    private OfferFakturaVorgangstyp $vorgangstyp;
    private ?FinanceCreditReason $creditReason;
    private OfferFakturaFakturaziel $fakturaziel;
    private Absender $ansprechpartner;
    private ?string $rechnungsnummer;
    private ?string $billingSubjectExtension;
    private bool $abgrenzung;
    private ?string $kommentar;
    private ?int $sapBestellnummer;

    /**
     * StoreUpdateLbuDTO constructor.
     * @param SIN $sin
     * @param int $leistungsMonth
     * @param int $leistungsYear
     * @param OfferFakturaVorgangstyp $vorgangstyp
     * @param FinanceCreditReason|null $creditReason
     * @param OfferFakturaFakturaziel $fakturaziel
     * @param Absender $ansprechpartner
     * @param string|null $rechnungsnummer
     * @param string|null $billingSubjectExtension
     * @param bool $abgrenzung
     * @param string|null $kommentar
     * @param int|null $sapBestellnummer
     */
    public function __construct(
        SIN $sin,
        int $leistungsMonth,
        int $leistungsYear,
        OfferFakturaVorgangstyp $vorgangstyp,
        ?FinanceCreditReason $creditReason,
        OfferFakturaFakturaziel $fakturaziel,
        Absender $ansprechpartner,
        ?string $rechnungsnummer,
        ?string $billingSubjectExtension,
        bool $abgrenzung,
        ?string $kommentar,
        ?int $sapBestellnummer
    )
    {
        $this->sin = $sin;
        $this->leistungsMonth = $leistungsMonth;
        $this->leistungsYear = $leistungsYear;
        $this->vorgangstyp = $vorgangstyp;
        $this->creditReason = $creditReason;
        $this->fakturaziel = $fakturaziel;
        $this->ansprechpartner = $ansprechpartner;
        $this->rechnungsnummer = $rechnungsnummer;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->abgrenzung = $abgrenzung;
        $this->kommentar = $kommentar;
        $this->sapBestellnummer = $sapBestellnummer;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getLeistungsMonth(): int
    {
        return $this->leistungsMonth;
    }

    /**
     * @return int
     */
    public function getLeistungsYear(): int
    {
        return $this->leistungsYear;
    }

    /**
     * @return OfferFakturaVorgangstyp
     */
    public function getVorgangstyp(): OfferFakturaVorgangstyp
    {
        return $this->vorgangstyp;
    }

    /**
     * @return FinanceCreditReason|null
     */
    public function getCreditReason(): ?FinanceCreditReason
    {
        return $this->creditReason;
    }

    /**
     * @return OfferFakturaFakturaziel
     */
    public function getFakturaziel(): OfferFakturaFakturaziel
    {
        return $this->fakturaziel;
    }

    /**
     * @return Absender
     */
    public function getAnsprechpartner(): Absender
    {
        return $this->ansprechpartner;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return bool
     */
    public function isAbgrenzung(): bool
    {
        return $this->abgrenzung;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return int|null
     */
    public function getSapBestellnummer(): ?int
    {
        return $this->sapBestellnummer;
    }
}
