<?php

namespace App\Domain\DTO\Order\LBU;

use App\Domain\Entities\FinanceCreditReason;
use App\Domain\Entities\OfferFakturaVorgangstyp;
use App\Domain\ValueObjects\SIN;

class CopyLbuDTO
{
    private SIN $sin;
    private int $leistungsMonth;
    private int $leistungsYear;
    private OfferFakturaVorgangstyp $vorgangstyp;
    private ?FinanceCreditReason $creditReason;
    private ?string $rechnungsnummer;
    private ?string $billingSubjectExtension;
    private ?string $kommentar;
    private ?int $sapBestellnummer;

    /**
     * StoreLbuDTO constructor.
     * @param SIN $sin
     * @param int $leistungsMonth
     * @param int $leistungsYear
     * @param OfferFakturaVorgangstyp|object $vorgangstyp
     * @param FinanceCreditReason|null|object $creditReason
     * @param string|null $rechnungsnummer
     * @param string|null $billingSubjectExtension
     * @param string|null $kommentar
     * @param int|null $sapBestellnummer
     */
    public function __construct(
        SIN $sin,
        int $leistungsMonth,
        int $leistungsYear,
        OfferFakturaVorgangstyp $vorgangstyp,
        ?FinanceCreditReason $creditReason,
        ?string $rechnungsnummer,
        ?string $billingSubjectExtension,
        ?string $kommentar,
        ?int $sapBestellnummer
    )
    {
        $this->sin = $sin;
        $this->leistungsMonth = $leistungsMonth;
        $this->leistungsYear = $leistungsYear;
        $this->vorgangstyp = $vorgangstyp;
        $this->creditReason = $creditReason;
        $this->rechnungsnummer = $rechnungsnummer;
        $this->billingSubjectExtension = $billingSubjectExtension;
        $this->kommentar = $kommentar;
        $this->sapBestellnummer = $sapBestellnummer;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }

    /**
     * @return int
     */
    public function getLeistungsMonth(): int
    {
        return $this->leistungsMonth;
    }

    /**
     * @return int
     */
    public function getLeistungsYear(): int
    {
        return $this->leistungsYear;
    }

    /**
     * @return OfferFakturaVorgangstyp
     */
    public function getVorgangstyp(): OfferFakturaVorgangstyp
    {
        return $this->vorgangstyp;
    }

    /**
     * @return FinanceCreditReason|null
     */
    public function getCreditReason(): ?FinanceCreditReason
    {
        return $this->creditReason;
    }

    /**
     * @return string|null
     */
    public function getRechnungsnummer(): ?string
    {
        return $this->rechnungsnummer;
    }

    /**
     * @return string|null
     */
    public function getBillingSubjectExtension(): ?string
    {
        return $this->billingSubjectExtension;
    }

    /**
     * @return string|null
     */
    public function getKommentar(): ?string
    {
        return $this->kommentar;
    }

    /**
     * @return int|null
     */
    public function getSapBestellnummer(): ?int
    {
        return $this->sapBestellnummer;
    }
}
