<?php

namespace App\Domain\DTO\Configuration;


use App\Domain\Entities\OnkaConfigurationParam;

class UpdateConfigurationParamDTO
{
    private OnkaConfigurationParam $param;
    private $value;
    private ?array $selectedItemsIds;
    private ?array $previousItemsIds;

    /**
     * UpdateConfigurationParamDTO constructor.
     * @param OnkaConfigurationParam $param
     * @param $value
     * @param array|null $selectedItemsIds
     * @param array|null $previousItemsIds
     */
    public function __construct(
        OnkaConfigurationParam $param,
        $value,
        ?array $selectedItemsIds,
        ?array $previousItemsIds
    )
    {
        $this->param = $param;
        $this->value = $value;
        $this->selectedItemsIds = $selectedItemsIds;
        $this->previousItemsIds = $previousItemsIds;

    }

    /**
     * @return OnkaConfigurationParam
     */
    public function getParam(): OnkaConfigurationParam
    {
        return $this->param;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return array|null
     */
    public function getSelectedItemsIds(): ?array
    {
        return $this->selectedItemsIds;
    }

    /**
     * @return array|null
     */
    public function getPreviousItemsIds(): ?array
    {
        return $this->previousItemsIds;
    }

    /**
     * @param mixed $value
     */
    public function setValue($value): void
    {
        $this->value = $value;
    }
}
