<?php


namespace App\Domain\DTO\Configuration;


use App\Domain\Entities\OnkaConfiguration;

class EditConfigurationNameDTO
{
    private OnkaConfiguration $configuration;
    private string $name;

    /**
     * EditConfigurationNameDTO constructor.
     * @param OnkaConfiguration $configuration
     * @param string $name
     */
    public function __construct(
        OnkaConfiguration $configuration,
        string $name
    )
    {
        $this->configuration = $configuration;
        $this->name = $name;
    }

    /**
     * @return OnkaConfiguration
     */
    public function getConfiguration(): OnkaConfiguration
    {
        return $this->configuration;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }
}
