<?php

namespace App\Domain\DTO\Configuration;

use App\Domain\ValueObjects\SIN;

class CreateConfigurationDTO
{
    private int $configuratorId;
    private SIN $sin;

    /**
     * CreateConfigurationDTO constructor.
     * @param int $configuratorId
     * @param SIN $sin
     */
    public function __construct(int $configuratorId, SIN $sin)
    {
        $this->configuratorId = $configuratorId;
        $this->sin = $sin;
    }

    /**
     * @return int
     */
    public function getConfiguratorId(): int
    {
        return $this->configuratorId;
    }

    /**
     * @return SIN
     */
    public function getSin(): SIN
    {
        return $this->sin;
    }
}