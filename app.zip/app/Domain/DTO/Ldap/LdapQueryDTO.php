<?php

namespace App\Domain\DTO\Ldap;

use App\Exceptions\Application\ObjectPropertyIsNotSetException;

class LdapQueryDTO
{
    private string $name;
    private string $surname;
    private string $email;

    /**
     * LdapQueryDTO constructor.
     * @param string $query
     */
    public function __construct(string $query)
    {
        $this->setProperties($query);
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getName(): string
    {
        if ($this->name === null) {
            throw new ObjectPropertyIsNotSetException('name', self::class);
        }
        return $this->name;
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getSurname(): string
    {
        if ($this->surname === null) {
            throw new ObjectPropertyIsNotSetException('surname', self::class);
        }
        return $this->surname;
    }

    /**
     * @return string
     * @throws ObjectPropertyIsNotSetException
     */
    public function getEmail(): string
    {
        if ($this->email === null) {
            throw new ObjectPropertyIsNotSetException('email', self::class);
        }
        return $this->email;
    }

    /**
     * @return bool
     */
    public function hasEmail(): bool
    {
        return isset($this->email);
    }

    /**
     * @return bool
     */
    public function hasName(): bool
    {
        return isset($this->name);
    }

    /**
     * @return bool
     */
    public function hasSurname(): bool
    {
        return isset($this->surname);
    }

    /**
     * @param string $query
     */
    private function setProperties(string $query)
    {
        if (filter_var($query, FILTER_VALIDATE_EMAIL)) {
            $this->email = $query;
        } else if(str_contains($query, ',')) {
            $search = explode(',', $query);

            $this->surname = trim($search[0]);

            if(strlen(trim($search[1])) !== 0) {
                $this->name = trim($search[1]);
            }
        } else {
            $this->surname = $query;
        }
    }
}