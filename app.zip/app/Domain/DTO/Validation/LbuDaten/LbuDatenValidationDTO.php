<?php

namespace App\Domain\DTO\Validation\LbuDaten;

class LbuDatenValidationDTO
{
    private int $lbuDatenId;
    private ?int $debitorId;
    private ?string $sapBestellnummer;
    private ?string $icpKontPspKst;

    /**
     * LbuDatenValidationDTO constructor.
     * @param int $lbuDatenId
     * @param int|null $debitorId
     * @param string|null $sapBestellnummer
     * @param string|null $icpKontPspKst
     */
    public function __construct(int $lbuDatenId, ?int $debitorId, ?string $sapBestellnummer, ?string $icpKontPspKst)
    {
        $this->lbuDatenId = $lbuDatenId;
        $this->debitorId = $debitorId;
        $this->sapBestellnummer = $sapBestellnummer;
        $this->icpKontPspKst = $icpKontPspKst;
    }

    /**
     * @return int
     */
    public function getLbuDatenId(): int
    {
        return $this->lbuDatenId;
    }

    /**
     * @return int|null
     */
    public function getDebitorId(): ?int
    {
        return $this->debitorId;
    }

    /**
     * @return string|null
     */
    public function getSapBestellnummer(): ?string
    {
        return $this->sapBestellnummer;
    }

    /**
     * @return string|null
     */
    public function getIcpKontPspKst(): ?string
    {
        return $this->icpKontPspKst;
    }

}
