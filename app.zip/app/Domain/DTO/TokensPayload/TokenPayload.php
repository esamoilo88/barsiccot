<?php

namespace App\Domain\DTO\TokensPayload;

use App\Utils\SimpleSerializer\SimpleSerializer;

class TokenPayload
{
    /**
     * @return string
     */
    public function serialize(): string
    {
        return SimpleSerializer::create()->serialize($this, 'json');
    }
}
