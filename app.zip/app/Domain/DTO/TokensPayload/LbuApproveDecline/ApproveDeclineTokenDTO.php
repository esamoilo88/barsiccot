<?php

namespace App\Domain\DTO\TokensPayload\LbuApproveDecline;

use App\Domain\DTO\TokensPayload\ITokenPayload;
use App\Domain\DTO\TokensPayload\TokenPayload;

class ApproveDeclineTokenDTO extends TokenPayload implements ITokenPayload
{
    private int $simpleId;
    private array $lbuIds;
    private array $emails;

    /**
     * ApproveDeclineTokenDTO constructor.
     * @param int $simpleId
     * @param array $lbuIds
     * @param array $emails
     */
    public function __construct(int $simpleId, array $lbuIds, array $emails)
    {
        $this->simpleId = $simpleId;
        $this->lbuIds = $lbuIds;
        $this->emails = $emails;
    }

    /**
     * @param array|null $tokenPayload
     * @return ApproveDeclineTokenDTO
     * @throws \Exception
     */
    public static function createFromRequest(?array $tokenPayload): ApproveDeclineTokenDTO
    {
        if (!$tokenPayload) {
            throw new \Exception("Token payload is empty!");
        }

        if (!isset($tokenPayload['simpleId']) || !isset($tokenPayload['lbuIds']) || !isset($tokenPayload['emails'])) {
            throw new \Exception("Some token data is missing!");
        }

        return new static((int) $tokenPayload['simpleId'], $tokenPayload['lbuIds'], $tokenPayload['emails']);
    }

    /**
     * @return int
     */
    public function getSimpleId(): int
    {
        return $this->simpleId;
    }

    /**
     * @return array
     */
    public function getLbuIds(): array
    {
        return $this->lbuIds;
    }

    /**
     * @return array
     */
    public function getEmails(): array
    {
        return $this->emails;
    }
}
