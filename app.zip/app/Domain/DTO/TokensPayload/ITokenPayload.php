<?php

namespace App\Domain\DTO\TokensPayload;

interface ITokenPayload
{
    public static function createFromRequest(?array $tokenPayload): self;
}
