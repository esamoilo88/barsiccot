<?php

namespace App\Domain\Embedded;

use Doctrine\ORM\Mapping as ORM;

/**
 * Class Name
 * @package App\Domain\Embedded
 *
 * @ORM\Embeddable
 */
class Name
{
    /**
     * @ORM\Column(type="string")
     */
    private string $name;

    /**
     * Name constructor.
     * @param string $name
     */
    public function __construct(string $name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function value(): string
    {
        return $this->name;
    }
}
