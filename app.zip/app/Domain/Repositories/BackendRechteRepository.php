<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendRechte;
use App\Domain\Repositories\Interfaces\IBackendRechteRepository;
use App\Domain\Repositories\BaseRepository;
use FontLib\TrueType\Collection;

class BackendRechteRepository extends BaseRepository implements IBackendRechteRepository
{
    protected string $alias = 'BackendRechte';

    /**
     * @param int $rechteId
     * @return BackendRechte|object|null
     */
    public function find(int $rechteId): ?BackendRechte
    {
        return $this->genericRepository->find($rechteId);
    }

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->findAll();
    }

    /**
     * @param array $values
     * @return array
     */
    public function findIn(array $values): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->andWhere("{$this->alias}.rechteId IN (:ids)")
            ->setParameter('ids', $values)
            ->getQuery()
            ->getResult();
    }

    /**
     * @return array
     */
    public function getForAdmin(): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias)
            ->where("{$this->alias}.hide = 0")
            ->orderBy("{$this->alias}.group")
            ->getQuery()
            ->getResult();
    }
}
