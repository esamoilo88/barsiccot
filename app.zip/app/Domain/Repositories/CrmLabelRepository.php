<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CrmLabel;
use App\Domain\Repositories\Interfaces\ICrmLabelRepository;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class CrmLabelRepository extends BaseRepository implements ICrmLabelRepository
{
    protected string $alias = 'CrmLabel';

    /**
     * @param int $id
     * @return CRMLabel|object
     */
    public function find(int $id): CRMLabel
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findAllLabels(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("{$this->alias}.id AS labelId","crmCategory.id AS categoryId","crmCategory.name AS categoryName","{$this->alias}.name")
            ->join("{$this->alias}.crmCategory", 'crmCategory')
            ->where("{$this->alias}.hide = 0")
            ->andWhere("crmCategory.hide = 0")
            ->orderBy("crmCategory.sort", "ASC")
            ->addOrderBy("{$this->alias}.sort", "ASC")
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
    }
}
