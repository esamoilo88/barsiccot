<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\CrmCustomer;
use App\Domain\Repositories\Interfaces\ICrmCustomerRepository;
use App\Domain\Repositories\Utils\Filters\Customers\CustomersFilter;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use App\Domain\ValueObjects\Pagination\Pagination;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\QueryBuilder;

class CrmCustomerRepository extends BaseRepository implements ICrmCustomerRepository
{
    public string $alias = 'CrmCustomer';

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @param SIN $sin
     * @return CrmCustomer|object|null
     */
    public function find(int $id): ?CrmCustomer
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param int $id
     * @return CrmCustomer|null
     * @throws NonUniqueResultException
     */
    public function getCustomerData(int $id): ?CrmCustomer
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias, 'contacts', 'notes')
            ->leftJoin("{$this->alias()}.contacts", 'contacts')
            ->leftJoin("{$this->alias}.notes", 'notes')
            ->where("{$this->alias}.id = :id")
            ->setParameter('id', $id)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param array $search
     * @param string|null $isInternal
     * @param PaginationRequestDTO $dto
     * @param Filterable $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginated(array $search, ?string $isInternal, PaginationRequestDTO $dto, Filterable $filter): PaginationResponseDTO
    {
        $segmentList =  CrmCustomer::getInternalSegments();

        $fields = [
            "{$this->alias}.id AS customerId",
            "{$this->alias}.name AS kundenname",
            "{$this->alias}.country",
            "{$this->alias}.akpDTAGnameLang AS dtagNameLang",
            "{$this->alias}.akpDTAGkdnr AS kundennummer",
            "{$this->alias}.internal",
            "cg.gpId",
            "ck.kundeId",
            "{$this->alias}.state",
            "{$this->alias}.postalCode AS plz",
            "{$this->alias}.city AS kundenstandort",
            "{$this->alias}.akpSegment AS segment",
            "{$this->alias}.akpGpNameLang AS gpNameLang",
            "{$this->alias}.akpZgId AS zgId",
            "{$this->alias}.akpUstId AS ustId",
            "{$this->alias}.akpWzId AS wzId",
            "{$this->alias}.akpGpNr AS gpNummer",
            "{$this->alias}.isActive",
            "{$this->alias}.akpZgBezeichnung AS zgBezeichnung",
            "{$this->alias}.akpWzBezeichnung AS wzBezeichnung"
        ];
        $condition = $this->getCondition($search);
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);
        $query = $builder
            ->select($fields)
            ->leftJoin("{$this->alias}.crmGp", 'cg')
            ->leftJoin("{$this->alias}.crmKunde", 'ck')
            ->where("{$this->alias}.isActive = 1")
            ->andWhere($condition);
        if($isInternal === 'konzern'){
            $query = $query->andWhere($builder->expr()->in("cg.segment", $segmentList));
        }
        $query = $query ->orderBy("{$this->alias}.akpGpNameLang", "ASC");
        $paginate = new Paginate($this, $query, $dto, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * @param array $search
     * @return string
     */
    private function getCondition(array $search): string
    {
        $condition = [];
        $kundenname = explode(' ', trim($search['kundenname']));
        foreach ($kundenname as $word) {
            if ($word == '') continue;
            $condition[] = "{$this->alias}.name LIKE CONCAT('%', '$word' ,'%')" ;
        }
        $gpNummer = $search['gpNummer'];
        $kundennummer =$search['kundennummer'];
        $ort = $search['ort'];
        if ($gpNummer !='') $condition[] = "{$this->alias}.akpGpNr =". $gpNummer;
        if($kundennummer !='') $condition[] = "$this->alias.akpDTAGkdnr =" . $kundennummer;
        if ($ort != '') $condition[] = "{$this->alias}.city LIKE CONCAT('%', '$ort' ,'%')";
        return implode(' AND ', $condition);
     }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getList(PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->select($this->alias);

        $paginate = new Paginate($this, $qb, $dto, new CustomersFilter());

        return $paginate->proceedPagination();
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'kunde' => "{$this->alias}.name",
            'akpSegment' => "{$this->alias}.akpSegment"
        ];
    }

    /**
     * @param bool $onlyCount
     * @param Pagination|null $pagination
     * @return array
     */
    public function findToUpdate(bool $onlyCount, ?Pagination $pagination = null): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        if ($onlyCount) {
            $builder->select("COUNT({$this->alias}) AS count");
        } else {
            $builder->select($this->alias, 'crmKunde', 'crmGp');
        }

        $builder
            ->join("{$this->alias}.crmKunde", 'crmKunde')
            ->join("{$this->alias}.crmGp", 'crmGp');

        if ($pagination) {
            $builder->setFirstResult($pagination->skip())->setMaxResults($pagination->limit());
        }

        return $builder->getQuery()->getResult();
    }
}

