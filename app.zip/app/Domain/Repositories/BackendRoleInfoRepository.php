<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendRoleInfo;
use App\Domain\Repositories\Interfaces\IBackendRoleInfoRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\QueryBuilder;

class BackendRoleInfoRepository extends BaseRepository implements IBackendRoleInfoRepository
{
    public string $alias = 'Backend_RoleInfo';

    /**
     * @param  int  $id
     * @return BackendRoleInfo|object
     */
    public function find(int $id): ?BackendRoleInfo
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        return new ArrayCollection($builder
            ->where("{$this->alias}.hide = 0")
            ->orderBy("{$this->alias}.name", 'ASC')
            ->getQuery()
            ->getResult()
        );
    }
}

