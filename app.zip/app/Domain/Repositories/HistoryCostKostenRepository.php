<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\IHistoryCostKostenRepository;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\Query;

class HistoryCostKostenRepository extends BaseRepository implements IHistoryCostKostenRepository
{
    public string $alias = 'h_cost_kosten';

    /**
     * @param int $kostenId
     * @return array
     */
    public function findByKostenId(int $kostenId): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.kostenId =" . $kostenId)
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
    }
}
