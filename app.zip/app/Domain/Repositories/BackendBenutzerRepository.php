<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\DTO\User\UserSearchDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendGroup;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Entities\BackendRoles;
use App\Domain\Repositories\Utils\Filters\BackendBenutzerFilter;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Interfaces\IBackendBenutzerRepository;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\ORM\Query;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\NoResultException;
use Doctrine\ORM\QueryBuilder;
use App\Exceptions\Application\ObjectPropertyIsNotSetException;
use Exception;

class BackendBenutzerRepository extends BaseRepository implements IBackendBenutzerRepository
{
    protected string $alias = 'BackendBenutzer';

    /**
     * @param int $id
     * @return BackendBenutzer|object|null
     */
    public function find(int $id): ?BackendBenutzer
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param string $userName
     * @return BackendBenutzer|object|null
     * @throws Exception
     */
    public function findByUserName(string $userName): ?BackendBenutzer
    {
        return $this->genericRepository->findOneBy(['username' => $userName]);
    }

    /**
     * @param string $email
     * @return BackendBenutzer|object|null
     * @throws Exception
     */
    public function findByEmail(string $email): ?BackendBenutzer
    {
        return $this->genericRepository->findOneBy(['email' => $email]);
    }

    /**
     * @param int $page
     * @param array $filters
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginated(int $page, array $filters = []): PaginationResponseDTO
    {
        $queryBuilder = $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.benutzerId AS id",
                "{$this->alias}.vorname AS first_name",
                "{$this->alias}.nachname AS last_name",
                'b.bezeichnung AS area'
            )
            ->join("{$this->alias}.bereich", 'b')
            ->orderBy("{$this->alias}.benutzerId", 'ASC');

        $paginate = new Paginate(
            $this,
            $queryBuilder,
            new PaginationRequestDTO([
                'currentPage' => $page,
                'filter' => $filters
            ]),
            new BackendBenutzerFilter()
        );

        $paginate->setPerPage(4);

        return $paginate->proceedPagination();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginatedForAdmin(PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->select($this->alias, 'bereich')
            ->leftJoin("{$this->alias}.bereich", 'bereich')
            ->orderBy("{$this->alias}.nachname", 'ASC');

        $paginate = new Paginate(
            $this,
            $qb,
            $dto,
            new BackendBenutzerFilter()
        );

        $paginate->setPerPage(20);

        return $paginate->proceedPagination();
    }

    /**
     * @param QueryBuilder $query
     * @param array $filters
     * @return QueryBuilder
     */
    protected function buildFilters(QueryBuilder $query, array $filters): QueryBuilder
    {
        foreach ($filters as $col => $value) {
            if ($value) {
                $query->orWhere("u.{$col} LIKE :{$col}")
                    ->setParameter($col, "%{$value}%");
            }
        }

        return $query;
    }

    /**
     * @param UserSearchDTO $dto
     * @return array
     * @throws ObjectPropertyIsNotSetException
     */
    public function search(UserSearchDTO $dto): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $fields = [
            $this->alias . '.benutzerId',
            $this->alias . '.email',
            $this->alias . '.nachname',
            $this->alias . '.vorname',
            "{$this->alias}.ressort AS department",
            "{$this->alias}.nachname + ', ' + {$this->alias}.vorname AS display_name"
        ];

        $query = $builder
            ->select($fields)
            ->distinct();

        if ($dto->hasName()) {
            $query = $query
                ->where($this->alias . '.nachname = :surname')
                ->setParameter('surname', $dto->getSurname())
                ->andWhere($this->alias . '.vorname LIKE :name')
                ->setParameter('name', '%' . $dto->getName() . '%');
        } else {
            $query = $query
                ->where($this->alias . '.nachname LIKE :surname')
                ->setParameter('surname', '%' . $dto->getSurname() . '%');
        }

        if ($dto->hasRoles()) {
            $query = $query
                ->leftJoin($this->alias . '.backendRechtes', 'rechte')
                ->andWhere($query->expr()->orX(
                    $query->expr()->in('rechte', $dto->getRoles()),
                    $query->expr()->eq($this->alias . '.isAdmin', true)
                ));
        }

        return $query->getQuery()->getArrayResult();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @param Filterable $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getListToOfferAssign(PaginationRequestDTO $dto, Filterable $filter): PaginationResponseDTO
    {
        $role = config('dbconfig.roles.ANGEBOTSERSTELLER_LONG_NAME');

        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $fields = [
            $this->alias . '.benutzerId AS userId',
            "{$this->alias}.ressort AS department",
            "{$this->alias}.nachname + ', ' + {$this->alias}.vorname AS user",
            "COUNT(status) AS count"
        ];

        $subquery = $this->entityManager->createQueryBuilder()
            ->select('bpr')
            ->from(BackendProjectRoles::class, 'bpr')
            ->join('bpr.backendRoles' ,'br', 'WITH', 'br.roleShort = :role')
            ->where("bpr.backendBenutzer = {$this->alias}");

        $query = $builder
            ->select($fields)
            ->join($this->alias . '.backendRechtes', 'rechtes', 'WITH', 'rechtes.bezeichnung = :permission')
            ->leftJoin($this->alias . '.backendProjectRoles', 'pivot', 'WITH', "pivot IN({$subquery->getDQL()})")
            ->leftJoin('pivot.salesStammdaten', 'project')
            ->leftJoin('project.globalGate', 'global')
            ->leftJoin('global.sinStatus', 'sinStatus')
            ->leftJoin('sinStatus.status', 'status', 'WITH', 'status.active = 1 AND status.offerComplete = 0')
            ->setParameters(['permission' => $role, 'role' => 'AE'])
            ->groupBy("{$this->alias}.benutzerId, {$this->alias}.ressort, {$this->alias}.nachname, {$this->alias}.vorname");

        $paginate = new Paginate(
            $this,
            $query,
            $dto,
            $filter
        );

        return $paginate->proceedPagination();
    }

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'user' => "{$this->alias}.nachname",
            'fullName' => "{$this->alias}.nachname",
            'admin' => "{$this->alias}.isAdmin",
            'blocked' => "{$this->alias}.blocked",
            'bereichId' => "{$this->alias}.bereich",
        ];
    }

    /**
     * @param BackendRoles $role
     * @param array $filters
     * @return array
     */
    public function getUsersAccessibleToRole(BackendRoles $role, array $filters): array
    {
        $filter = new BackendBenutzerFilter();

        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select([
                "{$this->alias}.benutzerId AS id",
                "{$this->alias}.email",
                "CONCAT({$this->alias}.vorname, ' ', {$this->alias}.nachname) AS display_name",
                "{$this->alias}.ressort AS department",
            ])
            ->join("{$this->alias}.backendRechtes", 'permissions')
            ->join('permissions.accessibleRoles', 'accessibleRoles', 'WITH', 'accessibleRoles.roleId = :role')
            ->setParameter('role', $role);

        $query = $filter->filter($query, $filters, $this->alias);

        return $query->getQuery()->getArrayResult();
    }

    /**
     * @param array $rechteIds
     * @param array $filters
     * @return array
     */
    public function getUsersAccessibleToRights(array $rechteIds, array $filters): array
    {
        $filter = new BackendBenutzerFilter();

        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select([
                "{$this->alias}.benutzerId AS id",
                "{$this->alias}.email",
                "CONCAT({$this->alias}.vorname, ' ', {$this->alias}.nachname) AS display_name",
                "{$this->alias}.ressort AS department",
            ])
            ->join($this->alias . '.backendRechtes', 'rechtes', 'WITH', 'rechtes.rechteId IN (:rechteIds)')
            ->setParameter('rechteIds', $rechteIds);

        $query = $filter->filter($query, $filters, $this->alias);

        return $query->getQuery()->getArrayResult();
    }

    /**
     * @param BackendBenutzer $user
     * @param BackendRoles $role
     * @return bool
     */
    public function couldUserHaveRole(BackendBenutzer $user, BackendRoles $role): bool
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("COUNT({$this->alias}.benutzerId)")
            ->join("{$this->alias}.backendRechtes", 'permissions')
            ->join('permissions.accessibleRoles', 'accessibleRoles', 'WITH', 'accessibleRoles.roleId = :role')
            ->where("{$this->alias}.benutzerId = :user")
            ->setParameters([
                'user' => $user,
                'role' => $role
            ])
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param SIN $sin
     * @return array
     */
    public function getAnsprechpartners(SIN $sin): array
    {
        $roles = ['SM', 'AD', 'FLU'];

        return $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.benutzerId AS id",
                "CONCAT({$this->alias}.vorname, ' ', {$this->alias}.nachname) AS text"
            )
            ->join("{$this->alias}.backendProjectRoles", 'backendProjectRoles')
            ->join('backendProjectRoles.backendRoles', 'backendRoles')
            ->where('backendProjectRoles.salesStammdaten = :simpleId')
            ->andWhere('backendRoles.roleShort IN (:roles)')
            ->setParameters([
                'roles' => $roles,
                'simpleId' => $sin->value()
            ])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param BackendBenutzer $user
     * @param array $roles
     * @return bool
     */
    public function isUserHasRoles(BackendBenutzer $user, array $roles): bool
    {
        $result = $this->genericRepository->createQueryBuilder('bb')
            ->select('br.roleShort','role.roleShort AS groupRoleShort')
            ->join('bb.backendProjectRoles', 'bpr')
            ->join('bb.backendBenutzerGroup', 'bbg')
            ->leftJoin('bpr.backendRoles','br','WITH','br.roleShort IN (:roles)')
            ->join('bbg.group', 'bg')
            ->leftJoin('bg.role','role','WITH','role.roleShort IN (:roles)')
            ->where('bb.benutzerId = :userId')
            ->setParameters([
                'roles' => $roles,
                'userId' => $user->getBenutzerId()
            ])
            ->getQuery()
            ->getResult();

        $rolesOfUser = [];

        foreach ($result as $item){
            if($item['roleShort']) {
                array_push($rolesOfUser, $item['roleShort']);
            }
            if($item['groupRoleShort']) {
                array_push($rolesOfUser,$item['groupRoleShort']);
            }
        };
        return array_intersect($roles, $rolesOfUser) !== [];
    }

     /**
     * @param int $userId
     * @param SIN $sin
     * @param array $roles
     * @return BackendBenutzer|null
     */
    public function findUserWithProjectRoles(int $userId, SIN $sin, array $roles): ?BackendBenutzer
    {
        return $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->join("{$this->alias}.backendProjectRoles", 'backendProjectRoles')
            ->join('backendProjectRoles.backendRoles', 'backendRoles')
            ->where("{$this->alias}.benutzerId = :userId")
            ->andWhere('backendProjectRoles.salesStammdaten = :simpleId')
            ->andWhere('backendRoles.roleShort IN (:roles)')
            ->setParameters([
                'userId' => $userId,
                'simpleId' => $sin->value(),
                'roles' => $roles
            ])
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param array $emails
     * @return array
     */
    public function findUniqueByEmails(array $emails): array
    {
        $rsm = new ResultSetMapping();

        $rsm->addScalarResult('email', 'email');
        $rsm->addScalarResult('name', 'name');

        $sql = "
            select
                email,
                concat(min(vorname), ' ', min(nachname)) as name
            from Backend_Benutzer
            where email in ('".implode("','", $emails)."')
            group by email
        ";

        return $this->entityManager->createNativeQuery($sql, $rsm)->getResult();
    }

    /**
     * @param array $filters
     * @return array
     */
    public function getUsers(array $filters): array
    {
        $filter = new BackendBenutzerFilter();

        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        $qb->select([
                "{$this->alias}.benutzerId AS id",
                "{$this->alias}.email",
                "CONCAT({$this->alias}.vorname, ' ', {$this->alias}.nachname) AS display_name",
                "{$this->alias}.ressort AS department",
            ]);

        $qb = $filter->filter($qb, $filters, $this->alias);

        return $qb->getQuery()->getArrayResult();
    }

    /**
     * @param int $userId
     * @return BackendBenutzer|null
     */
    public function findWithBereich(int $userId): ?BackendBenutzer
    {
        return $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->select("{$this->alias}", 'bereich')
            ->join("{$this->alias}.bereich", 'bereich')
            ->where("{$this->alias}.benutzerId = :benutzerId")
            ->setParameter('benutzerId', $userId)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param string $email
     * @return BackendBenutzer|null
     * @throws NoResultException
     * @throws NonUniqueResultException
     */
    public function findFirstByEmail(string $email): ?BackendBenutzer
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select($this->alias)
            ->where("{$this->alias}.email = :email")
            ->setParameter('email', $email)
            ->setMaxResults(1)
            ->getQuery()
            ->getSingleResult();
    }

    /**
     * @param int $id
     * @return BackendBenutzer|null
     * @throws NonUniqueResultException
     */
    public function findById(int $id): ?BackendBenutzer
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select($this->alias)
            ->where("{$this->alias}.benutzerId = :id")
            ->setParameter('id', $id)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param string $email
     * @return array
     */
    public function findByLowerEmail(string $email): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select($this->alias)
            ->where("LOWER({$this->alias}.email) = :email")
            ->setParameter('email', $email)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $userId
     * @return BackendBenutzer|null
     */
    public function findUserData(int $userId): ?BackendBenutzer
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->leftJoin("{$this->alias}.bereich", 'bereich')
            ->leftJoin("{$this->alias}.backendRechtes", 'backendRechtes')
            ->leftJoin("{$this->alias}.lastLogin", 'lastLogin')
            ->where("{$this->alias}.benutzerId = :userId")
            ->setParameter("userId", $userId)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
