<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CrmNote;
use App\Domain\Repositories\Interfaces\ICrmNoteRepository;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use Doctrine\ORM\QueryBuilder;

class CrmNoteRepository extends BaseRepository implements Paginationable, ICrmNoteRepository
{
    public string $alias = 'CrmNote';

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @param int $id
     * @return CrmNote|object|null
     */
    public function find(int $id): ?CrmNote
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param int $customerId
     * @return array
     */
    public function getList(int $customerId): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb
            ->select(
                "{$this->alias}.id",
                "CONCAT(backendBenutzer.nachname, ', ', backendBenutzer.vorname) AS user",
                "{$this->alias}.created",
                "{$this->alias}.note"
            )
            ->join("{$this->alias}.backendBenutzer", 'backendBenutzer')
            ->where("{$this->alias}.crmCustomer = :customerId")
            ->setParameters([
                'customerId' => $customerId
            ])
            ->orderBy("{$this->alias}.created", 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'note' => "{$this->alias}.note",
        ];
    }
}