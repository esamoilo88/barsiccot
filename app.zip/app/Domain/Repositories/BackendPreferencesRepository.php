<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendPreferences;
use App\Domain\Entities\BackendPreferencesBenutzer;
use App\Domain\Repositories\Interfaces\IBackendPreferencesRepository;

class BackendPreferencesRepository extends BaseRepository implements IBackendPreferencesRepository
{
    protected string $alias = 'BackendPreferences';

    /**
     * @param  int  $id
     * @return BackendPreferences|object|null
     */
    public function find(int $id): ?BackendPreferences
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->findAll();
    }

    /**
     * @param int $userId
     * @param bool $withAdditions
     * @return array
     */
    public function findUserPreferences(int $userId, bool $withAdditions = false): array
    {
        $qb = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.sysName",
                "{$this->alias}.value",
                'CASE WHEN bpb.id IS NOT NULL THEN 1 ELSE 0 END AS isOverridden',
                'bpb.value AS overriddenValue'
            );

        if ($withAdditions) {
            $qb->addSelect("{$this->alias}.structure");
            $qb->addSelect("{$this->alias}.group");
            $qb->addSelect("{$this->alias}.name");
            $qb->addSelect("{$this->alias}.subtext");
        }

        return $qb->leftJoin(BackendPreferencesBenutzer::class, 'bpb', 'WITH', "bpb.preference = {$this->alias}.id AND bpb.benutzer = :user")
            ->setParameter('user', $userId)
            ->andWhere("{$this->alias}.hide = 0")
            ->getQuery()
            ->getResult();
    }
}
