<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendTree;
use App\Domain\Repositories\Interfaces\IBackendTreeRepository;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Illuminate\Contracts\Auth\Authenticatable;
use App\Domain\Repositories\BaseRepository;

class BackendTreeRepository extends BaseRepository implements IBackendTreeRepository
{
    protected string $alias = 'BackendTree';

    /**
     * @param PaginationRequestDTO $gridParamsDTO
     * @param Filterable|null $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginated(PaginationRequestDTO $gridParamsDTO, Filterable $filter = null): PaginationResponseDTO {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias, 'ba', 'br')
            ->leftJoin("{$this->alias}.backendAnwendung", 'ba')
            ->leftJoin("{$this->alias}.backendRechtes", 'br');
        $paginate = new Paginate($this, $query, $gridParamsDTO, $filter);
        return $paginate->proceedPagination();
    }

    /**
     * Get data about rights for current action.
     * @param string $controller
     * @param string $action
     * @return BackendTree
     */
    public function findByControllerAndAction(string $controller, string $action): ?BackendTree
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.controller = :controller")
            ->andWhere("{$this->alias}.action = :action")
            ->setParameter('controller', $controller)
            ->setParameter('action', $action)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @return Collection
     */
    public function getAllRoutes(): Collection
    {
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias, "ba")
            ->join("{$this->alias}.backendAnwendung", "ba")
            ->addOrderBy("ba.anwendungId", "ASC")
            ->addOrderBy("{$this->alias}.sort", "ASC")
            ->getQuery()
            ->getResult();

        return new ArrayCollection($result);
    }

    /**
     * Get protected routes which $user can visit
     * @param BackendBenutzer|Authenticatable $user
     * @param bool $minified - get only controller and action concatenated (for middleware check)
     * @return Collection
     */
    public function getUserProtectedRoutes(BackendBenutzer $user, bool $minified = false): Collection
    {
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        if ($minified) {
            $qb->select("DISTINCT {$this->alias}.controller + '@' + {$this->alias}.action");
        } else {
            $qb->select($this->alias);
        }

        $result = $qb->join("{$this->alias}.backendRechtes", "br")
            ->andWhere("br.rechteId IN (:rechtes)")
            ->setParameter('rechtes', $user->getBackendRechtes())
            ->getQuery()
            ->getResult();

        return new ArrayCollection($result);
    }

    /**
     * @param BackendBenutzer|null $user - pass it for getting navigation for non admin user
     * @return Collection
     */
    public function getNavigationRoutes(BackendBenutzer $user = null): Collection
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->addSelect("ba")
            ->leftJoin("{$this->alias}.backendAnwendung", "ba")
            ->andWhere("{$this->alias}.inNav = 1")
            ->andWhere("ba.hide=0 OR ba IS NULL")
            ->addOrderBy("ba.sort", "ASC")
            ->addOrderBy("{$this->alias}.sort", "ASC");

        if (!is_null($user)) {
            $query->join("{$this->alias}.backendRechtes", "br")
                ->andWhere("br.rechteId IN (:rechtes)")
                ->setParameter('rechtes', $user->getBackendRechtes());
        }

        return new ArrayCollection($query->getQuery()->getResult());
    }

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
          'treeId' => "{$this->alias}.treeId"
        ];
    }
}
