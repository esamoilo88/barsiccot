<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceOrder;
use App\Domain\Entities\FinanceOrderPosition;
use App\Domain\Repositories\Interfaces\IFinanceOrderPositionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\QueryBuilder;

class FinanceOrderPositionRepository extends BaseRepository implements IFinanceOrderPositionRepository
{
    public string $alias = 'FinanceOrderPosition';

    /**
     * @param  int  $id
     * @return FinanceOrderPosition|object
     */
    public function find(int $id): ?FinanceOrderPosition
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param int $financeOrderId
     * @param bool $indexByApId
     * @return array
     * @throws \Doctrine\ORM\Query\QueryException
     */
    public function findAllByFinanceOrderId(int $financeOrderId, bool $indexByApId = false): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        if ($indexByApId) {
            $builder->indexBy($this->alias,   "{$this->alias}.angebotspositionId");
        }

        $select = [
            "{$this->alias}.angebotspositionId",
            "{$this->alias}.icpKontBpos",
            'financeOrder.orderNumber',
            'ap.bezeichnung'
        ];

        $builder
                ->select($select)
                ->join("{$this->alias}.angebotsposition", 'ap')
                ->join("{$this->alias}.financeOrder", 'financeOrder')
                ->where("{$this->alias}.financeOrder = :id")
                ->setParameter('id', $financeOrderId);

        return $builder->getQuery()->getResult();
    }

    /**
     * @param int $financeOrderId
     * @param array $apIds
     * @return Collection
     */
    public function findAllByFinanceOrderIdAndApIds(int $financeOrderId, array $apIds): Collection
    {
        $builder = $this->customQueryBuilder->getQueryBuilder();

        return new ArrayCollection(
            $builder
                ->where("{$this->alias}.financeOrder = :id")
                ->andWhere($builder->expr()->in("{$this->alias}.angebotsposition", $apIds))
                ->setParameter('id', $financeOrderId)
                ->getQuery()
                ->getResult()
        );
    }

    /**
     * @param int $apId
     * @return array|null
     */
    public function findLastBposAndOrderNumberByApId(int $apId): ?array
    {
        $select = [
            "{$this->alias}.icpKontBpos",
            'financeOrder.orderNumber'
        ];
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($select)
            ->join("{$this->alias}.financeOrder", 'financeOrder')
            ->where("{$this->alias}.angebotsposition = :apId")
            ->orderBy("{$this->alias}.created", 'DESC')
            ->setParameter('apId', $apId)
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }

}

