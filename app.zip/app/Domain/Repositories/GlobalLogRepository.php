<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Repositories\Interfaces\IGlobalLogRepository;
use App\Domain\Repositories\Utils\Filters\CCF\HistoryFilter;
use App\Domain\Repositories\Utils\Filters\Offers\Calculations\OnkaHistoryFilter;
use App\Domain\Repositories\Utils\Filters\Orders\OrderHistoryFilter;
use App\Domain\Repositories\Utils\Filters\Projects\ProjectHistoryFilter;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use DateTime;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\QueryBuilder;
use Illuminate\Support\Carbon;

class GlobalLogRepository extends BaseRepository implements IGlobalLogRepository
{
    protected string $alias = "GlobalLog";

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'timestamp' => "{$this->alias}.timestamp"
        ];
    }

    /**
     * @param int $sin
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getFinanceRelevantPaginated(int $sin, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $lastMonths = (new DateTime())->modify('-3 months');

        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->join("{$this->alias}.group", 'glg')
            ->where("{$this->alias}.simple = :sin")
            ->andWhere("glg.financeRelevant = 1")
            ->andWhere($this->alias . '.timestamp >= :date')
            ->setParameter(':date', $lastMonths)
            ->setParameter('sin', $sin);

        $paginate = new Paginate($this, $query, $dto);
        return $paginate->proceedPagination();
    }

    /**
     * @param SIN $sin
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getOnkaRelatedLogs(SIN $sin, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.changes",
                "{$this->alias}.action",
                "{$this->alias}.objectName",
                "{$this->alias}.timestamp",
                'g.sysName AS groupSysName',
                'b.nachname AS userSecondName',
                'b.vorname AS userName'
            )
            ->join("{$this->alias}.group", 'g')
            ->join("{$this->alias}.benutzer", 'b')
            ->where("{$this->alias}.simple = :sin")
            ->andWhere("g.onkaRelevant = 1")
            ->setParameter('sin', $sin->value());

        $paginate = new Paginate($this, $query, $dto, new OnkaHistoryFilter());
        return $paginate->proceedPagination();
    }

    /**
     * @param int $userId
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function findDataForWidget(int $userId, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.logText",
                "{$this->alias}.objectName",
                "{$this->alias}.timestamp",
                'gg.simpleId',
                'g.sysName AS groupSysName',
                'g.icon',
                'g.cssClass',
                'b.nachname AS userSecondName',
                'b.vorname AS userName'
            )
            ->distinct()
            ->join("{$this->alias}.group", 'g')
            ->join("{$this->alias}.simple", 'gg')
            ->join("gg.salesStammdaten", 'ss')
            ->join("ss.members", 'bpr')
            ->join("bpr.backendBenutzer", 'b')
            ->where("bpr.representative = 0")
            ->andWhere("b.benutzerId = :userId")
            ->andWhere("{$this->alias}.timestamp > :period")
            ->setParameters(["userId" => $userId, "period" => Carbon::now()->subDays(7 * config('dbconfig.calendar.RECENT_ACTIVITY_MAX_WEEKS'))]);
        $paginate = new Paginate($this, $query, $dto, null);
        return $paginate->proceedPagination();
    }

    /**
     * @param SIN $sin
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getOrderRelatedLogs(SIN $sin, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.objectName",
                "{$this->alias}.timestamp",
                "{$this->alias}.logText",
                'b.nachname AS userSecondName',
                'b.vorname AS userName')
            ->join("{$this->alias}.group", 'g')
            ->leftJoin("{$this->alias}.benutzer", 'b')
            ->where("{$this->alias}.simple = :sin")
            ->andWhere("g.financeRelevant = 1")
            ->setParameter('sin', $sin->value());

        $paginate = new Paginate($this, $query, $dto, new OrderHistoryFilter());
        return $paginate->proceedPagination();
    }

    /**
     * @param SIN $sin
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getProjectRelatedLogs(SIN $sin, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.objectName",
                "{$this->alias}.timestamp",
                "{$this->alias}.logText",
                'b.nachname AS userSecondName',
                'b.vorname AS userName')
            ->join("{$this->alias}.group", 'g')
            ->join("{$this->alias}.benutzer", 'b')
            ->where("{$this->alias}.simple = :sin")
            ->andWhere("g.salesRelevant = 1")
            ->setParameter('sin', $sin->value());

        $paginate = new Paginate($this, $query, $dto, new ProjectHistoryFilter());
        return $paginate->proceedPagination();
    }

    /**
     * @param int $sin
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getAllPaginated(int $sin, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias, 'benutzer')
            ->leftJoin("{$this->alias}.benutzer", 'benutzer')
            ->where("{$this->alias}.simple = :sin")
            ->setParameters([
                'sin' => $sin
            ]);

        $paginate = new Paginate($this, $query, $dto);
        return $paginate->proceedPagination();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function ccfPaginated(PaginationRequestDTO $dto): PaginationResponseDTO
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->select($this->alias, 'g', 'b')
            ->join("{$this->alias}.group", 'g')
            ->join("{$this->alias}.benutzer", 'b')
            ->where('g.financeRelevant = 1')
            ->orderBy("{$this->alias}.timestamp", 'DESC');

        $paginate = new Paginate($this, $qb, $dto, new HistoryFilter());

        return $paginate->proceedPagination();
    }

    /**
     * @param BackendBenutzer $user
     * @param string $groupSysName
     * @return array
     */
    public function getMembersGroupLog(BackendBenutzer $user, string $groupSysName): array
    {
        $rsm = new ResultSetMapping();

        $rsm->addScalarResult('timestamp', 'timestamp', 'datetime');
        $rsm->addScalarResult('log_text', 'logText');
        $rsm->addScalarResult('simple_id', 'simpleId', 'integer');
        $rsm->addScalarResult('vorname', 'vorname');
        $rsm->addScalarResult('nachname', 'nachname');
        $rsm->addScalarResult('sys_name', 'sysName');

        $timestamp = Carbon::now()->subMinute()->format('Y-m-d H:i');

        $sql = "
            select
                Global_Log.timestamp,
                Global_Log.log_text,
                Global_Log.simple_id,
                Backend_Benutzer.vorname,
                Backend_Benutzer.nachname,
                Global_Log_Group.sys_name,
                convert(char(16), Global_Log.timestamp) as date
            from Global_Log
            left join Backend_Benutzer on Global_Log.benutzer_id = Backend_Benutzer.benutzer_id
            left join Global_Log_Group on Global_Log.group_id = Global_Log_Group.id
            where Global_Log_Group.sys_name = '${groupSysName}' and
                  Global_Log.benutzer_id = {$user->getBenutzerId()} and
                  Global_Log.timestamp >= '{$timestamp}'
            order by date desc, Global_Log.simple_id, Global_Log.log_text
            ";

        return $this->entityManager->createNativeQuery($sql, $rsm)->getArrayResult();
    }
}
