<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Repositories\Interfaces\IBackendAnwendungRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;

class BackendAnwendungRepository extends BaseRepository implements IBackendAnwendungRepository
{
    /**
     * @param BackendBenutzer $user
     * @return Collection
     */
    public function findAnwendungsByUser(BackendBenutzer $user): Collection
    {
        $queryBuilder = $this->genericRepository->createQueryBuilder('ba')
            ->select('ba', 'bba')
            ->join('ba.backendBenutzeranwendung', 'bba')
            ->where('bba.backendBenutzer = :user')
            ->andWhere('ba.hide = 0')
            ->setParameter('user', $user);

        $result = $queryBuilder->getQuery()->getResult();

        return new ArrayCollection($result);
    }

    /**
     * For Administrator
     * @return Collection
     */
    public function findAllVisibleAnwendungs(): Collection
    {
       return new ArrayCollection($this->genericRepository->findBy(['hide' => 0]));
    }
}

