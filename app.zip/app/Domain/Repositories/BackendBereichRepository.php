<?php


namespace App\Domain\Repositories;


use App\Domain\Entities\BackendBereich;
use App\Domain\Repositories\Interfaces\IBackendBereichRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

class BackendBereichRepository extends BaseRepository implements IBackendBereichRepository
{
    protected string $alias = 'BackendBereich';

    /**
     * @param int $id
     * @return BackendBereich
     */
    public function find(int $id): ?BackendBereich
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param string $value
     * @return array
     */
    public function findByRessort4KurzOrBezeichnung(string $value): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $value = $qb->expr()->literal("%{$value}%");

        return $qb->select($this->alias)
            ->where("{$this->alias}.hide = 0")
            ->where(
                $qb->expr()->orX(
                    $qb->expr()->like("{$this->alias}.bereichId", $value),
                    $qb->expr()->like("{$this->alias}.ressort4Kurz", $value),
                    $qb->expr()->like("{$this->alias}.teamKurz", $value),
                    $qb->expr()->like("{$this->alias}.bezeichnung", $value),
                )
            )
            ->getQuery()
            ->getResult();
    }
}
