<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\Entities\FinancePsp;
use App\Domain\Repositories\Interfaces\IFinancePspRepository;
use App\Domain\ValueObjects\SIN;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\ORM\NonUniqueResultException;

class FinancePspRepository extends BaseRepository implements IFinancePspRepository
{
    protected string $alias = 'FinancePsp';

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'name' => "$this->alias.name",
            'parentName' => "$this->alias.parentName",
            'pspElement' => "$this->alias.pspElement",
        ];
    }

    /**
     * @param int $id
     * @return FinancePsp|null|object
     */
    public function find(int $id): ?FinancePsp
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param string $name
     * @return FinancePsp|null
     * @throws NonUniqueResultException
     */
    public function findByName(string $name): ?FinancePsp
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias)
            ->where("{$this->alias}.pspElement = :pspElement")
            ->setParameter('pspElement', $name)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param SIN $sin
     * @return FinancePsp|null
     */
    public function getPspElement(SIN $sin): ?FinancePsp
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->join("$this->alias.salesProject", 'salesProject')
            ->where("salesProject.simpleId = :simpleId")
            ->setParameter('simpleId', $sin->value())
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param bool $withHide
     * @return array
     */
    public function findAll(bool $withHide = false): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        if (!$withHide) {
            $qb->where("$this->alias.hide = 0");
        }

        return $qb->select($this->alias)
            ->orderBy("$this->alias.pspElement", "ASC")
            ->getQuery()
            ->getResult();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @param Filterable|null $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function findPspElementsPaginated(PaginationRequestDTO $dto, Filterable $filter = null): PaginationResponseDTO
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "$this->alias.id",
                "$this->alias.pspElement",
                "$this->alias.name",
                "$this->alias.parentName",
                "$this->alias.collector",
                "$this->alias.hide",
                "$this->alias.locked",
                "CONCAT(contact.nachname, ', ', contact.vorname) AS contact_name",
                "contact.email as contact_email",
                "contact.benutzerId AS contact_id",
                "representative.benutzerId AS representative_id",
                "CONCAT(representative.nachname, ', ', representative.vorname) AS representative_name",
                "representative.email as representative_email"
            )
            ->leftJoin("$this->alias.contact", 'contact')
            ->leftJoin("$this->alias.representative", 'representative');

        $paginate = new Paginate($this, $query, $dto, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * @param array $filters
     * @return int
     */
    public function getCountPspElements(array $filters): int
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select("COUNT({$this->alias}.pspElement)");

        if (isset($filters['sichtbar'])) {
            if ($filters['sichtbar'] !== 'alle') {
                $filters['sichtbar'] = $filters['sichtbar'] === 'sichtbar' ? 0 : 1;
                $query = $query
                    ->andWhere("{$this->alias}.hide = :hide")
                    ->setParameter('hide', $filters['sichtbar']);
            }
        }
        // sperre condition
        if (isset($filters['sperre'])) {
            if ($filters['sperre'] !== 'alle') {
                $filters['sperre'] = $filters['sperre'] === 'gesperrt' ? 1 : 0;
                $query = $query
                    ->andWhere("{$this->alias}.locked = :locked")
                    ->setParameter('locked', $filters['sperre']);
            }
        }

        // sammler condition
        if (isset($filters['sammler'])) {
            if ($filters['sammler'] !== 'alle') {
                $filters['sammler'] = $filters['sammler'] === 'nur_sammler' ? 1 : 0;
                $query = $query
                    ->andWhere("{$this->alias}.collector = :collector")
                    ->setParameter('collector', $filters['sammler']);
            }
        }

        //search condition
        if (isset($filters['search_elements'])) {
            $query = $query
                ->andWhere(
                    "{$this->alias}.parentName LIKE :search OR ".
                    "{$this->alias}.name LIKE :search OR ".
                    "{$this->alias}.pspElement LIKE :search")
                ->setParameter('search', '%' . $filters['search_elements'] . '%');
        }

        $query =$query->getQuery()
            ->getSingleScalarResult();

        return $query;
    }

    /**
     * @param string $pspElement
     * @return bool
     */
    public function hasAlreadyElement(string $pspElement): bool
    {
        $result = $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->select("COUNT($this->alias.pspElement)")
            ->where("$this->alias.pspElement = :pspElement")
            ->setParameter('pspElement',$pspElement)
            ->getQuery()
            ->getSingleScalarResult();

        return $result > 0;
    }

    /**
     * @param int|null $pspId
     * @param string|null $pspElementOld
     * @return FinancePsp|null
     * @throws NonUniqueResultException
     */
    public function findPsp(?int $pspId, ?string $pspElementOld): ?FinancePsp
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        if ($pspId) {
            $qb->where("{$this->alias}.id = :id")
                ->setParameter('id', $pspId);
        } else {
            $qb->where("{$this->alias}.pspElement = :pspElement")
                ->setParameter('pspElement', $pspElementOld);
        }

        return $qb->select($this->alias, 'contact', 'representative')
            ->leftJoin("{$this->alias}.contact", 'contact')
            ->leftJoin("{$this->alias}.representative", 'representative')
            ->getQuery()
            ->getOneOrNullResult();
    }
}
