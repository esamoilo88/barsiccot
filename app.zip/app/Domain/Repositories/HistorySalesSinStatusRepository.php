<?php

namespace App\Domain\Repositories;

use App\Domain\ValueObjects\SIN;
use App\Domain\Entities\HISTORY_SalesSinStatus;
use App\Domain\Repositories\Interfaces\IHistorySalesSinStatusRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Query;
use App\Domain\Repositories\BaseRepository;

class HistorySalesSinStatusRepository extends BaseRepository implements IHistorySalesSinStatusRepository
{
    public string $alias = 'h_sin_status';

    /**
     * @param int $id
     * @return HISTORY_SalesSinStatus|object|null
     */
    public function find(int $id): ?HISTORY_SalesSinStatus
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param SIN $id
     * @return Collection
     */
    public function findBySimpleId(SIN $id): Collection
    {
        return new ArrayCollection($this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.simpleId= :id")
            ->setParameter('id', $id->value())
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY));
    }
}
