<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CostsKostentyp;
use App\Domain\Repositories\Interfaces\ICostsKostentypRepository;

class CostsKostentypRepository extends BaseRepository implements ICostsKostentypRepository
{
    protected string $alias = 'CostsKostentyp';

    /**
     * @param int $id
     * @return CostsKostentyp|object|null
     */
    public function find(int $id): ?CostsKostentyp
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->findAll();
    }
}