<?php


namespace App\Domain\Repositories;


use App\Domain\Entities\FinanceSinStatus;
use App\Domain\Repositories\Interfaces\IFinanceSinStatusRepository;
use App\Domain\ValueObjects\SIN;

class FinanceSinStatusRepository extends BaseRepository implements IFinanceSinStatusRepository
{

    /**
     * @param SIN $sin
     * @return FinanceSinStatus|null
     */
    public function findBySin(SIN $sin): ?FinanceSinStatus
    {
        /** @var FinanceSinStatus $result */
        $result = $this->genericRepository->findOneBy(['simpleId' => $sin->value()]);

        return $result;
    }
}
