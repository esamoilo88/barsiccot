<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectGroup;
use App\Domain\Repositories\Interfaces\IBackendBenutzerGroupRepository;
use App\Domain\Repositories\Interfaces\IBackendProjectGroupRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class BackendBenutzerGroupRepository extends BaseRepository implements IBackendBenutzerGroupRepository
{
    public string $alias = 'BackendBenutzerGroup';

    /**
     * @param int $id
     * @return BackendProjectGroup|null|object
     */
    public function find(int $id): ?BackendProjectGroup
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param BackendBenutzer $userId
     * @return array
     */
    public function findByUserId(BackendBenutzer $userId): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        return $builder
            ->select("{$this->alias}")
            ->where("{$this->alias}.benutzer = :benutzerId")
            ->setParameters([
                'benutzerId' => $userId
            ])
            ->getQuery()
            ->getResult();
    }
    /**
     * @param BackendBenutzer $user
     */
    public function clear(BackendBenutzer $user): void
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->delete()
            ->where("{$this->alias}.benutzer = :user")
            ->setParameter('user', $user)
            ->getQuery()
            ->execute();
    }

}
