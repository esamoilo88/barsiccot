<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendMailhistorie;
use App\Domain\Repositories\Interfaces\IBackendMailhistorieRepository;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\Query;

class BackendMailhistorieRepository extends BaseRepository implements IBackendMailhistorieRepository
{
    protected string $alias = 'mails';

    /**
     * @param  int  $id
     * @return BackendMailhistorie|object|null
     */
    public function find(int $id): ?BackendMailhistorie
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }


    /**
     * @param SIN $sin
     * @param PaginationRequestDTO $gridParamsDTO
     * @param Filterable|null $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginated(SIN $sin, PaginationRequestDTO $gridParamsDTO, Filterable $filter = null): PaginationResponseDTO
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $fields = [
            $this->alias.'.dateline AS sentAt',
            $this->alias.'.betreff AS subject',
            $this->alias.'.mailId',
            $this->alias.'.von',
            $this->alias.'.an'
        ];

        $query = $builder
            ->select($fields)
            ->where($this->alias.'.simpleId = :sin')
            ->setParameter('sin', $sin->value());

        $paginate = new Paginate($this, $query, $gridParamsDTO, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            'sentAt' => $this->alias.'.dateline'
        ];
    }

    /**
     * @param int $mailId
     * @return array
     */
    public function getMailInfo(int $mailId): array
    {
        /** @var QueryBuilder $builder */
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb
            ->select(
                "{$this->alias}.mailId",
                "{$this->alias}.simpleId",
                "{$this->alias}.von",
                "{$this->alias}.dateline",
                "{$this->alias}.attachments",
                "{$this->alias}.betreff",
                "{$this->alias}.nachricht",
                "{$this->alias}.an",
                "{$this->alias}.cc",
            )
            ->where("{$this->alias}.mailId = :mailId")
            ->setParameter('mailId', $mailId)
            ->getQuery()
            ->getArrayResult();
    }
}

