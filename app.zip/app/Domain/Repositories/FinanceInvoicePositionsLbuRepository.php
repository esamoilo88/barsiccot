<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\IFinanceInvoicePositionsLbuRepository;
use App\Domain\Repositories\Utils\Conditions\CBI\CBIConditions;
use Doctrine\ORM\Query\ResultSetMapping;

class FinanceInvoicePositionsLbuRepository extends BaseRepository implements IFinanceInvoicePositionsLbuRepository
{
    protected string $alias = 'FinanceInvoicePositionsLbu';
}
