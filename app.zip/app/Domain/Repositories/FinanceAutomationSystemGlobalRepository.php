<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceAutomationSuperglobal;
use App\Domain\Entities\FinanceAutomationSystemGlobal;
use App\Domain\Repositories\BaseRepository;
use App\Domain\Repositories\Interfaces\IFinanceAutomationSystemGlobalRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

class FinanceAutomationSystemGlobalRepository extends BaseRepository implements IFinanceAutomationSystemGlobalRepository
{
    protected string $alias = 'finance_automation_systemglobal';

    /**
     * @param int $id
     * @return FinanceAutomationSuperglobal|object|null
     */
    public function find(int $id): ?FinanceAutomationSystemGlobal
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param SIN $sin
     * @return FinanceAutomationSystemGlobal|object|null
     */
    public function findBySIN(SIN $sin): ?FinanceAutomationSystemGlobal
    {
        /** @var FinanceAutomationSystemGlobal $result */
        return $this->genericRepository->findOneBy(['simpleId' => $sin->value()]);
    }

    /**
     * @param SIN $sin
     * @return Collection
     */
    public function findAllBySIN(SIN $sin): Collection
    {
        return new ArrayCollection(
            $this->genericRepository->findBy(['simpleId' => $sin->value()])
        );
    }

}
