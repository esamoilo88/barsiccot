<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceCreditReason;
use App\Domain\Repositories\Interfaces\IFinanceCreditReasonRepository;

class FinanceCreditReasonRepository extends BaseRepository implements IFinanceCreditReasonRepository
{
    protected string $alias = 'FinanceCreditReason';

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("$this->alias.hide = 0")
            ->orderBy("$this->alias.name", "ASC")
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $id
     * @return FinanceCreditReason|object|null
     */
    public function find(int $id): ?FinanceCreditReason
    {
        return $this->genericRepository->find($id);
    }
}
