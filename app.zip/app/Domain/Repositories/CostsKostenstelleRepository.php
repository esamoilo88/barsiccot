<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CostsKostenart;
use App\Domain\Entities\CostsKostenstelle;
use App\Domain\Repositories\Interfaces\ICostsKostenstelleRepository;

class CostsKostenstelleRepository extends BaseRepository implements ICostsKostenstelleRepository
{
    protected string $alias = 'CostsKostenstelle';

    /**
     * @param int $id
     * @return CostsKostenstelle|null|object
     */
    public function find(int $id): ?CostsKostenstelle
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->findAll();
    }

    /**
     * @param array $fields
     * @return array
     */
    public function getCostenstellelist(array $fields): array
    {
        return $this->findCustom($fields, [
            'conditions' => [['hide', '=', 0]],
            'groupBy' => ['gruppe'],
            'sorts' => [['sort', 'ASC']]
        ])->getResult();
    }

    /**
     *  Get kostenstelle for kosten import excel file
     * @return array
     */
    public function getExcelExportKostenstelle(): array
    {
        return $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "$this->alias.kostenstelleId",
                "$this->alias.kostenstelle",
                "$this->alias.gruppe",
                "$this->alias.beschreibung",
                "$this->alias.shortName"
            )
            ->where("{$this->alias}.hide = 0")
            ->orderBy("{$this->alias}.shortName",'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param string $bezeichnung
     * @return int|null
     */
    public function findByBezeichnung(string $bezeichnung): ?int
    {
        /** @var CostsKostenart $result */
        $result = $this->genericRepository->findOneBy(['bezeichnung' => $bezeichnung]);

        return ($result)? $result['kostenartId'] : null;
    }

}
