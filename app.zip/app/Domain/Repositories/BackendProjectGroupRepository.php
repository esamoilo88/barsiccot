<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectGroup;
use App\Domain\Entities\BackendRoles;
use App\Domain\Repositories\Interfaces\IBackendProjectGroupRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class BackendProjectGroupRepository extends BaseRepository implements IBackendProjectGroupRepository
{
    public string $alias = 'BackendProjectGroup';

    /**
     * @param int $id
     * @return BackendProjectGroup|null|object
     */
    public function find(int $id): ?BackendProjectGroup
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param int $simpleId
     * @return array
     */
    public function findAssignedGroupsInProject(int $simpleId): array
    {
        return $this->genericRepository->createQueryBuilder('backendProjectGroup')
            ->select('backendGroup.id AS groupId',
                'backendGroup.email AS email',
                'backendGroup.name AS full_name',
                'roleinfo.name AS roleinfo_name',
                'backendRole.roleLong AS role',
                'bereich.bezeichnung AS area')
            ->join('backendProjectGroup.group', 'backendGroup')
            ->join('backendGroup.role', 'backendRole')
            ->join('backendGroup.bereich', 'bereich')
            ->join('backendGroup.roleInfo', 'roleinfo')
            ->andWhere('backendProjectGroup.simple = :id')
            ->andWhere('backendGroup.active = 1')
            ->andWhere('backendGroup.hide = 0')
            ->setParameter('id' ,$simpleId)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $simpleId
     * @return array
     */
    public function findCountGroupsInProject(int $simpleId): int
    {
        return $this->genericRepository->createQueryBuilder('backendProjectGroup')
            ->select("COUNT(backendProjectGroup.id)")
            ->join('backendProjectGroup.group', 'backendGroup')
            ->andWhere('backendProjectGroup.simple = :id')
            ->andWhere('backendGroup.active = 1')
            ->andWhere('backendGroup.hide = 0')
            ->setParameter('id' ,$simpleId)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @return bool
     */
    public function isUserHasAnyGroups(SIN $sin, BackendBenutzer $user): bool
    {
        $groups = $this->genericRepository->createQueryBuilder('bpg')
            ->select('COUNT(role.roleId)')
            ->join("bpg.group", 'backendGroup')
            ->join("backendGroup.role", 'role')
            ->join('backendGroup.backendBenutzerGroup', 'benutzerGroup')
            ->where('bpg.simple = :simpleId')
            ->andWhere('benutzerGroup.benutzer = :userId')
            ->setParameters(['simpleId' => $sin->value(), 'userId' => $user->getBenutzerId()])
            ->getQuery()
            ->getSingleScalarResult();

        return (int) $groups > 0;
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @param array $necessaryRoles
     * @return bool
     */
    public function isUserHasGroups(SIN $sin, BackendBenutzer $user, array $necessaryRoles): bool
    {
        $groupResult = $this->genericRepository
            ->createQueryBuilder('bpg')
            ->select('roles.roleShort')
            ->join('bpg.group', 'backendGroup')
            ->join('backendGroup.role', 'roles')
            ->join("backendGroup.backendBenutzerGroup", 'benutzerGroup')
            ->where('bpg.simple = :simpleId')
            ->andWhere('benutzerGroup.benutzer = :userId')
            ->andWhere('backendGroup.active =1')
            ->setParameters(['simpleId' => $sin->value(), 'userId' => $user->getBenutzerId()])
            ->getQuery()
            ->getResult();

        $groupsOfUser = array_map(function ($item) {
            return $item['roleShort'];
        }, $groupResult);
        return array_intersect($necessaryRoles, $groupsOfUser) !== [];
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @return array
     */
    public function findUserGroupsInProjectShort(SIN $sin, BackendBenutzer $user): array
    {
        $params = ['simpleId' => $sin->value(), 'userId' => $user->benutzerId()];

        $groups = $this->genericRepository->createQueryBuilder($this->alias)
            ->select('roles.roleShort')
            ->join("{$this->alias}.group", 'backendGroup')
            ->join('backendGroup.role', 'roles')
            ->where("{$this->alias}.simple = :simpleId")
            ->join("backendGroup.backendBenutzerGroup", 'benutzerGroup')
            ->andWhere('benutzerGroup.benutzer = :userId')
            ->andWhere('backendGroup.active =1')
            ->setParameters($params)
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
        return array_map(function ($group) {
                return $group['roleShort'];
            }, $groups);
    }

    public function getUsersByGroupRoleInProject(BackendRoles $role, SIN $sin): array
    {
        return $this->genericRepository->createQueryBuilder("{$this->alias}")
            ->select('users.benutzerId AS id',
                'CONCAT(users.vorname, \' \', users.nachname) AS full_name',
                'users.email AS email')
            ->join("{$this->alias}.group", 'backendGroup')
            ->join("backendGroup.backendBenutzerGroup", 'benutzerGroup')
            ->join("benutzerGroup.benutzer", 'users')
            ->where("{$this->alias}.simple = :id")
            ->andWhere('backendGroup.role = :role')
            ->andWhere('backendGroup.active =1')
            ->setParameters(['id' => $sin->value(), 'role' => $role])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @param BackendRoles $role
     * @return int
     */
    public function getCountOfGroupsForRoleInProject(SIN $sin, BackendRoles $role): int
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("count(projectGroups.id)")
            ->join("{$this->alias}.group", 'backendGroup')
            ->where("{$this->alias}.simple = :id")
            ->andWhere("backendGroup.role = :role")
            ->andWhere('backendGroup.active =1')
            ->setParameters(['id' => $sin->value(), 'role' => $role])
            ->getQuery()
            ->getSingleScalarResult();
    }
    /**
     * @param array $roles
     * @param SIN $sin
     * @return array
     */
    public function findGroupByRoleName(array $roles, SIN $sin): array
    {
        return $this->genericRepository->createQueryBuilder('bpg')
            ->select('backendGroup.id',
                'backendGroup.email AS email',
                'backendGroup.name AS group')
            ->join('bpg.group', 'backendGroup')
            ->join('backendGroup.role', 'role')
            ->where('role.roleShort IN (:roles)')
            ->andWhere('bpg.simple = :id')
            ->setParameters(['id' => $sin->value(), 'roles' => $roles])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array $roles
     * @param int $userId
     * @return array
     */
    public function findUserProjectsByGroupRoles(array $roles, int $userId): array
    {
        return $this->genericRepository->createQueryBuilder('bpg')
            ->select('project.simpleId')
            ->distinct()
            ->join('bpg.group', 'backendGroup')
            ->join('backendGroup.role', 'role')
            ->join('bpg.simple', 'project')
            ->join('backendGroup.backendBenutzerGroup', 'benutzerGroup')
            ->where('role.roleShort IN (:roles)')
            ->andWhere('benutzerGroup.benutzer = :id')
            ->setParameters(['id' => $userId, 'roles' => $roles])
            ->orderBy('project.simpleId', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array $groupIds
     * @param array $simpleIds
     */
    public function deleteGroups(array $groupIds, array $simpleIds): void
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        $qb->delete()
            ->where($qb->expr()->in("{$this->alias}.simple", $simpleIds))
            ->andWhere($qb->expr()->in("{$this->alias}.group", $groupIds))
            ->getQuery()
            ->execute();
    }

    /**
     * @param array $ids
     * @param array $simpleIds
     * @return array
     */
    public function getGroupsByGroupIdAndProjectId(array $ids, array $simpleIds): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select(
            'backendGroup.name',
            'salesStammdaten.simpleId'
        )
            ->join("{$this->alias}.group", 'backendGroup')
            ->join("{$this->alias}.simple", 'salesStammdaten')
            ->where($qb->expr()->in("{$this->alias}.simple", $simpleIds))
            ->andWhere($qb->expr()->in("{$this->alias}.group", $ids))
            ->getQuery()
            ->getResult();
    }
}
