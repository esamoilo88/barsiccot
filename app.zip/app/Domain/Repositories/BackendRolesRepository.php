<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendRoles;
use App\Domain\Repositories\Interfaces\IBackendRolesRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\Query;

class BackendRolesRepository extends BaseRepository implements IBackendRolesRepository
{
    public string $alias = 'BackendRoles';

    /**
     * @param int $roleId
     * @return BackendRoles|object|null
     */
    public function find(int $roleId): ?BackendRoles
    {
        return $this->genericRepository->find($roleId);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findBy(['hide' => 0]));
    }

    /**
     * @param string $shortName
     * @return BackendRoles|object|null
     */
    public function findByShortName(string $shortName): ?BackendRoles
    {
        return $this->genericRepository->findOneBy(['roleShort' => $shortName]);
    }

    /**
     * @param array $roleIds
     * @return array|null
     */
    public function findIn(array $roleIds): ?array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.roleId IN (:roleIds)")
            ->setParameter('roleIds', $roleIds)
            ->getQuery()
            ->getResult();
    }
}

