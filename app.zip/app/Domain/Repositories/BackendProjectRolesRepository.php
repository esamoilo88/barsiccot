<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Entities\BackendRoles;
use App\Domain\Repositories\Interfaces\IBackendProjectRolesRepository;
use App\Domain\Repositories\Utils\Filters\BackendBenutzerFilter;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class BackendProjectRolesRepository extends BaseRepository implements IBackendProjectRolesRepository
{
    public string $alias = 'BackendProjectRoles';

    /**
     * @param int $id
     * @return BackendRoles|null|object
     */
    public function find(int $id): ?BackendProjectRoles
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @param array $necessaryRoles
     * @return bool
     */
    public function isUserHasRoles(SIN $sin, BackendBenutzer $user, array $necessaryRoles): bool
    {
        $result = $this->genericRepository
            ->createQueryBuilder('bpr')
            ->select('br.roleShort')
            ->join('bpr.backendRoles', 'br')
            ->where('bpr.salesStammdaten = :simpleId')
            ->andWhere('bpr.backendBenutzer = :userId')
            ->setParameters(['simpleId' => $sin->value(), 'userId' => $user->getBenutzerId()])
            ->getQuery()
            ->getResult();

        $rolesOfUser = array_map(function ($item) {
            return $item['roleShort'];
        }, $result);

        return array_intersect($necessaryRoles, $rolesOfUser) !== [];
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @return bool
     */
    public function isUserHasAnyRole(SIN $sin, BackendBenutzer $user): bool
    {
        $roles = $this->genericRepository->createQueryBuilder('bpr')
            ->select('COUNT(bpr.id)')
            ->where('bpr.salesStammdaten = :simpleId')
            ->andWhere('bpr.backendBenutzer = :userId')
            ->setParameters(['simpleId' => $sin->value(), 'userId' => $user->getBenutzerId()])
            ->getQuery()
            ->getSingleScalarResult();

        return (int)$roles > 0;
    }

    /**
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @return Collection
     */
    public function findUserRolesInProject(SIN $sin, BackendBenutzer $user): Collection
    {
        $query = $this->getUserRolesBySimpleIdQuery($sin->value(), $user->benutzerId());
        return new ArrayCollection($query->getQuery()->getResult());
    }

    /**
     * Get the list of short names of roles for a specific
     * user in a specific project
     * @param SIN $sin
     * @param BackendBenutzer $user
     * @return array
     */
    public function findUserRolesInProjectShort(SIN $sin, BackendBenutzer $user): array
    {
        $params = ['simpleId' => $sin->value(), 'userId' => $user->benutzerId()];

        $roles = $this->genericRepository->createQueryBuilder($this->alias)
            ->select("br.roleShort")
            ->join("{$this->alias}.backendRoles", 'br')
            ->where("{$this->alias}.salesStammdaten = :simpleId")
            ->andWhere("{$this->alias}.backendBenutzer = :userId")
            ->setParameters($params)
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);

        return array_map(function ($role) {
            return $role['roleShort'];
        }, $roles);
    }

    /**
     * @param BackendRoles $role
     * @param SIN $sin
     * @return array
     */
    public function getUsersByRoleInProject(BackendRoles $role, SIN $sin): array
    {
        return $this->genericRepository->createQueryBuilder('bpr')
            ->select('users.benutzerId AS id',
                'CONCAT(users.vorname, \' \', users.nachname) AS full_name',
                'users.email AS email')
            ->join('bpr.backendBenutzer', 'users')
            ->where('bpr.backendRoles = :role')
            ->andWhere('bpr.salesStammdaten = :id')
            ->setParameters(['id' => $sin->value(), 'role' => $role])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param BackendRoles $role
     * @param int $sin
     * @return array|null
     */
    public function findNotRepresentativeByRole(BackendRoles $role, int $sin): ?array
    {
        return $this->genericRepository->createQueryBuilder('bpr')
            ->select('users.benutzerId AS id',
                'CONCAT(users.vorname, \' \', users.nachname) AS full_name',
                'users.email AS email')
            ->join('bpr.backendBenutzer', 'users')
            ->where('bpr.backendRoles = :role')
            ->andWhere('bpr.salesStammdaten = :id')
            ->andWhere("bpr.representative = 0")
            ->setParameters(['id' => $sin, 'role' => $role])
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param int $simpleId
     * @return array
     */
    public function getProjectUsers(int $simpleId): array
    {
        return $this->genericRepository
            ->createQueryBuilder('bpr')
            ->select(
                'users.benutzerId AS id',
                'users.vorname AS first_name',
                'users.nachname AS last_name',
                'users.email',
                'users.telNr',
                'CONCAT(users.nachname, \', \', users.vorname) AS full_name',
                'roles.roleId AS role_id',
                'roles.roleLong AS role',
                'roles.roleShort AS role_short',
                'roleinfo.id AS roleinfo_id',
                'roleinfo.name AS roleinfo_name',
                'areas.bezeichnung AS area',
                'bpr.representative',
                'bpr.id AS project_role_id'
            )
            ->join('bpr.backendRoles', 'roles')
            ->join('bpr.backendBenutzer', 'users')
            ->join('users.bereich', 'areas')
            ->leftJoin('bpr.backendRoleInfo', 'roleinfo')
            ->where('bpr.salesStammdaten = :simpleId')
            ->setParameter('simpleId', $simpleId)
            ->orderBy('users.nachname', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $simpleId
     * @return int
     */
    public function getProjectUsersCount(int $simpleId): int
    {
        return $this->genericRepository
            ->createQueryBuilder('bpr')
            ->select('COUNT(users.benutzerId) AS count')
            ->join('bpr.backendBenutzer', 'users')
            ->where('bpr.salesStammdaten = :simpleId')
            ->setParameter('simpleId', $simpleId)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param int $simpleId
     * @param int $userId
     * @return QueryBuilder
     */
    protected function getUserRolesBySimpleIdQuery(int $simpleId, int $userId): QueryBuilder
    {
        $params = [
            'simpleId' => $simpleId,
            'userId' => $userId,
        ];

        return $this->genericRepository
            ->createQueryBuilder('bpr')
            ->select('bpr', 'br', 'ss')
            ->join('bpr.backendRoles', 'br')
            ->join('bpr.salesStammdaten', 'ss')
            ->join('bpr.backendBenutzer', 'bb')
            ->where('ss.globalGate = :simpleId')
            ->andWhere('bb.benutzerId = :userId')
            ->setParameters($params);
    }

    /**
     * @param SIN $sin
     * @param BackendRoles $role
     * @return int
     */
    public function getCountOfMembersForRoleInProject(SIN $sin, BackendRoles $role): int
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("count({$this->alias}.id)")
            ->where("{$this->alias}.salesStammdaten = :id")
            ->andWhere("{$this->alias}.backendRoles = :role")
            ->setParameters(['id' => $sin->value(), 'role' => $role])
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param int $simpleId
     * @param int $userId
     * @param int $roleId
     * @return BackendProjectRoles|null
     * @throws NonUniqueResultException
     */
    public function findUserRoleInProject(int $simpleId, int $userId, int $roleId): ?BackendProjectRoles
    {
        $query = $this->getUserRolesBySimpleIdQuery($simpleId, $userId);

        return $query
            ->andWhere('br.roleId = :role')
            ->setParameter('role', $roleId)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param array $roles
     * @param SIN $sin
     * @return array
     */
    public function findUsersByRoleName(array $roles, SIN $sin): array
    {
        return $this->genericRepository->createQueryBuilder('bpr')
            ->select('users.benutzerId AS id',
                'CONCAT(users.nachname, \', \', users.vorname) AS fullName',
                'users.email AS email',
                'users.vorname',
                'users.nachname')
            ->join('bpr.backendBenutzer', 'users')
            ->join('bpr.backendRoles', 'role')
            ->where('role.roleShort IN (:roles)')
            ->andWhere('bpr.salesStammdaten = :id')
            ->setParameters(['id' => $sin->value(), 'roles' => $roles])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array $roles
     * @param int $userId
     * @return array
     */
    public function findUserProjectsByRoles(array $roles, int $userId): array
    {
        return $this->genericRepository->createQueryBuilder('bpr')
            ->select('project.simpleId')
            ->distinct()
            ->join('bpr.backendRoles', 'role')
            ->join('bpr.salesStammdaten', 'project')
            ->where('role.roleShort IN (:roles)')
            ->andWhere('bpr.backendBenutzer = :id')
            ->setParameters(['id' => $userId, 'roles' => $roles])
            ->orderBy('project.simpleId', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array $ids
     * @param array $simpleIds
     */
    public function deleteMembers(array $ids, array $simpleIds): void
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        $qb->delete()
            ->where($qb->expr()->in("{$this->alias}.salesStammdaten", $simpleIds))
            ->andWhere($qb->expr()->in("{$this->alias}.backendBenutzer", $ids))
            ->getQuery()
            ->execute();
    }

    /**
     * @param array $ids
     * @param array $simpleIds
     * @return array
     */
    public function getMembersByUserIdAndProjectId(array $ids, array $simpleIds): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select(
            'users.benutzerId',
            'CONCAT(users.nachname, \', \', users.vorname) AS fullName',
            'salesStammdaten.simpleId',
            'role.roleId',
            'role.roleLong'
        )
            ->join("{$this->alias}.backendBenutzer", 'users')
            ->join("{$this->alias}.backendRoles", 'role')
            ->join("{$this->alias}.salesStammdaten", 'salesStammdaten')
            ->where($qb->expr()->in("{$this->alias}.salesStammdaten", $simpleIds))
            ->andWhere($qb->expr()->in("{$this->alias}.backendBenutzer", $ids))
            ->getQuery()
            ->getResult();
    }

}
