<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\CompetenceSkillprofile;
use Doctrine\Common\Collections\Collection;

interface ICompetenceSkillprofileRepository extends IBaseRepository
{
    public function find(int $id): ?CompetenceSkillprofile;
    public function findAll(): Collection;
}
