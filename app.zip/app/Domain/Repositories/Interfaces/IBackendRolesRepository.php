<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendRoles;
use Doctrine\Common\Collections\Collection;

interface IBackendRolesRepository extends IBaseRepository
{
    public function find(int $roleId): ?BackendRoles;
    public function findAll(): Collection;
    public function findByShortName(string $shortName): ?BackendRoles;
}
