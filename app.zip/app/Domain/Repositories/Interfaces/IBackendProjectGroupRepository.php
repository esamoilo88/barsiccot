<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectGroup;
use App\Domain\Entities\BackendRoles;
use App\Domain\ValueObjects\SIN;

interface IBackendProjectGroupRepository extends IBaseRepository
{
    public function find(int $id): ?BackendProjectGroup;
    public function findAssignedGroupsInProject(int $simpleId): array;
    public function deleteGroups(array $ids, array $simpleIds): void;
    public function getGroupsByGroupIdAndProjectId(array $ids, array $simpleIds): array;
    public function findCountGroupsInProject(int $simpleId): int;
    public function isUserHasAnyGroups(SIN $sin, BackendBenutzer $user): bool;
    public function getUsersByGroupRoleInProject(BackendRoles $role, SIN $sin): array;
    public function isUserHasGroups(SIN $sin, BackendBenutzer $user, array $necessaryRoles): bool;
    public function findUserGroupsInProjectShort(SIN $sin, BackendBenutzer $user): array;
    public function getCountOfGroupsForRoleInProject(SIN $sin, BackendRoles $role): int;
    public function findGroupByRoleName(array $roles, SIN $sin): array;
    public function findUserProjectsByGroupRoles(array $roles, int $userId): array;
}
