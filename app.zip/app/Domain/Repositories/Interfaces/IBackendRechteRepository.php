<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendRechte;

interface IBackendRechteRepository extends IBaseRepository
{
    public function find(int $rechteId): ?BackendRechte;
    public function findAll(): array;
    public function findIn(array $values): array;
}
