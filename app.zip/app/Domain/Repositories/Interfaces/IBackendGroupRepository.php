<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendGroup;
use Doctrine\Common\Collections\Collection;

interface IBackendGroupRepository extends IBaseRepository
{
    public function find(int $id): ?BackendGroup;
    public function findAll(): Collection;
    public function findActive(): array;
}
