<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendPreferencesBenutzer;

interface IBackendPreferencesBenutzerRepository extends IBaseRepository
{
    public function find(int $id): ?BackendPreferencesBenutzer;
    public function findByUser(int $userId, bool $grouped = false): array;
}
