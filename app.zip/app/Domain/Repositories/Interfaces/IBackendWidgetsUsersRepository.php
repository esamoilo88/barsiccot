<?php

namespace App\Domain\Repositories\Interfaces;

interface IBackendWidgetsUsersRepository extends IBaseRepository
{
    public function findUserWidgets(int $userId, bool $grouped = false): array;
}
