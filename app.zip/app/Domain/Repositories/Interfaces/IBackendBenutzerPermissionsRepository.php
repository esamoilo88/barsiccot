<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;

interface IBackendBenutzerPermissionsRepository extends IBaseRepository
{
    public function isUserHasRights(array $rechteIds, BackendBenutzer $backendBenutzer): bool;
    public function clear(BackendBenutzer $user): void;
}
