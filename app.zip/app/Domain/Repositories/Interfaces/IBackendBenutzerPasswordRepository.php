<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendBenutzerPassword;
use Doctrine\Common\Collections\Collection;

interface IBackendBenutzerPasswordRepository extends IBaseRepository
{
    public function find(int $id): BackendBenutzerPassword;
    public function findAll(): Collection;
    public function findLastThreeRows(BackendBenutzer $user): Collection;
}
