<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use App\Domain\Repositories\Utils\Sort\Sortable;

interface IBackendConfigRepository extends Paginationable, Sortable, IBaseRepository
{
    public function getConfig(array $fields): array;
    public function getPaginated(PaginationRequestDTO $gridParams, Filterable $filter = null): PaginationResponseDTO;
    public function getConfigGroups(): array;
}
