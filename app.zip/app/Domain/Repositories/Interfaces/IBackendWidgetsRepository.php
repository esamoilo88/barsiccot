<?php

namespace App\Domain\Repositories\Interfaces;

interface IBackendWidgetsRepository extends IBaseRepository
{
    public function findUserWidgets(int $userId): array;
    public function findWidgetsForProfile(int $userId): array;
}
