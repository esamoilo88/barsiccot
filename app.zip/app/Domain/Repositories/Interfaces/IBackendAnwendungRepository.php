<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;
use Doctrine\Common\Collections\Collection;

interface IBackendAnwendungRepository extends IBaseRepository
{
    public function findAnwendungsByUser(BackendBenutzer $backendBenutzer): Collection;
    public function findAllVisibleAnwendungs(): Collection;
}
