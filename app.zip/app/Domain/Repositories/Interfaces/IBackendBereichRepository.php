<?php


namespace App\Domain\Repositories\Interfaces;


use App\Domain\Entities\BackendBereich;
use Doctrine\Common\Collections\Collection;

interface IBackendBereichRepository extends IBaseRepository
{
    public function find(int $id): ?BackendBereich;
    public function findAll(): Collection;
    public function findByRessort4KurzOrBezeichnung(string $value): array;
}
