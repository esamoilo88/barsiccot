<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Entities\BackendRoles;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\Collection;

interface IBackendProjectRolesRepository extends IBaseRepository
{
    public function find(int $id): ?BackendProjectRoles;
    public function isUserHasRoles(SIN $sin, BackendBenutzer $user, array $necessaryRoles): bool;
    public function isUserHasAnyRole(SIN $sin, BackendBenutzer $user): bool;
    public function findUserRolesInProject(SIN $sin, BackendBenutzer $user): Collection;
    public function getCountOfMembersForRoleInProject(SIN $sin, BackendRoles $role): int;
    public function findUserRoleInProject(int $simpleId, int $userId, int $roleId): ?BackendProjectRoles;
    public function getUsersByRoleInProject(BackendRoles $role, SIN $sin): array;
    public function getProjectUsers(int $simpleId): array;
    public function findNotRepresentativeByRole(BackendRoles $role,int $sin): ?array;
    public function findUsersByRoleName(array $roles, SIN $sin): array;
    public function findUserProjectsByRoles(array $roles, int $userId): array;
    public function deleteMembers(array $ids, array $simpleIds): void;
    public function getMembersByUserIdAndProjectId(array $ids, array $simpleIds): array;
}
