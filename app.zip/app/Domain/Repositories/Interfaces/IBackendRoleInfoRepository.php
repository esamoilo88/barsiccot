<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendRoleInfo;
use Doctrine\Common\Collections\Collection;

interface IBackendRoleInfoRepository
{
    public function find(int $id): ?BackendRoleInfo;
    public function findAll(): Collection;
}
