<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Repositories\Utils\CustomQueryBuilder;

interface IBaseRepository
{
    public function findCustom(array $fields = [], array $options = []): CustomQueryBuilder;
    public function setFields($entity, array $fields);
    public function getFields(string $entityClassName = null, array $fields = [], array $except = [], bool $withAliasPrefix = true): array;
    public function prefixFields(array $fields): array;
}
