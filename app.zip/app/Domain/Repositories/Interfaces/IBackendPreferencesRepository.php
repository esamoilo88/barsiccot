<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendPreferences;

interface IBackendPreferencesRepository extends IBaseRepository
{
    public function find(int $id): ?BackendPreferences;
    public function findAll(): array;
    public function findUserPreferences(int $userId, bool $withAdditions = false): array;
}
