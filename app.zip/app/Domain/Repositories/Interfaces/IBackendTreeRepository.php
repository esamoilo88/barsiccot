<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendTree;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use App\Domain\Repositories\Utils\Sort\Sortable;
use Doctrine\Common\Collections\Collection;

interface IBackendTreeRepository extends Paginationable, Sortable, IBaseRepository
{
    public function getPaginated(PaginationRequestDTO $gridParamsDTO, Filterable $filter = null): PaginationResponseDTO;
    public function findByControllerAndAction(string $controller, string $action): ?BackendTree;
    public function getAllRoutes(): Collection;
    public function getUserProtectedRoutes(BackendBenutzer $user, bool $minified = false): Collection;
    public function getNavigationRoutes(BackendBenutzer $user = null): Collection;
}
