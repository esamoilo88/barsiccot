<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendProjectGroup;
use App\Domain\ValueObjects\SIN;

interface IBackendBenutzerGroupRepository extends IBaseRepository
{
    public function find(int $id): ?BackendProjectGroup;
    public function findByUserId(BackendBenutzer $userId): array;
    public function clear(BackendBenutzer $user): void;
}
