<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\CostsKostenart;

interface ICostsKostenartRepository extends IBaseRepository
{
    public function find(int $id): ?CostsKostenart;
    public function findAll(): array;
    public function getKostenarts(): array;
    public function getExcelExportKostenart(): array;
    public function getValidKostenarten($relevant = 0): array;
    public function getKostenartNames(): array;
    public function getWithKostentypById(int $id): ?CostsKostenart;
}
