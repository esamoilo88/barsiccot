<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\User\UserSearchDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendBenutzer;
use App\Domain\Entities\BackendRoles;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use App\Domain\Repositories\Utils\Sort\Sortable;
use App\Domain\ValueObjects\SIN;

interface IBackendBenutzerRepository extends Paginationable, Sortable, IBaseRepository
{
    public function find(int $userId): ?BackendBenutzer;
    public function findByUserName(string $userName): ?BackendBenutzer;
    public function findByEmail(string $email): ?BackendBenutzer;
    public function getPaginated(int $page, array $filters = []): PaginationResponseDTO;
    public function search(UserSearchDTO $dto): array;
    public function getListToOfferAssign(PaginationRequestDTO $dto, Filterable $filter): PaginationResponseDTO;
    public function couldUserHaveRole(BackendBenutzer $user, BackendRoles $role): bool;
    public function getAnsprechpartners(SIN $sin): array;
    public function findUserWithProjectRoles(int $userId, SIN $sin, array $roles): ?BackendBenutzer;
    public function findUniqueByEmails(array $emails): array;
    public function getUsers(array $filters): array;
    public function findWithBereich(int $userId): ?BackendBenutzer;
    public function findFirstByEmail(string $email): ?BackendBenutzer;
    public function findById(int $id): ?BackendBenutzer;
    public function getPaginatedForAdmin(PaginationRequestDTO $dto): PaginationResponseDTO;
    public function findByLowerEmail(string $email): array;
    public function findUserData(int $userId): ?BackendBenutzer;
}
