<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\Entities\BackendMailhistorie;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use App\Domain\Repositories\Utils\Sort\Sortable;
use Doctrine\Common\Collections\Collection;

interface IBackendMailhistorieRepository extends Paginationable, Sortable, IBaseRepository
{
    public function find(int $id): ?BackendMailhistorie;
    public function findAll(): Collection;
    public function getMailInfo(int $mailId): array;
}
