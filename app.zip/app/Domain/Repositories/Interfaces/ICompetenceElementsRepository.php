<?php

namespace App\Domain\Repositories\Interfaces;

use App\Domain\ValueObjects\SIN;

interface ICompetenceElementsRepository
{
    public function findBySin(SIN $sin): array;
    public function deleteBySIN(SIN $sin): void;
}
