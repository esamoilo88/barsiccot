<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\IGlobalLogGroupRepository;

class GlobalLogGroupRepository extends BaseRepository implements IGlobalLogGroupRepository
{
    protected string $alias = "GlobalLogGroup";
}
