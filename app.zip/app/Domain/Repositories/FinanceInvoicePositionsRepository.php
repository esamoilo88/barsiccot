<?php

namespace App\Domain\Repositories;

use App\Components\Calendar\Calendar;
use App\Domain\Entities\FinanceInvoicePositionsLbu;
use App\Domain\Repositories\Interfaces\IFinanceInvoicePositionsRepository;
use App\Domain\Repositories\Utils\Conditions\CBI\CBIConditions;
use App\Domain\ResultSetMapping\CBI\InvoicePosition;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\QueryBuilder;

class FinanceInvoicePositionsRepository extends BaseRepository implements IFinanceInvoicePositionsRepository
{
    protected string $alias = 'FinanceInvoicePositions';

    /**
     * @param int $streamId
     * @param int $switch
     * @param array $notIdLbus
     * @return array
     */
    public function aggregatePositions(int $streamId, int $switch = 0, array $notIdLbus = []): array
    {
        $notIdLbusStr = '';
        if (!empty($notIdLbus)) {
            $notIdLbusStr = 'AND lbu.lbu_id not in (' . implode(',', $notIdLbus) . ')';
        }

        $rsm = new ResultSetMapping();

        $rsm->addEntityResult(InvoicePosition::class, 'p');
        $rsm->addFieldResult('p', 'simple_id', 'auftrag');
        $rsm->addFieldResult('p', 'unit_price', 'unitPrice');
        $rsm->addFieldResult('p', 'quantity', 'quantity');
        $rsm->addFieldResult('p', 'short_text', 'shortText');
        $rsm->addFieldResult('p', 'psp_element_id', 'pspElementId');
        $rsm->addFieldResult('p', 'psp_element', 'pspElement');
        $rsm->addFieldResult('p', 'mat_nr_id', 'matNrId');
        $rsm->addFieldResult('p', 'mat_nr', 'matNr');
        $rsm->addFieldResult('p', 'icp_kont_konto_id', 'icpKontKontoId');
        $rsm->addFieldResult('p', 'sachkonto', 'sachkonto');
        $rsm->addFieldResult('p', 'icp_kont_psp_kst', 'icpKontPspKst');
        $rsm->addFieldResult('p', 'lbu_ids', 'lbuIds', InvoicePosition::class);

        $condition = CBIConditions::getCommonConditions($switch);

        $currentFakturaMonth = Calendar::getCurrentFakturaMonth();
        $currentFakturaYear = Calendar::getCurrentFakturaYear();

        $sql = "
            SELECT
            dbo.Offer_Auftrag.simple_id,
            SUM(lbu.price) AS unit_price,
            1 AS quantity,
            'SIN/' + CAST(dbo.Offer_Auftrag.simple_id AS Varchar) + ' - '
                + dbo.Sales_Label.abkuerzung + ' - Fakt ' + CAST({$currentFakturaMonth} AS Varchar) + '/'
                + CAST({$currentFakturaYear} AS Varchar) AS short_text,
            dbo.Sales_Stammdaten.psp_element_id,
            dbo.Finance_PSP.psp_element,
            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                'OA'
            ELSE
                'PCS'
            END AS source,

            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                dbo.Offer_Auftrag.mat_nr_id
            ELSE
                pcs.mat_nr_id
            END AS mat_nr_id,

            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                mat_oa.mat_nr
            ELSE
                mat_pcs.mat_nr
            END AS mat_nr,

            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                dbo.Offer_Auftrag.default_icp_kont_konto_id
            ELSE
                pcs.icp_kont_konto_id
            END AS icp_kont_konto_id,

            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                sk_sin.sachkonto
            ELSE
                sk_pcs.sachkonto
            END AS sachkonto,

            CASE WHEN pcs.cbi_use_pcs = 0 OR dbo.Offer_Auftrag.cbi_sin_control = 1 THEN
                dbo.Offer_Auftrag.default_icp_kont_psp_kst
            ELSE
                pcs.icp_kont_psp_kst
            END AS icp_kont_psp_kst,
            STRING_AGG(CAST(lbu.lbu_id AS VARCHAR), '-') AS lbu_ids

            FROM dbo.Offer_Auftrag
            INNER JOIN dbo.Offer_Profitcenter_Settings pcs ON dbo.Offer_Auftrag.profitcenter_settings_id = pcs.profitcenter_settings_id
            INNER JOIN dbo.Sales_Label ON pcs.[label_id] = dbo.Sales_Label.[label_id]
            INNER JOIN dbo.Sales_Stammdaten ON dbo.Offer_Auftrag.simple_id = dbo.Sales_Stammdaten.simple_id
            INNER JOIN dbo.Finance_PSP ON dbo.Sales_Stammdaten.psp_element_id = dbo.Finance_PSP.id
            INNER JOIN dbo.Offer_Profitcenter_Settings_Billingtype ON pcs.billing_type_id = dbo.Offer_Profitcenter_Settings_Billingtype.billing_type_id
            INNER JOIN dbo.Offer_Debitor ON dbo.Offer_Debitor.debitor_id = pcs.debitor_id
            INNER JOIN dbo.v_Finance_Positions_LBU lbu ON dbo.Offer_Auftrag.simple_id = lbu.simple_id
            INNER JOIN dbo.Offer_Faktura_LBU_Status ON lbu.status_id = dbo.Offer_Faktura_LBU_Status.id
            LEFT JOIN dbo.Offer_Faktura_LBU_Daten_Sachkonto sk_pcs ON pcs.icp_kont_konto_id = sk_pcs.konto_id
            LEFT JOIN dbo.Offer_Faktura_LBU_Daten_Sachkonto sk_sin ON dbo.Offer_Auftrag.default_icp_kont_konto_id = sk_sin.konto_id
            LEFT JOIN dbo.Offer_Faktura_Materialnummer mat_pcs ON pcs.mat_nr_id = mat_pcs.mat_nr_id
            LEFT JOIN dbo.Offer_Faktura_Materialnummer mat_oa ON dbo.Offer_Auftrag.mat_nr_id = mat_oa.mat_nr_id
            INNER JOIN dbo.Sales_SIN_Status on dbo.Sales_Stammdaten.simple_id = dbo.Sales_SIN_Status.simple_id
            INNER JOIN dbo.Sales_Status on dbo.Sales_Status.id = dbo.Sales_SIN_Status.status_id
            WHERE dbo.Offer_Profitcenter_Settings_Billingtype.hard_billing = 0
            AND pcs.frequency = 'monthly_3AT'
            AND Offer_Faktura_LBU_Status.sys_name = 'Ready'
            AND Finance_PSP.locked = 0
            AND Sales_Status.billing_locked = 0
            AND pcs.stream_id = {$streamId}
            {$notIdLbusStr}

            {$condition}

            GROUP BY
            dbo.Offer_Auftrag.simple_id,
            dbo.Sales_Label.abkuerzung,
            dbo.Sales_Stammdaten.psp_element_id,
            dbo.Finance_PSP.psp_element,
            pcs.icp_kont_konto_id,
            pcs.icp_kont_psp_kst,
            pcs.cbi_use_pcs,
            dbo.Offer_Auftrag.cbi_sin_control,
            dbo.Offer_Auftrag.mat_nr_id,
            dbo.Offer_Auftrag.default_icp_kont_konto_id,
            dbo.Offer_Auftrag.default_icp_kont_psp_kst,
            pcs.mat_nr_id,
            mat_pcs.mat_nr_id,
            mat_pcs.mat_nr,
            mat_oa.mat_nr_id,
            mat_oa.mat_nr,
            sk_pcs.sachkonto,
            sk_sin.sachkonto

            ORDER BY dbo.Offer_Auftrag.simple_id ASC
        ";

        return $this->entityManager->createNativeQuery($sql, $rsm)->getResult();
    }

    /**
     * @param array $ids
     * @return array
     */
    public function getAlreadyMapped(array $ids): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select(
            'lbu.lbuId',
            "{$this->alias}.id",
        )
            ->join("{$this->alias}.invoice", 'invoice')
            ->join(FinanceInvoicePositionsLbu::class, 'lbu', 'WITH', "{$this->alias}.id = lbu.position")
            ->where($qb->expr()->in('invoice.id', $ids))
            ->getQuery()
            ->getResult();
    }
}
