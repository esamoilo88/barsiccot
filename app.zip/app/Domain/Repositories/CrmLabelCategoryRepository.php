<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CrmCustomerLabel;
use App\Domain\Entities\CrmLabelCategory;
use App\Domain\Repositories\Interfaces\ICrmLabelCategoryRepository;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class CrmLabelCategoryRepository extends BaseRepository implements ICrmLabelCategoryRepository
{
    protected string $alias = 'CrmLabelCategory';

    /**
     * @param int $id
     * @return CrmCustomerLabel|object
     */
    public function find(int $id): CrmLabelCategory
    {
        return $this->genericRepository->find($id);
    }
}
