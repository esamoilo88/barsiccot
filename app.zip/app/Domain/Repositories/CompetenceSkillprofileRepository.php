<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CompetenceSkillprofile;
use App\Domain\Repositories\Interfaces\ICompetenceSkillprofileRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

class CompetenceSkillprofileRepository extends BaseRepository implements ICompetenceSkillprofileRepository
{
    /**
     * @param  int  $id
     * @return CompetenceSkillprofile|object
     */
    public function find(int $id): ?CompetenceSkillprofile
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }
}

