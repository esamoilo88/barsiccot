<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendWidgetsUsers;
use App\Domain\Repositories\Interfaces\IBackendWidgetsRepository;

class BackendWidgetsRepository extends BaseRepository implements IBackendWidgetsRepository
{
    protected string $alias = 'BackendWidgets';

    /**
     * @param int $userId
     * @return array
     */
    public function findUserWidgets(int $userId): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->join(BackendWidgetsUsers::class, 'bwu', 'WITH', "{$this->alias}.id = bwu.widget")
            ->where("bwu.user = :userId")
            ->andWhere("{$this->alias}.hide = 0")
            ->setParameter('userId', $userId)
            ->orderBy('bwu.sort', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $userId
     * @return array
     */
    public function findWidgetsForProfile(int $userId): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "$this->alias AS widget",
                'CASE WHEN bwu.id IS NOT NULL THEN 1 ELSE 0 END AS isSelected',
                'bwu.sort'
            )
            ->leftJoin(BackendWidgetsUsers::class, 'bwu', 'WITH', "bwu.widget = {$this->alias}.id AND bwu.user = :user")
            ->setParameter('user', $userId)
            ->getQuery()
            ->getResult();
    }
}
