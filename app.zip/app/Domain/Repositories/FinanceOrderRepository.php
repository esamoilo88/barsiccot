<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceOrder;
use App\Domain\Repositories\Interfaces\IFinanceOrderRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\NonUniqueResultException;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\QueryBuilder;

class FinanceOrderRepository extends BaseRepository implements IFinanceOrderRepository
{
    protected string $alias = 'finance_order';

    /**
     * @param int $id
     * @return FinanceOrder|object|null
     */
    public function find(int $id): ?FinanceOrder
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param int $sin
     * @param bool $onlyActive
     * @return array
     */
    public function findBySIN(int $sin, bool $onlyActive = false): array
    {
        $fields = [
            $this->alias . '.id',
            $this->alias . '.orderNumber',
            $this->alias . '.active',
            $this->alias . '.expire',
            $this->alias . '.budget'
        ];
        $qb = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($fields)
            ->where("{$this->alias}.simpleId = :sin")
            ->setParameter('sin', $sin);

        if ($onlyActive) {
            $qb->andWhere("{$this->alias}.active = 1");
        }

        return $qb->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @return FinanceOrder|null
     */
    public function getFirstActiveOrder(SIN $sin): ?array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.orderNumber",
                "{$this->alias}.active"
            )
            ->where("{$this->alias}.simpleId = :sin")
            ->andWhere("{$this->alias}.active = 1")
            ->orderBy("{$this->alias}.id", 'ASC')
            ->setParameter('sin', $sin->value())
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param SIN $sin
     * @return string|null
     */
    public function findActualOrderNumberAsString(SIN $sin): ?string
    {
        $result = $this->getActualOrderNumberQuery($sin)
            ->select("{$this->alias}.orderNumber")
            ->getQuery()
            ->getResult();

        return $result ? $result[0]['orderNumber'] : null;
    }

    /**
     * @param SIN $sin
     * @return FinanceOrder|null
     * @throws NonUniqueResultException
     */
    public function findActualOrderNumberAsObject(SIN $sin): ?FinanceOrder
    {
        return $this->getActualOrderNumberQuery($sin)->getQuery()->getOneOrNullResult();
    }

    /**
     * @param SIN $sin
     * @return QueryBuilder
     */
    private function getActualOrderNumberQuery(SIN $sin): QueryBuilder
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->where("{$this->alias}.simpleId = :sin")
            ->andWhere("{$this->alias}.active = 1")
            ->orderBy("{$this->alias}.created", 'DESC')
            ->setParameter('sin', $sin->value())
            ->setMaxResults(1);
    }

    /**
     * @param SIN $sin
     * @return FinanceOrder|null
     */
    public function getDefaultOrderNumber(SIN $sin): ?FinanceOrder
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->where("{$this->alias}.simpleId = :sin")
            ->andWhere("{$this->alias}.active = 1")
            ->andWhere("{$this->alias}.isDefault = 1")
            ->setParameter('sin', $sin->value())
            ->getQuery()
            ->getOneOrNullResult();
    }
}
