<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\FinanceSinStatus;
use App\Domain\Entities\OfferAngebotVk;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\ResultSetMapping\CollectedCreateUpdateProjectData;
use App\Domain\Entities\GlobalGate;
use App\Domain\Repositories\Interfaces\IGlobalGateRepository;
use App\Domain\ResultSetMapping\CollectedSalesData;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\QueryBuilder;

class GlobalGateRepository extends BaseRepository implements IGlobalGateRepository
{
    public string $alias = 'GlobalGate';

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
            "simpleId" => "{$this->alias}.simpleId"
        ];
    }

    /**
     * @param SIN $sin
     * @return GlobalGate|object|null
     */
    public function findBySIN(SIN $sin): ?GlobalGate
    {
        return $this->genericRepository->find($sin->value());
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param SIN $sin
     * @return CollectedCreateUpdateProjectData|null
     * @throws NonUniqueResultException
     */
    public function collectDataForProjectAndClearingAccount(SIN $sin): ?CollectedCreateUpdateProjectData
    {
        $rsm = new ResultSetMapping();

        $rsm->addEntityResult(CollectedCreateUpdateProjectData::class, 'd');
        $rsm->addFieldResult('d', 'simple_id', 'simpleId');
        $rsm->addFieldResult('d', 'vorhabenname', 'vorhabenname');
        $rsm->addFieldResult('d', 'sicherheitsstufe', 'sicherheitsstufe');
        $rsm->addFieldResult('d', 'status', 'status');
        $rsm->addFieldResult('d', 'kunde_crmt_nummer', 'kundeCrmtNummer');
        $rsm->addFieldResult('d', 'ust_id', 'ustId');
        $rsm->addFieldResult('d', 'kundenstandort', 'kundenstandort');
        $rsm->addFieldResult('d', 'volumen_dtts', 'volumenDtts');
        $rsm->addFieldResult('d', 'auftragswahrscheinlichkeit', 'auftragswahrscheinlichkeit');
        $rsm->addFieldResult('d', 'created', 'created');
        $rsm->addFieldResult('d', 'vertragsende', 'vertragsende');
        $rsm->addFieldResult('d', 'vorhabenbeschreibung', 'vorhabenbeschreibung');
        $rsm->addFieldResult('d', 'gp_id', 'gpId');
        $rsm->addFieldResult('d', 'gp_name_lang', 'gpNameLang');
        $rsm->addFieldResult('d', 'gp_nr', 'gpNr');

        $sql = "
            SELECT
                gg.simple_id,
                gg.thema AS vorhabenname,
                gg.sicherheitsstufe,
                CASE WHEN oa.simple_id IS NOT NULL THEN 'confirmed'
                     ELSE CASE WHEN ab.simple_id IS NOT NULL AND vhs.verkaufsstufen_id = " . config('dbconfig.competence.SALES_LOSS_ID') . " THEN 'lost'
                     ELSE CASE WHEN ab.simple_id IS NOT NULL AND vhs.verkaufsstufen_id = " . config('dbconfig.competence.SALES_STOP_ID') . " THEN 'canceled'
                     ELSE 'opportunity' END END END
                AS status,
                ss.kundennummer AS kunde_crmt_nummer,
                ss.ust_id AS ust_id,
                ss.kundenstandort,
                CAST(ss.volumen_dtts AS money) AS volumen_dtts,
                ss.auftragswahrscheinlichkeit,
                CONVERT(varchar(10), gg.created, 104) AS created,
                CONVERT(varchar(10), af.vertragsende, 104) AS vertragsende,
                ss.vorhabenbeschreibung,
                ss.gp_id,
                gp.gp_name_lang,
                gp.gp_nr
            FROM global_gate gg
            INNER JOIN sales_stammdaten ss ON gg.simple_id = ss.simple_id
            INNER JOIN sales_versionierung sv ON gg.simple_id = sv.simple_id
            INNER JOIN sales_anfrage af ON sv.af_versions_id = af.af_versions_id
            LEFT JOIN offer_angebot_vk avk ON sv.af_versions_id = avk.vk_versions_id
            LEFT JOIN offer_auftrag oa ON gg.simple_id = oa.simple_id
            LEFT JOIN sales_ablehnung ab ON gg.simple_id = ab.simple_id
            LEFT JOIN CRM_GP gp ON ss.gp_id = gp.gp_id
            OUTER APPLY (
                SELECT TOP 1 simple_id, verkaufsstufen_id
                FROM Sales_Vorhabenstufe
                WHERE gg.simple_id = simple_id
                ORDER BY dateline DESC
            ) vhs
            WHERE gg.simple_id = {$sin->value()}
        ";

        return $this->entityManager->createNativeQuery($sql, $rsm)->getOneOrNullResult();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @param Filterable|null $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function findToCopyKalkulation(PaginationRequestDTO $dto, Filterable $filter = null): PaginationResponseDTO
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $fields = [
            'version.vkVersionsId',
            'version.versionsnr',
            'version.versionsgrund',
            "{$this->alias}.thema",
            "{$this->alias}.simpleId",
            'version.totalPrice',
            'version.vkGesamt'
        ];

        $builder
            ->select($fields)
            ->join("{$this->alias}.salesStammdaten", 'ss')
            ->join(OfferAngebotVk::class, 'version', 'WITH', "{$this->alias} = version.globalGate")
            ->orderBy("{$this->alias}.simpleId", 'ASC');

        $paginate = new Paginate($this, $builder, $dto, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * Returns a security level of a project
     * @param SIN $sin
     * @return string
     */
    public function getConfidentialLevel(SIN $sin): string
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("{$this->alias}.sicherheitsstufe")
            ->where("{$this->alias}.simpleId = :simpleId")
            ->setParameter('simpleId', $sin->value())
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * Find data for Homescreen widget "OpenBilling"
     * @param int $userId
     * @param PaginationRequestDTO $dto
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function findOpenBillingWidgetData(int $userId, PaginationRequestDTO $dto): PaginationResponseDTO
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);
        $qb->select(
                "{$this->alias}.simpleId",
                "{$this->alias}.thema",
                "ss.kundenname",
                "financeStatus.shortName financeStatusShortName",
                "financeStatus.icon as financeStatusIcon",
                "financeStatus.color as financeStatusColor",
                "financeStatus.name as financeStatusName",
                "financeStatus.progress as financeStatusProgress",
                "status.shortName as statusShortName",
                "status.color as statusColor",
            )
            ->join("{$this->alias}.salesStammdaten", 'ss')
            ->join("{$this->alias}.sinStatus", 'sinStatus')
            ->join("sinStatus.status", 'status')
            ->join("ss.members", 'projectRoles')
            ->join("projectRoles.backendRoles", 'roles')
            ->leftJoin(FinanceSinStatus::class, 'financeSinStatus', 'WITH', "{$this->alias}.simpleId = financeSinStatus.simpleId")
            ->leftJoin("financeSinStatus.lbuStatus", 'financeStatus')
            ->where("roles.roleShort IN ('SM', 'FLU', 'FFU', 'FIU')")
            ->andWhere("projectRoles.backendBenutzer = :userId")
            ->andWhere("status.active = 1")
            ->andWhere("status.presales = 0")
            ->andWhere(
                $qb->expr()->orX(
                    $qb->expr()->isNull('financeStatus'),
                    $qb->expr()->in('financeStatus.sysName', ['Created', 'Send', 'Rejected'])
                )
            )
            ->setParameter('userId', $userId);

        $paginate = new Paginate($this, $qb, $dto);
        return $paginate->proceedPagination();
    }
}

