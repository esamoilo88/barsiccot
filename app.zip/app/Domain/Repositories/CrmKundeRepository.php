<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\CrmCustomer;
use App\Domain\Entities\CrmGp;
use App\Domain\Entities\CrmKunde;
use App\Domain\Repositories\Interfaces\ICrmKundeRepository;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\Repositories\Utils\Paginate\Paginationable;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\QueryBuilder;


class CrmKundeRepository extends BaseRepository implements Paginationable, ICrmKundeRepository
{
    public string $alias = 'CrmKunde';

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @param array $search
     * @param string|null $isInternal
     * @param PaginationRequestDTO $dto
     * @param Filterable $filter
     * @return PaginationResponseDTO
     * @throws \App\Exceptions\Application\SortFieldIsNotSetException
     */
    public function getPaginated(array $search, ?string $isInternal, PaginationRequestDTO $dto, Filterable $filter): PaginationResponseDTO
    {
        $segmentList = CrmCustomer::getInternalSegments();

        $fields = [
            "cc.id As customerId",
            "cg.gpId",
            "cg.gpNr AS gpNummer",
            "cg.gpNameLang AS kundenname",
            "cg.segment",
            "cg.wzBezeichnung",
            "cg.zgId",
            "cg.wzId",
            "cg.ustId",
            "cg.isActive",
            "cg.zgBezeichnung",
            "cg.gpOrt AS kundenstandort",
            "cg.gpPlz AS plz",
            "{$this->alias}.dtagNameLang",
            "{$this->alias}.dtagKdnr AS kundennummer",
            "{$this->alias}.kundeId"
        ];
        $condition = $this->getCondition($search);
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);
        $query = $builder
            ->select($fields)
            ->leftJoin(CrmGp::class, 'cg', 'WITH', "{$this->alias}.gpNr = cg.gpNr")
            ->leftJoin("{$this->alias}.crmCustomer", 'cc')
            ->where("cg.isActive = 1")
            ->andWhere($condition);
        if($isInternal === 'konzern'){
            $query = $query->andWhere($builder->expr()->in("cg.segment", $segmentList));
        }
        $query = $query->orderBy("cg.gpNameLang", "ASC");
        $paginate = new Paginate($this, $query, $dto, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * @param array $search
     * @return string
     */
    private function getCondition(array $search): string
    {
        $condition = [];
        $kundenname = explode(' ', trim($search['kundenname']));
        foreach ($kundenname as $word) {
            if ($word == '') continue;
            $condition[] = "cg.gpNameLang LIKE CONCAT('%', '$word' ,'%')" ;
        }
        $gpNummer = $search['gpNummer'];
        $kundennummer =$search['kundennummer'];
        $ort = $search['ort'];
        if ($gpNummer !='') $condition[] = "cg.gpNr =". $gpNummer;
        if($kundennummer !='') $condition[] = "$this->alias.dtagKdnr =" . $kundennummer;
        if ($ort != '') $condition[] = "cg.gpOrt LIKE CONCAT('%', '$ort' ,'%')";
        return implode(' AND ', $condition);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param int $kundennummer
     * @return CrmKunde[]
     */
    public function findByKundennummer(int $kundennummer): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select($this->alias, 'crmGp')
            ->where("{$this->alias}.dtagKdnr = :dtagKdnr")
            ->join("{$this->alias}.crmGp", 'crmGp')
            ->andWhere("{$this->alias}.isActive = 1")
            ->setParameter('dtagKdnr', $kundennummer)
            ->getQuery()
            ->getResult();
    }
}

