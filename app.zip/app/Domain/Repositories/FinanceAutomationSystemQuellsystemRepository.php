<?php

namespace App\Domain\Repositories;


use App\Domain\Entities\FinanceAutomationSystemQuellsystem;
use App\Domain\Repositories\BaseRepository;
use App\Domain\Repositories\Interfaces\IFinanceAutomationSystemQuellsystemRepository;
use App\Domain\ValueObjects\SIN;


class FinanceAutomationSystemQuellsystemRepository extends BaseRepository implements IFinanceAutomationSystemQuellsystemRepository
{

    protected string $alias = 'finance_automation_system_quellsystem';

    /**
     * @param int $id
     * @return FinanceAutomationSystemQuellsystem|object|null
     */
    public function find(int $id): ?FinanceAutomationSystemQuellsystem
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param SIN $sin
     * @return array|null
     */
    public function findBySIN(SIN $sin): ?array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.simpleId= :sin")
            ->setParameter('sin', $sin->value())
            ->getQuery()
            ->getResult();
    }
}
