<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\IFinanceCalendarRepository;

class FinanceCalendarRepository extends BaseRepository implements IFinanceCalendarRepository
{
    protected string $alias = 'FinanceCalendar';

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.hide = 0")
            ->orderBy("{$this->alias}.sort", 'ASC')
            ->getQuery()
            ->getResult();
    }
}
