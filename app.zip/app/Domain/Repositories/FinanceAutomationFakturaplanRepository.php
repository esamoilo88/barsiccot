<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceAutomationFakturaplan;
use App\Domain\Entities\SalesSinStatus;
use App\Domain\Repositories\Interfaces\IFinanceAutomationFakturaplanRepository;
use App\Domain\ValueObjects\Pagination\Pagination;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;

class FinanceAutomationFakturaplanRepository extends BaseRepository implements IFinanceAutomationFakturaplanRepository
{
    public string $alias = 'FinanceAutomationFakturaplan';

    /**
     * @param  int  $id
     * @return FinanceAutomationFakturaplan|object
     */
    public function find(int $id): ?FinanceAutomationFakturaplan
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param SIN $sin
     * @return Collection
     */
    public function findAllBySIN(SIN $sin): Collection
    {
        return new ArrayCollection(
            $this->genericRepository->findBy(['simpleId' => $sin->value()])
        );
    }

    /**
     * @param int $lbuId
     * @return array
     */
    public function findAllByLbuId(int $lbuId): array
    {
        return (
            $this->genericRepository->findBy(['lbuId' => $lbuId])
        );
    }

    /**
     * @param string $workingDay
     * @param string $ultimoDay
     * @param bool $onlyCount
     * @param Pagination|null $pagination
     * @return int|mixed|string
     */
    public function findByCreateDay(string $workingDay, string $ultimoDay, bool $onlyCount, ?Pagination $pagination = null)
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);
        $builder->join("{$this->alias}.lbu", 'lbu');

        if ($onlyCount) {
            $builder->select("COUNT({$this->alias}) AS count");
        } else {
            $builder
                ->select($this->alias, 'lbu', 'simple', 'backendBenutzer', 'financeOrder', 'SUM(lbuDaten.transferpreisDtag) as price')
                ->join('lbu.simple', 'simple')
                ->leftJoin("$this->alias.backendBenutzer", 'backendBenutzer')
                ->leftJoin("lbu.lbuDaten", 'lbuDaten')
                ->leftJoin("$this->alias.financeOrder", 'financeOrder')
                ->groupBy($this->alias, 'lbu', 'simple', 'financeOrder', 'backendBenutzer');
        }

        $builder
            ->join(SalesSinStatus::class, 'sss', Join::WITH, "sss.globalGate = lbu.simple")
            ->join('sss.status', 'status')
            ->where($builder->expr()->orX(
                "{$this->alias}.createAt = :workingDay",
                "{$this->alias}.createAt = :ultimoDay"
            ))
            ->andWhere('status.billingWritable = :status')
            ->setParameters([
                'workingDay' => $workingDay,
                'ultimoDay' => $ultimoDay,
                'status' => true
            ]);

        if ($pagination) {
            $builder->setFirstResult($pagination->skip())->setMaxResults($pagination->limit());
        }

        return $builder->getQuery()->getResult();
    }
}

