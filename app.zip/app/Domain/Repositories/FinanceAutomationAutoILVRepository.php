<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CostsKosten;
use App\Domain\Entities\FinanceAutomationAutoILV;
use App\Domain\Entities\SalesSinLabel;
use App\Domain\Entities\SalesSinStatus;
use App\Domain\Repositories\Interfaces\IFinanceAutomationAutoILVRepository;
use App\Domain\ValueObjects\Pagination\Pagination;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;

class FinanceAutomationAutoILVRepository extends BaseRepository implements IFinanceAutomationAutoILVRepository
{
    public string $alias = 'FinanceAutomationAutoILV';

    /**
     * @param  int  $id
     * @return FinanceAutomationAutoILV|object
     */
    public function find(int $id): ?FinanceAutomationAutoILV
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param SIN $sin
     * @return array
     */
    public function findBySin(SIN $sin): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        return $builder
            ->select(
                "{$this->alias}.id",
                "{$this->alias}.createAt",
                "{$this->alias}.jahr",
                "{$this->alias}.monat",
                'SUM(kosten.wert * kosten.stundensatzAlternativ) AS kostenwert'
            )
            ->leftJoin(CostsKosten::class, 'kosten', 'WITH', "kosten.simpleId = :sin AND {$this->alias}.monat = kosten.kostenMonat AND {$this->alias}.jahr = kosten.kostenJahr")
            ->where("{$this->alias}.offerAuftrag = :sin")
            ->setParameters([
                'sin' => $sin->value()
            ])
            ->groupBy($this->alias)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     */
    public function deleteBySin(SIN $sin): void
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $builder
            ->delete()
            ->where("{$this->alias}.offerAuftrag = :sin")
            ->setParameters([
                'sin' => $sin->value()
            ])
            ->getQuery()
            ->execute();
    }

    /**
     * @param array $ids
     */
    public function deleteByIds(array $ids): void
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $builder
            ->delete()
            ->where($builder->expr()->in($this->alias, $ids))
            ->getQuery()
            ->execute();
    }

    /**
     * @param string $workingDay
     * @param string $ultimoDay
     * @param bool $onlyCount
     * @param Pagination|null $pagination
     * @return array
     */
    public function findBySavedDay(string $workingDay, string $ultimoDay, $onlyCount = false, ?Pagination $pagination = null): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        if ($onlyCount) {
            $builder->select("COUNT({$this->alias}) AS count");
        } else {
            $builder
                ->select($this->alias, 'offerAuftrag')
                ->join("{$this->alias}.offerAuftrag", 'offerAuftrag');
        }

        $builder
            ->join(SalesSinStatus::class, 'sss', Join::WITH, "sss.globalGate = {$this->alias}.offerAuftrag")
            ->join('sss.status', 'status')
            ->where($builder->expr()->orX(
                "{$this->alias}.createAt = :workingDay",
                "{$this->alias}.createAt = :ultimoDay"
            ))
            ->andWhere('status.billingWritable = :status')
            ->setParameters([
                'workingDay' => $workingDay,
                'ultimoDay' => $ultimoDay,
                'status' => true
            ]);

        if ($pagination) {
            $builder->setFirstResult($pagination->skip())->setMaxResults($pagination->limit());
        }

        return $builder->getQuery()->getResult();
    }
}
