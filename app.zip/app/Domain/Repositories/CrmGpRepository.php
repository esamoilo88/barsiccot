<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CrmGp;
use App\Domain\Entities\CrmKunde;
use App\Domain\Repositories\Interfaces\ICrmGpRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\Query\ResultSetMapping;

class CrmGpRepository extends BaseRepository implements ICrmGpRepository
{
    public string $alias = 'CrmGp';

    /**
     * @param int $gpNumber
     * @return CrmGp
     */
    public function findByGpNumber(int $gpNumber): CrmGp
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.gpNr =" . $gpNumber)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param array $search
     * @return array
     */
    public function findForZDF(array $search): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        $qb->select($this->alias)->where("{$this->alias}.isActive = 1");

        $conditions = $qb->expr()->andX();

        foreach ($search as $value) {
            $conditions->add(
                $qb->expr()->like("{$this->alias}.gpNameLang", $qb->expr()->literal('%' . $value . '%'))
            );
        }

        $qb->andWhere($conditions)
            ->orderBy("{$this->alias}.gpNr", 'ASC');

        return $qb->getQuery()->getResult();
    }

    /**
     * @param string $table
     * @throws \Doctrine\DBAL\Exception
     */
    public function deleteAKP(string $table): void
    {
        $this->entityManager->getConnection()->executeQuery("DELETE FROM $table");
    }

    /**
     * @param string $table
     * @throws \Doctrine\DBAL\Exception
     */
    public function mergeGpTable(string $table): void
    {
        $sql = "
        MERGE
            dbo.CRM_GP AS target_table
        USING
            dbo.%s AS source_table ON target_table.gp_nr = source_table.gp_nr

            WHEN NOT MATCHED BY TARGET THEN
                INSERT (gp_nr, gp_name_lang, gp_plz, gp_ort, ust_id, is_active, segment, wz_id, wz_bezeichnung, zg_id, zg_bezeichnung, created, modified)
                VALUES (gp_nr, gp_name_lang, gp_plz, gp_ort, ust_id, IIF(LOWER(status) = 'aktiv', 1, 0), segment, wz_id, wz_name, zg_id, zg_name, GETDATE(), GETDATE())

            WHEN MATCHED THEN
                UPDATE SET
                    target_table.gp_nr = source_table.gp_nr,
                    target_table.gp_name_lang = source_table.gp_name_lang,
                    target_table.gp_plz = source_table.gp_plz,
                    target_table.gp_ort = source_table.gp_ort,
                    target_table.ust_id = source_table.ust_id,
                    target_table.is_active = IIF(LOWER(source_table.status) = 'aktiv', 1, 0),
                    target_table.segment = source_table.segment,
                    target_table.wz_id = source_table.wz_id,
                    target_table.wz_bezeichnung = source_table.wz_name,
                    target_table.zg_id = source_table.zg_id,
                    target_table.zg_bezeichnung = source_table.zg_name,
                    target_table.modified = GETDATE();";
        $sql = sprintf($sql, $table);

        /** @var QueryBuilder $qb */
        $this->entityManager->getConnection()->executeQuery($sql);
    }

    /**
     * @param string $table
     * @throws \Doctrine\DBAL\Exception
     */
    public function mergeKundeTable(string $table): void
    {
        $sql = "
        MERGE
            dbo.CRM_Kunde AS target_table
        USING
            dbo.%s AS source_table ON target_table.DTAG_kdnr = source_table.DTAG_kdnr

            WHEN NOT MATCHED BY TARGET THEN
                INSERT (DTAG_kdnr, gp_nr, DTAG_name_lang, DTAG_plz, DTAG_ort, is_active, created, modified)
                VALUES (DTAG_kdnr, gp_nr, DTAG_name_lang, DTAG_plz, DTAG_ort, IIF(LOWER(status) = 'aktiv', 1, 0), GETDATE(), GETDATE())

            WHEN MATCHED THEN
                UPDATE SET
                    target_table.gp_nr = source_table.gp_nr,
                    target_table.DTAG_kdnr = source_table.DTAG_kdnr,
                    target_table.DTAG_name_lang = source_table.DTAG_name_lang,
                    target_table.DTAG_plz = source_table.DTAG_plz,
                    target_table.DTAG_ort = source_table.DTAG_ort,
                    target_table.is_active = IIF(LOWER(source_table.status) = 'aktiv', 1, 0),
                    target_table.modified = GETDATE();";

        $sql = sprintf($sql, $table);
        /** @var QueryBuilder $qb */
        $this->entityManager->getConnection()->executeQuery($sql);
    }

    /**
     * @param string $table
     * @param string $file
     * @throws \Doctrine\DBAL\Exception
     */
    public function bulkQuery(string $table, string $file): void
    {
        $sql = "
        BULK INSERT %s FROM '%s'
        WITH (
            FIRSTROW = 2,
            CODEPAGE = '65001',
            DATAFILETYPE = 'char',
            FIELDTERMINATOR = '|',
            ROWS_PER_BATCH = 100,
            ROWTERMINATOR = '0x0a'
        )";

        $sql = sprintf($sql, $table, $file);
        /** @var QueryBuilder $qb */
        $this->entityManager->getConnection()->executeQuery($sql);
    }

    /**
     * @param string $kundeTable
     * @param string $gpTable
     * @throws \Doctrine\DBAL\Exception
     */
    public function removeInconsistentEntries(string $kundeTable, string $gpTable): void
    {
        $sql = "DELETE FROM %s WHERE gp_nr NOT IN (SELECT DISTINCT(gp_nr) FROM %s)";
        $sql = sprintf($sql, $kundeTable, $gpTable);
        $this->entityManager->getConnection()->executeQuery($sql);
    }

    /**
     * @param string $table
     * @throws \Doctrine\DBAL\Exception
     */
    public function alterIndex(string $table): void
    {
        $sql = "ALTER FULLTEXT INDEX ON $table START FULL POPULATION";
        $this->entityManager->getConnection()->executeQuery($sql);
    }


    /**
     * @param int $kundennummer
     * @return CrmGp[]
     */
    public function findByKundennummer(int $kundennummer): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select($this->alias)
            ->join(CrmKunde::class, 'ck', 'WITH', "{$this->alias}.gpNr = ck.gpNr")
            ->where("ck.dtagKdnr = :dtagKdnr")
            ->andWhere("ck.isActive = 1")
            ->setParameter('dtagKdnr', $kundennummer)
            ->getQuery()
            ->getResult();
    }
}
