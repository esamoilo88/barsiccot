<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\GlobalGate;
use App\Domain\Entities\GlobalProzess;
use App\Domain\Repositories\Interfaces\IGlobalProzessRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\ORM\Query;

class GlobalProzessRepository extends BaseRepository implements IGlobalProzessRepository
{
    protected string $alias = 'GlobalProzess';

    /**
     * @param int $prozessId
     * @return GlobalProzess|object
     */
    public function find(int $prozessId): GlobalProzess
    {
        return $this->genericRepository->find($prozessId);
    }

    /**
     * @param SIN $sin
     * @return GlobalProzess|null
     */
    public function findProzessBySin(SIN $sin): ?GlobalProzess
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->join(
                GlobalGate::class, 'gg',
                Query\Expr\Join::WITH,
                "{$this->alias}.prozessId = gg.prozess"
            )
            ->where('gg.simpleId = :sin')
            ->setParameter('sin', $sin->value())
            ->getQuery()
            ->getOneOrNullResult();
    }
}
