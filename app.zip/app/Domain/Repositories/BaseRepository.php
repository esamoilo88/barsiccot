<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\IBaseRepository;
use App\Domain\Repositories\Utils\CustomQueryBuilder;
use App\Domain\Repositories\Utils\Hydrators\CustomScalarHydrator;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ObjectRepository;
use Illuminate\Support\Facades\Log;

class BaseRepository implements IBaseRepository
{
    protected ObjectRepository $genericRepository;
    protected EntityManagerInterface $entityManager;
    protected CustomQueryBuilder $customQueryBuilder;

    /**
     * @param ObjectRepository $repository
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(ObjectRepository $repository, EntityManagerInterface $entityManager)
    {
        $this->genericRepository = $repository;
        $this->entityManager = $entityManager;

        $this->entityManager
            ->getConfiguration()
            ->addCustomHydrationMode('CUSTOM_SCALAR_HYDRATION', CustomScalarHydrator::class);

        if (!isset($this->alias)) {
            preg_match('/\w+$/', static::class, $className);
            $this->alias = (string) $className[0];
        }

        $this->customQueryBuilder = new CustomQueryBuilder($this->genericRepository, $this->entityManager, $this->alias);
    }

    /**
     * @param array $fields
     * @param array $options
     * @return CustomQueryBuilder
     */
    public function findCustom(array $fields = [], array $options = []): CustomQueryBuilder
    {
        return $this->customQueryBuilder->findCustom($fields, $options);
    }

    /**
     * @param array $fields
     * @return array
     */
    public function prefixFields(array $fields): array
    {
        $result = [];
        foreach ($fields as $field) {
            $result[] = $this->customQueryBuilder->prefixFieldWithAlias($field);
        }
        return $result;
    }

    /**
     * Mass set of entity fields
     * @param $entity
     * @param array $fields
     * @return mixed
     */
    public function setFields($entity, array $fields)
    {
        foreach ($fields as $field => $value) {
            $setterName = 'set'.mb_strtoupper(mb_substr($field, 0, 1)).mb_substr($field, 1, null);
            if (method_exists($entity, $setterName)) {
                $entity->{$setterName}($value);
            } else {
                Log::error("Couldn't set value to entity ".get_class($entity)." setter: ".$setterName);
            }
        }

        return $entity;
    }

    /**
     * @param string|null $entityClassName
     * @param array $fields
     * @param array $except
     * @param bool $withAliasPrefix
     * @return array
     */
    public function getFields(
        string $entityClassName = null,
        array $fields = [],
        array $except = [],
        bool $withAliasPrefix = true
    ): array
    {
        $result = [];
        if (empty($fields) && $entityClassName) {
            $classMetadata = $this->entityManager->getClassMetadata($entityClassName);
            $properties = $classMetadata->getFieldNames();
            $fields = array_merge(
                $properties,
                $classMetadata->getAssociationNames()
            );
        }
        if ($withAliasPrefix) {
            $fields = $this->prefixFields($fields);
            $except = $this->prefixFields($except);
        }
        foreach ($fields as $field) {
            if (!in_array($field, $except)) {
                if (str_contains($field, 'AS')) {
                    $field = explode('AS', $field)[0];
                }
                $result[] = $field;
            }
        }
        return $result;
    }
}
