<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendWidgetsUsers;
use App\Domain\Repositories\Interfaces\IBackendWidgetsUsersRepository;

class BackendWidgetsUsersRepository extends BaseRepository implements IBackendWidgetsUsersRepository
{
    protected string $alias = 'BackendWidgetUsers';

    /**
     * @param int $userId
     * @param bool $grouped
     * @return array
     */
    public function findUserWidgets(int $userId, bool $grouped = false): array
    {
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias, 'widget')
            ->join("{$this->alias}.widget", 'widget')
            ->andWhere("{$this->alias}.user = :user")
            ->setParameter('user', $userId)
            ->getQuery()
            ->getResult();

        $widgets = [];
        if ($grouped) {
            /** @var BackendWidgetsUsers $w */
            foreach ($result as $w) {
                $widgets[$w->getWidget()->getId()] = $w;
            }
        } else {
            $widgets = $result;
        }

        return $widgets;
    }
}
