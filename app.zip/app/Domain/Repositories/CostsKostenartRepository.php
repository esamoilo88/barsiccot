<?php


namespace App\Domain\Repositories;


use App\Domain\Entities\CostsKostenart;
use App\Domain\Repositories\Interfaces\ICostsKostenartRepository;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\QueryBuilder;

class CostsKostenartRepository extends BaseRepository implements ICostsKostenartRepository
{
    protected string $alias = 'CostsKostenart';

    /**
     * @param int $id
     * @return CostsKostenart|object|null
     */
    public function find(int $id): ?CostsKostenart
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findAll(): array
    {
        return $this->genericRepository->findAll();
    }

    /**
     * @return array
     */
    public function getKostenarts(): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select(
            "$this->alias.kostenartId",
            "$this->alias.bezeichnung",
            "$this->alias.zuordnung",
            "$this->alias.gruppe"
        )
            ->where("$this->alias.hide = 0")
            ->andWhere("$this->alias.kostenRelevant = 1")
            ->andWhere("$this->alias.ilvRelevant = 1")
            ->orderBy("$this->alias.sort", 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $relevant
     * @return array
     */
    public function getValidKostenarten($relevant = 0): array
    {
        $conditions = [];
        $conditions[] = "$this->alias.hide = 0";
        $conditions[] = ($relevant == 0) ? "AND $this->alias.onkaRelevant = 1" : "AND $this->alias.kostenRelevant = 1";

        $fields = [
            "$this->alias.kostenartId",
            'cs.stundensatz',
            'cs.gmkz'
        ];
        /** @var QueryBuilder $builder */
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($fields)
            ->leftJoin("{$this->alias}.costStundensatz", 'cs')
            ->where("CURRENT_TIMESTAMP() BETWEEN cs.gueltigVon AND cs.gueltigBis AND
            (cs.gmkz IS NULL OR cs.gmkz = 1.03 OR cs.gmkz = 1.13)")
            ->andWhere(implode(' ', $conditions))
            ->getQuery()
            ->getResult();

        $arrKostenarten = [];
        foreach ($result as $data) {
            $arrKostenarten[$data['kostenartId']] = [
                'stundensatz' => $data['stundensatz'],
                'gmkz'        => $data['gmkz'],
                'kostenartId' => $data['kostenartId']
            ];
        }

        return $arrKostenarten;
    }

    /**
     * @return array
     */
    public function getExcelExportKostenart(): array
    {
        return $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select("$this->alias.bezeichnung",
                "$this->alias.kostenartId",
                'stundensatz.stundensatz',
                'stundensatz.stundensatzAlternativ',
                'stundensatz.ofiLa')
            ->join("$this->alias.costStundensatz", "stundensatz", 'WITH', "stundensatz.gueltigBis = '31.12.9999'")
            ->where("{$this->alias}.hide = 0")
            ->andWhere("{$this->alias}.ilvRelevant = 1")
            ->andWhere("{$this->alias}.kostenRelevant = 1")
            ->orderBy("{$this->alias}.bezeichnung", 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return array
     */
    public function getKostenartNames(): array
    {
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select("$this->alias.kostenartId",
                "$this->alias.bezeichnung",
                "cs.stundensatz",
                "cs.gmkz",
                "cs.ofiLa")
            ->join("$this->alias.costStundensatz",'cs')
            ->where("{$this->alias}.onkaRelevant = 1")
            ->andWhere("{$this->alias}.hide = 0")
            ->andWhere("CURRENT_TIMESTAMP() BETWEEN cs.gueltigVon AND cs.gueltigBis")
            ->getQuery()
            ->getResult();
        $arrKostenarten = [];
        foreach ($result as $data) {
            $arrKostenarten[$data['kostenartId']] = $data;
        }
        return $arrKostenarten;
    }

    /**
     * @param int $id
     * @return CostsKostenart|null
     * @throws NonUniqueResultException
     */
    public function getWithKostentypById(int $id): ?CostsKostenart
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        return $builder
            ->select($this->alias, 'kostentyp')
            ->join("{$this->alias}.kostentyp", 'kostentyp')
            ->where("{$this->alias} = :id")
            ->setParameters([
                'id' => $id
            ])
            ->getQuery()
            ->getOneOrNullResult();
    }
}
