<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CostsServicelevel;
use App\Domain\Repositories\Interfaces\ICostsServicelevelRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Domain\Repositories\BaseRepository;

class CostsServicelevelRepository extends BaseRepository implements ICostsServicelevelRepository
{
    /**
     * @param int $id
     * @return CostsServicelevel|object
     */
    public function find(int $id): ?CostsServicelevel
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @return array
     */
    public function findOptions(): array
    {
        return $this->findCustom(
            ['servicelevelId', 'beschreibung', 'kategorie.bezeichnung'],
            [
                'conditions' => [['hide', '=', 0]],
                'joins' => ['left' => [['kategorie', 'kategorie']]],
                'sorts' => [['kategorie.bezeichnung', 'ASC'], ['sort', 'ASC']]
            ]
        )->getResult();
    }

    /**
     * @return array
     */
    public function getValidServicelevel() :array
    {
        return $this->findCustom(
            ['servicelevelId', 'wert'],
            [
                'conditions' => [['hide', '=', 0]],
                'sorts' => [['sort', 'ASC']]
            ]
        )->getResult();
    }
}

