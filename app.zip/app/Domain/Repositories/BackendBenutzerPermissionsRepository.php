<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendBenutzer;
use App\Domain\Repositories\Interfaces\IBackendBenutzerPermissionsRepository;
use Doctrine\ORM\Query;
use App\Domain\Repositories\BaseRepository;

class BackendBenutzerPermissionsRepository extends BaseRepository implements IBackendBenutzerPermissionsRepository
{
    public string $alias = 'b_benutzer_permission';

    /**
     * @param array $rechteIds
     * @param BackendBenutzer $backendBenutzer
     * @return bool
     */
    public function isUserHasRights(array $rechteIds, BackendBenutzer $backendBenutzer): bool
    {
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.backendBenutzer = :user AND {$this->alias}.backendRechte IN (:rechteId)")
            ->setParameter('user', $backendBenutzer)
            ->setParameter('rechteId', $rechteIds)
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);

        return $result !== [];
    }

    /**
     * @param BackendBenutzer $user
     */
    public function clear(BackendBenutzer $user): void
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->delete()
            ->where("{$this->alias}.backendBenutzer = :user")
            ->setParameter('user', $user)
            ->getQuery()
            ->execute();
    }
}
