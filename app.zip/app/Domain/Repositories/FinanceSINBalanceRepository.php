<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceSINBalance;
use App\Domain\Repositories\Interfaces\IFinanceSINBalanceRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\NonUniqueResultException;

class FinanceSINBalanceRepository extends BaseRepository implements IFinanceSINBalanceRepository
{
    protected string $alias = 'FinanceSINBalance';

    /**
     * @param SIN $sin
     * @return FinanceSINBalance|object
     */
    public function findBySIN(SIN $sin): ?FinanceSINBalance
    {
        return $this->genericRepository->findOneBy(['simpleId' => $sin->value()]);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param SIN $sin
     * @return FinanceSINBalance|null
     * @throws NonUniqueResultException
     */
    public function findWithSimple(SIN $sin): ?FinanceSINBalance
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias, 'simple')
            ->join("{$this->alias}.simple", 'simple')
            ->where("{$this->alias}.simple = :simpleId")
            ->setParameter('simpleId', $sin->value())
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param SIN[] $simpleIds
     * @return FinanceSINBalance[]
     */
    public function findBySimpleIds(array $simpleIds): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias)
            ->where($qb->expr()->in(
                "{$this->alias}.simpleId",
                array_map(function ($sin) {return $sin->value();}, $simpleIds))
            )
            ->getQuery()
            ->getResult();
    }
}

