<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendGroup;
use App\Domain\Repositories\Interfaces\IBackendGroupRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class BackendGroupRepository extends BaseRepository implements IBackendGroupRepository
{
    public string $alias = 'BackendProjectGroup';

    /**
     * @param int $id
     * @return BackendGroup|null|object
     */
    public function find(int $id): ?BackendGroup
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @return array
     */
    public function findActive(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("{$this->alias}", "bereich", "roleInfo", "role")
            ->join("{$this->alias}.bereich", "bereich")
            ->join("{$this->alias}.roleInfo", "roleInfo")
            ->join("{$this->alias}.role", "role")
            ->where("{$this->alias}.active = 1")
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
    }
}
