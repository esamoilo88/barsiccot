<?php


namespace App\Domain\Repositories;


use App\Domain\Entities\CostsKostenart;
use App\Domain\Entities\CostsStundensatz;
use App\Domain\Repositories\Interfaces\ICostsStundensatzRepository;
use Carbon\Carbon;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\QueryBuilder;

class CostsStundensatzRepository extends BaseRepository implements ICostsStundensatzRepository
{
    protected string $alias = 'CostsStundensatz';

    /**
     * @param CostsKostenart $kostenart
     * @return CostsStundensatz|object
     */
    public function getByGueltigBis(CostsKostenart $kostenart): ?CostsStundensatz
    {
        return $this->genericRepository->findOneBy([
            'gueltigBis' => new \DateTime('31.12.9999'),
            'kostenart' => $kostenart
        ]);
    }

    /**
     * @param  int  $kostenartId
     * @return int|null
     */
    public function getOfiLaNumber(int $kostenartId): ?int
    {
        $qb = $this->genericRepository->createQueryBuilder($this->alias);
        $ofiLa =  $qb->select("{$this->alias}.ofiLa")
            ->andWhere("{$this->alias}.kostenart = :kostenartId")
            ->andWhere("CURRENT_TIMESTAMP() BETWEEN {$this->alias}.gueltigVon AND {$this->alias}.gueltigBis")
            ->setParameter('kostenartId', $kostenartId)
            ->getQuery()
            ->getOneOrNullResult();

        return $ofiLa['ofiLa'] ?? null;
    }

    /**
     * @param Carbon $period
     * @param int $kostenartId
     * @return array
     */
    public function getByPeriod(Carbon $period, int $kostenartId): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select(
            "$this->alias.stundensatzId",
            "$this->alias.stundensatz",
            "$this->alias.stundensatzAlternativ",
            "$this->alias.gueltigVon",
            "$this->alias.gueltigBis",
        )
            ->where("$this->alias.gueltigVon <= :period")
            ->andWhere("$this->alias.gueltigBis >= :period")
            ->andWhere("$this->alias.kostenart = :kostenartId")
            ->setParameters([
                'period' => $period,
                'kostenartId' => $kostenartId
            ])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param Carbon $period
     * @param int $kostenartId
     * @return CostsStundensatz|null
     */
    public function findStundensatzByPeriod(Carbon $period, int $kostenartId): ?CostsStundensatz
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select( "$this->alias")
            ->where("$this->alias.gueltigVon <= :period")
            ->andWhere("$this->alias.gueltigBis >= :period")
            ->andWhere("$this->alias.kostenart = :kostenartId")
            ->setParameters([
                'period' => $period,
                'kostenartId' => $kostenartId
            ])
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @param CostsKostenart $kostenart
     * @return CostsStundensatz|null
     * @throws NonUniqueResultException
     */
    public function findDefaultByKostenart(CostsKostenart $kostenart): ?CostsStundensatz
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb
            ->where("{$this->alias}.kostenart = :kostenart")
            ->andWhere("{$this->alias}.isDefault = :isDefault")
            ->setParameters([
                'kostenart' => $kostenart,
                'isDefault' => true
            ])
            ->getQuery()
            ->getOneOrNullResult();
    }
}
