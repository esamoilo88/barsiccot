<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\BackendProjectRoles;
use App\Domain\Entities\CostsKosten;
use App\Domain\Entities\CostsKostenstelle;
use App\Domain\Entities\v_IstKosten;
use App\Domain\Repositories\Interfaces\ICostsKostenRepository;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Filters\Orders\Costs\CostsListFilter;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Domain\ValueObjects\Finance\MonthYear;
use App\Domain\ValueObjects\SIN;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\Query;
use Illuminate\Support\Carbon;

class CostsKostenRepository extends BaseRepository implements ICostsKostenRepository
{
    public string $alias = 'CostsKosten';

    /**
     * @param int $id
     * @return CostsKosten|object
     */
    public function find(int $id): ?CostsKosten
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return Collection
     */
    public function findAll(): Collection
    {
        return new ArrayCollection($this->genericRepository->findAll());
    }

    /**
     * @param SIN $sin
     * @param MonthYear|null $monthYear
     * @return array
     * @throws NonUniqueResultException
     */
    public function getSumCostsBySIN(SIN $sin, ?MonthYear $monthYear = null): ?array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $select = [
            "SUM({$this->alias}.stundensatz * {$this->alias}.wert) AS totalSum"
        ];

        $query = $builder
            ->select($select)
            ->where("{$this->alias}.simpleId = :simpleId")
            ->setParameters([
                'simpleId' => $sin->value(),
            ]);

        if ($monthYear) {
            $query
                ->andWhere("{$this->alias}.kostenJahr = :year")
                ->andWhere("{$this->alias}.kostenMonat = :month")
                ->setParameter('year', $monthYear->getYear())
                ->setParameter('month', $monthYear->getMonth());
        }

        return $query->getQuery()->getOneOrNullResult();
    }

    /**
     * @param SIN $sin
     * @param MonthYear $monthYear
     * @return array
     */
    public function getPreviousSumCosts(SIN $sin, MonthYear $monthYear): array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        return $builder
            ->select("SUM({$this->alias}.stundensatz * {$this->alias}.wert) AS sum", "{$this->alias}.kostenJahr as year")
            ->where("{$this->alias}.simpleId = :simpleId")
            ->andWhere("{$this->alias}.kostenJahr < :year")
            ->andWhere("{$this->alias}.kostenMonat < :month")
            ->setParameters(['simpleId' => $sin->value(), 'year' => $monthYear->getYear(), 'month' => $monthYear->getMonth()])
            ->groupBy("{$this->alias}.kostenJahr")
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @param MonthYear|null $monthYear
     * @return array
     * @throws NonUniqueResultException
     */
    public function getSumIlvBySIN(SIN $sin, ?MonthYear $monthYear = null): ?array
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $select = [
            "SUM({$this->alias}.stundensatzAlternativ * {$this->alias}.wert) AS totalSum"
        ];

        $query = $builder
            ->select($select)
            ->join("{$this->alias}.kostenart", 'kostenart')
            ->where("{$this->alias}.simpleId = :simpleId")
            ->andWhere('kostenart.ilvRelevant = 1')
            ->andWhere("{$this->alias}.ilvValid = 1")
            ->setParameters([
                'simpleId' => $sin->value(),
            ]);

        if ($monthYear) {
            $query
                ->andWhere("{$this->alias}.kostenJahr = :year")
                ->andWhere("{$this->alias}.kostenMonat = :month")
                ->setParameter('year', $monthYear->getYear())
                ->setParameter('month', $monthYear->getMonth());
        }

        return $query->getQuery()->getOneOrNullResult();
    }

    /**
     * @param SIN $sin
     * @param bool $isILV
     * @return MonthYear|null
     * @throws NonUniqueResultException
     */
    public function findLatestAvailableFakturamonatFakturajahr(SIN $sin, bool $isILV): ?MonthYear
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $select = [
            "{$this->alias}.kostenJahr",
            "{$this->alias}.kostenMonat"
        ];

        $subQuery = $this
            ->entityManager
            ->createQueryBuilder()
            ->select('ck')
            ->from(CostsKosten::class, 'ck')
            ->where("ck.simpleId = :simpleId")
            ->orderBy("ck.kostenJahr", 'DESC')
            ->addOrderBy("ck.kostenMonat", 'DESC');

        $query = $builder
            ->select($select)
            ->where("{$this->alias} = LIMIT1({$subQuery->getDQL()})")
            ->setParameters([
                'simpleId' => $sin->value(),
            ]);

        if ($isILV) {
            $query
                ->join("{$this->alias}.kostenart", 'kostenart')
                ->andWhere('kostenart.ilvRelevant = 1')
                ->andWhere("{$this->alias}.ilvValid = 1");
        }

        $result = $query->getQuery()->getOneOrNullResult();

        if (isset($result['kostenJahr']) && isset($result['kostenMonat'])) {
            return new MonthYear($result['kostenMonat'], $result['kostenJahr']);
        } else {
            return null;
        }
    }

    /**
     * @param SIN $sin
     * @param PaginationRequestDTO $dto
     * @param Filterable|null $filter
     * @param int|null $kostenMonat
     * @param int|null $kostenJahr
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getList(
        SIN $sin,
        PaginationRequestDTO $dto,
        Filterable $filter = null,
        ?int $kostenMonat = null,
        ?int $kostenJahr = null
    ): PaginationResponseDTO
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        $qb->select(
            "{$this->alias}.kostenId",
            "{$this->alias}.kostenId",
            "{$this->alias}.ofiLa",
            "{$this->alias}.wert",
            "{$this->alias}.stundensatzAlternativ",
            "{$this->alias}.kostenJahr",
            "{$this->alias}.kostenMonat",
            "{$this->alias}.locked",
            "{$this->alias}.automated",
            "{$this->alias}.pspElement",
            "{$this->alias}.modified",
            "({$this->alias}.wert * {$this->alias}.stundensatzAlternativ) as betrag",
            "({$this->alias}.kostenJahr * 12 + {$this->alias}.kostenMonat) as dateSum",
            "{$this->alias}.actualValue",
            "{$this->alias}.receiverKostenstelleId",
            'kostenart.kostenartId',
            'kostenart.bezeichnung',
            'kostenart.zuordnung',
            'kostenart.ilvRelevant',
            'kostenart.vlvRelevant',
            'kostenstelle.kostenstelleId',
            'kostenstelle.kostenstelle',
            'kostenstelle.shortName',
            'istKosten.bemerkungen',
            'istKosten.quellsystemBezeichnung',
            'istKosten.ofiLa as istKostenOfiLa',
            'istKosten.created',
            'receiver.kostenstelle as receiverKostenstelle',
            'quellsystem.quellsystemId',
            'kostentyp.bezeichnung as kostentypName'
        )
            ->leftJoin("{$this->alias}.kostenart", 'kostenart')
            ->leftJoin("kostenart.kostentyp", 'kostentyp')
            ->leftJoin("{$this->alias}.kostenstelle", 'kostenstelle')
            ->leftJoin("{$this->alias}.quellsystem", 'quellsystem')
            ->leftJoin(
                CostsKostenstelle::class, 'receiver',
                Query\Expr\Join::WITH,
                "{$this->alias}.receiverKostenstelleId = receiver.kostenstelleId"
            )
            ->leftJoin(
                v_IstKosten::class, 'istKosten',
                Query\Expr\Join::WITH,
                "{$this->alias}.kostenId = istKosten.kostenId"
            )
            ->where("{$this->alias}.simpleId = :simpleId");

        if ($kostenMonat && $kostenJahr) {
            $qb
                ->andWhere("{$this->alias}.kostenMonat = :kostenMonat")
                ->andWhere("{$this->alias}.kostenJahr = :kostenJahr")
                ->setParameters(
                    [
                        'simpleId' => $sin->value(),
                        'kostenMonat' => $kostenMonat,
                        'kostenJahr' => $kostenJahr
                    ]
                );
        } else {
            $qb->setParameter('simpleId', $sin->value());
        }

        $paginate = new Paginate(
            $this,
            $qb,
            $dto,
            new CostsListFilter()
        );

        return $paginate->proceedPagination();
    }

    /**
     * @param SIN $sin
     * @param bool $withBetrag
     * @return array
     */
    public function getCostsDate(SIN $sin, bool $withBetrag = false): array
    {
        $builder = $this->customQueryBuilder->getQueryBuilder()
            ->select(
                "{$this->alias}.kostenJahr",
                "{$this->alias}.kostenMonat"
            );

        if ($withBetrag) {
            $builder->addSelect("SUM({$this->alias}.wert * {$this->alias}.stundensatzAlternativ) as betrag");
        }

        return $builder
            ->where("{$this->alias}.simpleId = :simpleId")
            ->setParameter('simpleId', $sin->value())
            ->orderBy("{$this->alias}.kostenMonat", 'ASC')
            ->groupBy("{$this->alias}.kostenJahr", "{$this->alias}.kostenMonat")
            ->getQuery()
            ->getArrayResult();
    }


    public function alias(): string
    {
        return $this->alias;
    }

    public function getSortableFields(): array
    {
        return [
            'kostenJahr' => "dateSum",
            'kostenart' => 'kostenart.bezeichnung',
            'wert' => "{$this->alias}.wert",
            'stundensatzAlternativ' => "{$this->alias}.stundensatzAlternativ",
            'betrag' => "betrag",
            'created' => "{$this->alias}.created"
        ];
    }

    /**
     * @param array $ids
     * @return array
     */
    public function findNotLocked(array $ids): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias())
            ->where("$this->alias.locked = 0")
            ->where("{$this->alias}.kostenId IN (:ids)")
            ->setParameter('ids', $ids)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @return array
     */
    public function findBySin(SIN $sin): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select(
                $this->alias,
                'kostenart'
            )
            ->leftJoin("{$this->alias}.kostenart", 'kostenart')
            ->where("{$this->alias}.simple = :simple")
            ->setParameters([
                'simple' => $sin->value(),
            ])
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @param int $kostenMonat
     * @param int $kostenJahr
     * @param bool $getEntities
     * @return array
     */
    public function findBySinAndMonatAndJahr(SIN $sin, int $kostenMonat, int $kostenJahr, bool $getEntities = true): array
    {
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        if ($getEntities) {
            $qb->select(
                $this->alias,
                'kostenstelle',
                'kart',
                'receiverKostenstelle'
            );
        } else {
            $qb->select(
                "{$this->alias}.wert as kostenwert",
                'kart.kostenartId',
                'kart.bezeichnung as kostenart',
                'kart.zuordnung',
                'kostenstelle.kostenstelleId',
                'kostenstelle.kostenstelle'
            );
        }

        $qb
            ->leftJoin("{$this->alias}.kostenart", 'kart')
            ->leftJoin("{$this->alias}.kostenstelle", 'kostenstelle')
            ->leftJoin("{$this->alias}.receiverKostenstelle", 'receiverKostenstelle')
            ->where("{$this->alias}.simpleId = :simpleId")
            ->andWhere("{$this->alias}.kostenMonat = :kostenMonat")
            ->andWhere("{$this->alias}.kostenJahr = :kostenJahr")
            ->setParameters(['simpleId' => $sin->value(), 'kostenMonat' => $kostenMonat, 'kostenJahr' => $kostenJahr]);

        return $qb->getQuery()->getResult();
    }

    /**
     * @param array $ids
     * @return array
     */
    public function findByIds(array $ids): array
    {
        if ($ids === []) return [];

        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb
            ->select($this->alias())
            ->where("{$this->alias}.kostenId IN (:ids)")
            ->setParameter('ids', $ids)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     * @param int $month
     * @param int $year
     * @return bool
     */
    public function hasCostsInCurrentMonth(SIN $sin, int $month, int $year): bool
    {
        /** @var QueryBuilder $builder */
        $builder = $this->genericRepository->createQueryBuilder($this->alias);

        $result = $builder
            ->select("{$this->alias}.kostenId")
            ->where("{$this->alias}.simpleId = :sin")
            ->andWhere("{$this->alias}.kostenMonat = :month")
            ->andWhere("{$this->alias}.kostenJahr = :year")
            ->setParameters([
                'sin' => $sin->value(),
                'month' => $month,
                'year' => $year
            ])
            ->getQuery()
            ->getResult();

        return (bool) $result;
    }


    /**
     * @param int $userId
     * @return array
     */
    public function getMyUserProjectsSumData(int $userId): array
    {
        $rsm = new ResultSetMapping();
        $created = Carbon::create(Carbon::now()->year, 1, 1)->format('Y-m-d');
        $rsm->addScalarResult('simple_id', 'simple_id');
        $rsm->addScalarResult('sumIlv', 'sumIlv');

        $sql = "
            select
                projects.simple_id,
            SUM(ck.wert * ck.stundensatz_alternativ)as sumIlv
            from Costs_Kosten ck
            inner join Sales_Stammdaten projects on projects.simple_id = ck.simple_id
            left join Backend_Benutzer users on users.benutzer_id = (
                 select top 1 bpr.benutzer_id
                 from Backend_ProjectRoles bpr
                 left join Backend_Roles BR on bpr.role_id = BR.role_id
                 where bpr.simple_id = projects.simple_id and bpr.representative = 0
                 or bpr.representative is NULL
                 order by bpr.id ASC
            )
            inner join Global_Gate gg on projects.simple_id = gg.simple_id
            INNER JOIN Global_Prozess gp ON gg.prozess_id = gp.prozess_id
            left join Costs_Kostenart ckart ON ck.kostenart_id = ckart.kostenart_id
            AND gp.produktiv =1
            AND ckart.ilv_relevant = 1
            AND ck.ilv_valid =1
            AND ck.kosten_jahr = '".Carbon::now()->year."'
            group by  projects.simple_id";

        return $this->entityManager->createNativeQuery($sql, $rsm)->getResult();
    }
}

