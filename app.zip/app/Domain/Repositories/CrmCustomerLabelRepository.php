<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\CrmCustomerLabel;
use App\Domain\Repositories\Interfaces\ICrmCustomerLabelRepository;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;

class CrmCustomerLabelRepository extends BaseRepository implements ICrmCustomerLabelRepository
{
    protected string $alias = 'CrmCustomerLabel';

    /**
     * @param int $id
     * @return CrmCustomerLabel|object
     */
    public function find(int $id): CrmCustomerLabel
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @return array
     */
    public function findVisible(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                "crmCategory.id AS catId",
                "label.id AS labelId",
                "crmCategory.name AS catName",
                "label.name AS labelName",
                "customer.id AS customerId"
            )
            ->leftJoin("{$this->alias}.customer", 'customer')
            ->leftJoin("{$this->alias}.label", 'label')
            ->leftJoin("label.crmCategory", 'crmCategory')
            ->andWhere("crmCategory.hide = 0")
            ->orderBy("crmCategory.sort", "ASC")
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
    }

    /**
     * @param int $customerId
     * @param int $catId
     * @return CrmCustomerLabel|null
     */
    public function findCutomerByCatId(int $customerId,int $catId): ?CrmCustomerLabel
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("{$this->alias}")
            ->join("{$this->alias}.label", 'label')
            ->join("label.crmCategory", 'crmCategory')
            ->where("{$this->alias}.customer = :customerId")
            ->andWhere("crmCategory.id = :catId")
            ->setParameters(['customerId' => $customerId,'catId' => $catId])
            ->getQuery()
            ->getOneOrNullResult();
    }
}
