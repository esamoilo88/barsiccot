<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\SalesSinStatus;
use App\Domain\Entities\v_Email_Senden;
use App\Domain\Repositories\Interfaces\IEmailSendenRepository;
use App\Domain\ValueObjects\SIN;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Query\ResultSetMapping;


class EmailSendenRepository extends BaseRepository implements IEmailSendenRepository
{
    public string $alias = 'v_Email_Senden';

    /**
     * @param SIN $sin
     * @return v_Email_Senden|null
     */
    public function findBySIN(SIN $sin): ?v_Email_Senden
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->where("{$this->alias}.simpleId = :id")
            ->setParameter('id', $sin->value())
            ->getQuery()
            ->getOneOrNullResult();
    }
}

