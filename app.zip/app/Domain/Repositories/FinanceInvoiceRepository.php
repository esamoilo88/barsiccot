<?php

namespace App\Domain\Repositories;

use App\Components\Calendar\Calendar;
use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Entities\FinanceInvoice;
use App\Domain\Entities\FinanceStream;
use App\Domain\Entities\OfferProfitcenterSettings;
use App\Domain\Repositories\Interfaces\IFinanceInvoiceRepository;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;

class FinanceInvoiceRepository extends BaseRepository implements IFinanceInvoiceRepository
{
    protected string $alias = 'FinanceInvoice';

    /**
     * @param int|null $streamId
     * @param int|null $invoiceId
     * @param bool $isForSap
     * @param bool $open
     * @return array
     */
    public function findInvoices(
        ?int $streamId = null,
        ?int $invoiceId = null,
        bool $isForSap = false,
        bool $open = true
    ): array
    {
        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select(
                $this->alias,
                'auftrag',
                'apartner',
                'debitor',
                'stream',
                'vorgang',
                'positions',
                'lbus',
                'psp',
                'matnr',
                'sachkonto'
            )
            ->leftJoin("{$this->alias}.ansprechpartner", 'apartner')
            ->leftJoin("{$this->alias}.debitor", 'debitor')
            ->leftJoin("{$this->alias}.stream", 'stream')
            ->leftJoin("{$this->alias}.vorgangstyp", 'vorgang')
            ->leftJoin("{$this->alias}.positions", 'positions')
            ->leftJoin("positions.lbus", 'lbus')
            ->leftJoin("positions.auftrag", 'auftrag')
            ->leftJoin("positions.psp", 'psp')
            ->leftJoin("positions.matNr", 'matnr')
            ->leftJoin("positions.sachkonto", 'sachkonto');

        if (!is_null($invoiceId)) {
            $query->where("{$this->alias}.id = :invoiceId")
                ->setParameter("invoiceId", $invoiceId);
        }

        if (!is_null($streamId)) {
            $query->andWhere("{$this->alias}.stream = :streamId")
                ->setParameter("streamId", $streamId);
        }

        if ($open) {
            $query->andWhere("{$this->alias}.closed = 0");
        }

        return $query->orderBy("{$this->alias}.created", "ASC")
            ->getQuery()
            ->getResult();
    }

    /**
     * @param array $ids
     * @return array
     */
    public function findOpenInvoicesByIds(array $ids): array
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        return $qb->select(
                $this->alias,
                'auftrag',
                'apartner',
                'debitor',
                'stream',
                'vorgang',
                'positions',
                'lbus',
                'psp',
                'matnr',
                'sachkonto'
            )
            ->leftJoin("{$this->alias}.ansprechpartner", 'apartner')
            ->leftJoin("{$this->alias}.debitor", 'debitor')
            ->leftJoin("{$this->alias}.stream", 'stream')
            ->leftJoin("{$this->alias}.vorgangstyp", 'vorgang')
            ->leftJoin("{$this->alias}.positions", 'positions')
            ->leftJoin("positions.lbus", 'lbus')
            ->leftJoin("positions.auftrag", 'auftrag')
            ->leftJoin("positions.psp", 'psp')
            ->leftJoin("positions.matNr", 'matnr')
            ->leftJoin("positions.sachkonto", 'sachkonto')
            ->where("{$this->alias}.id IN (:ids)")
            ->andWhere("{$this->alias}.closed = 0")
            ->setParameter('ids', $ids)
            ->getQuery()
            ->getResult();
    }

    /**
     * Remove all opened invoices before creating new
     * @param int $streamId
     */
    public function removeOpenInvoices(int $streamId): void
    {
        $this->genericRepository->createQueryBuilder($this->alias)
            ->delete()
            ->where("{$this->alias}.closed = 0")
            ->andWhere("{$this->alias}.stream = :streamId")
            ->setParameter("streamId", $streamId)
            ->getQuery()
            ->execute();
    }

    /**
     * @param PaginationRequestDTO $dto
     * @param bool $actualFakturaMonth
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getList(PaginationRequestDTO $dto, bool $actualFakturaMonth = false): PaginationResponseDTO
    {
        /** @var QueryBuilder $qb */
        $qb = $this->genericRepository->createQueryBuilder($this->alias);

        $qb->select($this->alias, 'positions', 'stream')
            ->join(OfferProfitcenterSettings::class, 'profitcenter', Join::WITH, "profitcenter.stream = {$this->alias}.stream")
            ->join('profitcenter.billingType', 'billingType')
            ->join("{$this->alias}.stream", 'stream')
            ->leftJoin("{$this->alias}.positions", 'positions')
            ->where('billingType.hardBilling = 0')
            ->andWhere("profitcenter.frequency = 'monthly_3AT'")
            ->andWhere('stream.hide = 0')

            ->orderBy("{$this->alias}.closed", 'ASC')
            ->addOrderBy("{$this->alias}.created", 'DESC');

        if ($actualFakturaMonth) {
            $currFakturaYear = Calendar::getCurrentFakturaYear();
            $currFakturaMonth = Calendar::getCurrentFakturaMonth();

            $qb->andWhere("{$this->alias}.fakturaJahr = :fakturaJahr")
                ->andWhere("{$this->alias}.fakturaMonat = :fakturaMonat")
                ->setParameters([
                    'fakturaJahr' => $currFakturaYear,
                    'fakturaMonat' => $currFakturaMonth,
                ]);
        }

        $paginate = new Paginate($this, $qb, $dto, null);

        return $paginate->proceedPagination();
    }

    /**
     * @param FinanceStream $stream
     * @param int $year
     * @param int $month
     * @return int
     */
    public function getStreamCount(FinanceStream $stream, int $year, int $month): int
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        /** @var FinanceInvoice $result */
        $result = $qb->select($this->alias, 'stream', 'invoices')
            ->leftJoin("{$this->alias}.stream", 'stream')
            ->leftJoin('stream.invoices', 'invoices')
            ->where("stream.id = :stream")
            ->andWhere('invoices.fakturaJahr = :currDateYear')
            ->andWhere('invoices.fakturaMonat = :currDateMonth')
            ->setParameter('currDateYear', $year)
            ->setParameter('currDateMonth', $month)
            ->setParameter('stream', $stream)
            ->getQuery()
            ->getResult();

        if ($result = $result[0] ?? null) {
            return $result->getStream()->getInvoices()->count();
        }

        return 0;
    }

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }
}
