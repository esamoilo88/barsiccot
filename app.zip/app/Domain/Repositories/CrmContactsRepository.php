<?php


namespace App\Domain\Repositories;


use App\Domain\Entities\CrmContacts;
use App\Domain\Repositories\Interfaces\ICrmContactsRepository;

class CrmContactsRepository extends BaseRepository implements ICrmContactsRepository
{
    protected string $alias = 'CrmContacts';

    /**
     * @param int $customerId
     * @return CrmContacts[]
     */
    public function findByCustomerId(int $customerId): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select($this->alias, 'role')
            ->join("{$this->alias}.role", 'role')
            ->where("{$this->alias}.customer = :customerId")
            ->setParameter('customerId', $customerId)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param int $id
     * @return CrmContacts|object|null
     */
    public function find(int $id): ?CrmContacts
    {
        return $this->genericRepository->find($id);
    }
}
