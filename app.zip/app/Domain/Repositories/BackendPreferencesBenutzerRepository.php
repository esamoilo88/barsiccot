<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\BackendPreferencesBenutzer;
use App\Domain\Repositories\Interfaces\IBackendPreferencesBenutzerRepository;

class BackendPreferencesBenutzerRepository extends BaseRepository implements IBackendPreferencesBenutzerRepository
{
    protected string $alias = 'BackendPreferencesBenutzer';

    /**
     * @param  int  $id
     * @return BackendPreferencesBenutzer|object|null
     */
    public function find(int $id): ?BackendPreferencesBenutzer
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param int $userId
     * @param bool $grouped - grouped by preference id
     * @return array
     */
    public function findByUser(int $userId, bool $grouped = false): array
    {
        $result = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($this->alias)
            ->andWhere("{$this->alias}.benutzer = :user")
            ->setParameter('user', $userId)
            ->getQuery()
            ->getResult();

        $preferences = [];
        if ($grouped) {
            /** @var BackendPreferencesBenutzer $p */
            foreach ($result as $p) {
                $preferences[$p->getPreference()->getId()] = $p;
            }
        } else {
            $preferences = $result;
        }

        return $preferences;
    }
}
