<?php

namespace App\Domain\Repositories;

use App\Domain\Entities\FinanceAutomationSuperglobal;
use App\Domain\Repositories\Interfaces\IFinanceAutomationSuperglobalRepository;

use App\Domain\Repositories\BaseRepository;
use App\Domain\ValueObjects\SIN;

class FinanceAutomationSuperglobalRepository extends BaseRepository implements IFinanceAutomationSuperglobalRepository
{

    protected string $alias = 'finance_automation_superglobal';

    /**
     * @param int $id
     * @return FinanceAutomationSuperglobal|object|null
     */
    public function find(int $id): ?FinanceAutomationSuperglobal
    {
        return $this->genericRepository->find($id);
    }

    /**
     * @param SIN $sin
     * @return FinanceAutomationSuperglobal|object|null
     */
    public function findBySIN(SIN $sin): ?FinanceAutomationSuperglobal
    {
        return $this->genericRepository->findOneBy(['simpleId' => $sin->value()]);
    }
}
