<?php


namespace App\Domain\Repositories;


use App\Domain\Repositories\Interfaces\ICrmRoleRepository;

class CrmRoleRepository extends BaseRepository implements ICrmRoleRepository
{
    protected string $alias = 'CrmRole';

    /**
     * @return array
     */
    public function getRoles(): array
    {
        $qb = $this->customQueryBuilder->getQueryBuilder();

        return $qb->select(
            "{$this->alias}.id",
            "{$this->alias}.name as text",
        )
            ->where("{$this->alias}.hide = 0")
            ->orderBy("{$this->alias}.sort", 'ASC')
            ->getQuery()
            ->getResult();
    }
}
