<?php

namespace App\Domain\Repositories;

use App\Domain\DTO\Pagination\PaginationRequestDTO;
use App\Domain\DTO\Pagination\PaginationResponseDTO;
use App\Domain\Repositories\Utils\Filters\Filterable;
use App\Domain\Repositories\Utils\Filters\SuperAdmin\ConfigGridFilters;
use App\Domain\Repositories\Interfaces\IBackendConfigRepository;
use App\Domain\Repositories\Utils\Paginate\Paginate;
use App\Exceptions\Application\SortFieldIsNotSetException;
use Doctrine\ORM\Query;
use App\Domain\Repositories\BaseRepository;

class BackendConfigRepository extends BaseRepository implements IBackendConfigRepository
{
    protected string $alias = 'BackendConfig';

    /**
     * @param array $fields
     * @return array
     */
    public function getConfig(array $fields): array
    {
        array_walk($fields, function (&$item) {
            $item = "{$this->alias}.{$item}";
        });
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select($fields)
            ->getQuery()
            ->getResult(Query::HYDRATE_ARRAY);
    }

    /**
     * @param PaginationRequestDTO $gridParamsDTO
     * @param Filterable|null $filter
     * @return PaginationResponseDTO
     * @throws SortFieldIsNotSetException
     */
    public function getPaginated(PaginationRequestDTO $gridParamsDTO, Filterable $filter = null): PaginationResponseDTO
    {
        $fields = [
            "{$this->alias}.confGroup", "{$this->alias}.id", "{$this->alias}.name",
            "{$this->alias}.valueProd", "{$this->alias}.valueDev", "{$this->alias}.isJson"
        ];

        $query = $this->genericRepository->createQueryBuilder($this->alias)
            ->select($fields)
            ->groupby(...$fields);

        $paginate = new Paginate($this, $query, $gridParamsDTO, $filter);

        return $paginate->proceedPagination();
    }

    /**
     * Get the list of all possible config groups
     * @return array
     */
    public function getConfigGroups(): array
    {
        return $this->genericRepository->createQueryBuilder($this->alias)
            ->select("{$this->alias}.confGroup")
            ->distinct()
            ->getQuery()
            ->getArrayResult();
    }

    /**
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * @return array
     */
    public function getSortableFields(): array
    {
        return [
          'id' => "{$this->alias}.id"
        ];
    }
}
