<?php

namespace App\Domain\Repositories;

use App\Domain\Repositories\Interfaces\ICompetenceElementsRepository;
use App\Domain\ValueObjects\SIN;

class CompetenceElementsRepository extends BaseRepository implements ICompetenceElementsRepository
{
    public string $alias = 'CompetenceElements';

    /**
     * @param SIN $sin
     * @return array
     */
    public function findBySin(SIN $sin): array
    {
        return $this->genericRepository
            ->createQueryBuilder($this->alias)
            ->where("{$this->alias}.simpleId = :simpleId")
            ->setParameter('simpleId', $sin->value())
            ->getQuery()
            ->getResult();
    }

    /**
     * @param SIN $sin
     */
    public function deleteBySIN(SIN $sin): void
    {
        $this->genericRepository->createQueryBuilder($this->alias)
            ->delete()
            ->where("{$this->alias}.simpleId = :simpleId")
            ->setParameters([
                'simpleId' => $sin->value(),
            ])
            ->getQuery()
            ->execute();
    }
}
