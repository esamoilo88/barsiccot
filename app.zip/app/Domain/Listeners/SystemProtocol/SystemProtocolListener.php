<?php

namespace App\Domain\Listeners\SystemProtocol;

use App\Domain\Annotations\SystemProtocol;
use App\Domain\Entities\Interfaces\Loggable;
use App\Domain\Signatures\SystemProtocol\LogGroupSignature;
use App\Services\SystemProtocol\Protocols\FinanceProtocol;
use App\Services\SystemProtocol\Protocols\Onka\OnkaProtocol;
use App\Services\SystemProtocol\Protocols\SalesProtocol;
use App\Services\SystemProtocol\SystemProtocolService;
use Doctrine\Common\Annotations\AnnotationReader;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\Event\LifecycleEventArgs;
use Doctrine\ORM\Event\PreUpdateEventArgs;

class SystemProtocolListener
{
    private SystemProtocolService $systemProtocolService;
    private SalesProtocol $salesProtocol;
    private OnkaProtocol $onkaProtocol;
    private FinanceProtocol $financeProtocol;
    private EntityManagerInterface $em;

    private array $mapping;

    /**
     * SystemProtocolListener constructor.
     * @param SystemProtocolService $systemProtocolService
     * @param SalesProtocol $salesProtocol
     * @param OnkaProtocol $onkaProtocol
     * @param FinanceProtocol $financeProtocol
     * @param EntityManagerInterface $em
     */
    public function __construct(
        SystemProtocolService $systemProtocolService,
        SalesProtocol $salesProtocol,
        OnkaProtocol $onkaProtocol,
        FinanceProtocol $financeProtocol,
        EntityManagerInterface $em
    )
    {
        $this->systemProtocolService = $systemProtocolService;
        $this->salesProtocol = $salesProtocol;
        $this->onkaProtocol = $onkaProtocol;
        $this->financeProtocol = $financeProtocol;
        $this->em = $em;

        $this->mapping = [
            LogGroupSignature::SALES()->value()   => $this->salesProtocol,
            LogGroupSignature::FINANCE()->value() => $this->financeProtocol,
            LogGroupSignature::AP()->value()      => $this->onkaProtocol,
            LogGroupSignature::LP()->value()      => $this->onkaProtocol,
            LogGroupSignature::EL()->value()      => $this->onkaProtocol,
            LogGroupSignature::BER()->value()     => $this->onkaProtocol,
            LogGroupSignature::VAR()->value()     => $this->onkaProtocol
        ];
    }

    /**
     * @param Loggable $entity
     * @param LifecycleEventArgs $args
     * @throws \ReflectionException
     */
    public function prePersist(Loggable $entity, LifecycleEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->prePersist($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @param LifecycleEventArgs $args
     * @throws \ReflectionException
     */
    public function postPersist(Loggable $entity, LifecycleEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->postPersist($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @param PreUpdateEventArgs $args
     * @throws \ReflectionException
     */
    public function preUpdate(Loggable $entity, PreUpdateEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->preUpdate($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @param LifecycleEventArgs $args
     * @throws \ReflectionException
     */
    public function postUpdate(Loggable $entity, LifecycleEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->postUpdate($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @param LifecycleEventArgs $args
     * @throws \ReflectionException
     */
    public function preRemove(Loggable $entity, LifecycleEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->preRemove($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @param LifecycleEventArgs $args
     * @throws \ReflectionException
     */
    public function postRemove(Loggable $entity, LifecycleEventArgs $args)
    {
        $this->mapping[$this->getGroup($entity)->value()]->postRemove($entity, $args);
    }

    /**
     * @param Loggable $entity
     * @return mixed
     * @throws \ReflectionException
     * @throws \Exception
     */
    private function getGroup(Loggable $entity)
    {
        $className = $this->em->getClassMetadata(get_class($entity))->getName();
        $refClass = new \ReflectionClass($className);
        $reader = new AnnotationReader();
        /** @var SystemProtocol|null $spAnnotation */
        $spAnnotation = $reader->getClassAnnotation($refClass, SystemProtocol::class);

        if (!$spAnnotation) {
            throw new \Exception("Couldn't get SystemProtocol annotation from " . get_class($entity));
        }

        if (!$spAnnotation->group || !method_exists(LogGroupSignature::class, $spAnnotation->group)) {
            throw new \Exception("Couldn't get SystemProtocol group from " . get_class($entity));
        }

        return call_user_func([LogGroupSignature::class, $spAnnotation->group]);
    }
}
