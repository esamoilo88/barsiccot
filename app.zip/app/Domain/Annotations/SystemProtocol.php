<?php

namespace App\Domain\Annotations;

use Doctrine\Common\Annotations\Annotation;

/**
 * @Annotation
 * @Target("ALL")
 */
class SystemProtocol
{
    /**
     * @var string
     */
    public string $prettyName;

    /**
     * @var array
     */
    public array $messages = [];

    /**
     * @var string
     */
    public string $group;
}
