<?php

namespace App\Domain\Formatters;

use App\Components\Formatter\Formatter;
use App\Domain\DTO\Ldap\LdapQueryDTO;
use App\Domain\Signatures\DateFormat\DateFormatSignature;
use App\Exceptions\Application\ObjectPropertyIsNotSetException;
use App\Services\LDAP\LdapSearchService;
use LdapRecord\ConnectionException;

class MailsListResponseFormatter implements ResponseFormatter
{
    private LdapSearchService $service;

    /**
     * MailsListResponseFormatter constructor.
     * @param LdapSearchService $service
     */
    public function __construct(LdapSearchService $service)
    {
        $this->service = $service;
    }

    /**
     * @param $item
     * @return array
     */
    public function make($item): array
    {
        return [
            'sentAt' => Formatter::dateToString($item['sentAt'], DateFormatSignature::dateDMYWithHoursAndMinutes()),
            'subject' => $item['subject'],
            'mailId' => $item['mailId'],
            'from' => $this->getName($item['von']),
            'to' => $this->getName($item['an'])
        ];
    }

    /**
     * @param string $from
     * @return string
     * @throws ObjectPropertyIsNotSetException
     * @throws ConnectionException
     */
    private function getName(string $from): string
    {
        if ($from === env('MAIL_FROM_ADDRESS')) {
            return 'SIMPLE no-reply';
        }

        //if there were few receivers, we take only the first for displaying
        if (str_contains($from, ';')) {
            $from = explode(';', $from)[0];
        }

        $ldapUser = $this->service->search(new LdapQueryDTO($from));

        return $ldapUser === [] ? '': $ldapUser[0]['display_name'];
    }
}
