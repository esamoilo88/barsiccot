<?php

namespace App\Domain\Formatters;

use App\Components\Formatter\Formatter;
use App\Domain\Entities\GlobalLog;
use App\Domain\Signatures\DateFormat\DateFormatSignature;

class LogFormatter implements ResponseFormatter
{
    /**
     * @param GlobalLog $item
     * @return array
     */
    public function make($item): array
    {
        return [
            'logText' => $item->getLogText(),
            'timestamp' => Formatter::dateToString($item->getTimestamp(), DateFormatSignature::dateDMYWithHoursAndMinutes()),
            'user' => $item->getBenutzer() ? $item->getBenutzer()->getFullName() : null
        ];
    }
}