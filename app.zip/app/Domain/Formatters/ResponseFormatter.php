<?php

namespace App\Domain\Formatters;

interface ResponseFormatter
{
    /**
     * @param $item
     * @return array
     */
    public function make($item): array;
}