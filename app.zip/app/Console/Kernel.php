<?php

namespace App\Console;

use App\Console\Commands\EntityGenerator\GenerateAll;
use App\Console\Commands\EntityGenerator\GenerateDoctrineRepository;
use App\Console\Commands\EntityGenerator\GenerateEntity;
use App\Console\Commands\EntityGenerator\GenerateRepositoryInterface;
use App\Jobs\Automail\AutomailJob;
use App\Jobs\Competence\CancelCompetenceDemandsJob;
use App\Jobs\CRM\AKPImportJob;
use App\Jobs\EBI\EbiMassImportJob;
use App\Jobs\Finance\AutoIlvJob;
use App\Jobs\Finance\FakturaplanJob;
use App\Jobs\Finance\AutoBillJob;
use App\Jobs\Finance\PlanIlvJob;
use App\Jobs\Finance\PresumablyAccountedLbuJob;
use App\Jobs\SapBilling\IsSapAliveJob;
use App\Jobs\SapBilling\SapBillingRegularJob;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Console\Commands\SAPBilling\SAPBilling;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        GenerateEntity::class,
        GenerateDoctrineRepository::class,
        GenerateRepositoryInterface::class,
        GenerateAll::class,
        SAPBilling::class
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $queue = env('USE_QUEUE');

        $schedule
            ->command("queue:work --stop-when-empty --queue={$queue}")
            ->everyMinute()
            ->withoutOverlapping()
            ->runInBackground();

        $schedule->job(new SapBillingRegularJob(), env('SAP_QUEUE'))->hourlyAt(55);

        $schedule->job(new CancelCompetenceDemandsJob(), env('COMPETENCE_DEMANDS_QUEUE'))->daily();

        $schedule->job(new EbiMassImportJob(), env('EBI_MASS_IMPORT_QUEUE'))->monthlyOn(1, '04:00');

        $schedule->job(new AKPImportJob(), env('AKP_IMPORT_QUEUE'))->dailyAt('03:55');

        $schedule->job(new AutomailJob(), env('AUTOMAIL_QUEUE'))->dailyAt('02:00');

        $schedule->job(new AutoIlvJob(), env('AUTO_ILV_QUEUE'))->dailyAt('03:00');

        $schedule->job(new PlanIlvJob(), env('PLAN_ILV_QUEUE'))->dailyAt('06:00');

        $schedule->job(new FakturaplanJob(), env('FAKTURAPLAN_QUEUE'))->dailyAt('07:00');

        $schedule->job(new PresumablyAccountedLbuJob(), env('PRESUMABLY_ACCOUNTED_LBU_QUEUE'))->dailyAt('07:00');

        $schedule->job(new IsSapAliveJob(), 'isAlive', env('SAP_QUEUE'))->dailyAt('15:00');

        $schedule->job(new AutoBillJob(), env('AUTO_BILL_QUEUE'))->dailyAt('05:00');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
