<?php

namespace App\Console\Commands\Automail;

use App\Services\MailHistory\Automail\AutomailService;
use Illuminate\Console\Command;

class AutomailCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'automail:run';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Automail';

    /**
     * @param AutomailService $service
     */
    public function handle(AutomailService $service)
    {
        $service->proceed();
    }
}