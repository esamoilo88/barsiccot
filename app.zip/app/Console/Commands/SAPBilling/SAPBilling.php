<?php

namespace App\Console\Commands\SAPBilling;


use App\Services\SAP\HardBilling\HardBillingService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class SAPBilling extends Command
{
    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'sapbilling:bill {ft : The faktura type, either regular or collective}';

    /**
     * @var string
     */
    protected $description = 'Executes hourly hard billing process';

    public function handle(HardBillingService $hardBillingService)
    {
        $fakturaType = $this->argument('ft');
        switch ($fakturaType) {
            case 'regular':
                $hardBillingService->executeBilling();
                break;
        }

        return;
    }
}

