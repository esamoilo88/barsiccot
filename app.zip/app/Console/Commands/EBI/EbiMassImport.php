<?php

namespace App\Console\Commands\EBI;

use App\Services\EBI\EBIMassImportService;
use Illuminate\Console\Command;

class EbiMassImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ebi:massimport';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'EBI mass import';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param EBIMassImportService $service
     * @return void
     */
    public function handle(EBIMassImportService $service)
    {
        $service->import();
    }
}
