<?php

namespace App\Console\Commands\EntityGenerator;

use Illuminate\Console\GeneratorCommand;

class GenerateDoctrineRepository extends GeneratorCommand
{

    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'make:repository:doctrine {name}';

    /**
     * @var string
     */
    protected $description = 'Generates Doctrine Repository';

    /**
     * @var string
     */
    protected $type = "Doctrine Repository";
    /**
     * Get the stub file for the generator.
     *
     * @return string
     */
    protected function getStub()
    {
        return __DIR__ . "/stubs/doctrine_repository.stub";
    }


    /**
     * Get the default namespace for the class.
     *
     * @param  string  $rootNamespace
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace.'\Domain\Repositories';
    }


    /**
     * Get the desired class name from the input.
     *
     * @return string
     */
    protected function getNameInput()
    {
        return ucfirst(trim($this->argument('name')));
    }


    /**
     * Get the destination class path.
     *
     * @param  string  $name
     * @return string
     */
    protected function getPath($name)
    {
        $className = $this->getClassName($name);

        return parent::getPath($className);
    }

    /**
     * @param  string  $path
     * @return string
     */
    protected function getClassName(string $path)
    {
        return $path . "Repository";
    }
}
