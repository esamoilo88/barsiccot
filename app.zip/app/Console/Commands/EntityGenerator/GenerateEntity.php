<?php

namespace App\Console\Commands\EntityGenerator;

use Illuminate\Console\GeneratorCommand;
use League\Flysystem\FileNotFoundException;

class GenerateEntity extends GeneratorCommand
{

    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'make:entity {name}';

    /**
     * @var string
     */
    protected $description = 'Generates Doctrine Entity';

    /**
     * @var string
     */
    protected $type = "Doctrine Entity";


    /**
     * Get the stub file for the generator.
     *
     * @return string
     */
    protected function getStub()
    {
        return __DIR__ . "/stubs/entity.stub";
    }


    /**
     * Get the default namespace for the class.
     *
     * @param  string  $rootNamespace
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace.'\Domain\Entities';
    }


    /**
     * Get the desired class name from the input.
     *
     * @return string
     */
    protected function getNameInput()
    {
        return ucfirst(trim($this->argument('name')));
    }


    /**
     * Build the class with the given name.
     *
     * @param  string  $name
     *
     * @return string
     *
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    protected function buildClass($name)
    {
        return  str_replace(
            'DummyTable',
            strtolower(str_replace($this->getNamespace($name).'\\', '', $name) . 's'),
            parent::buildClass($name)
        );
    }
}
