<?php

namespace App\Console\Commands\EntityGenerator;

use Illuminate\Console\GeneratorCommand;

class GenerateRepositoryInterface extends GeneratorCommand
{

    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'make:repository:interface {name}';

    /**
     * @var string
     */
    protected $description = 'Generates Repository Interface';

    /**
     * @var string
     */
    protected $type = "Repository Interface";

    /**
     * Get the stub file for the generator.
     *
     * @return string
     */
    protected function getStub()
    {
        return __DIR__ . "/stubs/repository_interface.stub";
    }


    /**
     * Get the default namespace for the class.
     *
     * @param  string  $rootNamespace
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace.'\Domain\Repositories\Interfaces';
    }


    /**
     * Get the desired class name from the input.
     *
     * @return string
     */
    protected function getNameInput()
    {
        return ucfirst(trim($this->argument('name')));
    }


    /**
     * Get the destination class path.
     *
     * @param  string  $name
     * @return string
     */
    protected function getPath($name)
    {
        $className = $this->getClassName($name);

        return parent::getPath($className);
    }

    /**
     * @param  string  $path
     * @return string
     */
    protected function getClassName(string $path)
    {
        $pathExploded = explode('\\', $path);
        $name = end($pathExploded);
        $className = "I" . $name . "Repository";
        return str_replace($name, $className, $path);
    }
}
