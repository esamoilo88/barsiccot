<?php

namespace App\Console\Commands\EntityGenerator;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Console\Input\InputArgument;

/**
 * Class GenerateAll
 * @package App\Console\Commands\EntityGenerator
 */
class GenerateAll extends Command
{

    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'make:entity:all 
                            {name : The name of the class} 
                            {--except=*}';

    /**
     * @var string
     */
    protected $description = 'Generates Entity and Repositories';

    /**
     * List of possible generators
     *
     * @var string[]
     */
    protected $generators = [
        'entity' => 'entity',
        'repository' => 'repository:interface',
        'doctrine_repository' => 'repository:doctrine',
    ];


    public function handle()
    {
        $name = $this->argument('name');
        $excepted = $this->getExcepted();
        foreach ($this->generators as $label => $generator){
            if(in_array($label, $excepted)){
                continue;
            }

            Artisan::call("make:" . $generator, ['name' => $name]);
        }

        return;
    }

    /**
     * Get Classes excepted from generation
     */
    protected function getExcepted()
    {
        return array_map(
            function ($el){
                return strtolower($el);
            },
            $this->option('except')
        );
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['name', InputArgument::REQUIRED, 'The name of the entity'],
        ];
    }
}
