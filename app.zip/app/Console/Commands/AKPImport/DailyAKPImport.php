<?php

namespace App\Console\Commands\AKPImport;

use App\Jobs\CRM\UpdateCrmDataJob;
use App\Services\AKPImport\AKPImportService;
use Illuminate\Console\Command;

class DailyAKPImport extends Command
{
    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'akpimport:import {format?}';

    /**
     * @var string
     */
    protected $description = 'Executes daily akp import process';

    public function handle(AKPImportService $akpImportService)
    {
        $format = $this->argument('format');
        $akpImportService->import($format);

        dispatch_sync(new UpdateCrmDataJob());
    }
}

